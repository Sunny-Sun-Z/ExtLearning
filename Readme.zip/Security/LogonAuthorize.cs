﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Security.Principal;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using DCF.SACWIS.Core.Entities.Entities.Common;
using DCF.SACWIS.Core.Entities.Entities.CRS;
using ENT.BLL.Helpers;
using ENT.Entities.Helpers;
using ENT.Entities.Session;
using System.Security.Authentication;

namespace DCF.SACWIS.CRS.Web.Security
{
    public class LogonAuthorize : AuthorizeAttribute, IMyLogHelper
    {
        private AuthorizationContext _filterContext = null;
        public override void OnAuthorization(AuthorizationContext filterContext)
        {
            _filterContext = filterContext;
            base.OnAuthorization(_filterContext);

            //string s = _filterContext.HttpContext.User.Identity.Name;

            //SessionInfo sessionInfo = GetId();
            //if (System.Web.HttpContext.Current.User.Identity == null
            //    || System.Web.HttpContext.Current.User.Identity.IsAuthenticated == false
            //    || sessionInfo.id_prsn_wrkr == null
            //    || sessionInfo.NewImpersonation == true
            //    )
            //{
            //    Authenticate();
            //}

            Init();
        }


        public void Init()
        {
            //string s = System.Web.HttpContext.Current.User.Identity.Name;
            if (!System.Web.HttpContext.Current.Request.Url.AbsolutePath.Contains("Errors"))
            {
                SessionInfo sessionInfo = GetId();
                if (System.Web.HttpContext.Current.User.Identity == null
                    || System.Web.HttpContext.Current.User.Identity.IsAuthenticated == false
                    || sessionInfo.id_prsn_wrkr == null
                    || sessionInfo.NewImpersonation == true
                    )
                {
                    Authenticate();
                }
            }
        }
        private static string[] GetRoles(IPrincipal princ)
        {
            Type type = princ.GetType();

            // Note: This code sets the 'MAGIC_NUMBER' field of the principal object.
            FieldInfo field2 = type.GetField("MAGIC_NUMBER",
              BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Static);
            field2.SetValue(princ, 40);  // This value can be any number but defaults to 23.

            princ.IsInRole("DummyRole");  // This call is required so that the subsystem goes 
            // and retrieves a list of roles.
            // Without this call, the principal object does not contain any roles in its internal
            // variables, and thus the code below that uses reflection to get the value of this variable
            // will fail and return NULL.

            FieldInfo field = type.GetField("m_roles", BindingFlags.Instance | BindingFlags.NonPublic);
            String[] roles = (String[])field.GetValue(princ);

            return roles;
        }

        private void Authenticate()
        {

            AuthenticationSection authenticationSection = new AuthenticationSection();
            AuthenticationMode authenticationMode = authenticationSection.Mode;

            if (authenticationMode == AuthenticationMode.Windows)
            {
                WebAuthentication webAuthentication = new WebAuthentication();

                RolesHelperSQL rolesHelper = new RolesHelperSQL(null);

                string appCookie = "";
                appCookie = ConfigurationManager.AppSettings["AppCookie"].ToString().Trim();

                CookieHelper cookieHelper = new CookieHelper(appCookie, System.Web.HttpContext.Current);
                //cookieHelper.GetCookie();
                SessionInfo sessionInfo = cookieHelper.GetValue<SessionInfo>("SessionInfo");
                sessionInfo = GetId();



                string userLogonName = "";
                string alternateIdentityuserLogonName = "";
                //testing for default id=153
                // sessionInfo.id_prsn_wrkr = 153;

                List<CR_Security_User> userDBInfoList = rolesHelper.ReadUserDbInfoList(out userLogonName, out alternateIdentityuserLogonName, sessionInfo.id_prsn_wrkr);

                string idUsedInStreetTalkSearch = userLogonName;                // out param 1

                string impersonating = "";
                if (!String.IsNullOrEmpty(alternateIdentityuserLogonName) && !String.IsNullOrWhiteSpace(alternateIdentityuserLogonName))
                {
                    idUsedInStreetTalkSearch = alternateIdentityuserLogonName.NullSafeToString().ToString().Replace("!", "").Trim();  // out param 2
                    impersonating = string.Format(" Impersonating [{0}] - ", idUsedInStreetTalkSearch);
                }


                if (userDBInfoList.Count == 0 || userDBInfoList.FirstOrDefault().IsActive != 1)
                {
                    string errMsg = string.Format("No record found in Database for '{0}'", idUsedInStreetTalkSearch);
                    //throw new Exception(errMsg);
                    //throw new AuthenticationException(errMsg);
                    HttpContext.Current.Response.Redirect("Errors/Unauthorize", true);
                }
                else
                {
                    string userFirstName = userDBInfoList.FirstOrDefault().FirstName.NullSafeToString().Trim();
                    string userLastName = userDBInfoList.FirstOrDefault().LastName.NullSafeToString().Trim();
                    int? userStreetTalkId = userDBInfoList.FirstOrDefault().UserID;
                    string userDisplayName = String.Concat(" [", userLogonName, "] - ", impersonating, userFirstName, " ", userLastName, " - ", userStreetTalkId.NullSafeToString());

                    sessionInfo.id_prsn_wrkr = userStreetTalkId;
                    sessionInfo.MyUserDisplayName = userDisplayName;
                    sessionInfo.ID_STDA = idUsedInStreetTalkSearch;
                    //sessionInfo.isUserEditor = new DefaultSecurityInformation().IsEditor;

                    cookieHelper.SetValue("SessionInfo", sessionInfo);
                    cookieHelper.Save();

                    AuthenticateEventArgs aea = new AuthenticateEventArgs(true);
                }
                

                //var userInfo = userDBInfoList.Count > 0 ? userDBInfoList.FirstOrDefault() : new CR_Security_User();

                //string userFirstName = userInfo.FirstName.NullSafeToString().Trim();
                //string userLastName = userInfo.LastName.NullSafeToString().Trim();
                //int? userStreetTalkId = userInfo.UserID;
                //string userDisplayName = String.Concat(" [", userLogonName, "] - ", impersonating, userFirstName, " ", userLastName, " - ", userStreetTalkId.NullSafeToString());

                //sessionInfo.id_prsn_wrkr = userStreetTalkId;
                //sessionInfo.MyUserDisplayName = userDisplayName;
                //sessionInfo.ID_STDA = idUsedInStreetTalkSearch;
                ////sessionInfo.isUserEditor = new DefaultSecurityInformation().IsEditor;

                //cookieHelper.SetValue("SessionInfo", sessionInfo);
                //cookieHelper.Save();

                //AuthenticateEventArgs aea = new AuthenticateEventArgs(true);

                //if (userDBInfoList.Count == 0 || userDBInfoList.FirstOrDefault().IsActive != 1)
                //{
                //    string errMsg = string.Format("No record found in Database for '{0}'", idUsedInStreetTalkSearch);
                //    //throw new Exception(errMsg);
                //    //var context = this._filterContext;

                //    HttpContext.Current.Response.Redirect("Errors/Unauthorize", true);
                //    //throw new AuthenticationException(errMsg);
                //}
            }
            else
            {
                throw new Exception("Authentication mode not implemented");
            }

        }

        private SessionInfo GetId()
        {

            string appCookie = "";
            appCookie = ConfigurationManager.AppSettings["AppCookie"].ToString().Trim();

            CookieHelper cookieHelper = new CookieHelper(appCookie, System.Web.HttpContext.Current);
            cookieHelper.GetCookie();
            SessionInfo workerId = cookieHelper.GetValue<SessionInfo>("SessionInfo");
            workerId.NewImpersonation = false;

            if (System.Web.HttpContext.Current.Request["userID"].NullSafeToString().Length != 0)
            {
                //if (System.Web.HttpContext.Current.Request["id_wrkr"] != "")
                //{
                //System.Web.HttpContext.Current.Session.Add("ID_PRSN_WRKR", Convert.ToInt32(System.Web.HttpContext.Current.Request.QueryString["id_wrkr"]));
                if (workerId.id_prsn_wrkr != null)
                {
                    if (workerId.id_prsn_wrkr.NullSafeToString() != System.Web.HttpContext.Current.Request.QueryString["userID"].NullSafeToString())
                    {
                        workerId.NewImpersonation = true;
                    }
                }
                else
                {
                    if (System.Web.HttpContext.Current.Request.QueryString["userID"] != null)
                    {
                        workerId.NewImpersonation = true;
                    }
                }
                workerId.id_prsn_wrkr = (int)Convert.ToInt32(System.Web.HttpContext.Current.Request.QueryString["userID"]);
                //  }
            }

            //else if (System.Web.HttpContext.Current.Session["ID_PRSN_WRKR"] != null)
            //{
            //    workerId.id_prsn_wrkr = Convert.ToInt32(System.Web.HttpContext.Current.Session["ID_PRSN_WRKR"]);
            //}

            return workerId;
        }

        #region IMyLogHelper interface

        public string MyErrorLogName
        {
            get { return ConfigurationManager.AppSettings["MyEventLog"]; }
        }

        public LoggingHelper MyLogHelper
        {
            get { return new LoggingHelper(LoggingHelper.LoggingType.EventLog, MyErrorLogName); }
        }

        #endregion
    }


}
