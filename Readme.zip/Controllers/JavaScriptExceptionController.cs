﻿using System;
using System.Web.Mvc;
using ENT.Entities.Helpers;
using Ext.Direct.Mvc;
using Microsoft.Practices.Unity;

namespace DCF.SACWIS.CRS.Web.Controllers
{
    // supporting class used by JavaScriptExceptionController (below it)
    public class JavaScriptException : Exception
    {
        private readonly string _stackTrace;
        public JavaScriptException(string message, string stacktrace): base(message)
        {
            _stackTrace = stacktrace;
        }

        public override string StackTrace
        {
            get { return _stackTrace; }
        }
    }

    public class JavaScriptExceptionController : DirectController
    {

        // This code is called by javascript code on the client
        // You can place this code in a file anywhere under app
        // and the bundler will grab it and include it if you use
        // this project as a shell for your application.
        //
        //        Ext.isHandlingError = false;
        //        Ext.lastError = null;
        //        Ext.Error.handle = function (error)
        //        {
        //            if (Ext.isHandlingError) {
        //                return;
        //            }
        //            Ext.isHandlingError = true;
        //            if (error.msg)
        //            {
        //                error.description = error.msg;
        //                error.stack = error.sourceClass + ":" + error.sourceMethod;
        //            }
        //            if (!error.description) {
        //                error = { description: error, stack: '' };
        //            }
        //            if (!error.stack) {
        //                error.stack = "no stack available";
        //            }
        //            error = { errorDescription: error.description, stack: error.stack };
        //            if (!Ext.lastError || error.errorDescription !== Ext.lastError.errorDescription || error.stack !== Ext.lastError.stack) {
        //                window.JavaScriptException.Log(error);
        //                Ext.lastError = { errorDescription: error.description, stack: error.stack };
        //            }
        //            Ext.isHandlingError = false;
        //        };
        //        window.onerror = function (m, u, l, c, error) {
        //            if (!error)
        //                return;
        //            Ext.Error.handle(error);
        //        };

        [NamedArguments]
        public ActionResult Log(string errorDescription, string stack)
        {
            // create a JavaScriptException object and 
            // log it to the event log for this application
            var ex = new JavaScriptException(errorDescription,stack);
            var logHelper = DefaultContainer.Container.Resolve<ILogHelper>();
            if (logHelper != null)
                logHelper.LogExceptionError(ex);
            return null;
        }
    }
}