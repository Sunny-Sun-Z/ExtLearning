﻿using DCF.SACWIS.CRS.Web.Models;
using System.Web.Mvc;

namespace DCF.SACWIS.CRS.Web.Controllers
{
    [AllowAnonymous]
    public class ErrorsController : CRSBaseController
    {
        //
        // GET: /Error/

        public ActionResult Index()
        {
            @ViewBag.Title = "Error";
            ViewBag.ErrorMessage = "Problems in the system, please contact system administrator";
            return View();
        }

        public ActionResult Unauthorize()
        {
            @ViewBag.Title = "401 - Unauthorized";
            return View();
        }
    }
}
;