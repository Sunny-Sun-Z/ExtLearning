﻿using System;
using System.Configuration;
using System.Web;
using System.Web.Mvc;
using DCF.SACWIS.CRS.BLL.Attributes;

namespace DCF.SACWIS.CRS.Web.Controllers
{
    [CRSSecurity]
    public class DashboardController : CRSBaseController
    {
            private readonly HttpContext _currentContext;
        private readonly string _cdn;
        private readonly string _applicationPath;
        /// <summary>
        /// Don't use this constructor for unit testing
        /// </summary>
        public DashboardController()
        {
            _currentContext = System.Web.HttpContext.Current;
            _cdn = ConfigurationManager.AppSettings["CDN"];
            _applicationPath = _currentContext.Request.ApplicationPath;
        }

        ///  <summary>
        ///  Use this constructor for unit testing
        ///  </summary>
        ///  <param name="context">
        ///  this constructor allows us to pass in a context
        ///  using code similar to the following
        ///  var context = new HttpContext(
        ///      new HttpRequest("", "http://tempuri.org", ""),
        ///      new HttpResponse(new StringWriter())
        ///      );
        /// 
        ///  // User is logged in
        ///  context.User = new GenericPrincipal(
        ///      new GenericIdentity("username"),
        ///      new string[0]
        ///      );
        /// 
        ///  // User is logged out
        ///  context.User = new GenericPrincipal(
        ///      new GenericIdentity(String.Empty),
        ///      new string[0]
        ///      );
        ///  
        ///  var controller = new HomeController(context);
        ///  </param>
        /// <param name="cdn">cdnUrl</param>
        /// <param name="applicationPath">Request.ApplicationPath</param>
        public DashboardController(HttpContext context, string cdn, string applicationPath)
        {
            _cdn = cdn;
            _currentContext = context;
            _applicationPath = applicationPath;
        }
        public ActionResult Default(int? id)
        {

            // Since this is a single page application,
            // it is ok for all of this code to be here
            // But if you had multiple pages, you would
            // probably extract this into the constructor
            // of a parent class.
            //ViewBag.extVersion = "5.1.1";
            //ViewBag.baseUrl = "";
            //ViewBag.programVersion = "1.0.0";
            //ViewBag.cdnUrl = _cdn;

            //if (_applicationPath != null)
            //{
            //    ViewBag.baseUrl = _currentContext.Request.Url.Scheme + "://" +
            //           _currentContext.Request.Url.Authority +
            //           _applicationPath.TrimEnd('/');
            //}

            ////////////////////////////////////////
            //// This code allows localhost code to be
            //// run from other computers.  Primarily needed
            //// for Selenium tests.
            ////
            //if (ViewBag.cdnUrl.EndsWith("/"))
            //{
            //    ViewBag.cdnUrl = ViewBag.cdnUrl.Substring(0, ViewBag.cdnUrl.Length - 1);
            //}
            //if (ViewBag.cdnUrl.Contains("localhost"))
            //{
            //    if (!ViewBag.baseUrl.Contains("localhost"))
            //    {
            //        var baseUri = new Uri(ViewBag.baseUrl);
            //        ViewBag.cdnUrl = ViewBag.cdnUrl.Replace("/localhost:", "/" + baseUri.Host + ":");
            //    }
            //}

            //ViewBag.appPath = _applicationPath;
            //if (ViewBag.appPath.Length == 1)
            //{
            //    ViewBag.appPath = "";
            //}
            //ViewBag.ext = ViewBag.cdnUrl + "/cdn/js/ext/ext-" + ViewBag.extVersion + "/ext-all.js";
            //ViewBag.framework = ViewBag.cdnUrl + "/cdn/js/framework/" + "5.1.0" + "/framework/framework." + "5.1.0" + ".min.js?" + ViewBag.versionNumber;
            //if (_currentContext.IsDebuggingEnabled)
            //{
            //    ViewBag.ext = ViewBag.cdnUrl + "/cdn/js/ext/ext-" + ViewBag.extVersion + "/ext-all-debug.js";
            //    ViewBag.framework = ViewBag.cdnUrl + "/cdn/js/framework/" + "5.1.0" + "/framework/framework." + "5.1.0" + ".js?" + ViewBag.versionNumber;
            //}
            ////
            //////////////////////////////////////////////////////




            ViewBag.Title = @"Case Review - Dashboard";

            if (id == null)
                id = 0;
            ViewBag.Id = id;
           //return View();

           return RedirectToAction("", "CRS");
        }

    }
}