﻿using System;
using System.Configuration;
using System.Web.Mvc;
using DCF.SACWIS.CRS.BLL;
using DCF.SACWIS.CRS.Web.Security;
using ENT.BLL.Helpers;
using ENT.Entities.BaseCode;
using ENT.Entities.Helpers;
using ENT.Entities.Session;
using ENT.CBF.BaseCode;

namespace DCF.SACWIS.CRS.Web.Controllers
{
    public class CRSBaseController : Controller, ICrsInformation, IMyUser, IVersionNumber, IEnvironment, IMyLogHelper, IDatabaseSchema
    {
        // This is a controller to return the values of certain parameters,
        // like user, envoirnment, logging info etc.


        protected override void Initialize(System.Web.Routing.RequestContext requestContext)
        {
            base.Initialize(requestContext);

            # region ENT MVC code
            var programVersion = ConfigurationManager.AppSettings["Version"];

            var baseUrl = System.Web.HttpContext.Current.Request.Url.Scheme + "://" +
                System.Web.HttpContext.Current.Request.Url.Authority +
                System.Web.HttpContext.Current.Request.ApplicationPath.TrimEnd('/') + '/';

            var cdnUrl = ConfigurationManager.AppSettings["CDN"];

            //_userLogOnName = System.Web.HttpContext.Current.User.Identity.Name;
            //_userLogOnName = _userLogOnName.NullSafeToString().Substring(_userLogOnName.NullSafeToString().LastIndexOf("\\") + 1);

            //_userDisplayName = System.Web.HttpContext.Current.User.Identity.Name;

            _versionNumber = programVersion;
            _environment = ConfigurationManager.AppSettings["ENVIRONMENT"];

            CookieHelper cookieHelper = new CookieHelper("CRSCookie", System.Web.HttpContext.Current);
            cookieHelper.GetCookie();
            SessionInfo sessionInfo = cookieHelper.GetValue<SessionInfo>("SessionInfo");

            if (sessionInfo.MyUserDisplayName == null)
            {
                LogonAuthorize logonAuthorize = new LogonAuthorize();
                logonAuthorize.Init();
                cookieHelper = new CookieHelper("CRSCookie", System.Web.HttpContext.Current);
                cookieHelper.GetCookie();
                sessionInfo = cookieHelper.GetValue<SessionInfo>("SessionInfo");
            }

            _userDisplayName = sessionInfo.MyUserDisplayName;


            //ViewBag.ext = ViewBag.cdnUrl + "/cdn/js/ext/ext-" + ViewBag.extVersion + "/ext-all.js";
            //ViewBag.framework = ViewBag.cdnUrl + "/cdn/js/framework/" + "5.1.0" + "/framework/framework." + "5.1.0" + ".min.js?" + ViewBag.versionNumber;
            //if (_currentContext.IsDebuggingEnabled)
            //{
            //    ViewBag.ext = ViewBag.cdnUrl + "/cdn/js/ext/ext-" + ViewBag.extVersion + "/ext-all-debug.js";
            //    ViewBag.framework = ViewBag.cdnUrl + "/cdn/js/framework/" + "5.1.0" + "/framework/framework." + "5.1.0" + ".js?" + ViewBag.versionNumber;
            //}

            var ext = cdnUrl + "/cdn/js/ext/ext-5.1.1/ext-all-debug.js";
            //var ext = cdnUrl + "/cdn/js/ext/ext-6.2.0/ext-all-debug.js";
            var framework = cdnUrl + "/cdn/js/framework/5.1.1/framework/framework.5.1.1.js?version=" +_versionNumber;

            if (_environment == "PROD")
            {
                ext = cdnUrl + "/cdn/js/ext/ext-5.1.1/ext-all.js";
                framework = cdnUrl + "/cdn/js/framework/5.1.1/framework/framework.5.1.1.min.js?version=" + _versionNumber;
            }

            var overrideSecurity = ConfigurationManager.AppSettings["OverrideSecurity"];

            MvcControllerBaseViewModel vm = new MvcControllerBaseViewModel() 
            {
                baseUrl = baseUrl,
                programVersion = programVersion,
                cdnUrl = cdnUrl,
                //userLogOnName = _userLogOnName,
                userDisplayName = _userDisplayName,
                versionNumber = _versionNumber,
                environment = _environment,
                userLogOnName = sessionInfo.ID_STDA,
                DatabaseSchema = this.DatabaseSchema,
                extVersion = "5.1.1",
                ext = ext,
                framework = framework
                

            };
            ViewBag.MvcBaseVars = vm;
            #endregion

            var query = System.Web.HttpContext.Current.Request.Url.PathAndQuery;
            if (System.Web.HttpContext.Current.Request.Path.ToLower().Contains(@"/casereview/"))

            {
                var tokens = query.Split('/');
                //if (tokens[2] != null)
                //    baseViewModel.MeetingId = Convert.ToInt32(tokens[2]);
                if (this.ControllerContext != null)
                {
                    if (RouteData.Values["id"] != null)
                    {
                        CaseReviewRootID = Convert.ToInt32(RouteData.Values["id"]);
                        ViewBag.CaseReviewRootID = CaseReviewRootID;
                    }
                }

            }
            ViewBag.UserID = sessionInfo.id_prsn_wrkr;
            ViewBag.OverrideSecurity = overrideSecurity;

        }

        #region ICrsInformation
        public int CaseId
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public int CaseReviewRootID
        {
            get;set;
        }

        public int MeetingId
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public int PersonId
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public int UserID { get; set; }

        #endregion

        #region IMyuser Interface

        protected string _userDisplayName;

        protected string _userFirstName;

        protected string _userLastName;

        protected string _userLogOnName;

        protected int? _userStreetTalkId;
        public string UserLogOnName
        {
            get { return _userDisplayName; }
        }

        public string UserFirstName
        {
            get { return _userFirstName; }
        }

        public string UserLastName
        {
            get { return _userLastName; }
        }

        public string UserDisplayName
        {
            get { return _userLogOnName; }
        }

        public int? UserStreetTalkId
        {
            get { return _userStreetTalkId; }
        }

        #endregion
        
        #region Envoirnment and Version
        private string _environment;

        private string _versionNumber;
        public string VersionNumber
        {
            get { return _versionNumber; }
        }

        public string Environment
        {
            get { return _environment; }
        }

        #endregion

        public string DatabaseSchema
        {
            get { return ConfigurationManager.AppSettings["SACWIS_SQL"]; }
        }

        #region IMyLogHelper interface

        public string MyErrorLogName
        {
            get { return ConfigurationManager.AppSettings["MyEventLog"]; }
        }

        public LoggingHelper MyLogHelper
        {
            get { return new LoggingHelper(LoggingHelper.LoggingType.EventLog, MyErrorLogName); }
        }

        #endregion IMyLogHelper interface
    }
}