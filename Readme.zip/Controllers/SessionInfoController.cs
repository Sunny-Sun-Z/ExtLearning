﻿using System;
using System.Text;
using System.Web;
using ENT.BLL.Helpers;
using ENT.Entities.Session;

namespace DCF.SACWIS.CRS.Web.Controllers
{
        public static class Html
        {
            public static IHtmlString SessionInfo(this System.Web.Mvc.HtmlHelper html)
            {

                CookieHelper cookieHelper = new CookieHelper("CRSCookie", System.Web.HttpContext.Current);
                cookieHelper.GetCookie();
                SessionInfo sessionInfo = cookieHelper.GetValue<SessionInfo>("SessionInfo");

                StringBuilder output = new System.Text.StringBuilder();
                output.Append(String.Format("<br />Welcome {0}", sessionInfo.MyUserDisplayName));

                return html.Raw(output.ToString());


            }
        }
    }

