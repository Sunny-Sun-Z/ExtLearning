﻿using System;
using System.Collections.Generic;

namespace DCF.SACWIS.CRS.Web.Controllers.Data
{
    public class LOOKUPDATA
    {
        public Int32? ID_LOOKUPDATA { get; set; }
        public string TYPE { get; set; }
        public string VALUE { get; set; }
        public string DISPLAY { get; set; }
    }

    public class ADDRESS
    {
        public Int32? ID_ADDRESS { get; set; }
        public Int32? ID_MAINDATA { get; set; }

        public string ADDRESS1 { get; set; }
        public string CITY { get; set; }
        public string STATE { get; set; }
        public string ZIP { get; set; }
    }

    public class CHILD
    {
        public Int32? ID_CHILD { get; set; }
        public Int32? ID_MAINDATA { get; set; }
        public string FIRSTNAME { get; set; }
        public string LASTNAME { get; set; }
        public DateTime? BIRTHDAY { get; set; }
    }

    public class MAINDATA
    {
        public Int32? ID_MAINDATA { get; set; }
        public string FIRSTNAME { get; set; }
        public string LASTNAME { get; set; }
        public DateTime? BIRTHDAY { get; set; }
        // One Record Example
        public List<ADDRESS> ADDRESS { get; set; }
        public List<CHILD> CHILDREN { get; set; }
        public string YES_NO { get; set; }
        public string CHILDREN_EXIST { get; set; }
        public string HIDERADIOS { get; set; }
        public string LOOKUP1VALUE { get; set; }
    }

    public class TopDashboard
    {
        public int id { get; set; }
        public List<LOOKUPDATA> LOOKUPTABLE1 { get; set; }
        public List<LOOKUPDATA> LOOKUPTABLE2 { get; set; }
        public List<LOOKUPDATA> LOOKUPTABLE3 { get; set; }

        public List<LOOKUPDATA> LOOKUPTABLE4 { get; set; }
        public List<DashboardSearchResults> DashboardSearchResultses { get; set; }
    }

    public class TopCaseReview
    {
        public int id { get; set; }
        public List<LOOKUPDATA> LOOKUPTABLE1 { get; set; }
        public List<LOOKUPDATA> LOOKUPTABLE2 { get; set; }
        public List<MAINDATA> MAINDATA { get; set; }
        public List<CaseParticipant> CaseParticipants { get; set; }
    }

    public class CaseParticipant
    {
        public int srNo { get; set; }
        public string ChildName { get; set; }
        public string role { get; set; }

        public string relationship { get; set; }

        public string Interview { get; set; }

    }

    public class DashboardSearchResults
    {

        public int meetingId { get; set; }

        public int caseReviewID { get; set; }
        
        public string caseReviewType { get; set; }

        public string caseReviewFirstName { get; set; }

        public string caseReviewLastName { get; set; }

        public string status { get; set; }

        public DateTime ReviewStartDate { get; set; }

        public DateTime ReviewEndDate { get; set; }

       public string SiteName { get; set; }

        public string Reviewers { get; set; }

    }


}