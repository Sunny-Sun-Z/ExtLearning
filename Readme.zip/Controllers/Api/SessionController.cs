﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
//using System.Web.Mvc;
using DCF.SACWIS.Core.Entities.Entities.Common;
using DCF.SACWIS.Core.Entities.Entities.CRS;
using DCF.SACWIS.CRS.BLL;
using DCF.SACWIS.CRS.Web.Controllers.Data;
using ENT.BLL.Helpers;
using ENT.Entities.BaseCode;
using ENT.Entities.Helpers;
using Ext.Direct.Mvc;
using Microsoft.Practices.Unity;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using ENT.Entities.Visitor;
using DCF.SACWIS.Core.BLL.Visitor;
using System.Reflection;
using ENT.Entities.Session;
using DCF.SACWIS.CRS.Web.Models;
using System.Configuration;
using DCF.SACWIS.CRS.Web.Core.Extensions;

namespace DCF.SACWIS.CRS.Web.Controllers.Api
{
    [RoutePrefix("session")]
    public class SessionController : BaseApiController
    {


        [HttpGet]
        [Route("GetSession")]
        public dynamic GetSession()
        {
            System.Security.Principal.IIdentity id = System.Web.HttpContext.Current.User.Identity;

            var context = System.Web.HttpContext.Current;
            var sessionInfo = new
            {
                databaseSchema = ConfigurationManager.AppSettings["SACWIS_SQL"],
                region = ConfigurationManager.AppSettings["AppEnvironment"].Replace("CRS", "").Trim(),
                year = DateTime.Now.Year,
                browser = context.Request.Browser,
                clientAddr = context.Request.UserHostAddress,
                sessionId = context.Request.Cookies["ASP.NET_SessionId"].Value
            };

            var session = new
            {
                //user = new { id = 153, name = "Kanchan Kora" },
                user = GetUser(id.GetLogin()),
                debug = false,
                resources = ResourcePath,
                assemblyVersion = Assembly.GetExecutingAssembly().GetName().Version.ToString(),
                sessionInfo = sessionInfo,
                exportPath = ExportPath,
                importPath = ImagePath,
                caseExportUrl = CaseExportUrl,
                reportInBrowsers = ReportInBrowsers,
                autoSave = AutoSave
            };
            
            var enable = ConfigurationManager.AppSettings["EnableADProfilePictureSync"];

            if (string.Equals(enable, "true", StringComparison.OrdinalIgnoreCase))
                UpdateUserPictures();
            return new { success = true, session = session };
        }

        private dynamic GetUser(string loginId)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var data = db.CR_Security_User.Where(w => w.LoginID == loginId).Select(e => new
                {
                    id = e.UserID,
                    loginId = e.LoginID,
                    firstName = e.FirstName,
                    lastName = e.LastName,
                    email = e.Email,
                    name = e.FirstName + " " + e.LastName,
                    isActive = e.IsActive,
                    avatar = e.Avatar,
                    role= e.CR_Security_UserRole.FirstOrDefault().CR_Security_Role.Description,
                    roles = e.CR_Security_UserRole.Select(r => r.RoleID).ToList(),
                    permissions = e.CR_Security_UserPermission.Select(p => p.PermissionID).ToList()

                }).FirstOrDefault();

                var allPermissions = db.CR_Security_UserRole.Where(w => w.UserID == data.id)
                    .SelectMany(e => e.CR_Security_Role.CR_Security_RolePermission).ToList()
                    .Select(s => s.CR_Security_Permission)
                  .Union(db.CR_Security_UserPermission.Where(w => w.UserId == data.id)
                  .Select(e => e.CR_Security_Permission)).Select(s => new { id = s.PermissionID, name = s.Description }).Distinct()
                  .ToList();
                ;

                return new
                {
                    id = data.id,
                    loginId = data.loginId,
                    firstName = data.firstName,
                    lastName = data.lastName,
                    email = data.email,
                    name = data.name,
                    isActive = data.isActive,
                    avatar = data.avatar,
                    role = data.role,
                    roles = data.roles,
                    permissions = data.permissions,
                    allPermissions = allPermissions
                };
            }
        }
    }
}
