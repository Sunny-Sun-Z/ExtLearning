﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DCF.SACWIS.CRS.Web.Models;
using DCF.SACWIS.CRS.Web.Models.DB;
using DCF.SACWIS.CRS.BLL;
using System.Reflection;

using DCF.SACWIS.Core.Entities.Entities.CRS;
using System.Globalization;
using DCF.SACWIS.CRS.Web.Core.Enums;
namespace DCF.SACWIS.CRS.Web.Controllers.Api
{
    [RoutePrefix("lookup")]
    public class LookupController : BaseApiController
    {
        [HttpGet]
        [Route("GetLookups")]
        public dynamic GetLookups()
        {
            var lookups = new List<dynamic>();
            try
            {

                var formsBll = new CRS_FormsBLL();

                var data = formsBll.GetCaseReviewLookup();

                foreach (var rec in data.Applicability)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));
                foreach (var rec in data.AssessmentType)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));
                foreach (var rec in data.CaseEliminationReason.OrderBy(o => o.Sequence))
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));
                foreach (var rec in data.CaseReason)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));

                foreach (var rec in data.CrReviewType)
                {
                    lookups.Add(new
                    {
                        group = "CrReviewType",
                        groupId = rec.ReviewTypeID,
                        code = rec.ReviewTypeID,
                        codeId = rec.ReviewTypeID,
                        name = rec.Description
                    });
                }
                foreach (var rec in data.CrReviewSubType)
                {
                    lookups.Add(new
                    {
                        group = "CrReviewSubType",
                        groupId = rec.ReviewSubTypeID,
                        code = rec.ReviewSubTypeID,
                        codeId = rec.ReviewSubTypeID,
                        name = rec.Description,
                        parentCode = rec.ReviewTypeID
                    });
                }

                foreach (var rec in data.CrSecurityRoles)
                {
                    lookups.Add(new
                    {
                        group = "CrSecurityRoles",
                        groupId = rec.RoleID,
                        code = rec.RoleID,
                        codeId = rec.RoleID,
                        name = rec.Description
                    });
                }

                foreach (var rec in data.CrSecurityPermission)
                {
                    lookups.Add(new
                    {
                        group = "CrSecurityPermission",
                        groupId = rec.PermissionID,
                        code = rec.PermissionID,
                        codeId = rec.PermissionID,
                        name = rec.Description
                    });
                }
                foreach (var rec in data.CrSecurityUserPermission)
                {
                    lookups.Add(new
                    {
                        group = "CrSecurityUserPermission",
                        groupId = rec.UserId,
                        code = rec.PermissionID,
                        codeId = rec.UserPermissionID
                    });
                }
                foreach (var rec in data.CrSecurityUserRole)
                {
                    lookups.Add(new
                    {
                        group = "CrSecurityUserRole",
                        groupId = rec.UserID,
                        code = rec.RoleID,
                        codeId = rec.UserRoleID
                    });
                }
                foreach (var rec in data.CrSecurityRolePermission)
                {
                    lookups.Add(new
                    {
                        group = "CrSecurityRolePermission",
                        groupId = rec.RoleID,
                        code = rec.PermissionID,
                        codeId = rec.RolePermissionID
                    });
                }
                foreach (var rec in data.CaseReviewQA)
                    lookups.Add(GetLookupObject(rec, "CaseReviewQA"));
                foreach (var rec in data.CaseReviewReviewers)
                    lookups.Add(GetLookupObject(rec, "CaseReviewReviewers"));

                foreach (var rec in data.CrSecurityUser.OrderBy(o => o.FirstName).ThenBy(o => o.LastName))
                    lookups.Add(GetLookupObject(rec, "CrSecurityUser"));

                lookups.Add(new
                {
                    group = "CrSecurityUserSampling",
                    groupId = 0,
                    code = 0,
                    codeId = 0,
                    name = " Not Assigned"
                });

                foreach (var rec in data.CrSecurityUser.OrderBy(o => o.FirstName).ThenBy(o => o.LastName))
                    lookups.Add(GetLookupObject(rec, "CrSecurityUserSampling"));

                foreach (var rec in data.CaseReviewSecondaryOversight)
                    lookups.Add(GetLookupObject(rec, "CaseReviewSecondaryOversight"));


                foreach (var rec in data.CaseStatus)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));
                foreach (var rec in data.Disposition)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));

                foreach (var rec in data.Ethnicity)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));
                foreach (var rec in data.FosterPlacementConcern)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));
                foreach (var rec in data.FosterSafety)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));
                foreach (var rec in data.Gender)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));
                foreach (var rec in data.ItemRating)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));
                foreach (var rec in data.LivingArrangement)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));
                foreach (var rec in data.MaltreatmentAllegations)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));
                foreach (var rec in data.OutcomeCodes)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));

                foreach (var rec in data.OutcomeCodes)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));

                foreach (var rec in data.OutComeRating)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));

                foreach (var rec in data.ParticipantRole)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));

                foreach (var rec in data.PermanencyGoal1)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(new
                          {
                              groupId = rec.CodeDescriptionID,
                              group = rec.GroupName,
                              code = rec.GroupID,
                              codeId = rec.CodeDescriptionID,
                              name = !string.IsNullOrEmpty(rec.DescriptionSmall) ? rec.DescriptionSmall :
                                    !string.IsNullOrEmpty(rec.DescriptionMedium) ? rec.DescriptionMedium :
                                    !string.IsNullOrEmpty(rec.DescriptionLarge) ? rec.DescriptionLarge : rec.GroupName,
                              small = rec.DescriptionSmall,
                              medium = rec.DescriptionMedium,
                              large = rec.DescriptionLarge
                          });


                foreach (var rec in data.PermanencyGoal2)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));

                foreach (var rec in data.PerpetratorChildRelationship)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));

                foreach (var rec in data.PlacementChangeReason)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));
                foreach (var rec in data.PlacementType)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));
                foreach (var rec in data.PriorityLevel)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));
                foreach (var rec in data.Race)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));
                foreach (var rec in data.SafetyRelatedIncidents)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));
                foreach (var rec in data.Site)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));

                //Shfuang added for new group
                foreach (var rec in data.Office)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));

                foreach (var rec in data.TerminationExceptions)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));
                foreach (var rec in data.TimeUnit)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));

                foreach (var rec in data.TrueFalse)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));

                foreach (var rec in data.VisitationFrequency)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));

                foreach (var rec in data.YesNoNa)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));
                foreach (var rec in data.SiblingVisitationFrequency)
                    if (!string.IsNullOrEmpty(rec.GroupName))
                        lookups.Add(GetLookupObject(rec));


                return new { success = true, data = lookups };
            }
            catch (Exception ex)
            {
                return ex;
            }
        }

        [HttpGet]
        [Route("GetSamplePeriod")]
        public dynamic GetSamplePeriod(string query = "", int start = 0, int limit = 20)
        {
            var lookups = new List<dynamic>();
            try
            {
                var monthNames = DateTimeFormatInfo.CurrentInfo.MonthNames;
                string period1 = SampleMonthPeriod1, period2 = SampleMonthPeriod2, monthName1 = string.Empty, monthName2 = string.Empty, monthName3 = string.Empty, monthName4 = string.Empty;
                int month1 = 0, month2 = 0, month3 = 0, month4 = 0;
                if (!string.IsNullOrEmpty(period1) && period1.IndexOf("-") >= 0)
                {
                    monthName1 = period1.Split('-')[0].Trim();
                    monthName2 = period1.Split('-')[1].Trim();

                    month2 = monthNames.Select(e => e.ToLower()).ToList().IndexOf(monthName2.ToLower()) + 1;
                    month1 = monthNames.Select(e => e.ToLower()).ToList().IndexOf(monthName1.ToLower()) + 1;
                    monthName1 = monthNames[month1 - 1];
                    monthName2 = monthNames[month2 - 1];

                }
                if (!string.IsNullOrEmpty(period2))
                {
                    monthName3 = period2.Split('-')[0].Trim();
                    monthName4 = period2.Split('-')[1].Trim();
                    month3 = monthNames.Select(e => e.ToLower()).ToList().IndexOf(monthName3.ToLower()) + 1;
                    month4 = monthNames.Select(e => e.ToLower()).ToList().IndexOf(monthName4.ToLower()) + 1;

                }

                for (var year = DateTime.Now.Year - 1; year >= DateTime.Now.Year - 10; year--)
                {
                    DateTime d1 = new DateTime(year, month1, 1), d2 = new DateTime(year, month2, DateTime.DaysInMonth(year, month2)),
                        d3 = new DateTime(year, month3, 1), d4 = new DateTime(year + 1, month4, DateTime.DaysInMonth(year + 1, month4));
                    if (year + 1 < DateTime.Now.Year)
                        lookups.Add(new { codeId = month3, code = string.Format("{0}-{1}", d3.ToShortDateString(), d4.ToShortDateString()), name = string.Format("{0} - {1}", d3.ToString("MMM yyyy"), d4.ToString("MMM yyyy")) });
                    lookups.Add(new { codeId = month1, code = string.Format("{0}-{1}", d1.ToShortDateString(), d2.ToShortDateString()), name = string.Format("{0} - {1}", d1.ToString("MMM yyyy"), d2.ToString("MMM yyyy")) });

                }
                if (!string.IsNullOrEmpty(query))
                {
                    lookups = lookups.Where(w => w.name.Contains(query)).ToList();
                }
                return new { success = true, data = lookups, count = lookups.Count };
            }
            catch (Exception ex)
            {
                return ex;
            }
        }

        private dynamic GetLookupObject(DCF.SACWIS.Core.Entities.Entities.CRS.CR_Security_User rec, string group)
        {
            return new
              {
                  group = group,
                  groupId = rec.UserID,
                  code = rec.UserID,
                  codeId = rec.UserID,
                  name = rec.FirstName + " " + rec.LastName
              };

        }
        private dynamic GetLookupObject(DCF.SACWIS.Core.Entities.Entities.CRS.CR_CodeDescription rec)
        {
            return new
            {
                groupId = rec.GroupID,
                group = rec.GroupName,
                code = rec.GroupID,
                codeId = rec.CodeDescriptionID,
                name = !string.IsNullOrEmpty(rec.DescriptionSmall) ? rec.DescriptionSmall :
                      !string.IsNullOrEmpty(rec.DescriptionMedium) ? rec.DescriptionMedium :
                      !string.IsNullOrEmpty(rec.DescriptionLarge) ? rec.DescriptionLarge : rec.GroupName,
                small = rec.DescriptionSmall,
                medium = rec.DescriptionMedium,
                large = rec.DescriptionLarge

            };

        }

        [HttpGet]
        [Route("GetOperators")]
        public dynamic GetOperators()
        {
            var lookups = new List<dynamic>();
            try
            {


                lookups.Add(new { name = System.Linq.Expressions.ExpressionType.Equal.ToString() });
                lookups.Add(new { name = System.Linq.Expressions.ExpressionType.GreaterThan.ToString() });
                lookups.Add(new { name = System.Linq.Expressions.ExpressionType.GreaterThanOrEqual.ToString() });
                lookups.Add(new { name = System.Linq.Expressions.ExpressionType.LessThan.ToString() });
                lookups.Add(new { name = System.Linq.Expressions.ExpressionType.LessThanOrEqual.ToString() });
                lookups.Add(new { name = System.Linq.Expressions.ExpressionType.NotEqual.ToString() });

                return new { success = true, data = lookups };
            }
            catch (Exception ex)
            {
                return ex;
            }
        }

        [HttpGet]
        [Route("GetPredicates")]
        public dynamic GetPredicates()
        {
            var lookups = new List<dynamic>();
            try
            {

                lookups.AddRange(GetPredicateListFromType(new CaseReviewModel()));
                lookups.AddRange(GetPredicateListFromType(new FaceSheetModel()));
                lookups.AddRange(GetPredicateListFromType(new ChildDemographicModel()));
                lookups.AddRange(GetPredicateListFromType(new CaseParticipantModel()));
                lookups.AddRange(GetPredicateListFromType(new Item1Model()));
                lookups.AddRange(GetPredicateListFromType(new SafetyReportModel()));
                lookups.AddRange(GetPredicateListFromType(new Item2Model()));
                lookups.AddRange(GetPredicateListFromType(new Item3Model()));
                lookups.AddRange(GetPredicateListFromType(new Item4Model()));
                lookups.AddRange(GetPredicateListFromType(new PlacementModel()));

                lookups.AddRange(GetPredicateListFromType(new Item5Model()));
                lookups.AddRange(GetPredicateListFromType(new GoalModel()));

                lookups.AddRange(GetPredicateListFromType(new Item6Model()));
                lookups.AddRange(GetPredicateListFromType(new Item7Model()));
                lookups.AddRange(GetPredicateListFromType(new Item8Model()));
                lookups.AddRange(GetPredicateListFromType(new Item9Model()));
                lookups.AddRange(GetPredicateListFromType(new Item10Model()));
                lookups.AddRange(GetPredicateListFromType(new Item11Model()));
                lookups.AddRange(GetPredicateListFromType(new Item12AModel()));
                lookups.AddRange(GetPredicateListFromType(new Item12BModel()));
                lookups.AddRange(GetPredicateListFromType(new Item12CModel()));
                lookups.AddRange(GetPredicateListFromType(new Item13Model()));
                lookups.AddRange(GetPredicateListFromType(new Item14Model()));
                lookups.AddRange(GetPredicateListFromType(new Item15Model()));
                lookups.AddRange(GetPredicateListFromType(new Item16Model()));
                lookups.AddRange(GetPredicateListFromType(new EducationModel()));

                lookups.AddRange(GetPredicateListFromType(new Item17Model()));
                lookups.AddRange(GetPredicateListFromType(new PhysicalDentalHealthTableModel()));

                lookups.AddRange(GetPredicateListFromType(new Item18Model()));
                lookups.AddRange(GetPredicateListFromType(new MentalBehavirolHealthTableModel()));

                return new { success = true, data = lookups };
            }
            catch (Exception ex)
            {
                return ex;
            }
        }
        [HttpGet]
        [Route("MobileCarrierGateway")]
        public dynamic MobileCarrierGateway(string query = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var lookup = db.NotificationMobileCarrierGateways.Where(w => w.Enabled == true);

                if (!string.IsNullOrEmpty(query))
                {

                    lookup = lookup.Where(w => w.NotificationMobileCarrierGatewayName.Contains(query));

                }
                lookup = lookup.OrderBy(o => o.NotificationMobileCarrierGatewayName);
                var data = lookup.Select(e => new
                {
                    Id = e.Id,
                    Name = e.NotificationMobileCarrierGatewayName,

                }).ToList();
                return new { success = true, data = data, total = data.Count };
            }

        }


        private dynamic GetPredicateListFromType(object atype)
        {
            var list = new List<dynamic>();
            if (atype == null) return list;
            Type t = atype.GetType();
            PropertyInfo[] props = t.GetProperties();
            foreach (PropertyInfo p in props)
            {
                var ignoreProp = false;
                var name = p.Name;
                var attr = p.CustomAttributes.FirstOrDefault(w => w.AttributeType.Name == "RuleDefinationAttribute");
                if (attr != null)
                {
                    var cstIignore = attr.NamedArguments.FirstOrDefault(w => w.MemberName == "Ignore");
                    if (cstIignore != null && cstIignore.MemberInfo != null)
                    {
                        ignoreProp = (bool)cstIignore.TypedValue.Value;
                    }
                    var cstName = attr.NamedArguments.FirstOrDefault(w => w.MemberName == "DisplayName");
                    if (cstName != null && cstName.MemberInfo != null)
                    {
                        name = cstName.TypedValue.Value.ToString();
                    }
                }
                if (!ExclusionList(p.Name) && !ignoreProp)
                {
                    object value = p.GetValue(atype, new object[] { });
                    list.Add(new { group = t.Name.Replace("Model", ""), code = string.Concat(t.Name, "::", p.Name), name = name, value = value });
                }
            }
            return list;
        }
        private bool ExclusionList(string name)
        {
            switch (name)
            {
                case "ID_CR":
                case "ID_UP":
                case "TS_CR":
                case "TS_UP":

                    return true;
                default:
                    return false;
            }
        }


        [HttpGet]
        [Route("GetCases")]
        public dynamic GetCases(string query = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                if (string.IsNullOrEmpty(query))
                    query = string.Empty;
                var excludeStatuses = new List<int?> { (int)CaseStatusEnum.Eliminated, (int)CaseStatusEnum.CaseEliminatedPendingApproval, (int)CaseStatusEnum.Approved };

                var caseReviewList = db.ActiveCases()
                 .Where(w => w.IsIRR != true && (w.CaseName.Contains(query) || w.CaseID.ToString().Contains(query)))
                 .Select(v => v.CaseReviewID)
                 .ToList();

                var lookup = db.ActiveCases()
                    .Where(w => w.IRRReviewerID == null && !excludeStatuses.Contains(w.CaseStatusCode) && caseReviewList.Contains(w.CaseReviewID))
                    .OrderBy(o => o.CaseName);

                var statuses = db.CR_CodeDescription.Where(w => w.GroupName == "CaseStatus").Select(e => new LookupModel { Id = (int)e.GroupID, Name = e.DescriptionLarge }).ToList();
                var types = db.CR_ReviewSubType.Where(w => w.ReviewSubTypeID >= 19 && w.ReviewSubTypeID <= 21).Select(e => new LookupModel { Id = e.ReviewSubTypeID, Name = e.Description }).ToList();
                var data = lookup.Select(e => new
                {
                    e.CaseReviewID,
                    Id = e.CaseID,
                    Name = e.CaseName,
                    e.CaseStatusCode,
                    ReviewSubTypeID = e.ReviewSubTypeID,
                    Status = "",
                    Type = "",

                }).Distinct().ToList();
                var count = data.Count;
                data = data.Skip(start).Take(limit).Select(e => new
                {
                    e.CaseReviewID,
                    e.Id,
                    e.Name,
                    e.CaseStatusCode,
                    e.ReviewSubTypeID,
                    Status = statuses.Where(w => w.Id == e.CaseStatusCode).Select(e1 => e1.Name).FirstOrDefault(),
                    Type = types.Where(w => w.Id == e.ReviewSubTypeID).Select(e1 => e1.Name).FirstOrDefault(),

                }).ToList();
                return new { success = true, data = data, total = count };
            }
        }

        [HttpGet]
        [Route("GetCasesWithVersions")]
        public dynamic GetCasesWithVersions(string query = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                if (string.IsNullOrEmpty(query))
                    query = string.Empty;
                var excludeStatuses = new List<int?> { (int)CaseStatusEnum.Eliminated, (int)CaseStatusEnum.CaseEliminatedPendingApproval };

                var caseReviewList = db.ActiveCases()
                 .Where(w => w.IsIRR != true && (w.CaseName.Contains(query) || w.CaseID.ToString().Contains(query)))
                 .Select(v => v.CaseReviewID)
                 .ToList();

                var lookup = db.ActiveCases()
                    .Where(w => w.IRRReviewerID == null && !excludeStatuses.Contains(w.CaseStatusCode) && caseReviewList.Contains(w.CaseReviewID))
                    .OrderBy(o => o.CaseName);

                var statuses = db.CR_CodeDescription.Where(w => w.GroupName == "CaseStatus").Select(e => new LookupModel { Id = (int)e.GroupID, Name = e.DescriptionLarge }).ToList();
                var types = db.CR_ReviewSubType.Where(w => w.ReviewSubTypeID >= 19 && w.ReviewSubTypeID <= 21).Select(e => new LookupModel { Id = e.ReviewSubTypeID, Name = e.Description }).ToList();
                var data = lookup.Select(e => new
                {
                    e.CaseReviewRootID,
                    e.CaseReviewID,
                    Id = e.CaseID,
                    Name = e.CaseName,
                    e.CaseStatusCode,
                    ReviewSubTypeID = e.ReviewSubTypeID,
                }).Distinct().ToList();
                var count = data.Count;
                var data1 = data.Skip(start).Take(limit).Select(e => new
                 {
                     e.CaseReviewRootID,
                     e.CaseReviewID,
                     e.Id,
                     e.Name,
                     e.CaseStatusCode,
                     e.ReviewSubTypeID,
                     Status = statuses.Where(w => w.Id == e.CaseStatusCode).Select(e1 => e1.Name).FirstOrDefault(),
                     Type = types.Where(w => w.Id == e.ReviewSubTypeID).Select(e1 => e1.Name).FirstOrDefault(),
                     Versions = db.ActiveCasesByRootId(e.CaseReviewRootID.Value).ToList().Select(v => new
                     {
                         e.CaseReviewRootID,
                         v.CaseReviewID,
                         v.CaseStatusCode,
                         Status = statuses.Where(w => w.Id == v.CaseStatusCode).Select(e1 => e1.Name).FirstOrDefault(),
                     }).ToList()
                 }).ToList();
                return new { success = true, data = data1, total = count };
            }
        }

        [HttpGet]
        [Route("GetIrrUsers")]
        public dynamic GetIrrUsers(string query = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var iRRRoleId = 21;
                var lookup = db.CR_Security_User.Where(w => w.IsActive == 1 && w.CR_Security_UserRole.Any(a => a.RoleID == iRRRoleId));

                if (!string.IsNullOrEmpty(query))
                {
                    lookup = lookup.Where(w => w.FirstName.Contains(query) || w.LastName.ToString().Contains(query));
                }
                var data = lookup.Select(e => new
                {
                    Id = e.UserID,
                    Name = e.FirstName + " " + e.LastName,
                    e.LoginID,
                    e.Email,
                    e.Avatar,
                    IsActive = e.IsActive == 1,
                    Image = e.Avatar == true ? e.LoginID : "Default",
                    Role = e.CR_Security_UserRole.FirstOrDefault().CR_Security_Role.Description

                }).ToList();
                data = data.OrderBy(o => o.Name).ToList();
                var count = data.Count;
                //   data = data.Skip(start).Take(limit).ToList();
                return new { success = true, data = data, total = count };
            }
        }

        [HttpGet]
        [Route("GetAllUsers")]
        public dynamic GetAllUsers(string query = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var irrList = new List<int>() { 21 };
                var reviewerList = new List<int>() { 1, 2, 3 };
                var qaList = new List<int>() { 2, 3 };
                var oversightList = new List<int>() { 3 };
                var admin = new List<int>() { 7 };

                var lookup = db.CR_Security_User.Where(w => w.IsActive == 1);

                if (!string.IsNullOrEmpty(query))
                {
                    lookup = lookup.Where(w => w.FirstName.Contains(query) || w.LastName.ToString().Contains(query));
                }
                var data = lookup.Select(e => new UserLookupModel
                {
                    Id = e.UserID,
                    FirstName = e.FirstName,
                    LastName = e.LastName,
                    LoginID = e.LoginID,
                    Email = e.Email,
                    Avatar = e.Avatar ?? false,
                    IsActive = e.IsActive == 1,
                    Role = e.CR_Security_UserRole.FirstOrDefault().CR_Security_Role.Description,
                    IsIRR = e.CR_Security_UserRole.Any(a => irrList.Contains(a.RoleID)),
                    IsReviewer = e.CR_Security_UserRole.Any(a => reviewerList.Contains(a.RoleID)),
                    IsQa = e.CR_Security_UserRole.Any(a => qaList.Contains(a.RoleID)),
                    IsOversight = e.CR_Security_UserRole.Any(a => oversightList.Contains(a.RoleID)),
                    IsAdmin = e.CR_Security_UserRole.Any(a => admin.Contains(a.RoleID)),

                }).ToList();
                data = data.OrderBy(o => o.Name).ToList();
                var count = data.Count;
                //   data = data.Skip(start).Take(limit).ToList();
                return new { success = true, data = data, total = count };
            }
        }

        [HttpGet]
        [Route("GetRegions")]
        public dynamic GetAllRegions(string query = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var lookup = db.CR_Region.Where(w => w.IsActive == 1);

                var data = lookup.Select(e => new LookupModel
                {
                    Id = e.Id,
                    Name = e.Name
                }).ToList();

                data = data.OrderBy(o => o.Name).ToList();
                var count = data.Count;
                return new { success = true, data, total = count };
            }
        }

        [HttpGet]
        [Route("GetLocations")]
        public dynamic GetAllLocations(string query = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var lookup = db.CR_OfficeLocation.Where(w => w.IsActive == 1);

                var data = lookup.Select(e => new LocationModel
                {
                    Id = e.Id,
                    Name = e.Name,
                    RegionId = e.RegionId
                }).ToList();

                data = data.OrderBy(o => o.Name).ToList();
                var count = data.Count;
                return new { success = true, data, total = count };
            }
        }

        [HttpGet]
        [Route("GetFiscalYears")]
        public dynamic GetFiscalYears(string query = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var minDate = DateTime.Now.AddYears(-2);
                var lookup = db.CR_SamplingFiscalYear.Where(w => w.EndDate > minDate);

                var data = lookup.Select(e => new FiscalYears
                {
                    FFY = e.FFY,
                    StartDate = e.StartDate.Value,
                    EndDate = e.EndDate.Value
                }).ToList();

                data = data.OrderByDescending(o => o.EndDate).ToList();
                var count = data.Count;
                return new { success = true, data, total = count };
            }
        }


        [HttpGet]
        [Route("GetReviewSamplePeriod")]
        public List<ReviewPeriod> GetReviewSamplePeriod()
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var minDate = DateTime.Now.AddYears(-10);
                var lookup = db.CR_SampleReviewPeriod.Where(w => w.EndDate > minDate).ToList();

                var data = lookup.Select(e => new ReviewPeriod
                {
                    Id = e.ID,
                    Period = string.Format("{0:MMM-yyyy} to {1:MMM-yyyy}", e.StartDate.Value, e.EndDate.Value),
                    StartDate = e.StartDate.Value,
                    EndDate = e.EndDate.Value
                }).ToList();

                data.Add(new ReviewPeriod()
                {
                    Id = -1,
                    Period = "--Add New--"
                });

                data.Add(new ReviewPeriod()
                {
                    Id = 0,
                    Period = "ALL",
                    EndDate = new DateTime(9999, 12, 31)
                });
                return data.OrderByDescending(o => o.EndDate).ToList();
            }
        }

        //[HttpGet]
        //[Route("GetHometowns")]
       
        //public dynamic GetHometowns(string query = "", int start = 0, int limit = 20)
        //{
        //    using (var db = new Models.DB.CrsContext(Connection))
        //    {
        //        var lookup = db.Hometowns;

        //        var data = lookup.Select(e => new LookupModel
        //        {
        //            Id = e.Id,
        //            Name = e.HometownName
        //        }).ToList();

        //        data = data.OrderBy(o => o.Name).ToList();
        //        var count = data.Count;
        //        return new { success = true, data, total = count };
        //    }
        //}
    }

}
