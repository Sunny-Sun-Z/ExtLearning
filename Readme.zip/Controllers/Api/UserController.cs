﻿using DCF.SACWIS.CRS.Web.Models;
using DCF.SACWIS.CRS.Web.Models.DB;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.DirectoryServices;
using System.IO;
using System.Globalization;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.ObjectModel;
using System.Drawing.Imaging;
using DCF.SACWIS.CRS.Web.Core;
using DCF.SACWIS.CRS.Web.Services;
using DCF.SACWIS.CRS.Web.Core.Constants;

namespace DCF.SACWIS.CRS.Web.Controllers.Api
{
    [RoutePrefix("user")]
    public class UserController : BaseApiController
    {
        [HttpGet]
        [Route("GetAllUsers")]
        public dynamic GetAllUsers(string filter = "", string sort = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var query = db.CR_Security_User.AsQueryable();
                query = query.OrderBy(o => o.FirstName).ThenBy(o => o.LastName);
                var count = query.Count();
                var data = query.Select(e => new
                {
                    e.UserID,
                    e.LoginID,
                    e.FirstName,
                    e.LastName,
                    Email = e.Email,
                    IsActive = e.IsActive == 1,
                    Avatar = e.Avatar ?? false,


                }).ToList();
                return new { success = true, data = data, total = count };
            }

        }

        //#region Profile

        //[HttpGet]
        //[Route("GetAllReviewerProfiles")]
        //public dynamic GetAllReviewerProfiles(string filter = "", string sort = "", int start = 0, int limit = 20)
        //{
        //    using (var db = new Models.DB.CrsContext(Connection))
        //    {
               
        //        var filters = new List<Filter>();
        //        var query = db.CR_Security_User.AsQueryable().Where(x => x.IsProfileActive == true && x.IsActive == 1);

        //        if (!string.IsNullOrEmpty(filter))
        //        {

        //            filters = JsonConvert.DeserializeObject<List<Filter>>(filter);
        //            var nameFilter = filters.FirstOrDefault(w => w.Property.Equals("name", StringComparison.OrdinalIgnoreCase));
        //          //  var activeFilter = filters.FirstOrDefault(w => w.Property.Equals("IsProfileActive", StringComparison.OrdinalIgnoreCase));
        //            if (filters.Any())
        //            {
        //                if (nameFilter != null && !string.IsNullOrEmpty(nameFilter.Value))
        //                {
        //                    var name = nameFilter.Value.ToString();
        //                    query = query.Where( w=> w.FirstName.Contains(name) || w.LastName.Contains(name) );
        //                }
                        
        //            }
        //        }

        //        var queryjoin3 =
        //            from e in query

        //            join office in db.CR_CodeDescription.Where(x => x.GroupName == "Office")
        //            on e.CurrentOffice equals office.GroupID into leftJoinCurrentOffice
        //            from co in leftJoinCurrentOffice.DefaultIfEmpty()

        //            join office in db.CR_CodeDescription.Where(x => x.GroupName == "Office")
        //         on e.PreviousOffice equals office.GroupID into leftJoinPreviousOffice
        //            from po in leftJoinPreviousOffice.DefaultIfEmpty()

        //            join hometown in db.Hometowns
        //         on e.Hometown equals hometown.Id into leftJointHometown
        //            from ht in leftJointHometown.DefaultIfEmpty()

        //            select new
        //            {
        //                e.UserID,
        //                e.FirstName,
        //                e.LastName,
        //                IsActive = e.IsActive == 1,
        //                e.SpecialConsideration,
        //                CurrentOffice = co.DescriptionMedium,
        //                CurrentOfficeID = e.CurrentOffice,
        //                PreviousOfficeID = e.PreviousOffice,
        //                PreviousOffice = po.DescriptionMedium,
        //                HometownID = e.Hometown,
        //                Hometown = ht.HometownName,
        //                e.OtherHometown,
        //                e.IsProfileActive 
        //            };



               


        //        if (!string.IsNullOrEmpty(sort))
        //        {
        //            var sorts = JsonConvert.DeserializeObject<List<Sorting>>(sort);
        //            var s = sorts.FirstOrDefault();
        //            var descDir = s.Direction.Equals("DESC", StringComparison.OrdinalIgnoreCase);
        //            switch (s.Property.ToLower())
        //            {
        //                case "name":
        //                    queryjoin3 = descDir ? queryjoin3.OrderByDescending(o => o.FirstName).ThenBy(o => o.LastName) : queryjoin3.OrderBy(o => o.FirstName).ThenBy(o => o.LastName);
        //                    break;
        //                case "hometown":
        //                    queryjoin3 = descDir ? queryjoin3.OrderByDescending(o => o.Hometown) : queryjoin3.OrderBy(o => o.Hometown);
        //                    break;
        //                case "currentoffice":
        //                    queryjoin3 = descDir ? queryjoin3.OrderByDescending(o => o.CurrentOffice) : queryjoin3.OrderBy(o => o.CurrentOffice);
        //                    break;
        //                case "previousoffice":
        //                    queryjoin3 = descDir ? queryjoin3.OrderByDescending(o => o.PreviousOffice) : queryjoin3.OrderBy(o => o.PreviousOffice);
        //                    break;
                        

        //            }
        //        }
        //        else
        //        {
        //            queryjoin3 = queryjoin3.OrderBy(o => o.FirstName).ThenBy(o => o.LastName);
        //        }


        //        var data = queryjoin3.Skip(start).Take(limit).Select(e => new
        //        {
        //            e.UserID,
        //            e.FirstName,
        //            e.LastName,
        //            IsActive = e.IsActive ,
        //            e.SpecialConsideration,
        //            e.CurrentOffice,
        //            e.CurrentOfficeID,
        //            e.PreviousOffice,
        //            e.PreviousOfficeID,
        //            Hometown = e.HometownID==999? "OtherTown: " + e.OtherHometown : e.Hometown,
        //            e.HometownID,
        //            e.OtherHometown,
        //            e.IsProfileActive

        //        }).ToList();

        //        var count = queryjoin3.Count();
        //        return new { success = true, data = data, total = count };
        //    }

        //}
       

        //[HttpPost]
        //[Route("DeleteReviewerProfile")]
        //public dynamic DeleteReviewerProfile(UserModel user)
        //{
        //    using (var db = new Models.DB.CrsContext(Connection))
        //    {
        //        var item = db.CR_Security_User.FirstOrDefault(w => w.UserID == user.UserID);
        //        if (item != null)
        //        {
        //            item.IsProfileActive = false;
        //            item.TS_UP = DateTime.UtcNow;
        //            item.ID_UP = UserId;
        //        }
        //        db.SaveChanges();
        //        return new { success = true, message = "Reviewer Profile deleted successfully", data = user };
        //    }

        //}


        //[HttpPost]
        //[Route("UpdateReviewerProfile")]
        //public dynamic UpdateReviewerProfile(ReviewerProfileModel profiler)
        //{
        //    using (var db = new Models.DB.CrsContext(Connection))
        //    {
        //        var item = db.CR_Security_User.FirstOrDefault(w => w.UserID == profiler.UserID);
        //        if (item != null)
        //        {
        //            item.PreviousOffice = profiler.PreviousOfficeID;
        //            item.CurrentOffice = profiler.CurrentOfficeID;
        //            item.Hometown = profiler.HometownID;
        //            item.SpecialConsideration = profiler.SpecialConsideration;
        //            item.ID_UP = UserId;
        //            item.IsProfileActive = true;
        //            item.OtherHometown = profiler.OtherHometown;
        //            item.TS_UP = DateTime.UtcNow;

        //        }
        //        db.SaveChanges();
        //        return new { success = true, message = "User updated successfully", data = profiler };
        //    }
        //}

        //#endregion

        [HttpGet]
        [Route("GetUsers")]
        public dynamic GetUsers(string filter = "", string sort = "", int start = 0, int limit = 20)
        {

            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var query = db.CR_Security_User.AsQueryable();

                if (!string.IsNullOrEmpty(filter))
                {

                    filters = JsonConvert.DeserializeObject<List<Filter>>(filter);
                    var nameFilter = filters.FirstOrDefault(w => w.Property.Equals("name", StringComparison.OrdinalIgnoreCase));
                    var activeFilter = filters.FirstOrDefault(w => w.Property.Equals("IsActive", StringComparison.OrdinalIgnoreCase));
                    var profileActiveFilter = filters.FirstOrDefault(w => w.Property.Equals("IsProfileActive", StringComparison.OrdinalIgnoreCase));
                    if (filters.Any())
                    {
                        if (nameFilter != null && !string.IsNullOrEmpty(nameFilter.Value))
                        {
                            var name = nameFilter.Value.ToString();
                            query = query.Where(w => w.Email.Contains(name) || w.FirstName.Contains(name) || w.FirstName.Contains(name) || w.LoginID.Contains(name));
                        }
                        if (activeFilter != null && !string.IsNullOrEmpty(activeFilter.Value))
                        {
                            //var flag = activeFilter.Value.Equals("true", StringComparison.OrdinalIgnoreCase) ? 2 : 1;
                            var flag = activeFilter.Value.Equals("1", StringComparison.OrdinalIgnoreCase) ? 1 : 2;
                            query = query.Where(w => w.IsActive == flag);
                        }
                        //if (profileActiveFilter != null)
                        //{
                        //    query = db.CR_Security_User.AsQueryable().Where(x => x.IsActive == 1 && x.IsProfileActive != true);
                        //}
                    }
                }

                if (!string.IsNullOrEmpty(sort))
                {
                    var sorts = JsonConvert.DeserializeObject<List<Sorting>>(sort);
                    var s = sorts.FirstOrDefault();
                    var descDir = s.Direction.Equals("DESC", StringComparison.OrdinalIgnoreCase);
                    switch (s.Property.ToLower())
                    {
                        case "name":
                            query = descDir ? query.OrderByDescending(o => o.FirstName).ThenBy(o => o.LastName) : query.OrderBy(o => o.FirstName).ThenBy(o => o.LastName);
                            break;
                        case "firstname":
                            query = descDir ? query.OrderByDescending(o => o.FirstName) : query.OrderBy(o => o.FirstName);
                            break;
                        case "lastname":
                            query = descDir ? query.OrderByDescending(o => o.LastName) : query.OrderBy(o => o.LastName);
                            break;
                        case "email":
                            query = descDir ? query.OrderByDescending(o => o.Email) : query.OrderBy(o => o.Email);
                            break;
                        case "loginid":
                            query = descDir ? query.OrderByDescending(o => o.LoginID) : query.OrderBy(o => o.LoginID);
                            break;
                        case "isactive":
                            query = descDir ? query.OrderByDescending(o => o.IsActive) : query.OrderBy(o => o.IsActive);
                            break;

                    }
                }
                else
                {
                    query = query.OrderBy(o => o.FirstName).ThenBy(o => o.LastName);
                }

                var count = query.Count();
                var data = query.Skip(start).Take(limit).Select(e => new
                {
                    e.UserID,
                    e.LoginID,
                    e.FirstName,
                    e.LastName,
                    Email = e.Email,
                    IsActive = e.IsActive == 1,
                    Avatar = e.Avatar ?? false,
                    e.PhoneServiceProvider,
                    e.Phone,
                    e.MessagePreference

                }).ToList();
                return new { success = true, data = data, total = count };
            }

        }
        [HttpGet]
        [Route("GetRoles")]
        public dynamic GetRoles(string filter = "", string sort = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var query = db.CR_Security_Role.AsQueryable();

                if (!string.IsNullOrEmpty(filter))
                {
                    filters = JsonConvert.DeserializeObject<List<Filter>>(filter);
                    var nameFilter = filters.FirstOrDefault(w => w.Property.Equals("name", StringComparison.OrdinalIgnoreCase));
                    if (filters.Any())
                    {
                        if (nameFilter != null && !string.IsNullOrEmpty(nameFilter.Value))
                        {
                            var name = nameFilter.Value;
                            query = query.Where(w => w.Description.Contains(name));
                        }

                    }
                }
                query = query.OrderBy(o => o.Description);
                var data = query.Select(e => new
                {
                    Id = e.RoleID,
                    Name = e.Description,

                }).ToList();
                return new { success = true, data = data, total = data.Count };
            }

        }
        [HttpGet]
        [Route("GetPermissions")]
        public dynamic GetPermissions(string filter = "", string sort = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var query = db.CR_Security_Permission.AsQueryable();

                if (!string.IsNullOrEmpty(filter))
                {
                    filters = JsonConvert.DeserializeObject<List<Filter>>(filter);
                    var nameFilter = filters.FirstOrDefault(w => w.Property.Equals("name", StringComparison.OrdinalIgnoreCase));
                    if (filters.Any())
                    {
                        if (nameFilter != null && !string.IsNullOrEmpty(nameFilter.Value))
                        {
                            var name = nameFilter.Value;
                            query = query.Where(w => w.Description.Contains(name));
                        }

                    }
                }
                query = query.OrderBy(o => o.Description);
                var data = query.Select(e => new
                {
                    Id = e.PermissionID,
                    Name = e.Description,

                }).ToList();
                return new { success = true, data = data, total = data.Count };
            }

        }

        [HttpGet]
        [Route("GetUserRolesAndPermissions")]
        public dynamic GetUserRolesAndPermissions(int userId)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var data = db.CR_Security_User.Where(w => w.UserID == userId).Select(e => new
                {
                    UserID = e.UserID,
                    LoginID = e.LoginID,
                    FirstName = e.FirstName,
                    LastName = e.LastName,
                    Email = e.Email,
                    IsActive = e.IsActive,
                    Avatar = e.Avatar,
                    Roles = e.CR_Security_UserRole.Select(r => r.RoleID).ToList(),
                    Permissions = e.CR_Security_UserPermission.Select(p => p.PermissionID).ToList()

                }).FirstOrDefault();
                return new { success = true, data = data };
            }
        }

        [HttpGet]
        [Route("GetUserRoles")]
        public dynamic GetUserRoles(string filter = "", string sort = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var query = db.CR_Security_UserRole.AsQueryable();
                int id = 0;

                if (!string.IsNullOrEmpty(filter))
                {
                    filters = JsonConvert.DeserializeObject<List<Filter>>(filter);
                    var IdFilter = filters.FirstOrDefault(w => w.Property.Equals("Id", StringComparison.OrdinalIgnoreCase));
                    if (filters.Any())
                    {
                        if (IdFilter != null && !string.IsNullOrEmpty(IdFilter.Value))
                        {
                            int.TryParse(IdFilter.Value, out id);
                        }
                    }
                }
                query = query.Where(w => w.UserID == id);
                var data = query.Select(e => new
                {
                    Id = e.RoleID,
                    Name = e.CR_Security_Role.Description,

                }).OrderBy(o => o.Name).Distinct().ToList();
                return new { success = true, data = data, total = data.Count };
            }

        }

        [HttpGet]
        [Route("GetUserPermissions")]
        public dynamic GetUserPermissions(string filter = "", string sort = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var query = db.CR_Security_UserPermission.AsQueryable();
                int id = 0;

                if (!string.IsNullOrEmpty(filter))
                {
                    filters = JsonConvert.DeserializeObject<List<Filter>>(filter);
                    var IdFilter = filters.FirstOrDefault(w => w.Property.Equals("Id", StringComparison.OrdinalIgnoreCase));
                    if (filters.Any())
                    {
                        if (IdFilter != null && !string.IsNullOrEmpty(IdFilter.Value))
                        {
                            int.TryParse(IdFilter.Value, out id);
                        }
                    }
                }
                query = query.Where(w => w.UserId == id);
                var data = query.Select(e => new
                {
                    Id = e.PermissionID,
                    Name = e.CR_Security_Permission.Description,
                    InRole = false
                }).OrderBy(o => o.Name).Distinct().ToList();

                var roles = db.CR_Security_UserRole.Where(w => w.UserID == id).Select(e => e.RoleID).ToList();
                var permissions = db.CR_Security_RolePermission.Where(w => roles.Contains(w.RoleID)).Select(e => new { Id = e.PermissionID, Name = e.CR_Security_Permission.Description, InRole = true }).OrderBy(o => o.Name).Distinct().ToList();
                data.AddRange(permissions);

                return new { success = true, data = data, total = data.Count };
            }

        }

        [HttpGet]
        [Route("GetUserNonePermissions")]
        public dynamic GetUserNonePermissions(int userId, string sort = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var userPermisions = db.CR_Security_UserPermission.Where(w => w.UserId == userId).Select(e => e.PermissionID).ToList();

                var roles = db.CR_Security_UserRole.Where(w => w.UserID == userId).Select(e => e.RoleID).ToList();
                var permissions = db.CR_Security_RolePermission.Where(w => roles.Contains(w.RoleID)).Select(e => e.PermissionID).ToList();
                userPermisions.AddRange(permissions);
                var data = db.CR_Security_Permission.Where(w => !userPermisions.Contains(w.PermissionID)).Select(e => new { Id = e.PermissionID, Name = e.Description }).Distinct().OrderBy(o => o.Name).ToList();
                return new { success = true, data = data, total = data.Count };
            }

        }

        [HttpGet]
        [Route("GetUserNoneRoles")]
        public dynamic GetUserNoneRoles(int userId, string sort = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var userRoles = db.CR_Security_UserRole.Where(w => w.UserID == userId).Select(e => e.RoleID).ToList();

                var data = db.CR_Security_Role.Where(w => !userRoles.Contains(w.RoleID)).Select(e => new { Id = e.RoleID, Name = e.Description }).Distinct().OrderBy(o => o.Name).ToList();
                return new { success = true, data = data, total = data.Count };
            }

        }

        [HttpGet]
        [Route("GetRolePermissions")]
        public dynamic GetRolePermissions(int roleId)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var data = db.CR_Security_Role.Where(w => w.RoleID == roleId).Select(e => new
                {
                    Id = e.RoleID,
                    Name = e.Description,
                    Permissions = e.CR_Security_RolePermission.Select(p => p.PermissionID).ToList()

                }).FirstOrDefault();
                return new { success = true, data = data };
            }
        }

        [HttpGet]
        [Route("GetRolePermissionsEx")]
        public dynamic GetRolePermissionsEx(string filter = "", string sort = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var query = db.CR_Security_RolePermission.AsQueryable();
                int id = 0;

                if (!string.IsNullOrEmpty(filter))
                {
                    filters = JsonConvert.DeserializeObject<List<Filter>>(filter);
                    var IdFilter = filters.FirstOrDefault(w => w.Property.Equals("Id", StringComparison.OrdinalIgnoreCase));
                    if (filters.Any())
                    {
                        if (IdFilter != null && !string.IsNullOrEmpty(IdFilter.Value))
                        {
                            int.TryParse(IdFilter.Value, out id);
                        }
                    }
                }
                query = query.Where(w => w.RoleID == id);
                var data = query.Select(e => new
                {
                    Id = e.PermissionID,
                    Name = e.CR_Security_Permission.Description,
                    InRole = true
                }).OrderBy(o => o.Name).Distinct().ToList();

                var existingPermissions = data.Select(e => e.Id).ToList();
                var permissions = db.CR_Security_Permission.Where(w => !existingPermissions.Contains(w.PermissionID)).Select(e => new { Id = e.PermissionID, Name = e.Description, InRole = false }).OrderBy(o => o.Name).Distinct().ToList();
                data.AddRange(permissions);

                return new { success = true, data = data };
            }
        }


        [HttpPost]
        [Route("CreateUser")]
        public dynamic CreateUser(UserModel user)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                short active = (short)(user.IsActive ? 1 : 2);
                //var temp = db.CR_Security_User.FirstOrDefault(w => (w.IsActive == active) && w.FirstName == user.FirstName && w.LastName == user.LastName && w.LoginID == user.LoginID);
                var temp = db.CR_Security_User.FirstOrDefault(w => w.LoginID == user.LoginID);
                if (temp != null)
                {
                    return new { success = false, message = "User already exist", data = user };
                }

                var item = new Models.DB.CR_Security_User
                {
                    UserID = user.UserID,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    LoginID = user.LoginID,
                    IsActive = (short?)(user.IsActive ? 1 : 2),
                    Email = user.Email,
                    ID_CR = UserId,
                    ID_UP = UserId,
                    TS_CR = DateTime.UtcNow,
                    TS_UP = DateTime.UtcNow,
                    MessagePreference = user.MessagePreference,
                    Phone = user.Phone,
                    PhoneServiceProvider = user.PhoneServiceProvider

                };
                if (user.Roles != null && user.Roles.Any())
                {
                    foreach (var role in user.Roles)
                    {
                        item.CR_Security_UserRole.Add(new Models.DB.CR_Security_UserRole
                        {
                            RoleID = role,
                            ID_CR = UserId,
                            ID_UP = UserId,
                            TS_CR = DateTime.UtcNow,
                            TS_UP = DateTime.UtcNow,
                        });
                    }
                }
                if (user.Permissions != null && user.Permissions.Any())
                {
                    foreach (var p in user.Permissions)
                    {
                        item.CR_Security_UserPermission.Add(new Models.DB.CR_Security_UserPermission
                        {
                            PermissionID = p,
                            ID_CR = UserId,
                            ID_UP = UserId,
                            TS_CR = DateTime.UtcNow,
                            TS_UP = DateTime.UtcNow,
                        });
                    }
                }
                db.CR_Security_User.Add(item);
                db.SaveChanges();
                user.UserID = item.UserID;
                UserCreatedNotification(user);
                return new { success = true, message = "User created successfully", data = user };
            }
        }

        [HttpPost]
        [Route("UpdateUser")]
        public dynamic UpdateUser(UserModel user)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var anotherUser = db.CR_Security_User.FirstOrDefault(w => w.UserID != user.UserID && w.LoginID == user.LoginID);
                if (anotherUser != null)
                    return new { success = false, message = "Another user already exists with same login Id", data = user };

                var item = db.CR_Security_User.FirstOrDefault(w => w.UserID == user.UserID);
                if (item != null)
                {
                    item.FirstName = user.FirstName;
                    item.LastName = user.LastName;
                    item.LoginID = user.LoginID;
                    item.IsActive = (short?)(user.IsActive ? 1 : 2);
                    item.Email = user.Email;
                    item.PhoneServiceProvider = user.PhoneServiceProvider;
                    item.Phone = user.Phone;
                    item.MessagePreference = user.MessagePreference;
                }

                db.SaveChanges();
                ///  UserCreatedNotification(user);
                return new { success = true, message = "User updated successfully", data = user };
            }
        }


        [HttpPost]
        [Route("ActiveDeactiveUser")]
        public dynamic ActiveDeactiveUser(UserModel user)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var item = db.CR_Security_User.FirstOrDefault(w => w.UserID == user.UserID);
                if (item != null)
                {
                    item.IsActive = (short?)(user.IsActive ? 1 : 2); //1 =active 2 =deactive
                }

                db.SaveChanges();
                user.IsActive = item.IsActive == 1;
                return new { success = true, message = user.IsActive ? "User activated successfully" : "User deactivated successfully", data = user };
            }

        }

        [HttpPost]
        [Route("UpdateUserRoles")]
        public dynamic UpdateUserRoles(UserModel user)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var roles = db.CR_Security_UserRole.Where(w => w.UserID == user.UserID).ToList();
                var removeList = new List<Models.DB.CR_Security_UserRole>();
                foreach (var role in roles)
                {
                    if (user.Roles.Any(w => w == role.RoleID))
                    {
                        user.Roles.Remove(role.RoleID); //role already exist.
                    }
                    else
                    {
                        removeList.Add(role);
                    }
                }

                db.CR_Security_UserRole.RemoveRange(removeList);
                foreach (var role in user.Roles)
                {
                    db.CR_Security_UserRole.Add(new CR_Security_UserRole
                    {
                        RoleID = role,
                        UserID = user.UserID,
                        ID_CR = UserId,
                        ID_UP = UserId,
                        TS_CR = DateTime.UtcNow,
                        TS_UP = DateTime.UtcNow,
                    });
                }
                db.SaveChanges();
                var data = GetUser(user.UserID);

                return new { success = true, message = "User roles updated successfully", data = data };
            }
        }

        [HttpPost]
        [Route("UpdateUserRolesEx")]
        public dynamic UpdateUserRolesEx(UserModel user)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {

                foreach (var role in user.Roles)
                {
                    db.CR_Security_UserRole.Add(new CR_Security_UserRole
                    {
                        RoleID = role,
                        UserID = user.UserID,
                        ID_CR = UserId,
                        ID_UP = UserId,
                        TS_CR = DateTime.UtcNow,
                        TS_UP = DateTime.UtcNow,
                    });
                }
                db.SaveChanges();
                var data = GetUser(user.UserID);

                return new { success = true, message = "User roles updated successfully", data = data };
            }
        }

        [HttpPost]
        [Route("UpdateUserPermissions")]
        public dynamic UpdateUserPermissions(UserModel user)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var permissions = db.CR_Security_UserPermission.Where(w => w.UserId == user.UserID).ToList();
                var removeList = new List<Models.DB.CR_Security_UserPermission>();
                foreach (var p in permissions)
                {
                    if (user.Permissions.Any(w => w == p.PermissionID))
                    {
                        user.Permissions.Remove(p.PermissionID); //permission already exist.
                    }
                    else
                    {
                        removeList.Add(p);
                    }
                }

                db.CR_Security_UserPermission.RemoveRange(removeList);
                foreach (var p in user.Permissions)
                {
                    db.CR_Security_UserPermission.Add(new CR_Security_UserPermission
                    {
                        PermissionID = p,
                        UserId = user.UserID,
                        ID_CR = UserId,
                        ID_UP = UserId,
                        TS_CR = DateTime.UtcNow,
                        TS_UP = DateTime.UtcNow,
                    });
                }
                db.SaveChanges();
                var data = GetUser(user.UserID);

                return new { success = true, message = "User permissions updated successfully", data = data };
            }
        }
        [HttpPost]
        [Route("UpdateUserPermissionsEx")]
        public dynamic UpdateUserPermissionsEx(UserModel user)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                foreach (var p in user.Permissions)
                {
                    db.CR_Security_UserPermission.Add(new CR_Security_UserPermission
                    {
                        PermissionID = p,
                        UserId = user.UserID,
                        ID_CR = UserId,
                        ID_UP = UserId,
                        TS_CR = DateTime.UtcNow,
                        TS_UP = DateTime.UtcNow,
                    });
                }
                db.SaveChanges();
                var data = GetUser(user.UserID);

                return new { success = true, message = "User permissions updated successfully", data = data };
            }
        }

        [HttpPost]
        [Route("DeleteUserPermissions")]
        public dynamic DeleteUserPermissions(UserModel user)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                if (user.Permissions.Any())
                {
                    var removeList = db.CR_Security_UserPermission.Where(w => w.UserId == user.UserID && user.Permissions.Contains(w.PermissionID)).ToList();
                    db.CR_Security_UserPermission.RemoveRange(removeList);

                    db.SaveChanges();
                }
                var data = GetUser(user.UserID);

                return new { success = true, message = "User permissions deleted successfully", data = data };
            }
        }
        [HttpPost]
        [Route("DeleteUserRoles")]
        public dynamic DeleteUserRoles(UserModel user)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                if (user.Roles.Any())
                {
                    var removeList = db.CR_Security_UserRole.Where(w => w.UserID == user.UserID && user.Roles.Contains(w.RoleID)).ToList();
                    db.CR_Security_UserRole.RemoveRange(removeList);

                    db.SaveChanges();
                }
                var data = GetUser(user.UserID);

                return new { success = true, message = "User roles deleted successfully", data = data };
            }
        }

        [HttpPost]
        [Route("UpdateRolePermissions")]
        public dynamic UpdateRolePermissions(RoleModel role)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var permissions = db.CR_Security_RolePermission.Where(w => w.RoleID == role.RoleId).ToList();
                var removeList = new List<Models.DB.CR_Security_RolePermission>();
                foreach (var p in permissions)
                {
                    if (role.Permissions.Any(w => w == p.PermissionID))
                    {
                        role.Permissions.Remove(p.PermissionID); //permission already exist.
                    }
                    else
                    {
                        removeList.Add(p);
                    }
                }

                db.CR_Security_RolePermission.RemoveRange(removeList);
                foreach (var p in role.Permissions)
                {
                    db.CR_Security_RolePermission.Add(new CR_Security_RolePermission
                    {
                        PermissionID = p,
                        RoleID = role.RoleId,
                        ID_CR = UserId,
                        ID_UP = UserId,
                        TS_CR = DateTime.UtcNow,
                        TS_UP = DateTime.UtcNow,
                    });
                }
                db.SaveChanges();

                return new { success = true, message = "Role permissions updated successfully", data = role };
            }
        }

        [HttpPost]
        [Route("UpdateRolePermissionsEx")]
        public dynamic UpdateRolePermissionsEx(RolePermissionModel role)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var permissionIds = role.Permissions.Where(w => !w.InRole).Select(e => e.Id).ToList();
                var removeList = db.CR_Security_RolePermission.Where(w => w.RoleID == role.RoleId && permissionIds.Contains(w.PermissionID)).ToList();

                db.CR_Security_RolePermission.RemoveRange(removeList);
                foreach (var p in role.Permissions.Where(w => w.InRole).ToList())
                {
                    db.CR_Security_RolePermission.Add(new CR_Security_RolePermission
                    {
                        PermissionID = p.Id,
                        RoleID = role.RoleId,
                        ID_CR = UserId,
                        ID_UP = UserId,
                        TS_CR = DateTime.UtcNow,
                        TS_UP = DateTime.UtcNow,
                    });
                }
                db.SaveChanges();

                return new { success = true, message = "Role permissions updated successfully", data = role };
            }
        }

        private UserModel GetUser(int userId)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var data = db.CR_Security_User.Where(w => w.UserID == userId).Select(e => new UserModel
                {
                    UserID = e.UserID,
                    LoginID = e.LoginID,
                    FirstName = e.FirstName,
                    LastName = e.LastName,
                    Email = e.Email,
                    IsActive = e.IsActive == 1,
                    Avatar = e.Avatar ?? false,
                    Roles = e.CR_Security_UserRole.Select(r => r.RoleID).ToList(),
                    Permissions = e.CR_Security_UserPermission.Select(p => p.PermissionID).ToList()
                }).FirstOrDefault();
                return data;
            }
        }

        private Image GetUserPicture(string userName)
        {
            var list = new List<Image>();
            using (var db = new Models.DB.CrsContext(Connection))
            {
                DirectorySearcher searcher = new DirectorySearcher();

                searcher.SearchScope = SearchScope.Subtree;
                searcher.Filter = string.Format(CultureInfo.InvariantCulture, "(sAMAccountName={0})", userName);
                //SearchResult findUser = searcher.FindOne();
                foreach (SearchResult findUser in searcher.FindAll())
                {
                    if (findUser != null)
                    {
                        //string userName = findUser.Properties["displayName"].Value.ToString();
                        //string departement = findUser.Properties["Department"].Value.ToString();

                        var photo = findUser.Properties["thumbnailPhoto"];
                        //   var a = photo.Value;
                        var jpegPhoto = findUser.Properties["jpegPhoto"];
                        // byte[] photodata = findUser.Properties["jpegPhoto"] as byte[];
                        //using (MemoryStream str = new MemoryStream(photodata))
                        //{
                        //    return Bitmap.FromStream(str);
                        //}
                    }
                }

                using (DirectorySearcher dsSearcher = new DirectorySearcher())
                {


                    foreach (var u in db.CR_Security_User)
                    {

                        try
                        {

                            dsSearcher.Filter = "(&(objectClass=user) (cn=" + u.LoginID + "))";
                            SearchResult result = dsSearcher.FindOne();
                            if (result != null)
                            {
                                using (DirectoryEntry user = new DirectoryEntry(result.Path))
                                {
                                    byte[] data = user.Properties["jpegPhoto"].Value as byte[];

                                    if (data != null)
                                    {
                                        using (MemoryStream s = new MemoryStream(data))
                                        {
                                            list.Add(Bitmap.FromStream(s));
                                        }
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Log(ex);
                           
                        }
                    }


                }
                return list.FirstOrDefault();
            }

        }

        [HttpGet]
        [Route("GetCodeDescriptions")]
        public dynamic GetCodeDescriptions(string filter = "", string sort = "", int start = 0, int limit = 20)
        {


            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var query = db.CR_CodeDescription.AsQueryable();
                query = query.OrderBy(o => o.GroupName).ThenBy(o => o.GroupID);
                var count = query.Count();
                var data = query.Select(e => e).ToList();
                return new { success = true, data = data, total = count };
            }

        }



        [HttpGet]
        [Route("GetPicture")]
        public HttpResponseMessage GetPicture(string id)
        {
            String filePath = string.Concat(ImagePath, id);
           //if( !File.Exists(filePath))
           //    filePath = string.Concat(ImagePath, "default.png");

            return GetImage(filePath);
        }

        [HttpGet]
        [Route("GetProfilePicture")]
        public HttpResponseMessage GetProfilePicture(int id)
        {
            var user = GetUser(id);
            var file = user != null && user.Avatar ? string.Concat(user.LoginID, ".png") : "default.png";
            String filePath = string.Concat(ImagePath, file);

            return user != null && user.Avatar ? GetImage(filePath) : GetProfileImage(filePath);
        }
        [HttpGet]
        [Route("GetLogo")]
        public HttpResponseMessage GetLogo()
        {
            var file = string.Concat(ResourcePath, "images/logo.png");
            var result = GetImage(file);
            return result;
        }
        private HttpResponseMessage GetImage(string path)
        {
            var result = new HttpResponseMessage(HttpStatusCode.OK);
            String filePath = System.Web.Hosting.HostingEnvironment.MapPath(path);
            if (File.Exists(filePath))
            {
                using (FileStream fileStream = new FileStream(filePath, FileMode.Open))
                {
                    Image image = Image.FromStream(fileStream);
                    MemoryStream memoryStream = new MemoryStream();
                    image.Save(memoryStream, ImageFormat.Png);
                    result.Content = new ByteArrayContent(memoryStream.ToArray());
                    result.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("image/jpeg");
                    fileStream.Close();
                }
            }
            return result;
        }
        private HttpResponseMessage GetProfileImage(string path)
        {
            if (defaultProfileResponse == null)
            {
                defaultProfileResponse = new HttpResponseMessage(HttpStatusCode.OK);
                String filePath = System.Web.Hosting.HostingEnvironment.MapPath(path);
                if (File.Exists(filePath))
                {
                    using (FileStream fileStream = new FileStream(filePath, FileMode.Open))
                    {
                        Image image = Image.FromStream(fileStream);
                        MemoryStream memoryStream = new MemoryStream();
                        image.Save(memoryStream, ImageFormat.Png);
                        defaultProfileResponse.Content = new ByteArrayContent(memoryStream.ToArray());
                        defaultProfileResponse.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("image/jpeg");
                        fileStream.Close();

                    }
                }
            }
            return defaultProfileResponse;
        }
        private void UserCreatedNotification(UserModel user)
        {
            try
            {

                if (AllowNewUserNotification)
                {

                    var dic = user.ToDictionary();
                    dic.Add("BaseUrl", Request.Headers.Referrer.AbsoluteUri);
                    var tPath = System.Web.Hosting.HostingEnvironment.MapPath(string.Format("~/App_data/templates/{0}", TemplateNames.NewUserNotification));
                    var mb = new MessageBuilder(user, NewUserNotificationSubject, tPath);
                    var message = mb.Build<UserModel>(user);
                    message.AdditionalData = dic;
                    var ns = new NotificationService(Smtp, null);
                    ns.Notify(message);

                    if (user.IsValidPhoneServiceProvider())
                    {
                        //   ns.SmsNotify(user.GetPhoneNumber(), "CRS-New User", this.NewCaseNotificationSmsMessageBody, dic, null);
                    }
                }
            }
            catch (Exception)
            {

            }
        }
        HttpResponseMessage defaultProfileResponse = null;
    }
}
