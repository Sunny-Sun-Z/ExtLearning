﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using DCF.SACWIS.CRS.Web.Models;
using DCF.SACWIS.CRS.Web.Models.DB;
using System.Configuration;
using ENT.BLL.Helpers;
using ENT.Entities.Session;
using System.DirectoryServices;
using System.IO;
using System.Drawing.Imaging;

using System.Drawing;
using DCF.SACWIS.CRS.Web.Core.Enums;
namespace DCF.SACWIS.CRS.Web.Controllers.Api
{
    public class BaseApiController : ApiController
    {
        UserModel currentUser = null;
        List<KeyValueModel> keyValuePairs;
        IDictionary<PermissionEnum, bool> usePermissions;

        protected int? UserId
        {
            get
            {
                CookieHelper cookieHelper = new CookieHelper("CRSCookie", System.Web.HttpContext.Current);
                cookieHelper.GetCookie();
                var sessionInfo = cookieHelper.GetValue<SessionInfo>("SessionInfo") ?? new SessionInfo();
                if (sessionInfo != null)
                {

                }
                return sessionInfo.id_prsn_wrkr;
            }
        }
        protected UserModel GetCurrentUser(int? userId)
        {
            if (currentUser == null)
            {
                using (var db = new Models.DB.CrsContext(Connection))
                {
                    currentUser = db.CR_Security_User.Where(w => w.UserID == userId).Select(e => new UserModel
                    {
                        UserID = e.UserID,
                        LoginID = e.LoginID,
                        FirstName = e.FirstName,
                        LastName = e.LastName,
                        Email = e.Email,
                        IsActive = e.IsActive == 1,
                        Avatar = e.Avatar ?? false,
                        MessagePreference = e.MessagePreference,
                        Phone = e.Phone,
                        PhoneServiceProvider = e.PhoneServiceProvider,
                        PhoneServiceProviderName = db.NotificationMobileCarrierGateways.Where(w => w.Id == e.PhoneServiceProvider && w.Enabled == true).Select(p => p.SmsGateway).FirstOrDefault()

                    }).FirstOrDefault();
                }
            }
            return currentUser;
        }

        protected string Connection
        {
            get
            {
                var connectionName = ConfigurationManager.AppSettings["SACWIS_SQL"];
                var commandTimeout = ConfigurationManager.AppSettings["CommandTimeout"];
                if (!string.IsNullOrEmpty(commandTimeout))
                {
                    int.TryParse(commandTimeout, out int time);
                    CrsContext.DefaultCommandTimeout = time;
                }
                var connString = ConfigurationManager.ConnectionStrings[connectionName].ConnectionString;
                var conn = CrsContext.GetEntityConnectionString(connString);
                return conn;

            }
        }
        protected Dictionary<string, byte[]> GetUserPictures()
        {
            var directoryEntry = new DirectoryEntry();
            var directorySearcher = new DirectorySearcher(directoryEntry);
            var dic = new Dictionary<string, byte[]>();

            using (var db = new Models.DB.CrsContext(Connection))
            {
                foreach (var u in db.CR_Security_User)
                {
                    directorySearcher.Filter = string.Format("(&(SAMAccountName={0}))", u.LoginID);
                    var user = directorySearcher.FindOne();
                    if (user != null)
                    {
                        var pic = user.Properties["thumbnailPhoto"];
                        if (pic.Count > 0)
                        {
                            dic.Add(u.LoginID, pic[0] as byte[]);

                        }
                    }
                }

            }

            return dic;

        }
        protected void SaveUserPictures()
        {
            var dic = GetUserPictures();
            var path = System.Web.HttpContext.Current.Server.MapPath(ImagePath);
            foreach (var u in dic)
            {
                using (var ms = new MemoryStream(u.Value))
                {
                    Image img = Image.FromStream(ms);

                    var imageSource = new Bitmap(img, new Size(128, 128));
                    imageSource.Save(path + u.Key + ".png", ImageFormat.Png);

                    imageSource = new Bitmap(img, new Size(36, 36));
                    imageSource.Save(path + u.Key + "36x36.png", ImageFormat.Png);

                    imageSource = new Bitmap(img);
                    imageSource.Save(path + u.Key + "64x64.png", ImageFormat.Png);

                }
            }
        }

        protected List<Rule> GetRules()
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var query = db.Rules.Where(w => w.Enabled == true);
                var rules = query.OrderBy(o => o.Priority).ThenBy(o => o.RuleSetName).Select(e => e).ToList();
                return rules;
            }
        }
        protected void UpdateUserPictures()
        {
            var directoryEntry = new DirectoryEntry();
            var directorySearcher = new DirectorySearcher(directoryEntry);
            var dic = new Dictionary<string, byte[]>();
            var path = System.Web.HttpContext.Current.Server.MapPath(ImagePath);

            using (var db = new Models.DB.CrsContext(Connection))
            {
                foreach (var u in db.CR_Security_User)
                {
                    directorySearcher.Filter = string.Format("(&(SAMAccountName={0}))", u.LoginID);
                    var user = directorySearcher.FindOne();
                    if (user != null)
                    {
                        var pic = user.Properties["thumbnailPhoto"];
                        if (pic.Count > 0)
                        {
                            var pbytes = pic[0] as byte[];
                            using (var ms = new MemoryStream(pbytes))
                            {
                                Image img = Image.FromStream(ms);

                                var imageSource = new Bitmap(img, new Size(128, 128));
                                imageSource.Save(path + u.LoginID + ".png", ImageFormat.Png);

                                imageSource = new Bitmap(img, new Size(36, 36));
                                imageSource.Save(path + u.LoginID + "36x36.png", ImageFormat.Png);

                                imageSource = new Bitmap(img);
                                imageSource.Save(path + u.LoginID + "64x64.png", ImageFormat.Png);
                                u.Avatar = true;
                            }
                        }
                    }

                }
                db.SaveChanges();
            }


        }
        protected static string ImagePath
        {
            get
            {
                //                return "~/app/crs/resources/images/user-profile/";
                //  return "~/app/ExtjsWS/build/testing/quickstart/resources/images/user-profile/";
                return ConfigurationManager.AppSettings["UserProfilePath"];
            }
        }
        protected static string ResourcePath
        {
            get
            {
                return ConfigurationManager.AppSettings["ResourcePath"];
            }
        }

        #region Settings
        protected bool RuleApply
        {
            get
            {
                return KeyValues.FirstOrDefault(w => w.Key.ToLower() == "rule-apply" && w.Value == "1") != null;
            }
        }
        protected bool AllowCaseUpdateNotification
        {
            get
            {
                return KeyValues.FirstOrDefault(w => w.Key.ToLower() == "allow-case-update-notification" && (w.Value == "1" || w.Value.Equals("true", StringComparison.OrdinalIgnoreCase))) != null;
            }
        }
        protected bool AllowNewCaseNotification
        {
            get
            {
                return KeyValues.FirstOrDefault(w => w.Key.ToLower() == "allow-new-case-notification" && (w.Value == "1" || w.Value.Equals("true", StringComparison.OrdinalIgnoreCase))) != null;
            }
        }
        protected bool AllowNewUserNotification
        {
            get
            {
                return KeyValues.FirstOrDefault(w => w.Key.ToLower() == "allow-new-user-notification" && (w.Value == "1" || w.Value.Equals("true", StringComparison.OrdinalIgnoreCase))) != null;
            }
        }
        protected string CaseEliminationFormNotificationSubject
        {
            get
            {
                return KeyValues.Where(w => w.Key.ToLower() == "case-elimination-form-notification-subject").Select(e => e.Value).FirstOrDefault();

            }
        }
        protected string CaseUpdateNotificationSubject
        {
            get
            {
                return KeyValues.Where(w => w.Key.ToLower() == "case-update-notification-subject").Select(e => e.Value).FirstOrDefault();

            }
        }
        protected string FederalTeamEmail
        {
            get
            {
                return KeyValues.Where(w => w.Key.ToLower() == "federal-team-email").Select(e => e.Value).FirstOrDefault();

            }
        }
        protected string CaseUpdateNotificationSmsMessageBody
        {
            get
            {
                return KeyValues.Where(w => w.Key.ToLower() == "case-update-notification-sms-message-body").Select(e => e.Value).FirstOrDefault();
            }
        }
        protected string NewCaseNotificationSmsMessageBody
        {
            get
            {
                return KeyValues.Where(w => w.Key.ToLower() == "new-case-notification-sms-message-body").Select(e => e.Value).FirstOrDefault();

            }
        }

        protected string NewCaseNotificationSubject
        {
            get
            {
                return KeyValues.Where(w => w.Key.ToLower() == "new-case-notification-subject").Select(e => e.Value).FirstOrDefault();

            }
        }
        protected string NewUserNotificationSubject
        {
            get
            {
                return KeyValues.Where(w => w.Key.ToLower() == "new-user-notification-subject").Select(e => e.Value).FirstOrDefault();

            }
        }


        protected string ImportPath
        {
            get
            {
                return KeyValues.Where(w => w.Key.ToLower() == "import-path").Select(e => e.Value).FirstOrDefault();
            }
        }

        protected string ExportPath
        {
            get
            {
                return KeyValues.Where(w => w.Key.ToLower() == "export-path").Select(e => e.Value).FirstOrDefault();
            }
        }
        protected List<KeyValueModel> KeyValues
        {
            get
            {
                if (keyValuePairs == null)
                {
                    using (var db = new Models.DB.CrsContext(Connection))
                    {
                        keyValuePairs = db.KeyValueSettings.Select(e => new KeyValueModel { Key = e.Key, Value = e.Value }).ToList();
                    }
                }
                return keyValuePairs;
            }
        }

        protected SmtpModel Smtp
        {
            get
            {
                var value = KeyValues.Where(w => w.Key.ToLower() == "smtp-setting").Select(e => e.Value).FirstOrDefault();
                if (!string.IsNullOrEmpty(value))
                {
                    return Newtonsoft.Json.JsonConvert.DeserializeObject<SmtpModel>(value);
                }
                return null;
            }
        }

        protected string SampleMonthPeriod1
        {
            get
            {
                return KeyValues.Where(w => w.Key.ToLower() == "sample-month-period-1").Select(e => e.Value).FirstOrDefault();
            }
        }
        protected string SampleMonthPeriod2
        {
            get
            {
                return KeyValues.Where(w => w.Key.ToLower() == "sample-month-period-2").Select(e => e.Value).FirstOrDefault();
            }
        }
        protected string CaseExportUrl
        {
            get
            {
                return KeyValues.Where(w => w.Key.ToLower() == "case-export-url").Select(e => e.Value).FirstOrDefault();
            }
        }

        protected string ReportInBrowsers
        {
            get
            {
                return KeyValues.Where(w => w.Key.ToLower() == "report-in-browsers").Select(e => e.Value).FirstOrDefault();
            }
        }

        protected bool AutoSave
        {
            get
            {
                return KeyValues.FirstOrDefault(w => w.Key.ToLower() == "auto-save" && (w.Value == "1" || w.Value.Equals("true", StringComparison.OrdinalIgnoreCase))) != null;
            }
        }

        #endregion

        #region Permission

        private IDictionary<PermissionEnum, bool> GetUserPermission()
        {
            if (usePermissions == null)
            {

                using (var db = new Models.DB.CrsContext(Connection))
                {
                    var list = db.CR_Security_UserRole.Where(w => w.UserID == UserId)
                        .SelectMany(e => e.CR_Security_Role.CR_Security_RolePermission).ToList()
                        .Select(s => s.CR_Security_Permission)
                        .Union(db.CR_Security_UserPermission.Where(w => w.UserId == UserId)
                            .Select(e => e.CR_Security_Permission)).Select(s => s.PermissionID).Distinct()
                        .ToList();
                    ;

                   // var list = db.CR_Security_UserPermission.Where(w => w.UserId == UserId).Select(e => e.PermissionID).ToList();
                    if (list.Any())
                    {
                        usePermissions = new Dictionary<PermissionEnum, bool>();
                        foreach (var item in list)
                        {
                            try
                            {
                                usePermissions.Add((PermissionEnum) item, true);
                            }
                            catch (Exception ex)
                            {
                                // ignored
                            }
                        }
                    }                   
                }
                
            }

            return usePermissions;
        }
        protected bool HasPermission(PermissionEnum permission)
        {
            var dic = GetUserPermission();
          
            return dic != null && dic.Keys.Contains(permission) && dic[permission];
        }
        #endregion

        #region Audit

        protected void Log(string message, LogEnum type = LogEnum.INFO)
        {
            Log(new ErrorLog
            {
                Message = message,
                Type = type.ToString(),
                UserId = UserId

            });
        }
        protected void Log(Exception ex)
        {
            Log(new ErrorLog
            {
                Message=ex.Message,
                StackTrace=ex.StackTrace,
                Type = LogEnum.ERROR.ToString(),
                UserId=UserId,
                Source=ex.TargetSite.DeclaringType.FullName + " - " + ex.TargetSite.Name,
                
            });
        }
        protected void Log(ErrorLog log)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                log.Created = DateTime.UtcNow;
                db.AddLog(log);
            }
        }

        protected IEnumerable<LogModel> GetLogs(string query)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                return db.GetLogs(query).Select(e => new LogModel { Id = e.Id ,Message=e.Message, Created=e.Created??DateTime.MinValue, Type=e.Type, Source=e.Source,StackTrace=e.StackTrace,UserId=e.UserId}).ToList();
            }
        }
        

        #endregion
    }
}
