﻿using DCF.SACWIS.CRS.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Controllers.Api
{

    public class Dummy
    {
        public static CaseReviewEntityModel GetCaseReviewEntityModel()
        {
            var model = new CaseReviewEntityModel
            {
                CaseReview = new CaseReviewModel
                {
                    CaseID = 1000,
                    CaseName = "test",
                    ReviewStartDate = DateTime.UtcNow,
                    ReviewCompleted = DateTime.UtcNow.AddDays(5),
                    SecondQAUserID = null
                },
                FaceSheet = new FaceSheetModel { },
                Item1 = new Item1Model { }
            };

            return model;
        }
    }
}