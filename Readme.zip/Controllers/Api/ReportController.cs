﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
//using System.Web.Mvc;
using DCF.SACWIS.Core.Entities.Entities.Common;
using DCF.SACWIS.Core.Entities.Entities.CRS;
using DCF.SACWIS.CRS.BLL;
using DCF.SACWIS.CRS.Web.Controllers.Data;
using ENT.BLL.Helpers;
using ENT.Entities.BaseCode;
using ENT.Entities.Helpers;
using Ext.Direct.Mvc;
using Microsoft.Practices.Unity;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using ENT.Entities.Visitor;
using DCF.SACWIS.Core.BLL.Visitor;
using System.Reflection;
using ENT.Entities.Session;
using DCF.SACWIS.CRS.Web.Models;
using DCF.SACWIS.CRS.Web.Models.DB;
using DCF.SACWIS.CRS.Web.Core.Extensions;

namespace DCF.SACWIS.CRS.Web.Controllers.Api
{
    [RoutePrefix("report")]
    public class ReportController : BaseApiController
    {
        [HttpGet]
        [Route("GetReports")]
        public dynamic GetReports(string filter = "", string sort = "", string group = "", int start = 0, int limit = 20)
        {

            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var query = db.AdhocReports.Where(w => w.Enabled == true && w.Type != "LOOKUP");

                if (!string.IsNullOrEmpty(filter))
                {

                    filters = JsonConvert.DeserializeObject<List<Filter>>(filter);
                    var nameFilter = filters.FirstOrDefault(w => w.Property.Equals("name", StringComparison.OrdinalIgnoreCase));
                    if (filters.Any())
                    {
                        if (nameFilter != null && !string.IsNullOrEmpty(nameFilter.Value))
                        {
                            var name = nameFilter.Value.ToString();
                            query = query.Where(w => w.Description.Contains(name) || w.Name.Contains(name));
                        }

                    }
                }
                if (!string.IsNullOrEmpty(sort))
                {
                    var sorts = JsonConvert.DeserializeObject<List<Sorting>>(sort);
                    var s = sorts.FirstOrDefault();
                    var descDir = s.Direction.Equals("DESC", StringComparison.OrdinalIgnoreCase);
                    switch (s.Property.ToLower())
                    {
                        case "name":
                            query = descDir ? query.OrderByDescending(o => o.Name) : query.OrderBy(o => o.Name);
                            break;
                        case "description":
                            query = descDir ? query.OrderByDescending(o => o.Description) : query.OrderBy(o => o.Description);
                            break;

                    }

                }
                else
                {
                    query = query.OrderBy(o => o.Description);
                }

                var count = query.Count();
                var data = query.Select(e => new Models.ReportModel
                {
                    Created = e.Created,
                    CreatedBy = e.CreatedBy,
                    Description = e.Description,
                    Enabled = e.Enabled,
                    FileName = e.FileName,
                    Id = e.Id,
                    Name = e.Name,
                    Query = e.Query,
                    Type = e.Type,
                    Url = e.Url,
                    Component = e.Component,
                    Parameters = e.Parameters.Select(p =>
                        new Parameter
                        {
                            DataType = p.DataType,
                            DefaultValue = p.DefaultValue,
                            FieldType = p.FieldType,
                            Id = p.Id,
                            Label = p.Label,
                            LookupDisplayField = p.LookupDisplayField,
                            LookupId = p.LookupId,
                            LookupValueField = p.LookupValueField,
                            Name = p.Name,
                            FieldValidationType = p.FieldValidationType,
                            Required = p.Required
                        })
                        .ToList()

                }).ToList();
                return new { success = true, data = data, total = count };
            }

        }



        [HttpGet]
        [Route("GetReportLookup")]
        public dynamic GetReportLookup(string filter = "", string sort = "", int start = 0, int limit = 20)
        {

            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var query = db.AdhocReports.Where(w => w.Enabled == true && w.Type == "LOOKUP").OrderBy(o => o.Description);

                var count = query.Count();
                var data = query.Select(e => new { Key = e.Id, Value = e.Description }).ToList();
                return new { success = true, data = data, total = count };
            }

        }
        [HttpGet]
        [Route("GetReportLookupResult")]
        public dynamic GetReportLookupResult(int id, string query = "", string sort = "", int start = 0, int limit = 20)
        {

            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var item = db.AdhocReports.FirstOrDefault(w => w.Enabled == true && w.Type == "LOOKUP" && w.Id == id);
                var count = 0;
                List<dynamic> data;
                if (!string.IsNullOrEmpty(query))
                    data = db.DynamicSqlQuery(item.Query)
                        .Where(w => w.Value.ToLower().Contains(query.ToLower()))
                        .OrderBy(o => o.Value)
                        .ToList();
                else
                    data = db.DynamicSqlQuery(item.Query)
                        .OrderBy(o => o.Value)
                        .ToList();

                count = data.Count();
                data = data.Skip(start).Take(limit).ToList();
                return new { success = true, data = data, total = count };
            }

        }

        [HttpPost]
        [Route("SaveReport")]
        public dynamic SaveReport(Models.DB.AdhocReport item)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {

                item.CreatedBy = UserId;
                item.Created = DateTime.UtcNow;
                item.Enabled = true;
                item.Name = item.Description.ToUpper().Replace(" ", "_");
                if (item.Type == "SSIS")
                {
                    item.Query = null;
                }
                else
                {
                    item.FileName = null;
                    var q = item.Query.ToLower();
                    if (q.Contains("insert ") || q.Contains("update ") || q.Contains("delete ") || q.Contains("drop ") || q.Contains("exec ") || q.Contains("execute "))
                        return new { success = false, data = item, message = "Query does not support INSERT/UPDATE/DELETE/DROP/EXECUTE Command" };
                }
                item.Created = DateTime.UtcNow;
                if (item.Id == 0)
                {
                    db.AdhocReports.Add(item);
                }
                else
                {
                    var temp = db.AdhocReports.FirstOrDefault(w => w.Id == item.Id);


                    if (temp != null)
                    {

                        temp.Name = item.Name;
                        temp.Query = item.Query;
                        temp.FileName = item.FileName;
                        temp.Component = item.Component;
                        temp.Description = item.Description;
                        temp.Url = item.Url;
                        temp.Type = item.Type;
                        temp.Enabled = item.Enabled;

                        db.AdhocReportQueryParameters.RemoveRange(temp.Parameters.Select(e => e));
                        if (item.Parameters.Any())
                        {
                            foreach (var p in item.Parameters)
                            {
                                temp.Parameters.Add(new AdhocReportQueryParameter
                                {
                                    DataType = p.DataType,
                                    DefaultValue = p.DefaultValue,
                                    FieldType = p.FieldType,
                                    FieldValidationType = p.FieldValidationType,
                                    Label = p.Label,
                                    LookupDisplayField = p.LookupDisplayField,
                                    LookupId = p.LookupId,
                                    LookupValueField = p.LookupValueField,
                                    Name = p.Name,
                                    Required = p.Required
                                });
                            }
                        }

                    }
                }

                db.SaveChanges();

                return new { success = true, message = "Report Saved successfully" };
            }

        }

        [HttpPost]
        [Route("DeleteReport")]
        public dynamic DeleteReport(Models.DB.AdhocReport item)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var temp = db.AdhocReports.FirstOrDefault(w => w.Id == item.Id);
                if (temp != null)
                {
                    temp.Enabled = false;
                    db.SaveChanges();
                }

                return new { success = true, message = "Report deleted successfully" };
            }

        }

        [HttpGet]
        [Route("getAdhocColumns")]
        public dynamic GetAdhocColumns(int id)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var item = db.AdhocReports.Where(w => w.Enabled == true && w.Id == id).FirstOrDefault();

                Dictionary<string, object> parameters = null;
                if (item.Parameters.Any())
                {
                    parameters = new Dictionary<string, object>();
                    foreach (var p in item.Parameters.Select(e => new Parameter { DefaultValue = e.DefaultValue, DataType = e.DataType, Name = e.Name }).ToList())
                    {
                        parameters.Add(p.Name, p.GetDefaultValue());
                    }
                }
                var cols = db.DynamicSqlColumns(item.Query, parameters);

                return new { success = true, data = cols.ToExtJsColumns() };

            }

        }

        [HttpGet]
        [Route("GetAdhocResult")]
        public dynamic GetAdhocResult(int id, string filter = "", string sort = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var item = db.AdhocReports.Where(w => w.Enabled == true && w.Id == id).FirstOrDefault();
                Dictionary<string, object> parameters = null;
                if (!string.IsNullOrEmpty(filter))
                {
                    filters = JsonConvert.DeserializeObject<List<Filter>>(filter);
                }
                if (item.Parameters.Any())
                {

                    parameters = new Dictionary<string, object>();
                    foreach (var p in item.Parameters.Select(e => new Parameter { DefaultValue = e.DefaultValue, DataType = e.DataType, Name = e.Name, }).ToList())
                    {
                        var val = p.GetDefaultValue();
                        if (filters.Any())
                        {
                            var val1 = filters.Where(w => w.Property == p.Name).Select(f => f.Value).FirstOrDefault();
                            if (val1 != null)
                                val = val1;
                        }
                        parameters.Add(p.Name, val);
                    }
                }

                var data = db.DynamicSqlQuery(item.Query, parameters).ToList();

                return new { success = true, data = data, total = data.Count };
            }

        }


        #region Private Method


        #endregion
    }


}
