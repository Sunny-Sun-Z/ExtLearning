﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DCF.SACWIS.CRS.Web.Models;
using DCF.SACWIS.CRS.Web.Models.DB;
using System.Reflection;
using System.Linq.Expressions;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using System.Threading.Tasks;
using System.IO;
using DCF.SACWIS.CRS.Web.Services;
using System.ComponentModel;
namespace DCF.SACWIS.CRS.Web.Controllers.Api
{
    [RoutePrefix("setting")]
    public class SettingController : BaseApiController
    {
        [HttpGet]
        [Route("GetRules")]
        public dynamic GetRules(string filter = "", string sort = "", string group = "", int start = 0, int limit = 20)
        {

            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var query = db.Rules.AsQueryable();

                if (!string.IsNullOrEmpty(filter))
                {

                    filters = JsonConvert.DeserializeObject<List<Filter>>(filter);
                    var enabledFilter = filters.FirstOrDefault(w => w.Property.Equals("Enabled", StringComparison.OrdinalIgnoreCase));
                    var nameFilter = filters.FirstOrDefault(w => w.Property.Equals("PropertyName", StringComparison.OrdinalIgnoreCase));
                    var ruleSetNameFilter = filters.FirstOrDefault(w => w.Property.Equals("RuleSetName", StringComparison.OrdinalIgnoreCase));
                    var categoryFilter = filters.FirstOrDefault(w => w.Property.Equals("Category", StringComparison.OrdinalIgnoreCase));
                    var requiredFilter = filters.FirstOrDefault(w => w.Property.Equals("Required", StringComparison.OrdinalIgnoreCase));

                    if (filters.Any())
                    {
                        if (enabledFilter != null && !string.IsNullOrEmpty(enabledFilter.Value))
                        {
                            var flag = enabledFilter.Value.Equals("true", StringComparison.OrdinalIgnoreCase);
                            query = query.Where(w => w.Enabled == flag);
                        }
                        if (nameFilter != null && !string.IsNullOrEmpty(nameFilter.Value))
                        {
                            var name = nameFilter.Value.ToString();
                            query = query.Where(w => w.PropertyName.Contains(name));
                        }
                        if (ruleSetNameFilter != null && !string.IsNullOrEmpty(ruleSetNameFilter.Value))
                        {
                            var name = ruleSetNameFilter.Value.ToString();
                            query = query.Where(w => w.RuleSetName.Contains(name));
                        }
                        if (categoryFilter != null && !string.IsNullOrEmpty(categoryFilter.Value))
                        {
                            var name = categoryFilter.Value.ToString();
                            query = query.Where(w => w.Category.Contains(name));
                        }

                        if (requiredFilter != null && !string.IsNullOrEmpty(requiredFilter.Value))
                        {
                            var flag = requiredFilter.Value.Equals("true", StringComparison.OrdinalIgnoreCase);
                            query = query.Where(w => w.Enabled == flag);
                        }
                    }
                }
                if (!string.IsNullOrEmpty(group))
                {
                    var g = JsonConvert.DeserializeObject<Sorting>(group);
                    var descDir = g.Direction.Equals("DESC", StringComparison.OrdinalIgnoreCase);
                    switch (g.Property.ToLower())
                    {
                        case "enabled":
                            query = SortedRules(descDir ? query.OrderByDescending(o => o.Enabled) : query.OrderBy(o => o.Enabled), sort);
                            break;
                        case "rulesetname":
                            query = SortedRules(descDir ? query.OrderByDescending(o => o.RuleSetName) : query.OrderBy(o => o.RuleSetName), sort);
                            break;
                        case "category":
                            query = SortedRules(descDir ? query.OrderByDescending(o => o.Category) : query.OrderBy(o => o.Category), sort);
                            break;
                        case "required":
                            query = SortedRules(descDir ? query.OrderByDescending(o => o.Required) : query.OrderBy(o => o.Required), sort);
                            break;
                        case "created":
                            query = SortedRules(descDir ? query.OrderByDescending(o => o.Created) : query.OrderBy(o => o.Created), sort);
                            break;
                        case "createdby":
                            query = SortedRules(descDir ? query.OrderByDescending(o => o.CreatedBy) : query.OrderBy(o => o.CreatedBy), sort);
                            break;
                    }
                }
                else
                {
                    if (!string.IsNullOrEmpty(sort))
                    {
                        var sorts = JsonConvert.DeserializeObject<List<Sorting>>(sort);
                        var s = sorts.FirstOrDefault();
                        var descDir = s.Direction.Equals("DESC", StringComparison.OrdinalIgnoreCase);
                        switch (s.Property.ToLower())
                        {
                            case "id":
                                query = descDir ? query.OrderByDescending(o => o.Id) : query.OrderBy(o => o.Id);
                                break;
                            case "enabled":
                                query = descDir ? query.OrderByDescending(o => o.Enabled) : query.OrderBy(o => o.Enabled);
                                break;
                            case "rulesetname":
                                query = descDir ? query.OrderByDescending(o => o.RuleSetName) : query.OrderBy(o => o.RuleSetName);
                                break;
                            case "category":
                                query = descDir ? query.OrderByDescending(o => o.Category) : query.OrderBy(o => o.Category);
                                break;
                            case "required":
                                query = descDir ? query.OrderByDescending(o => o.Required) : query.OrderBy(o => o.Required);
                                break;
                            case "created":
                                query = descDir ? query.OrderByDescending(o => o.Created) : query.OrderBy(o => o.Created);
                                break;
                            case "createdby":
                                query = descDir ? query.OrderByDescending(o => o.CreatedBy) : query.OrderBy(o => o.CreatedBy);
                                break;
                            case "priority":
                                query = descDir ? query.OrderByDescending(o => o.Priority) : query.OrderBy(o => o.Priority);
                                break;
                        }

                    }
                    else
                    {
                        query = query.OrderBy(o => o.Id);
                    }
                }



                var count = query.Count();
                var data = query.Select(e => e).ToList();
                return new { success = true, data = data, total = count };
            }

        }

        private IOrderedQueryable<Rule> SortedRules(IOrderedQueryable<Rule> query, string sort)
        {
            if (!string.IsNullOrEmpty(sort))
            {
                var sorts = JsonConvert.DeserializeObject<List<Sorting>>(sort);
                var s = sorts.FirstOrDefault();
                var descDir = s.Direction.Equals("DESC", StringComparison.OrdinalIgnoreCase);
                switch (s.Property.ToLower())
                {
                    case "id":
                        query = descDir ? query.ThenByDescending(o => o.Id) : query.ThenBy(o => o.Id);
                        break;
                    case "enabled":
                        query = descDir ? query.ThenByDescending(o => o.Enabled) : query.ThenBy(o => o.Enabled);
                        break;
                    case "rulesetname":
                        query = descDir ? query.ThenByDescending(o => o.RuleSetName) : query.ThenBy(o => o.RuleSetName);
                        break;
                    case "category":
                        query = descDir ? query.ThenByDescending(o => o.Category) : query.ThenBy(o => o.Category);
                        break;
                    case "required":
                        query = descDir ? query.ThenByDescending(o => o.Required) : query.ThenBy(o => o.Required);
                        break;
                    case "created":
                        query = descDir ? query.ThenByDescending(o => o.Created) : query.ThenBy(o => o.Created);
                        break;
                    case "createdby":
                        query = descDir ? query.ThenByDescending(o => o.CreatedBy) : query.ThenBy(o => o.CreatedBy);
                        break;
                    case "priority":
                        query = descDir ? query.ThenByDescending(o => o.Priority) : query.ThenBy(o => o.Priority);
                        break;
                }
            }
            else
            {
                query = query.ThenBy(o => o.Id);
            }

            return query;
        }

        [HttpPost]
        [Route("SaveRule")]
        public dynamic SaveRule(Models.DB.Rule item)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var msg = "Rule added successfully";
                item.Created = DateTime.UtcNow;
                item.CreatedBy = UserId;
                item.IsRuleSet = !string.IsNullOrEmpty(item.RuleSetName);
                item.PropertyName = item.Predicate.Substring(item.Predicate.IndexOf("::") + 2);
                item.Category = item.Predicate.Substring(0, item.Predicate.IndexOf("::")).Replace("Model", "");

                if (item.Id == 0)
                {
                    db.Rules.Add(item);
                }
                else
                {
                    var temp = db.Rules.FirstOrDefault(w => w.Id == item.Id);
                    if (temp != null)
                    {
                        temp.ErrorMessage = item.ErrorMessage;
                        temp.PropertyName = item.PropertyName;
                        temp.Category = item.Category;
                        temp.OpenBracket = item.OpenBracket;
                        temp.CloseBracket = item.CloseBracket;
                        temp.StartDate = item.StartDate;
                        temp.EndDate = item.EndDate;
                        temp.LogicOperator = item.LogicOperator;
                        temp.Created = item.Created;
                        temp.CreatedBy = item.CreatedBy;
                        temp.DataType = item.DataType;
                        temp.Enabled = item.Enabled;
                        temp.IsRuleSet = item.IsRuleSet;
                        temp.Mode = item.Mode;
                        temp.Required = item.Required;
                        temp.Operator = item.Operator;
                        temp.Predicate = item.Predicate;
                        temp.Priority = item.Priority;
                        temp.RuleSetName = item.RuleSetName;
                        temp.TargetValue = item.TargetValue;
                        temp.TargetValue1 = item.TargetValue1;
                        msg = "Rule updated successfully";
                    }
                }
                db.SaveChanges();
                return new { success = true, data = item, message = msg };
            }

        }
        [HttpPost]
        [Route("DeleteRule")]
        public dynamic DeleteRule(Models.DB.Rule item)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {

                if (item.Id > 0)
                {
                    item = db.Rules.FirstOrDefault(w => w.Id == item.Id);
                    if (item != null)
                        db.Rules.Remove(item);
                }
                db.SaveChanges();
                return new { success = true, data = item, message = "Rule deleted successfully" };
            }

        }

        [HttpGet]
        [Route("GetKeyValueSettings")]
        public dynamic GetKeyValueSettings(string filter = "", string sort = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var query = db.KeyValueSettings.Where(w => w.Type == null || w.Type != 3); //3=not visible in list
                query = query.OrderBy(o => o.Key);
                var count = query.Count();
                var data = query.Select(e => e).ToList();
                return new { success = true, data = data, total = count };
            }

        }
        [HttpPost]
        [Route("SaveKeyValues")]
        public dynamic SaveKeyValues(List<Models.DB.KeyValueSetting> items)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                foreach (var item in items)
                {

                    if (item.Id > 0)
                    {
                        var temp = db.KeyValueSettings.FirstOrDefault(w => w.Id == item.Id);
                        if (temp != null)
                        {
                            temp.CreatedBy = UserId;
                            temp.DataType = item.DataType;
                            temp.Description = item.Description;
                            temp.Key = item.Key;
                            temp.Value = item.Value;
                        }
                    }
                    else
                    {
                        item.CreatedBy = UserId;
                        item.Created = DateTime.UtcNow;
                        db.KeyValueSettings.Add(item);
                    }

                    db.SaveChanges();
                }



                return new { success = true, data = items, message = "Key Value Settings updated successfully" };
            }

        }
        [HttpPost]
        [Route("DeleteKeyValue")]
        public dynamic DeleteKeyValue(Models.DB.KeyValueSetting item)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {

                if (item.Id > 0)
                {
                    item = db.KeyValueSettings.FirstOrDefault(w => w.Id == item.Id);
                    if (item != null)
                        db.KeyValueSettings.Remove(item);
                }
                db.SaveChanges();
                return new { success = true, data = item, message = "Key Value Settings deleted successfully" };
            }

        }

        [HttpGet]
        [Route("GetSmtp")]
        public dynamic GetSmtp()
        {
            return new { success = true, data = Smtp };
        }

        [HttpPost]
        [Route("SaveSmtp")]
        public dynamic SaveSmtp(SmtpModel item)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {

                var temp = db.KeyValueSettings.FirstOrDefault(w => w.Key == "smtp-setting");
                if (temp != null)
                {
                    temp.CreatedBy = UserId;
                    temp.Type = 3;
                    temp.Value = JsonConvert.SerializeObject(item);
                }

                else
                {
                    var kv = new KeyValueSetting
                    {
                        CreatedBy = UserId,
                        Created = DateTime.UtcNow,
                        DataType = "SmtpModel",
                        Description = "smtp-setting",
                        Key = "smtp-setting",
                        Type = 3,
                        Value = JsonConvert.SerializeObject(item)
                    };

                    db.KeyValueSettings.Add(kv);
                }

                db.SaveChanges();
                return new { success = true, data = item, message = "Smtp Setting updated successfully" };
            }
        }
        [HttpPost]
        [Route("SendTestMail")]
        public dynamic SendTestMail(SmtpModel item, string email)
        {

            dynamic result = null;
            new NotificationService(Smtp, null)
               .NotifyAsync(email, "SMTP Test Mail", "Test SMTP Configured", (object sender, AsyncCompletedEventArgs e) =>
               {
                   if (e.Cancelled)
                       result = new { success = true, message = "Test mail has been canceled" };
                   if (e.Error != null)
                       result = new { success = true, message = "Test mail failed to deliver" };
                   else
                       result = new { success = true, message = "Test mail has been sent successfully" };

               });

            return new { success = true, message = "Test mail has been submited in queue. It might be take sometimes to deliver." };

        }


        [HttpGet]
        [Route("UpdateUserPictures")]
        public dynamic UpdateADProfilePictures()
        {
            UpdateUserPictures();
            return new { success = true, message = "Sync Completed" };
        }

        [HttpGet]
        [Route("Compile")]
        public dynamic Compile(string editedItems)
        {
            var failedList = new List<Rule>();
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var modifiedItems = editedItems.Split(',').ToList().Distinct().ToList();
                var filters = new List<Filter>();
                var rules = GetRules();
                var model = Dummy.GetCaseReviewEntityModel();
                RuleBuilder rb = new RuleBuilder(modifiedItems, rules, model);

                rb.Build();
                rb.Process();

                return new { success = true, message = rb.IsFailed ? "Compilation Failed" : "Compilation Success", data = rb.FailedItems };

            }
        }


        [HttpGet]
        [Route("GetExportCaseAvailable")]
        public dynamic GetExportCaseAvailable(string filter = "", string sort = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var v = 0;
                var where = db.ActiveCases().Where(w => w.CaseStatusCode == 7 && w.BatchProcessedID == null);
                if (!string.IsNullOrEmpty(filter))
                {

                    filters = JsonConvert.DeserializeObject<List<Filter>>(filter);

                    foreach (var f in filters)
                    {
                        switch (f.Property)
                        {
                            case "CaseReviewRootID":
                                v = Convert.ToInt32(f.Value);
                                switch (f.Operator)
                                {
                                    case "gt":
                                        where = where.Where(w => w.CaseReviewRootID > v);
                                        break;
                                    case "lt":
                                        where = where.Where(w => w.CaseReviewRootID < v);
                                        break;
                                    case "like":
                                        where = where.Where(w => w.CaseReviewRootID.HasValue && w.CaseReviewRootID.ToString().Contains(f.Value));
                                        break;
                                    default:
                                        where = where.Where(w => w.CaseReviewRootID == v);

                                        break;
                                }
                                break;
                            case "CaseID":
                                v = Convert.ToInt32(f.Value);

                                switch (f.Operator)
                                {
                                    case "gt":
                                        where = where.Where(w => w.CaseID > v);
                                        break;
                                    case "lt":
                                        where = where.Where(w => w.CaseID < v);
                                        break;
                                    case "like":
                                        where = where.Where(w => w.CaseID.HasValue && w.CaseID.ToString().Contains(f.Value));
                                        break;
                                    default:
                                        where = where.Where(w => w.CaseID == v);

                                        break;
                                }
                                break;
                            case "CaseName":

                                where = where.Where(w => w.CaseName.Contains(f.Value));

                                break;

                        }
                    }
                }


                var query = where.Select(e => new
                {
                    e.CaseID,
                    e.MeetingID,
                    e.CaseName,
                    e.CaseReviewID,
                    e.CaseReviewRootID,
                    e.BatchProcessedID,
                    e.FederalProcessedDate,
                    e.ReviewCompleted,
                    e.ReviewStartDate,
                    e.ReviewSubTypeID,
                    e.ReviewTypeID,
                    e.SiteCode,
                    e.CaseStatusCode,
                    e.Active,
                    e.ExportedBy,
                    e.ExportedDate
                });


                if (!string.IsNullOrEmpty(sort))
                {
                    var sorts = JsonConvert.DeserializeObject<List<Sorting>>(sort);
                    var s = sorts.FirstOrDefault();
                    var descDir = s.Direction.Equals("DESC", StringComparison.OrdinalIgnoreCase);
                    switch (s.Property)
                    {
                        case "CaseID":
                            query = descDir ? query.OrderByDescending(o => o.CaseID) : query.OrderBy(o => o.CaseID);
                            break;
                        case "CaseReviewRootID":
                            query = descDir ? query.OrderByDescending(o => o.CaseReviewRootID) : query.OrderBy(o => o.CaseReviewRootID);
                            break;
                        case "CaseReviewID":
                            query = descDir ? query.OrderByDescending(o => o.CaseReviewID) : query.OrderBy(o => o.CaseReviewID);
                            break;
                        default:
                            query = descDir ? query.OrderByDescending(o => o.CaseName) : query.OrderBy(o => o.CaseName);
                            break;

                    }
                }
                else
                {
                    query = query.OrderBy(o => o.CaseName);

                }
                var count = query.Count();
                var data = query.Skip(start).Take(limit).ToList();
                return new { success = true, data = data, total = count };
            }

        }
        [HttpGet]
        [Route("GetProcessedExportCases")]
        public dynamic GetProcessedExportCases(string filter = "", string sort = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var v = 0;
                var where = db.ActiveCases().Where(w => w.CaseStatusCode == 7 && w.BatchProcessedID == null);

                if (!string.IsNullOrEmpty(filter))
                {

                    filters = JsonConvert.DeserializeObject<List<Filter>>(filter);

                    foreach (var f in filters)
                    {
                        switch (f.Property)
                        {
                            case "CaseID":
                                v = Convert.ToInt32(f.Value);

                                switch (f.Operator)
                                {
                                    case "gt":
                                        where = where.Where(w => w.CaseID > v);
                                        break;
                                    case "lt":
                                        where = where.Where(w => w.CaseID < v);
                                        break;
                                    case "like":
                                        where = where.Where(w => w.CaseID.HasValue && w.CaseID.ToString().Contains(f.Value));
                                        break;
                                    default:
                                        where = where.Where(w => w.CaseID == v);

                                        break;
                                }
                                break;
                            case "CaseName":
                                where = where.Where(w => w.CaseName.Contains(f.Value));
                                break;

                        }
                    }
                }

                var query = where.Select(e => new ExportCaseModel
                {
                    CaseID = e.CaseID,
                    MeetingID = e.MeetingID,
                    CaseName = e.CaseName,
                    CaseReviewID = e.CaseReviewID,
                    CaseReviewRootID = e.CaseReviewRootID,
                    BatchProcessedID = e.BatchProcessedID,
                    FederalProcessedDate = e.FederalProcessedDate,
                    ReviewCompleted = e.ReviewCompleted,
                    ReviewStartDate = e.ReviewStartDate,
                    ReviewSubTypeID = e.ReviewSubTypeID,
                    ReviewTypeID = e.ReviewTypeID,
                    SiteCode = e.SiteCode,
                    CaseStatusCode = e.CaseStatusCode,
                    Active = e.Active,
                    ExportedDate = e.ExportedDate,
                    ExportedBy = e.ExportedBy
                });

                if (!string.IsNullOrEmpty(sort))
                {
                    var sorts = JsonConvert.DeserializeObject<List<Sorting>>(sort);
                    var s = sorts.FirstOrDefault();
                    var descDir = s.Direction.Equals("DESC", StringComparison.OrdinalIgnoreCase);
                    switch (s.Property)
                    {
                        case "CaseID":
                            query = descDir ? query.OrderByDescending(o => o.CaseID) : query.OrderBy(o => o.CaseID);
                            break;
                        case "CaseReviewRootID":
                            query = descDir ? query.OrderByDescending(o => o.CaseReviewRootID) : query.OrderBy(o => o.CaseReviewRootID);
                            break;
                        case "CaseReviewID":
                            query = descDir ? query.OrderByDescending(o => o.CaseReviewID) : query.OrderBy(o => o.CaseReviewID);
                            break;
                        case "CaseName":
                            query = descDir ? query.OrderByDescending(o => o.CaseName) : query.OrderBy(o => o.CaseName);
                            break;
                    }
                }
                else
                {
                    query = query.OrderBy(o => o.CaseName);
                }
                var count = query.Count();
                var data = query.Skip(start).Take(limit).ToList();

                var exportPathDir = ExportPath;

                if (count > 0 && !String.IsNullOrEmpty(exportPathDir) && Directory.Exists(exportPathDir))
                {
                    foreach (var item in data)
                    {

                        var file = string.Concat(item.CaseName, "_", item.CaseReviewID, ".xml");
                        var filePath = Path.Combine(exportPathDir, file);
                        var fileOutPath = Path.Combine(exportPathDir.ToLower().Replace("inmanual","out"), file);

                        item.HasFile = File.Exists(filePath) || File.Exists(fileOutPath);
                    }
                }
                return new { success = true, data = data, total = count };
            }

        }

        [HttpGet]
        [Route("GetImportedCases")]
        public dynamic GetImportedCases(string filter = "", string sort = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var v = 0;
                var where = db.ActiveCases().Where(w => w.IsCaseImported == true || w.ImportSource != null);
                if (!string.IsNullOrEmpty(filter))
                {

                    filters = JsonConvert.DeserializeObject<List<Filter>>(filter);

                    foreach (var f in filters)
                    {
                        switch (f.Property)
                        {
                            case "CaseReviewRootID":
                                v = Convert.ToInt32(f.Value);
                                switch (f.Operator)
                                {
                                    case "gt":
                                        where = where.Where(w => w.CaseReviewRootID > v);
                                        break;
                                    case "lt":
                                        where = where.Where(w => w.CaseReviewRootID < v);
                                        break;
                                    case "like":
                                        where = where.Where(w => w.CaseReviewRootID.HasValue && w.CaseReviewRootID.ToString().Contains(f.Value));
                                        break;
                                    default:
                                        where = where.Where(w => w.CaseReviewRootID == v);

                                        break;
                                }
                                break;
                            case "CaseID":
                                v = Convert.ToInt32(f.Value);

                                switch (f.Operator)
                                {
                                    case "gt":
                                        where = where.Where(w => w.CaseID > v);
                                        break;
                                    case "lt":
                                        where = where.Where(w => w.CaseID < v);
                                        break;
                                    case "like":
                                        where = where.Where(w => w.CaseID.HasValue && w.CaseID.ToString().Contains(f.Value));
                                        break;
                                    default:
                                        where = where.Where(w => w.CaseID == v);

                                        break;
                                }
                                break;
                            case "CaseName":

                                where = where.Where(w => w.CaseName.Contains(f.Value));

                                break;

                        }
                    }
                }


                var query = where.Select(e => new
                {
                    e.CaseID,
                    e.MeetingID,
                    e.CaseName,
                    e.CaseReviewID,
                    e.CaseReviewRootID,
                    e.BatchProcessedID,
                    e.FederalProcessedDate,
                    e.ReviewCompleted,
                    e.ReviewStartDate,
                    e.ReviewSubTypeID,
                    e.ReviewTypeID,
                    e.SiteCode,
                    e.CaseStatusCode,
                    e.Active,
                    e.ImportSource,
                    e.IsCaseImported,
                    e.InitialQAUserID,
                    e.SecondQAUserID,
                    e.SecondaryOversightUserID,
                    e.CtSecondaryOversightUserID,
                    Reviewers = e.CR_Reviewer.Select(r => r.UserID).ToList(),
                    ImportedDate = e.TS_CR
                });


                if (!string.IsNullOrEmpty(sort))
                {
                    var sorts = JsonConvert.DeserializeObject<List<Sorting>>(sort);
                    var s = sorts.FirstOrDefault();
                    var descDir = s.Direction.Equals("DESC", StringComparison.OrdinalIgnoreCase);
                    switch (s.Property)
                    {
                        case "CaseID":
                            query = descDir ? query.OrderByDescending(o => o.CaseID) : query.OrderBy(o => o.CaseID);
                            break;
                        case "CaseReviewRootID":
                            query = descDir ? query.OrderByDescending(o => o.CaseReviewRootID) : query.OrderBy(o => o.CaseReviewRootID);
                            break;
                        case "CaseReviewID":
                            query = descDir ? query.OrderByDescending(o => o.CaseReviewID) : query.OrderBy(o => o.CaseReviewID);
                            break;
                        default:
                            query = descDir ? query.OrderByDescending(o => o.CaseName) : query.OrderBy(o => o.CaseName);
                            break;

                    }
                }
                else
                {
                    query = query.OrderBy(o => o.CaseName);

                }
                var count = query.Count();
                var data = query.Skip(start).Take(limit).ToList();
                return new { success = true, data = data, total = count };
            }

        }

        [HttpPost]
        [Route("AssignUsersToCase")]
        public dynamic AssignUsersToCase(CaseAssignUserModel model)
        {

            using (var db = new Models.DB.CrsContext(Connection))
            {
                try
                {

                    if (model == null || model.Ids.Count == 0)
                        throw new Exception("There is no file requested for export");

                    foreach (var id in model.Ids)
                    {
                        var cr = db.CaseReviews.FirstOrDefault(w => w.CaseReviewID == id);
                        if (cr != null)
                        {

                            cr.CaseID = model.CaseID;
                            cr.InitialQAUserID = model.InitialQAUserID;
                            cr.SecondQAUserID = model.SecondQAUserID;
                            cr.SecondaryOversightUserID = model.SecondaryOversightUserID;
                            cr.CtSecondaryOversightUserID = model.CtSecondaryOversightUserID;
                            cr.ID_UP = UserId;
                            cr.TS_UP = DateTime.UtcNow;
                            if (!cr.CR_Reviewer.Any())
                            {
                                foreach (var reviewer in model.Reviewers)
                                {
                                    cr.CR_Reviewer.Add(new CR_Reviewer { ID_CR = UserId, TS_CR = DateTime.UtcNow, UserID = reviewer });
                                }
                            }
                            db.SaveChanges();
                        }
                    }
                    return new { success = true, message = " QA and Reviewers have been assigned successfully to the selected cases" };

                }
                catch (Exception ex)
                {
                    Log(ex);
                    return new { success = false, message = ex.Message };
                }

            }
        }



        [HttpGet]
        [Route("export")]
        public dynamic Export(int id, string name)
        {

            using (var db = new Models.DB.CrsContext(Connection))
            {
                try
                {
                    var exportPathDir = ExportPath;

                    if (String.IsNullOrEmpty(exportPathDir))
                    {
                        throw new Exception("Export Path does not configured in setting.");
                    }
                    var cr = db.CaseReviews.OrderByDescending(w=>w.CaseReviewID).FirstOrDefault(w => w.CaseReviewRootID == id);

                    if (!Directory.Exists(exportPathDir))
                        throw new DirectoryNotFoundException(string.Format("Attempted to access a path '{0}' that is not on the disk or not accessible.", exportPathDir));
                    if (cr != null)
                    {
                        var filePath = Path.Combine(exportPathDir, string.Concat(name, "_",cr.CaseReviewID.ToString(), ".xml"));
                        
                        var xml = db.Export(id);
                        if (String.IsNullOrEmpty(xml))
                        {
                            throw new Exception("Case has already been processed");
                        }

                        using (var fs = new System.IO.StreamWriter(filePath))
                        {
                            fs.WriteLine(xml);
                        }

                        cr.ExportedDate = DateTime.UtcNow;
                        cr.ExportedBy = UserId;
                        db.SaveChanges();
                    }
                    return new { success = true, message = "Case exported successfully" };

                }
                catch (Exception ex)
                {
                    Log(ex);
                    return new { success = false, message = ex.Message };
                }

            }
        }


        [HttpPost]
        [Route("ExportMultiple")]
        public dynamic ExportMultiple(List<LookupModel> items)
        {

            using (var db = new Models.DB.CrsContext(Connection))
            {
                try
                {
                    var exportPathDir = ExportPath;

                    if (String.IsNullOrEmpty(exportPathDir))
                    {
                        throw new Exception("Export Path does not configured in setting.");
                    }

                    if (!Directory.Exists(exportPathDir))
                        throw new DirectoryNotFoundException(string.Format("Attempted to access a path '{0}' that is not on the disk or not accessible.", exportPathDir));

                    if (items == null || items.Count == 0)
                        throw new Exception("There is no file requested for export");

                    var error = new List<string>();
                    foreach (var item in items)
                    {
                        var filePath = Path.Combine(exportPathDir, string.Concat(item.Name, "_", item.Id.ToString(), ".xml"));
                        var xml = db.Export(item.Id);
                        if (String.IsNullOrEmpty(xml))
                        {
                            error.Add(string.Format("Case (ID:{0}, {1}) has already been processed", item.Id, item.Name));
                        }
                        else
                        {
                            try
                            {
                                using (var fs = new System.IO.StreamWriter(filePath))
                                {
                                    fs.WriteLine(xml);
                                }
                                var cr = db.CaseReviews.FirstOrDefault(w => w.CaseReviewID == item.Id);
                                if (cr != null)
                                {
                                    cr.ExportedDate = DateTime.UtcNow;
                                    cr.ExportedBy = UserId;
                                    db.SaveChanges();
                                }
                            }
                            catch (Exception ex1)
                            {
                                error.Add(string.Format("Case (ID:{0}, {1}) Faild. Erorr:{2}", item.Id, item.Name, ex1.Message));
                            }
                        }

                    }
                    return new { success = error.Count == 0, message = error.Count == 0 ? "Case exported successfully" : string.Join("<br/>", error) };

                }
                catch (Exception ex)
                {
                    Log(ex);
                    return new { success = false, message = ex.Message };
                }

            }
        }

        [HttpPost]
        [Route("import")]
        public dynamic Import()
        {
            HttpRequestMessage request = this.Request;
            try
            {


                if (!request.Content.IsMimeMultipartContent())
                {
                    throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);
                }
                var importDir = ImportPath;

                if (string.IsNullOrEmpty(importDir))
                    throw new Exception("Import Path does not configured");
                if (!Directory.Exists(importDir))
                    throw new DirectoryNotFoundException(string.Format("Attempted to access a path '{0}' that is not on the disk or not accessible.", importDir));


                var filePath = Path.Combine(importDir, System.Web.HttpContext.Current.Request.Files[0].FileName);
                using (var fs = new System.IO.FileStream(filePath, System.IO.FileMode.Create))
                {
                    System.Web.HttpContext.Current.Request.InputStream.CopyTo(fs);
                }
                return new { success = true, message = "Imported successfully" };
            }
            catch (Exception ex)
            {

                Log(ex);
                return new { success = false, message = ex.Message, ex };
            }
        }

        [HttpGet]
        [Route("download")]
        public dynamic Download(int caseReviewId) //Case
        {

            using (var db = new Models.DB.CrsContext(Connection))
            {
                try
                {
                    var exportPathDir = ExportPath;

                    if (String.IsNullOrEmpty(exportPathDir))
                    {
                        throw new Exception("Export Path does not configured in setting.");
                    }

                    if (!Directory.Exists(exportPathDir))
                        throw new DirectoryNotFoundException(string.Format("Attempted to access a path '{0}' that is not on the disk or not accessible.", exportPathDir));

                    var item = db.CaseReviews.FirstOrDefault(w => w.CaseReviewID == caseReviewId);
                    if (item == null)
                    {
                        throw new Exception(string.Format("Record (CaseReviewId={0}) does not found.", caseReviewId));
                    }
                    var file = string.Concat(item.CaseName, "_", item.CaseReviewID, ".xml");
                    var filePath = Path.Combine(exportPathDir, file);

                    if (!File.Exists(filePath))
                        throw new FileNotFoundException(string.Format("Attempted to access a path '{0}' that is not on the disk or not accessible.", filePath));


                    var dataBytes = File.ReadAllBytes(filePath);
                    var dataStream = new MemoryStream(dataBytes);

                    HttpResponseMessage httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK);
                    httpResponseMessage.Content = new StreamContent(dataStream);
                    httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
                    httpResponseMessage.Content.Headers.ContentDisposition.FileName = file;
                    httpResponseMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");

                    return httpResponseMessage;

                }
                catch (Exception ex)
                {
                    Log(ex);
                    return new { success = false, message = ex.Message, ex };
                }

            }
        }



        [HttpGet]
        [Route("GetLogs")]
        public dynamic GetLogs(string filter = "", string sort = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {

                var filters = new List<Filter>();

                var query = base.GetLogs(string.Empty);
                if (!string.IsNullOrEmpty(sort))
                {
                    var sorts = JsonConvert.DeserializeObject<List<Sorting>>(sort);
                    var s = sorts.FirstOrDefault();
                    var descDir = s.Direction.Equals("DESC", StringComparison.OrdinalIgnoreCase);
                    switch (s.Property)
                    {
                        case "Type":
                            query = descDir ? query.OrderByDescending(o => o.Type) : query.OrderBy(o => o.Type);
                            break;
                        case "Source":
                            query = descDir ? query.OrderByDescending(o => o.Source) : query.OrderBy(o => o.Source);
                            break;
                        case "Message":
                            query = descDir ? query.OrderByDescending(o => o.Message) : query.OrderBy(o => o.Message);
                            break;
                        default:
                            query = descDir ? query.OrderByDescending(o => o.Id) : query.OrderBy(o => o.Id);
                            break;

                    }
                }
                else
                {
                    query = query.OrderByDescending(o => o.Id);
                }
                var count = query.Count();
                var data = query.Skip(start).Take(limit).ToList();
                data.ForEach(d => d.Created = d.Created.ToLocalTime());

                return new { success = true, data = data, total = count };
            }

        }

        private async Task<Stream> ReadStream()
        {
            Stream stream = null;
            var provider = new MultipartMemoryStreamProvider();
            await Request.Content.ReadAsMultipartAsync(provider);
            foreach (var file in provider.Contents)
            {
                var buffer = await file.ReadAsByteArrayAsync();
                stream = new MemoryStream(buffer);
            }

            return stream;
        }
    }


}
