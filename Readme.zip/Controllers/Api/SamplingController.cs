﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using DCF.SACWIS.CRS.Web.Models;
using Newtonsoft.Json;
using static System.String;
using System.Data.Entity;
using DCF.SACWIS.CRS.Web.Util;

namespace DCF.SACWIS.CRS.Web.Controllers.Api
{
    [RoutePrefix("sampling")]
    public class SamplingController : BaseApiController
    {
        [HttpGet]
        [Route("{id}")]
        public async Task<dynamic> Get(int id)
        {
            try
            {
                using (var db = new Models.DB.CrsContext(Connection))
                {
                    db.Configuration.ProxyCreationEnabled = false;
                    //db.Configuration.LazyLoadingEnabled = false;
                    var data = await db.CR_CIP_FINAL.FindAsync(id);
                    if (data == null)
                        return new { success = false, data };


                    //Get worker information
                    var workerInfo = await db.Database.SqlQuery<WorkerInfo>("exec usp_GetWorkerInfoByCaseId @p0 ", data.Case_ID).FirstOrDefaultAsync();

                    //var jsonSerializerSettings = new JsonSerializerSettings
                    //{
                    //    PreserveReferencesHandling = PreserveReferencesHandling.Objects
                    //};
                    //var result = JsonConvert.DeserializeObject<SamplingModel>(JsonConvert.SerializeObject(data, jsonSerializerSettings));
                    var result = JsonConvert.DeserializeObject<SamplingModel>(JsonConvert.SerializeObject(data));
                    result.WorkerInfo = workerInfo;

                    var reviewPeriod = await db.CR_SampleReviewPeriod.FindAsync(data.ReviewPeriodId);
                    if (reviewPeriod != null)
                    {
                        result.PeriodUnderReview = reviewPeriod.StartDate.Value.AddYears(-1);
                    }

                    result.FRST_RMVL_DATE = result.FRST_RMVL_DATE.ToDateFormat();
                    result.RCNT_RMVL_DATE = result.RCNT_RMVL_DATE.ToDateFormat();
                    result.LST_DSCHRG_DATE = result.LST_DSCHRG_DATE.ToDateFormat();
                    result.CRRNT_PLCMNT_STRT_DT = result.CRRNT_PLCMNT_STRT_DT.ToDateFormat();
                    result.MOTHER_TPR_DT = result.MOTHER_TPR_DT.ToDateFormat();
                    result.FATHER_TPR_DT = result.FATHER_TPR_DT.ToDateFormat();
                    result.DISCHARGE_DT = result.DISCHARGE_DT.ToDateFormat();

                    //result.Reviewers = GetReviewers(result.CaseReviewRootID);

                    var reviewerIds = GetReviewers(result.CaseReviewRootID);

                    var query = db.CR_Security_User.AsQueryable().Where(u => reviewerIds.Contains(u.UserID));
                    var userData = query.Select(e => new
                    {
                        e.FirstName,
                        e.LastName
                    }).ToList();

                    List<string> reviewers = new List<string>();
                    userData.ForEach(u => reviewers.Add($"{u.FirstName} {u.LastName}"));

                    result.Reviewers = Join(", ", reviewers);
                    return new { success = true, data = result };
                }
            }
            catch (Exception ex)
            {
                Log(ex);
                return new { success = false, message = ex.Message, ex };
            }
        }

        [HttpGet]
        [Route("GetSampling")]
        public async Task<dynamic> GetSampling(string filter = "", int start = 0, int limit = 50)
        {
            //return new List<Models.DB.CR_CIP_FINAL>();
            //string ffy = string.Empty;
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var samplingFilter = new SamplingFilterModel();
                IQueryable<Models.DB.CR_CIP_FINAL> query = db.CR_CIP_FINAL.AsQueryable();

                if (!IsNullOrEmpty(filter))
                {
                    //samplingFilter = JsonConvert.DeserializeObject<SamplingFilterModel>(filter);
                    List<Filter> f = JsonConvert.DeserializeObject<List<Filter>>(filter);
                    if (!IsNullOrEmpty(f.FirstOrDefault().Value) || f.FirstOrDefault().Value != null)
                    {
                        samplingFilter = JsonConvert.DeserializeObject<SamplingFilterModel>(f.FirstOrDefault().Value);
                    }
                }

                if (samplingFilter.ReviewPeriodId.HasValue && samplingFilter.ReviewPeriodId.Value > 0)
                {
                    query = query.Where(w => w.ReviewPeriodId == samplingFilter.ReviewPeriodId.Value);
                }

                if (samplingFilter.ReviewStartMonth.HasValue)
                {
                    query = query.Where(w => w.ReviewMonth >= samplingFilter.ReviewStartMonth.Value);
                }

                if (samplingFilter.ReviewEndMonth.HasValue)
                {
                    query = query.Where(w => w.ReviewMonth <= samplingFilter.ReviewEndMonth.Value);
                }

                if (!IsNullOrEmpty(samplingFilter.Region))
                {
                    if (int.TryParse(samplingFilter.Region, out int regionId))
                    {
                        query = query.Where(w => w.Region_Id == regionId);
                    }
                }

                if (samplingFilter.Office.HasValue && samplingFilter.Office.Value > 0)
                {
                    query = query.Where(w => w.Office_Id == samplingFilter.Office.Value);
                }

                if (!IsNullOrEmpty(samplingFilter.CaseType))
                {
                    query = query.Where(w => w.Case_Type == samplingFilter.CaseType);
                }

                if (!IsNullOrEmpty(samplingFilter.SampleType))
                {
                    query = query.Where(w => w.SampleType == samplingFilter.SampleType);
                }

                if (samplingFilter.IsIntake.HasValue)
                {
                    var isintake = samplingFilter.IsIntake;
                    query = query.Where(w => w.IsIntake == isintake);
                }

                if (samplingFilter.IsEliminated.HasValue && samplingFilter.IsEliminated.Value == true)
                {
                    query = query.Where(w => w.IsEliminated == true);
                }

                if (samplingFilter.InitialQAUserID.HasValue)
                {
                    query = query.Where(w => w.CaseReviewRootID.HasValue &&
                    db.CaseReviews.Any(y => y.InitialQAUserID == samplingFilter.InitialQAUserID && y.CaseReviewRootID == w.CaseReviewRootID));
                }

                string tabType = IsNullOrEmpty(samplingFilter.TabType) ? "P" : samplingFilter.TabType.Trim();

                if (tabType != "S" && !IsNullOrEmpty(samplingFilter.Reviewer))
                {
                    if (int.TryParse(samplingFilter.Reviewer, out int reviewerId))
                    {
                        if (reviewerId > 0)
                        {
                            var caseIds = db.ActiveCases().Where(e => e.CR_Reviewer.Any(r => r.UserID.HasValue && r.UserID.Value == reviewerId)).Select(s => s.CaseReviewRootID).ToList();
                            query = query.Where(w => w.CaseReviewRootID.HasValue && caseIds.Contains(w.CaseReviewRootID.Value));
                        }
                        else
                        {
                            query = query.Where(w => !w.CaseReviewRootID.HasValue);
                        }
                    }
                }

                if (tabType == "P")
                {
                    //query = query.Where(w => (w.SampleType == tabType || w.IsPrimary == true) && (!w.IsEliminated.HasValue || w.IsEliminated.Value == false));
                    query = query.Where(w => w.IsPrimary == true && w.IsEliminated.Value == false);
                }
                else if (tabType == "S")
                {
                    query = query.Where(w => w.SampleType == tabType && (!w.IsEliminated.HasValue || w.IsEliminated.Value == false));
                }
                else if (tabType == "E")
                {
                    query = query.Where(w => w.IsEliminated.Value == true);
                }

                /// Change sort order because originally sampling generation directly loop  office_IDs, so the sort by ID and sort by Office_id will have same result; 
                /// but now it randomly chooses offices
                /// 

                query = query.OrderBy(o => o.Office_Id).ThenBy(o=>o.ID);
                var count = query.Count();
                //var data = query.Skip(start).Take(limit).ToList();

                var data = await query.Skip(start).Take(limit)
                    .Select(e => new SampleModelDashboard
                    {
                        ID = e.ID,
                        FFY = e.FFY,
                        Office_Name = e.Office_Name,
                        Region_Name = e.Region_Name,
                        Case_Type = e.Case_Type,
                        Case_ID = e.Case_ID,
                        Case_Name = e.Case_Name,
                        Case_Status = e.Case_Status,
                        Primary_Language = e.Primary_Language,
                        Home_Town = e.Home_Town,
                        Legal_Status = e.Legal_Status,
                        ChildName = e.ChildName,
                        Child_DOB = e.Child_DOB,
                        AGE_RPT_DT = e.AGE_RPT_DT,
                        SampleType = e.SampleType,
                        ReviewMonth = e.ReviewMonth,
                        IsPrimary = e.IsPrimary,
                        IsEliminated = e.IsEliminated,
                        TS_Eliminated = e.TS_Eliminated,
                        CaseReviewRootID = e.CaseReviewRootID,
                        IsIntake = e.IsIntake,
                        CaseStatusCode = e.CaseReviewRootID.HasValue ? db.CaseReviews.OrderByDescending(o => o.CaseReviewID).Where(w => w.CaseReviewRootID == e.CaseReviewRootID).Select(e1 => e1.CaseStatusCode).FirstOrDefault() : null,
                        InitialQAUserID = e.CaseReviewRootID.HasValue ? db.CaseReviews.OrderByDescending(o => o.CaseReviewID).Where(w => w.CaseReviewRootID == e.CaseReviewRootID).Select(e1 => e1.InitialQAUserID).FirstOrDefault() : null,
                    }).ToListAsync();
                data.ForEach(e => e.Reviewers = GetReviewers(e.CaseReviewRootID));
                return new { success = true, data, total = count };
            }
        }

        private List<int> GetReviewers(int? caseReviewRootId)
        {
            if (caseReviewRootId.HasValue && caseReviewRootId.Value > 0)
            {
                using (var db = new Models.DB.CrsContext(Connection))
                {
                    var mostRecentCase = db.CaseReviews.Where(e => e.CaseReviewRootID == caseReviewRootId.Value).OrderByDescending(e => e.CaseReviewID).FirstOrDefault();
                    return mostRecentCase.CR_Reviewer.Where(w => w.UserID.HasValue).Select(r => r.UserID.Value).ToList();
                }
            }
            return new List<int>();
        }

        [HttpGet]
        [Route("SampleDashboardWidget")]
        public async Task<dynamic> SampleDashboardWidget(int? reviewPeriodId)
        {
            try
            {
                using (var db = new Models.DB.CrsContext(Connection))
                {
                    IQueryable<Models.DB.CR_CIP_FINAL> query = db.CR_CIP_FINAL.AsQueryable();

                    if (reviewPeriodId.HasValue && reviewPeriodId.Value > 0)
                    {
                        query = query.Where(w => w.ReviewPeriodId == reviewPeriodId.Value);
                    }

                    var widget = new
                    {
                        //primay = query.Count(w => w.SampleType == "P"),
                        primay = await query.CountAsync(w => w.IsPrimary == true && w.IsEliminated == false),
                        secondary = await query.CountAsync(w => w.SampleType == "S" && w.IsEliminated == false),
                        eliminated = await query.CountAsync(w => w.IsEliminated == true),
                        universe = await query.CountAsync()
                    };

                    return new { success = true, data = widget };
                }
            }
            catch (Exception ex)
            {
                Log(ex);
                return new { success = false, message = ex.Message, ex };
            }
        }

        [HttpPost]
        [Route("GenerateSamplingforReviewPeriod")]
        public async Task<dynamic> GenerateSamplingforReviewPeriod(ReviewPeriod reviewPeriod, int userID)
        {
            string logMsg = string.Empty;
            try
            {
                if (reviewPeriod == null)
                    return new { success = false, message = "Review Period can not be blank" };

                if (reviewPeriod.StartDate >= DateTime.Now.AddMonths(3))
                    return new { success = false, message = "Review Period start cannot be more than 3 months ahead of current date." };

                if (reviewPeriod.StartDate <= DateTime.Now.AddYears(-3))
                    return new { success = false, message = "Review Period start cannot be less than 3 years of current date." };

                reviewPeriod.StartDate = new DateTime(reviewPeriod.StartDate.Year, reviewPeriod.StartDate.Month, 1);
                reviewPeriod.EndDate = new DateTime(reviewPeriod.EndDate.Year, reviewPeriod.EndDate.Month, 1).AddMonths(1).AddDays(-1);
                var review = new ReviewPeriod();
                using (var db = new Models.DB.CrsContext(Connection))
                {
                    int count = await db.CR_SampleReviewPeriod.CountAsync(w => (reviewPeriod.StartDate >= w.StartDate && reviewPeriod.StartDate <= w.EndDate) || (reviewPeriod.EndDate >= w.StartDate && reviewPeriod.EndDate <= w.EndDate));
                    if (count > 0)
                        return new { success = false, message = "Review Period already defined and overlapping with existing review period, please choose different review period" };

                    var msg = await IsFederalYearDataExists(reviewPeriod.StartDate, reviewPeriod.EndDate);
                    if(!IsNullOrEmpty(msg))
                    {
                        return new { success = false, message = msg };
                    }

                    logMsg = Format($"Review Start Date : {reviewPeriod.StartDate:MMM-yyyy}, Review End Date : {reviewPeriod.EndDate:MMM-yyyy} : Start Time : {DateTime.Now}");

                    Log(logMsg, Core.Enums.LogEnum.INFO);

                    await db.Database.ExecuteSqlCommandAsync("usp_GenerateAutomatedSampling @p0, @p1, @p2", reviewPeriod.StartDate, reviewPeriod.EndDate, userID);

                    logMsg = Format($"Review Start Date : {reviewPeriod.StartDate:MMM-yyyy}, Review End Date : {reviewPeriod.EndDate:MMM-yyyy} : Finished Time : {DateTime.Now}");
                    Log(logMsg, Core.Enums.LogEnum.INFO);

                    var newItem = await db.CR_SampleReviewPeriod.Where(w => w.ID_CR == userID).OrderByDescending(o => o.ID).FirstOrDefaultAsync();

                    review.Id = newItem.ID;
                    review.Period = Format("{0:MMM-yyyy} to {1:MMM-yyyy}", newItem.StartDate.Value, newItem.EndDate.Value);
                    review.StartDate = newItem.StartDate.Value;
                    review.EndDate = newItem.EndDate.Value;
                }
                return new { success = true, review, message = "Review Period successfully generated." };
            }
            catch (Exception ex)
            {
                logMsg = Format($"Error in generating the sample for Review Start Date : {reviewPeriod.StartDate:MMM-yyyy}, Review End Date : {reviewPeriod.EndDate:MMM-yyyy} : Time : {DateTime.Now}");
                Log(logMsg, Core.Enums.LogEnum.ERROR);
                Log(ex);
                return new { success = false, message = ex.Message };
            }

        }

        private async Task<string> IsFederalYearDataExists(DateTime reviewStateDt, DateTime reviewEndDt)
        {
            var tempDate = reviewStateDt;
            int recordCount = 0;
            List<string> federalYears = new List<string>();
            List<int> partAmonths = new List<int>() { 10, 11, 12, 1, 2, 3 };
            while (tempDate <= reviewEndDt)
            {
                var federalDt = tempDate.AddMonths(-12);
                if (partAmonths.Contains(federalDt.Month))
                {
                    int year = federalDt.Month <= 4 ? federalDt.Year : federalDt.Year + 1;
                    if (!federalYears.Contains($"{year}A"))
                        federalYears.Add($"{year}A");
                }
                else
                {
                    if (!federalYears.Contains($"{ federalDt.Year }B"))
                        federalYears.Add($"{ federalDt.Year }B");
                }

                tempDate = tempDate.AddMonths(1);
            }

            foreach (var fedYear in federalYears)
            {
                using (var db = new Models.DB.CrsContext(Connection))
                {
                    recordCount = await db.CR_CIP_UNIVERSE.CountAsync(c => c.FFY == fedYear);
                    if (recordCount <= 0)
                    {
                        return $"There is no record exists for federal period {fedYear}. Please contact administrator, if you are looking automated sampling for this federal period.";
                    }
                }
            }

            return Empty;
        }
    }
}
