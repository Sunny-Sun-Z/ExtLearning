﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using DCF.SACWIS.Core.Entities.Entities.CRS;
using DCF.SACWIS.CRS.BLL;
using ENT.BLL.Helpers;
using ENT.Entities.BaseCode;
using Newtonsoft.Json;
using ENT.Entities.Visitor;
using DCF.SACWIS.Core.BLL.Visitor;
using DCF.SACWIS.CRS.Web.Models;
using DCF.SACWIS.CRS.Web.Util;
using DCF.SACWIS.CRS.Web.Services;
using DCF.SACWIS.CRS.Web.Core;
using DCF.SACWIS.CRS.Web.Core.Constants;
using DCF.SACWIS.CRS.Web.Core.Enums;
using System.Text;
using System.Data.Entity;
using System.Threading.Tasks;
using static System.String;

namespace DCF.SACWIS.CRS.Web.Controllers.Api
{
    [RoutePrefix("case")]
    public class CaseController : BaseApiController
    {

        [HttpGet]
        [Route("GetLookups")]
        public dynamic GetLookups()
        {
            try
            {

                var formsBll = new CRS_FormsBLL();

                var data = formsBll.GetCaseReviewLookup();

                return new { success = true, data = data };
            }
            catch (Exception ex)
            {
                Log(ex);
                return new { success = false, message = ex.Message, ex };
            }
        }

        #region Dashboard

        //[HttpGet]
        //[Route("DashboardData")]
        //public dynamic DashboardData(string filter, string sort = "", int start = 0, int limit = 20, int userID = 0)
        //{
        //    try
        //    {
        //        CaseReviewDashboardSearch crDs = null;

        //        List<Filter> f = JsonConvert.DeserializeObject<List<Filter>>(filter);
        //        if (!string.IsNullOrEmpty(f.FirstOrDefault().Value) || f.FirstOrDefault().Value != null)
        //        {
        //            crDs = JsonConvert.DeserializeObject<CaseReviewDashboardSearch>(f.FirstOrDefault().Value);
        //        }
        //        if (crDs == null)
        //            crDs = new CaseReviewDashboardSearch { MeetingID = "", CaseID = "", CaseName = "" };
        //        crDs.CaseID = string.IsNullOrEmpty(crDs.CaseID) ? string.Empty : crDs.CaseID;
        //        crDs.MeetingID = string.IsNullOrEmpty(crDs.MeetingID) ? string.Empty : crDs.MeetingID;
        //        crDs.CaseName = string.IsNullOrEmpty(crDs.CaseName) ? string.Empty : crDs.CaseName;

        //        var formsBll = new CRS_FormsBLL();

        //        var data = formsBll.GetReviewDashboardSearch(crDs);

        //        if (!string.IsNullOrEmpty(sort))
        //        {
        //            var sorts = JsonConvert.DeserializeObject<List<Sorting>>(sort);
        //            var s = sorts.FirstOrDefault();
        //            var descDir = s.Direction.Equals("DESC", StringComparison.OrdinalIgnoreCase);
        //            switch (s.Property.ToLower())
        //            {
        //                case "caseid":
        //                    data = descDir ? data.OrderByDescending(o => o.CaseID).ToList() : data.OrderBy(o => o.CaseID).ToList();
        //                    break;
        //                case "meetingid":
        //                    data = descDir ? data.OrderByDescending(o => o.MeetingID).ToList() : data.OrderBy(o => o.MeetingID).ToList();
        //                    break;
        //                case "reviewtypeid":
        //                    data = descDir ? data.OrderByDescending(o => o.ReviewTypeID).ToList() : data.OrderBy(o => o.ReviewTypeID).ToList();
        //                    break;
        //                case "reviewsubtypeid":
        //                    data = descDir ? data.OrderByDescending(o => o.ReviewSubTypeID).ToList() : data.OrderBy(o => o.ReviewSubTypeID).ToList();
        //                    break;
        //                case "casename":
        //                    data = descDir ? data.OrderByDescending(o => o.CaseName).ToList() : data.OrderBy(o => o.CaseName).ToList();
        //                    break;
        //                case "casestatuscode":
        //                    data = descDir ? data.OrderByDescending(o => o.CaseStatusCode).ToList() : data.OrderBy(o => o.CaseStatusCode).ToList();
        //                    break;
        //                case "reviewstartdate":
        //                    data = descDir ? data.OrderByDescending(o => o.ReviewStartDate).ToList() : data.OrderBy(o => o.ReviewStartDate).ToList();
        //                    break;
        //                case "reviewcompleted":
        //                    data = descDir ? data.OrderByDescending(o => o.ReviewCompleted).ToList() : data.OrderBy(o => o.ReviewCompleted).ToList();
        //                    break;
        //                case "sitecode":
        //                    data = descDir ? data.OrderByDescending(o => o.SiteCode).ToList() : data.OrderBy(o => o.SiteCode).ToList();
        //                    break;
        //            }
        //        }
        //        else
        //        {
        //            data = data.OrderByDescending(o => o.CaseReviewID).ToList();
        //        }
        //        var count = data.Count();

        //        data = data.Skip(start).Take(limit).ToList();
        //        return new { success = true, data = data, total = count };
        //    }
        //    catch (Exception ex)
        //    {
        //        Log(ex);
        //        return new { success = false, message = ex.Message, ex };
        //    }
        //}

        //[HttpGet]
        //[Route("DashboardWidget")]
        //public dynamic DashboardWidget(string filter = "")
        //{
        //    try
        //    {
        //        CaseReviewDashboardSearch crDs = null;
        //        if (!string.IsNullOrEmpty(filter))
        //        {
        //            List<Filter> f = JsonConvert.DeserializeObject<List<Filter>>(filter);
        //            if (!string.IsNullOrEmpty(f.FirstOrDefault().Value) || f.FirstOrDefault().Value != null)
        //            {
        //                crDs = JsonConvert.DeserializeObject<CaseReviewDashboardSearch>(f.FirstOrDefault().Value);
        //            }
        //        }
        //        if (crDs == null)
        //            crDs = new CaseReviewDashboardSearch { MeetingID = "", CaseID = "", CaseName = "" };
        //        crDs.CaseID = string.IsNullOrEmpty(crDs.CaseID) ? string.Empty : crDs.CaseID;
        //        crDs.MeetingID = string.IsNullOrEmpty(crDs.MeetingID) ? string.Empty : crDs.MeetingID;
        //        crDs.CaseName = string.IsNullOrEmpty(crDs.CaseName) ? string.Empty : crDs.CaseName;

        //        var formsBll = new CRS_FormsBLL();

        //        var data = formsBll.GetReviewDashboardSearch(crDs);
        //        var widget = new DashboardWidget
        //        {
        //            dataEntryComplete = data.Count(w => w.CaseStatusCode == 1),
        //            inProgress = data.Count(w => w.CaseStatusCode == 2),
        //            notStarted = data.Count(w => w.CaseStatusCode == 3),
        //            qaInProgress = data.Count(w => w.CaseStatusCode == 4),
        //            finalized = data.Count(w => w.CaseStatusCode == 5),
        //            eliminated = data.Count(w => w.CaseStatusCode == 6),
        //            approved = data.Count(w => w.CaseStatusCode == 7),
        //            eliminatedPendingApproval = data.Count(w => w.CaseStatusCode == 8),

        //        };
        //        return new { success = true, data = widget };
        //    }
        //    catch (Exception ex)
        //    {
        //        Log(ex);
        //        return new { success = false, message = ex.Message, ex };
        //    }
        //}


        [HttpGet]
        [Route("DashboardDataNew")]
        public dynamic DashboardDataNew(string filter = "", string sort = "", int start = 0, int limit = 20, int userID = 0)
        {
            try
            {

                var data = GetDashboardRecords(filter);

                if (!string.IsNullOrEmpty(sort))
                {
                    var sorts = JsonConvert.DeserializeObject<List<Sorting>>(sort);
                    var s = sorts.FirstOrDefault();
                    var descDir = s.Direction.Equals("DESC", StringComparison.OrdinalIgnoreCase);
                    switch (s.Property.ToLower())
                    {
                        case "caseid":
                            data = descDir ? data.OrderByDescending(o => o.CaseID).ToList() : data.OrderBy(o => o.CaseID).ToList();
                            break;
                        case "meetingid":
                            data = descDir ? data.OrderByDescending(o => o.MeetingID).ToList() : data.OrderBy(o => o.MeetingID).ToList();
                            break;
                        case "reviewtypeid":
                            data = descDir ? data.OrderByDescending(o => o.ReviewTypeID).ToList() : data.OrderBy(o => o.ReviewTypeID).ToList();
                            break;
                        case "reviewsubtypeid":
                            data = descDir ? data.OrderByDescending(o => o.ReviewSubTypeID).ToList() : data.OrderBy(o => o.ReviewSubTypeID).ToList();
                            break;
                        case "casename":
                            data = descDir ? data.OrderByDescending(o => o.CaseName).ToList() : data.OrderBy(o => o.CaseName).ToList();
                            break;
                        case "casestatuscode":
                            data = descDir ? data.OrderByDescending(o => o.CaseStatusCode).ToList() : data.OrderBy(o => o.CaseStatusCode).ToList();
                            break;
                        case "reviewstartdate":
                            data = descDir ? data.OrderByDescending(o => o.ReviewStartDate).ToList() : data.OrderBy(o => o.ReviewStartDate).ToList();
                            break;
                        case "reviewcompleted":
                            data = descDir ? data.OrderByDescending(o => o.ReviewCompleted).ToList() : data.OrderBy(o => o.ReviewCompleted).ToList();
                            break;
                        case "sitecode":
                            data = descDir ? data.OrderByDescending(o => o.SiteCode).ToList() : data.OrderBy(o => o.SiteCode).ToList();
                            break;
                    }
                }
                else
                {
                    data = data.OrderByDescending(o => o.CaseReviewID).ToList();
                }
                var count = data.Count();

                data = data.Skip(start).Take(limit).ToList();
                return new { success = true, data = data, total = count };

            }
            catch (Exception ex)
            {
                Log(ex);
                return new { success = false, message = ex.Message, ex };
            }
        }
        [HttpGet]
        [Route("DashboardWidgetNew")]
        public dynamic DashboardWidgetNew(string filter = "")
        {
            try
            {
                var data = GetDashboardRecords(filter);
                var widget = new DashboardWidget
                {
                    dataEntryComplete = data.Count(w => w.CaseStatusCode == 1),
                    inProgress = data.Count(w => w.CaseStatusCode == 2),
                    notStarted = data.Count(w => w.CaseStatusCode == 3),
                    qaInProgress = data.Count(w => w.CaseStatusCode == 4),
                    finalized = data.Count(w => w.CaseStatusCode == 5),
                    eliminated = data.Count(w => w.CaseStatusCode == 6),
                    approved = data.Count(w => w.CaseStatusCode == 7),
                    eliminatedPendingApproval = data.Count(w => w.CaseStatusCode == 8),

                };
                return new { success = true, data = widget };
            }
            catch (Exception ex)
            {
                Log(ex);
                return new { success = false, message = ex.Message, ex };
            }
        }

        [HttpGet]
        [Route("GetUserSearches")]
        public dynamic GetUserSearches(int? id=0)
        {
            try
            {
                if (id == 0 || id==null)
                    id = UserId;
                using (var db = new Models.DB.CrsContext(Connection))
                {
                    var data = db.UserSearches
                        .OrderByDescending(o => o.Created)
                        .Where(w => (w.Enabled == null || w.Enabled == true) && w.UserId == id && w.Type == 1)
                        .Select(e => new SearchModel
                        {
                            Created = e.Created,
                            Data = e.Data,
                            Id = e.Id,
                            Name = e.Name,
                            Type = e.Type,
                            UserId = e.UserId

                        }).ToList();
                    var count = data.Count;
                    data = data.Skip(0).Take(10).ToList();

                    return new { success = true, data = data, total = count };
                }
            }
            catch (Exception ex)
            {
                Log(ex);
                return new { success = false, message = ex.Message, ex };
            }
        }
        [HttpPost]
        [Route("SaveUserSearch")]
        public dynamic SaveUserSearch(SearchModel item)
        {
            try
            {
                using (var db = new Models.DB.CrsContext(Connection))
                {
                    db.UserSearches.Add(new Models.DB.UserSearch
                    {
                        UserId = UserId ?? item.UserId,
                        Name = item.Name,
                        Data = item.Data,
                        Enabled = true,
                        Type = 1,
                        Created = DateTime.UtcNow
                    });
                    db.SaveChanges();
                    return new { success = true, data = item, message = "Search saved successfulyy" };
                }
            }
            catch (Exception ex)
            {
                Log(ex);
                return new { success = false, message = ex.Message, ex };
            }
        }
        [HttpGet]
        [Route("ClearUserSearches")]
        public dynamic ClearUserSearches()
        {
            try
            {
                using (var db = new Models.DB.CrsContext(Connection))
                {
                    db.UserSearches.RemoveRange(db.UserSearches.Select(e => e));
                    db.SaveChanges();
                    return new { success = true, message = "Clear all saved searches successfulyy" };
                }
            }
            catch (Exception ex)
            {
                Log(ex);
                return new { success = false, message = ex.Message, ex };
            }
        }
        #endregion

        #region Review

        [System.Web.Http.HttpGet]
        [Route("GetData")]
        public dynamic GetData(int caseReviewRootId, int? caseReviewId, int userID)
        {
            try
            {
                var formsBll = new CRS_FormsBLL();
                var data = formsBll.GetCaseReviewData(new CaseReview() { CaseReviewRootID = caseReviewRootId, CaseReviewID = caseReviewId }, true);

                return new { success = true, data = data };

            }
            catch (Exception ex)
            {
                Log(ex);
                return new { success = false, message = ex.Message, ex };
            }
        }

        [HttpPost]
        [Route("CreateCase")]
        public async Task<dynamic> CreateCase(CaseReview caseReview, string editedItems, int userID = 0)
        {
            try
            {
                caseReview.ReviewTypeID = (int)ReviewTypeEnum.CFSR;

                var modifiedItems = editedItems.Split(',').ToList().Distinct().ToList();
                dynamic ruleValidation = null;
                if (RuleApply)
                {
                    var rules = GetRules();
                    var model = caseReview.ToEntityModel();
                    RuleBuilder rb = new RuleBuilder(modifiedItems, rules, model);
                    rb.Build();
                    rb.Process();
                    if (rb.IsFailed)
                    {
                        var msg = "Data has been saved with below failed business rules.";
                        if (rb.HasBusinessRequired)
                        {
                            msg = "Data does not saved due to some mandatory business rules required.";
                        }
                        ruleValidation = new { ruleApplied = true, message = msg, data = rb.FailedItems, required = rb.HasBusinessRequired };
                    }
                    if (rb.HasBusinessRequired)
                    {
                        return new { success = true, rule = ruleValidation };
                    }
                }


                using (var db = new Models.DB.CrsContext(Connection))
                {
                    var item = db.CaseReviews.FirstOrDefault(w => w.CaseID == caseReview.CaseID && w.ReviewSubTypeID==caseReview.ReviewSubTypeID && w.ReviewStartDate==caseReview.ReviewStartDate && w.ReviewCompleted ==caseReview.ReviewCompleted
                        && w.IsIRR == caseReview.IsIRR
                        ); // need to check IsIRR
                    if (item != null)
                    {
                        Log("Case has duplicate Case ID within the same PUR and with the same review type.",LogEnum.WARNING);
                        return new { success = false, message = "Case has duplicate Case ID within the same PUR and with the same review type." };

                    }
                }

                var visitor = new DataStateVisitorCRS();
                var formsBll = new CRS_FormsBLL();
                // this is where you would save the graph to the database
                //throw new Exception("Case has duplicate Case ID within the same PUR and with the same review type.");
                caseReview.DataState = DataState.Added;
                MarkChildAsAdded(caseReview, userID);
                caseReview.Accept(visitor);

                //UpdateDemographicIDinSafetyReport(caseReview);
                //UpdateParticipantIDinItemParticipant(caseReview);
                //caseReview.DataState = DataState.Modified;
                //caseReview.Accept(visitor);
                if (caseReview.SampleReviewId > 0)
                {
                    using (var db = new Models.DB.CrsContext(Connection))
                    {
                        var data = await db.CR_CIP_FINAL.FindAsync(caseReview.SampleReviewId);
                        if (data != null)
                        {
                            data.CaseReviewRootID = caseReview.CaseReviewRootID;
                            await db.SaveChangesAsync();
                        }
                    }
                }

                CaseCreatedNotification(caseReview);
                return new { success = true, rule = ruleValidation, data = new { CaseReviewRootID = caseReview.CaseReviewRootID, CaseReviewID = caseReview.CaseReviewID } };
            }
            catch (Exception ex)
            {
                Log(ex);
                return new { success = false, message = ex.Message ,ex};
            }
        }
        [HttpGet]
        [Route("DeleteData")]
        public dynamic DeleteData(int caseReviewRootID)
        {
            var formsBll = new CRS_FormsBLL();
            var visitor = new DataStateVisitorCRS();
            var caseReviewList = formsBll.GetCaseReviewDataAll(new CaseReview() { CaseReviewRootID = caseReviewRootID });

            foreach (var cr in caseReviewList)
            {
                cr.DataState = DataState.Deleted;
                cr.Accept(visitor);
            }
            return new { success = true };
        }
        //private int userID = 153;


        [HttpPost]
        [Route("SaveData")]
        public dynamic SaveData(CaseReview caseReview, string editedItems, int userID = 0)
        {
            try
            {
                var modifiedItems = editedItems.Split(',').ToList().Distinct().ToList();
                dynamic ruleValidation = null;
                if (RuleApply)
                {
                    var rules = GetRules();
                    var model = caseReview.ToEntityModel();
                    RuleBuilder rb = new RuleBuilder(modifiedItems, rules, model);
                    rb.Build();
                    rb.Process();
                    if (rb.IsFailed)
                    {
                        var msg = "Data has been saved with below failed business rules.";
                        if (rb.HasBusinessRequired)
                        {
                            msg = "Data does not saved due to some mandatory business rules required.";
                        }
                        ruleValidation = new { ruleApplied = true, message = msg, data = rb.FailedItems, required = rb.HasBusinessRequired };
                    }
                    if (rb.HasBusinessRequired)
                    {
                        return new { success = true, rule = ruleValidation };
                    }
                }
                int? prevReviewId = caseReview.CaseReviewID;

                var visitor = new DataStateVisitorCRS();
                // this is where you would save the graph to the database

                //caseReviewTop.CaseReview[0].DataState = DataState.Added;
                MarkChildAsAdded(caseReview, userID);
                var formsBll = new CRS_FormsBLL();
                caseReview.Accept(visitor);

                UpdateDemographicIDinSafetyReport(caseReview);
                UpdateParticipantIDinItemParticipant(caseReview);

                caseReview.DataState = DataState.Modified;
                caseReview.Accept(visitor);

                StatusUpdateNotification(caseReview, prevReviewId);

                var reasonCode = caseReview.EliminationReasonCode;
                var reasonExplained = caseReview.EliminationReasonExplained;


                //CR_CIP_Final related Eliminated case
                if (reasonCode.HasValue && !IsNullOrEmpty(reasonExplained)
                    && !((reasonCode >= 5 && reasonCode != 6 && IsNullOrEmpty(reasonExplained))))
                {
                    ProcessSamplingDataAfterEliminated(caseReview, userID);
                }

                return new { success = true, rule = ruleValidation, data = new { CaseReviewRootID = caseReview.CaseReviewRootID, CaseReviewID = caseReview.CaseReviewID } };

                // return new { success = true, data = caseReview };
            }
            catch (Exception ex)
            {
                Log(ex);
                return new { success = false, message = ex.Message, ex };
            }
        }


        protected void ProcessSamplingDataAfterEliminated(CaseReview caseReview, int userID = 0)
        {

            using (var db = new Models.DB.CrsContext(Connection))
            {
                /// set IsEliminated for the eliminated sampling
                /// 
                var rootID = caseReview.CaseReviewRootID;
                var eleminatedSampling = db.CR_CIP_FINAL.FirstOrDefault(x => x.CaseReviewRootID == rootID);
                if (eleminatedSampling != null)
                {
                 
                    /// pick up the top secondary order by office_id and then ID,  and set it to Primary
                    /// 
                    var officeid = eleminatedSampling.Office_Id;
                    var caseType = eleminatedSampling.Case_Type;
                    var ffy = eleminatedSampling.FFY;
                    var isIntake = eleminatedSampling.IsIntake;
                    var case_id = caseReview.CaseID;
                    var replacementSampling = db.CR_CIP_FINAL
                        .Where(x => x.Office_Id == officeid &&
                        x.Case_Type == caseType &&
                        x.FFY == ffy && x.SampleType == "S"
                        && x.IsIntake == isIntake
                        && x.IsPrimary != true
                        )
                        .OrderBy(x => x.Office_Id)
                        .ThenBy(x => x.ID)
                        .FirstOrDefault();

                    if (replacementSampling != null)
                       
                    {
                        eleminatedSampling.IsEliminated = true;
                        eleminatedSampling.TS_Eliminated = DateTime.UtcNow;

                        replacementSampling.IsPrimary = true;
                        replacementSampling.TS_UP = DateTime.UtcNow;
                        replacementSampling.ID_UP = userID;
                        db.SaveChanges();
                    }
                  
                }
            }

        }

        [System.Web.Http.HttpGet]
        [Route("GetPreview")]
        public dynamic GetPreview(int caseReviewRootId, int caseReviewId, int userID)
        {
            try
            {
                var formsBll = new CRS_FormsBLL();
                var data = formsBll.GetCaseReviewData(new CaseReview() { CaseReviewID = caseReviewId }, true);

                return new { success = true, data = data.ToEntityModel() };

            }
            catch (Exception ex)
            {
                Log(ex);
                return new { success = false, message = ex.Message, ex };
            }
        }

        [System.Web.Http.HttpGet]
        [Route("GetComparePreview")]
        public dynamic GetComparePreview(int caseReviewRootId, int caseReviewId, int caseId, int userID)
        {
            try
            {
                var formsBll = new CRS_FormsBLL();
                var lookup = formsBll.GetCaseReviewLookup();
                var irrData = formsBll.GetCaseReviewData(new CaseReview() { CaseReviewID = caseReviewId }, true);
                var crId = 0;

                using (var db = new Models.DB.CrsContext(Connection))
                {
                    var cr = db.ActiveCaseByCaseId(irrData.CaseID);
                    if (cr != null)
                        crId = cr.CaseReviewID;
                }
                var caseData = formsBll.GetCaseReviewData(new CaseReview() { CaseReviewID = crId }, true);

                return new { success = true, data = new { Case = caseData.ToEntityModel(lookup), Irr = irrData.ToEntityModel(lookup) } };

            }
            catch (Exception ex)
            {
                Log(ex);
                return new { success = false, message = ex.Message, ex };
            }
        }
        [System.Web.Http.HttpGet]
        [Route("Compare2Cases")]
        public dynamic Compare2Cases(int caseReviewId1, int caseReviewId2)
        {
            try
            {
                var formsBll = new CRS_FormsBLL();
                var lookup = formsBll.GetCaseReviewLookup();
                var case1 = formsBll.GetCaseReviewData(new CaseReview() { CaseReviewID = caseReviewId1 }, true);

                var case2 = formsBll.GetCaseReviewData(new CaseReview() { CaseReviewID = caseReviewId2 }, true);

                return new { success = true, data = new { Case = case1.ToEntityModel(lookup), Irr = case2.ToEntityModel(lookup) } };

            }
            catch (Exception ex)
            {
                Log(ex);
                return new { success = false, message = ex.Message, ex };
            }
        }

        [HttpGet]
        [Route("GetCompareCases")]
        public dynamic GetCompareCases(string filter = "", string sort = "", int start = 0, int limit = 20)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var filters = new List<Filter>();
                var v = 0;
                var includeCases = new List<short> { (short)CaseStatusEnum.QaInProgress, (short)CaseStatusEnum.DataEntryComplete, (short)CaseStatusEnum.Finalized, (short)CaseStatusEnum.Approved };
                var where = db.ActiveCases().Where(w => includeCases.Contains( w.CaseStatusCode.Value) );
                if (!string.IsNullOrEmpty(filter))
                {

                    filters = JsonConvert.DeserializeObject<List<Filter>>(filter);

                    foreach (var f in filters)
                    {
                        switch (f.Property)
                        {
                            case "CaseID":
                                v = Convert.ToInt32(f.Value);
                                switch (f.Operator)
                                {
                                    case "gt":
                                        where = where.Where(w => w.CaseID > v);
                                        break;
                                    case "lt":
                                        where = where.Where(w => w.CaseID < v);
                                        break;
                                    case "like":
                                        where = where.Where(w => w.CaseID.HasValue && w.CaseID.ToString().Contains(f.Value));
                                        break;
                                    default:
                                        where = where.Where(w => w.CaseID == v);

                                        break;
                                }
                                break;
                            case "CaseName":

                                where = where.Where(w => w.CaseName.Contains(f.Value));

                                break;

                        }
                    }
                }

                var query = where.Select(e => new
                {
                    e.CaseID,
                    e.MeetingID,
                    e.CaseName,
                    e.CaseReviewID,
                    e.CaseReviewRootID,
                    e.BatchProcessedID,
                    e.FederalProcessedDate,
                    e.ReviewCompleted,
                    e.ReviewStartDate,
                    e.ReviewSubTypeID,
                    e.ReviewTypeID,
                    e.SiteCode,
                    e.CaseStatusCode,
                    UserID = e.ID_CR,
                    Reviewers = e.CR_Reviewer.Where(w => w.UserID.HasValue).Select(r => r.UserID.Value).ToList()

                });

                if (!string.IsNullOrEmpty(sort))
                {
                    var sorts = JsonConvert.DeserializeObject<List<Sorting>>(sort);
                    var s = sorts.FirstOrDefault();
                    var descDir = s.Direction.Equals("DESC", StringComparison.OrdinalIgnoreCase);
                    switch (s.Property)
                    {
                        case "CaseID":
                            query = descDir ? query.OrderByDescending(o => o.CaseID) : query.OrderBy(o => o.CaseID);
                            break;
                        default:
                            query = descDir ? query.OrderByDescending(o => o.CaseName) : query.OrderBy(o => o.CaseName);
                            break;

                    }
                }
                else
                {
                    query = query.OrderBy(o => o.CaseName);

                }
                var count = query.Count();
                var data = query.Skip(start).Take(limit).ToList();
                return new { success = true, data = data, total = count };
            }

        }


        #region  Elimination
        [HttpPost]
        [Route("SendEliminationRequestForm")]
        public dynamic SendEliminationRequestForm(EliminationRequest req)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var item = db.CR_EliminationRequest.FirstOrDefault(w => w.CaseReviewRootID == req.CaseReviewRootId);
                req.CopyTo(ref item);
                if (item.Id == 0)
                    db.CR_EliminationRequest.Add(item);
                db.SaveChanges();
                CaseEliminationRequestNotification(req);
            }
            return new { success = true, message = "Elimination request has been sent successfully" };

        }
        [HttpGet]
        [Route("GetEliminationRequestForm")]
        public dynamic GetEliminationRequestForm(int id)
        {
            // SendGeneratedEliminationList(132);
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var caseItem = db.CaseReviews.FirstOrDefault(w => w.CaseReviewID == id);
                if (caseItem != null)
                {
                    var item = db.CR_EliminationRequest.FirstOrDefault(w => w.CaseReviewRootID == caseItem.CaseReviewRootID);
                    var data = new EliminationRequest();

                    if (item != null)
                    {
                        data = data.CopyFrom(item);
                        return new { success = true, data = data };
                    }
                }

                return new { success = true, message = "Record not found" };
            }

        }
        [HttpGet]
        [Route("GenerateEliminationCriteria")]
        public dynamic GetEliminationRequestForm()
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var status = (short?)CaseStatusEnum.Finalized;
                var caseReviewList = db.CaseReviews.Where(w => w.CaseStatusCode < status).GroupBy(g => g.CaseReviewRootID)
                    .Select(m => m.Max(v => v.CaseReviewID)).ToList();

                var eliminationList = db.CR_EliminationRequest.Where(w => w.ApprovedDate != null && w.EliminatedDate != null)
                    .Select(m => m.CaseReviewRootID).ToList();


                int count1 = 0, count2 = 0;
                try
                {
                    var homeServiceCaseDuringPur = (from cr in db.CaseReviews
                                                    join fs in db.CR_FaceSheet on cr.CaseReviewID equals fs.CaseReviewID
                                                    where caseReviewList.Contains(cr.CaseReviewID)
                                                    // && !eliminationList.Contains(cr.CaseReviewRootID)
                                                    && fs.FirstCaseOpeningDate != null
                                                    && fs.CaseClosureDate != null
                                                    //   && (fs.CaseClosureDate.Value - fs.FirstCaseOpeningDate.Value).TotalDays < 45

                                                    select new
                                                    {
                                                        CaseReviewRootID = cr.CaseReviewRootID,
                                                        CaseReviewID = cr.CaseReviewID,
                                                        HomeServiceCaseOpenedDuringPUR = fs.FirstCaseOpeningDate,
                                                        HomeServiceCaseClosedDuringPUR = fs.CaseClosureDate,
                                                        CaseClosureDate = fs.CaseClosureDate.Value,
                                                        FirstCaseOpeningDate = fs.FirstCaseOpeningDate.Value
                                                    }).ToList().Where(w => (w.CaseClosureDate - w.FirstCaseOpeningDate).TotalDays < 45).Select(e => e);


                    var homeServiceCaseDuringPurData = homeServiceCaseDuringPur.ToList();
                    count1 = homeServiceCaseDuringPurData.Count;
                    foreach (var item in homeServiceCaseDuringPurData)
                    {
                        var data = db.CR_EliminationRequest.FirstOrDefault(w => w.CaseReviewRootID == item.CaseReviewRootID && w.ApprovedDate != null && w.EliminatedDate != null);
                        if (data != null)
                        {
                            data.IsHomeServiceCaseOpenDuringPUR = true;
                            data.TargetChildTurned18Date = item.HomeServiceCaseOpenedDuringPUR;
                            data.HomeServiceCaseClosedDuringPUR = item.HomeServiceCaseClosedDuringPUR;
                        }
                        else
                        {
                            db.CR_EliminationRequest.Add(new Models.DB.CR_EliminationRequest
                            {
                                IsHomeServiceCaseOpenDuringPUR = true,
                                HomeServiceCaseOpenedDuringPUR = item.HomeServiceCaseOpenedDuringPUR,
                                HomeServiceCaseClosedDuringPUR = item.HomeServiceCaseClosedDuringPUR,
                                CaseReviewID = item.CaseReviewID,
                                CaseReviewRootID = item.CaseReviewRootID,
                                IsSystemGenerated = true,
                                SystemGeneratedDate = DateTime.UtcNow
                            });
                        }
                        db.SaveChanges();
                    }

                }
                catch (Exception)
                {
                }


                try
                {
                    var targetChildTurned18 = (from cr in db.CaseReviews
                                               join fs in db.CR_FaceSheet on cr.CaseReviewID equals fs.CaseReviewID
                                               join d in db.CR_ChildDemographic on fs.FaceSheetID equals d.FaceSheetID

                                               where caseReviewList.Contains(cr.CaseReviewID)
                                                 //   && !eliminationList.Contains(cr.CaseReviewRootID)
                                                 && cr.ReviewCompleted != null
                                               && d.DateOfBirth != null
                                               && d.IsTargetChild == 1
                                               //   && d.DateOfBirth.Value.yr < cr.ReviewCompleted.Value

                                               select new
                                               {
                                                   CaseReviewRootID = cr.CaseReviewRootID,
                                                   CaseReviewID = cr.CaseReviewID,
                                                   TargetChildTurned18Date = d.DateOfBirth.Value,
                                                   ReviewCompleted = cr.ReviewCompleted.Value
                                               }).ToList().Where(w => w.TargetChildTurned18Date.AddYears(18) < w.ReviewCompleted).Select(e => e);

                    var targetChildTurned18Data = targetChildTurned18.ToList();
                    count2 = targetChildTurned18Data.Count;
                    foreach (var item in targetChildTurned18Data)
                    {
                        var data = db.CR_EliminationRequest.FirstOrDefault(w => w.CaseReviewRootID == item.CaseReviewRootID && w.ApprovedDate != null && w.EliminatedDate != null);
                        if (data != null)
                        {
                            data.IsTargetChildTurned18 = true;
                            data.TargetChildTurned18Date = item.TargetChildTurned18Date;
                        }
                        else
                        {
                            db.CR_EliminationRequest.Add(new Models.DB.CR_EliminationRequest
                            {
                                IsTargetChildTurned18 = true,
                                TargetChildTurned18Date = item.TargetChildTurned18Date,
                                CaseReviewID = item.CaseReviewID,
                                CaseReviewRootID = item.CaseReviewRootID,
                                IsSystemGenerated = true,
                                SystemGeneratedDate = DateTime.UtcNow
                            });
                        }
                        db.SaveChanges();
                    }
                }
                catch (Exception)
                {
                }


                return new { success = true, homeServiceCaseDuringPurCount = count1, targetChildTurned18 = count2 };
            }

        }

        [HttpGet]
        [Route("GetGeneratedEliminationList")]
        public dynamic GetGeneratedEliminationList(int userId)
        {
            var list = GetGeneratedEliminationRecords(userId);
            return new { success = true, data = list, total = list.Count };
        }
        [HttpGet]
        [Route("SendGeneratedEliminationList")]
        public dynamic SendGeneratedEliminationList(int userId)
        {

            var list = GetGeneratedEliminationRecords(userId);
            if (list.Any())
            {
                var sb = new StringBuilder();
                sb.Append("<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">");
                sb.Append("<tr><th>Case Name & Elimination Reason</th></tr>");
                foreach (var item in list)
                {
                    sb.AppendFormat("<tr><td class=\"content-block\"><a href=\"{0}#case/{1}/{2}\"><strong>{4} ({3})</strong></a>{5}{6}</td></tr>",
                        Request.Headers.Referrer.AbsoluteUri,
                        item.CaseReviewRootId,
                        item.CaseReviewId,
                        item.CaseId,
                        item.CaseName,
                        item.IsTargetChildTurned18 == true ? "<br/></br>The target child reached the age of majority before the period under review." : string.Empty,
                        item.IsHomeServiceCaseOpenDuringPUR == true ? "<br/></br>An in-home services case open for fewer than 45 consecutive days during the period under review." : string.Empty

                        );
                }
                sb.Append("</table>");

                var user = GetCurrentUser(userId);

                if (true) //add setting 
                {

                    var dic = new Dictionary<string, object>();
                    dic.Add("BaseUrl", Request.Headers.Referrer.AbsoluteUri);
                    dic.Add("CaseList", sb.ToString());

                    var tPath = System.Web.Hosting.HostingEnvironment.MapPath(string.Format("~/App_data/templates/{0}", TemplateNames.EliminationList));
                    var mb = new MessageBuilder(user, "System Pre-Populated Case Elimination List", tPath);
                    var messgae = mb.Build<EliminationRequest>(null);
                    messgae.AdditionalData = dic;
                    var ns = new NotificationService(Smtp, null);
                    ns.Notify(messgae);

                }

                using (var db = new Models.DB.CrsContext(Connection))
                {
                    var ids = list.Select(e => e.Id);
                    var elList = db.CR_EliminationRequest.Where(w => ids.Contains(w.Id));
                    foreach (var item in elList)
                        item.EmailSentDate = DateTime.UtcNow;
                    db.SaveChanges();
                }
            }

            return new { success = true, data = list, total = list.Count };
        }

        #endregion


        #endregion

        #region Sampling

        [HttpGet]
        [Route("GetPipReviewSample")]
        public dynamic GetPipReviewSample(string filter = "", string sort = "", int start = 0, int limit = 20)
        {
            try
            {
                List<Filter> filters = new List<Filter>();
                DateTime startDate = DateTime.MaxValue, endDate = DateTime.MaxValue;
                if (!string.IsNullOrEmpty(filter))
                {
                    filters = JsonConvert.DeserializeObject<List<Filter>>(filter);
                    if (!string.IsNullOrEmpty(filters.FirstOrDefault().Value))
                    {
                        string period = filters.FirstOrDefault().Value;
                        startDate = Convert.ToDateTime(period.Split('-')[0]);
                        endDate = Convert.ToDateTime(period.Split('-')[1]);

                    }
                }

                using (var db = new Models.DB.CrsContext(Connection))
                {
                    var data = db.GetPipReviewSample(startDate, endDate)
                         .Select(e => new PipReviewSampleModel
                         {
                             CaseId = e.CaseId,
                             Date = e.Date,
                             Id = e.Id,
                             SampleGroup = e.SampleGroup,
                             SampleType = e.SampleType,
                             IsAdditionalHS = e.IsAdditionalHS,
                             RegionId = e.RegionId,
                             Office = e.Office,
                             Month1 = e.Month1,
                             Month2 = e.Month2,
                             Month3 = e.Month3,
                             Month4 = e.Month4,
                             Month5 = e.Month5,
                             Month6 = e.Month6
                         }).ToList();

                    var count = data.Count;

                    //  data = data.Skip(start).Take(limit).ToList();

                    return new { success = true, data = data, total = count };
                }

            }
            catch (Exception ex)
            {
                Log(ex);
                return new { success = false, message = ex.Message, ex };
            }
        }


        #endregion

        #region Irr Cases

        [HttpGet]
        [Route("IrrDashboard")]
        public dynamic IrrDashboard(string filter = "", string sort = "", int start = 0, int limit = 20, int userID = 0)
        {
            try
            {

                var data = GetIrrDashboardRecords(filter);

                if (!string.IsNullOrEmpty(sort))
                {
                    var sorts = JsonConvert.DeserializeObject<List<Sorting>>(sort);
                    var s = sorts.FirstOrDefault();
                    var descDir = s.Direction.Equals("DESC", StringComparison.OrdinalIgnoreCase);
                    switch (s.Property.ToLower())
                    {
                        case "caseid":
                            data = descDir ? data.OrderByDescending(o => o.CaseID).ToList() : data.OrderBy(o => o.CaseID).ToList();
                            break;
                        case "meetingid":
                            data = descDir ? data.OrderByDescending(o => o.MeetingID).ToList() : data.OrderBy(o => o.MeetingID).ToList();
                            break;
                        case "reviewtypeid":
                            data = descDir ? data.OrderByDescending(o => o.ReviewTypeID).ToList() : data.OrderBy(o => o.ReviewTypeID).ToList();
                            break;
                        case "reviewsubtypeid":
                            data = descDir ? data.OrderByDescending(o => o.ReviewSubTypeID).ToList() : data.OrderBy(o => o.ReviewSubTypeID).ToList();
                            break;
                        case "casename":
                            data = descDir ? data.OrderByDescending(o => o.CaseName).ToList() : data.OrderBy(o => o.CaseName).ToList();
                            break;
                        case "casestatuscode":
                            data = descDir ? data.OrderByDescending(o => o.CaseStatusCode).ToList() : data.OrderBy(o => o.CaseStatusCode).ToList();
                            break;
                        case "reviewstartdate":
                            data = descDir ? data.OrderByDescending(o => o.ReviewStartDate).ToList() : data.OrderBy(o => o.ReviewStartDate).ToList();
                            break;
                        case "reviewcompleted":
                            data = descDir ? data.OrderByDescending(o => o.ReviewCompleted).ToList() : data.OrderBy(o => o.ReviewCompleted).ToList();
                            break;
                        case "sitecode":
                            data = descDir ? data.OrderByDescending(o => o.SiteCode).ToList() : data.OrderBy(o => o.SiteCode).ToList();
                            break;
                    }
                }
                else
                {
                    data = data.OrderByDescending(o => o.CaseReviewID).ToList();
                }
                var count = data.Count();

                data = data.Skip(start).Take(limit).ToList();
                return new { success = true, data = data, total = count };

            }
            catch (Exception ex)
            {
                Log(ex);
                return new { success = false, message = ex.Message, ex };
            }
        }

        [HttpGet]
        [Route("CreateIRRCase")]
        public dynamic CreateIRRCase(int caseId, int userId)
        {
            CaseReview caseReview=new CaseReview();
            try
            {
                var currentUserId=UserId;
                var formsBll = new CRS_FormsBLL();

                using (var db = new Models.DB.CrsContext(Connection))
                {
                    var hasIrrCaseReviewRecord = db.CaseReviews
                       .Where(w => w.CaseID == caseId && w.IsIRR == true)
                       .GroupBy(g => g.CaseReviewRootID)
                       .Select(m => m.Max(v => v.CaseReviewID))
                       .FirstOrDefault();

                    if (hasIrrCaseReviewRecord != 0)
                    {
                        return new { success = false, message = "Case Already Exist", data = new { CaseReviewRootID = caseReview.CaseReviewRootID, CaseReviewID = caseReview.CaseReviewID } };
                    }
                    var caseReviewId = db.CaseReviews
                        .Where(w => w.CaseID == caseId && w.IsIRR !=true)
                        .GroupBy(g => g.CaseReviewRootID)
                        .Select(m => m.Max(v => v.CaseReviewID))
                        .FirstOrDefault();

                    var cr = db.CaseReviews.FirstOrDefault(w => w.CaseReviewID == caseReviewId);
                    caseReview = formsBll.GetCaseReviewData(new CaseReview() { CaseReviewID = caseReviewId }, true);

                    caseReview.IsIRR = true;
                    caseReview.ReviewTypeID = (int)ReviewTypeEnum.IRR;

                    caseReview.IRRReviewerID = userId;
                    caseReview.CaseReviewRootID = null;
                    caseReview.CaseReviewID = null;
                    caseReview.CaseStatusCode =(short) CaseStatusEnum.NotStarted;
                    caseReview.ID_CR = currentUserId;
                    caseReview.TS_CR = DateTime.UtcNow;

                    var fs=caseReview.CR_FaceSheet_Collection[0];
                    if (fs != null)
                    {
                        foreach (var p in fs.CR_CaseParticipant_Collection.ToList())
                        {
                            p.DataState = 0;
                        }
                        foreach (var c in fs.CR_ChildDemographic_Collection.ToList())
                        {
                            c.DataState = 0;
                            foreach (var r in c.CR_ChildRace_Collection.ToList())
                            {
                                r.DataState = 0;
                            }
                        }
                        fs.DataState = 0;
                    }
                    else
                    {
                        caseReview.CR_FaceSheet_Collection = new MyObjectCollection<int?, CR_FaceSheet>();

                    }

                    caseReview.CR_CaseNote_Collection = new MyObjectCollection<int?,CR_CaseNote>();
                    caseReview.CR_MultiAnswer_Collection = new MyObjectCollection<int?,CR_MultiAnswer>();
                    caseReview.CR_Outcome_Collection = new MyObjectCollection<int?,CR_Outcome>();
                    caseReview.CR_Permanency_Collection = new MyObjectCollection<int?,CR_Permanency>();
                    caseReview.CR_Safety_Collection = new MyObjectCollection<int?,CR_Safety>();
                    caseReview.CR_WellBeing_Collection = new MyObjectCollection<int?,CR_WellBeing>();
                    foreach (var reviewer in caseReview.CR_Reviewer_Collection)
                    {
                        reviewer.DataState = DataState.Added;
                        reviewer.ID_CR = currentUserId;
                        reviewer.TS_CR = DateTime.UtcNow;
                    }
                    var visitor = new DataStateVisitorCRS();
                    caseReview.DataState = DataState.Added;
                    caseReview.Accept(visitor);

                    cr.IRRReviewerID = userId;
                    db.SaveChanges();
                }



                return new { success = true,message="Case Created successfully", data = new { CaseReviewRootID = caseReview.CaseReviewRootID, CaseReviewID = caseReview.CaseReviewID } };
            }
            catch (Exception ex)
            {
                Log(ex);
                return new { success = false, message = ex.Message, ex };
            }
        }

        #endregion

        #region Private Methods
        private void MarkChildAsAdded(dynamic obj, int userID)
        {

            if (obj.DataState != DataState.Added && obj.TS_CR != null  // For records which were saved intially
                        || obj.DataState == DataState.Added // // for records which are already marked as added from client side
                        || obj.DataState == DataState.Modified)// for records which are already marked as Modified from client side due to any business rule
            {


                obj.DataState = DataState.Added;
                obj.ID_CR = userID;
                obj.ID_UP = userID;

            }

            // looping through all the child objects for the same.
            foreach (var list in obj.Children)
            {
                foreach (var child in list)
                {
                    if (child.Children != null && child.Children.Count > 0)
                    {
                        MarkChildAsAdded(child, userID);
                    }
                    else
                    {
                        if (child.DataState != DataState.Added && child.TS_CR != null  // For records which were saved intially
                            || child.DataState == DataState.Added // // for records which are already marked as added from client side
                            || child.DataState == DataState.Modified)// for records which are already marked as Modified from client side due to any business rule
                        {


                            child.DataState = DataState.Added;
                            child.ID_CR = userID;
                            child.ID_UP = userID;

                        }

                    }
                }

            }
        }
        private void UpdateDemographicIDinSafetyReport(CaseReview caseReview)
        {

            var lstSafetyReports = new MyObjectCollection<int?, CR_SafetyReport>();
            var lstChildDemographics = new MyObjectCollection<int?, CR_ChildDemographic>();
            CR_FaceSheet crFaceSheet = new CR_FaceSheet();
            CR_Safety crSafety = new CR_Safety();


            if (caseReview.CR_FaceSheet_Collection.Count == 0)
            {
                return;
            }

            crFaceSheet = caseReview.CR_FaceSheet_Collection[0];

            if (crFaceSheet.CR_ChildDemographic_Collection.Count == 0)
            {
                return;
            }

            lstChildDemographics = crFaceSheet.CR_ChildDemographic_Collection;


            if (caseReview.CR_Safety_Collection.Count == 0)
            {
                return;
            }
            crSafety = caseReview.CR_Safety_Collection[0];

            if (crSafety.CR_SafetyReport_Collection.Count == 0)
                return;

            lstSafetyReports = crSafety.CR_SafetyReport_Collection;

            foreach (var safetyReport in lstSafetyReports)
            {
                var previousDemographicLst = lstChildDemographics.Where(i => i.ChildDemographicPreviousID == safetyReport.ChildDemographicID).ToList();
                if (previousDemographicLst.Count > 0)
                {
                    safetyReport.ChildDemographicID = previousDemographicLst[0].ChildDemographicID;
                    safetyReport.DataState = DataState.Modified;
                }
            }


        }
        private void UpdateParticipantIDinItemParticipant(CaseReview caseReview)
        {

            var lstCaseParticipants = new MyObjectCollection<int?, CR_CaseParticipant>();
            var lstCaseDemographics = new MyObjectCollection<int?, CR_ChildDemographic>();

            var crFaceSheet = new CR_FaceSheet();



            if (caseReview.CR_FaceSheet_Collection.Count == 0)
            {
                return;
            }

            crFaceSheet = caseReview.CR_FaceSheet_Collection[0];

            if (crFaceSheet.CR_CaseParticipant_Collection.Count == 0)
            {
                return;
            }

            lstCaseParticipants = crFaceSheet.CR_CaseParticipant_Collection;
            lstCaseDemographics = crFaceSheet.CR_ChildDemographic_Collection;

            if (caseReview.CR_Outcome_Collection.Count == 0)
            {
                return;
            }


            foreach (var outcome in caseReview.CR_Outcome_Collection)
            {
                foreach (var item in outcome.CR_Item_Collection)
                {
                    foreach (var itemParticipant in item.CR_ItemParticipant_Collection)
                    {
                        if (itemParticipant.CodeDescriptionID == 269 || itemParticipant.CodeDescriptionID == 270)
                        {
                            var previousParticipantIDLst =
                                lstCaseParticipants.Where(i => i.CasePreviousPreviousID == itemParticipant.ParticipantID)
                                    .ToList();
                            if (previousParticipantIDLst.Count > 0)
                            {
                                itemParticipant.ParticipantID = previousParticipantIDLst[0].CaseParticipantID;
                                itemParticipant.DataState = DataState.Modified;
                            }
                        }
                        else
                        {
                            var previousDemogrpahicIDLst =
                                lstCaseDemographics.Where(
                                    i => i.ChildDemographicPreviousID == itemParticipant.ParticipantID).ToList();

                            if (previousDemogrpahicIDLst.Any())
                            {
                                itemParticipant.ParticipantID = previousDemogrpahicIDLst[0].ChildDemographicID;
                                itemParticipant.DataState = DataState.Modified;
                            }
                        }
                    }
                }

            }


        }
        private void CaseCreatedNotification(CaseReview caseReview)
        {
            try
            {
                var user = GetCurrentUser(UserId);

                if (AllowNewCaseNotification)
                {

                    var dic = caseReview.ToDictionary();
                    dic.Add("BaseUrl", Request.Headers.Referrer.AbsoluteUri);
                    var tPath = System.Web.Hosting.HostingEnvironment.MapPath(string.Format("~/App_data/templates/{0}", TemplateNames.NewCaseNotification));
                    var mb = new MessageBuilder(user, NewCaseNotificationSubject, tPath);
                    var messgae = mb.Build<CaseReview>(caseReview);
                    messgae.AdditionalData = dic;
                    var ns = new NotificationService(Smtp, null);
                    ns.Notify(messgae);

                    if (user.IsValidPhoneServiceProvider())
                    {
                        ns.SmsNotify(user.GetPhoneNumber(), "CRS-New Case", this.NewCaseNotificationSmsMessageBody, dic, null);
                        //  ns.Notify("2245004451@tmomail.net", subject, string.Format("New case [{0}-{1}] hase been created", caseReview.CaseName, caseReview.CaseID));
                    }
                }
            }
            catch (Exception)
            {

            }
        }
        private void StatusUpdateNotification(CaseReview caseReview, int? prevCaseReviewId)
        {
            try
            {
                short? prevStatusCode;
                string oldStatus = string.Empty, newStatus = string.Empty;

                using (var db = new Models.DB.CrsContext(Connection))
                {
                    prevStatusCode = db.CaseReviews.Where(w => w.CaseReviewID == prevCaseReviewId).Select(e => e.CaseStatusCode).FirstOrDefault();
                    oldStatus = db.CR_CodeDescription.Where(w => w.GroupName == "CaseStatus" && w.GroupID == prevStatusCode).Select(e => e.DescriptionLarge).FirstOrDefault();
                    newStatus = db.CR_CodeDescription.Where(w => w.GroupName == "CaseStatus" && w.GroupID == caseReview.CaseStatusCode).Select(e => e.DescriptionLarge).FirstOrDefault();
                }

                if (AllowCaseUpdateNotification && prevStatusCode > 1 && prevStatusCode != caseReview.CaseStatusCode)
                {
                    int? userId = UserId;

                    var status = (Core.Enums.CaseStatusEnum)caseReview.CaseStatusCode;
                    switch (status)
                    {
                        case Core.Enums.CaseStatusEnum.InProgress:
                        case Core.Enums.CaseStatusEnum.DataEntryComplete:
                            userId = caseReview.CR_Reviewer_Collection.FirstOrDefault().UserID;
                            break;
                        case Core.Enums.CaseStatusEnum.QaInProgress:
                            userId = caseReview.InitialQAUserID;
                            break;
                        case Core.Enums.CaseStatusEnum.Finalized:
                            userId = caseReview.SecondQAUserID;
                            break;
                        case Core.Enums.CaseStatusEnum.Approved:
                            userId = caseReview.SecondaryOversightUserID;
                            break;
                    }
                    var dic = caseReview.ToDictionary();

                    var user = GetCurrentUser(userId);
                    dic.Add("BaseUrl", Request.Headers.Referrer.AbsoluteUri);
                    dic.Add("OldStatus", oldStatus);
                    dic.Add("NewStatus", newStatus);

                    var tPath = System.Web.Hosting.HostingEnvironment.MapPath(string.Format("~/App_data/templates/{0}", TemplateNames.CaseStatusNotification));
                    var mb = new MessageBuilder(user, CaseUpdateNotificationSubject, tPath);
                    var messgae = mb.Build<CaseReview>(caseReview);

                    messgae.AdditionalData = dic;
                    var ns = new NotificationService(Smtp, null);
                    ns.Notify(messgae);

                    if (user.IsValidPhoneServiceProvider())
                    {
                        ns.SmsNotify(user.GetPhoneNumber(), "CRS-Case Status", this.CaseUpdateNotificationSmsMessageBody, dic, null);
                    }
                }
            }
            catch (Exception)
            {

            }

        }
        private void CaseEliminationRequestNotification(EliminationRequest item)
        {
            try
            {
                //  var user = GetCurrentUser(UserId);
                var user = new UserModel { Email = FederalTeamEmail, FirstName = "Federal", LastName = "Team" };
                if (true)
                {
                    //https://stackoverflow.com/questions/658044/tick-symbol-in-html-xhtml
                    //unchecked char code=>&#9744;
                    //checked char code=>&#9745;
                    string @unchecked = "&#9744;", @checked = "&#9745;";
                    var dic = item.ToDictionaryWithNullValue();
                    var tempDic = new Dictionary<string, object>();
                    foreach (var kv in dic)
                    {
                        var val = kv.Value;
                        if (kv.Key.StartsWith("Is") && (kv.Value is Nullable<bool> || kv.Value is bool))
                        {
                            val = kv.Value.Equals(true) ? @checked : @unchecked;
                            if (kv.Key == "IsCaseMeetEliminationCriteria")
                            {
                                tempDic.Add("IsCaseNotMeetEliminationCriteria", kv.Value.Equals(false) ? @checked : @unchecked);
                            }
                        }
                        else if (kv.Value != null && (kv.Value is Nullable<DateTime> || kv.Value is DateTime))
                        {
                            val = Convert.ToDateTime(kv.Value).ToShortDateString();
                        }
                        tempDic.Add(kv.Key, val);

                    }
                    tempDic.Add("BaseUrl", Request.Headers.Referrer.AbsoluteUri);

                    dic = tempDic;

                    var tPath = System.Web.Hosting.HostingEnvironment.MapPath(string.Format("~/App_data/templates/{0}", TemplateNames.EliminationRequest));
                    var mb = new MessageBuilder(user, "CT DCF Case Elimination Request [secure]", tPath);
                    var messgae = mb.Build<EliminationRequest>(item);
                    messgae.AdditionalData = dic;
                    var ns = new NotificationService(Smtp, null);
                    ns.Notify(messgae);

                    if (user.IsValidPhoneServiceProvider())
                    {
                        //   ns.SmsNotify(user.GetPhoneNumber(), "CRS-New Case", this.NewCaseNotificationSmsMessageBody, dic, null);
                    }
                }
            }
            catch (Exception)
            {

            }
        }
        private List<EliminationRequestBase> GetGeneratedEliminationRecords(int userId)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                var status = (short?)CaseStatusEnum.Finalized;
                var caseReviewList = db.CaseReviews.Where(w => w.CaseStatusCode < status).GroupBy(g => g.CaseReviewRootID)
                    .Select(m => m.Max(v => v.CaseReviewID)).ToList();
                var lastDay = DateTime.Now.AddHours(-20);
                var list = (from cr in db.CaseReviews
                            join el in db.CR_EliminationRequest on cr.CaseReviewRootID equals el.CaseReviewRootID
                            where
                            caseReviewList.Contains(cr.CaseReviewID)
                            && cr.InitialQAUserID == userId
                            && el.RequestedDate == null
                            && el.ApprovedDate == null
                            && el.EliminatedDate == null
                            && (el.EmailSentDate == null || el.EmailSentDate <= lastDay)
                            select new EliminationRequestBase
                            {
                                Id = el.Id,
                                CaseReviewRootId = cr.CaseReviewRootID,
                                CaseReviewId = cr.CaseReviewID,
                                CaseName = cr.CaseName,
                                CaseId = cr.CaseID,
                                IsTargetChildTurned18 = el.IsTargetChildTurned18,
                                TargetChildTurned18Date = el.TargetChildTurned18Date,
                                IsHomeServiceCaseOpenDuringPUR = el.IsHomeServiceCaseOpenDuringPUR,
                                HomeServiceCaseOpenedDuringPUR = el.HomeServiceCaseOpenedDuringPUR,
                                HomeServiceCaseClosedDuringPUR = el.HomeServiceCaseClosedDuringPUR,

                            }).ToList();



                return list;
            }

        }
        private List<DashboardModel> GetDashboardRecords(string filter)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                DashboardFilterModel crDs = null;
                if (!string.IsNullOrEmpty(filter))
                {
                    List<Filter> f = JsonConvert.DeserializeObject<List<Filter>>(filter);
                    if (!string.IsNullOrEmpty(f.FirstOrDefault().Value) || f.FirstOrDefault().Value != null)
                    {
                        crDs = JsonConvert.DeserializeObject<DashboardFilterModel>(f.FirstOrDefault().Value);
                    }
                }
                var list = db.ActiveCases();

                var hasEditIrrCasePermission = HasPermission(PermissionEnum.EditIRRCase);
                var hasViewAllIrrCasePermission = HasPermission(PermissionEnum.ShowAllIRRCases);
                if (hasEditIrrCasePermission)
                {
                    list = list.Where(w => w.IsIRR == true);
                    if (!hasViewAllIrrCasePermission)
                    {
                        list = list.Where(w => w.IRRReviewerID.HasValue && w.IRRReviewerID == UserId);
                    }
                }
                //else
                //{
                //    list = list.Where(w => w.IsIRR == null || w.IsIRR==false);
                //}

                if (crDs != null)
                {
                    if (crDs.CaseReviewID.HasValue)
                        list = list.Where(w => w.CaseReviewID==crDs.CaseReviewID);
                    if (!string.IsNullOrEmpty(crDs.CaseID))
                        list = list.Where(w => w.CaseID.HasValue && w.CaseID.Value.ToString().Contains(crDs.CaseID));
                    if (!string.IsNullOrEmpty(crDs.MeetingID))
                        list = list.Where(w => w.MeetingID.HasValue && w.MeetingID.Value.ToString().Contains(crDs.MeetingID));

                    if (!string.IsNullOrEmpty(crDs.CaseName))
                        list = list.Where(w => w.CaseName.ToString().Contains(crDs.CaseName));

                    if (crDs.ReviewTypeID != null && crDs.ReviewTypeID!=0)
                        list = list.Where(w => w.ReviewTypeID.HasValue && crDs.ReviewTypeID==w.ReviewTypeID);

                    if (crDs.ReviewSubTypeID != null && crDs.ReviewSubTypeID!=0)
                        list = list.Where(w => w.ReviewSubTypeID.HasValue && crDs.ReviewSubTypeID==w.ReviewSubTypeID);

                    if (crDs.CaseStatusCode != null && crDs.CaseStatusCode.Any())
                        list = list.Where(w => w.CaseStatusCode.HasValue && crDs.CaseStatusCode.Contains(w.CaseStatusCode.Value));

                    if (crDs.ReviewStartDate.HasValue)
                        list = list.Where(w => DbFunctions.TruncateTime(w.ReviewStartDate) == DbFunctions.TruncateTime(crDs.ReviewStartDate));

                    if (crDs.ReviewCompleted.HasValue)
                        list = list.Where(w => DbFunctions.TruncateTime(w.ReviewCompleted) == DbFunctions.TruncateTime(crDs.ReviewCompleted));

                    if (crDs.SiteCode != null && crDs.SiteCode.Any())
                        list = list.Where(w => w.SiteCode.HasValue && crDs.SiteCode.Contains(w.SiteCode.Value));
                    if (crDs.Reviewers != null && crDs.Reviewers.Any())
                        list = list.Where(w => w.CR_Reviewer.Any(r => r.UserID.HasValue && crDs.Reviewers.Contains(r.UserID.Value)));
                    if (crDs.IsPIPMonitored.HasValue)
                        list = list.Where(w => w.IsPIPMonitored == crDs.IsPIPMonitored);
                    if (crDs.IsCaseImported.HasValue)
                        list = list.Where(w => w.IsCaseImported == crDs.IsCaseImported || (crDs.IsCaseImported==true && w.ImportSource!=null));
                    if (crDs.InitialQAUserID != null)
                        list = list.Where(w => w.InitialQAUserID.HasValue && w.InitialQAUserID == crDs.InitialQAUserID);
                }

                var data = list.Select(e => new DashboardModel
                {
                    CaseID = e.CaseID,
                    CaseName = e.CaseName,
                    CaseReviewID = e.CaseReviewID,
                    CaseReviewRootID = e.CaseReviewRootID,
                    CaseStatusCode = e.CaseStatusCode,
                    IsPIPMonitored = e.IsPIPMonitored,
                    MeetingID = e.MeetingID,
                    ReviewCompleted = e.ReviewCompleted,
                    ReviewStartDate = e.ReviewStartDate,
                    ReviewSubTypeID = e.ReviewSubTypeID,
                    ReviewTypeID = e.ReviewTypeID,
                    SiteCode = e.SiteCode,
                    UserID = e.ID_CR,
                    InitialQAUserID = e.InitialQAUserID,
                    Reviewers = e.CR_Reviewer.Where(w => w.UserID.HasValue).Select(r => r.UserID.Value).ToList()

                }).ToList();

                return data;
            }

        }


        private List<DashboardModel> GetIrrDashboardRecords(string filter)
        {
            using (var db = new Models.DB.CrsContext(Connection))
            {
                List<Filter> f = new List<Filter>();
                if (!string.IsNullOrEmpty(filter))
                {
                    f = JsonConvert.DeserializeObject<List<Filter>>(filter);
                }

                var list = db.ActiveCases().Where(w => w.IsIRR==true);

                var hasEditIrrCasePermission = HasPermission(PermissionEnum.EditIRRCase);
                var hasViewAllIrrCasePermission = HasPermission(PermissionEnum.ShowAllIRRCases);
                if (hasEditIrrCasePermission)
                {
                    if (!hasViewAllIrrCasePermission)
                    {
                        list = list.Where(w => w.IRRReviewerID.HasValue && w.IRRReviewerID == UserId);
                    }
                }

                if (f.Any())
                {
                    var name = f.FirstOrDefault();
                    if (name !=null && !string.IsNullOrEmpty(name.Value))
                        list = list.Where(w => w.CaseName.ToString().Contains(name.Value) || w.CaseID.ToString().Contains(name.Value));
                }

                var data = list.Select(e => new DashboardModel
                {
                    CaseID = e.CaseID,
                    CaseName = e.CaseName,
                    CaseReviewID = e.CaseReviewID,
                    CaseReviewRootID = e.CaseReviewRootID,
                    CaseStatusCode = e.CaseStatusCode,
                    IsPIPMonitored = e.IsPIPMonitored,
                    MeetingID = e.MeetingID,
                    ReviewCompleted = e.ReviewCompleted,
                    ReviewStartDate = e.ReviewStartDate,
                    ReviewSubTypeID = e.ReviewSubTypeID,
                    ReviewTypeID = e.ReviewTypeID,
                    IRRReviewerID=e.IRRReviewerID,
                    SiteCode = e.SiteCode,
                    UserID = e.ID_CR,
                    Reviewers = e.CR_Reviewer.Where(w => w.UserID.HasValue).Select(r => r.UserID.Value).ToList()

                }).ToList();

                return data;
            }

        }

        #endregion

    }
}
