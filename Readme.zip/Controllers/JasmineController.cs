using System.Web.Mvc;

namespace DCF.SACWIS.CRS.Web.Controllers
{
    public class JasmineController : Controller
    {
        public ViewResult Run()
        {
            return View("SpecRunner");
        }
    }
}
