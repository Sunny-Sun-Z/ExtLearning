﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Web.Mvc;
using DCF.SACWIS.Core.Entities.Entities.Common;
using DCF.SACWIS.Core.Entities.Entities.CRS;
using DCF.SACWIS.CRS.BLL;
using DCF.SACWIS.CRS.Web.Controllers.Data;
using ENT.BLL.Helpers;
using ENT.Entities.BaseCode;
using ENT.Entities.Helpers;
using Ext.Direct.Mvc;
using Microsoft.Practices.Unity;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using ENT.Entities.Visitor;
using DCF.SACWIS.Core.BLL.Visitor;

namespace DCF.SACWIS.CRS.Web.Controllers
{
    public class CrsController : CRSBaseController
    {
        private readonly IsoDateTimeConverter _dateFormat = new IsoDateTimeConverter
        {
            DateTimeFormat = "yyyy-MM-dd HH:mm:ss.fffK"
        };
        public ActionResult Default()
        {
            ViewBag.Title = @"Case Review System";
            ViewBag.IsProd = IsProd;
            ViewBag.Version = Version;
            return View();
        }

        [HttpPost]
        public ActionResult GetDashboardData(CaseReviewDashboardSearch crDs, int userID, int start, int limit)
        {
            try
            {
                if (crDs == null)
                    crDs = new CaseReviewDashboardSearch { MeetingID = "", CaseID = "", CaseName = "" };
                crDs.CaseID = string.IsNullOrEmpty(crDs.CaseID) ? string.Empty : crDs.CaseID;
                crDs.MeetingID = string.IsNullOrEmpty(crDs.MeetingID) ? string.Empty : crDs.MeetingID;
                crDs.CaseName = string.IsNullOrEmpty(crDs.CaseName) ? string.Empty : crDs.CaseName;

                var formsBll = new CRS_FormsBLL();

                var data = formsBll.GetReviewDashboardSearch(crDs);
                return Json(new { success = true, data = data, total = data.Count() });
            }
            catch (Exception ex)
            {
                return HandleError(ex);
            }
        }

        [HttpGet]
        public ActionResult GetLookups()
        {
            try
            {

                var formsBll = new CRS_FormsBLL();

                var data = formsBll.GetCaseReviewLookup();

                return Json(new { success = true, data = data }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return HandleError(ex);
            }
        }

        [HttpGet]
        public ActionResult GetData(int caseReviewRootId, int caseReviewId, int userID)
        {
            try
            {
                var formsBll = new CRS_FormsBLL();
                var data = formsBll.GetCaseReviewData(new CaseReview() { CaseReviewRootID = caseReviewRootId, CaseReviewID = caseReviewId }, true);
               var s = JsonConvert.SerializeObject(data, Formatting.Indented, new IsoDateTimeConverter());

               return Json(new { success = true, data = data }, JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {
                return HandleError(ex);
            }
        }

        private ActionResult HandleError(Exception ex)
        {
            var logHelper = ENT.Entities.Helpers.DefaultContainer.Container.Resolve<ENT.Entities.Helpers.ILogHelper>();
            if (logHelper != null)
                logHelper.LogExceptionError(ex);

#if DEBUG
            var result = new
            {
                success = false,
                error = ex.Message + "\r" + ex.StackTrace,
                debug = true,
                data = new { }
            };
#else
                                        var dt = DateTime.Now;
                            var refer = "unknown";
                            if(Request != null && Request.UrlReferrer != null)
                                refer = Request.UrlReferrer.AbsoluteUri;
                            var result = new
                            {
                                success = false,
                                error = "This issue has been logged, please contact your Information Systems department with detail below.<br/> "
                                  + "Press Ok to refresh and continue <br/>"
                                  + "<br/>"
                                  + "Time: " + dt.ToShortDateString() + " " + dt.ToShortTimeString() + "<br/>"
                                  + "Url: " + refer + "<br/>",
                                debug = false,
                                data = new { }
                            };
#endif
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public string Version
        {
            get { return DateTime.UtcNow.Ticks.ToString(); }
        }

        public bool IsProd
        {
            get
            {
                var appEnvironment = ConfigurationManager.AppSettings["AppEnvironment"];
                return appEnvironment.ToLower().Contains("prod");
               // return true;
            }
        }
    }
}
