﻿using System;
using System.Linq;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using DCF.SACWIS.CRS.Web.Security;
using ENT.BLL.Helpers;

namespace DCF.SACWIS.CRS.Web
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }

        protected void Session_Start()
        {
            CookieHelper cookieHelper = new CookieHelper("CRSCookie", System.Web.HttpContext.Current);
            cookieHelper.Delete();
            if (!Request.Url.AbsolutePath.Contains("Errors"))
            {
                LogonAuthorize logonAuthorize = new LogonAuthorize();
                logonAuthorize.Init();
            }
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            Exception exception = Server.GetLastError();
            // Server.ClearError();
            //Response.Redirect(@"~/Errors/Index.cshtml");

            if (exception != null && exception.InnerException != null && exception.InnerException.TargetSite.Name == "Authenticate")
            {
                var httpContext = Request.RequestContext.HttpContext;
                RequestContext requestContext = ((MvcHandler)httpContext.CurrentHandler).RequestContext;

                httpContext.Response.Clear();
                string controllerName = requestContext.RouteData.GetRequiredString("controller");
                IControllerFactory factory = ControllerBuilder.Current.GetControllerFactory();
                IController controller = factory.CreateController(requestContext, controllerName);
                ControllerContext controllerContext = new ControllerContext(requestContext, (ControllerBase)controller);

                var jsonResult = new JsonResult
                {
                    Data = new DCF.SACWIS.CRS.Web.Models.Error { Success = false, ServerError = "401", ErrorMessage = exception.Message.Replace("'", "") + ". Please contact system administrator" },
                    JsonRequestBehavior = JsonRequestBehavior.AllowGet
                };
                //jsonResult.ExecuteResult(controllerContext);
                //httpContext.Response.End();
                httpContext.Response.RedirectPermanent("Errors/Unauthorize", true);
            }
        }
    }
}


