﻿using System;
using System.Web;
using System.Configuration;
using System.Reflection;
using System.Web.Optimization;
using DCF.SACWIS.Core.Entities.Entities.CRS;
using DCF.SACWIS.CRS.Web.Controllers.Data;
using ENT.Entities.Ext;
using ENT.Entities.Helpers;
using Microsoft.Practices.Unity;
namespace DCF.SACWIS.CRS.Web
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            var em = DefaultContainer.Container.Resolve<IExtractModel>();
            var jsString = em.GetModels(typeof(CaseReviewDashboardTop), "App");
            System.IO.File.WriteAllText(
                HttpContext.Current.Server.MapPath("~/app/Dashboard/model/Models.js"),
                jsString);


            em = DefaultContainer.Container.Resolve<IExtractModel>();
            jsString = em.GetModels(typeof(CaseReviewTop), "App");
            System.IO.File.WriteAllText(
                HttpContext.Current.Server.MapPath("~/app/CaseReview/model/Models.js"),
                jsString);

            em = DefaultContainer.Container.Resolve<IExtractModel>();
            jsString = em.GetModels(typeof(CaseReviewTop), "App");
            System.IO.File.WriteAllText(
                HttpContext.Current.Server.MapPath("~/app/CreateCaseReview/model/Models.js"),
                jsString);


            // -->  none of the following bundles are used <--
            //            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
            //                        "~/Scripts/jquery-{version}.js"));
            //
            //            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            //            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            //            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
            //                        "~/Scripts/modernizr-*"));
            //
            //            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
            //                //"~/Scripts/bootstrap.js",
            //                      "~/Scripts/respond.js"));
            //
            //            bundles.Add(new StyleBundle("~/Content/css").Include(
            //                //"~/Content/bootstrap.css",
            //                      "~/Content/site.css"
            //                      ));

            //// Bundle all of the CSS into one file.
            //// can't call it CSS because that directory already exist
            //bundles.Add(new StyleBundle("~/Content/css2").Include(
            //    //"~/content/chosen.css",
            //    //"~/content/theme/avocado.css",
            //    //"~/content/glyphicon.css",
            //    "~/content/styles.css"
            //));

            var cssBundle = new StyleBundle("~/Content/css2").Include("~/content/styles.css");
            cssBundle.Transforms.Add(new CssMinify());

            bundles.Add(cssBundle);

            var programVersion = ConfigurationManager.AppSettings["Version"];
            var verString = "?version=" + programVersion;
            var bundlePath = "~/Commonjs" + verString;

            var jsBundle = new ScriptBundle(bundlePath).IncludeDirectory("~/app/Common", "*.js", true);
            jsBundle.Transforms.Add(new JsMinify());
            bundles.Add(jsBundle);

            bundlePath = "~/Dashboardjs" + verString;

            jsBundle = new ScriptBundle(bundlePath).IncludeDirectory("~/app/Dashboard", "*.js", true);
            jsBundle.Transforms.Add(new JsMinify());
            bundles.Add(jsBundle);

            bundlePath = "~/CaseReviewjs" + verString;

            jsBundle = new ScriptBundle(bundlePath).IncludeDirectory("~/app/CaseReview", "*.js", true);
            jsBundle.Transforms.Add(new JsMinify());
            bundles.Add(jsBundle);

            bundlePath = "~/CreateCaseReviewjs" + verString;

            jsBundle = new ScriptBundle(bundlePath).IncludeDirectory("~/app/CreateCaseReview", "*.js", true);
            jsBundle.Transforms.Add(new JsMinify());
            bundles.Add(jsBundle);

            //
            // Below is the old code
            //
            //bundles.Add(new ScriptBundle(bundlePath).IncludeDirectory(
            //    "~/app/Common", "*.js", true));

            //bundlePath = "~/Dashboardjs" + verString;

            //bundles.Add(new ScriptBundle(bundlePath).IncludeDirectory(
            //    "~/app/Dashboard", "*.js", true));

            //bundlePath = "~/CaseReviewjs" + verString;

            //bundles.Add(new ScriptBundle(bundlePath).IncludeDirectory(
            //    "~/app/CaseReview", "*.js", true));

            //bundlePath = "~/CreateCaseReviewjs" + verString;

            //bundles.Add(new ScriptBundle(bundlePath).IncludeDirectory(
            //    "~/app/CreateCaseReview", "*.js", true)); 

            // Set EnableOptimizations to false for debugging. For more information,
            // visit http://go.microsoft.com/fwlink/?LinkId=301862

            var appEnvironment = ConfigurationManager.AppSettings["AppEnvironment"];

            ScriptBundle devScripts = new ScriptBundle("~/dev");
            devScripts.Include("~/app/ExtjsWS/build/testing/quickstart/app.js");
            bundles.Add(devScripts);
            ScriptBundle prodScripts = new ScriptBundle("~/appjs");
            prodScripts.Include("~/app/ExtjsWS/build/production/quickstart/app.js");
            bundles.Add(prodScripts);

            //var prodCssBundle = new StyleBundle("~/prod/css").IncludeDirectory("~/app/ExtJsWs/build/production/QuickStart/resources","QuickStart-all_*");
            //prodCssBundle.Transforms.Add(new CssMinify());
            //bundles.Add(prodCssBundle);

            BundleTable.EnableOptimizations = true;
        }
    }
}
