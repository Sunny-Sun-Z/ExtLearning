﻿using System.Web.Mvc;
using DCF.SACWIS.CRS.Web.Security;

namespace DCF.SACWIS.CRS.Web
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new LogonAuthorize()); 
            filters.Add(new HandleErrorAttribute());
        }
    }
}
