﻿using System.Web.Mvc;
using System.Web.Routing;

namespace DCF.SACWIS.CRS.Web
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            //routes.MapRoute(
            //    "CRSDefault",
            //    "{controller}/{action}/{id}",
            //    new { controller = "Dashboard", action = "Default", id = UrlParameter.Optional }
            //    , new string[] { "DCF.SACWIS.CRS.Web.Controllers" }
            //    );

            routes.MapRoute(
                "NewCaseReview",
                "CreateCaseReview/Default",
                new { controller = "CreateCaseReview", action = "Default"}


            );

            routes.MapRoute(
                "ErrorsDefault",
           "error/{Message}",
           new { controller = "Errors", action = "ErrorScreen" }
        );



            routes.MapRoute(
                "CaseReview",
                "CaseReview/Index/{id}",
                new { controller = "CaseReview", action = "Index"},
                new { caseReviewRootId = @"\d{1,9}" }


            );

           routes.MapRoute(
                "Default",
                "{controller}/{action}/{id}",
                new { controller = "Dashboard", action = "Default", id = UrlParameter.Optional }
                

            );
        }
    }
}
