﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Models
{
    public class RuleModel
    {
        public int Id { get; set; }
        public string Category { get; set; }
        public string ClassName { get; set; }
        public string PropertyName { get; set; }
        public System.Linq.Expressions.ExpressionType Operator { get; set; }
        public object TargetValue { get; set; }
        public string DataType { get; set; }
        public string ErrorMessage { get; set; }
        public string RuleSetName { get; set; }
        public bool IsRuleSet { get; set; }
        public bool IsArray { get; set; }
        public bool Required { get; set; }

        public System.Linq.Expressions.ExpressionType ListOperator { get; set; }
     
    }
}