﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Models
{
    public class EliminationRequestBase
    {
        public int Id { get; set; }
        public int CaseReviewId { get; set; }
        public int? CaseReviewRootId { get; set; }
        public int? CaseId { get; set; }
        public string CaseName { get; set; }

        public bool? IsTargetChildTurned18 { get; set; }
        public DateTime? TargetChildTurned18Date { get; set; }

        public bool? IsHomeServiceCaseOpenDuringPUR { get; set; }
        public DateTime? HomeServiceCaseOpenedDuringPUR { get; set; }
        public DateTime? HomeServiceCaseClosedDuringPUR { get; set; }

    }
    public class EliminationRequest : EliminationRequestBase
    {
        public string TargetChildName { get; set; }
        public string CaseType { get; set; }
        public string Reviewers { get; set; }
        public string QaTeam { get; set; }
        public string ScheduledReviewMonth { get; set; }

        public DateTime? RequestedDate { get; set; }
        public bool? IsIdentifyKeyIndividual { get; set; }
        public string IdentifyKeyIndividualExplain { get; set; }
        public bool? IsIdentifyPhoneCall { get; set; }
        public string IdentifyPhoneCallExplain { get; set; }
        public bool? IsIdentifyLetter { get; set; }
        public string IdentifyLetterExplain { get; set; }
        public bool? IsIdentifyCpsStaff { get; set; }
        public string IdentifyCpsStaffExplain { get; set; }
        public bool? IsCaseAppearedMultipleTimes { get; set; }
        public string CaseAppearedMultipleTimesExplain { get; set; }
        public bool? IsChildEntryInFosterCare { get; set; }
        public DateTime? ChildEntryInFosterCareDate { get; set; }
        public bool? IsFosterCareCaseClosed { get; set; }
        public DateTime? FosterCareCaseClosedDate { get; set; }
        public bool? IsTargetChildPlacementOfAnotherState { get; set; }
        public string TargetChildPlacementOfAnotherStateExplain { get; set; }
        public bool? IsChildAdoptionOrGuardianshipFinalize { get; set; }
        public DateTime? ChildAdoptionOrGuardianshipDateFinalize { get; set; }
        public string ChildAdoptionOrGuardianshipFinalizeExplain { get; set; }
        public bool? IsCaseOpenForSubsidizedAdoptionOrGuardianship { get; set; }
        public bool? IsQaTeamForEliminationRequest { get; set; }
        public string QaTeamForEliminationRequestExplain { get; set; }
        public bool? IsCaseMeetEliminationCriteria { get; set; }
        public string CaseMeetEliminationCriteriaReason { get; set; }
        public DateTime? ApprovedDate { get; set; }
        public string ApproverName { get; set; }
        public string ApproverEmail { get; set; }
        public string ApprovalFileName { get; set; }
        public byte[] ApprovalFileContent { get; set; }
        public DateTime? EliminatedDate { get; set; }
        public DateTime? Created { get; set; }
        public Nullable<int> CreatedBy { get; set; }
        public bool? IsSystemGenerated { get; set; }
        public DateTime? SystemGeneratedDate { get; set; }
        public DateTime? EmailSentDate { get; set; }

        public void CopyTo(ref Models.DB.CR_EliminationRequest item)
        {
            if (item == null)
                item = new Models.DB.CR_EliminationRequest();

            item.CaseReviewID = this.CaseReviewId;
            item.CaseReviewRootID = this.CaseReviewRootId;
            item.IsCaseOpenForSubsidizedAdoptionOrGuardianship = this.IsCaseOpenForSubsidizedAdoptionOrGuardianship;
            item.IsCaseMeetEliminationCriteria = this.IsCaseMeetEliminationCriteria;
            item.CaseMeetEliminationCriteriaReason = this.CaseMeetEliminationCriteriaReason;
            item.IsQaTeamForEliminationRequest = this.IsQaTeamForEliminationRequest;
            item.QaTeamForEliminationRequestExplain = this.QaTeamForEliminationRequestExplain;
            item.IsChildAdoptionOrGuardianshipFinalize = this.IsChildAdoptionOrGuardianshipFinalize;
            item.ChildAdoptionOrGuardianshipFinalizeExplain = this.ChildAdoptionOrGuardianshipFinalizeExplain;
            item.ChildAdoptionOrGuardianshipDateFinalize = this.ChildAdoptionOrGuardianshipDateFinalize;
            item.IsTargetChildPlacementOfAnotherState = this.IsTargetChildPlacementOfAnotherState;
            item.TargetChildPlacementOfAnotherStateExplain = this.TargetChildPlacementOfAnotherStateExplain;
            item.IsTargetChildTurned18 = this.IsTargetChildTurned18;
            item.TargetChildTurned18Date = this.TargetChildTurned18Date;
            item.IsFosterCareCaseClosed = this.IsFosterCareCaseClosed;
            item.FosterCareCaseClosedDate = this.FosterCareCaseClosedDate;
            item.IsChildEntryInFosterCare = this.IsChildEntryInFosterCare;
            item.ChildEntryInFosterCareDate = this.ChildEntryInFosterCareDate;
            item.IsHomeServiceCaseOpenDuringPUR = this.IsHomeServiceCaseOpenDuringPUR;
            item.HomeServiceCaseOpenedDuringPUR = this.HomeServiceCaseOpenedDuringPUR;
            item.HomeServiceCaseClosedDuringPUR = this.HomeServiceCaseClosedDuringPUR;
            item.IsCaseAppearedMultipleTimes = this.IsCaseAppearedMultipleTimes;
            item.CaseAppearedMultipleTimesExplain = this.CaseAppearedMultipleTimesExplain;
            item.IsIdentifyCpsStaff = this.IsIdentifyCpsStaff;
            item.IdentifyCpsStaffExplain = this.IdentifyCpsStaffExplain;
            item.IsIdentifyKeyIndividual = this.IsIdentifyKeyIndividual;
            item.IdentifyKeyIndividualExplain = this.IdentifyKeyIndividualExplain;
            item.IsIdentifyPhoneCall = this.IsIdentifyPhoneCall;
            item.IdentifyPhoneCallExplain = this.IdentifyPhoneCallExplain;
            item.IsIdentifyLetter = this.IsIdentifyLetter;
            item.IdentifyLetterExplain = this.IdentifyLetterExplain;
            item.RequestedDate = this.RequestedDate;
            item.EliminatedDate = this.EliminatedDate;
            item.ApprovedDate = this.ApprovedDate;
            item.ApproverName = this.ApproverName;
            item.ApproverEmail = this.ApproverEmail;
            item.Created = this.Created;
            item.CreatedBy = this.CreatedBy;
            item.EmailSentDate = this.EmailSentDate;

        }
        public Models.EliminationRequest CopyFrom(Models.DB.CR_EliminationRequest req)
        {
            var item = new Models.EliminationRequest();

            item.CaseReviewId = req.CaseReviewID;
            item.CaseReviewRootId = req.CaseReviewRootID;
            item.IsCaseOpenForSubsidizedAdoptionOrGuardianship = req.IsCaseOpenForSubsidizedAdoptionOrGuardianship;
            item.IsCaseMeetEliminationCriteria = req.IsCaseMeetEliminationCriteria;
            item.CaseMeetEliminationCriteriaReason = req.CaseMeetEliminationCriteriaReason;
            item.IsQaTeamForEliminationRequest = req.IsQaTeamForEliminationRequest;
            item.QaTeamForEliminationRequestExplain = req.QaTeamForEliminationRequestExplain;
            item.IsChildAdoptionOrGuardianshipFinalize = req.IsChildAdoptionOrGuardianshipFinalize;
            item.ChildAdoptionOrGuardianshipFinalizeExplain = req.ChildAdoptionOrGuardianshipFinalizeExplain;
            item.ChildAdoptionOrGuardianshipDateFinalize = req.ChildAdoptionOrGuardianshipDateFinalize;
            item.IsTargetChildPlacementOfAnotherState = req.IsTargetChildPlacementOfAnotherState;
            item.TargetChildPlacementOfAnotherStateExplain = req.TargetChildPlacementOfAnotherStateExplain;
            item.IsTargetChildTurned18 = req.IsTargetChildTurned18;
            item.TargetChildTurned18Date = req.TargetChildTurned18Date;
            item.IsFosterCareCaseClosed = req.IsFosterCareCaseClosed;
            item.FosterCareCaseClosedDate = req.FosterCareCaseClosedDate;
            item.IsChildEntryInFosterCare = req.IsChildEntryInFosterCare;
            item.ChildEntryInFosterCareDate = req.ChildEntryInFosterCareDate;
            item.IsHomeServiceCaseOpenDuringPUR = req.IsHomeServiceCaseOpenDuringPUR;
            item.HomeServiceCaseOpenedDuringPUR = req.HomeServiceCaseOpenedDuringPUR;
            item.HomeServiceCaseClosedDuringPUR = req.HomeServiceCaseClosedDuringPUR;
            item.IsCaseAppearedMultipleTimes = req.IsCaseAppearedMultipleTimes;
            item.CaseAppearedMultipleTimesExplain = req.CaseAppearedMultipleTimesExplain;
            item.IsIdentifyCpsStaff = req.IsIdentifyCpsStaff;
            item.IdentifyCpsStaffExplain = req.IdentifyCpsStaffExplain;
            item.IsIdentifyKeyIndividual = req.IsIdentifyKeyIndividual;
            item.IdentifyKeyIndividualExplain = req.IdentifyKeyIndividualExplain;
            item.IsIdentifyPhoneCall = req.IsIdentifyPhoneCall;
            item.IdentifyPhoneCallExplain = req.IdentifyPhoneCallExplain;
            item.IsIdentifyLetter = req.IsIdentifyLetter;
            item.IdentifyLetterExplain = req.IdentifyLetterExplain;
            item.RequestedDate = req.RequestedDate;
            item.EliminatedDate = req.EliminatedDate;
            item.ApprovedDate = req.ApprovedDate;
            item.ApproverName = req.ApproverName;
            item.ApproverEmail = req.ApproverEmail;
            item.Created = req.Created;
            item.CreatedBy = req.CreatedBy;
            item.EmailSentDate = req.EmailSentDate;

            return item;
        }

    }
}