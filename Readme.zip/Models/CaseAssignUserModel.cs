﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Models
{
    public class CaseAssignUserModel
    {

        public int? CaseID { get; set; }
        public List<int> Reviewers { get; set; }
        public int? InitialQAUserID { get; set; }
        public int? SecondaryOversightUserID { get; set; }
        public int? SecondQAUserID { get; set; }
        public int? CtSecondaryOversightUserID { get; set; }
        public List<int> Ids { get; set; }

    }
}