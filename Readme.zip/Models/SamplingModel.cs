﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Models
{
    public class SamplingModel : DB.CR_CIP_FINAL
    {
        public WorkerInfo WorkerInfo { get; set; }
        public DateTime PeriodUnderReview { get; set; }

        public string Reviewers { get; set; }
    }

    public class WorkerInfo
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string SupervisorFirstName { get; set; }

        public string SupervisorLastName { get; set; }

        public string ManagerFirstName { get; set; }

        public string ManagerLastName { get; set; }
    }
    public class SamplingFilterModel
    {
        public int? ReviewPeriodId { get; set; }

        public DateTime? ReviewStartMonth { get; set; }

        public DateTime? ReviewEndMonth { get; set; }

        public string Region { get; set; }

        public int? Office { get; set; }

        public string CaseType { get; set; }

        public string Reviewer { get; set; }

        public string SampleType { get; set; }

        public string TabType { get; set; }

        public bool? IsIntake { get; set; }
        public bool? IsEliminated { get; set; }
        public int? InitialQAUserID { get; set; }
    }

    public class LocationModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int RegionId { get; set; }
    }

    public class FiscalYears
    {
        public string FFY { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }

    public class ReviewPeriod
    {
        public int Id { get; set; }

        public string Period { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }
    }

    public class SampleModelDashboard
    {
        public int ID { get; set; }
        public string FFY { get; set; }
        //public Nullable<int> ReviewPeriodId { get; set; }
        public string Office_Name { get; set; }
        public string Region_Name { get; set; }
        public string Case_Type { get; set; }
        public int? Case_ID { get; set; }
        public int? CaseReviewRootID { get; set; }
        public string Case_Name { get; set; }
        public string Case_Status { get; set; }
        public string Primary_Language { get; set; }
        public string Home_Town { get; set; }
        public string Legal_Status { get; set; }
        public string ChildName { get; set; }
        public DateTime? Child_DOB { get; set; }
        public int? AGE_RPT_DT { get; set; }
        //public string TypeChild { get; set; }
        public string SampleType { get; set; }
        public DateTime? ReviewMonth { get; set; }
        public List<int> Reviewers { get; set; }
        public bool? IsPrimary { get; set; }
        public bool? IsEliminated { get; set; }
        public DateTime? TS_Eliminated { get; set; }
        public bool? IsIntake { get; set; }
        public short? CaseStatusCode { get; set; }
        public int? InitialQAUserID { get; set; }
    }
}