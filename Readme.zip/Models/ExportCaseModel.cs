﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Models
{
    public class ExportCaseModel
    {

        public int? CaseID { get; set; }
        public int? MeetingID { get; set; }
        public string CaseName { get; set; }
        public int CaseReviewID { get; set; }
        public int? CaseReviewRootID { get; set; }
        public Guid? BatchProcessedID { get; set; }
        public DateTime? FederalProcessedDate { get; set; }
        public DateTime? ReviewCompleted { get; set; }
        public DateTime? ReviewStartDate { get; set; }
        public int? ReviewSubTypeID { get; set; }
        public int? ReviewTypeID { get; set; }
        public short? SiteCode { get; set; }
        public short? CaseStatusCode { get; set; }
        public bool? Active { get; set; }
        public bool HasFile { get; set; }

        public int? ExportedBy { get; set; }
        public DateTime? ExportedDate { get; set; }

    }
}