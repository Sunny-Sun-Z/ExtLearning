﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Models
{
    public class PipReviewSampleModel
    {
        public int Id { get; set; }
        public int CaseId { get; set; }
        public int RegionId { get; set; }
        public string Office { get; set; }
        public string SampleGroup { get; set; }
        public string SampleType { get; set; }
        public DateTime Date { get; set; }
        public bool? IsAdditionalHS { get; set; }
     
        
        public int? Month { get; set; }
        public int? Month1 { get; set; }
        public int? Month2 { get; set; }
        public int? Month3 { get; set; }
        public int? Month4 { get; set; }
        public int? Month5 { get; set; }
        public int? Month6 { get; set; }
      
      
    }
}