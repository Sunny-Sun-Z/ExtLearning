﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Models
{
    public class CaseReviewEntityModel
    {
        public string Title { get; set; }
        public string TitleDesc { get; set; }

        public CaseReviewModel CaseReview { get; set; }
        public FaceSheetModel FaceSheet { get; set; }
        public Item1Model Item1 { get; set; }
        public Item2Model Item2 { get; set; }
        public Item3Model Item3 { get; set; }
        public Item4Model Item4 { get; set; }
        public Item5Model Item5 { get; set; }
        public Item6Model Item6 { get; set; }
        public Item7Model Item7 { get; set; }
        public Item8Model Item8 { get; set; }
        public Item9Model Item9 { get; set; }
        public Item10Model Item10 { get; set; }
        public Item11Model Item11 { get; set; }
        public Item12Model Item12 { get; set; }
        public Item12AModel Item12A { get; set; }
        public Item12BModel Item12B { get; set; }
        public Item12CModel Item12C { get; set; }
        public Item13Model Item13 { get; set; }
        public Item14Model Item14 { get; set; }
        public Item15Model Item15 { get; set; }
        public Item16Model Item16 { get; set; }
        public Item17Model Item17 { get; set; }
        public Item18Model Item18 { get; set; }

        public List<OutcomeModel> Outcomes { get; set; }

        public CustomPropertyModel CustomProperties { get; set; }

        
    }
    public class CaseReviewModel
    {
        [RuleDefination(Ignore = true)]
        public int? CaseReviewRootID { get; set; }
        [RuleDefination(Ignore = true)]
        public int? MeetingID { get; set; }

        public int? CaseReviewID { get; set; }

        [RuleDefination(DisplayName = "Case Name")]
        public string CaseName { get; set; }

        public int? CaseID { get; set; }


        public short? SiteCode { get; set; }

        public DateTime? ReviewStartDate { get; set; }

        public int? InitialQAUserID { get; set; }

        public int? SecondQAUserID { get; set; }

        public int? SecondaryOversightUserID { get; set; }

        public List<int> Reviewers { get; set; }
        public int? ReviewTypeID { get; set; }

        public int? ReviewSubTypeID { get; set; }

        public DateTime? ReviewCompleted { get; set; }

        public short? CaseStatusCode { get; set; }

        public Boolean? Active { get; set; }

        public int? EliminationReasonCode { get; set; }

        public string EliminationReasonExplained { get; set; }

        public int? CtSecondaryOversightUserID { get; set; }

        public short? IsPIPMonitored { get; set; }
        [RuleDefination(Ignore = true)]
        public DateTime? Created { get; set; }

    }
    public class FaceSheetModel
    {
        [RuleDefination(Ignore = true)]
        public short? StatusCode { get; set; }

        [RuleDefination(Ignore = true)]
        public int? FaceSheetID { get; set; }

        [RuleDefination(DisplayName = "Question G1 Child Demographic Table")]
        public List<ChildDemographicModel> ChildDemographics { get; set; }
        [RuleDefination(DisplayName = "Question G2 Case Participant Table")]
        public List<CaseParticipantModel> CaseParticipants { get; set; }

        [RuleDefination(DisplayName = "Question H")]
        public short? IsCaseOpenReasonOtherAbuseNeglect { get; set; }

        [RuleDefination(DisplayName = "Question I")]
        public DateTime? FirstCaseOpeningDate { get; set; }

        [RuleDefination(DisplayName = "Question J Foster Entry Date")]
        public DateTime? FosterEntryDate { get; set; }

        [RuleDefination(DisplayName = "Question J Foster Entry Date NA")]
        public short? IsFosterEntryDateNA { get; set; }

        [RuleDefination(DisplayName = "Question K Episode Discharge Date")]
        public DateTime? EpisodeDischargeDate { get; set; }

        [RuleDefination(DisplayName = "Question K Episode Discharge Date NA")]
        public short? IsEpisodeDischargeDateNA { get; set; }

        [RuleDefination(DisplayName = "Question K Episode Not Yet Discharged")]
        public short? IsEpisodeNotYetDischarged { get; set; }

        [RuleDefination(DisplayName = "Question L Case Closure Date")]
        public DateTime? CaseClosureDate { get; set; }

        [RuleDefination(DisplayName = "Question L Case Closure Not Closed")]
        public short? IsCaseClosureNotClosed { get; set; }



        [RuleDefination(DisplayName = "Question M Case Reason")]
        public List<int> CaseReasons { get; set; }

        [RuleDefination(DisplayName = "Question M Other Case Reason")]
        public string OtherCaseReason { get; set; }


    }

    public class CaseParticipantModel
    {

        [RuleDefination(Ignore = true)]
        public int? CaseParticipantID { get; set; }


        public string Name { get; set; }

        public short? RoleCode { get; set; }

        public string OtherRole { get; set; }

        public string RelationshipToChild { get; set; }

        public short? IsInterviewed { get; set; }
    }
    public class ChildDemographicModel
    {

        [RuleDefination(Ignore = true)]
        public int? ChildDemographicID { get; set; }

        public short? IsTargetChild { get; set; }

        public string Name { get; set; }
        public string Age { get; set; }

        public short? EthnicityCode { get; set; }

        public DateTime? DateOfBirth { get; set; }

        public short? GenderCode { get; set; }

        public short? IsInterviewed { get; set; }
        public List<short> Races { get; set; }


    }
    public class OutcomeModel
    {
        public int? OutcomeID { get; set; }
        public short? OutcomeCode { get; set; }

        public short? OutcomeRatingCode { get; set; }
        public short? OverriddenOutcomeRatingCode { get; set; }

    }
    public class BaseItem
    {
        [RuleDefination(Ignore = true)]
        public int? ItemID { get; set; }


        [RuleDefination(Ignore = true)]
        public int? OutcomeID { get; set; }

        public short? ItemCode { get; set; }

        public short? IsRatingOverride { get; set; }

        public short? ItemRatingCode { get; set; }

        public short? StatusCode { get; set; }

        public string RatingComments { get; set; }

        public string OverrideReason { get; set; }

        public short? OverriddenRatingCode { get; set; }

    }


    public class Item1Model : BaseItem
    {
        public string GetCategory()
        {
            return "Safety";
        }

        [RuleDefination(DisplayName = "Case Applicable?")]
        public short? IsApplicable { get; set; }

        public string Comments { get; set; }
        public List<SafetyReportModel> SafetyReports { get; set; }

        [RuleDefination(DisplayName = "Question A: Reports Not In Accordance")]
        public short? ReportsNotInAccordance { get; set; }
        [RuleDefination(DisplayName = "Question B: Face To Face Reports Not In Accordance")]
        public short? FaceToFaceReportsNotInAccordance { get; set; }
        [RuleDefination(DisplayName = "Delay Reason")]
        public string DelayReason { get; set; }
        [RuleDefination(DisplayName = "Question 1C: Delay Beyond Agency Control")]
        public short? IsDelayBeyondAgencyControl { get; set; }
        public List<NoteModel> Notes { get; set; }

    }
    public class SafetyReportModel
    {
        [RuleDefination(Ignore = true)]
        public int? SafetyReportID { get; set; }


        public int? ChildDemographicID { get; set; }

        [RuleDefination(Ignore = true)]
        public string ChildName { get; set; }

        public DateTime? ReportDate { get; set; }

        public string AllegationOther { get; set; }

        public string PriorityLevel { get; set; }

        public short? AssessmentCode { get; set; }

        public DateTime? DateAssessmentAssigned { get; set; }


        public short? IsAssigned { get; set; }

        public DateTime? DateAssessmentInitiated { get; set; }

        public short? IsInitiated { get; set; }

        public DateTime? DateFaceToFaceContact { get; set; }

        public short? IsFaceToFaceContact { get; set; }

        [RuleDefination(Ignore = true)]
        public string DateAssessmentAssignedText
        {
            get
            {
                return this.DateAssessmentAssigned.HasValue ? this.DateAssessmentAssigned.Value.ToShortDateString() : "Did not occur";
            }
           
        }
        [RuleDefination(Ignore = true)]
        public string DateAssessmentInitiatedText
        {
            get
            {
                return this.DateAssessmentInitiated.HasValue ? this.DateAssessmentInitiated.Value.ToShortDateString() : "Did not occur";
            }
            
        }
        [RuleDefination(Ignore = true)]
        public string DateFaceToFaceContactText
        {
            get
            {
                return this.DateFaceToFaceContact.HasValue ? this.DateFaceToFaceContact.Value.ToShortDateString() : "Did not occur";
            }
          
        }


        public short? PerpetratorChildRelationshipCode { get; set; }

        public string PerpetratorChildRelationshipOther { get; set; }

        public short? DispositionCode { get; set; }

        [RuleDefination(Ignore = true)]
        public List<short> Allegations { get; set; }
    }

    public class Item2Model : BaseItem
    {
        public string GetCategory()
        {
            return "Safety";
        }

        [RuleDefination(DisplayName = "Case Applicable?")]
        public short? IsApplicable { get; set; }

        public string Comments { get; set; }

        [RuleDefination(DisplayName = "Applicability: It is an in-home services case and the reviewer determines that there are concerns regarding the safety of at least one child in the family during the period under review.")]
        public short? Applicability51 { get; set; }
        [RuleDefination(DisplayName = "Applicability: It is an in-home services case and services were provided for children at risk of foster care placement to remain safely in their homes.")]
        public short? Applicability52 { get; set; }
        [RuleDefination(DisplayName = "Applicability: It is a foster care case and the child entered foster care during the period under review due to safety concerns.")]
        public short? Applicability53 { get; set; }
        [RuleDefination(DisplayName = "Applicability: It is a foster care case and the child was reunified during the period under review or was returned home on a trial basis, and the reviewer determines that there are concerns regarding the safety of that child in the home.")]
        public short? Applicability54 { get; set; }
        [RuleDefination(DisplayName = "Applicability: It is a foster care case, and although the target child entered foster care before the period under review and remained in care for the entire period under review, there are other children in the home and the reviewer determines that there are concerns regarding the safety of those children during the period under review.")]
        public short? Applicability55 { get; set; }
        [RuleDefination(DisplayName = "Applicability: Only a safety plan was needed to ensure the child(ren)’s safety and no safety-related services were necessary based on the circumstances of the case.  (In this situation, item 2 would be Not Applicable and the safety plan would be assessed in item 3.)")]
        public short? Applicability56 { get; set; }

        [RuleDefination(DisplayName = "Question 2A: Effort To Prevent Re-Entry")]
        public short? IsEffortToPreventReEntry { get; set; }
        [RuleDefination(DisplayName = "Question 2A: Effort To Prevent Re-Entry Explained")]
        public string EffortToPreventReEntryExplained { get; set; }

        [RuleDefination(DisplayName = "Question 2B: Child Removed To Ensure Safety")]
        public short? IsChildRemovedToEnsureSafety { get; set; }
        [RuleDefination(DisplayName = "Question 2B:  Child Removed To Ensure Safety Explained")]
        public string ChildRemovedToEnsureSafetyExplained { get; set; }



    }

    public class Item3Model : BaseItem
    {
        public string GetCategory()
        {
            return "Safety";
        }
        [RuleDefination(DisplayName = "Question 3A1: Family Maltreatment Allegations")]
        public short? IsFamilyMaltreatmentAllegations { get; set; }

        [RuleDefination(DisplayName = "Question 3A1: Maltreatment Not Substantiated")]
        public short? IsMaltreatmentNotSubstantiated { get; set; }


        [RuleDefination(DisplayName = "Question 3A: Initial Assesment For All Children In Home")]
        public short? IsInitialAssesmentForAllChildrenInHome { get; set; }

        [RuleDefination(DisplayName = "Question 3A: Initial Assesment For All Children In Home Explained")]
        public string InitialAssesmentForAllChildrenInHomeExplained { get; set; }

        [RuleDefination(DisplayName = "Question 3B:  Assessment For All Children InHome")]
        public short? IsOngoingAssesementForAllChildrenInHome { get; set; }

        [RuleDefination(DisplayName = "Question 3B: Ongoing Assessment For All Children InHome Explained")]
        public string OngoingAssessmentForAllChildrenInHomeExplained { get; set; }

        [RuleDefination(DisplayName = "Question 3C: Safety Plan Developed And Monitored")]
        public short? IsSafetyPlanDevelopedAndMonitored { get; set; }

        [RuleDefination(DisplayName = "Question 3C: Safety Plan Developed And Monitored Explained")]
        public string SafetyPlanDevelopedAndMonitoredExplained { get; set; }

        [RuleDefination(DisplayName = "Question 3D1: Safety Related Incidents")]
        public List<int> SafetyRelatedIncidents { get; set; }

        [RuleDefination(DisplayName = "Question 3D1: Other Safety Concern Explained")]
        public string OtherSafetyConcernExplained { get; set; }


        [RuleDefination(DisplayName = "Question 3D: Safety Concern For Other Children")]
        public short? IsSafetyConcernForOtherChildren { get; set; }

        [RuleDefination(DisplayName = "Question 3E1: Foster Safety")]
        public List<int> FosterSafety { get; set; }

        [RuleDefination(DisplayName = "Question 3E1: Foster Safety Other Explained")]
        public string FosterSafetyOtherExplained { get; set; }


        [RuleDefination(DisplayName = "Question 3E: Foster Safety Concern During Visitation")]
        public short? IsFosterSafetyConcernDuringVisitation { get; set; }

        [RuleDefination(DisplayName = "Question 3F1: Foster Placement Concern")]
        public List<int> FosterPlacementConcern { get; set; }

        [RuleDefination(DisplayName = "Question 3F1: Foster Placement Concer Other Explained")]
        public string FosterPlacementConcerOtherExplained { get; set; }

        [RuleDefination(DisplayName = "Question 3F: Foster Safety Concern Not Addressed")]
        public short? IsFosterSafetyConcernNotAddressed { get; set; }

    }


    public class Item4Model : BaseItem
    {
        public string GetCategory()
        {
            return "Permanancy";
        }

        [RuleDefination(DisplayName = "A1 Placement Table")]
        public List<PlacementModel> Placements { get; set; }

        [RuleDefination(DisplayName = "Question 4A: Number Of Placement Settings")]
        public int? NumberOfPlacementSettings { get; set; }

        [RuleDefination(DisplayName = "Question 4B: Were All Placement Changes Planned")]
        public short? WereAllPlacementChangesPlanned { get; set; }

        [RuleDefination(DisplayName = "Question 4C: Placement Applicable Circumstances")]
        public List<int> PlacementApplicableCircumstances { get; set; }

        [RuleDefination(DisplayName = "Question 4C: Placement Applicable Circumstances Other")]
        public string PlacementApplicableCircumstancesOther { get; set; }

        [RuleDefination(DisplayName = "Question 4D: Current Placement Setting Stable")]
        public short? IsCurrentPlacementSettingStable { get; set; }


    }

    public class PlacementModel
    {
        [RuleDefination(Ignore = true)]
        public int? PlacementID { get; set; }

        public DateTime? Date { get; set; }
        public long? TypeCode { get; set; }
        public string TypeOther { get; set; }
        public long? ChangeReasonCode { get; set; }
        public string ChangeReasonOther { get; set; }

    }

    public class Item5Model : BaseItem
    {
        public string GetCategory()
        {
            return "Permanancy";
        }

        [RuleDefination(DisplayName = "Case Applicable?")]
        public short? IsApplicable { get; set; }

        public string Comments { get; set; }

        [RuleDefination(DisplayName = "5A1 Permanency Goal Table")]
        public List<GoalModel> Goals { get; set; }

        [RuleDefination(DisplayName = "Question 5A2: Permanency Goal1")]
        public short? Goal1Code { get; set; }
        [RuleDefination(DisplayName = "Question 5A2: Permanency Goal2")]
        public short? Goal2Code { get; set; }


        [RuleDefination(DisplayName = "Question 5A3: Goal Specified")]
        public short? IsGoalSpecified { get; set; }

        [RuleDefination(DisplayName = "Question 5B: All Goals In Timely Manner")]
        public short? WereAllGoalsInTimelyManner { get; set; }

        [RuleDefination(DisplayName = "Question 5B: All Goals In Timely Manner Explained")]
        public string AllGoalsInTimelyMannerExplained { get; set; }

        [RuleDefination(DisplayName = "Question 5C: All Goals Appropriate")]
        public short? WereAllGoalsAppropriate { get; set; }

        [RuleDefination(DisplayName = "Question 5C: All Goals Appropriate Explained")]
        public string AllGoalsAppropriateExplained { get; set; }

        [RuleDefination(DisplayName = "Question 5D: In Foster 15 Out Of 22")]
        public short? IsInFoster15OutOf22 { get; set; }

        [RuleDefination(DisplayName = "Question 5E: Meets Termination Of Parental Rights")]
        public short? MeetsTerminationOfParentalRights { get; set; }

        [RuleDefination(DisplayName = "Question 5F: Agency Joint Termination Of Parental Rights")]
        public short? IsAgencyJointTerminationOfParentalRights { get; set; }


        [RuleDefination(DisplayName = "Question 5G1: Termination Exceptions")]
        public List<int> TerminationExceptions { get; set; }

        [RuleDefination(DisplayName = "Question 5G: Exception For Termination")]
        public short? IsExceptionForTermination { get; set; }


    }
    public class Item6Model : BaseItem
    {
        public string GetCategory()
        {
            return "Permanancy";
        }

        [RuleDefination(DisplayName = "Question 6A1: Child Most Recent Foster Entry Date")]
        public DateTime? ChildMostRecentFosterEntryDate { get; set; }

        [RuleDefination(DisplayName = "Question 6A2: Time In Care")]
        public int? TimeInCare { get; set; }
        [RuleDefination(DisplayName = "Question 6A3: Discharge Date")]
        public DateTime? DischargeDate { get; set; }
        [RuleDefination(DisplayName = "Question 6A3: Discharge Date NA")]
        public short? IsDischargeDateNA { get; set; }
        [RuleDefination(DisplayName = "Question 6A4: Permanency Goal1")]
        public List<int> PermanencyGoal1 { get; set; }

        [RuleDefination(DisplayName = "Question 6B: Agency Concerted Efforts")]
        public short? IsAgencyConcertedEfforts { get; set; }

        [RuleDefination(DisplayName = "Question 6B: Agency Concerted Efforts Explained")]
        public string AgencyConcertedEffortsExplained { get; set; }

        [RuleDefination(DisplayName = "Question 6C1: Living Arrangement Code")]
        public short? LivingArrangementCode { get; set; }

        [RuleDefination(DisplayName = "Question 6C1: Living Arrangement Explained")]
        public string LivingArrangementExplained { get; set; }

        [RuleDefination(DisplayName = "Question 6C2: OtherPlannedArrangementDocumentationDate")]
        public DateTime? OtherPlannedArrangementDocumentationDate { get; set; }

        [RuleDefination(DisplayName = "Question 6C2: Other Planned Arrangement NA")]
        public short? IsOtherPlannedArrangementNA { get; set; }
        [RuleDefination(DisplayName = "Question 6C2: Other Planned Arrangement No Date")]
        public short? IsOtherPlannedArrangementNoDate { get; set; }

        [RuleDefination(DisplayName = "Question 6C: Other Planned Concerted Effort")]
        public short? IsOtherPlannedConcertedEffort { get; set; }

        [RuleDefination(DisplayName = "Question 6C: Other Planned Concerted Effort Explained")]
        public string OtherPlannedConcertedEffortExplained { get; set; }


    }

    public class Item7Model : BaseItem
    {
        public string GetCategory()
        {
            return "Permanancy";
        }

        [RuleDefination(DisplayName = "Case Applicable?")]
        public short? IsApplicable { get; set; }

        public string Comments { get; set; }

        [RuleDefination(DisplayName = "Question 7A: Placed With All Siblings")]
        public short? IsPlacedWithAllSiblings { get; set; }

        [RuleDefination(DisplayName = "Question 7B: Valid Reason For Separation")]
        public short? IsValidReasonForSeparation { get; set; }

        [RuleDefination(DisplayName = "Question 7B: Valid Reason For Separation Explained")]
        public string ValidReasonForSeparationExplained { get; set; }

    }
    public class Item8Model : BaseItem
    {
        public string GetCategory()
        {
            return "Permanancy";
        }

        [RuleDefination(DisplayName = "Applicability: The child has at least one sibling in foster care who is in a different placement setting. ")]
        public short? Applicability57 { get; set; }
        [RuleDefination(DisplayName = "Applicability: Both parents are not applicable for assessment for other reasons.")]
        public short? Applicability58 { get; set; }
        [RuleDefination(DisplayName = "Applicability: There is documentation in the case file indicating that contact between the child and both of his or her parents is not in the child’s best interests.")]
        public short? Applicability59 { get; set; }
        [RuleDefination(DisplayName = "Applicability: The whereabouts of both parents are unknown despite documented concerted agency efforts to locate the parents.")]
        public short? Applicability60 { get; set; }
        [RuleDefination(DisplayName = "Applicability: Both parents were deceased during the entire period under review. ")]
        public short? Applicability61 { get; set; }
        [RuleDefination(DisplayName = "Applicability: The parental rights of both parents remained terminated during the entire period under review.")]
        public short? Applicability62 { get; set; }


        [RuleDefination(DisplayName = "Case Applicable?")]
        public short? IsApplicable { get; set; }

        public string Comments { get; set; }


        [RuleDefination(DisplayName = "Case Participant Mother")]
        public List<int> ParticipantMother { get; set; }

        [RuleDefination(DisplayName = "Case Participant Father")]
        public List<int> ParticipantFather { get; set; }


        [RuleDefination(DisplayName = "Question 8A1: Mother Visitation Frequency")]
        public short? MotherVisitationFrequencyCode { get; set; }
        [RuleDefination(DisplayName = "Question 8A: Sufficient Frequency For Mother Visitation")]
        public short? IsSufficientFrequencyForMotherVisitation { get; set; }


        [RuleDefination(DisplayName = "Question 8B1: Father Visitation Frequency")]
        public short? FatherVisitationFrequencyCode { get; set; }
        [RuleDefination(DisplayName = "Question 8B: Sufficient Frequency For Father Visitation")]
        public short? IsSufficientFrequencyForFatherVisitation { get; set; }


        [RuleDefination(DisplayName = "Question 8C: Sufficient Quality For Mother Visitation")]
        public short? IsSufficientQualityForMotherVisitation { get; set; }
        [RuleDefination(DisplayName = "Question 8D: Sufficent Quality For Father Visitation")]
        public short? IsSufficentQualityForFatherVisitation { get; set; }
        [RuleDefination(DisplayName = "Question 8E1: SiblingVisitationFrequencyCode")]
        public short? SiblingVisitationFrequencyCode { get; set; }
        [RuleDefination(DisplayName = "Question 8E: Sufficient Frequency For Sibling Visitation")]
        public short? IsSufficientFrequencyForSiblingVisitation { get; set; }
        [RuleDefination(DisplayName = "Question 8F: Sufficent Quality For Sibling Visitation")]
        public short? IsSufficentQualityForSiblingVisitation { get; set; }


    }
    public class Item9Model : BaseItem
    {
        public string GetCategory()
        {
            return "Permanancy";
        }

        [RuleDefination(DisplayName = "Case Applicable?")]
        public short? IsApplicable { get; set; }

        public string Comments { get; set; }

        [RuleDefination(DisplayName = "Question 9A: Concerted Efforts For Important Connections")]
        public short? IsConcertedEffortsForImportantConnections { get; set; }

        [RuleDefination(DisplayName = "Question 9B: Sufficient Inquiry For Indian Tribe")]
        public short? IsSufficientInquiryForIndianTribe { get; set; }
        [RuleDefination(DisplayName = "Question 9C: Tribe Provided Timely Notification")]
        public short? IsTribeProvidedTimelyNotification { get; set; }
        [RuleDefination(DisplayName = "Question 9D: Accordance With Indian Child Welfare Act")]
        public short? IsAccordanceWithIndianChildWelfareAct { get; set; }


    }

    public class Item10Model : BaseItem
    {
        public string GetCategory()
        {
            return "Permanancy";
        }

        [RuleDefination(DisplayName = "Case Applicable?")]
        public short? IsApplicable { get; set; }

        public string Comments { get; set; }

        [RuleDefination(DisplayName = "Question 10A1: Recent Placement With Relative")]
        public short? IsRecentPlacementWithRelative { get; set; }

        [RuleDefination(DisplayName = "Question 10A2: Placement With Relative Stable")]
        public short? IsPlacementWithRelativeStable { get; set; }
        [RuleDefination(DisplayName = "Question 10B: Concerted Effort To Locate Maternal Relatives")]
        public short? IsConcertedEffortToLocateMaternalRelatives { get; set; }
        [RuleDefination(DisplayName = "Question 10B: Placement Effort Concerns Mother")]
        public List<int> PlacementEffortConcernsMother { get; set; }
        [RuleDefination(DisplayName = "Question 10C: Concerted Effort To Locate Paternal Relatives")]
        public short? IsConcertedEffortToLocatePaternalRelatives { get; set; }
        [RuleDefination(DisplayName = "Question 10C: Placement Effort Concerns Father")]
        public List<int> PlacementEffortConcernsFather { get; set; }


    }
    public class Item11Model : BaseItem
    {
        public string GetCategory()
        {
            return "Permanancy";
        }

        [RuleDefination(DisplayName = "Applicability: The parental rights for both parents remained terminated during the entire period under review. ")]
        public short? Applicability63 { get; set; }

        [RuleDefination(DisplayName = "Applicability: The child was abandoned and neither parent could be located.")]
        public short? Applicability64 { get; set; }

        [RuleDefination(DisplayName = "Applicability: The whereabouts of both parents were not known during the entire period under review despite documented concerted agency efforts to locate both parents.")]
        public short? Applicability65 { get; set; }

        [RuleDefination(DisplayName = "Applicability: Contact with both parents was considered to be not in the child’s best interests and this is documented in the case record.")]
        public short? Applicability66 { get; set; }

        [RuleDefination(DisplayName = "Applicability: During the entire period under review, both parents were deceased.")]
        public short? Applicability67 { get; set; }

        [RuleDefination(DisplayName = "Applicability: The only parent(s) being assessed in this item do not meet the definition of Mother/Father for this item.")]
        public short? Applicability261 { get; set; }


        [RuleDefination(DisplayName = "Case Participant Mother")]
        public List<int> ParticipantMother { get; set; }

        [RuleDefination(DisplayName = "Case Participant Father")]
        public List<int> ParticipantFather { get; set; }


        [RuleDefination(DisplayName = "Case Applicable?")]
        public short? IsApplicable { get; set; }

        public string Comments { get; set; }

        [RuleDefination(DisplayName = "Question 11A: Concerted Effort Mother Foster Relationship")]
        public short? IsConcertedEffortMotherFosterRelationship { get; set; }

        [RuleDefination(DisplayName = "Question 11A1: Efforts To Support Mother Foster Relationship")]
        public List<int> EffortsToSupportMotherFosterRelationship { get; set; }

        [RuleDefination(DisplayName = "Question 11A1: Efforts Mother Foster Other")]
        public string EffortsMotherFosterOther { get; set; }


        [RuleDefination(DisplayName = "Question 11B: Concerted Effort Father Foster Relationship")]
        public short? IsConcertedEffortFatherFosterRelationship { get; set; }

        [RuleDefination(DisplayName = "Question 11B1: Efforts To Support Father Foster Relationship")]
        public List<int> EffortsToSupportFatherFosterRelationship { get; set; }

        [RuleDefination(DisplayName = "Question 11B1: Efforts Father Foster Relationship Other")]
        public string EffortFatherFosterRelationshipOther { get; set; }

    }

    public class Item12Model : BaseItem
    {
        public string GetCategory()
        {
            return "Well Being";
        }
    }

    public class Item12AModel : BaseItem
    {
        public string GetCategory()
        {
            return "Well Being";
        }
        public string Comments { get; set; }


        [RuleDefination(DisplayName = "Question 12A1: Comprehensive Assessement Conducted")]
        public short? IsComprehensiveAssessementConducted { get; set; }

        [RuleDefination(DisplayName = "Question 12A1: Comprehensive Assessment Explained")]
        public string ComprehensiveAssessmentExplained { get; set; }

        [RuleDefination(DisplayName = "Question 12A2: Appropriate Services Provided")]
        public short? IsAppropriateServicesProvided { get; set; }
        [RuleDefination(DisplayName = "Question 12A2: Appropriate Services Provided Explained")]
        public string AppropriateServicesProvidedExplained { get; set; }


    }

    public class Item12BModel : BaseItem
    {
        public string GetCategory()
        {
            return "Well Being";
        }

        [RuleDefination(DisplayName = "Applicability: Parental rights remained terminated during the entire period under review")]
        public short? Applicability68 { get; set; }

        [RuleDefination(DisplayName = "Applicability: Parent’s whereabouts were not known during the entire period under review despite agency efforts to locate the parent")]
        public short? Applicability69 { get; set; }

        [RuleDefination(DisplayName = "Applicability: Parent was deceased during the entire period under review")]
        public short? Applicability70 { get; set; }

        [RuleDefination(DisplayName = "Applicability: During the entire period under review it was documented in the case file that it was not in the child’s best interests to involve the parent in case planning")]
        public short? Applicability71 { get; set; }

        [RuleDefination(DisplayName = "Applicability: During the entire period under review the parent has indicated he/she does not want to be involved in the child’s life and this was documented in the case file")]
        public short? Applicability72 { get; set; }



        [RuleDefination(DisplayName = "Case Participant Mother")]
        public List<int> ParticipantMother { get; set; }

        [RuleDefination(DisplayName = "Case Participant Father")]
        public List<int> ParticipantFather { get; set; }


        [RuleDefination(DisplayName = "Applicable for Mother?")]
        public short? IsNeedsServicesApplicableForMother { get; set; }
        [RuleDefination(DisplayName = "Applicable for Father?")]
        public short? IsNeedsServicesApplicableForFather { get; set; }

        public string Comments { get; set; }



        [RuleDefination(DisplayName = "Question 12B1: Agency Conduct Comprehensive Assessement For Mother")]
        public short? IsComprehensiveAssessementForMotherConducted { get; set; }


        [RuleDefination(DisplayName = "Question 12B1: Agency Conduct Comprehensive Assessement For Mother Explained")]
        public string ComprehensiveAssessementForMotherExplained { get; set; }


        [RuleDefination(DisplayName = "Question 12B2: Agency Conduct Comprehensive Assessement For Father")]
        public short? IsComprehensiveAssessementForFatherConducted { get; set; }


        [RuleDefination(DisplayName = "Question 12B2: Agency Conduct Comprehensive Assessement For Father Explained")]
        public string ComprehensiveAssessementforFatherConductedExplained { get; set; }


        [RuleDefination(DisplayName = "Question 12B3: Agency Provide Appropriate Services For Mother")]
        public short? IsAppropriateServicesForMotherProvided { get; set; }


        [RuleDefination(DisplayName = "Question 12B3: Agency Provide Appropriate Services For Mother Explained")]
        public string AppropriateServicesForMotherExplained { get; set; }



        [RuleDefination(DisplayName = "Question 12B4: Agency Provide Appropriate Services For Father ")]
        public short? IsAppropriateServicesForFatherProvided { get; set; }


        [RuleDefination(DisplayName = "Question 12B4: Agency Provide Appropriate Services For Father Explained")]
        public string AppropriateServicesForFatherExplained { get; set; }


    }

    public class Item12CModel : BaseItem
    {
        public string GetCategory()
        {
            return "Well Being";
        }
        [RuleDefination(DisplayName = "Case Applicable?")]
        public short? IsApplicable { get; set; }

        public string Comments { get; set; }

        [RuleDefination(DisplayName = "Question 12C1: Needs Of Foster Parents Adequately Assessed")]
        public short? IsNeedsOfFosterParentsAdequatelyAssessed { get; set; }
        [RuleDefination(DisplayName = "Question 12C1: Needs Of Foster Parents Adequately Assessed Explained")]
        public string NeedsOfFosterParentsAdequatelyAssessedExplained { get; set; }


        [RuleDefination(DisplayName = "Question 12C2: Foster Parents Provided Appropriate Services")]
        public short? IsFosterParentsProvidedAppropriateServices { get; set; }
        [RuleDefination(DisplayName = "Question 12C2: Foster Parents Provided Appropriate Services Explained")]
        public string FosterParentsProvidedAppropriateServicesExplained { get; set; }

    }

    public class Item13Model : BaseItem
    {
        public string GetCategory()
        {
            return "Well Being";
        }

        [RuleDefination(DisplayName = "Applicability: Cases involving children for whom participating in planning is not developmentally appropriate.")]
        public short? Applicability73 { get; set; }

        [RuleDefination(DisplayName = "Applicability: Parental rights remained terminated during the entire period under review.")]
        public short? Applicability74 { get; set; }

        [RuleDefination(DisplayName = "Applicability: Parent’s whereabouts were not known during the entire period under review despite agency efforts to locate the parent.")]
        public short? Applicability75 { get; set; }

        [RuleDefination(DisplayName = "Applicability: Parent was deceased during the entire period under review.")]
        public short? Applicability76 { get; set; }

        [RuleDefination(DisplayName = "Applicability: During the entire period under review it was documented in the case file that it was not in the child’s best interests to involve the parent in case planning.")]
        public short? Applicability77 { get; set; }
        [RuleDefination(DisplayName = "Applicability: During the entire period under review the parent has indicated he/she does not want to be involved in the child’s life and this was documented in the case file.")]
        public short? Applicability78 { get; set; }

        [RuleDefination(DisplayName = "Applicability: The Reviewer has determined that Item 12B is rated as an Area Needing Improvement due to lack of concerted efforts to find applicable parents.")]
        public short? Applicability292 { get; set; }


        [RuleDefination(DisplayName = "Case Participant Mother")]
        public List<int> ParticipantMother { get; set; }

        [RuleDefination(DisplayName = "Case Participant Father")]
        public List<int> ParticipantFather { get; set; }


        [RuleDefination(DisplayName = "Case Applicable?")]
        public short? IsApplicable { get; set; }

        public string Comments { get; set; }



        [RuleDefination(DisplayName = "Question 13A: IsAgencyConcertedEffortsToInvolveTheChild")]
        public short? IsAgencyConcertedEffortsToInvolveTheChild { get; set; }


        [RuleDefination(DisplayName = "Question 13A: AgencyConcertedEffortsToInvolveTheChildExplained")]
        public string AgencyConcertedEffortsToInvolveTheChildExplained { get; set; }


        [RuleDefination(DisplayName = "Question 13B: IsAgencyConcertedEffortsToInvolveTheMother")]
        public short? IsAgencyConcertedEffortsToInvolveTheMother { get; set; }


        [RuleDefination(DisplayName = "Question 13B: AgencyConcertedEffortsToInvolveTheMotherExplained")]
        public string AgencyConcertedEffortsToInvolveTheMotherExplained { get; set; }


        [RuleDefination(DisplayName = "Question 13C: IsAgencyConcertedEffortsToInvolveTheFather")]
        public short? IsAgencyConcertedEffortsToInvolveTheFather { get; set; }


        [RuleDefination(DisplayName = "Question 13C: AgencyConcertedEffortsToInvolveTheFatherExplained")]
        public string AgencyConcertedEffortsToInvolveTheFatherExplained { get; set; }



    }

    public class Item14Model : BaseItem
    {
        public string GetCategory()
        {
            return "Well Being";
        }
        [RuleDefination(DisplayName = "Question 14A1: Responsible Party Visitation Frequency")]
        public short? ResponsiblePartyVisitationFrequencyCode { get; set; }

        [RuleDefination(DisplayName = "Question 14A: Responsible Party Visitation Frequency Sufficient")]
        public short? IsResponsiblePartyVisitationFrequencySufficient { get; set; }
        [RuleDefination(DisplayName = "Question 14B: Responsible Party Visitation Quality Sufficient")]
        public short? IsResponsiblePartyVisitationQualitySufficient { get; set; }
        [RuleDefination(DisplayName = "Question 14B: Responsible Party Visitation Quality Explained")]
        public string ResponsiblePartyVisitationQualityExplained { get; set; }

    }
    public class Item15Model : BaseItem
    {
        public string GetCategory()
        {
            return "Well Being";
        }

        [RuleDefination(DisplayName = "Applicability: Parental rights remained terminated during the entire period under review.")]
        public short? Applicability79 { get; set; }

        [RuleDefination(DisplayName = "Applicability: Parent’s whereabouts were not known during the entire period under review despite agency efforts to locate the parent.")]
        public short? Applicability80 { get; set; }

        [RuleDefination(DisplayName = "Applicability: Parent was deceased during the entire period under review.")]
        public short? Applicability81 { get; set; }

        [RuleDefination(DisplayName = "Applicability: During the entire period under review it was documented in the case file that it was not in the child’s best interests to involve the parent in case planning.")]
        public short? Applicability82 { get; set; }

        [RuleDefination(DisplayName = "Applicability: During the entire period under review the parent has indicated he/she does not want to be involved in the child’s life and this was documented in the case file.")]
        public short? Applicability83 { get; set; }

        [RuleDefination(DisplayName = "Applicability: The Reviewer has determined that Item 12B is rated as an Area Needing Improvement due to lack of concerted efforts to find applicable parents.")]
        public short? Applicability293 { get; set; }


        [RuleDefination(DisplayName = "Case Participant Mother")]
        public List<int> ParticipantMother { get; set; }

        [RuleDefination(DisplayName = "Case Participant Father")]
        public List<int> ParticipantFather { get; set; }


        [RuleDefination(DisplayName = "Case Applicable?")]
        public short? IsApplicable { get; set; }

        public string Comments { get; set; }



        [RuleDefination(DisplayName = "Question 15A1: Responsible Party Visitation Frequency With Mother")]
        public short? ResponsiblePartyVisitationFrequencyWithMotherCode { get; set; }

        [RuleDefination(DisplayName = "Question 15A2: Efforts Is Responsible Party Visitation Frequency With Mother Sufficient")]
        public short? IsResponsiblePartyVisitationFrequencyWithMotherSufficient { get; set; }


        [RuleDefination(DisplayName = "Question 15B1: Responsible Party Visitation Frequency With Father")]
        public short? ResponsiblePartyVisitationFrequencyWithFatherCode { get; set; }

        [RuleDefination(DisplayName = "Question 15B2: Responsible Party Visitation Frequency With Father Sufficient")]
        public short? IsResponsiblePartyVisitationFrequencyWithFatherSufficient { get; set; }

        [RuleDefination(DisplayName = "Question 15C1: Responsible Party Visitation Quality With Mother Sufficient")]
        public short? IsResponsiblePartyVisitationQualityWithMotherSufficient { get; set; }

        [RuleDefination(DisplayName = "Question 15C1: Responsible Party Visitation Quality With Mother Explained")]
        public string ResponsiblePartyVisitationQualityWithMotherExplained { get; set; }

        [RuleDefination(DisplayName = "Question 15D1: Responsible Party Visitation Quality With Father Sufficient")]
        public short? IsResponsiblePartyVisitationQualityWithFatherSufficient { get; set; }

        [RuleDefination(DisplayName = "Question 15D1: Responsible Party Visitation Quality With Father Explained")]
        public string ResponsiblePartyVisitationQualityWithFatherExplained { get; set; }


    }

    public class Item16Model : BaseItem
    {
        public string GetCategory()
        {
            return "Well Being";
        }

        [RuleDefination(DisplayName = "Case Applicable?")]
        public short? IsApplicable { get; set; }

        public string Comments { get; set; }



        [RuleDefination(DisplayName = "Question 16A: Agency Assess Education Needs")]
        public short? IsAgencyAssessEducationNeeds { get; set; }

        [RuleDefination(DisplayName = "Question 16A1. Education Table")]
        public List<EducationModel> Educations { get; set; }


        [RuleDefination(DisplayName = "Question 16B: Agency Address Education Needs")]
        public short? IsAgencyAddressEducationNeeds { get; set; }



    }

    public class Item17Model : BaseItem
    {
        public string GetCategory()
        {
            return "Well Being";
        }

        [RuleDefination(DisplayName = "Case Applicable?")]
        public short? IsApplicable { get; set; }

        public string Comments { get; set; }



        [RuleDefination(DisplayName = "Question 17A1: Agency Assess Physical Health Needs")]
        public short? IsAgencyAssessPhysicalHealthNeeds { get; set; }
        [RuleDefination(DisplayName = "Question 17A2: Agency Assess Dental Health Needs")]
        public short? IsAgencyAssessDentalHealthNeeds { get; set; }

        [RuleDefination(DisplayName = "Question 17A3. Physical And Dental Health Table")]
        public List<PhysicalDentalHealthTableModel> PhysicalDentalHealthHealths { get; set; }

        [RuleDefination(DisplayName = "Question 17A4: Foster Federal Case Managament Criteria")]
        public List<int> FosterFederalCaseManagamentCriteria { get; set; }


        [RuleDefination(DisplayName = "Question 17B1: Foster Oversight Medication For Physical Healthy Appropriate")]
        public short? IsFosterOversightMedicationForPhysicalHealtyAppropriate { get; set; }

        [RuleDefination(DisplayName = "Question 17B2: Appropriate Serivces For All Physical Health Needs")]
        public short? IsAppropriateSerivcesForAllPhysicalHealthNeeds { get; set; }
        [RuleDefination(DisplayName = "Question 17B3: Appropriate Services For All Dental Needs")]
        public short? IsAppropriateServicesForAllDentalNeeds { get; set; }


    }

    public class Item18Model : BaseItem
    {
        public string GetCategory()
        {
            return "Well Being";
        }

        [RuleDefination(DisplayName = "Case Applicable?")]
        public short? IsApplicable { get; set; }

        public string Comments { get; set; }



        [RuleDefination(DisplayName = "Question 18A: Agency Assess Mental Health Needs")]
        public short? IsAgencyAssessMentalHealthNeeds { get; set; }

        [RuleDefination(DisplayName = "A1. Mental/Behavioral Health Table")]
        public List<MentalBehavirolHealthTableModel> MentalBehavirolHealths { get; set; }

        [RuleDefination(DisplayName = "Question 18B: Foster Oversight Medication For Mental Healthy Appropriate")]
        public short? IsFosterOversightMedicationForMentalHealtyAppropriate { get; set; }

        [RuleDefination(DisplayName = "Question 18C: Appropriate Serivces For Mental Health Needs")]
        public short? IsAppropriateSerivcesForMentalHealthNeeds { get; set; }

    }
    public class GoalModel
    {
        [RuleDefination(Ignore = true)]
        public int? GoalID { get; set; }
        public int? GoalCode { get; set; }
        public DateTime? DateEstablished { get; set; }
        public int? TimeInFosterCare { get; set; }
        public short? TimeUnitCode { get; set; }
        public DateTime? DateGoalChanged { get; set; }
        public short? IsCurrentGoal { get; set; }
        public string ReasonForGoalChange { get; set; }
    }

    public class HealthModel
    {
        [RuleDefination(Ignore = true)]
        public int? HealthID { get; set; }
        public string HealthNeeds { get; set; }
        public string ServicesProvided { get; set; }
        public string ServicesNeededNotProvided { get; set; }
        [RuleDefination(Ignore = true)]
        public short? HealthNeedCode { get; set; }
    }
    public class PhysicalDentalHealthTableModel : HealthModel { }
    public class MentalBehavirolHealthTableModel : HealthModel { }

    public class EducationModel
    {
        public int? EducationID { get; set; }
        public string Needs { get; set; }
        public string ServicesProvided { get; set; }
        public string ServicesNeededNotProvided { get; set; }
    }

    public class NoteModel
    {
        public List<ResponseModel> Responses { get; set; }

    }
    public class ResponseModel
    {

    }
    public class ItemParticipantModel
    {
        [RuleDefination(Ignore = true)]
        public int? ItemParticipantID { get; set; }
        public short? CodeDescriptionID { get; set; }
        public int? ParticipantID { get; set; }
    }

    public class CustomPropertyModel
    {
        public string SiteName { get; set; }
        public string InitialQAUserName { get; set; }
        public string SecondQAUserName { get; set; }
        public string SecondaryOversightUserName { get; set; }
        public string CtSecondaryOversightUserName { get; set; }
        public string ReviewSubType { get; set; }
        public string ReviewerNames { get; set; }
    }
    public sealed class RuleDefinationAttribute : Attribute
    {

        public bool Ignore { get; set; }
        public string DisplayName { get; set; }
        public string Code { get; set; }

    }
}