﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Models
{
    public class UserModel
    {
        public int UserID { get; set; }
        public string LoginID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public bool IsActive { get; set; }
        public bool Avatar { get; set; }
        public List<int> Roles { get; set; }
        public List<int> Permissions { get; set; }

        public string Phone { get; set; }
        public string PhoneServiceProviderName { get; set; }
        public int? PhoneServiceProvider { get; set; }
        public int? MessagePreference { get; set; }

        public bool IsValidPhoneServiceProvider()
        {
            return !string.IsNullOrEmpty(this.Phone) && !string.IsNullOrEmpty(this.PhoneServiceProviderName) && (this.MessagePreference == 2 || this.MessagePreference == 3);
        }
        public string GetPhoneNumber()
        {
            return this.PhoneServiceProviderName.Replace("##########", this.Phone);
        }

        public Nullable<bool> IsProfileActive { get; set; }
        public string SpecialConsideration { get; set; }
        public Nullable<int> Hometown { get; set; }
        public string OtherHometown { get; set; }
        public Nullable<int> CurrentOffice { get; set; }
        public Nullable<int> PreviousOffice { get; set; }

    }


    public class ReviewerProfileModel
    {
        public int UserID { get; set; }
      
        public string FirstName { get; set; }
        public string LastName { get; set; }
        
        public bool IsActive { get; set; }
        
        public Nullable<bool> IsProfileActive { get; set; }
        public string SpecialConsideration { get; set; }
        public string Hometown { get; set; }
        public int HometownID { get; set; }
        public string OtherHometown { get; set; }
        public string CurrentOffice { get; set; }
        public int CurrentOfficeID { get; set; }
        public string PreviousOffice { get; set; }
        public int PreviousOfficeID { get; set; }

    }

    public class RoleModel
    {
        public int RoleId { get; set; }
        public string Name { get; set; }

        public List<int> Permissions { get; set; }

    }
    public class RolePermissionModel
    {
        public int RoleId { get; set; }
        public string Name { get; set; }

        public List<PermissionModel> Permissions { get; set; }

    }
    public class PermissionModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool InRole { get; set; }
        public bool InUser { get; set; }
    }

    public class LookupModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public class Filter
    {
        public string Operator { get; set; }
        public string Property { get; set; }
        public string Value { get; set; }

    }
    public class Sorting
    {
        public string Property { get; set; }
        public string Direction { get; set; }

    }
    public partial class KeyValueModel
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }

    public class UserLookupModel
    {
        public int Id { get; set; }
        public string LoginID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Name
        {
            get
            {
                return string.Concat(this.FirstName, " ", this.LastName);
            }
        }
        public string Email { get; set; }
        public string Role { get; set; }
        public bool IsActive { get; set; }
        public bool Avatar { get; set; }
        public bool IsIRR { get; set; }
        public bool IsReviewer { get; set; }
        public bool IsQa { get; set; }
        public bool IsOversight { get; set; }
        public bool IsAdmin { get; set; }
       

      
    }


//    public class ReviewerProfileLookupModel
//    {
//        public int Id { get; set; }
       
//        public string FirstName { get; set; }
//        public string LastName { get; set; }
//        public string Name
//        {
//            get
//            {
//                return string.Concat(this.FirstName, " ", this.LastName);
//            }
//        }
//        public bool IsActive { get; set; }
//        public Nullable<bool> IsProfileActive { get; set; }
//        public string SpecialConsideration { get; set; }
//        public Nullable<int> Hometown { get; set; }
//        public string OtherHometown { get; set; }
//        public Nullable<int> CurrentOffice { get; set; }
//        public Nullable<int> PreviousOffice { get; set; }
//    }

}