﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Models
{
    public class DashboardFilterModel
    {
        public int? CaseReviewRootID { get; set; }
      
        public int? CaseReviewID { get; set; }
                      
	    public string CaseName {get; set;}
	    
	    public string CaseID {get; set;}
	    
	    public string MeetingID {get; set;}
	    
	    public List<short>  SiteCode {get; set;}
	    
	    public DateTime? ReviewStartDate {get; set;}
	    
        public DateTime? ReviewCompleted { get; set; }

        public List<short> CaseStatusCode { get; set; }

        public int ?ReviewTypeID { get; set; }

        public int? ReviewSubTypeID { get; set; }

        public List<int> Reviewers { get; set; }
        public int? IsPIPMonitored { get; set; }
        public Boolean? IsCaseImported { get; set; }
        public int? InitialQAUserID { get; set; }
    }

    public class DashboardModel
    {       
        public int? CaseReviewRootID { get; set; }
       
        public int? CaseReviewID { get; set; }
       
        public string CaseName { get; set; }

        public int? CaseID { get; set; }

        public int? MeetingID { get; set; }
       
        public short? SiteCode { get; set; }
       
        public DateTime? ReviewStartDate { get; set; }
       
        public DateTime? ReviewCompleted { get; set; }
       
        public short? CaseStatusCode { get; set; }
       
        public int? ReviewTypeID { get; set; }

        public int? ReviewSubTypeID { get; set; }
        public int? IRRReviewerID { get; set; }

        public int? UserID { get; set; }

        public List<int> Reviewers { get; set; }
        public int? IsPIPMonitored { get; set; }
        public int? InitialQAUserID { get; set; }
    }
}