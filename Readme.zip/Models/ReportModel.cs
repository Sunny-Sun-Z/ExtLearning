﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Models
{
    public class ReportModel
    {
        public ReportModel()
        {
            this.Parameters = new List<Parameter>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Type { get; set; }
        public string FileName { get; set; }
        public System.DateTime? Created { get; set; }
        public int? CreatedBy { get; set; }
        public string Url { get; set; }
        public bool? Enabled { get; set; }
        public string Query { get; set; }
        public string Component { get; set; }
    
        public List<Parameter> Parameters { get; set; }
    }

    public partial class Parameter
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Label { get; set; }
        public string DataType { get; set; }
        public string DefaultValue { get; set; }
        public object Value { get; set; }
        public int? LookupId { get; set; }
        public string LookupValueField { get; set; }
        public string LookupDisplayField { get; set; }
        public string FieldType { get; set; }
        public bool? Required { get; set; }
        public string FieldValidationType { get; set; }
  

    }

    public static class ParameterExtension
    {

        public static object GetDefaultValue(this Parameter parameter)
        {
            var type = string.IsNullOrEmpty(parameter.DataType) ? "string" : parameter.DataType.ToLower();
            object val = null;


            switch (type)
            {
                case "int":
                    int v;
                    int.TryParse(parameter.DefaultValue, out v);
                    val = string.IsNullOrEmpty(parameter.DefaultValue) ? null : (object)v;

                    break;
                case "date":
                    DateTime d;
                    DateTime.TryParse(parameter.DefaultValue, out d);
                    val = string.IsNullOrEmpty(parameter.DefaultValue) ? null : (object)d;

                    break;
                case "boolean":
                    Boolean b;
                    Boolean.TryParse(parameter.DefaultValue, out b);
                    val = string.IsNullOrEmpty(parameter.DefaultValue) ? null : (object)b;

                    break;
                case "float":
                    float f;
                    float.TryParse(parameter.DefaultValue, out f);
                    val = string.IsNullOrEmpty(parameter.DefaultValue) ? null : (object)f;

                    break;

                default:
                    val = string.IsNullOrEmpty(parameter.DefaultValue) || parameter.DefaultValue.Equals("null", StringComparison.OrdinalIgnoreCase) ? null : parameter.DefaultValue;

                    break;
            }
            return val;
        }
        private static KeyValuePair<string, object> GetDefaultValue1(this Parameter parameter)
        {
            var type = string.IsNullOrEmpty(parameter.DataType) ? "string" : parameter.DataType.ToLower();
            object val = null;


            switch (type)
            {
                case "int":
                    int v;
                    int.TryParse(parameter.DefaultValue, out v);
                    val = string.IsNullOrEmpty(parameter.DefaultValue) ? null : (object)v;

                    break;
                case "date":
                    DateTime d;
                    DateTime.TryParse(parameter.DefaultValue, out d);
                    val = string.IsNullOrEmpty(parameter.DefaultValue) ? null : (object)d;

                    break;
                case "boolean":
                    Boolean b;
                    Boolean.TryParse(parameter.DefaultValue, out b);
                    val = string.IsNullOrEmpty(parameter.DefaultValue) ? null : (object)b;

                    break;
                case "float":
                    float f;
                    float.TryParse(parameter.DefaultValue, out f);
                    val = string.IsNullOrEmpty(parameter.DefaultValue) ? null : (object)f;

                    break;

                default:
                    val = string.IsNullOrEmpty(parameter.DefaultValue) || parameter.DefaultValue.Equals("null", StringComparison.OrdinalIgnoreCase) ? null : parameter.DefaultValue;

                    break;
            }
            return new KeyValuePair<string, object>(parameter.Name, val);
        }
  

    }
}