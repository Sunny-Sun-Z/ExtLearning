﻿using DCF.SACWIS.CRS.Web.Core.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Models
{
    public class MessageModel
    {
        public MessageModel()
        {
            this.Attachments = new List<MessageAttachmentModel>();
        }

        public int Id { get; set; }
        public int ReceiverId { get; set; }
        public string ReceiverName { get; set; }
        public string ReceiverEmail { get; set; }
        public string ReceiverFullName { get; set; }
        public string SenderName { get; set; }
        public string SenderEmail { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public Guid Token
        {
            get
            {
                return Guid.NewGuid();
            }
        }
        public bool HasAttachment
        {
            get
            {
                return this.Attachments != null && this.Attachments.Any();
            }
        }
        public DateTime? CreatedTime { get; set; }
        public IList<MessageAttachmentModel> Attachments { get; set; }
        public NotificationTypeEnum Type { get; set; }
        public NotificationStatusEnum Status { get; set; }

        public IDictionary<string, object> AdditionalData { get; set; }

    }

    public partial class MessageAttachmentModel
    {
        public int Id { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public int? FileSize { get; set; }
        public string FileContentType { get; set; }
        public string FileContent { get; set; }
        public DateTime? Created { get; set; }
        public string Notes { get; set; }

    }
}