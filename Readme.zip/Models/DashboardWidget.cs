﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Models
{
    public class DashboardWidget
    {
        public int dataEntryComplete { get; set; }
        public int inProgress { get; set; }
        public int notStarted { get; set; }
        public int qaInProgress { get; set; }
        public int finalized { get; set; }
        public int eliminated { get; set; }
        public int approved { get; set; }
        public int eliminatedPendingApproval { get; set; }
       
    }
}