﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.Entity;
using System.Dynamic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Models.DB
{
    public partial class CrsContext
    {
        private static int _defaultCommandTimeout = 300;

        public static CrsContext CreateContext(string nameOrConnectionString = "")
        {
            return string.IsNullOrEmpty(nameOrConnectionString) ? new CrsContext() : new CrsContext(nameOrConnectionString);
        }
        public CrsContext(string nameOrConnectionString)
            : base(nameOrConnectionString)
        {
            this.Database.CommandTimeout = DefaultCommandTimeout;
        }

        public static int DefaultCommandTimeout
        {
            get { return _defaultCommandTimeout; }
            internal set
            {
                _defaultCommandTimeout = value;
            }
        }
        public static string GetEntityConnectionString(string connectionString)
        {

            if (String.IsNullOrEmpty(connectionString))
            {
                throw new InvalidOperationException("Database connection string is not set. Please check if application is configured properly.");
            }

            return string.Format("metadata=res://*/Models.DB.CrsContext.csdl|res://*/Models.DB.CrsContext.ssdl|res://*/Models.DB.CrsContext.msl;provider=System.Data.SqlClient;provider connection string='{0}'", connectionString);
        }

        public string Export(int caseReviewRootID)
        {

            var data = this.usp_GetCaseReview_FedXML(caseReviewRootID);

            var result = data.FirstOrDefault();
            return result;
        }

        public List<usp_GetPipReviewSample_Result> GetPipReviewSample(DateTime start, DateTime end)
        {

            var data = this.usp_GetPipReviewSample(start, end);

            var result = data.ToList<usp_GetPipReviewSample_Result>();
            return result;
        }


        public List<int> GetUniqueCaseReviewIdList()
        {
            var ids = this.CaseReviews.Where(w => w.CaseReviewRootID.HasValue).GroupBy(g => g.CaseReviewRootID)
                 .Select(m => m.Max(v => v.CaseReviewID)).ToList();
            return ids;
        }
        public IQueryable<CaseReview> ActiveCases()
        {
            var ids = GetUniqueCaseReviewIdList();
            return this.CaseReviews.Where(w => w.Active != false && ids.Contains(w.CaseReviewID));
        }

        public CaseReview ActiveCaseByCaseId(int? caseId)
        {
            return ActiveCases().Where(w => w.CaseID == caseId).FirstOrDefault();
        }
        public IQueryable<CaseReview> ActiveCasesByRootId(int rootId)
        {
            return this.CaseReviews.OrderByDescending(o => o.CaseReviewID).Where(w => w.CaseReviewRootID == rootId);
        }
        public IQueryable<CaseReview> ActiveCasesByRootIdd(List<int> rootIds)
        {
            return this.CaseReviews.OrderByDescending(o => o.CaseReviewID).Where(w => rootIds.Contains( w.CaseReviewRootID.Value));
        }

        public void AddLog(ErrorLog log)
        {
            this.ErrorLogs.Add(log);
            this.SaveChanges();
        }

        public IQueryable<ErrorLog> GetLogs(string query)
        {
            return this.ErrorLogs.OrderByDescending(o => o.Id).Where(w => w.Message.Contains(query) || w.StackTrace.Contains(query));
        }

    }

    public static class DbContextExtension
    {
        public static IEnumerable<KeyValuePair<string, string>> DynamicSqlColumns(this DbContext db, string Sql, Dictionary<string, object> Params = null)
        {
            var rows = new List<KeyValuePair<string, string>>();

            using (var command = db.Database.Connection.CreateCommand())
            {
                command.CommandText = Sql;
                if (command.Connection.State != ConnectionState.Open) { command.Connection.Open(); }

                if (Params != null)
                {
                    foreach (KeyValuePair<string, object> p in Params)
                    {
                        DbParameter dbParameter = command.CreateParameter();
                        dbParameter.ParameterName = p.Key;
                        dbParameter.Value = p.Value==null? DBNull.Value: p.Value;
                        command.Parameters.Add(dbParameter);
                    }
                }
                using (var dataReader = command.ExecuteReader())
                {
                    var schema = dataReader.GetSchemaTable();
                    foreach (System.Data.DataRow row in schema.Rows)
                    {
                        rows.Add(new KeyValuePair<string, string>((string)row["ColumnName"], ((Type)row["DataType"]).Name));
                    }
                }
            }
            return rows.AsEnumerable();
        }
        public static IEnumerable<dynamic> DynamicSqlQuery(this DbContext db, string Sql, Dictionary<string, object> Params = null)
        {
            //example
            //List<dynamic> results = DynamicListFromSql("select * from table where a=@a and b=@b", new Dictionary<string, object> { { "a", true }, { "b", false } }).ToList();
            using (var command = db.Database.Connection.CreateCommand())
            {
                command.CommandText = Sql;
                if (command.Connection.State != ConnectionState.Open) { command.Connection.Open(); }

                if (Params != null)
                {
                    foreach (KeyValuePair<string, object> p in Params)
                    {
                        DbParameter dbParameter = command.CreateParameter();
                        dbParameter.ParameterName = p.Key;
                        dbParameter.Value = p.Value == null ? DBNull.Value : p.Value;
                        command.Parameters.Add(dbParameter);
                    }
                }
                using (var dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        var row = new ExpandoObject() as IDictionary<string, object>;
                        for (var fieldCount = 0; fieldCount < dataReader.FieldCount; fieldCount++)
                        {
                            row.Add(dataReader.GetName(fieldCount), dataReader[fieldCount]);
                        }
                        yield return row;
                    }
                }
            }
        }

        public static IEnumerable<dynamic> DynamicSqlQuery(this Database database, string sql, params object[] parameters)
        {
            TypeBuilder builder = createTypeBuilder("AdhocAssembly", "AdhocModule", "AdhocType");

            using (System.Data.IDbCommand command = database.Connection.CreateCommand())
            {
                try
                {

                    if (command.Connection.State != ConnectionState.Open) { database.Connection.Open(); }

                    command.CommandText = sql;
                    command.CommandTimeout = command.Connection.ConnectionTimeout;
                    if (parameters != null)
                    {
                        foreach (var param in parameters)
                        {
                            command.Parameters.Add(param);
                        }
                    }
                    using (System.Data.IDataReader reader = command.ExecuteReader())
                    {
                        var schema = reader.GetSchemaTable();

                        foreach (System.Data.DataRow row in schema.Rows)
                        {
                            string name = (string)row["ColumnName"];
                            //var a=row.ItemArray.Select(d=>d)
                            Type type = (Type)row["DataType"];
                            if (type != typeof(string) && (bool)row.ItemArray[schema.Columns.IndexOf("AllowDbNull")])
                            {
                                type = typeof(Nullable<>).MakeGenericType(type);
                            }
                            createAutoImplementedProperty(builder, name, type);
                        }
                    }
                }
                finally
                {
                    database.Connection.Close();
                    command.Parameters.Clear();
                }
            }

            Type resultType = builder.CreateType();
            if (parameters == null)
                return database.SqlQuery(resultType, sql).ToListAsync().Result;
            return database.SqlQuery(resultType, sql, parameters).ToListAsync().Result;
        }

        private static TypeBuilder createTypeBuilder(string assemblyName, string moduleName, string typeName)
        {
            TypeBuilder typeBuilder = AppDomain
                .CurrentDomain
                .DefineDynamicAssembly(new AssemblyName(assemblyName), AssemblyBuilderAccess.Run)
                .DefineDynamicModule(moduleName)
                .DefineType(typeName, TypeAttributes.Public);
            typeBuilder.DefineDefaultConstructor(MethodAttributes.Public);
            return typeBuilder;
        }

        private static void createAutoImplementedProperty(TypeBuilder builder, string propertyName, Type propertyType)
        {
            const string PrivateFieldPrefix = "m_";
            const string GetterPrefix = "get_";
            const string SetterPrefix = "set_";

            // Generate the field.
            FieldBuilder fieldBuilder = builder.DefineField(
                string.Concat(PrivateFieldPrefix, propertyName),
                              propertyType, FieldAttributes.Private);

            // Generate the property
            PropertyBuilder propertyBuilder = builder.DefineProperty(
                propertyName, System.Reflection.PropertyAttributes.HasDefault, propertyType, null);

            // Property getter and setter attributes.
            MethodAttributes propertyMethodAttributes =
                MethodAttributes.Public | MethodAttributes.SpecialName |
                MethodAttributes.HideBySig;

            // Define the getter method.
            MethodBuilder getterMethod = builder.DefineMethod(
                string.Concat(GetterPrefix, propertyName),
                propertyMethodAttributes, propertyType, Type.EmptyTypes);

            // Emit the IL code.
            // ldarg.0
            // ldfld,_field
            // ret
            ILGenerator getterILCode = getterMethod.GetILGenerator();
            getterILCode.Emit(OpCodes.Ldarg_0);
            getterILCode.Emit(OpCodes.Ldfld, fieldBuilder);
            getterILCode.Emit(OpCodes.Ret);

            // Define the setter method.
            MethodBuilder setterMethod = builder.DefineMethod(
                string.Concat(SetterPrefix, propertyName),
                propertyMethodAttributes, null, new Type[] { propertyType });

            // Emit the IL code.
            // ldarg.0
            // ldarg.1
            // stfld,_field
            // ret
            ILGenerator setterILCode = setterMethod.GetILGenerator();
            setterILCode.Emit(OpCodes.Ldarg_0);
            setterILCode.Emit(OpCodes.Ldarg_1);
            setterILCode.Emit(OpCodes.Stfld, fieldBuilder);
            setterILCode.Emit(OpCodes.Ret);

            propertyBuilder.SetGetMethod(getterMethod);
            propertyBuilder.SetSetMethod(setterMethod);
        }
    }

}