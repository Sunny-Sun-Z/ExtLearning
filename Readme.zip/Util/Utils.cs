﻿using System;

namespace DCF.SACWIS.CRS.Web.Util
{
    public static class Utils
    {
        public static string ToDateFormat(this string data, string format = "YYYYMMDD")
        {
            try
            {
                if (string.IsNullOrWhiteSpace(data))
                    return data;

                if (format == "YYYYMMDD")
                {
                    if (data.Length != 8)
                        return data;

                    return $"{data.Substring(4, 2)}-{data.Substring(6, 2)}-{data.Substring(0, 4)}";
                }
                return data;
            }
            catch
            {
                return data;
            }
        }
    }
}