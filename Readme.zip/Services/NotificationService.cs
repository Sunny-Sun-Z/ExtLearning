﻿using DCF.SACWIS.CRS.Web.Core;
using DCF.SACWIS.CRS.Web.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net.Mail;
using System.Net.Mime;
using System.Threading.Tasks;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Services
{
    public class NotificationService : INotificationSender
    {
        SmtpModel smtp;
        Action logger;
        public NotificationService(SmtpModel smtp, Action logger)
        {
            this.smtp = smtp;
            this.logger = logger;
        }

        public Task NotifyAsync(string email, string subject, string message, Action<object, AsyncCompletedEventArgs> callback=null)
        {
            NotifyAsync(new MessageModel { ReceiverEmail = email, Subject = subject, Body = message }, callback);
            return Task.FromResult(0);
        }

        public Task NotifyAsync(Models.MessageModel message, Action<object, AsyncCompletedEventArgs> callback = null)
        {
            SmtpClient client = new SmtpClient(smtp.Server);
            client.UseDefaultCredentials = true;

            if (!string.IsNullOrEmpty(smtp.UserName) && !string.IsNullOrEmpty(smtp.Password))
            {
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                client.Credentials = new System.Net.NetworkCredential(smtp.UserName, smtp.Password);
                client.EnableSsl = smtp.EnableSsl;
            }

            var senderEmail = string.IsNullOrEmpty(message.SenderEmail) ? smtp.SenderEmail : message.SenderEmail;
            var senderName = string.IsNullOrEmpty(message.SenderName) ? smtp.SenderName : message.SenderName;
            message.Subject = this.MandateReplaceTokens(message.Subject, message);
            message.Body = this.MandateReplaceTokens(message.Body, message);

            MailAddress from = new MailAddress(senderEmail, senderName);
            MailAddress to = new MailAddress(message.ReceiverEmail);

            MailMessage mm = new MailMessage(from, to);
            mm.BodyEncoding = System.Text.Encoding.UTF8;
            mm.SubjectEncoding = System.Text.Encoding.UTF8;
          
            mm.Subject = this.ReplaceTokens(message.Subject, message.AdditionalData);
            mm.Body = this.ReplaceTokens(message.Body, message.AdditionalData);
            mm.IsBodyHtml = true;
            if (message.HasAttachment)
            {
                foreach (var att in message.Attachments)
                {
                    mm.Attachments.Add(new Attachment(att.FileName, MediaTypeNames.Application.Octet));
                }
            }

            client.SendCompleted += new SendCompletedEventHandler(callback != null ? callback : SendCompletedCallback);


            client.SendAsync(mm, message.Token.ToString());


            return Task.FromResult(0);
        }
        public void Notify(string email, string subject, string message, Action<object, AsyncCompletedEventArgs> callback = null)
        {
            Notify(new MessageModel { ReceiverEmail = email, Subject = subject, Body = message }, callback);

        }
        public void Notify(Models.MessageModel message, Action<object, AsyncCompletedEventArgs> callback = null)
        {
            SmtpClient client = new SmtpClient(smtp.Server);
            client.UseDefaultCredentials = true;

            if (!string.IsNullOrEmpty(smtp.UserName) && !string.IsNullOrEmpty(smtp.Password))
            {
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                client.Credentials = new System.Net.NetworkCredential(smtp.UserName, smtp.Password);
                client.EnableSsl = smtp.EnableSsl;
            }

            var senderEmail = string.IsNullOrEmpty(message.SenderEmail) ? smtp.SenderEmail : message.SenderEmail;
            var senderName = string.IsNullOrEmpty(message.SenderName) ? smtp.SenderName : message.SenderName;
            message.Subject = this.MandateReplaceTokens(message.Subject, message);
            message.Body = this.MandateReplaceTokens(message.Body, message);

            MailAddress from = new MailAddress(senderEmail, senderName);
            MailAddress to = new MailAddress(message.ReceiverEmail);

            MailMessage mm = new MailMessage(from, to);
            mm.BodyEncoding = System.Text.Encoding.UTF8;
            mm.SubjectEncoding = System.Text.Encoding.UTF8;
            mm.Subject = this.ReplaceTokens(message.Subject, message.AdditionalData);
            mm.Body = this.ReplaceTokens(message.Body, message.AdditionalData);
            mm.IsBodyHtml = true;
            if (message.HasAttachment)
            {
                foreach (var att in message.Attachments)
                {
                    mm.Attachments.Add(new Attachment(att.FileName, MediaTypeNames.Application.Octet));
                }
            }
            client.SendCompleted += new SendCompletedEventHandler(callback != null ? callback : SendCompletedCallback);            
            client.Send(mm);

            // throw new NotImplementedException();
        }

        public void SmsNotify(MessageModel message, Action<object, AsyncCompletedEventArgs> callback)
        {
            SmtpClient client = new SmtpClient(smtp.Server);
            client.UseDefaultCredentials = true;

            if (!string.IsNullOrEmpty(smtp.UserName) && !string.IsNullOrEmpty(smtp.Password))
            {
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                client.Credentials = new System.Net.NetworkCredential(smtp.UserName, smtp.Password);
                client.EnableSsl = smtp.EnableSsl;
            }

            var senderEmail = string.IsNullOrEmpty(message.SenderEmail) ? smtp.SenderEmail : message.SenderEmail;
            var senderName = string.IsNullOrEmpty(message.SenderName) ? smtp.SenderName : message.SenderName;
            message.Body = this.MandateReplaceTokens(message.Body, message);
            message.Subject = this.MandateReplaceTokens(message.Subject, message);
          
            MailAddress from = new MailAddress(senderEmail, senderName);
            MailAddress to = new MailAddress(message.ReceiverEmail);

            MailMessage mm = new MailMessage(from, to);
            mm.BodyEncoding = System.Text.Encoding.UTF8;
            mm.Body = this.ReplaceTokens(message.Body, message.AdditionalData);
            mm.Subject = this.ReplaceTokens(message.Subject, message.AdditionalData);
            mm.IsBodyHtml = false;
            client.SendCompleted += new SendCompletedEventHandler(callback != null ? callback : SendCompletedCallback);
            client.Send(mm);

        }

        public void SmsNotify(string number, string subject, string message, IDictionary<string, object> data, Action<object, AsyncCompletedEventArgs> callback)
        {
            SmsNotify(new MessageModel { ReceiverEmail = number, Subject = subject, Body = message, AdditionalData = data }, callback);
        }
        private void SendCompletedCallback(object sender, AsyncCompletedEventArgs e)
        {
            // Get the unique identifier for this asynchronous operation.
            String token = (string)e.UserState;

            if (e.Cancelled)
            {
                Console.WriteLine("[{0}] Send canceled.", token);
            }
            if (e.Error != null)
            {
                Console.WriteLine("[{0}] {1}", token, e.Error.ToString());
            }
            else
            {
                Console.WriteLine("Message sent.");
            }

        }
                private string MandateReplaceTokens(string message, MessageModel data)
        {
            var msg = message;
            if (data != null)
            {

                msg = msg.Replace("{ReceiverEmail}", data.ReceiverEmail);
                msg = msg.Replace("{ReceiverName}", data.ReceiverName);
                msg = msg.Replace("{ReceiverFullName}", data.ReceiverFullName);
                msg = msg.Replace("{SenderEmail}", data.SenderEmail);
                msg = msg.Replace("{SenderName}", data.SenderName);
                
            }

            return msg;
        }
        private string ReplaceTokens(string message, IDictionary<string, object> data)
        {
            var msg = message;
            if (data != null)
            {
                foreach (var item in data)
                {
                    msg = msg.Replace(string.Concat("{", item.Key, "}"), item.Value.ToString());
                }
            }

            return msg;
        }

        
     
    }
}