﻿using DCF.SACWIS.CRS.Web.Models.DB;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Threading.Tasks;

namespace DCF.SACWIS.CRS.Web.Models
{
    public static class ExpressionBuilder
    {
        private static Expression BuildExpression<T>(DCF.SACWIS.CRS.Web.Models.RuleModel rule, Expression expressionParameter)
        {
            var left = Expression.Property(expressionParameter, rule.PropertyName);
            var propertyToApplyRuleTo = typeof(T).GetTypeInfo().GetProperty(rule.PropertyName).PropertyType;
            //var right = Expression.Constant(Convert.ChangeType(rule.TargetValue, propertyToApplyRuleTo));
           
         
            var right = Expression.Constant(rule.TargetValue, propertyToApplyRuleTo);
          
            var method = propertyToApplyRuleTo.GetMethod("Contains");
            return Expression.MakeBinary(rule.Operator, left, right);
        }

        public static Func<T, bool> CompileRule<T>(DCF.SACWIS.CRS.Web.Models.RuleModel rule)
        {
            var expressionParameter = Expression.Parameter(typeof(T));
            var expression = BuildExpression<T>(rule, expressionParameter);
            return Expression.Lambda<Func<T, bool>>(expression, expressionParameter).Compile();
        }

        public static IEnumerable<Func<T, bool>> CompileRules<T>(ICollection<DCF.SACWIS.CRS.Web.Models.RuleModel> rules)
        {
            return rules.Select(CompileRule<T>).ToList();
        }
    }
}