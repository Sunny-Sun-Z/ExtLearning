﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DCF.SACWIS.CRS.Web.Core
{
    public class CryptoHelper
    {
        SymmetricAlgorithm algorithm;

        byte[] rgbKey;
        byte[] rgbIV;

        public CryptoHelper(string key , string hash)
        {
            algorithm = new TripleDESCryptoServiceProvider();

            var rgb = new Rfc2898DeriveBytes(key, Encoding.Unicode.GetBytes(hash));
            rgbKey = rgb.GetBytes(algorithm.KeySize >> 3);
            rgbIV = rgb.GetBytes(algorithm.BlockSize >> 3);
        }

        public static string GetPasswordSalt()
        {
            return Guid.NewGuid().ToString().Replace("-", "#");
        }

        public static String GetPasswordHash(String password, string salt)
        {
            if (password == null)
            {
                throw new ArgumentException("password");
            }

            var key = password + salt;
            using (var sha256 = new System.Security.Cryptography.SHA256Managed())
            {
                var hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(key));
                return Convert.ToBase64String(hash);
            }
        }

        public string Encrypt(string value)
        {
            ICryptoTransform transform = algorithm.CreateEncryptor(rgbKey, rgbIV);

            using (MemoryStream buffer = new MemoryStream())
            {
                using (CryptoStream stream = new CryptoStream(buffer, transform, CryptoStreamMode.Write))
                {
                    using (StreamWriter writer = new StreamWriter(stream, Encoding.Unicode))
                    {
                        writer.Write(value);
                    }
                }

                return Convert.ToBase64String(buffer.ToArray());
            }
        }

        public bool IsEncrypted(string text)
        {
            text = text.Trim();
            return (text.Length % 4 == 0) && Regex.IsMatch(text, @"^[a-zA-Z0-9\+/]*={0,3}$", RegexOptions.None);
        }

        public string Decrypt(string text)
        {
            ICryptoTransform transform = algorithm.CreateDecryptor(rgbKey, rgbIV);

            using (MemoryStream buffer = new MemoryStream(Convert.FromBase64String(text)))
            {
                using (CryptoStream stream = new CryptoStream(buffer, transform, CryptoStreamMode.Read))
                {
                    using (StreamReader reader = new StreamReader(stream, Encoding.Unicode))
                    {
                        return reader.ReadToEnd();
                    }
                }
            }
        }
    }
}