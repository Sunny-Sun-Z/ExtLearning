﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Core.Extensions
{
    public static class UtilExtension
    {
        public static List<KeyValuePair<string, string>> ToExtJsColumns(this List<KeyValuePair<string, string>> cols)
        {
            var list = new List<KeyValuePair<string, string>>();
            foreach (var item in cols)
            {
                var value="string";
                if(item.Value.Contains("Int"))
                    value="int";
                else if (item.Value.Contains("Date"))
                    value = "date";
                else if (item.Value.Contains("Bool"))
                    value = "boolean";

                list.Add(new KeyValuePair<string, string>(item.Key, value));
            }

            return list;
        }

        public static IEnumerable<KeyValuePair<string, string>> ToExtJsColumns(this IEnumerable<KeyValuePair<string, string>> cols)
        {
            var list = new List<KeyValuePair<string, string>>();
            foreach (var item in cols)
            {
                var value = "string";
                if (item.Value.Contains("Int"))
                    value = "int";
                else if (item.Value.Contains("Date"))
                    value = "date";
                else if (item.Value.Contains("Bool"))
                    value = "boolean";

                list.Add(new KeyValuePair<string, string>(item.Key, value));
            }

            return list;
        }
    }


   

}