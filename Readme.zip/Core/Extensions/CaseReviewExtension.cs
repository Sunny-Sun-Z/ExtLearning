﻿using DCF.SACWIS.Core.Entities.Entities.CRS;
using ENT.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Util
{

    public static class CaseReviewExtension
    {
        public static Models.CaseReviewEntityModel ToEntityModel(this DCF.SACWIS.Core.Entities.Entities.CRS.CaseReview cr, CaseReviewLookUp lookup = null)
        {
            Models.CaseReviewEntityModel model = new Models.CaseReviewEntityModel
            {

                CaseReview = new Models.CaseReviewModel
                {
                    CaseID = cr.CaseID,
                    Active = cr.Active,
                    CaseName = cr.CaseName,
                    CaseReviewID = cr.CaseReviewID,
                    CaseReviewRootID = cr.CaseReviewRootID,
                    CaseStatusCode = cr.CaseStatusCode,
                    CtSecondaryOversightUserID = cr.CtSecondaryOversightUserID,
                    EliminationReasonCode = cr.EliminationReasonCode,
                    EliminationReasonExplained = cr.EliminationReasonExplained,
                    InitialQAUserID = cr.InitialQAUserID,
                    IsPIPMonitored = cr.IsPIPMonitored,
                    MeetingID = cr.MeetingID,
                    ReviewCompleted = cr.ReviewCompleted,
                    ReviewStartDate = cr.ReviewStartDate,
                    ReviewSubTypeID = cr.ReviewSubTypeID,
                    ReviewTypeID = cr.ReviewTypeID,
                    SecondaryOversightUserID = cr.SecondaryOversightUserID,
                    SecondQAUserID = cr.SecondQAUserID,
                    SiteCode = cr.SiteCode,
                    Reviewers = cr.CR_Reviewer_Collection.Where(w => w.UserID.HasValue).Select(e => e.UserID.Value).ToList(),
                    Created = cr.TS_CR
                }
            };

            var cp = new Models.CustomPropertyModel();

            model.CustomProperties = cp;

            if (!model.CaseReview.Reviewers.Any())
            {
                model.CaseReview.Reviewers = null;
            }
            if (cr.CR_FaceSheet_Collection.Any() && cr.CR_Outcome_Collection.Count() > 1)
            {
                var fs = cr.CR_FaceSheet_Collection.Any() ? cr.CR_FaceSheet_Collection.FirstOrDefault() : new DCF.SACWIS.Core.Entities.Entities.CRS.CR_FaceSheet();
                var s = cr.CR_Safety_Collection.FirstOrDefault();
                var p = cr.CR_Permanency_Collection.FirstOrDefault();
                var wb = cr.CR_WellBeing_Collection.FirstOrDefault();

                var ofs = cr.CR_Outcome_Collection.Where(w => w.OutcomeCode == 21).Select(e => e.CR_Item_Collection.ToList()).FirstOrDefault() ?? new List<CR_Item>();
                var o1 = cr.CR_Outcome_Collection.Where(w => w.OutcomeCode == 1).Select(e => e.CR_Item_Collection.ToList()).FirstOrDefault() ?? new List<CR_Item>();
                var o2 = cr.CR_Outcome_Collection.Where(w => w.OutcomeCode == 2).Select(e => e.CR_Item_Collection.ToList()).FirstOrDefault() ?? new List<CR_Item>();
                var o3 = cr.CR_Outcome_Collection.Where(w => w.OutcomeCode == 3).Select(e => e.CR_Item_Collection.ToList()).FirstOrDefault() ?? new List<CR_Item>();
                var o4 = cr.CR_Outcome_Collection.Where(w => w.OutcomeCode == 4).Select(e => e.CR_Item_Collection.ToList()).FirstOrDefault() ?? new List<CR_Item>();
                var o5 = cr.CR_Outcome_Collection.Where(w => w.OutcomeCode == 5).Select(e => e.CR_Item_Collection.ToList()).FirstOrDefault() ?? new List<CR_Item>();
                var o6 = cr.CR_Outcome_Collection.Where(w => w.OutcomeCode == 6).Select(e => e.CR_Item_Collection.ToList()).FirstOrDefault() ?? new List<CR_Item>();
                var o7 = cr.CR_Outcome_Collection.Where(w => w.OutcomeCode == 7).Select(e => e.CR_Item_Collection.ToList()).FirstOrDefault() ?? new List<CR_Item>();

                var ifs = ofs.FirstOrDefault(w => w.ItemCode == 23) ?? new CR_Item();

                var i1 = o1.FirstOrDefault(w => w.ItemCode == 2) ?? new CR_Item() ?? new CR_Item();
                var i2 = o2.FirstOrDefault(w => w.ItemCode == 3) ?? new CR_Item();
                var i3 = o2.FirstOrDefault(w => w.ItemCode == 4) ?? new CR_Item();

                var i4 = o3.FirstOrDefault(w => w.ItemCode == 5) ?? new CR_Item();
                var i5 = o3.FirstOrDefault(w => w.ItemCode == 6) ?? new CR_Item();
                var i6 = o3.FirstOrDefault(w => w.ItemCode == 7) ?? new CR_Item();

                var i7 = o4.FirstOrDefault(w => w.ItemCode == 8) ?? new CR_Item();
                var i8 = o4.FirstOrDefault(w => w.ItemCode == 9) ?? new CR_Item();
                var i9 = o4.FirstOrDefault(w => w.ItemCode == 10) ?? new CR_Item();
                var i10 = o4.FirstOrDefault(w => w.ItemCode == 11) ?? new CR_Item();
                var i11 = o4.FirstOrDefault(w => w.ItemCode == 12) ?? new CR_Item();

                var i12 = o5.FirstOrDefault(w => w.ItemCode == 13) ?? new CR_Item();
                var i12a = o5.FirstOrDefault(w => w.ItemCode == 14) ?? new CR_Item();
                var i12b = o5.FirstOrDefault(w => w.ItemCode == 15) ?? new CR_Item();
                var i12c = o5.FirstOrDefault(w => w.ItemCode == 16) ?? new CR_Item();
                var i13 = o5.FirstOrDefault(w => w.ItemCode == 17) ?? new CR_Item();
                var i14 = o5.FirstOrDefault(w => w.ItemCode == 18) ?? new CR_Item();
                var i15 = o5.FirstOrDefault(w => w.ItemCode == 19) ?? new CR_Item();

                var i16 = o6.FirstOrDefault(w => w.ItemCode == 20) ?? new CR_Item();

                var i17 = o7.FirstOrDefault(w => w.ItemCode == 21) ?? new CR_Item();
                var i18 = o7.FirstOrDefault(w => w.ItemCode == 22) ?? new CR_Item();

                var reasons = cr.CR_MultiAnswer_Collection.Where(w => w.GroupName == "CaseReason").Select(e => (int)e.CodeDescriptionID.Value).ToList();

                model.FaceSheet = new Models.FaceSheetModel
                {
                    StatusCode = i1.StatusCode,

                    CaseClosureDate = fs.CaseClosureDate,
                    CaseParticipants = !fs.CR_CaseParticipant_Collection.Any() ? null : fs.CR_CaseParticipant_Collection.Select(e => new Models.CaseParticipantModel
                    {
                        CaseParticipantID = e.CaseParticipantID,
                        IsInterviewed = e.IsInterviewed,
                        Name = e.Name,
                        OtherRole = e.OtherRole,
                        RelationshipToChild = e.RelationshipToChild,
                        RoleCode = e.RoleCode
                    }).ToList(),
                    ChildDemographics = !fs.CR_ChildDemographic_Collection.Any() ? null : fs.CR_ChildDemographic_Collection.Select(e => new Models.ChildDemographicModel
                    {
                        ChildDemographicID = e.ChildDemographicID,
                        DateOfBirth = e.DateOfBirth,
                        EthnicityCode = e.EthnicityCode,
                        GenderCode = e.GenderCode,
                        IsInterviewed = e.IsInterviewed,
                        IsTargetChild = e.IsTargetChild,
                        Name = e.Name,
                        Age = GetAgeInYmd(e.DateOfBirth, cr.ReviewCompleted),
                        Races = e.CR_ChildRace_Collection.Where(w => w.RaceCode.HasValue).Select(r => r.RaceCode.Value).ToList()

                    }).ToList(),
                    CaseReasons = !reasons.Any() ? null : reasons,
                    EpisodeDischargeDate = fs.EpisodeDischargeDate,
                    FaceSheetID = fs.FaceSheetID,
                    FirstCaseOpeningDate = fs.FirstCaseOpeningDate,
                    FosterEntryDate = fs.FosterEntryDate,
                    IsCaseClosureNotClosed = fs.IsCaseClosureNotClosed,
                    IsCaseOpenReasonOtherAbuseNeglect = fs.IsCaseOpenReasonOtherAbuseNeglect,
                    IsEpisodeDischargeDateNA = fs.IsEpisodeDischargeDateNA,
                    IsEpisodeNotYetDischarged = fs.IsEpisodeNotYetDischarged,
                    IsFosterEntryDateNA = fs.IsFosterEntryDateNA,
                    OtherCaseReason = fs.OtherCaseReason,

                };
                model.Outcomes = cr.CR_Outcome_Collection.Select(e => new Models.OutcomeModel { OutcomeID = e.OutcomeID, OutcomeCode = e.OutcomeCode,OverriddenOutcomeRatingCode=e.OverriddenOutcomeRatingCode,  OutcomeRatingCode = e.OutcomeRatingCode }).ToList();

                model.Item1 = new Models.Item1Model
               {
                   Comments = i1.Comments,
                   IsApplicable = i1.IsApplicable,
                   IsRatingOverride = i1.isRatingOverride,
                   ItemCode = i1.ItemCode,
                   ItemID = i1.ItemID,
                   ItemRatingCode = i1.ItemRatingCode,
                   OutcomeID = i1.OutcomeID,
                   OverriddenRatingCode = i1.OverriddenRatingCode,
                   OverrideReason = i1.OverrideReason,
                   RatingComments = i1.RatingComments,
                   StatusCode = i1.StatusCode,


               };
                if (i1.IsApplicable == 1)
                {
                    model.Item1.DelayReason = s.DelayReason;
                    model.Item1.FaceToFaceReportsNotInAccordance = s.FaceToFaceReportsNotInAccordance;
                    model.Item1.IsDelayBeyondAgencyControl = s.IsDelayBeyondAgencyControl;
                    model.Item1.ReportsNotInAccordance = s.ReportsNotInAccordance;
                    model.Item1.SafetyReports = !s.CR_SafetyReport_Collection.Any() ? null : s.CR_SafetyReport_Collection.Select(e => new Models.SafetyReportModel
                     {
                         AllegationOther = e.AllegationOther,
                         AssessmentCode = e.AssessmentCode,
                         ChildDemographicID = e.ChildDemographicID,
                         ChildName = model.FaceSheet.ChildDemographics.Where(w => w.ChildDemographicID == e.ChildDemographicID).Select(sr => sr.Name).FirstOrDefault(),
                         DateAssessmentAssigned = e.DateAssessmentAssigned,
                         DateAssessmentInitiated = e.DateAssessmentInitiated,
                         DateFaceToFaceContact = e.DateFaceToFaceContact,
                         DispositionCode = e.DispositionCode,
                         IsAssigned = e.IsAssigned,
                         IsFaceToFaceContact = e.IsFaceToFaceContact,
                         IsInitiated = e.IsInitiated,
                         PerpetratorChildRelationshipCode = e.PerpetratorChildRelationshipCode,
                         PerpetratorChildRelationshipOther = e.PerpetratorChildRelationshipOther,
                         PriorityLevel = e.PriorityLevel,
                         ReportDate = e.ReportDate,
                         SafetyReportID = e.SafetyReportID,
                         Allegations = e.CR_SafetyReport_Allegation_Collection.Where(w => w.SafetyReportAllegationCode.HasValue).Select(r => r.SafetyReportAllegationCode.Value).ToList()

                     }).ToList();
                }

                model.Item2 = new Models.Item2Model
                {
                    Comments = i2.Comments,
                    IsApplicable = i2.IsApplicable,
                    IsRatingOverride = i2.isRatingOverride,
                    ItemCode = i2.ItemCode,
                    ItemID = i2.ItemID,
                    ItemRatingCode = i2.ItemRatingCode,
                    OutcomeID = i2.OutcomeID,
                    OverriddenRatingCode = i2.OverriddenRatingCode,
                    OverrideReason = i2.OverrideReason,
                    RatingComments = i2.RatingComments,
                    StatusCode = i2.StatusCode,

                    Applicability51 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 51).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability52 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 52).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability53 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 53).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability54 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 54).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability55 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 55).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability56 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 56).Select(e => e.AnswerCode).FirstOrDefault(),


                };
                if (i2.IsApplicable == 1)
                {
                    model.Item2.ChildRemovedToEnsureSafetyExplained = s.ChildRemovedToEnsureSafetyExplained;
                    model.Item2.EffortToPreventReEntryExplained = s.EffortToPreventReEntryExplained;
                    model.Item2.IsChildRemovedToEnsureSafety = s.IsChildRemovedToEnsureSafety;
                    model.Item2.IsEffortToPreventReEntry = s.IsEffortToPreventReEntry;

                }
                model.Item3 = new Models.Item3Model
                {

                    IsRatingOverride = i3.isRatingOverride,
                    ItemCode = i3.ItemCode,
                    ItemID = i3.ItemID,
                    ItemRatingCode = i3.ItemRatingCode,
                    OutcomeID = i3.OutcomeID,
                    OverriddenRatingCode = i3.OverriddenRatingCode,
                    OverrideReason = i3.OverrideReason,
                    RatingComments = i3.RatingComments,
                    StatusCode = i3.StatusCode,

                    FosterPlacementConcern = cr.CR_MultiAnswer_Collection.Where(w => w.GroupName == "FosterPlacementConcern").Select(e => (int)e.CodeDescriptionID.Value).ToList(),
                    FosterPlacementConcerOtherExplained = s.FosterPlacementConcerOtherExplained,
                    FosterSafety = cr.CR_MultiAnswer_Collection.Where(w => w.GroupName == "FosterSafety").Select(e => (int)e.CodeDescriptionID.Value).ToList(),
                    FosterSafetyOtherExplained = s.FosterSafetyOtherExplained,
                    InitialAssesmentForAllChildrenInHomeExplained = s.InitialAssesmentForAllChildrenInHomeExplained,
                    IsFamilyMaltreatmentAllegations = s.IsFamilyMaltreatmentAllegations,
                    IsFosterSafetyConcernDuringVisitation = s.IsFosterSafetyConcernDuringVisitation,
                    IsFosterSafetyConcernNotAddressed = s.IsFosterSafetyConcernNotAddressed,
                    IsInitialAssesmentForAllChildrenInHome = s.IsInitialAssesmentForAllChildrenInHome,
                    IsMaltreatmentNotSubstantiated = s.IsMaltreatmentNotSubstantiated,
                    IsOngoingAssesementForAllChildrenInHome = s.IsOngoingAssesementForAllChildrenInHome,
                    IsSafetyConcernForOtherChildren = s.IsSafetyConcernForOtherChildren,
                    IsSafetyPlanDevelopedAndMonitored = s.IsSafetyPlanDevelopedAndMonitored,
                    OngoingAssessmentForAllChildrenInHomeExplained = s.OngoingAssessmentForAllChildrenInHomeExplained,
                    OtherSafetyConcernExplained = s.OtherSafetyConcernExplained,
                    SafetyPlanDevelopedAndMonitoredExplained = s.SafetyPlanDevelopedAndMonitoredExplained,
                    SafetyRelatedIncidents = cr.CR_MultiAnswer_Collection.Where(w => w.GroupName == "SafetyRelatedIncidents").Select(e => (int)e.CodeDescriptionID.Value).ToList(),

                };


                model.Item4 = new Models.Item4Model
                {

                    IsRatingOverride = i4.isRatingOverride,
                    ItemCode = i4.ItemCode,
                    ItemID = i4.ItemID,
                    ItemRatingCode = i4.ItemRatingCode,
                    OutcomeID = i4.OutcomeID,
                    OverriddenRatingCode = i4.OverriddenRatingCode,
                    OverrideReason = i4.OverrideReason,
                    RatingComments = i4.RatingComments,
                    StatusCode = i4.StatusCode,

                    IsCurrentPlacementSettingStable = p.IsCurrentPlacementSettingStable,
                    NumberOfPlacementSettings = p.NumberOfPlacementSettings,
                    PlacementApplicableCircumstances = cr.CR_MultiAnswer_Collection.Where(w => w.GroupName == "PlacementApplicableCircumstances").Select(e => (int)e.CodeDescriptionID.Value).ToList(),
                    PlacementApplicableCircumstancesOther = p.PlacementApplicableCircumstancesOther,
                    Placements = p.CR_Placement_Collection.Select(e => new Models.PlacementModel
                    {
                        ChangeReasonCode = e.ChangeReasonCode,
                        ChangeReasonOther = e.ChangeReasonOther,
                        Date = e.Date,
                        PlacementID = e.PlacementID,
                        TypeCode = e.TypeCode,
                        TypeOther = e.TypeOther

                    }).ToList(),
                    WereAllPlacementChangesPlanned = p.WereAllPlacementChangesPlanned,

                };

                model.Item5 = new Models.Item5Model
                {
                    Comments = i5.Comments,
                    IsApplicable = i5.IsApplicable,
                    IsRatingOverride = i5.isRatingOverride,
                    ItemCode = i5.ItemCode,
                    ItemID = i5.ItemID,
                    ItemRatingCode = i5.ItemRatingCode,
                    OutcomeID = i5.OutcomeID,
                    OverriddenRatingCode = i5.OverriddenRatingCode,
                    OverrideReason = i5.OverrideReason,
                    RatingComments = i5.RatingComments,
                    StatusCode = i5.StatusCode,


                };
                if (i5.IsApplicable == 1)
                {
                    model.Item5.AllGoalsAppropriateExplained = p.AllGoalsAppropriateExplained;
                    model.Item5.AllGoalsInTimelyMannerExplained = p.AllGoalsInTimelyMannerExplained;
                    model.Item5.Goal1Code = p.Goal1Code;
                    model.Item5.Goal2Code = p.Goal2Code;
                    model.Item5.Goals = p.CR_Goal_Collection.Select(e => new Models.GoalModel
                      {
                          DateEstablished = e.DateEstablished,
                          DateGoalChanged = e.DateGoalChanged,
                          GoalCode = e.GoalCode,
                          GoalID = e.GoalID,
                          IsCurrentGoal = e.IsCurrentGoal,
                          ReasonForGoalChange = e.ReasonForGoalChange,
                          TimeInFosterCare = e.TimeInFosterCare,
                          TimeUnitCode = e.TimeUnitCode
                      }).ToList();
                    model.Item5.IsAgencyJointTerminationOfParentalRights = p.IsAgencyJointTerminationOfParentalRights;
                    model.Item5.IsExceptionForTermination = p.IsExceptionForTermination;
                    model.Item5.IsGoalSpecified = p.IsGoalSpecified;
                    model.Item5.IsInFoster15OutOf22 = p.IsInFoster15OutOf22;
                    model.Item5.MeetsTerminationOfParentalRights = p.MeetsTerminationOfParentalRights;
                    model.Item5.TerminationExceptions = cr.CR_MultiAnswer_Collection.Where(w => w.GroupName == "TerminationExceptions").Select(e => (int)e.CodeDescriptionID.Value).ToList();
                    model.Item5.WereAllGoalsAppropriate = p.WereAllGoalsAppropriate;
                    model.Item5.WereAllGoalsInTimelyManner = p.WereAllGoalsInTimelyManner;

                }
                model.Item6 = new Models.Item6Model
                {
                    IsRatingOverride = i6.isRatingOverride,
                    ItemCode = i6.ItemCode,
                    ItemID = i6.ItemID,
                    ItemRatingCode = i6.ItemRatingCode,
                    OutcomeID = i6.OutcomeID,
                    OverriddenRatingCode = i6.OverriddenRatingCode,
                    OverrideReason = i6.OverrideReason,
                    RatingComments = i6.RatingComments,
                    StatusCode = i6.StatusCode,

                    AgencyConcertedEffortsExplained = p.AgencyConcertedEffortsExplained,
                    ChildMostRecentFosterEntryDate = p.ChildMostRecentFosterEntryDate,
                    DischargeDate = p.DischargeDate,
                    IsAgencyConcertedEfforts = p.IsAgencyConcertedEfforts,
                    IsDischargeDateNA = p.IsDischargeDateNA,
                    IsOtherPlannedArrangementNA = p.IsOtherPlannedArrangementNA,
                    IsOtherPlannedArrangementNoDate = p.IsOtherPlannedArrangementNoDate,
                    IsOtherPlannedConcertedEffort = p.IsOtherPlannedConcertedEffort,
                    LivingArrangementCode = p.LivingArrangementCode,
                    LivingArrangementExplained = p.LivingArrangementExplained,
                    OtherPlannedArrangementDocumentationDate = p.OtherPlannedArrangementDocumentationDate,
                    OtherPlannedConcertedEffortExplained = p.OtherPlannedConcertedEffortExplained,
                    PermanencyGoal1 = cr.CR_MultiAnswer_Collection.Where(w => w.GroupName == "PermanencyGoal1").Select(e => (int)e.CodeDescriptionID.Value).ToList(),
                    TimeInCare = p.TimeInCare,

                };

                model.Item7 = new Models.Item7Model
                {
                    Comments = i7.Comments,
                    IsApplicable = i7.IsApplicable,
                    IsRatingOverride = i7.isRatingOverride,
                    ItemCode = i7.ItemCode,
                    ItemID = i7.ItemID,
                    ItemRatingCode = i7.ItemRatingCode,
                    OutcomeID = i7.OutcomeID,
                    OverriddenRatingCode = i7.OverriddenRatingCode,
                    OverrideReason = i7.OverrideReason,
                    RatingComments = i7.RatingComments,
                    StatusCode = i7.StatusCode,

                    IsPlacedWithAllSiblings = p.IsPlacedWithAllSiblings,
                    IsValidReasonForSeparation = p.IsValidReasonForSeparation,
                    ValidReasonForSeparationExplained = p.ValidReasonForSeparationExplained,


                };

                model.Item8 = new Models.Item8Model
                {
                    Comments = i8.Comments,
                    IsApplicable = i8.IsApplicable,
                    IsRatingOverride = i8.isRatingOverride,
                    ItemCode = i8.ItemCode,
                    ItemID = i8.ItemID,
                    ItemRatingCode = i8.ItemRatingCode,
                    OutcomeID = i8.OutcomeID,
                    OverriddenRatingCode = i8.OverriddenRatingCode,
                    OverrideReason = i8.OverrideReason,
                    RatingComments = i8.RatingComments,
                    StatusCode = i8.StatusCode,

                    FatherVisitationFrequencyCode = p.FatherVisitationFrequencyCode,
                    IsSufficentQualityForFatherVisitation = p.IsSufficentQualityForFatherVisitation,
                    IsSufficentQualityForSiblingVisitation = p.IsSufficentQualityForSiblingVisitation,
                    IsSufficientFrequencyForFatherVisitation = p.IsSufficientFrequencyForFatherVisitation,
                    IsSufficientFrequencyForMotherVisitation = p.IsSufficientFrequencyForMotherVisitation,
                    IsSufficientFrequencyForSiblingVisitation = p.IsSufficientFrequencyForSiblingVisitation,
                    IsSufficientQualityForMotherVisitation = p.IsSufficientQualityForMotherVisitation,
                    MotherVisitationFrequencyCode = p.MotherVisitationFrequencyCode,
                    ParticipantMother = i8.CR_ItemParticipant_Collection.Where(w => w.CodeDescriptionID == 269).Select(e => e.ParticipantID ?? 0).ToList(), //269 =mother
                    ParticipantFather = i8.CR_ItemParticipant_Collection.Where(w => w.CodeDescriptionID == 270).Select(e => e.ParticipantID ?? 0).ToList(), //270=father
                    SiblingVisitationFrequencyCode = p.SiblingVisitationFrequencyCode,
                    Applicability57 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 57).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability58 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 58).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability59 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 59).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability60 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 60).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability61 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 61).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability62 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 62).Select(e => e.AnswerCode).FirstOrDefault(),


                };

                model.Item9 = new Models.Item9Model
                {
                    Comments = i9.Comments,
                    IsApplicable = i9.IsApplicable,
                    IsRatingOverride = i9.isRatingOverride,
                    ItemCode = i9.ItemCode,
                    ItemID = i9.ItemID,
                    ItemRatingCode = i9.ItemRatingCode,
                    OutcomeID = i9.OutcomeID,
                    OverriddenRatingCode = i9.OverriddenRatingCode,
                    OverrideReason = i9.OverrideReason,
                    RatingComments = i9.RatingComments,
                    StatusCode = i9.StatusCode,

                    IsAccordanceWithIndianChildWelfareAct = p.IsAccordanceWithIndianChildWelfareAct,
                    IsConcertedEffortsForImportantConnections = p.IsConcertedEffortsForImportantConnections,
                    IsSufficientInquiryForIndianTribe = p.IsSufficientInquiryForIndianTribe,
                    IsTribeProvidedTimelyNotification = p.IsTribeProvidedTimelyNotification,


                };

                model.Item10 = new Models.Item10Model
                {
                    Comments = i10.Comments,
                    IsApplicable = i10.IsApplicable,
                    IsRatingOverride = i10.isRatingOverride,
                    ItemCode = i10.ItemCode,
                    ItemID = i10.ItemID,
                    ItemRatingCode = i10.ItemRatingCode,
                    OutcomeID = i10.OutcomeID,
                    OverriddenRatingCode = i10.OverriddenRatingCode,
                    OverrideReason = i10.OverrideReason,
                    RatingComments = i10.RatingComments,
                    StatusCode = i10.StatusCode,

                    IsConcertedEffortToLocateMaternalRelatives = p.IsConcertedEffortToLocateMaternalRelatives,
                    IsConcertedEffortToLocatePaternalRelatives = p.IsConcertedEffortToLocatePaternalRelatives,
                    IsPlacementWithRelativeStable = p.IsPlacementWithRelativeStable,
                    IsRecentPlacementWithRelative = p.IsRecentPlacementWithRelative,
                    PlacementEffortConcernsFather = cr.CR_MultiAnswer_Collection.Where(w => w.GroupName == "PlacementEffortConcernsFather").Select(e => (int)e.CodeDescriptionID.Value).ToList(),
                    PlacementEffortConcernsMother = cr.CR_MultiAnswer_Collection.Where(w => w.GroupName == "PlacementEffortConcernsMother").Select(e => (int)e.CodeDescriptionID.Value).ToList(),

                };


                model.Item11 = new Models.Item11Model
                {
                    Comments = i11.Comments,
                    IsApplicable = i11.IsApplicable,
                    IsRatingOverride = i11.isRatingOverride,
                    ItemCode = i11.ItemCode,
                    ItemID = i11.ItemID,
                    ItemRatingCode = i11.ItemRatingCode,
                    OutcomeID = i11.OutcomeID,
                    OverriddenRatingCode = i11.OverriddenRatingCode,
                    OverrideReason = i11.OverrideReason,
                    RatingComments = i11.RatingComments,
                    StatusCode = i11.StatusCode,

                    Applicability63 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 63).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability64 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 64).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability65 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 65).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability66 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 66).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability67 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 67).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability261 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 261).Select(e => e.AnswerCode).FirstOrDefault(),


                    EffortFatherFosterRelationshipOther = p.EffortFatherFosterRelationshipOther,
                    EffortsMotherFosterOther = p.EffortsMotherFosterOther,
                    EffortsToSupportFatherFosterRelationship = cr.CR_MultiAnswer_Collection.Where(w => w.GroupName == "EffortsToSupportFatherFosterRelationship").Select(e => (int)e.CodeDescriptionID.Value).ToList(),
                    EffortsToSupportMotherFosterRelationship = cr.CR_MultiAnswer_Collection.Where(w => w.GroupName == "EffortsToSupportMotherFosterRelationship").Select(e => (int)e.CodeDescriptionID.Value).ToList(),
                    IsConcertedEffortFatherFosterRelationship = p.IsConcertedEffortFatherFosterRelationship,
                    IsConcertedEffortMotherFosterRelationship = p.IsConcertedEffortMotherFosterRelationship,

                    ParticipantMother = i11.CR_ItemParticipant_Collection.Where(w => w.CodeDescriptionID == 269).Select(e => e.ParticipantID ?? 0).ToList(), //269 =mother
                    ParticipantFather = i11.CR_ItemParticipant_Collection.Where(w => w.CodeDescriptionID == 270).Select(e => e.ParticipantID ?? 0).ToList(), //270=father

                };
                if (!model.Item11.EffortsToSupportMotherFosterRelationship.Any())
                {
                    model.Item11.EffortsToSupportMotherFosterRelationship.Add(164);
                }
                if (!model.Item11.EffortsToSupportFatherFosterRelationship.Any())
                {
                    model.Item11.EffortsToSupportFatherFosterRelationship.Add(171);
                }
                model.Item12 = new Models.Item12Model
              {
                  IsRatingOverride = i12.isRatingOverride,
                  ItemCode = i12.ItemCode,
                  ItemID = i12.ItemID,
                  ItemRatingCode = i12.ItemRatingCode,
                  OutcomeID = i12.OutcomeID,
                  OverriddenRatingCode = i12.OverriddenRatingCode,
                  OverrideReason = i12.OverrideReason,
                  RatingComments = i12.RatingComments,
                  StatusCode = i12.StatusCode,

              };

                model.Item12A = new Models.Item12AModel
                {
                    Comments = i12a.Comments,

                    IsRatingOverride = i12a.isRatingOverride,
                    ItemCode = i12a.ItemCode,
                    ItemID = i12a.ItemID,
                    ItemRatingCode = i12a.ItemRatingCode,
                    OutcomeID = i12a.OutcomeID,
                    OverriddenRatingCode = i12a.OverriddenRatingCode,
                    OverrideReason = i12a.OverrideReason,
                    RatingComments = i12a.RatingComments,
                    StatusCode = i12a.StatusCode,

                    AppropriateServicesProvidedExplained = wb.AppropriateServicesProvidedExplained,
                    ComprehensiveAssessmentExplained = wb.ComprehensiveAssessmentExplained,
                    IsAppropriateServicesProvided = wb.IsAppropriateServicesProvided,
                    IsComprehensiveAssessementConducted = wb.IsComprehensiveAssessementConducted,

                };

                model.Item12B = new Models.Item12BModel
                {
                    Comments = i12b.Comments,

                    IsRatingOverride = i12b.isRatingOverride,
                    ItemCode = i12b.ItemCode,
                    ItemID = i12b.ItemID,
                    ItemRatingCode = i12b.ItemRatingCode,
                    OutcomeID = i12b.OutcomeID,
                    OverriddenRatingCode = i12b.OverriddenRatingCode,
                    OverrideReason = i12b.OverrideReason,
                    RatingComments = i12b.RatingComments,
                    StatusCode = i12b.StatusCode,

                    Applicability68 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 68).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability69 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 69).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability70 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 70).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability71 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 71).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability72 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 72).Select(e => e.AnswerCode).FirstOrDefault(),

                    IsNeedsServicesApplicableForFather = wb.IsNeedsServicesApplicableForFather,
                    IsNeedsServicesApplicableForMother = wb.IsNeedsServicesApplicableForMother,

                    IsComprehensiveAssessementForMotherConducted = wb.IsComprehensiveAssessementForMotherConducted,
                    ComprehensiveAssessementForMotherExplained = wb.ComprehensiveAssessementForMotherExplained,
                    IsComprehensiveAssessementForFatherConducted = wb.IsComprehensiveAssessementForFatherConducted,
                    ComprehensiveAssessementforFatherConductedExplained = wb.ComprehensiveAssessementforFatherConductedExplained,
                    IsAppropriateServicesForMotherProvided = wb.IsAppropriateServicesForMotherProvided,
                    AppropriateServicesForMotherExplained = wb.AppropriateServicesForMotherExplained,
                    IsAppropriateServicesForFatherProvided = wb.IsAppropriateServicesForFatherProvided,
                    AppropriateServicesForFatherExplained = wb.AppropriateServicesForFatherExplained,

                    ParticipantMother = i12b.CR_ItemParticipant_Collection.Where(w => w.CodeDescriptionID == 269).Select(e => e.ParticipantID ?? 0).ToList(), //269 =mother
                    ParticipantFather = i12b.CR_ItemParticipant_Collection.Where(w => w.CodeDescriptionID == 270).Select(e => e.ParticipantID ?? 0).ToList(), //270=father



                };
                model.Item12C = new Models.Item12CModel
              {
                  Comments = i12c.Comments,
                  IsApplicable = i12c.IsApplicable,

                  IsRatingOverride = i12c.isRatingOverride,
                  ItemCode = i12c.ItemCode,
                  ItemID = i12c.ItemID,
                  ItemRatingCode = i12c.ItemRatingCode,
                  OutcomeID = i12c.OutcomeID,
                  OverriddenRatingCode = i12c.OverriddenRatingCode,
                  OverrideReason = i12c.OverrideReason,
                  RatingComments = i12c.RatingComments,
                  StatusCode = i12c.StatusCode,


                  FosterParentsProvidedAppropriateServicesExplained = wb.FosterParentsProvidedAppropriateServicesExplained,
                  IsFosterParentsProvidedAppropriateServices = wb.IsFosterParentsProvidedAppropriateServices,
                  IsNeedsOfFosterParentsAdequatelyAssessed = wb.IsNeedsOfFosterParentsAdequatelyAssessed,
                  NeedsOfFosterParentsAdequatelyAssessedExplained = wb.NeedsOfFosterParentsAdequatelyAssessedExplained,

              };

                model.Item13 = new Models.Item13Model
                {
                    Comments = i13.Comments,
                    IsApplicable = i13.IsApplicable,

                    IsRatingOverride = i13.isRatingOverride,
                    ItemCode = i13.ItemCode,
                    ItemID = i13.ItemID,
                    ItemRatingCode = i13.ItemRatingCode,
                    OutcomeID = i13.OutcomeID,
                    OverriddenRatingCode = i13.OverriddenRatingCode,
                    OverrideReason = i13.OverrideReason,
                    RatingComments = i13.RatingComments,
                    StatusCode = i13.StatusCode,

                    Applicability73 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 73).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability74 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 74).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability75 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 75).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability76 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 76).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability77 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 77).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability78 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 78).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability292 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 292).Select(e => e.AnswerCode).FirstOrDefault(),
                    ParticipantMother = i13.CR_ItemParticipant_Collection.Where(w => w.CodeDescriptionID == 269).Select(e => e.ParticipantID ?? 0).ToList(), //269 =mother
                    ParticipantFather = i13.CR_ItemParticipant_Collection.Where(w => w.CodeDescriptionID == 270).Select(e => e.ParticipantID ?? 0).ToList(), //270=father

                    AgencyConcertedEffortsToInvolveTheChildExplained = wb.AgencyConcertedEffortsToInvolveTheChildExplained,
                    AgencyConcertedEffortsToInvolveTheFatherExplained = wb.AgencyConcertedEffortsToInvolveTheFatherExplained,
                    AgencyConcertedEffortsToInvolveTheMotherExplained = wb.AgencyConcertedEffortsToInvolveTheMotherExplained,
                    IsAgencyConcertedEffortsToInvolveTheChild = wb.IsAgencyConcertedEffortsToInvolveTheChild,
                    IsAgencyConcertedEffortsToInvolveTheFather = wb.IsAgencyConcertedEffortsToInvolveTheFather,
                    IsAgencyConcertedEffortsToInvolveTheMother = wb.IsAgencyConcertedEffortsToInvolveTheMother,

                };
                model.Item14 = new Models.Item14Model
              {

                  IsRatingOverride = i14.isRatingOverride,
                  ItemCode = i14.ItemCode,
                  ItemID = i14.ItemID,
                  ItemRatingCode = i14.ItemRatingCode,
                  OutcomeID = i14.OutcomeID,
                  OverriddenRatingCode = i14.OverriddenRatingCode,
                  OverrideReason = i14.OverrideReason,
                  RatingComments = i14.RatingComments,
                  StatusCode = i14.StatusCode,

                  IsResponsiblePartyVisitationFrequencySufficient = wb.IsResponsiblePartyVisitationFrequencySufficient,
                  IsResponsiblePartyVisitationQualitySufficient = wb.IsResponsiblePartyVisitationQualitySufficient,
                  ResponsiblePartyVisitationFrequencyCode = wb.ResponsiblePartyVisitationFrequencyCode,
                  ResponsiblePartyVisitationQualityExplained = wb.ResponsiblePartyVisitationQualityExplained,

              };

                model.Item15 = new Models.Item15Model
                {
                    Comments = i15.Comments,
                    IsApplicable = i15.IsApplicable,

                    IsRatingOverride = i15.isRatingOverride,
                    ItemCode = i15.ItemCode,
                    ItemID = i15.ItemID,
                    ItemRatingCode = i15.ItemRatingCode,
                    OutcomeID = i15.OutcomeID,
                    OverriddenRatingCode = i15.OverriddenRatingCode,
                    OverrideReason = i15.OverrideReason,
                    RatingComments = i15.RatingComments,
                    StatusCode = i15.StatusCode,

                    Applicability79 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 79).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability80 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 80).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability81 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 81).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability82 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 82).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability83 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 83).Select(e => e.AnswerCode).FirstOrDefault(),
                    Applicability293 = cr.CR_MultiAnswer_Collection.Where(w => w.CodeDescriptionID == 293).Select(e => e.AnswerCode).FirstOrDefault(),
                    ParticipantMother = i15.CR_ItemParticipant_Collection.Where(w => w.CodeDescriptionID == 269).Select(e => e.ParticipantID ?? 0).ToList(), //269 =mother
                    ParticipantFather = i15.CR_ItemParticipant_Collection.Where(w => w.CodeDescriptionID == 270).Select(e => e.ParticipantID ?? 0).ToList(), //270=father

                    IsResponsiblePartyVisitationFrequencyWithFatherSufficient = wb.IsResponsiblePartyVisitationFrequencyWithFatherSufficient,
                    IsResponsiblePartyVisitationFrequencyWithMotherSufficient = wb.IsResponsiblePartyVisitationFrequencyWithMotherSufficient,
                    IsResponsiblePartyVisitationQualityWithFatherSufficient = wb.IsResponsiblePartyVisitationQualityWithFatherSufficient,
                    IsResponsiblePartyVisitationQualityWithMotherSufficient = wb.IsResponsiblePartyVisitationQualityWithMotherSufficient,
                    ResponsiblePartyVisitationFrequencyWithFatherCode = wb.ResponsiblePartyVisitationFrequencyWithFatherCode,
                    ResponsiblePartyVisitationFrequencyWithMotherCode = wb.ResponsiblePartyVisitationFrequencyWithMotherCode,
                    ResponsiblePartyVisitationQualityWithFatherExplained = wb.ResponsiblePartyVisitationQualityWithFatherExplained,
                    ResponsiblePartyVisitationQualityWithMotherExplained = wb.ResponsiblePartyVisitationQualityWithMotherExplained

                };

                model.Item16 = new Models.Item16Model
             {
                 Comments = i16.Comments,
                 IsApplicable = i16.IsApplicable,

                 IsRatingOverride = i16.isRatingOverride,
                 ItemCode = i16.ItemCode,
                 ItemID = i16.ItemID,
                 ItemRatingCode = i16.ItemRatingCode,
                 OutcomeID = i16.OutcomeID,
                 OverriddenRatingCode = i16.OverriddenRatingCode,
                 OverrideReason = i16.OverrideReason,
                 RatingComments = i16.RatingComments,
                 StatusCode = i16.StatusCode,

                 IsAgencyAddressEducationNeeds = wb.IsAgencyAddressEducationNeeds,
                 IsAgencyAssessEducationNeeds = wb.IsAgencyAssessEducationNeeds,
                 Educations = wb.CR_Education_Collection.Select(e => new Models.EducationModel
                 {
                     EducationID = e.EducationID,
                     Needs = e.Needs,
                     ServicesNeededNotProvided = e.ServicesNeededNotProvided,
                     ServicesProvided = e.ServicesProvided
                 }).ToList()
             };

                model.Item17 = new Models.Item17Model
                {
                    Comments = i17.Comments,
                    IsApplicable = i17.IsApplicable,

                    IsRatingOverride = i17.isRatingOverride,
                    ItemCode = i17.ItemCode,
                    ItemID = i17.ItemID,
                    ItemRatingCode = i17.ItemRatingCode,
                    OutcomeID = i17.OutcomeID,
                    OverriddenRatingCode = i17.OverriddenRatingCode,
                    OverrideReason = i17.OverrideReason,
                    RatingComments = i17.RatingComments,
                    StatusCode = i17.StatusCode,


                    FosterFederalCaseManagamentCriteria = cr.CR_MultiAnswer_Collection.Where(w => w.GroupName == "FosterFederalCaseManagamentCriteria").Select(e => (int)e.CodeDescriptionID.Value).ToList(),
                    IsAgencyAssessDentalHealthNeeds = wb.IsAgencyAssessDentalHealthNeeds,
                    IsAgencyAssessPhysicalHealthNeeds = wb.IsAgencyAssessPhysicalHealthNeeds,
                    IsAppropriateSerivcesForAllPhysicalHealthNeeds = wb.IsAppropriateSerivcesForAllPhysicalHealthNeeds,
                    IsAppropriateServicesForAllDentalNeeds = wb.IsAppropriateServicesForAllDentalNeeds,
                    IsFosterOversightMedicationForPhysicalHealtyAppropriate = wb.IsFosterOversightMedicationForPhysicalHealtyAppropriate,

                    PhysicalDentalHealthHealths = wb.CR_Health_Collection.Where(w => w.HealthNeedCode == 1).Select(e => new Models.PhysicalDentalHealthTableModel
                    {
                        HealthID = e.HealthID,
                        HealthNeeds = e.HealthNeeds,
                        ServicesNeededNotProvided = e.ServicesNeededNotProvided,
                        ServicesProvided = e.ServicesProvided,
                        HealthNeedCode = e.HealthNeedCode
                    }).ToList()
                };

                model.Item18 = new Models.Item18Model
                {
                    Comments = i18.Comments,
                    IsApplicable = i18.IsApplicable,

                    IsRatingOverride = i18.isRatingOverride,
                    ItemCode = i18.ItemCode,
                    ItemID = i18.ItemID,
                    ItemRatingCode = i18.ItemRatingCode,
                    OutcomeID = i18.OutcomeID,
                    OverriddenRatingCode = i18.OverriddenRatingCode,
                    OverrideReason = i18.OverrideReason,
                    RatingComments = i18.RatingComments,
                    StatusCode = i18.StatusCode,

                    IsAgencyAssessMentalHealthNeeds = wb.IsAgencyAssessMentalHealthNeeds,
                    IsAppropriateSerivcesForMentalHealthNeeds = wb.IsAppropriateSerivcesForMentalHealthNeeds,
                    IsFosterOversightMedicationForMentalHealtyAppropriate = wb.IsFosterOversightMedicationForMentalHealtyAppropriate,


                    MentalBehavirolHealths = wb.CR_Health_Collection.Where(w => w.HealthNeedCode == 2).Select(e => new Models.MentalBehavirolHealthTableModel
                    {
                        HealthID = e.HealthID,
                        HealthNeeds = e.HealthNeeds,
                        ServicesNeededNotProvided = e.ServicesNeededNotProvided,
                        ServicesProvided = e.ServicesProvided,
                        HealthNeedCode = e.HealthNeedCode
                    }).ToList()
                };

                if (lookup != null)
                {

                    cp.SiteName = lookup.Site.Where(w => w.GroupID == model.CaseReview.SiteCode).Select(e => e.DescriptionLarge).FirstOrDefault();
                    cp.ReviewerNames = string.Join(", ", lookup.CrSecurityUser.Where(w => w.UserID.HasValue && model.CaseReview.Reviewers.Contains(w.UserID.Value)).Select(e => string.Concat(e.FirstName, " ", e.LastName)).ToList());
                    cp.InitialQAUserName = lookup.CrSecurityUser.Where(w => w.UserID == model.CaseReview.InitialQAUserID).Select(e => string.Concat(e.FirstName, " ", e.LastName)).FirstOrDefault();
                    cp.SecondQAUserName = lookup.CrSecurityUser.Where(w => w.UserID == model.CaseReview.SecondQAUserID).Select(e => string.Concat(e.FirstName, " ", e.LastName)).FirstOrDefault();
                    cp.SecondaryOversightUserName = lookup.CrSecurityUser.Where(w => w.UserID == model.CaseReview.SecondaryOversightUserID).Select(e => string.Concat(e.FirstName, " ", e.LastName)).FirstOrDefault();
                    cp.CtSecondaryOversightUserName = lookup.CrSecurityUser.Where(w => w.UserID == model.CaseReview.CtSecondaryOversightUserID).Select(e => string.Concat(e.FirstName, " ", e.LastName)).FirstOrDefault();
                    cp.ReviewSubType = lookup.CrReviewSubType.Where(w => w.ReviewSubTypeID == model.CaseReview.ReviewSubTypeID).Select(e => e.Description).FirstOrDefault();


                    model.CustomProperties = cp;
                }
            }
            return model;
        }

        private static string GetAgeInYmd(DateTime? Dob, DateTime? dateOn)
        {
            if (!Dob.HasValue || !dateOn.HasValue || dateOn < Dob)
            {
                return null;
            }

            Age age = new Age(Dob.Value, dateOn.Value);
            return String.Format("{0}y {1}m {2}d", age.Years, age.Months, age.Days);

            /*
            DateTime Now = dateOn.Value;
            int Years = new DateTime(DateTime.Now.Subtract(Dob.Value).Ticks).Year - 1;
            DateTime PastYearDate = Dob.Value.AddYears(Years);
            int Months = 0;
            for (int i = 1; i <= 12; i++)
            {
                if (PastYearDate.AddMonths(i) == Now)
                {
                    Months = i;
                    break;
                }
                else if (PastYearDate.AddMonths(i) >= Now)
                {
                    Months = i - 1;
                    break;
                }
            }
            int Days = Now.Subtract(PastYearDate.AddMonths(Months)).Days;
            int Hours = Now.Subtract(PastYearDate).Hours;
            int Minutes = Now.Subtract(PastYearDate).Minutes;
            int Seconds = Now.Subtract(PastYearDate).Seconds;
             
            return String.Format("{0}y {1}m {2}d", Years, Months, Days);
           */
        }
        private static int CalculateAge(DateTime dateOfBirth)
        {
            int age = 0;
            age = DateTime.Now.Year - dateOfBirth.Year;
            if (DateTime.Now.DayOfYear < dateOfBirth.DayOfYear)
                age = age - 1;

            return age;
        }
    }
}