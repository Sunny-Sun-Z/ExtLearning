﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Core.Extensions
{
    public static class ObjectExtensions
    {

        public static bool JsonCompare<T>(this T val1, T val2)
        {
            if (ReferenceEquals(val1, val2)) return true;
            if ((val1 == null) || (val2 == null)) return false;
            if (val1.GetType() != val2.GetType()) return false;

            var objJson = JsonConvert.SerializeObject(val1);
            var anotherJson = JsonConvert.SerializeObject(val2);

            return objJson == anotherJson;
        }

        public static List<Variance> DetailedCompare<T>(this T val1, T val2)
        {
            List<Variance> variances = new List<Variance>();
            var fi = val1.GetType().GetProperties();
            foreach (var f in fi)
            {
                Variance v = new Variance();
                v.Property = f.Name;
                v.ValueA = f.GetValue(val1);
                v.ValueB = f.GetValue(val2);
                if ((v.ValueA != null && !v.ValueA.Equals(v.ValueB)) || (v.ValueA == null && v.ValueA != v.ValueB))
                    variances.Add(v);

            }
            return variances;
        }

        public class Variance
        {
            public string Property { get; set; }
            public object ValueA { get; set; }
            public object ValueB { get; set; }
        }

    }
}