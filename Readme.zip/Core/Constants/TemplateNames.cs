﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Core.Constants
{
    public  sealed class TemplateNames
    {
        public const string CaseEliminationFormNotification = "CaseEliminationFormNotification.html";
        public const string CaseStatusNotification = "CaseStatusNotification.html";
        public const string NewCaseNotification = "NewCaseNotification.html";
        public const string NewUserNotification = "NewUserNotification.html";
        public const string EliminationList = "EliminationList.html";
        public const string EliminationRequest = "EliminationRequest.html";
		
    }
}