﻿using DCF.SACWIS.CRS.Web.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DCF.SACWIS.CRS.Web.Core
{
  public  interface INotificationSender
    {
      Task NotifyAsync(string email, string subject, string message, Action<object, AsyncCompletedEventArgs> callback);
      Task NotifyAsync(MessageModel message, Action<object, AsyncCompletedEventArgs> callback);

      void Notify(MessageModel message, Action<object, AsyncCompletedEventArgs> callback);
      void Notify(string email, string subject, string message, Action<object, AsyncCompletedEventArgs> callback);

      void SmsNotify(MessageModel message, Action<object, AsyncCompletedEventArgs> callback);
      void SmsNotify(string number, string subject, string message, IDictionary<string, object> data, Action<object, AsyncCompletedEventArgs> callback);


    }
}
