﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Models
{
    public class RuleBuilder
    {
        List<Models.DB.Rule> rules = null;
        List<RuleModel> ruleList = null;
        CaseReviewEntityModel model = null;
        List<RuleModel> failedList = new List<RuleModel>();
        List<string> modifiedItems = new List<string>();
        public RuleBuilder(List<string> modifiedItems, List<Models.DB.Rule> rules, CaseReviewEntityModel model)
        {
            this.rules = rules;
            this.model = model;
            this.modifiedItems = modifiedItems;
            ruleList = new List<RuleModel>();
        }
        public List<RuleModel> Build()
        {
            foreach (var rule in rules)
            {
                ExpressionType binaryType;
                Enum.TryParse(rule.Operator, true, out binaryType);

                var r = new RuleModel
                {
                    Id = rule.Id,
                    ClassName = rule.Predicate.Substring(0, rule.Predicate.IndexOf("::")),
                    Category = rule.Predicate.Substring(0, rule.Predicate.IndexOf("::")).Replace("Model", "").ToLower(),
                    RuleSetName = rule.RuleSetName,
                    Required = rule.Required,
                    ErrorMessage = rule.ErrorMessage,
                    IsRuleSet = rule.IsRuleSet ?? false,
                    DataType = rule.DataType,
                    PropertyName = rule.PropertyName,
                    Operator = binaryType,
                    TargetValue = rule.TargetValue
                };

                if (rule.TargetValue.Equals("*Empty*", StringComparison.OrdinalIgnoreCase))
                    r.TargetValue = string.Empty;
                else if (rule.TargetValue.Equals("*Null*", StringComparison.OrdinalIgnoreCase))
                    r.TargetValue = null;
                else if (rule.TargetValue.ToLower().Contains("*count"))
                {
                    string result = Regex.Replace(rule.TargetValue, @"[^\d]", "");
                    int v;
                    int.TryParse(result, out v);
                    r.TargetValue = v;
                    r.IsArray = true;
                    r.ListOperator = GetListOperator(rule.TargetValue);
                }
                else
                {
                    var clsObj = GetTargetObjectFromName(model, r.ClassName);
                    if (clsObj != null)
                        r.TargetValue = GetTargetValueFromValue(clsObj, rule.PropertyName, rule.TargetValue);

                }

                if (!string.IsNullOrEmpty(rule.TargetValue1))
                {
                    var clsName = rule.TargetValue1.Substring(0, rule.TargetValue1.IndexOf("::"));
                    var propertyName = rule.TargetValue1.Substring(rule.TargetValue1.IndexOf("::") + 2);
                    var clsObj = GetTargetObjectFromName(model, clsName);
                    if (clsObj != null)
                        r.TargetValue = GetTargetValueFromType(clsObj, propertyName);

                }

                ruleList.Add(r);
            }
            ruleList = ruleList.Where(w => modifiedItems.Contains(w.Category)).ToList();
            return ruleList;
        }

        public List<RuleModel> Process()
        {

            foreach (var r in ruleList)
            {
                try
                {


                    if (r.IsArray)
                    {


                    }
                    else
                    {

                        //var compiledRule = ExpressionBuilder.CompileRule<CaseReviewModel>(r);
                        dynamic compiledRule = null;
                        var result = true;
                        switch (r.Category)
                        {
                            case "casereview":
                                compiledRule = ExpressionBuilder.CompileRule<CaseReviewModel>(r);
                                result = compiledRule.Invoke(model.CaseReview);
                                break;
                            case "facesheet":
                                compiledRule = ExpressionBuilder.CompileRule<FaceSheetModel>(r);
                                result = compiledRule.Invoke(model.FaceSheet);
                                break;
                            case "item1":
                                compiledRule = ExpressionBuilder.CompileRule<Item1Model>(r);
                                result = compiledRule.Invoke(model.Item1);
                                break;
                            case "item2":
                                compiledRule = ExpressionBuilder.CompileRule<Item2Model>(r);
                                result = compiledRule.Invoke(model.Item2);
                                break;
                            case "item3":
                                compiledRule = ExpressionBuilder.CompileRule<Item3Model>(r);
                                result = compiledRule.Invoke(model.Item3);
                                break;
                            case "item4":
                                compiledRule = ExpressionBuilder.CompileRule<Item4Model>(r);
                                result = compiledRule.Invoke(model.Item4);
                                break;
                            case "item5":
                                compiledRule = ExpressionBuilder.CompileRule<Item5Model>(r);
                                result = compiledRule.Invoke(model.Item5);
                                break;
                            case "item6":
                                compiledRule = ExpressionBuilder.CompileRule<Item6Model>(r);
                                result = compiledRule.Invoke(model.Item6);
                                break;
                            case "item7":
                                compiledRule = ExpressionBuilder.CompileRule<Item7Model>(r);
                                result = compiledRule.Invoke(model.Item7);
                                break;
                            case "item8":
                                compiledRule = ExpressionBuilder.CompileRule<Item8Model>(r);
                                result = compiledRule.Invoke(model.Item8);
                                break;
                            case "item9":
                                compiledRule = ExpressionBuilder.CompileRule<Item9Model>(r);
                                result = compiledRule.Invoke(model.Item9);
                                break;
                            case "item10":
                                compiledRule = ExpressionBuilder.CompileRule<Item10Model>(r);
                                result = compiledRule.Invoke(model.Item10);
                                break;
                            case "item11":
                                compiledRule = ExpressionBuilder.CompileRule<Item11Model>(r);
                                result = compiledRule.Invoke(model.Item11);
                                break;
                            case "item12":
                                compiledRule = ExpressionBuilder.CompileRule<Item12Model>(r);
                                result = compiledRule.Invoke(model.Item12);
                                break;
                            case "item12a":
                                compiledRule = ExpressionBuilder.CompileRule<Item12AModel>(r);
                                result = compiledRule.Invoke(model.Item12A);
                                break;
                            case "item12b":
                                compiledRule = ExpressionBuilder.CompileRule<Item12BModel>(r);
                                result = compiledRule.Invoke(model.Item12B);
                                break;
                            case "item12c":
                                compiledRule = ExpressionBuilder.CompileRule<Item12CModel>(r);
                                result = compiledRule.Invoke(model.Item12C);
                                break;
                            case "item13":
                                compiledRule = ExpressionBuilder.CompileRule<Item13Model>(r);
                                result = compiledRule.Invoke(model.Item13);
                                break;
                            case "item14":
                                compiledRule = ExpressionBuilder.CompileRule<Item14Model>(r);
                                result = compiledRule.Invoke(model.Item14);
                                break;
                            case "item15":
                                compiledRule = ExpressionBuilder.CompileRule<Item15Model>(r);
                                result = compiledRule.Invoke(model.Item5);
                                break;
                            case "item16":
                                compiledRule = ExpressionBuilder.CompileRule<Item6Model>(r);
                                result = compiledRule.Invoke(model.Item6);
                                break;
                            case "item17":
                                compiledRule = ExpressionBuilder.CompileRule<Item17Model>(r);
                                result = compiledRule.Invoke(model.Item7);
                                break;
                            case "item18":
                                compiledRule = ExpressionBuilder.CompileRule<Item18Model>(r);
                                result = compiledRule.Invoke(model.Item8);
                                break;

                        }
                        if (compiledRule != null)
                        {
                            if (!result)
                            {
                                failedList.Add(r);
                            }
                        }

                    }
                }
                catch (Exception ex)
                {
                   
                }
            }
            //var compiledRules = ExpressionBuilder.CompileRules<CaseReviewModel>(ruleList).ToList();
            return failedList;
        }

        private object GetTargetObjectFromName(CaseReviewEntityModel model, string clsName)
        {
            switch (clsName)
            {
                case "CaseReview":
                case "CaseReviewModel":
                    return model.CaseReview;
                case "FaceSheet":
                case "FaceSheetModel":
                    return model.FaceSheet;
                case "Item1Model":
                    return model.Item1;

                default:
                    return null;
            }
        }

        private dynamic GetTargetValueFromType(object atype, string propertyName)
        {
            if (atype == null) return null;
            Type t = atype.GetType();


            PropertyInfo[] props = t.GetProperties();
            foreach (PropertyInfo p in props)
            {

                System.Type propertyType = p.PropertyType;

                // Get the type code so we can switch
                System.TypeCode typeCode = System.Type.GetTypeCode(propertyType);

                if (p.Name.Equals(propertyName, StringComparison.OrdinalIgnoreCase))
                {
                    object value = p.GetValue(atype, new object[] { });
                    if (value == null)
                        return null;
                    switch (typeCode)
                    {
                        case TypeCode.Int16:
                            return Convert.ToInt16(value);
                        case TypeCode.Int32:
                            return Convert.ToInt32(value);
                        case TypeCode.Int64:
                            return Convert.ToInt64(value);
                        case TypeCode.DateTime:
                            return Convert.ToDateTime(value);
                        case TypeCode.Boolean:
                            return Convert.ToBoolean(value);
                        case TypeCode.String:
                            return (string)value;
                        case TypeCode.Object:
                            return Convert.ChangeType(value, typeCode);

                            if (propertyType == typeof(Guid) || propertyType == typeof(Guid?))
                            {
                                return null;
                            }
                            else if (propertyType == typeof(Int16?))
                                return (Int16?)Convert.ToInt16(value);
                            else if (propertyType == typeof(Int32?))
                                return (Int32?)Convert.ToInt32(value);
                            else if (propertyType == typeof(Int64?))
                                return (Int64?)Convert.ToInt64(value);
                            else if (propertyType == typeof(DateTime?))
                                return (DateTime?)Convert.ToDateTime(value);
                            else if (propertyType == typeof(Boolean?))
                                return (Boolean?)Convert.ToBoolean(value);

                            break;
                        default:
                            return value;
                    }
                    return value;
                }
            }
            return null;
        }
        private dynamic GetTargetValueFromValue(object atype, string propertyName, string value)
        {
            if (atype == null) return null;
            Type t = atype.GetType();


            PropertyInfo[] props = t.GetProperties();
            foreach (PropertyInfo p in props)
            {

                System.Type propertyType = p.PropertyType;

                // Get the type code so we can switch
                System.TypeCode typeCode = System.Type.GetTypeCode(propertyType);


                if (p.Name.Equals(propertyName, StringComparison.OrdinalIgnoreCase))
                {

                    if (string.IsNullOrEmpty(value))
                        return null;
                    switch (typeCode)
                    {
                        case TypeCode.Int16:
                            return Convert.ToInt16(value);
                        case TypeCode.Int32:
                            return Convert.ToInt32(value);
                        case TypeCode.Int64:
                            return Convert.ToInt64(value);
                        case TypeCode.DateTime:
                            return Convert.ToDateTime(value);
                        case TypeCode.Boolean:
                            return Convert.ToBoolean(value);
                        case TypeCode.String:
                            return (string)value;
                        case TypeCode.Object:
                            // return Convert.ChangeType(value, typeCode);

                            if (propertyType == typeof(Guid) || propertyType == typeof(Guid?))
                            {
                                return null;
                            }
                            else if (propertyType == typeof(Int16?))
                                return (Int16?)Convert.ToInt16(value);
                            else if (propertyType == typeof(Int32?))
                                return (Int32?)Convert.ToInt32(value);
                            else if (propertyType == typeof(Int64?))
                                return (Int64?)Convert.ToInt64(value);
                            else if (propertyType == typeof(DateTime?))
                                return (DateTime?)Convert.ToDateTime(value);
                            else if (propertyType == typeof(Boolean?))
                                return (Boolean?)Convert.ToBoolean(value);

                            break;
                        default:
                            return value;
                    }
                    return value;
                }
            }
            return null;
        }

        private System.Linq.Expressions.ExpressionType GetListOperator(string str)
        {
            if (str.Contains(">="))
                return System.Linq.Expressions.ExpressionType.GreaterThanOrEqual;
            else if (str.Contains(">"))
                return System.Linq.Expressions.ExpressionType.GreaterThan;
            else if (str.Contains("<="))
                return System.Linq.Expressions.ExpressionType.LessThanOrEqual;
            else if (str.Contains("<"))
                return System.Linq.Expressions.ExpressionType.LessThan;
            else
                return System.Linq.Expressions.ExpressionType.Equal;

        }

        public List<RuleModel> FailedItems
        {
            get
            {
                return failedList;
            }
        }
        public Boolean IsFailed
        {
            get
            {
                return failedList.Count() > 0;
            }
        }
        public Boolean HasBusinessRequired
        {
            get
            {
                return failedList.Count(w => w.Required) > 0;
            }
        }
    }

}