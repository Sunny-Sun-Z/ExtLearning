﻿using DCF.SACWIS.CRS.Web.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Core
{
    public class MessageBuilder
    {
        MessageModel message;
        string tempalteFileName;
        public MessageBuilder(UserModel sender,string subject, string tempalteFileName)
        {
            message = new MessageModel
            {
                ReceiverId=sender.UserID,
                ReceiverName=sender.LoginID,
                ReceiverFullName=string.Concat(sender.FirstName, " ", sender.LastName),
                ReceiverEmail=sender.Email,
                Status=Enums.NotificationStatusEnum.Pending,
                Type=Enums.NotificationTypeEnum.Email,
                CreatedTime=DateTime.UtcNow,
                Subject=subject
            };
            this.tempalteFileName = tempalteFileName;
        }
        public MessageModel Build<T>(T item)
        {

            var content = File.ReadAllText(tempalteFileName);
            message.Body = content;
            return message;
        }
    }
}