﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Core.Enums
{
    public enum NotificationTypeEnum
    {
        Email = 1, SMS = 2, Web = 3, Phone=4
    }
}