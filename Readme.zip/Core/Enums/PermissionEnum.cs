﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Core.Enums
{
    public enum PermissionEnum
    {
        ViewCaseReadOnly = 1,
        CreateCaseReview = 2,
        EliminateCase = 3,
        ViewCaseLevelReports = 4,
        CompleteAdministration = 12,
        SecurityManagement = 13,
        AssignAsQARoleWithinCase = 14,
        AssignAsSecondaryOversigthWithinCase = 15,
        Enter_EditCaseData = 16,
        AccessHelpTab = 17,
        AccessReportsTab_DownloadReports = 18,
        AccessReviewLevelReports = 19,
        SubmitCaseToQA = 20,
        Add_EditQANotes = 21,
        OverrideRating = 22,
        ApproveEliminatedCases = 23,
        TransferBackToDataEntryMode = 24,
        FinalizeCase = 25,
        Access_EditCaseSetupPage = 26,
        AssignSelfAsReviewer = 27,
        ITAdministrator = 28,
        SubmitToFinalize = 29,
        SubmitBackToQA = 30,
        IRRTab = 31,
        CreateIRRCase = 32,
        EditIRRCase = 33,
        ShowAllIRRCases = 34,
        ShowInterviewNotes = 35,
        FinalizeImportCases = 36,
        ExportCase = 37,
        ImportCase = 38,
        ExportImportTab = 39,
        AutomatedSampling=40

    }
}