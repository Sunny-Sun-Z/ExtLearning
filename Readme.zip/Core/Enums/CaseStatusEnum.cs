﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Core.Enums
{
    public enum CaseStatusEnum
    {
        DataEntryComplete=1,
        InProgress = 2,
        NotStarted = 3,
        QaInProgress = 4,
        Finalized = 5,
        Eliminated = 6,
        Approved = 7,
        CaseEliminatedPendingApproval = 8,

    }
}