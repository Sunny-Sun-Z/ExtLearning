﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Core.Enums
{
    public enum NotificationStatusEnum
    {
        Pending=1,
        Queue=2,
        Processed=3,
        Failed=99

    }
}