﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCF.SACWIS.CRS.Web.Core.Enums
{
    public enum ReviewTypeEnum
    {
        CFSR=2,
        ACR=3,
        IRR=4
    }
}