/**
 * Created by kkora on 2/21/2018.
 */
Ext.define('QuickStart.view.sampling.SamplingController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.sampling',
    mixins: ['QuickStart.mixins.Global'],


    init: function () {

    },
    onTabFilter: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            tabType = btn.tabType;

        var tabs = btn.up().items.items;
        for (i = 0; i < tabs.length; i++) {
            tabs[i].setUI('default-toolbar');
        }
        btn.setUI('soft-green');

        vm.set('current.tabType', tabType);

        me.onSearch();
    },
    onReviewPeriodStoreLoad: function (store) {
        if (store.getCount() > 2) {
            var me = this,
                vm = me.getViewModel(),
                record = store.getAt(1);

            if (record.get('Id') > 0)
                this.lookupReference('reviewPeriod').setValue(record.get('Id'));

            vm.set('current.reviewPeriod', record.getData());
            vm.set('current.selectedReviewPeriod', record.get('Id'));

            setTimeout(function () {
                me.updateStatusWidget();
                me.onResetSearch();
            }, 50);
        }
    },
    onReviewPeriodSelected: function (field) {
        //console.log('onReviewPeriodSelected', field.getValue());
        var me = this, vm = me.getViewModel();
        if (field.getValue() === -1) {
            var reviewPeriod = Ext.create('QuickStart.model.sampling.ReviewPeriod');
            vm.set('current.reviewPeriod', reviewPeriod);
            win = me.getView().down('#addReviewWindow');
            win.show(field);
        }
        else {
            var record = field.findRecord(field.valueField, field.getValue());
            vm.set('current.reviewPeriod', record.getData());
            vm.set('current.selectedReviewPeriod', field.getValue());
            me.updateStatusWidget();
            me.onResetSearch();
        }
    },
    onWindowCancel: function (owner) {
        if (owner.isWindow)
            owner.hide();
        else
            owner.up('window').close();

        var me = this,
            vm = me.getViewModel();

        this.lookupReference('reviewPeriod').setValue(vm.get('current.selectedReviewPeriod'));

    },
    onGenerateReviewPeriod: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            reviewPeriodsStore = vm.getStore('reviewPeriods'),
            window = btn.up('window'),
            record = vm.get('current.reviewPeriod'),
            data = record.getData();

        Ext.Msg.show({
            title: 'Confirmation?',
            message: 'Are you sure you want to generate sample for this review period?',
            buttons: Ext.Msg.YESNO,
            icon: Ext.Msg.QUESTION,
            fn: function (btn1) {
                if (btn1 === 'yes') {
                    var myMask = new Ext.LoadMask({ msg: 'Please wait...', target: window }),
                        action = 'sampling/GenerateSamplingforReviewPeriod';

                    myMask.show();
                    Ext.Ajax.request({
                        timeout: 1000 * 60 * 2,//2 minutes
                        url: QuickStart.util.Global.getApi() + action,
                        method: 'POST',
                        params: { userID: QuickStart.util.Global.getUser().id },
                        jsonData: data,
                        success: function (response, opts) {
                            myMask.hide();
                            var result = Ext.decode(response.responseText);
                            if (result !== null) {
                                if (result.success) {
                                    QuickStart.util.Global.showMessage(result.message);
                                    reviewPeriodsStore.reload();
                                    window.close();

                                    vm.set('current.reviewPeriod', result.review);
                                    Ext.defer(function () {
                                        me.lookupReference('reviewPeriod').setValue(result.review.Id);
                                        me.onResetSearch();
                                    }, 500, this);

                                }
                                else {
                                    Ext.Msg.alert('Status', result.message);
                                }
                            }
                        },
                        failure: function (response, opts) {
                            myMask.hide();
                            var result = Ext.decode(response.responseText);
                            Ext.Msg.alert('Error', result.message);
                            console.log('server-side failure with status code ' + response.status);
                        },
                        scope: this
                    });
                }
            }
        });
    },
    updateStatusWidget: function (store) {
        var me = this,
            vm = me.getViewModel(),
            reviewPeriod = vm.get('current.reviewPeriod'),
            myMask = new Ext.LoadMask({ msg: 'Please wait...', target: me.getView() }),
            url = 'sampling/SampleDashboardWidget',
            ReviewPeriodId = 0;

        if (reviewPeriod)
            ReviewPeriodId = reviewPeriod.Id || 0;

        Ext.Ajax.request({
            url: url,
            method: 'GET',
            params: {
                reviewPeriodId: ReviewPeriodId
            },
            success: function (response, opts) {
                var result = Ext.decode(response.responseText);
                if (result !== null) {
                    if (!Ext.isEmpty(result.data)) {
                        vm.set('widgets', result.data);
                    }
                }
            },
            failure: function (response, opts) {
                myMask.hide();
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });
    },

    onRegionSelected: function (field) {
        var me = this,
            vm = me.getViewModel(),
            store = vm.getStore('locations'),
            officeField = field.up('form').getForm().findField('office'),
            filters = [];

        if (officeField) {
            officeField.setValue();
        }
        if (field.getValue()) {
            filters.push({ property: 'RegionId', value: field.getValue() });
            store.clearFilter();
            store.setFilters(filters);
        }
        else {
            store.clearFilter();
        }
    },
    onSearch: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            form = me.getView().down('form').getForm(),
            values = form.getValues(),
            store = vm.getStore('samplingStore'),
            reviewPeriod = vm.get('current.reviewPeriod'),
            tabType = vm.get('current.tabType'),
            filters = [];

        if (reviewPeriod)
            values.ReviewPeriodId = reviewPeriod.Id || 0;

        values.tabType = tabType || 'P';

        filters.push({ property: 'filter', value: Ext.encode(values) });

        store.setFilters(filters);
    },
    onResetSearch: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            form = me.getView().down('form').getForm(),
            locationStore = vm.getStore('locations');
        form.reset();
        locationStore.clearFilter();
        me.onSearch();
    },
    exportTo: function (btn) {
        var cfg = Ext.merge({
            title: 'Grid export',
            fileName: 'GridExport' + '.' + (btn.cfg.ext || btn.cfg.type)
        }, btn.cfg);

        var grid = btn.up('pipreviewgrid');
        //grid.saveDocumentAs(cfg);
        grid.saveDocumentAs({
            type: 'excel',
            title: 'Monthly Schedule of PIP Reviews by Office and Sample Group (In-Home/Foster Care)',
            fileName: 'myExport.xml'
        });

    },
    onOptionsArrowClick: function (btn, e) {
        var me = this,
            vm = me.getViewModel(),
            tabType = vm.get('current.tabType') || 'P';

        var menus = [{
            iconCls: 'x-fa fa-search',
            ui: 'gray',
            text: '<strong>Case Details</strong>',
            handler: 'onCaseDetailButtonClick'
        }];

        if (tabType === 'P') {
            menus.push({
                iconCls: 'x-fa fa-user-circle',
                ui: 'gray',
                text: '<strong>Face Sheet</strong>',
                handler: 'onFaceSheetButtonClick'
            });
        }

        if (btn.up().actionPosition) {
            var record = btn.up().actionPosition.record.getData();
            vm.set('current.caseDetail', record);
        }

        if (btn.getMenu().items.length !== menus.length) {
            btn.setMenu(menus);
            Ext.defer(function () {
                btn.showMenu();
            }, 100, this);
        }
    },
    onCaseDetailButtonClick: function (btn) {
        var me = this,
            vm = me.getViewModel();
        var record = vm.get('current.caseDetail');

        var myMask = new Ext.LoadMask({ msg: 'Please wait...', target: btn }),
            action = 'sampling/' + record.ID;

        myMask.show();
        Ext.Ajax.request({
            url: QuickStart.util.Global.getApi() + action,
            success: function (response) {
                myMask.hide();
                var result = Ext.decode(response.responseText);
                if (result !== null) {
                    if (result.success) {
                        vm.set('current.caseDetail', Ext.create('QuickStart.model.sampling.SampleCase', result.data));
                        win = me.getView().down('#caseWindow');
                        win.show(btn);
                    }
                    else {
                        Ext.Msg.alert('Status', result.message);
                    }
                }
            },
            failure: function (response) {
                myMask.hide();
                var result = Ext.decode(response.responseText);
                Ext.Msg.alert('Error', result.message);
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });
    },
    onFaceSheetButtonClick: function (btn) {
        var me = this,
            vm = me.getViewModel();
        var record = vm.get('current.caseDetail');

        if (record.CaseReviewRootID) {
            this.redirectTo('#case/' + record.CaseReviewRootID);
            //QuickStart.util.Global.showMessage('This functionality is not implemented in this version of CRS application but you will be transfer to case review facesheet screen once it implemented.');
        }
        else {
            if (!QuickStart.util.Global.permissions.allowCreateCaseReview()) {
                QuickStart.util.Global.showMessage('You do not have sufficient permission to create a case in CRS. Please contact administrator.');
                return;
            }
            this.redirectTo('#newcase/' + record.ID);
        }
    },
    onBeforeDocumentSave: function (view) {
        this.timeStarted = Date.now();
        view.mask('Document is prepared for export. Please wait ...');
        Ext.log('export started');
    },

    onDocumentSave: function (view) {
        view.unmask();
        Ext.log('export finished; time passed = ' + (Date.now() - this.timeStarted));
    },

    onDataReady: function () {
        Ext.log('data ready; time passed = ' + (Date.now() - this.timeStarted));
    }
});