﻿/**
 * Created by rkumar on 10/19/2018.
 */

Ext.define('QuickStart.view.sampling.detail.Case', {
    extend: 'QuickStart.view.common.BaseWindow',

    xtype: 'casewindow',
    requires: [
        'Ext.form.field.*',
        'Ext.layout.container.HBox',
        'Ext.form.CheckboxGroup'
    ],
    scrollable: 'y',
    closable: true,
    bodyPadding: '10 10 0 10',
    bind:
    {
        title: '{current.caseDetail.Case_Type_Desc}  - Case Details'
    },
    items: [
        {
            xtype: 'form',
            defaults: {
                bodyPadding: '10 10 0 10',
                layout: 'hbox'
            },
            items: [
                {
                    defaults: {
                        anchor: '100%',
                        xtype: 'displayfield',
                        labelWidth: 150,
                        flex: 1
                    },
                    items: [
                        {
                            fieldLabel: 'Case Id',
                            bind: '{current.caseDetail.Case_ID}'
                        }, {
                            fieldLabel: 'Case Name',
                            bind: '{current.caseDetail.Case_Name}'
                        }, {
                            fieldLabel: 'Case Status',
                            bind: '{current.caseDetail.Case_Status}'
                        }
                    ]
                }, {
                    defaults: {
                        anchor: '100%',
                        xtype: 'displayfield',
                        labelWidth: 150,
                        flex: 1
                    },
                    items: [
                        {
                            fieldLabel: 'Sample Type',
                            bind: '{current.caseDetail.SampleType_Desc}'
                        },
                        {
                            fieldLabel: 'Primary Language',
                            bind: '{current.caseDetail.Primary_Language}'
                        }, {
                            fieldLabel: 'Home Town',
                            bind: '{current.caseDetail.HomeTown}'
                        }
                    ]
                }, {
                    defaults: {
                        anchor: '100%',
                        xtype: 'displayfield',
                        labelWidth: 150,
                        flex: 1
                    },
                    items: [
                        {
                            fieldLabel: 'Region Name',
                            bind: '{current.caseDetail.Region_Name}'
                        }, {
                            fieldLabel: 'Office Name',
                            bind: '{current.caseDetail.Office_Name}'
                        },{
                            fieldLabel: ''
                        }
                    ]
                }, {
                    defaults: {
                        anchor: '100%',
                        xtype: 'displayfield',
                        labelWidth: 150,
                        flex: 1
                    },
                    bind:
                    {
                        hidden: '{current.caseDetail.IsPrimary == false}'
                    },
                    items: [
                       {
                            fieldLabel: 'Review Month',
                            renderer: Ext.util.Format.dateRenderer('M-Y'),
                            bind: '{current.caseDetail.ReviewMonth}'
                        }, {
                            fieldLabel: 'Reviewer Name',
                            bind: '{current.caseDetail.Reviewers}'
                            //bind: '{current.caseDetail.Reviewer_Name}'
                        }, {
                            fieldLabel: ''
                        }
                    ]
                }, {
                    defaults: {
                        anchor: '100%',
                        xtype: 'displayfield',
                        labelWidth: 150,
                        flex: 1
                    },
                    items: [
                        {
                            fieldLabel: 'Eliminated',
                            bind: '{current.caseDetail.IsEliminated_Desc}'
                        }, {
                            fieldLabel: 'Eliminated Date',
                            renderer: Ext.util.Format.dateRenderer('m-d-Y'),
                            bind: '{current.caseDetail.TS_Eliminated}'
                        }, {
                            fieldLabel: 'Recent Assignment Type',
                            bind:
                            {
                                value: '{current.caseDetail.RCNT_ASSIGN_TYPE}',
                                hidden: '{current.caseDetail.Case_Type === "FC"}'
                            }
                        }, {
                            fieldLabel: '',
                            bind: { hidden: '{current.caseDetail.Case_Type === "IH"}' }
                        }
                    ]
                }, {
                    defaults: {
                        anchor: '100%',
                        xtype: 'displayfield',
                        labelWidth: 150,
                        flex: 1
                    },
                    items: [
                        {
                            fieldLabel: 'Social Worker',
                            bind: '{current.caseDetail.WorkerInfo.LastName}, {current.caseDetail.WorkerInfo.FirstName}'
                        }, {
                            fieldLabel: 'Supervisor',
                            bind: '{current.caseDetail.WorkerInfo.SupervisorLastName}, {current.caseDetail.WorkerInfo.SupervisorFirstName}'
                        }, {
                            fieldLabel: 'Manager',
                            bind: '{current.caseDetail.WorkerInfo.ManagerLastName}, {current.caseDetail.WorkerInfo.ManagerFirstName}'
                        }
                    ]
                }, {
                    defaults: {
                        anchor: '100%',
                        xtype: 'displayfield',
                        labelWidth: 150,
                        flex: 1
                    },
                    bind:
                    {
                        hidden: '{current.caseDetail.Case_Type === "FC"}'
                    },
                    items: [
                        {
                            fieldLabel: 'Case Open Date',
                            renderer: Ext.util.Format.dateRenderer('m-d-Y'),
                            bind:'{current.caseDetail.DT_CASE_OPN}'
                        }, {
                            fieldLabel: 'Recent Assign Start Date',
                            renderer: Ext.util.Format.dateRenderer('m-d-Y'),
                            bind:'{current.caseDetail.RCNT_ASSIGN_START}'
                            
                        }, {
                            fieldLabel: 'Recent Assign End Date',
                            renderer: Ext.util.Format.dateRenderer('m-d-Y'),
                            bind:'{current.caseDetail.RCNT_ASSIGN_END}'
                            
                        }
                    ]
                }, {
                    defaults: {
                        anchor: '100%',
                        xtype: 'displayfield',
                        labelWidth: 150,
                        flex: 1
                    },
                    bind:
                    {
                        hidden: '{current.caseDetail.Case_Type === "FC"}'
                    },
                    items: [
                         {
                            fieldLabel: 'Days Open',
                            bind:
                            {
                                value: '{current.caseDetail.DAYS_OPEN_SMPL_PRD}'
                            }
                        }
                    ]
                },{
                    defaults: {
                        anchor: '100%',
                        xtype: 'displayfield',
                        labelWidth: 150,
                        flex: 1
                    },
                    bind:
                    {
                        hidden: '{current.caseDetail.Case_Type === "IH"}'
                    },
                    items: [
                        {
                            fieldLabel: 'Child Name',
                            bind: '{current.caseDetail.ChildName}'
                        }, {
                            fieldLabel: 'Child Type',
                            bind: '{current.caseDetail.TypeChild}'
                        }, {
                            fieldLabel: 'Child DOB',
                            renderer: Ext.util.Format.dateRenderer('m-d-Y'),
                            bind: '{current.caseDetail.Child_DOB}'
                        }
                    ]
                }, {
                    defaults: {
                        anchor: '100%',
                        xtype: 'displayfield',
                        labelWidth: 150,
                        flex: 1
                    },
                    bind:
                    {
                        hidden: '{current.caseDetail.Case_Type === "IH"}'
                    },
                    items: [
                        {
                            fieldLabel: 'Child Sex',
                            bind: '{current.caseDetail.SEX}'
                        }, {
                            fieldLabel: 'Child Race',
                            bind: '{current.caseDetail.ChildRace}'
                        }, {
                            fieldLabel: 'Child Hispanic',
                            bind: '{current.caseDetail.HISPNC}'
                        }
                    ]
                },
                {
                    defaults: {
                        anchor: '100%',
                        xtype: 'displayfield',
                        labelWidth: 150,
                        flex: 1
                    },
                    bind:
                    {
                        hidden: '{current.caseDetail.Case_Type === "IH"}'
                    },
                    items: [
                        {
                            fieldLabel: 'Age',
                            bind: '{current.caseDetail.AGE_RPT_DT}'
                        }, {
                            fieldLabel: 'Ever Adopted',
                            bind: '{current.caseDetail.EVER_ADOPTED}'
                        }, {
                            fieldLabel: 'Age at the time of Adoption',
                            bind: '{current.caseDetail.ADPTN_AGE}'
                        }
                    ]
                },
                {
                    defaults: {
                        anchor: '100%',
                        xtype: 'displayfield',
                        labelWidth: 150,
                        flex: 1
                    },
                    bind:
                    {
                        hidden: '{current.caseDetail.Case_Type === "IH"}'
                    },
                    items: [
                        {
                            fieldLabel: 'First Removal Date',
                            bind: '{current.caseDetail.FRST_RMVL_DATE}'
                        },
                        {
                            fieldLabel: 'Recent Removal Date',
                            bind: '{current.caseDetail.RCNT_RMVL_DATE}'
                        }, {
                            fieldLabel: '# of Episodes',
                            bind: '{current.caseDetail.TTL_RMVLS}'
                        }
                    ]
                }, {
                    defaults: {
                        anchor: '100%',
                        xtype: 'displayfield',
                        labelWidth: 150,
                        flex: 1
                    },
                    bind:
                    {
                        hidden: '{current.caseDetail.Case_Type === "IH"}'
                    },
                    items: [
                        {
                            fieldLabel: 'Latest Discharge Date',
                            bind: '{current.caseDetail.LST_DSCHRG_DATE}'
                        },
                        {
                            fieldLabel: 'Current Placement Start Date',
                            bind: '{current.caseDetail.CRRNT_PLCMNT_STRT_DT}'
                        }, {
                            fieldLabel: 'Previous # of Placement Episode',
                            bind: '{current.caseDetail.PREV_PLCMNTS_IN_EPSD}'
                        }
                    ]
                }, {
                    defaults: {
                        anchor: '100%',
                        xtype: 'displayfield',
                        labelWidth: 150,
                        flex: 1
                    },
                    bind:
                    {
                        hidden: '{current.caseDetail.Case_Type === "IH"}'
                    },
                    items: [
                        {
                            fieldLabel: 'Placement Settings',
                            bind: '{current.caseDetail.PLCMNT_SETTING}'
                        },
                        {
                            fieldLabel: 'Placement out of State',
                            bind: '{current.caseDetail.PLCMNT_OUTOFSTATE}'
                        }, {
                            fieldLabel: 'Recent Permanant Goal',
                            bind: '{current.caseDetail.RCNT_PERM_GOAL}'
                        }
                    ]
                },
                {
                    defaults: {
                        anchor: '100%',
                        xtype: 'displayfield',
                        labelWidth: 150,
                        flex: 1
                    },
                    bind:
                    {
                        hidden: '{current.caseDetail.Case_Type === "IH"}'
                    },
                    items: [
                       {
                            fieldLabel: 'Removal Manner',
                            bind: '{current.caseDetail.RMVL_MANNER}'
                        }, {
                            fieldLabel: 'Clinically Diagnose Disability',
                            bind: '{current.caseDetail.CLIN_DIAGN_DSBLTY}'
                        }, {
                            fieldLabel: ''
                        }
                    ]
                },
                {
                    xtype: 'fieldset',
                    title: 'Reason for Removal',
                    layout: 'anchor',
                    defaults: {
                        anchor: '100%',
                        hideEmptyLabel: false
                    },
                    bind:
                    {
                        hidden: '{current.caseDetail.Case_Type === "IH"}'
                    },
                    items: [
                        {
                            xtype: 'checkboxgroup',
                            bodyPadding: '10 10 0 10',
                            labelSeparator: '',
                            labelWidth: '100%',
                            labelAlign: 'top',
                            columns: 4,
                            vertical: true,
                            defaults: { name: 'CaseReasons' },
                            bind: { value: '{current.caseDetail.CaseReasons}' },
                            //value: { 'CaseReasons': [1, 3, 10, 15] },
                            items: [
                                { boxLabel: 'Physical Abuse', inputValue: 1 },
                                { boxLabel: 'Sexual abuse', inputValue: 2 },
                                { boxLabel: 'Neglect', inputValue: 3 },
                                { boxLabel: 'Alcohol Abuse (Child)', inputValue: 4 },
                                { boxLabel: 'Drug Abuse (Child)', inputValue: 5 },
                                { boxLabel: 'Alcohol Abuse (Parent)', inputValue: 6 },
                                { boxLabel: 'Drug Abuse (Parent)', inputValue: 7 },
                                { boxLabel: 'Inadequate Housing', inputValue: 8 },
                                { boxLabel: 'Child\'s Behavior Problem', inputValue: 9 },
                                { boxLabel: 'Child Disability', inputValue: 10 },
                                { boxLabel: 'Incarceration of Parent(s)', inputValue: 11 },
                                { boxLabel: 'Death of Parent(s)', inputValue: 12 },
                                { boxLabel: 'Caretaker\'s Inability to Cope', inputValue: 13 },
                                { boxLabel: 'Abandonment', inputValue: 14 },
                                { boxLabel: 'Relinquishment', inputValue: 15 }
                            ]
                        }
                    ]
                }, {
                    xtype: 'fieldset',
                    title: 'Clinically Diagnosed Disabilities Contributing to Removal',
                    layout: 'anchor',
                    defaults: {
                        anchor: '100%',
                        hideEmptyLabel: false
                    },
                    bind:
                    {
                        hidden: '{current.caseDetail.Case_Type === "IH"}'
                    },
                    items: [
                        {
                            xtype: 'checkboxgroup',
                            bodyPadding: '10 10 0 10',
                            labelSeparator: '',
                            labelWidth: '100%',
                            labelAlign: 'top',
                            columns: 4,
                            vertical: true,
                            defaults: { name: 'DisableReasons' },
                            bind: { value: '{current.caseDetail.DisableReasons}' },
                            items: [
                                //{ boxLabel: 'Intellectually Disabled', inputValue: 1 },
                                { boxLabel: 'Development / Disability', inputValue: 1 },
                                { boxLabel: 'Visually / Hearing Impaired', inputValue: 2 },
                                { boxLabel: 'Physically Disabled', inputValue: 3 },
                                { boxLabel: 'Emotionally Disturbed', inputValue: 4 },
                                { boxLabel: 'Other Medically Diagnosed Conditions Requiring Special Care', inputValue: 5 }
                            ]
                        }
                    ]
                }, {
                    defaults: {
                        anchor: '100%',
                        xtype: 'displayfield',
                        labelWidth: 150,
                        flex: 1
                    },
                    bind:
                    {
                        hidden: '{current.caseDetail.Case_Type === "IH"}'
                    },
                    items: [
                        {
                            fieldLabel: 'Care Taker Family Structure',
                            bind: '{current.caseDetail.CRTKR_FMLY_STRCTR}'
                        },
                        {
                            fieldLabel: 'Care Taker 1 Birth Year',
                            bind: '{current.caseDetail.CRTKR1_BRTH_YR_TEXT}'
                        }, {
                            fieldLabel: 'Care Taker 2 Birth Year',
                            bind: '{current.caseDetail.CRTKR2_BRTH_YR_TEXT}'
                        }
                    ]
                }, {
                    defaults: {
                        anchor: '100%',
                        xtype: 'displayfield',
                        labelWidth: 150,
                        flex: 1
                    },
                    bind:
                    {
                        hidden: '{current.caseDetail.Case_Type === "IH"}'
                    },
                    items: [
                        {
                            fieldLabel: 'Mother Termination of Parental Rights',
                            bind: '{current.caseDetail.MOTHER_TPR_DT}'
                        }, {
                            fieldLabel: 'Father Termination of Parental Rights',
                            bind: '{current.caseDetail.FATHER_TPR_DT}'
                        }, {
                            fieldLabel: 'Foster Care Taker Family Structure',
                            bind: '{current.caseDetail.FO_FMLY_STRCTR}'
                        }
                    ]
                }, {
                    defaults: {
                        anchor: '100%',
                        xtype: 'displayfield',
                        labelWidth: 150,
                        flex: 1
                    },
                    bind:
                    {
                        hidden: '{current.caseDetail.Case_Type === "IH"}'
                    },
                    items: [
                        {
                            fieldLabel: 'Foster Care Taker 1 Birth Year',
                            bind: '{current.caseDetail.FO_CRTRKR1_BIRTH_YR_TEXT}'
                        }, {
                            fieldLabel: 'Foster Care Taker 1 Race',
                            bind: '{current.caseDetail.FO_CRTRKR1_RACE}'
                        }, {
                            fieldLabel: 'Foster Care Taker 1 Hispanic',
                            bind: '{current.caseDetail.FO_CRTRKR1_HISP}'
                        }
                    ]
                }, {
                    defaults: {
                        anchor: '100%',
                        xtype: 'displayfield',
                        labelWidth: 150,
                        flex: 1
                    },
                    bind:
                    {
                        hidden: '{current.caseDetail.Case_Type === "IH"}'
                    },
                    items: [
                        {
                            fieldLabel: 'Foster Care Taker 2 Birth Year',
                            bind: '{current.caseDetail.FO_CRTRKR2_BIRTH_YR_TEXT}'
                        }, {
                            fieldLabel: 'Foster Care Taker 2 Race',
                            bind: '{current.caseDetail.FO_CRTRKR2_RACE}'
                        }, {
                            fieldLabel: 'Foster Care Taker 2 Hispanic',
                            bind: '{current.caseDetail.FO_CRTRKR2_HISP}'
                        }
                    ]
                }, {
                    defaults: {
                        anchor: '100%',
                        xtype: 'displayfield',
                        labelWidth: 150,
                        flex: 1
                    },
                    bind:
                    {
                        hidden: '{current.caseDetail.Case_Type === "IH"}'
                    },
                    items: [
                        {
                            fieldLabel: 'Discharge Date',
                            bind: '{current.caseDetail.DISCHARGE_DT}'
                        }, {
                            fieldLabel: 'Discharge Reason',
                            bind: '{current.caseDetail.DISCHARGE_REASON}'
                        }, {
                            fieldLabel: ''
                        }
                    ]
                }
            ],
            dockedItems: [
                {
                    xtype: 'toolbar',
                    dock: 'bottom',
                    ui: 'footer',
                    items: ['->', {
                        text: 'Cancel',
                        ui: 'gray',
                        iconCls: 'x-fa fa-close',
                        handler: 'onWindowCancel'
                    }]
                }]

        }
    ],
    listeners: {
        close: 'onWindowCancel'
    }
});