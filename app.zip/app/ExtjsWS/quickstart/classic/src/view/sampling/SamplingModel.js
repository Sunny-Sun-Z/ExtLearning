/**
 * Created by kkora on 2/21/2018.
 */
Ext.define('QuickStart.view.sampling.SamplingModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.sampling',

    requires: [
        'Ext.data.proxy.Ajax',
        'Ext.data.reader.Json'
    ],

    stores: {
        samplingStore: {
            //model: 'QuickStart.model.sampling.SampleCase',
            model: 'QuickStart.model.sampling.Dashboard',
            autoLoad: true,
            pageSize: 25,
            remoteFilter: true,
            remoteSort: false,
            filters: [{ Property: 'filter', Value: '' }],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'sampling/GetSampling'
                    // read: 'case/DashboardData'
                },
                //  actionMethods: {read: 'POST'},
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },

        //federalYears: {
        //    model: 'QuickStart.model.FederalYear',
        //    autoLoad: true,
        //    //pageSize: 100,
        //    remoteFilter: false,
        //    //filters: [{ property: 'period', value: '' }],
        //    proxy: {
        //        url: QuickStart.util.Global.getApi(),
        //        type: 'ajax',
        //        paramsAsJson: true,
        //        pageParam: null,
        //        api: { read: 'lookup/GetFiscalYears' },
        //        reader: {
        //            type: 'json',
        //            rootProperty: 'data',
        //            totalProperty: 'total'
        //        }
        //    }
        //},
        locations: {
            model: 'QuickStart.model.Location',
            autoLoad: true,
            pageSize: 100,
            remoteFilter: false,
            //filters: [{ property: 'period', value: '' }],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: { read: 'lookup/GetLocations' },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },
        regions: {
            model: 'QuickStart.model.BaseLookup',
            autoLoad: true,
            pageSize: 100,
            remoteFilter: false,
            //filters: [{ property: 'period', value: '' }],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: { read: 'lookup/GetRegions' },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },
        reviewMonth: {
            type: 'months'
        },
        caseType: {
            fields: ['code', 'description'],
            data: [
                { code: 'IH', description: 'In-Home' },
                { code: 'FC', description: 'Foster Care' }
            ]
        },
        sampleType: {
            fields: ['code', 'description'],
            data: [
                { code: 'P', description: 'Primary' },
                { code: 'S', description: 'Secondary' }
            ]
        },
        isIntake: {
            fields: ['code', 'description'],
            data: [
                { code: 'true', description: 'Y' },
                { code: 'false', description: 'N' }
            ]
        },
        userStore: {
            type: 'grouplookups',
            filters: [{ property: 'group', value: 'CrSecurityUserSampling', operator: '=' }]
            // sorters: ([{property: 'name', direction: 'ASC'}])
        },
        pipReviews: {
            model: 'QuickStart.model.PipReviewSample',
            autoLoad: true,
            pageSize: 100,
            remoteFilter: true,
            filters: [{property: 'period', value: ''}],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {read: 'case/GetPipReviewSample'},
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },
        reviewPeriods:{
            model: 'QuickStart.model.sampling.ReviewPeriod',
            autoLoad: true,
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: { read: 'lookup/GetReviewSamplePeriod'},
                reader: {
                    type: 'json'
                    //rootProperty: 'data',
                    //totalProperty: 'total'
                }
            },
            listeners: {
                load: 'onReviewPeriodStoreLoad'
            }
        }
    },

    data: {
        /* This object holds the arbitrary data that populates the ViewModel and is then available for binding. */
        current: {
            title: 'Available Cases for Federal Period: ',
            tabType: 'P',
            selectedReviewPeriod: 0,
            reviewPeriod: null,
            caseDetail:null
        },
        widgets: {
            primay: 0,
            secondary: 0,
            eliminated: 0,
            universe: 0
        }
    }
});