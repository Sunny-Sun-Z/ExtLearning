﻿/**
 * Created by rkumar on 10/04/2018.
 */
Ext.define('QuickStart.view.sampling.SamplingInfo', {
    extend: 'Ext.grid.Panel',

    xtype: 'samplinggrid',
    config: {
        type: 'FC'
    },

    title:'Foster Care Sampling',

    requires: [
       'Ext.form.field.ComboBox',
       'Ext.grid.column.RowNumberer'
    ],

    columns: [
        { xtype: 'rownumberer' },
        {
            flex: 1,
            text: 'Region'
        },
        {
            flex: 1,
            text: 'Office Name'
        },
        {
            flex: 1,
            text: 'Review Month'
        },

                {
                    flex: 1,
                    sortable: true,
                    text: 'LINK Case ID'
                },
                {
                    flex: 1,
                    text: 'Case Status'
                },
                {
                    flex: 1,
                    text: 'Case First Name'
                },
                {
                    flex: 1,
                    text: 'Case Last Name'
                },
                {
                    flex: 1,
                    text: 'Child Last Name '
                },
                 {
                     flex: 1,
                     text: 'Child First Name '
                 }
    ],
    dockedItems: [
        {
            xtype: 'toolbar',
            // dock: 'bottom',
            //ui: 'footer',
            items: [{
                xtype: 'combobox',
                itemId: 'samplePeriod',
                width: 300,
                minChars: 2,
                fieldLabel: 'Sample Period',
                forceSelection: true,
                // editable: false,
                queryMode: 'remote',
                bind: { store: '{samplePeriods}' },
                displayField: 'name',
                valueField: 'code'
            }]
        }, {
            xtype: 'toolbar',
            layout: { pack: 'center' },
            ui: 'footer',
            items: [{
                xtype: 'component',
                html: '<div style="text-align: center;font-weight: bold;font-size: large;">Foster Care automated sampling records for review</div> '
            }]
        }
    ],
});
