/**
 * Created by kkora on 2/20/2018.
 */
Ext.define('QuickStart.view.sampling.Filter', {
    extend: 'Ext.panel.Panel',

    xtype: 'samplingfilter',

    requires: [
        'Ext.form.Panel',
        'Ext.form.field.*',
        'Ext.layout.container.VBox',
        'Ext.toolbar.Fill',
        'Ext.toolbar.Separator'
    ],

    region: 'west',
    title: 'Search Criteria',
    flex: 1,
    collapsible: true,
    split: true,
    layout: {
        type: 'vbox',
        align: 'stretch'
    },
    scrollable: 'y',
    items: [
        {
            layout: {
                type: 'vbox',
                align: 'stretch'
            },
            xtype: 'form',
            defaults: {
                labelWidth: 90,
                margin: '5 10 0 10',
                flex: 1,
                filterPickList: true,
                editable: true,
                growMax: 50
            },
           defaultType: 'combobox',

            items: [
                {
                    //xtype: 'datefield',
                    xtype: 'monthfield',
                    fieldLabel: 'Review Start Month',
                    name: 'reviewStartMonth',
                    itemId: 'reviewStartMonth',
                    reference: 'reviewStartMonth',
                    format: 'M-Y'
                },
                {
                    //xtype: 'datefield',
                    xtype: 'monthfield',
                    fieldLabel: 'Review End Month',
                    name: 'reviewEndMonth',
                    reference: 'reviewEndMonth',
                    format: 'M-Y'
                },
                {
                    fieldLabel: 'Region',
                    name: 'region',
                    queryMode: 'local',
                    bind: { store: '{regions}' },
                    displayField: 'Name',
                    valueField: 'Id',
                    emptyText: '--Select--',
                    listeners: {
                        blur: 'onRegionSelected'
                    }
                },
                {
                    fieldLabel: 'Office',
                    name: 'office',
                    bind: { store: '{locations}' },
                    displayField: 'Name',
                    valueField: 'Id',
                    emptyText: '--Select--'
                },
                //{
                //    fieldLabel: 'Review Month',
                //    name: 'reviewMonth',
                //    queryMode: 'local',
                //    bind: { store: '{reviewMonth}' },
                //    displayField: 'Name',
                //    valueField: 'Id',
                //    emptyText: '--Select--'
                //},
                {
                    fieldLabel: 'Case Type',
                    name: 'caseType',
                    queryMode: 'local',
                    bind: { store: '{caseType}' },
                    displayField: 'description',
                    valueField: 'code',
                    emptyText: '--Select--'
                },
                {
                    fieldLabel: 'Reviewer',
                    name: 'reviewer',
                    queryMode: 'local',
                    bind: { store: '{userStore}' },
                    displayField: 'name',
                    valueField: 'code',
                    emptyText: '--Select--'
                },
                {
                    fieldLabel: 'InitialQA',
                    name: 'InitialQAUserID',
                    queryMode: 'local',
                    bind: { store: '{userStore}' },
                    displayField: 'name',
                    forceSelection: true,
                    valueField: 'code',
                    emptyText: '--Select--'
                },
                {
                    fieldLabel: 'Sample Type',
                    name: 'sampleType',
                    queryMode: 'local',
                    bind: { store: '{sampleType}' },
                    displayField: 'description',
                    valueField: 'code',
                    emptyText: '--Select--'
                }
                ,
                {
                    fieldLabel: 'Sample Intake',
                    name: 'isIntake',
                    queryMode: 'local',
                    bind: { store: '{isIntake}' },
                    displayField: 'description',
                    valueField: 'code',
                    emptyText: '--Select--'
                }
                //{
                //    xtype: 'checkbox',
                //    fieldLabel: ' ',
                //    labelSeparator : '',
                //    boxLabel: '<b>Sample Intake</b>',
                //    name: 'IsIntake',
                //    inputValue: true
                //},
                ,
                {
                    xtype: 'checkbox',
                    fieldLabel: ' ',
                    labelSeparator: '',
                    boxLabel: '<b>Eliminated</b>',
                    name: 'IsEliminated',
                    inputValue: true

                }
            ],
            dockedItems: [{
                xtype: 'toolbar',
                dock: 'bottom',
                items: ['->',
                    {
                        text: 'Reset all',
                        ui: 'gray',
                        itemId: 'clear',
                        iconCls: 'x-fa fa-close',
                        handler: 'onResetSearch'
                    }, {
                        ui: 'dcf',
                        text: 'Search',
                        itemId: 'search',
                        iconCls: 'x-fa fa-search',
                        handler: 'onSearch',
                        xtype:'button'
                        //defaults:{  handler: 'onUserSavedSearchClick'},
                        //menu:[]
                    }
                ]
            }]
        },
        {xtype: 'tbfill', flex: 1},
        {
            hidden: true,
            xtype: 'component',
            html: QuickStart.util.Resources.tips.dashboard.search()
        }]
});