/**
 * Created by kkora on 2/21/2018.
 */
Ext.define('QuickStart.view.sampling.pipreview.Grid', {
    extend: 'Ext.grid.Panel',

    xtype: 'pipreviewgrid',
    config: {
        sampleStartMonth: 4
    },
    requires: [
        'Ext.form.field.ComboBox',
        'Ext.grid.column.RowNumberer',
        'Ext.grid.feature.Grouping',
        'Ext.grid.feature.GroupingSummary',
        'Ext.grid.feature.Summary',
        'Ext.toolbar.Fill',
        'Ext.grid.plugin.Exporter'
    ],

    title: 'PIP Reviews',
    features: [
        {
            ftype: 'summary',
            dock:'bottom'
        }
    ],
    plugins: {
        ptype: 'gridexporter'
       // gridexporter: true
    },
   // columnLines: true,
    viewConfig: {
        trackOver: false,
        headersDisabled: true,
        trackMouseOver: false,
        getRowClass: function (record, index) {
            return record.get('IsAdditionalHS') == true ? 'yellow-background' : '';
        },
        listeners: {
            refresh: function (dataview) {

                var monthStart = dataview.ownerGrid.getSampleStartMonth();
                Ext.each(dataview.panel.columns, function (column) {
                    if (column.monthIndex >= 0) {

                        var monthNumber = monthStart + column.monthIndex;
                        monthNumber = (monthNumber > 12 ? monthNumber - 12 : monthNumber);
                        var text = Ext.Date.monthNames[monthNumber - 1];
                        text = text.length > 5 ? text.substr(0, 3) : text;
                        column.setText(text);
                    }

                });
            }
        }
    },
    split: false,
    lockedGridConfig: {flex: 1 / 2},
    columns: [
        {xtype: 'rownumberer'},
        {
            flex: 1,
            align: 'center',
            menuDisabled: true,
            sortable: false,
            text: '<strong>Region',
            dataIndex: 'RegionId',
            locked: true
        },
        {flex: 2, menuDisabled: true, sortable: false, text: '<strong>Office', dataIndex: 'Office', locked: true},
        {
            flex: 2,
            menuDisabled: true,
            sortable: false,
            text: '<strong>Sample Group',
            dataIndex: 'SampleGroup',
            locked: true,
            summaryType: 'count',
            summaryRenderer: function (value, summaryData, dataIndex) {
                // return Ext.String.format('{0} Item{1}', value, value !== 1 ? 's' : '');
                return '<strong>Total</strong>';
            }
        },
        {
            text: '<strong>PIP Sample/Review Month',
            lockable: false,
            menuDisabled: true,
            flex: 1,
            focusable: true,
            columns: [
                {
                    flex: 1,
                    align: 'center',
                    menuDisabled: true,
                    sortable: false,
                    text: 'Month1',
                    dataIndex: 'Month1',
                    monthIndex: 0,
                    summaryType: 'sum',
                    summaryRenderer: 'summaryRendererBold'
                },
                {
                    flex: 1,
                    align: 'center',
                    menuDisabled: true,
                    sortable: false,
                    text: 'Month2',
                    dataIndex: 'Month2',
                    monthIndex: 1,
                    summaryType: 'sum',
                    summaryRenderer: 'summaryRendererBold'
                },
                {
                    flex: 1,
                    align: 'center',
                    menuDisabled: true,
                    sortable: false,
                    text: 'Month3',
                    dataIndex: 'Month3',
                    monthIndex: 2,
                    summaryType: 'sum',
                    summaryRenderer: 'summaryRendererBold'
                },
                {
                    flex: 1,
                    align: 'center',
                    menuDisabled: true,
                    sortable: false,
                    text: 'Month4',
                    dataIndex: 'Month4',
                    monthIndex: 3,
                    summaryType: 'sum',
                    summaryRenderer: 'summaryRendererBold'
                },
                {
                    flex: 1,
                    align: 'center',
                    menuDisabled: true,
                    sortable: false,
                    text: 'Month5',
                    dataIndex: 'Month5',
                    monthIndex: 4,
                    summaryType: 'sum',
                    summaryRenderer: 'summaryRendererBold'
                },
                {
                    flex: 1,
                    align: 'center',
                    menuDisabled: true,
                    sortable: false,
                    text: 'Month6',
                    dataIndex: 'Month6',
                    monthIndex: 5,
                    summaryType: 'sum',
                    summaryRenderer: 'summaryRendererBold'
                },
                {
                    flex: 1,
                    align: 'center',
                    menuDisabled: true,
                    sortable: false,
                    text: 'Total',
                    dataIndex: 'Total',
                    summaryType: 'sum',
                    summaryRenderer: 'summaryRendererBold'
                }
            ]

        }

    ],
    dockedItems: [
        {
            xtype: 'toolbar',
            // dock: 'bottom',
            //ui: 'footer',
            items: [{
                xtype:'combobox',
                itemId:'samplePeriod',
                width:300,
                minChars:2,
                fieldLabel:'Sample Period',
                forceSelection:true,
               // editable: false,
                queryMode: 'remote',
                bind: {store: '{samplePeriods}'},
                displayField: 'name',
                valueField: 'code'
            },'->', {
                hidden:true,
                iconCls: 'x-fa fa-file-excel-o',
                itemId:'exportToExcel',
                text: 'Export To Excel',
                menu: {
                    defaults: {
                        handler: 'exportTo'
                    },
                    items: [{
                        text:   'Excel xlsx',
                        cfg: {
                            type: 'excel07',
                            ext: 'xlsx'
                        }
                    },{
                        text:   'Excel xlsx (include groups)',
                        cfg: {
                            type: 'excel07',
                            ext: 'xlsx',
                            includeGroups: true,
                            includeSummary: true
                        }
                    },{
                        text: 'Excel xml',
                        cfg: {
                            type: 'excel03',
                            ext: 'xml'
                        }
                    },{
                        text: 'Excel xml (include groups)',
                        cfg: {
                            includeGroups: true,
                            includeSummary: true
                        }
                    },{
                        text:   'CSV',
                        cfg: {
                            type: 'csv'
                        }
                    },{
                        text:   'TSV',
                        cfg: {
                            type: 'tsv',
                            ext: 'csv'
                        }
                    },{
                        text:   'HTML',
                        cfg: {
                            type: 'html'
                        }
                    },{
                        text:   'HTML (include groups)',
                        cfg: {
                            type: 'html',
                            includeGroups: true,
                            includeSummary: true
                        }
                    }]
                }
            }]
        }, {
            xtype: 'toolbar',
            layout: {pack: 'center'},
            ui: 'footer',
            items: [{
                xtype: 'component',
                html: '<div style="text-align: center;font-weight: bold;font-size: large;">Monthly Schedule of PIP Reviews by Office and Sample Group (In-Home/Foster Care)</div> '
            }]
        }, {
            xtype: 'toolbar',
            layout: {pack: 'center'},
            ui: 'footer',
            items: [{
                xtype: 'component',
                html: '<div style="text-align: center;font-weight: bold;">Additional In-Home Services Case for CT-DCF Six Largest Offices</div> '
            }]
        }
    ],
    listeners: {
       documentsave: 'onDocumentSave',
       beforedocumentsave: 'onBeforeDocumentSave',
       dataready: 'onDataReady'
    }


});