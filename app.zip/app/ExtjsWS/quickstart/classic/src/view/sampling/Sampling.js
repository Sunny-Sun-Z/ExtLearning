/**
 * Created by kkora on 2/21/2018.
 */
Ext.define('QuickStart.view.sampling.Sampling', {
    extend: 'Ext.panel.Panel',

    requires: [
        'Ext.layout.container.Border',
        'Ext.layout.container.boxOverflow.Menu',
        'QuickStart.util.Resources',
        'QuickStart.view.sampling.SamplingController',
        'QuickStart.view.sampling.SamplingModel'
    ],
    alias: 'widget.sampling',

    //xtype: 'sampling',

    viewModel: {
        type: 'sampling'
    },

    cls: 'casereview-container',

    controller: 'sampling',
    margin: 20,
    layout: 'border',

    items: [
        {
            xtype: 'samplingfilter'
        },
        {
            flex: 5,
            region: 'center',
            layout: 'fit',
            items: [
                {
                    xtype: 'grid',
                    reference: 'samplingGrid',
                    bind:
                    {
                        //title: '{current.title}',
                        store: '{samplingStore}'                       
                    },
                    headerBorders: false,
                    border:false,
                    columns: [
                        {
                            xtype: 'rownumberer',
                            renderer: function (val, meta, rec) {
                                var isReplacement = rec.get('IsReplacement');
                                if (isReplacement) {
                                    meta.tdCls = 'replacement-grid-cell'; 
                                }
                                return val;
                            },
                        },
                        {
                            text: 'View&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
                            menuDisabled: true,
                            //flex: 5,
                            xtype: 'widgetcolumn',
                            widget: {
                                text: 'Options',
                                itemId: 'viewButton',
                                xtype: 'splitbutton',
                                listeners:
                                {
                                    arrowclick : 'onOptionsArrowClick'
                                },
                                menu: [
                                    {
                                        iconCls: 'x-fa fa-search',
                                        ui: 'gray',
                                        text: '<strong>Case Details</strong>',
                                        handler: 'onCaseDetailButtonClick'
                                    }
                                ]
                            }
                        },
                        {
                            text: 'Case Type',
                            dataIndex: 'Case_Type',
                            menuDisabled: true,
                            flex: 1
                        },

                        {
                            text: 'Intake',
                            dataIndex: 'IsIntake',
                            renderer: 'rendererYesNo',
                            menuDisabled: true,
                            flex: 1
                        },

                        {
                            text: 'Region',
                            dataIndex: 'Region_Name',
                            menuDisabled: true,
                            flex: 1
                        },
                        {
                            text: 'Office',
                            dataIndex: 'Office_Name',
                            menuDisabled: true,
                            flex: 1
                        },
                        {
                            text: 'Review Month',
                            dataIndex: 'ReviewMonth',
                            formatter: 'date("M-Y")',
                            menuDisabled: true,
                            bind:
                            {
                                hidden: '{current.tabType === "S"}'
                            },
                            flex: 1
                        },
                        //{
                        //    text: 'Case ID',
                        //    dataIndex: 'Case_ID',
                        //    menuDisabled: true,
                        //    flex: 1
                        //},

                        {
                            text: 'Case ID',
                            dataIndex: 'Case_ID',
                            menuDisabled: true,
                            flex: 1,
                            renderer: 'rendererCaseIdWithStaus'
                        },
                        {
                            text: 'Case Name',
                            dataIndex: 'Case_Name',
                            menuDisabled: true,
                            flex: 1
                        },
                        {
                            text: 'Case Status',
                            dataIndex: 'Case_Status',
                            menuDisabled: true,
                            flex: 1
                        },
                        {
                            text: 'Reviewer',
                            menuDisabled: true,
                            flex: 1,
                            bind:
                            {
                                hidden: '{current.tabType === "S"}'
                            },
                            dataIndex: 'Reviewers',
                            renderer: 'renderReviewers'
                        },
                        {
                            text: 'Initial QA',
                            menuDisabled: true,
                            flex: 1,
                            bind:
                            {
                                hidden: '{current.tabType === "S"}'
                            },
                            dataIndex: 'InitialQAUserID',
                            renderer: 'rendererUser'
                        },
                        {
                            text: 'Sample Type',
                            dataIndex: 'SampleType',
                            renderer: 'rendererSampleType',
                            menuDisabled: true,
                            flex: 1
                        },
                        {
                            text: 'Primary Language',
                            dataIndex: 'Primary_Language',
                            menuDisabled: true,
                            flex: 1
                        },
                        {
                            text: 'Town of Residence',
                            dataIndex: 'HomeTown',
                            menuDisabled: true,
                            flex: 1
                        },
                        {
                            text: 'Child Name',
                            dataIndex: 'ChildName',
                            menuDisabled: true,
                            flex: 1
                        },
                        {
                            text: 'Child DOB',
                            dataIndex: 'Child_DOB',
                            formatter: 'date("m/d/Y")',
                            menuDisabled: true,
                            flex: 1
                        }
                        ,
                        {
                            text: 'Child Age',
                            dataIndex: 'Child_Age_Calc',
                            menuDisabled: true,
                            flex: 1,
                            bind:
                            {
                                hidden: '{current.tabType !== "P"}'
                            }
                        },
                        {
                            text: 'Child Legal Status',
                            dataIndex: 'Legal_Status',
                            menuDisabled: true,
                            flex: 1
                        },
                        {
                            text: 'Is Eliminated?',
                            bind:
                            {
                                hidden: '{current.tabType !== "U"}'
                            },
                            dataIndex: 'IsEliminated',
                            renderer: 'rendererYesNo',
                            menuDisabled: true,
                            flex: 1
                        }

                    ],
                    viewConfig: {
                        emptyText: '<div style="text-align:center;font-weight:bold"> No Record Found</div>',
                        forceFit: true,
                        listeners: {
                            refresh: function (dataview) {
                                Ext.each(dataview.panel.columns, function (column) {
                                    column.autoSize();
                                });
                            }
                        }
                    },
                    dockedItems: [
                        {
                            xtype: 'toolbar',
                            overflowHandler: 'menu',
                            cls: 'widget-follower-toolbar',
                            defaults: {
                                handler: 'onTabFilter',
                                flex: 1,
                                labelAlign: 'top',
                                margin: 0
                            },

                            items: [
                                {
                                    tabType: 'P',
                                    ui:'soft-green',
                                    cls: 'widget-follower-tool-label',
                                    //style: { 'border-top': '2px solid #16b603' },
                                    bind: '<div class="label">Primary</div><div>{widgets.primay}</div>'
                                }
                                ,{
                                    tabType: 'S',
                                    ui:'default-toolbar',
                                    cls: 'widget-follower-tool-label',
                                    //style: { 'border-top': '2px solid #1a568a' },
                                    bind: '<div class="label">Secondary</div><div>{widgets.secondary}</div>'
                                }
                                //,{
                                //    tabType: 'E',
                                //    ui: 'default-toolbar',
                                //    style: { 'border-top': '2px solid #e44959' },
                                //    bind: '<div class="label">Eliminated</div><div>{widgets.eliminated}</div>'
                                //}
                                ,{
                                    tabType: 'U',
                                    ui: 'default-toolbar',
                                    //style: { 'border-top': '2px solid #ffc000' },
                                    bind: '<div class="label">Full Sample</div><div>{widgets.universe}</div>'
                                }
                            ]
                        }
                        ,{
                            xtype: 'pagingtoolbar',
                            dock: 'bottom',
                            itemId: 'userPaginationToolbar',
                            displayInfo: true,
                            bind: '{samplingStore}'
                        }
                    ]
                }
            ]
        }
        , {
            xtype: 'addreviewwindow',
            itemId: 'addReviewWindow'
        }, {
            xtype: 'casewindow',
            itemId: 'caseWindow'
        }
    ],
    dockedItems: [
        {
            xtype: 'toolbar',
            // dock: 'bottom',
            ui: 'footer',
            items: [{
                xtype: 'combobox',
                itemId: 'reviewPeriod',
                reference: 'reviewPeriod',
                width: 300,
                minChars: 2,
                fieldLabel: 'Sample Review Period',
                forceSelection: true,
                // editable: false,
                queryMode: 'remote',
                bind: {
                    store: '{reviewPeriods}'
                },
                displayField: 'Period',
                valueField: 'Id',
                listeners: {
                    select: 'onReviewPeriodSelected'
                }
            }]
        }]
     //,
    //listeners: {
    //    afterrender: 'onSamplingAfterRender'
    //}
});