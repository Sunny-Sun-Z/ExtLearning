﻿/**
 * Created by rkumar on 10/19/2018.
 */

Ext.define('QuickStart.view.sampling.add.ReviewPeriod', {
    extend: 'QuickStart.view.common.BaseWindow',

    xtype: 'addreviewwindow',

    width: 400,
    height:250,
    layout: 'fit',
    defaults: {
        defaultFocus: 'textfield:not([value]):focusable:not([disabled])',
        defaultButton: 'reviewGenerateButton'
    },
    bind: {
        title: 'Add Review Period'
    },
    maximized: false,
    constrain: false,
    items: [
        {
            bodyPadding: '10 10 0 10',
            xtype: 'form',
            defaultType: 'textfield',
            defaults: {
                submitEmptyText: false,
                anchor: '100%',
                labelWidth: 150,
                fieldLabel: ' ',
                msgTarget: 'side',
                allowBlank: false

            },
            items: [
                //{
                //    xtype: 'component',
                //    html: 'Dates should be between today\'s date and 3 years in past.'
                //},
                {
                    //xtype: 'datefield',
                    xtype: 'monthfield',
                    //showButtons: false,
                    bind: '{current.reviewPeriod.StartDate}',
                    fieldLabel: 'Review Period Start:',
                    name: 'reviewStartDate',
                    itemId: 'reviewStartDate',
                    format: 'M-Y',
                    maxValue: Ext.Date.add(new Date(), Ext.Date.MONTH, 3),
                    minValue: Ext.Date.add(new Date(), Ext.Date.YEAR, -3)
                    //maxValue: new Date(),  // limited to the current date or prior
                    //minValue: new Date(new Date().getFullYear()-3, 1, 1)
                },
                {
                    xtype: 'datefield',
                    //showButtons: false,
                    bind: '{current.reviewPeriod.EndDate}',
                    fieldLabel: 'Review Period End:',
                    name: 'reviewEndDate',
                    itemId: 'reviewEndDate',
                    format: 'M-Y',
                    disabled:true
                },
                {
                    xtype:'displayfield',
                    fieldLabel: 'Review Period',
                    bind: '{current.reviewPeriod.message}'
                }

            ],
            dockedItems: [
                {
                    xtype: 'toolbar',
                    dock: 'bottom',
                    ui: 'footer',
                    items: ['->', {
                        text: 'Generate....',
                        ui: 'soft-green',
                        iconCls: 'x-fa fa-save',
                        reference: 'reviewGenerateButton',
                        formBind: true,
                        handler: 'onGenerateReviewPeriod'

                    }, {
                            text: 'Cancel',
                            ui: 'gray',
                            iconCls: 'x-fa fa-close',
                            handler: 'onWindowCancel'
                        }]
                }]

        }
    ],
    listeners: {
        close: 'onWindowCancel'
    }
});