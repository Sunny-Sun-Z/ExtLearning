/**
 * Created by kkora on 2/20/2018.
 */
Ext.define('QuickStart.view.dashboard.Filter', {
    extend: 'Ext.panel.Panel',

    xtype: 'dashboardfilter',

    requires: [
        'Ext.button.Split',
        'Ext.form.Panel',
        'Ext.form.field.*',
        'Ext.layout.container.VBox',
        'Ext.toolbar.Fill',
        'Ext.toolbar.Separator'
    ],

    region: 'west',
    title: 'Search Criteria',
    flex: 1,
    collapsible: true,
    split: true,
    layout: {
        type: 'vbox',
        align: 'stretch'
    },
    scrollable: 'y',
    items: [
        {
            layout: {
                type: 'vbox',
                align: 'stretch'
            },
            xtype: 'form',
            defaults: {
                labelWidth: 90,
                // labelAlign: 'top',
                margin: '5 10 0 10',
                flex: 1,
                filterPickList: true,
                editable: true,
                growMax: 50
            },
           //   defaultType: 'combobox',
           defaultType: 'tagfield',

            items: [
                {
                    xtype: 'numberfield',
                    name: 'CaseReviewID',
                    hideTrigger: true,
                    fieldLabel: 'CRS ID'
                },
                {
                    xtype: 'numberfield',
                    name: 'CaseID',
                    hideTrigger: true,
                    fieldLabel: 'Case ID'
                },
                {
                    hideTrigger: true,
                    xtype: 'numberfield',
                    name: 'MeetingID',
                    fieldLabel: 'Meeting ID'
                },
                {
                    xtype: 'textfield',
                    name: 'CaseName',
                    fieldLabel: 'Case Name'

                },
                {
					xtype: 'combobox',
                    fieldLabel: 'Type',
                    name: 'ReviewTypeID',
                    queryMode: 'local',
                    bind: {store: '{reviewTypeStore}'},
                    displayField: 'name',
                    valueField: 'code',
                    listeners: {
                        select:'onReviewTypeSelected'
                    }
                },
                {
					xtype: 'combobox',
					fieldLabel: 'Sub Type',
                    name: 'ReviewSubTypeID',
                    queryMode: 'local',
                    bind: {store: '{reviewSubTypeChainedStore}'},
                    displayField: 'name',
                    valueField: 'code'
                },
                 {
                    fieldLabel: 'Status',
                    name: 'CaseStatusCode',
                    queryMode: 'local',
                    bind: {store: '{caseStatusStore}'},
                    displayField: 'large',
                    valueField: 'code'

                },
                {
                    xtype: 'datefield',
                    name: 'ReviewStartDate',
                    fieldLabel: 'Review Start',
                    maxValue: new Date(),
                    minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30)

                },
                {
                    xtype: 'datefield',
                    name: 'ReviewCompleted',
                    fieldLabel: 'Review End',
                    maxValue: new Date(),
                    minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30)

                },
                {
                    fieldLabel: 'Site',
                    name: 'SiteCode',
                    queryMode: 'local',
                    store: 'Sites',
                    displayField: 'medium',
                    valueField: 'code'

                },
                {
                    fieldLabel: 'Reviewers',
                    name: 'Reviewers',
                    queryMode: 'local',
                    bind: {store: '{userStore}'},
                    displayField: 'name',
                    valueField: 'code'
                },
                {
                   xtype: 'combobox',
                    fieldLabel: 'InitialQA',
                    name: 'InitialQAUserID',
                    queryMode: 'local',
                    forceSelection: true,
                    bind: { store: '{userStore}' },
                    displayField: 'name',
                    valueField: 'code'
                },
                {
                    xtype: 'combobox',
                    fieldLabel: 'PIP',
                    name: 'IsPIPMonitored',
                    queryMode: 'local',
                    editable: false,
                    bind: {store: '{pipStore}'},
                    displayField: 'name',
                    valueField: 'code'
                },
                {
                    xtype: 'checkbox',
                    fieldLabel: ' ',
					labelSeparator :'',
                    boxLabel: '<b>All Imported Cases</b>',
                    name: 'IsCaseImported',
                    inputValue: true
                    
                }
            ],
            dockedItems: [{
                xtype: 'toolbar',
                dock: 'bottom',
                items: ['->',
                    {
                        text: 'Reset all',
                        ui: 'gray',
                        itemId: 'clear',
                        iconCls: 'x-fa fa-close',
                        handler: 'onResetSearch'
                    }, {
                        ui: 'dcf',
                        text: 'Search',
                        itemId: 'search',
                        iconCls: 'x-fa fa-search',
                        handler: 'onSearch',
                          xtype:'splitbutton',
                        defaults:{  handler: 'onUserSavedSearchClick'},
                        menu:[]
                    }
                ]
            }]
        },
        {xtype: 'tbfill', flex: 1},
        {
            hidden: true,
            xtype: 'component',
            html: QuickStart.util.Resources.tips.dashboard.search()
        }]
});