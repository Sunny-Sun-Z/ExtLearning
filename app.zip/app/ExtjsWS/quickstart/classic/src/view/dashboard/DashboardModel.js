/**
 * Created by kkora on 9/13/2017.
 */
Ext.define('QuickStart.view.dashboard.DashboardModel', {
	extend: 'Ext.app.ViewModel',
	alias: 'viewmodel.dashboard',

	requires: [
		'QuickStart.model.Dashboard',
		'QuickStart.proxy.API',
		'QuickStart.store.GroupLookups',
		'Ext.data.proxy.Direct'
	],

	stores: {
		dashboardStore1: {
			model: 'QuickStart.model.Dashboard',
			autoLoad: true,
			pageSize: 20,
			proxy: {
				type: 'api',
				url: '~api/dashboard/reviews'
			},
			listeners: {
				load: 'onDashboardLoad'
			}
		},
		dashboardStore: {
			model: 'QuickStart.model.Dashboard',
			autoLoad: false,
			pageSize: 20,
			remoteFilter: true,
			remoteSort: true,
			filters: [{property: 'crDs', value: ''}],
			proxy: {
				url: QuickStart.util.Global.getApi(),
				type: 'ajax',
				paramsAsJson: true,
				pageParam: null,
				api: {
					read: 'case/DashboardDataNew'
					// read: 'case/DashboardData'
				},
				//  actionMethods: {read: 'POST'},
				reader: {
					type: 'json',
					rootProperty: 'data',
					totalProperty: 'total'
				}
			},
			listeners: {
				load: 'onDashboardLoad'
			}
		},

		userSavedSearchStore: {
			model: 'QuickStart.model.SearchCriteria',
			autoLoad: true,
			pageSize: 10,
			proxy: {
				url: QuickStart.util.Global.getApi(),
				type: 'ajax',
				pageParam: null,
				api: {read: 'case/GetUserSearches'},
				extraParams: {id: 0},
				reader: {
					type: 'json',
					rootProperty: 'data',
					totalProperty: 'total'
				}
			},
			listeners: {
				load: 'onUserSavedSearchLoad'
			}
		},

		userStore: {
			type: 'grouplookups',
			filters: [{property: 'group', value: 'CrSecurityUser', operator: '='}],
			// sorters: ([{property: 'name', direction: 'ASC'}])
		},
		siteStore: {
			type: 'grouplookups',
			sorters: [{property: 'medium', direction: 'ASC'}],
			filters: [{property: 'group', value: 'Site', operator: '='}]
		},
		caseStatusStore: {
			type: 'grouplookups',
			filters: [{property: 'group', value: 'CaseStatus', operator: '='}]
		},
		reviewTypeStore: {
			type: 'grouplookups',
			filters: [{property: 'group', value: 'CrReviewType', operator: '='}]
		},
		reviewSubTypeStore: {
			type: 'grouplookups',
			filters: [{property: 'group', value: 'CrReviewSubType', operator: '='}]
		},

		reviewSubTypeChainedStore: {
			type: 'chained',
			source: '{reviewSubTypeStore}'
		},

		pipStore: {
			fields: ['code', 'name'],
			data: [{code: 1, name: 'PIP Monitored Cases'}, {code: 2, name: 'Non-PIP Monitored Cases'}]
		}
	},
	data: {
		widgets: {
			dataEntryComplete: 0,
			inProgress: 0,
			notStarted: 0,
			qaInProgress: 0,
			finalized: 0,
			eliminated: 0,
			approved: 0,
			eliminatedPendingApproval: 0
		}
	}
});