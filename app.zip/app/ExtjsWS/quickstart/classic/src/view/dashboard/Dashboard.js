/**
 * Created by kkora on 9/13/2017.
 */
Ext.define('QuickStart.view.dashboard.Dashboard', {
    extend: 'Ext.panel.Panel',

    requires: [
        'Ext.layout.container.Border',
        'Ext.layout.container.boxOverflow.Menu',
        'QuickStart.util.Resources',
        'QuickStart.view.dashboard.DashboardController',
        'QuickStart.view.dashboard.DashboardModel'
    ],

    alias: 'widget.dashboard',
    config: {
        highlightTitle: 'Dashboard'
    },

    viewModel: {
        type: 'dashboard'
    },
    cls: 'casereview-container',
    controller: 'dashboard',
    margin: 20,
    layout: 'border',
    items: [
        {
            xtype: 'dashboardfilter'
        },
        {
            flex: 4,
            region: 'center',
            layout: 'fit',
            items: [
                {
                    xtype: 'grid',
                    //stateId : 'dashboardGrid',
                   // stateful:true,
                    reference: 'dashboardGrid',
                    title: 'Available Cases',
                    bind: '{dashboardStore}',
                    // hideBorders:true,
                    // headerBorder:false,
                    // plugins: {
                    //     rowexpander: {
                    //         rowBodyTpl: new Ext.XTemplate('<p><b>Reviewer(s):</b> {Reviewers}</p>')
                    //     }
                    // },
                    headerBorders: false,
                    columns: [
                        {
                            text: 'View',
                            menuDisabled: true,
                            //width: 30,
                            renderer: function (val, meta, record) {

                                //  var url = window.location.host + window.location.pathname + '#casereview/' + record.get('CaseReviewRootID');
                                //var url = window.location.origin + window.location.pathname + '#case/' + record.get('CaseReviewRootID') + '/' + record.get('CaseReviewID');
                                var url = window.location.origin + window.location.pathname + '#case/' + record.get('CaseReviewRootID');
                                return '<a href="' + url + '">View</a>';
                            }
                        },
                        {
                            menuDisabled: true,
                            text: 'Case ID',
                            dataIndex: 'CaseID'
                        },
                        {
                            menuDisabled: true,
                            text: 'Meeting ID',
                            flex: 1,
                            dataIndex: 'MeetingID'
                        },
                        {
                            menuDisabled: true,
                            text: 'Type',
                            flex: 1,
                            dataIndex: 'ReviewTypeID',
                            renderer: 'rendererReviewType'
                        },
                        {
                            menuDisabled: true,
                            text: 'Sub Type',
                            flex: 1,
                            dataIndex: 'ReviewSubTypeID',
                            renderer: 'rendererReviewSubType'
                        },
                        {
                            text: 'Case Name',
                            menuDisabled: true,
                            flex: 2,
                            dataIndex: 'CaseName'

                        },
                        {
                            menuDisabled: true,
                            text: 'Status',
                            flex: 1,
                            dataIndex: 'CaseStatusCode',
                            renderer: 'rendererCaseStatus'
                        },
                        {
                            menuDisabled: true,
                            text: 'Review Start',
                            flex: 1,
                            dataIndex: 'ReviewStartDate',
                            formatter: 'date("m/d/Y")'
                            // ,renderer: 'dateRenderer'


                        },
                        {
                            text: 'Review End',
                            menuDisabled: true,
                            flex: 1,
                            dataIndex: 'ReviewCompleted',
                            formatter: 'date("m/d/Y")'
                            //, renderer: 'dateRenderer'
                        },
                        {
                            menuDisabled: true,
                            text: 'Office Name',
                            flex: 1,
                            dataIndex: 'SiteCode',
                            renderer: 'rendererSite'
                        },
                        {
                            flex: 1,
                            hidden: false,
                            sortable: false,
                            menuDisabled: true,
                            text: 'Reviewer(s)',
                            //cellWrap:true,
                            dataIndex: 'Reviewers',
                            renderer: 'renderReviewers'
                        },
                        {
                            flex: 1,
                            hidden: false,
                            sortable: false,
                            menuDisabled: true,
                            text: 'Initial QA',
                            dataIndex: 'InitialQAUserID',
                            renderer: 'rendererUser'
                        }
                    ],
                    viewConfig: {
                        emptyText: '<div style="text-align:center;font-weight:bold"> No Record Found</div>',
                        forceFit: true,
                        listeners: {
                            refresh: function (dataview) {
                                Ext.each(dataview.panel.columns, function (column) {
                                    column.autoSize();
                                });
                            }
                        }
                    },
                    dockedItems: [
                        {
                            xtype: 'toolbar',
                            overflowHandler: 'menu',
                            cls: 'widget-follower-toolbar',
                            defaults: {
                                //   xtype: 'displayfield',
                                handler: 'onStatusFilter',
                                flex: 1,
                                labelAlign: 'top',
                                margin: 0
                            },

                            items: [
                                {
                                    statusCode: 3,
                                    cls: 'widget-follower-tool-label',
                                    style: {'border-top': '2px solid #ADB3B8'},
                                    bind: '<div class="label">Not Started</div><div>{widgets.notStarted}</div>'
                                },
                                {
                                    statusCode: 2,
                                    style: {'border-top': '2px solid #1a568a'},
                                    bind: '<div class="label">In Progress</div><div>{widgets.inProgress}</div>'
                                },
                                {
                                    statusCode: 1,
                                    cls: 'widget-follower-tool-label',
                                    style: { 'border-top': '2px solid #ffc000' },
                                    bind: '<div class="label">Data Entry Complete</div><div>{widgets.dataEntryComplete}</div>'
                                },
                                {
                                    statusCode: 4,
                                    style: {'border-top': '2px solid #925e8b'},
                                    cls: 'widget-follower-tool-label',
                                    bind: '<div class="label">QA in Progress</div><div>{widgets.qaInProgress}</div>'
                                },
                                {
                                    statusCode: 6,
                                    style: {'border-top': '2px solid #e44959'},
                                    bind: '<div class="label">Case Eliminated</div><div>{widgets.eliminated}</div>'
                                },
                                {
                                    statusCode: 5,
                                    style: {'border-top': '2px solid #9cc96b'},
                                    cls: 'widget-follower-tool-label',
                                    bind: '<div class="label">Finalized</div><div>{widgets.finalized}</div>'
                                },
                                {
                                    statusCode: 7,
                                    style: {'border-top': '2px solid #16b603'},
                                    bind: '<div class="label">Approved</div><div>{widgets.approved}</div>'
                                }
                            ]
                        },
                        {
                            xtype: 'pagingtoolbar',
                            dock: 'bottom',
                            itemId: 'userPaginationToolbar',
                            displayInfo: true,
                            bind: '{dashboardStore}'

                        }
                    ]
                }
            ]
        }
    ],
    listeners: {
        afterrender: 'onDashboardAfterRender'
    }
});