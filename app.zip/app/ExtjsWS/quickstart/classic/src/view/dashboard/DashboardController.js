/**
 * Created by kkora on 9/13/2017.
 */

Ext.define('QuickStart.view.dashboard.DashboardController', {
	extend: 'Ext.app.ViewController',
//    extend: 'QuickStart.DirectViewController',
	alias: 'controller.dashboard',
	mixins: ['QuickStart.mixins.Global'],


	finishInit: function () {

		//var store = this.getViewModel().getStore('dashboardStore3');

		// store.load();
	},
	onResetSearch: function (btn) {
		var me = this,
			form = btn.up('form').getForm(),
			vm = me.getViewModel(),
			store = vm.getStore('dashboardStore')
		;
		form.reset();
		me.onSearch(btn);

	},
	onFilter: function (filters) {
		var me = this,
			vm = me.getViewModel(),
			store = vm.getStore('dashboardStore')
		;
		store.clearFilter();
		store.setFilters(filters);
	},
	onSearch: function (btn) {
		//  console.log('onSearch')

		var me = this,
			form = btn.up('form').getForm(),
			values = form.getValues(),
			grid = me.getView().down('grid'),
			vm = me.getViewModel(),
			store = vm.getStore('dashboardStore'),
//            store = grid.getStore(),
			filters = [];

		filters.push({property: 'crDs', value: Ext.encode(values)});
		store.clearFilter();
		store.setFilters(filters);
		Ext.state.Manager.set('dashboardfilter', Ext.encode(values));
	},
	onDashboardAfterRender: function (panel) {

		var me = this,
			view = me.getView(),
			form = view.down('form').getForm(),
			vm = me.getViewModel(),
			btnSearch = view.down('#search'),
			store = vm.getStore('dashboardStore'),
			values = Ext.state.Manager.get('dashboardfilter'),
			filters = [];
		if (values) {
			form.setValues(Ext.decode(values));
		}

		filters.push({property: 'crDs', value: Ext.encode(form.getValues())});
		store.clearFilter();
		store.setFilters(filters);
		this.updateStatusWidget(store);
		this.loadSavedSearches();
	},
	onDashboardLoad: function (store) {
		// this.updateStatusWidget(store);
	},
	onUserSavedSearchLoad: function (store) {
		this.loadSavedSearches(store);
	},
	updateStatusWidget: function (store) {
		var me = this,
			vm = me.getViewModel(),
			myMask = new Ext.LoadMask({msg: 'Please wait...', target: me.getView()}),
			isTest = QuickStart.util.Global.getTest(),
			url = isTest ? '~api/testdata/dashboardwidget' : QuickStart.util.Global.getApi() + 'case/DashboardWidgetNew';

		Ext.Ajax.request({
			url: url,
			method: 'GET',
			params: {
				filter: '',
				userID: QuickStart.util.Global.getUser().id
			},
			success: function (response, opts) {
				var result = Ext.decode(response.responseText);
				if (result != null) {
					if (!Ext.isEmpty(result.data)) {
						vm.set('widgets', result.data);
					}
				}
			},
			failure: function (response, opts) {
				myMask.hide();
				Ext.Msg.alert('Status', "failure");
				console.log('server-side failure with status code ' + response.status);
			},
			scope: this
		});
	},
	onStatusFilter: function (btn) {
		var me = this,
			vm = me.getViewModel(),
			store = vm.getStore('dashboardStore'),
			form = me.getView().down('form').getForm(),
			values = form.getValues(),
			statusCode = btn.statusCode,
			filters = []
		;
		values.CaseStatusCode = [statusCode];
		filters.push({property: 'crDs', value: Ext.encode(values)});

		// filters.push({property: 'CaseStatusCode', value: statusCode});
		store.clearFilter();
		store.setFilters(filters);
	},
	loadSavedSearches: function () {
		var me = this,
			vm = me.getViewModel(),
			store = vm.getStore('userSavedSearchStore'),
			panel = me.getView().down('form'),
			form = panel.getForm(),
			searchButton = panel.down('#search'),
			menus = [{
				iconCls: 'x-fa fa-save',
				ui: 'gray',
				text: '<strong>Save Search</strong>',
				handler: 'onSaveUserSearch'
			}]
		;

		if (searchButton && store && store.getCount() > 0) {
			menus.push('-');
			Ext.each(store.getRange(), function (rec) {
				menus.push({
					text: rec.get('Name'),
					data: rec.get('Data'),
					handler: 'onUserSavedSearchClick'
				});
			});
		}
		searchButton.setMenu(menus);

	},
	onSaveUserSearch: function (btn) {

		var me = this,
			vm = me.getViewModel(),
			store = vm.getStore('userSavedSearchStore'),
			panel = me.getView().down('form'),
			form = panel.getForm(),
			values = form.getValues(),
			myMask = new Ext.LoadMask({msg: 'Please wait...', target: panel}),
			url = QuickStart.util.Global.getApi() + 'case/SaveUserSearch';
		Ext.MessageBox.prompt("Save Current Search", "Enter the name of search", function (confirm, name) {
			if (confirm == 'ok') {

				Ext.Ajax.request({
					url: url,
					method: 'POST',
					headers: {'Content-Type': 'application/json'},
					jsonData: {
						userId: QuickStart.util.Global.getUser().id,
						name: name,
						data: Ext.encode(values),
						type: 1
					},
					success: function (response, opts) {
						myMask.hide();
						var result = Ext.decode(response.responseText);
						if (result != null) {
							if (result.success) {
								QuickStart.util.Global.showMessage(result.message);
								store.reload({
									params: {
										id: QuickStart.util.Global.getUser().id
									}
								});
								me.loadSavedSearches();
							}
						}
					},
					failure: function (response, opts) {

						myMask.hide();
						//  debugger
						Ext.Msg.alert('Status', "failure");
						console.log('server-side failure with status code ' + response.status);
					},
					scope: this
				});
			}
		});

	},
	onUserSavedSearchClick: function (btn) {

		var me = this,
			view = me.getView(),
			form = view.down('form').getForm(),
			vm = me.getViewModel(),
			store = vm.getStore('dashboardStore'),
			filters = [];

		if (btn.config.data) {
			form.setValues(Ext.decode(btn.config.data));
			filters.push({property: 'crDs', value: btn.config.data});
			store.clearFilter();
			store.setFilters(filters);

		}

	},
	onReviewTypeSelected: function (field) {
		var me = this,
			vm = me.getViewModel(),
			store = vm.getStore('reviewSubTypeChainedStore'),
			reviewSubTypeField = field.up('form').getForm().findField('ReviewSubTypeID'),
			filters = [];
		if (reviewSubTypeField) {
			reviewSubTypeField.setValue();
		}
		if (field.getValue() != 4)
			filters.push({property: 'parentCode', value: field.getValue()});
		store.clearFilter();
		store.setFilters(filters);


	}
})
;