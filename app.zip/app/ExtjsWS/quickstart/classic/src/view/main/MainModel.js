Ext.define('QuickStart.view.main.MainModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.main',

    data: {
        currentView: null,
        user: {
            id: 0,
            name: ''
        },
        resources: 'resources',
        selectedHighlightTitle: ''
    },
    formulas: {
        allowedIRRTab: {
            bind: { bindTo: '{user}', deep: true },
            get: function (data) {
                return QuickStart.util.Global.permissions.allowIRRTab();
            }
        },
        allowedCreateCaseReview: {
            bind: { bindTo: '{user}', deep: true },
            get: function (data) {
                return QuickStart.util.Global.permissions.allowCreateCaseReview();
            }
        },
        allowedSecurityManagement: {
            bind: { bindTo: '{user}', deep: true },
            get: function (data) {
                return QuickStart.util.Global.permissions.allowSecurityManagement();
            }
        },
        allowedAccessReportTab: {
            bind: { bindTo: '{user}', deep: true },
            get: function (data) {
                return QuickStart.util.Global.permissions.allowAccessReportTab();
            }
        },
        allowedAccessHelpTab: {
            bind: { bindTo: '{user}', deep: true },
            get: function (data) {
                return QuickStart.util.Global.permissions.allowAccessHelpTab();
            }
        },
        allowedExportImportTab: {
            bind: { bindTo: '{user}', deep: true },
            get: function (data) {
                return QuickStart.util.Global.permissions.allowExportImportTab();
            }
        },
        allowedAdmin: {
            bind: { bindTo: '{user}', deep: true },
            get: function (data) {
                return QuickStart.util.Global.permissions.isAdmin();
            }
        },
        allowedAutomatedSampling: {
            bind: { bindTo: '{user}', deep: true },
            get: function (data) {
                return QuickStart.util.Global.permissions.allowedAutomatedSampling();
            }
        }
    }
});
