Ext.define('QuickStart.view.main.Main', {
    extend: 'Ext.container.Viewport',

    requires: [
        'Ext.button.Segmented',
        'Ext.button.Split',
        'Ext.container.Container',
        'Ext.layout.container.Card',
        'Ext.layout.container.HBox',
        'Ext.layout.container.VBox',
        'Ext.list.Tree',
        'Ext.toolbar.Fill',
        'Ext.toolbar.Toolbar'
    ],

    controller: 'main',
    viewModel: 'main',

    cls: 'sencha-dash-viewport',
    itemId: 'mainView',

    layout: {
        type: 'vbox',
        align: 'stretch'
    },

    listeners: {
        render: 'onMainViewRender'
    },

    items: [
        {
            xtype: 'toolbar',
            cls: 'app-dash-headerbar shadow',
            height: 50,
            itemId: 'headerBar',
            items: [
                // {
                //     xtype: 'component',
                //     reference: 'appLogo',
                //     cls: 'app-logo',
                //     bind:{
                //         html: '<div class="main-logo"><img src="{resources}/images/company-logo7.png"> <span></span></div>'
                //     },
                //     width: 60
                // },
                {
                    xtype: 'component',
                    reference: 'appLogo',
                    cls: 'app-logo',
                    bind: {
                        html: '<div class="main-logo"><img src="user/GetLogo"> <span></span></div>'
                    },
                    width: 175
                },
                {
                    margin: '0 0 0 8',
                    ui: 'header',
                    hidden: true,
                    iconCls: 'x-fa fa-navicon',
                    id: 'main-navigation-btn',
                    handler: 'onToggleNavigationSize'
                },
                {
                    xtype: 'component',
                    html: 'Case Review System',
                    cls: 'selected-highlight-title'
                },
                {
                    xtype: 'component',
                    hidden: true,
                    bind: {
                        html: '{selectedHighlightTitle}'
                    },
                    cls: 'selected-highlight-title'
                },
                '->',
                {
                    xtype: 'segmentedbutton',
                    reference: 'mainMenuButton',
                    // height: '100%',
                    height: 48,
                    defaults: {
                        ui: 'dcf',
                        width: 100,
                        enableToggle: true,
                        //  scale:'large',
                        hrefTarget: '_self'
                    },
                    items: [{
                        itemId: 'irr',
                        iconCls: 'x-fa fa-plus',
                        text: 'IRR Cases',
                        href: '#irr',
                        tooltip: 'IRR Case Review',
                        bind: { hidden: '{!allowedIRRTab}' }

                    }, {
                        itemId: 'newcase',
                        iconCls: 'x-fa fa-plus',
                        text: 'Create Case',
                        href: '#newcase',
                        tooltip: 'Create Case Review',
                        bind: { hidden: '{!allowedCreateCaseReview}' }
                    }, {
                        iconCls: 'x-fa fa-desktop',
                        itemId: 'dashboard',
                        text: 'Dashboard',
                        href: '#dashboard',
                        tooltip: 'Dashboard',
                        pressed: true
                    }, {
                        iconCls: 'x-fa fa-user',
                        itemId: 'security',
                        text: 'Security',
                        href: '#security',
                        tooltip: 'Security Management',
                        bind: { hidden: '{!allowedSecurityManagement}' }
                    }, {
                        iconCls: 'x-fa fa-bar-chart',
                        text: 'Reports',
                        itemId: 'report',
                        href: '#report',
                        tooltip: 'Reports',
                        bind: { hidden: '{!allowedAccessReportTab}' }
                    }, {
                        iconCls: 'x-fa fa-file-excel-o',
                        text: 'Export</br>Import',
                        itemId: 'exportimport',
                        href: '#exportimport',
                        //  tooltip: 'Emport</br>Import',
                        bind: { hidden: '{!allowedExportImportTab}' }
                    }
                        , {
                            iconCls: 'x-fa fa-cogs',
                            itemId: 'sampling',
                            text: 'Automated Sampling',
                            href: '#sampling',
                            tooltip: 'Automated Sampling',
                            bind: { hidden: '{!allowedAutomatedSampling}' }
                        }
                        , {
                        iconCls: 'x-fa fa-cog',
                        itemId: 'admin',
                        text: 'Admin',
                        href: '#admin',
                        tooltip: 'Administrator',
                        bind: { hidden: '{!allowedAdmin}' }
                    }
                    ]
                },

                {
                    hidden: true,
                    iconCls: 'x-fa fa-bell',
                    ui: 'header',
                    href: '#profile',
                    hrefTarget: '_self',
                    tooltip: 'Notifications'
                },

                {
                    // xtype: 'tbtext',
                    ui: 'header',
                    reference: 'userLabel',
                    cls: 'top-user-name',
                    bind: {
                        text: '<strong>{user.name:uppercase}</strong>',
                        tooltip: '<p>{user.name:uppercase}</p><p>{user.role}</p>'
                    }
                },
                {
                    xtype: 'image',
                    cls: 'header-right-profile-image',
                    //  reference: 'userImage',
                    height: 35,
                    width: 35,
                    alt: 'current user image',
                    bind: {
                        //  src: '{resources}/images/user-profile/default.png'
                        src: 'user/GetProfilePicture?id={user.id}'
                    }
                },
                {
                    xtype: 'splitbutton',
                    ui: 'header',
                    width: 40,
                    margin: '0 0 0 -25px',
                    cls: 'help-menu',
                    itemId: 'help',
                    text: '',

                    menu: {
                        items: [
                            {
                                text: 'About CRS',
                                handler: 'onAboutClick'
                            },
                            {
                                text: 'Release Notes',
                                handler: 'onReleaseNotesClick'
                            },
                            {
                                bind: { hidden: '{!allowedAccessHelpTab}' },
                                text: 'Help Center',
                                handler: 'onHelpClick'
                            }
                        ]
                    }
                }
            ]
        },
        {
            xtype: 'maincontainerwrap',
            hidden: true,
            layout: {
                type: 'hbox',
                align: 'stretch',

                // Tell the layout to animate the x/width of the child items.
                animate: true,
                animatePolicy: {
                    x: true,
                    width: true
                }
            },
            id: 'main-view-detail-wrap',
            reference: 'mainContainerWrap',
            flex: 1,
            items: [
                {
                    xtype: 'treelist',
                    reference: 'navigationTreeList',
                    itemId: 'navigationTreeList',
                    ui: 'nav',
                    store: 'NavigationTree',
                    width: 0,
                    hidden: true,
                    //width: 250,

                    expanderFirst: false,
                    expanderOnly: false,
                    listeners: {
                        selectionchange: 'onNavigationTreeSelectionChange'
                    }
                },
                {
                    xtype: 'container',
                    flex: 1, scrollable: 'y',
                    reference: 'mainCardPanel',
                    cls: 'sencha-dash-right-main-container',
                    itemId: 'contentPanel',
                    layout: {
                        type: 'card',
                        anchor: '100%'
                    }
                }
            ]
        },
        {
            xtype: 'comparewindow',
            itemId: 'compareWindow'
        }

    ]
});
