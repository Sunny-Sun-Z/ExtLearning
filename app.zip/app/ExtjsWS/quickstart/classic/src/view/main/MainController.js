
Ext.define('QuickStart.view.main.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.main',

    listen: {
        controller: {
            '#': {
                unmatchedroute: 'onRouteChange'
            }
        }
    },

    routes: {
        ':node': {
            before: 'checkSession',
            action: 'onRouteChange'
            //,
            //conditions: {
            //    ':id': '([0-9]+)'
            //':node': '([%a-zA-Z0-9\\.\\-\\_\\s,]+)'
            //}
        },
        'case/:id': {
            before: 'checkSession',
            action: 'onCaseRouteChange'
        },
        'case/:id/:sid': {
            before: 'checkSession',
            action: 'onCaseReviewRouteChange'
        },
        'newcase/:id': {
            before: 'checkSession',
            action: 'onNewCaseRouteChange'
        }

    },

    lastView: null,
    checkSession: function () {

        var me = this,
            refs = me.getReferences(),
            mainContainerWrap = refs.mainContainerWrap,

            args = Ext.Array.slice(arguments),
            action = args[args.length - 1],
            app = QuickStart.app,
            vm = me.getViewModel();

        if (app.appready) {
            if (app.user) {

                var viewName = me.lastView ? me.lastView.xtype || '' : '';
                var currentAction = me.getRouteTag(action);
                if (QuickStart.util.Global.getAutoSave()) {
                    if (viewName != currentAction && viewName.toLowerCase() == "case") {
                        if (!me.lastView.getViewModel().get('disabledItem')) {
                            var lastVM = me.lastView.getViewModel(),
                                dirty = false;

                            dirty = lastVM.checkDirty(lastVM.modified);
                            if (dirty) {
                                var controller = me.lastView.getController();
                                controller.onCaseUpdate(true);
                            }
                        }
                    }
                }
                mainContainerWrap.setHidden(false);
                mainContainerWrap.up('#mainView').down('#headerBar').setHidden(false);
                vm.setData(QuickStart.util.Global.getConfig());
                action.resume();
            } else {
                action.stop();
                //me.onLoginRouteChange();
            }
        } else {
            app.on('appready', Ext.Function.bind(me.checkSession, me, args), me, { single: true });
        }
    },
    getRouteTag: function (action) {
        var arr = action.getUrlParams().input.split('/');
        return arr.length > 0 ? arr[0] : '';
    },
    setCurrentView: function (hashTag, id, sid, tab) {
        hashTag = (hashTag || '').toLowerCase();

        var me = this,
            mainViewModel = me.getViewModel(),
            refs = me.getReferences(),
            mainCard = refs.mainCardPanel,
            mainLayout = mainCard.getLayout(),
            navigationList = refs.navigationTreeList,
            mainMenuButton = refs.mainMenuButton,
            store = navigationList.getStore(),
            node = store.findNode('routeId', hashTag) ||
                store.findNode('viewType', hashTag),
            view = (node && node.get('viewType')) || 'page404',
            lastView = me.lastView,
            existingItem = mainCard.child('component[routeId=' + hashTag + ']'),
            newView;

        if(!this.hasPermission(view)){
            view = 'page404';
        }
        // Kill any previously routed window
        if (lastView && lastView.isWindow) {
            lastView.destroy();
        }

        lastView = mainLayout.getActiveItem();

        if (!existingItem) {
            newView = Ext.create({
                xtype: view,
                routeId: hashTag,  // for existingItem search later
                hideMode: 'offsets'
            });
        }

        if (!newView || !newView.isWindow) {
            // !newView means we have an existing view, but if the newView isWindow
            // we don't add it to the card layout.
            if (existingItem) {
                // We don't have a newView, so activate the existing view.
                if (existingItem !== lastView) {
                    mainLayout.setActiveItem(existingItem);
                }
                newView = existingItem;
            }
            else {
                // newView is set (did not exist already), so add it and make it the
                // activeItem.
                Ext.suspendLayouts();
                mainLayout.setActiveItem(mainCard.add(newView));
                Ext.resumeLayouts(true);
            }
        }

        navigationList.setSelection(node);

        if (newView.isFocusable(true)) {
            newView.focus();
        }
        if (newView.xtype === 'case') {
            newView.fireEvent('loadcase', newView, parseInt(id), parseInt(sid));
        }
        else if (newView.xtype === 'newcase') {
            newView.fireEvent('loadsamplecase', newView, parseInt(id));
        }

        var btn = mainMenuButton.down('#' + newView.xtype);
        if (btn)
            btn.setPressed(true);

        newView.getViewModel().set('resources', QuickStart.util.Global.getResources());
        mainViewModel.set('resources', QuickStart.util.Global.getResources());
        mainViewModel.set('selectedHighlightTitle', newView.getHighlightTitle ? newView.getHighlightTitle() : '');

        if (newView.xtype === 'newcase') {
            // var rec = Ext.create('QuickStart.model.NewCaseReview', {Reviewers: QuickStart.util.Global.getUser().id});
            //newView.down('casereviewform').reset();
            var rec = Ext.create('QuickStart.model.NewCaseReview');
            for (var index = 0; index < mainCard.items.length; index++) {
                var item = mainCard.items.items[index];
                if (item && item.xtype === "case") {
                    me.lastView.getViewModel().set('caseReview', rec);
                    break;
                }
            }
            newView.getViewModel().set('caseReview', rec);
        }

        me.lastView = newView;
    },

    onNavigationTreeSelectionChange: function (tree, node) {
        var to = node && (node.get('routeId') || node.get('viewType'));
        //debugger
        if (to) {
            //commented by kanchan because its removing case id
            //this.redirectTo(to);
        }
    },

    onToggleNavigationSize: function () {
        var me = this,
            refs = me.getReferences(),
            navigationList = refs.navigationTreeList,
            wrapContainer = refs.mainContainerWrap,
            collapsing = !navigationList.getMicro(),
            new_width = collapsing ? 64 : 250;

        if (Ext.isIE9m || !Ext.os.is.Desktop) {
            Ext.suspendLayouts();

            refs.appLogo.setWidth(new_width);

            navigationList.setWidth(new_width);
            navigationList.setMicro(collapsing);

            Ext.resumeLayouts(); // do not flush the layout here...

            // No animation for IE9 or lower...
            wrapContainer.layout.animatePolicy = wrapContainer.layout.animate = null;
            wrapContainer.updateLayout();  // ... since this will flush them
        }
        else {
            if (!collapsing) {
                // If we are leaving micro mode (expanding), we do that first so that the
                // text of the items in the navlist will be revealed by the animation.
                navigationList.setMicro(false);
            }
            navigationList.canMeasure = false;

            // Start this layout first since it does not require a layout
            refs.appLogo.animate({ dynamic: true, to: { width: new_width } });

            // Directly adjust the width config and then run the main wrap container layout
            // as the root layout (it and its chidren). This will cause the adjusted size to
            // be flushed to the element and animate to that new size.
            navigationList.width = new_width;
            wrapContainer.updateLayout({ isRoot: true });
            navigationList.el.addCls('nav-tree-animating');

            // We need to switch to micro mode on the navlist *after* the animation (this
            // allows the "sweep" to leave the item text in place until it is no longer
            // visible.
            if (collapsing) {
                navigationList.on({
                    afterlayoutanimation: function () {
                        navigationList.setMicro(true);
                        navigationList.el.removeCls('nav-tree-animating');
                        navigationList.canMeasure = true;
                    },
                    single: true
                });
            }
        }
    },

    onMainViewRender: function () {
        if (!window.location.hash) {
            this.redirectTo("dashboard");
        }
        // var tips = [{
        //     target: this.lookup('userLabel').el,
        //     anchor: 'bottom',
        //     anchorOffset: 85, // center the anchor on the tooltip
        //     html: 'this is tooltip'
        // }];
        //
        // this.tips = Ext.Array.map(tips, function(cfg) {
        //     cfg.showOnTap = true;
        //     return new Ext.tip.ToolTip(cfg);
        // });

    },

    onRouteChange: function (id) {
        // console.log(arguments)
        this.setCurrentView(id);
    },
    onNewCaseRouteChange: function (id) {
        // console.log(arguments)
        this.setCurrentView('newcase', id);
    },
    onCaseRouteChange: function (id) {
        // console.log(arguments)
        this.setCurrentView('case', id);
    },
    onCaseReviewRouteChange: function (id, sid) {
        // console.log(arguments)
        this.setCurrentView('case', id, sid);
    },

    onSwitchToModern: function () {
        Ext.Msg.confirm('Switch to Modern', 'Are you sure you want to switch toolkits?',
            this.onSwitchToModernConfirmed, this);
    },

    onSwitchToModernConfirmed: function (choice) {
        if (choice === 'yes') {
            var s = window.location.search;

            // Strip "?classic" or "&classic" with optionally more "&foo" tokens
            // following and ensure we don't start with "?".
            s = s.replace(/(^\?|&)classic($|&)/, '').replace(/^\?/, '');

            // Add "?modern&" before the remaining tokens and strip & if there are
            // none.
            window.location.search = ('?modern&' + s).replace(/&$/, '');
        }
    },

    onEmailRouteChange: function () {
        this.setCurrentView('email');
    },
    onAboutClick: function (btn, e, eOpts) {

        var me = this,
            vm = me.getViewModel(),
            ver = vm.get('assemblyVersion'),
            sessionInfo = vm.get('sessionInfo'),
            user = QuickStart.util.Global.getUser(),
            currDate = new Date(),
            data = {
                version: ver,
                loginId: '[' + user.loginId.toUpperCase() + ']',
                userId: user.id,
                userName: user.name.toUpperCase(),
                database: sessionInfo.databaseSchema,
                region: sessionInfo.region,
                year: sessionInfo.year,
                renderDate: currDate.toLocaleDateString() + ' ' + currDate.toLocaleTimeString(),
                browserName: sessionInfo.browser.Browser + ' ' + sessionInfo.browser.Version,
                ipAddr: sessionInfo.clientAddr,
                sessionId: sessionInfo.sessionId
            },
            aboutWin = Ext.create('Ext.window.Window', {
                title: btn.text,
                titleAlign: 'center',
                height: 450,
                width: 650,
                layout: 'fit',
                items: {
                    xtype: 'crsabout'
                },
                dockedItems: [
                    {
                        xtype: 'toolbar',
                        dock: 'bottom',
                        ui: 'footer',
                        items: ['->', {
                            text: 'Close',
                            ui: 'gray',
                            iconCls: 'x-fa fa-close',
                            handler: function (btn) {
                                btn.up('window').close();
                            }
                        }]
                    }]
            });
        aboutWin.down('crsabout').update(data);
        aboutWin.show();
    },
    onReleaseNotesClick: function (btn, e, eOpts) {

        var me = this,
            vm = me.getViewModel(),
            ver = vm.get('assemblyVersion'),
            title = 'Release Notes for CRS version ' + ver;

        Ext.create('Ext.window.Window', {
            title: title,
            titleAlign: 'center',
            height: 450,
            width: 650,
            layout: 'fit',
            bodyPadding: 15,
            loader: {
                url: 'app/ExtjsWS/quickstart/app/data/releasenotes/releasenotes.html',
                autoLoad: true
            },
            closeAction: 'close',
            scrollable: true,
            dockedItems: [
                {
                    xtype: 'toolbar',
                    dock: 'bottom',
                    ui: 'footer',
                    items: ['->', {
                        text: 'Close',
                        ui: 'gray',
                        iconCls: 'x-fa fa-close',
                        handler: function (btn) {
                            btn.up('window').close();
                        }
                    }]
                }]
        }).show();
    },
    onHelpClick: function (btn, e, eOpts) {

        var title = 'Welcome to the CRS Help Center';

        Ext.create('Ext.window.Window', {
            title: title,
            titleAlign: 'center',
            height: 450,
            width: 650,
            layout: 'fit',
            bodyPadding: 20,
            loader: {
                url: 'app/ExtjsWS/quickstart/app/data/help/help.html',
                autoLoad: true
            },
            closeAction: 'close',
            scrollable: true,
            dockedItems: [
                {
                    xtype: 'toolbar',
                    dock: 'bottom',
                    ui: 'footer',
                    items: ['->', {
                        text: 'Close',
                        ui: 'gray',
                        iconCls: 'x-fa fa-close',
                        handler: function (btn) {
                            btn.up('window').close();
                        }
                    }]
                }]
        }).show();
    },
    hasPermission: function (view) {
        var flag = true;
        if (view === 'newcase' && !QuickStart.util.Global.permissions.allowCreateCaseReview()) {
            flag = false;
        }
        else if ((view === 'security' || view === 'user') && !QuickStart.util.Global.permissions.allowSecurityManagement()) {
            flag = false;
        }
        else if (view === 'report' && !QuickStart.util.Global.permissions.allowAccessReportTab()) {
            flag = false;
        }
        else if (view === 'exportimport' && !QuickStart.util.Global.permissions.allowExportImportTab()) {
            flag = false;
        }
        else if (view === 'admin' && !QuickStart.util.Global.permissions.isAdmin()) {
            flag = false;
        }
        else if (view === 'irr' && !QuickStart.util.Global.permissions.allowIRRTab()) {
            flag = false;
        }
        // else if(view=='dashboard'  ){
        //     flag=false;
        // }


        return flag;
    }
});
