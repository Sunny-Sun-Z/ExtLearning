/**
 * Created by kkora on 9/19/2017.
 */
Ext.define('QuickStart.view.admin.Admin', {
    extend: 'Ext.Container',

    requires: [
        'Ext.container.Container',
        'Ext.layout.container.Card',
        'Ext.layout.container.HBox',
        'Ext.list.Tree',
        'QuickStart.view.admin.AdminController',
        'QuickStart.view.admin.AdminModel',
        'QuickStart.view.pages.BlankPage'
    ],

    xtype: 'admin',


    viewModel: {
        type: 'admin'
    },
    config: {
        highlightTitle: 'admin'
    },

    controller: 'admin',
    layout: {
        type: 'hbox',
        align: 'stretch',

        // Tell the layout to animate the x/width of the child items.
        animate: true,
        animatePolicy: {
            x: true,
            width: true
        }
    },
    flex: 1,
    items: [
        {
            xtype: 'treelist',
            reference: 'adminNavigationTreeList',
            itemId: 'adminNavigationTreeList',
            ui: 'nav',
            store: 'AdminNavigationTree',
            width: 250,
            expanderFirst: false,
            expanderOnly: false,
            listeners: {
                selectionchange: 'onNavigationTreeSelectionChange'
            }
        },
        {
            xtype: 'container',
            flex: 1, scrollable: 'y',
            reference: 'adminCardPanel',
            itemId: 'adminCardPanel',
            cls: 'sencha-dash-right-main-container',
            layout: {
                type: 'card',
                anchor: '100%'
            }
        }
    ],
    listeners: {
         afterrender: 'afterAdminPanelRender'
    }
});