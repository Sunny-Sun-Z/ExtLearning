/**
 * Created by kkora on 12/21/2017.
 */
Ext.define('QuickStart.view.admin.exportimport.ProcessedGrid', {
    extend: 'Ext.grid.Panel',
    cls: 'dcf-grid',

    xtype: 'exportimportprocessedgrid',

    requires: [
        'Ext.grid.column.Action',
        'Ext.grid.column.RowNumberer',
        'Ext.grid.filters.Filters',
        'Ext.toolbar.Fill'
    ],
    title: 'Exported Cases',
    reference: 'exportImportProcessedGrid',
    bind: '{processedCases}',
    plugins: ['gridfilters'],
    columns: [
        { xtype: 'rownumberer' },
        {
            text: 'Case ID',
            dataIndex: 'CaseID',
            filter: {
                //type: 'number',
                itemDefaults: {
                    xtype: 'numberfield',
                    emptyText: 'Search for...'
                }
            }
        },
        {
            menuDisabled: true,
            hidden: true,
            text: 'CaseReviewRootID',
            dataIndex: 'CaseReviewRootID'
        },
        {
            menuDisabled: true,
            hidden: true,
            text: 'CaseReviewID',
            dataIndex: 'CaseReviewID'
        },
        {
            text: 'Case Name',
            flex: 2,
            dataIndex: 'CaseName',
            filter: {
                type: 'string',
                itemDefaults: {
                    emptyText: 'Search for...'
                }
            }
        },

        {
            menuDisabled: true,
            text: 'Status',
            hidden: true,
            flex: 1,
            dataIndex: 'CaseStatusCode',
            renderer: 'rendererCaseStatus'
        },
        {
            menuDisabled: true,
            text: 'Type',
            flex: 1,
            hidden: true,
            dataIndex: 'ReviewTypeID',
            renderer: 'rendererReviewType'
        },
        {
            menuDisabled: true,
            text: 'Sub Type',
            hidden: true,
            flex: 1,
            dataIndex: 'ReviewSubTypeID',
            renderer: 'rendererReviewSubType'
        },
        {
            menuDisabled: true,
            text: 'Review Start',
            hidden: true,
            flex: 1,
            dataIndex: 'ReviewStartDate',
            formatter: 'date("m/d/Y")'
        },
        {
            text: 'Review End',
            menuDisabled: true,
            hidden: true,
            flex: 1,
            dataIndex: 'ReviewCompleted',
            formatter: 'date("m/d/Y")'
        },
        {
            menuDisabled: true,
            hidden: true,
            text: 'Site Name',
            flex: 1,
            dataIndex: 'SiteCode',
            renderer: 'rendererSite'

        },
        {
            text: 'Is Processed?',
            menuDisabled: true,
            flex: 1,
            align: 'center',
            dataIndex: 'BatchProcessedID',
            renderer: function (v) {
                return Ext.isEmpty(v) ? 'No' : 'Yes';
            }
        },
        {
            menuDisabled: true,
            flex: 1,
            text: 'Exported On',
            dataIndex: 'FederalProcessedDate',
            formatter: 'date("m/d/Y h:i:s A")'
        },
        // {
        //     menuDisabled: true,
        //     flex: 1,
        //     text: 'User Exported On',
        //     dataIndex: 'ExportedDate',
        //     formatter: 'date("m/d/Y h:i:s A")'
        // },
        {
            menuDisabled: true,
            text: 'Exported By',
            flex: 1,
            dataIndex: 'ExportedBy',
            renderer: 'rendererUser'
        },
        {
            xtype: 'actioncolumn',
            items: [
                {
                    iconCls: 'x-fa fa-download',
                    handler: 'onFileDownload',
                    tooltip: 'Download file',
                    isActionDisabled: function (action, rowIndex, colIndex, e, rec) {
                        return !rec.get('HasFile');
                    }
                }
            ],
            align: 'center',
            menuDisabled: true,
            width: 70,
            sortable: false,
            dataIndex: 'bool',
            tooltip: 'Actions'
        }
    ],
    dockedItems: [
        {
            xtype: 'pagingtoolbar',
            dock: 'bottom',
            itemId: 'userPaginationToolbar',
            displayInfo: true,
            bind: '{processedCases}',
            items: [{
                text: 'Open Export Folder',
                iconCls: 'x-fa fa-download',
                target: 'blank',
                bind: {
                    href: 'file:///{exportPath}',
                    hidden: '{!exportPath}'
                }
            }]
        }]

});