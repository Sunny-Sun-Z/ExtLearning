/**
 * Created by kkora on 4/5/2018.
 */
Ext.define('QuickStart.view.admin.comparetool.CompareTool', {
    extend: 'Ext.panel.Panel',
    title: 'Case Compare Tool',

    requires: [
        'Ext.form.field.Display',
        'Ext.layout.container.Fit',
        'Ext.toolbar.Fill',
        'QuickStart.view.admin.comparetool.CompareToolController',
        'QuickStart.view.admin.comparetool.CompareToolModel'
    ],

    xtype: 'comparetool',
    viewModel: {
        type: 'comparetool'
    },
    controller: 'comparetool',
    layout:'fit',
    items: [
        {
            itemId: 'compareCaseGrid',
            xtype: 'comparecasegrid'
        }
    ],
    dockedItems: [
        {
            ui:'footer',
            xtype: 'toolbar',
            items: [
                {
                    xtype: 'displayfield',
                    labelWidth:50,
                    itemId: 'caseLabel',
                    fieldLabel: 'Cases',
                    bind:'{caseNames}'
                },
                '->',
                {
                    text:'Compare Cases',
                    ui: 'soft-purple',
                    iconCls: 'x-fa fa-clone',
                    bind:{
                        disabled:'{noOfCaseSelected!=2}'
                    },
                    handler: 'onCaseComparePreview'
                },
                {
                    text:'Clear',
                    ui: 'gray',
                    iconCls: 'x-fa fa-close',
                    handler: 'onCaseComparePreviewSelectionClear'
                }
            ]
        }
    ]
});