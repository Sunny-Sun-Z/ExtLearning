/**
 * Created by kkora on 1/25/2018.
 */
Ext.define('QuickStart.view.admin.exportimport.ExportImportController', {
	extend: 'Ext.app.ViewController',
	alias: 'controller.exportimport',
	mixins: ['QuickStart.mixins.Global', 'QuickStart.view.mixins.ExportImport'],

	requires: [
		'Ext.form.Panel'
	],
	errors: [],
	/**
	 * Called when the view is created
	 */
	init: function () {

	},
	onAfterRender: function () {

	},

	validateAssignUsers: function (data) {
		var me = this,
			reviewers = data.Reviewers || []
		;
		me.errors = [];
		var empty= reviewers.length==0 || Ext.isEmpty(data.InitialQAUserID) || Ext.isEmpty(data.SecondQAUserID)  ;
		if(data.Ids.length>1 && empty){
			me.errors.push('Please enter the required fields');
			return;
		}
		if(data.Ids.length==1 && empty && Ext.isEmpty(data.CaseID)){
			me.errors.push('Please enter the required fields');
			return;
		}

		if (!Ext.isArray(reviewers) && !Ext.isEmpty(reviewers)) {
			reviewers = [];
			reviewers.push(reviewers);
		}
		var result = reviewers.filter(function (item) {
			return item == data.InitialQAUserID;
		});

		if (result > 0)
			me.errors.push('Same person cannot be selected as Reviewer and Initial QA');

		result = reviewers.filter(function (item) {
			return item == data.SecondQAUserID;
		});

		if (result > 0)
			me.errors.push('Same person cannot be selected as Reviewer and Second Level QA');
		else if (data.InitialQAUserID === data.SecondQAUserID)
			me.errors.push('Same person cannot be selected as Initial QA and Second Level QA');

		result = reviewers.filter(function (item) {
			return item == data.SecondaryOversightUserID;
		});

		if (result > 0)
			me.errors.push('Same person cannot be selected as Reviewer and Secondary Oversight');
		else if (data.InitialQAUserID === data.SecondaryOversightUserID)
			me.errors.push('Same person cannot be selected as Initial QA and Secondary Oversight');
		else if (data.SecondQAUserID === data.SecondaryOversightUserID)
			me.errors.push('Same person cannot be selected as Second Level QA and Secondary Oversight');

		var result = reviewers.filter(function (item) {
			return item == data.CtSecondaryOversightUserID;
		});

        console.log(data.SecondaryOversightUserID,data.CtSecondaryOversightUserID);
		if (result > 0)
			me.errors.push('Same person cannot be selected as Reviewer and CT Secondary Oversight');
		else if (data.InitialQAUserID === data.CtSecondaryOversightUserID)
			me.errors.push('Same person cannot be selected as Initial QA and CT Secondary Oversight');
		else if (data.SecondQAUserID === data.CtSecondaryOversightUserID)
			me.errors.push('Same person cannot be selected as Second Level QA and CT Secondary Oversight');
		else if (data.SecondaryOversightUserID != '' && data.SecondaryOversightUserID === data.CtSecondaryOversightUserID)
			me.errors.push('Same person cannot be selected as Secondary Oversight and CT Secondary Oversight');

		return me.errors.length == 0;
	},

	onCaseExport: function (btn) {
		var me = this,
			vm = me.getViewModel(),
			grid = this.lookupReference('exportImportGrid'),
			selections = grid.getSelection(),
			data = selections.length > 0 ? selections[0].getData() : {},
			id = data.CaseReviewRootID,
			name = data.CaseName,
			recs = []
		;
		Ext.each(selections, function (rec) {
			recs.push({id: rec.get('CaseReviewRootID'), name: rec.get('CaseName')})
		});
		if (selections.length == 1)
			me.onExport(id, name, grid);
		else
			me.onExportMultiple(recs, grid);
	},
	onCaseImportClick: function (btn) {
		console.log('onCaseImport')
		var me = this,
			win = me.getView().down('#importWindow'),
			form = win.down('form').getForm()
		;

		win.show(btn);
		form.reset();
		form.isValid();

	},
	onCaseImport: function (btn) {
		console.log('onCaseImport')
		var me = this,
			win = btn.up('window'),
			form = win.down('form').getForm()
		;
		if (form.isValid()) {
			form.submit({
				headers: {'Content-Type': 'application/json'},
				url: QuickStart.util.Global.getApi() + 'setting/import',
				waitMsg: 'Uploading Case file...',
				success: function (fp, o) {
					win.close();
					var result = Ext.decode(this.response.responseText);
					if (result != null) {
						QuickStart.util.Global.showMessage(result.message);
					}
				},
				failure: function () {
					var result = Ext.decode(this.response.responseText);
					Ext.MessageBox.show({
						title: 'Error',
						msg: result.message,
						buttons: Ext.MessageBox.OK,
						icon: Ext.Msg.ERROR
					});

				}

			});
		}
	},
	onFileDownload: function (grid, row, col, view, op, rec) {
		console.log('onFileDownload')
		var me = this,
			data = rec.getData(),
			config =
				{
					params: {CaseReviewID: data.CaseReviewID},
					method: 'GET',
					url: QuickStart.util.Global.getApi() + 'setting/download'
				}
		;
		me.download(config);

	},
	onAssignUsersToCase: function (btn) {
		var me = this,
			win = me.getView().down('#assignUsersWindow'),
			form = win.down('form').getForm(),
			caseIdField = win.down('#CaseID'),
			grid = me.lookupReference('importGrid'),
			count = grid.getSelection().length
		;

		win.show(btn);
		caseIdField.setDisabled(count > 1);
		form.reset();
		form.isValid();
	},
	onAssignUsers: function (btn) {
		var me = this,
			win = btn.up('window'),
			form = win.down('form').getForm(),
			values = form.getValues(),
			grid = me.lookupReference('importGrid'),
			selectedIds = Ext.Array.pluck(Ext.Array.pluck(grid.getSelection(), 'data'), 'CaseReviewID'),
			myMask = new Ext.LoadMask({msg: 'Please wait...', target: win}),
			url = QuickStart.util.Global.getApi() + 'setting/AssignUsersToCase'
		;
		values['Ids'] = selectedIds;


		if (!me.validateAssignUsers(values)) {
			Ext.Msg.show({
				title: 'Validation',
				message: me.errors.join('<br><br>'),
				buttons: Ext.Msg.YES,
				icon: Ext.Msg.ERROR
			});

			return false;
		}
		myMask.show();

		Ext.Ajax.request({
			url: url,
			method: 'POST',
			headers: {'Content-Type': 'application/json'},
			params: {
				userID: QuickStart.util.Global.getUser().id
			},
			jsonData: values,
			success: function (response, opts) {
				myMask.hide();
				//  debugger
				var result = Ext.decode(response.responseText);

				if (result != null && result.success) {
					QuickStart.util.Global.showMessage(result.message);
					grid.getStore().reload();
					win.close();
				}
				else {
					QuickStart.util.Global.showErrors(result.message);
				}

			},
			failure: function (response, opts) {

				myMask.hide();
				//  debugger
				Ext.Msg.alert('Status', "failure");
				console.log('server-side failure with status code ' + response.status);
			},
			scope: this
		});

	},

});