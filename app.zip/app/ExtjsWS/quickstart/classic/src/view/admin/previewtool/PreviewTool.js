/**
 * Created by kkora on 4/5/2018.
 */
Ext.define('QuickStart.view.admin.previewtool.PreviewTool', {
    extend: 'Ext.panel.Panel',
    title: 'Case Review Time Machine',

    requires: [
        'Ext.button.Segmented',
        'Ext.form.field.ComboBox',
        'Ext.form.field.Display',
        'QuickStart.view.admin.previewtool.PreviewToolController',
        'QuickStart.view.admin.previewtool.PreviewToolModel'
    ],

    xtype: 'previewtool',


    viewModel: {
        type: 'previewtool'
    },

    controller: 'previewtool',
    scrollable: 'y',
    items: [
       {
           margin: 0,
           title: '',
           hidden:true,
           xtype: 'casepreviewcontainer'
       }
    ],
    dockedItems: [
       {
           // ui:'footer',
           xtype: 'toolbar',
           items: [
               {
                   xtype: 'combobox',
                   displayField: 'Name',
                   valueField: 'Id',
                   forceSelection: true,
                   queryMode: 'remote',
                   minChars: 1,
                   pageSize: 25,
                   labelWidth: 80,
                   triggerAction: 'all',
                   flex: 1,
                   listeners: {
                       //change: 'onSearchUser',
                       select: 'onCaseChanged',
                       beforequery: function (queryPlan, eOpts) {
                           queryPlan.combo.lastQuery = null;
                       }
                   },
                   fieldLabel: 'Case Name',
                   bind: { store: '{cases}' },
                   name: 'CaseId',
                   tpl: new Ext.create('Ext.XTemplate',
                       '<tpl for=".">',
                       '<div class="x-boundlist-item">',
                       '<div ><strong>{Id} - {Name}</strong></div>',
                       '<div >Type : {Type}</div>',
                       '<div>Status : <span class="status-color-{CaseStatusCode}">{Status}</span></div><hr>',
                       '</div>',
                       '</tpl>'
                   )
               },
              // {
              //     xtype: 'checkbox',
              //     itemId: 'showCase',
              //     boxLabel: 'Show Case',
              //     inputValue: 1,
              //     uncheckedValue: 2
              // },
              //{
              //    xtype: 'checkbox',
              //    itemId: 'showQaNotes',
              //    boxLabel: 'Show QA Notes',
              //    inputValue: 1,
              //    uncheckedValue: 2
              //},
              //{
              //    xtype: 'checkbox',
              //    itemId: 'showQaInterviewNotes',
              //    boxLabel: 'Show QA Interview Notes',
              //    inputValue: 1,
              //    uncheckedValue: 2
              //},
               {
                   xtype: 'displayfield',
                   hidden:true,
                   labelAlign:'right',
                   itemId: 'versionLabel',
                   fieldLabel: 'Version'
               },

           ]
       },
       {
           xtype: 'toolbar',
           itemId: 'versionToolbar',
           overflowHandler: 'scroller', //'menu/scroller'
           padding: 0,
           margin:0,
           defaults:{padding:'5px'},
           items: [{
               itemId: 'versionGroup',
               xtype: 'segmentedbutton',
               defaults:{handler:'onPreviewClick'},
               items: []
           }],
           ui: 'footer'
       }
    ]
});