/**
 * Created by kkora on 1/25/2018.
 */
Ext.define('QuickStart.view.admin.exportimport.ExportImportModel', {
	extend: 'Ext.app.ViewModel',
	alias: 'viewmodel.exportimport',
	requires: [
		'Ext.data.reader.Json',
		'QuickStart.model.Dashboard',
		'QuickStart.proxy.API'
	],
	stores: {
		exportCases: {
			model: 'QuickStart.model.Dashboard',
			autoLoad: true,
			pageSize: 20,
			remoteFilter: true,
			remoteSort: true,
			filters: [{property: "crDs", value: ''}],
			proxy: {
				url: QuickStart.util.Global.getApi(),
				type: 'ajax',
				paramsAsJson: true,
				pageParam: null,
				api: {
					//read: 'case/DashboardData'
					read: 'setting/GetExportCaseAvailable'

				},
				//  actionMethods: {read: 'POST'},
				reader: {
					type: 'json',
					rootProperty: 'data',
					totalProperty: 'total'
				}
			}
		},

		processedCases: {
			model: 'QuickStart.model.Dashboard',
			autoLoad: true,
			pageSize: 20,
			remoteFilter: true,
			remoteSort: true,
			filters: [{property: "crDs", value: ''}],
			proxy: {
				url: QuickStart.util.Global.getApi(),
				type: 'ajax',
				paramsAsJson: true,
				pageParam: null,
				api: {
					//read: 'case/DashboardData'
					read: 'setting/GetProcessedExportCases'

				},
				//  actionMethods: {read: 'POST'},
				reader: {
					type: 'json',
					rootProperty: 'data',
					totalProperty: 'total'
				}
			}
		},
		importCases: {
			model: 'QuickStart.model.Dashboard',
			autoLoad: true,
			pageSize: 20,
			remoteFilter: true,
			remoteSort: true,
			filters: [{property: "crDs", value: ''}],
			proxy: {
				url: QuickStart.util.Global.getApi(),
				type: 'ajax',
				paramsAsJson: true,
				pageParam: null,
				api: {read: 'setting/GetImportedCases'},
				reader: {
					type: 'json',
					rootProperty: 'data',
					totalProperty: 'total'
				}
			}
		},
		users: {
			model: 'QuickStart.model.BaseLookup',
			autoLoad: true,
			filters: [{ property: 'name', value: '' }],
			proxy: {
				url: QuickStart.util.Global.getApi(),
				type: 'ajax',
				paramsAsJson: true,
				pageParam: null,
				api: {
					read: 'lookup/GetAllUsers'
				},
				reader: {
					type: 'json',
					rootProperty: 'data',
					totalProperty: 'total'
				}
			}
		},
		reviewers: {
			type: 'chained',
			source: '{users}',
			filters: [{ property: 'IsReviewer', value: true }]
		},
		qas: {
			type: 'chained',
			source: '{users}',
			filters: [{ property: 'IsQa', value: true }]
		},
		oversights: {
			type: 'chained',
			source: '{users}',
			filters: [{ property: 'IsOversight', value: true }]
		},
		qas2: {
			type: 'chained',
			source: '{users}',
			filters: [{ property: 'IsQa', value: true }]
		},
		ctoversights: {
			type: 'chained',
			source: '{users}',
			filters: [{ property: 'IsOversight', value: true }]
		}
	},

	data: {
		/* This object holds the arbitrary data that populates the ViewModel and is then available for binding. */
	}
});