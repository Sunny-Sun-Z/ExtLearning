/**
 * Created by kkora on 1/25/2018.
 */
Ext.define('QuickStart.view.admin.exportimport.ExportImport', {
    extend: 'Ext.tab.Panel',

    requires: [],

    xtype: 'exportimport',

    controller: 'exportimport',
    margin: 20,
    viewModel: {
        type: 'exportimport'
    },
    items: [
        {
            xtype: 'exportimportgrid'
		},
		{
			xtype: 'exportimportprocessedgrid'
		},
		{
			xtype: 'importgrid'
        },
        {
            xtype: 'importwindow',
            itemId: 'importWindow'
        },
        {
            xtype: 'assignusers',
            itemId: 'assignUsersWindow'
        }
    ],
    listeners: {
        afterrender: 'onAfterRender'
    }
});