/**
 * Created by kkora on 4/9/2018.
 */
Ext.define('QuickStart.view.admin.auditlog.AuditLogModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.auditlog',

    stores: {
     logs:{
         model: 'QuickStart.model.Log',
         autoLoad: true,
         pageSize: 20,
         remoteFilter: true,
         remoteSort: true,
         filters: [{property: 'name', value: ''}],
         proxy: {
             url: QuickStart.util.Global.getApi(),
             type: 'ajax',
             paramsAsJson: true,
             pageParam: null,
             api: {                read: 'setting/GetLogs'            },
             reader: {
                 type: 'json',
                 rootProperty: 'data',
                 totalProperty: 'total'
             }
         },
         listeners:{
             // load:'onLoadAuditLog'
         }
     },
     users: {
         model: 'QuickStart.model.BaseLookup',
         autoLoad: true,
         filters: [{ property: 'name', value: '' }],
         proxy: {
             url: QuickStart.util.Global.getApi(),
             type: 'ajax',
             paramsAsJson: true,
             pageParam: null,
             api: {
                 read: 'lookup/GetAllUsers'
             },
             reader: {
                 type: 'json',
                 rootProperty: 'data',
                 totalProperty: 'total'
             }
         }
     }

    },

    data: {
        /* This object holds the arbitrary data that populates the ViewModel and is then available for binding. */
    }
});