/**
 * Created by kkora on 12/21/2017.
 */
Ext.define('QuickStart.view.admin.rule.Form', {
    extend: 'Ext.form.Panel',

    xtype: 'ruleform',

    requires: [
        'Ext.form.field.*',
        'Ext.layout.container.HBox',
        'Ext.toolbar.Fill'
    ],

    bodyPadding: '5 10 0 10',
    defaultType: 'fieldcontainer',
    items: [
        {
            width: 150,
            xtype: 'checkbox',
            boxLabel: '<b>Begin Group</b>',
            checked: false,
            bind: {
                hidden: '{!addNew}',
                value: '{rule.OpenBracket}'
            }
        },
        {
            layout: 'hbox',
            bind: {hidden: '{!addNew}'},
            defaults: {
                //   flex:1,
                labelWidth: 100,
                labelAlign: 'right'
            },
            items: [{
                flex: 1,
                allowBlank: false,
                xtype: 'combobox',
                fieldLabel: 'Property Name',
                queryMode: 'local',
                editable: false,
                displayField: 'name',
                valueField: 'code',
                bind: {
                    store: '{predicates}',
                    value: '{rule.Predicate}'
                },
                listConfig: {
                    cls: 'grouped-list',
                    width: 600
                },
                tpl: new Ext.create('Ext.XTemplate',
                    '<tpl for=".">',
                    '<tpl for="group" if="this.shouldShowHeader(group)"><div class="group-header">{[this.showHeader(values.group)]}</div></tpl>',
                    '<div class="x-boundlist-item">{name}</div>',
                    '</tpl>', {
                        shouldShowHeader: function (group) {
                            return this.currentGroup !== group;
                        },
                        showHeader: function (group) {
                            this.currentGroup = group;
                            return group;
                        }
                    })
            }]
        },
        {
            layout: 'hbox',
            bind: {hidden: '{!addNew}'},
            defaults: {
                //   flex:1,
                labelWidth: 100,
                labelAlign: 'right'
            },
            items: [
                {
                    allowBlank: false,
                    xtype: 'combobox',
                    fieldLabel: 'Operator',
                    queryMode: 'local',
                    editable: false,
                    displayField: 'name',
                    valueField: 'name',
                    bind: {
                        store: '{operators}',
                        value: '{rule.Operator}'
                    }
                },
                {
                    xtype: 'combobox',
                    fieldLabel: 'Target Value',
                    queryMode: 'local',
                    displayField: 'name',
                    valueField: 'code',
                    bind: {
                        store: '{targetValues}',
                        value: '{rule.TargetValue}'
                    }
                },
                {
                    flex: 1,
                    labelWidth: 125,
                    xtype: 'combobox',
                    fieldLabel: 'Or Target Lookup',
                    queryMode: 'local',
                    editable: false,
                    displayField: 'name',
                    valueField: 'code',
                    bind: {
                        store: '{predicates}',
                        value: '{rule.TargetValue1}'
                    },
                    listConfig: {
                        cls: 'grouped-list',
                        width: 600
                    },
                    tpl: new Ext.create('Ext.XTemplate',
                        '<tpl for=".">',
                        '<tpl for="group" if="this.shouldShowHeader(group)"><div class="group-header">{[this.showHeader(values.group)]}</div></tpl>',
                        '<div class="x-boundlist-item">{name}</div>',
                        '</tpl>', {
                            shouldShowHeader: function (group) {
                                return this.currentGroup !== group;
                            },
                            showHeader: function (group) {
                                this.currentGroup = group;
                                return group;
                            }
                        }),
                    triggers: {
                        clear: {
                            weight: -1,
                            cls: 'x-form-clear-trigger',
                            handler: function () {
                                this.setValue('');
                            }
                        }
                    }
                }, {
                    flex: 1,
                    labelWidth: 125,
                    xtype: 'textfield',
                    fieldLabel: 'Ruleset Name',
                    bind: '{rule.RuleSetName}'
                }
            ]
        },
        {
            //  bind: {hidden: '{!addNew}'},
            hidden: true,
            layout: 'hbox',
            defaults: {
                //   flex:1,
                labelWidth: 100,
                labelAlign: 'right'
            },
            items: [{
                flex: 1,
                xtype: 'combobox',
                fieldLabel: 'Data Type',
                queryMode: 'local',
                editable: false,
                bind: {
                    store: '{dataTypes}',
                    value: '{rule.DataType}'
                },
                displayField: 'name',
                valueField: 'code'
            }, {
                xtype: 'numberfield',
                fieldLabel: 'Priority',
                bind: '{rule.Priority}'
            }, {
                xtype: 'combobox',
                fieldLabel: 'Mode',
                queryMode: 'local',
                editable: false,
                value: 'Server',
                bind: {
                    store: '{modes}',
                    value: '{rule.Mode}'
                },
                displayField: 'name',
                valueField: 'name'
            }]
        },
        {
            // bind: {hidden: '{!addNew}'},
            hidden: true,
            layout: 'hbox',
            defaults: {
                //   flex:1,
                labelWidth: 100,
                labelAlign: 'right'
            },
            items: [
                {
                    flex: 1,
                    xtype: 'combobox',
                    fieldLabel: 'Category',
                    queryMode: 'local',
                    editable: false,
                    bind: {
                        store: '{modes}',
                        value: '{rule.Category}'
                    },
                    displayField: 'name',
                    valueField: 'name'
                }, {
                    flex: 1,
                    xtype: 'textfield',
                    fieldLabel: 'Sub Category',
                    bind: '{rule.SubCategory}'

                }]
        },
        {
            bind: {hidden: '{!addNew}'},
            layout: 'hbox',
            items: [{
                flex: 1,
                xtype: 'textarea',
                labelAlign: 'top',
                fieldLabel: 'Validation Message',
                bind: '{rule.ErrorMessage}'

            }]
        },
        {
            bind: {hidden: '{!addNew}'},
            layout: 'hbox',
            items: [{
                width: 150,
                xtype: 'checkbox',
                boxLabel: 'Business Required',
                checked: false,
                bind: '{rule.Required}'
            }, {
                width: 100,
                xtype: 'checkbox',
                boxLabel: 'Enabled',
                checked: true,
                bind: '{rule.Enabled}'
            }, {

                flex: 1,
                labelAlign: 'right',
                xtype: 'datefield',
                fieldLabel: 'Start Date',
                bind: '{rule.StartDate}'
            }, {

                flex: 1,
                xtype: 'datefield',
                labelAlign: 'right',
                fieldLabel: 'End Date',
                bind: '{rule.EndDate}'
            }, {
                flex: 1,
                xtype: 'combobox',
                labelAlign: 'right',
                fieldLabel: 'Group OP',
                queryMode: 'local',
                editable: false,
                value: 0,
                bind: {
                    store: '{logicOperators}',
                    value: '{rule.LogicOperator}'
                },
                displayField: 'name',
                valueField: 'code'

            }, {
                xtype: 'numberfield',
                labelAlign: 'right',
                hideTrigger:true,
                fieldLabel: 'Priority',
                bind: '{rule.Priority}'
            }]
        },
        {
            width: 150,
            xtype: 'checkbox',
            boxLabel: '<b>End Group</b>',
            checked: false,
            bind: {
                hidden: '{!addNew}',
                value: '{rule.CloseBracket}'
            }

        }
    ],
    dockedItems: [
        {
            xtype: 'toolbar',
            ui: 'footer',
            items: [
                {
                    bind: {disabled: '{addNew}'},
                    text: 'Add',
                    itemId: 'add',
                    iconCls: 'x-fa fa-plus',
                    handler: 'onAddRecord'
                }]
        },
        {
            xtype: 'toolbar',
            dock: 'bottom',
            ui: 'footer',
            bind: {hidden: '{!addNew}'},
            items: [{
                text: 'Compile',
                itemId: 'compile',
                ui: 'soft-purple',
                hidden: true,
                iconCls: 'x-fa fa-cog',
                handler: 'onCompileRecord'
            },
                '->',
                {
                    text: 'Save',
                    itemId: 'save',
                    formBind: true,
                    ui: 'soft-green',
                    iconCls: 'x-fa fa-save',
                    handler: 'onSaveRecord'
                },
                {
                    text: 'Save & Add New',
                    itemId: 'addnew',
                    formBind: true,
                    iconCls: 'x-fa fa-clipboard',
                    handler: 'onSaveAndAddNewRecord'
                },
                {
                    text: 'Reset',
                    itemId: 'reset',
                    iconCls: 'x-fa fa-close',
                    ui: 'gray',
                    handler: 'onResetRecord'
                }

            ]
        }]
});