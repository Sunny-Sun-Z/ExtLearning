/**
 * Created by ssun on 12/02/2019.
 */


Ext.define('QuickStart.view.admin.reviewerprofile.ReviewerProfileModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.reviewerprofile',

    requires: [
        'QuickStart.store.GroupLookups',
        //'QuickStart.store.ReviewerProfiles'
    ],
    data: {
        current: {
            user: null,
            userAction: 'Edit',
            rolePermissions: null
        }
    },
    
    stores: {
        reviewerStore: {
            model: 'QuickStart.model.ReviewerProfile',
            autoLoad: true,
            pageSize: 20,
            remoteFilter: true,
            remoteSort: true,
            filters: [{ property: 'Name', value: '' }, { property: 'IsProfileActive', value: true } ],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'user/GetAllReviewerProfiles',
                    //create: 'user/CreateUser',
                    //update: 'user/UpdateUser',
                    //destroy: 'user/DeactivateUser'
                },
                writer: {
                    type: 'json',
                    writeAllFields: true,
                    // allowSingle: true,
                    // rootProperty: 'data'
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            },
            listeners: {
                load: 'onReviewerStoreLoad'
            }
        },

        userStore: {
            model: 'QuickStart.model.User',
            autoLoad: true,
            pageSize: 200,
            remoteFilter: true,
            remoteSort: true,
            filters: [{ property: 'IsProfileActive', value: '' }, { property: 'name', value: '' }],  // 1: true; 2: false; 3: false and null 
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'user/GetUsers',
                },
                writer: {
                    type: 'json',
                    writeAllFields: true,
                   
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            },
            //listeners: {
            //    load: 'onUserStoreLoad'
            //}
        },

        usersStore: {
            type: 'chained',
            source: '{userStore}'
        },
       
        hometownStore: {
           model: 'QuickStart.model.BaseLookup',
            autoLoad: true,
            pageSize: 200,
            remoteFilter: true,
            remoteSort: true,
            //filters: [{ property: 'Name', value: ''}],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'lookup/GetHometowns'
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },

        hometownsStore: {
            type: 'chained',
            sorters: [{ property: 'Id', direction: 'ASC' }],
            source: '{hometownStore}'
        },

        
        previousOfficeStore: {
            type: 'grouplookups',
            sorters: [{ property: 'medium', direction: 'ASC' }],
            filters: [{ property: 'group', value: 'Office', operator: '=' }]
        },

        currentOfficeStore: {
            type: 'grouplookups',
            sorters: [{ property: 'medium', direction: 'ASC' }],
            filters: [{ property: 'group', value: 'Office', operator: '=' }]
        },

        //phoneServiceProvidersStore: {
        //    model: 'QuickStart.model.BaseLookup',
        //    autoLoad: true,
        //    pageSize: 100,
        //    proxy: {
        //        url: QuickStart.util.Global.getApi(),
        //        type: 'ajax',
        //        paramsAsJson: true,
        //        pageParam: null,
        //        api: {
        //            read: 'lookup/MobileCarrierGateway'
        //        },
        //        reader: {
        //            type: 'json',
        //            rootProperty: 'data',
        //            totalProperty: 'total'
        //        }
        //    }
        //},

    }
});
