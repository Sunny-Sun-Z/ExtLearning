/**
 * Created by kkora on 4/9/2018.
 */
Ext.define('QuickStart.view.admin.auditlog.AuditLog', {
    extend: 'Ext.Container',
    xtype: 'auditlog',
    requires: [
        'QuickStart.view.admin.auditlog.AuditLogModel',
        'QuickStart.view.admin.auditlog.AuditLogController'
    ],
    viewModel: {
        type: 'auditlog'
    },
    controller: 'auditlog',

    margin: 20,
    layout:'fit',
    items: [
        {
            xtype: 'auditloggrid'
        }
    ]
});