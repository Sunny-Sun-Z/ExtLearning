/**
 * Created by kkora on 4/5/2018.
 */
Ext.define('QuickStart.view.admin.previewtool.PreviewToolModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.previewtool',

    stores: {
        cases: {
            model: 'QuickStart.model.BaseLookup',
            autoLoad: false,
            pageSize: 20,
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'lookup/GetCasesWithVersions'
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },
    },

    data: {
        /* This object holds the arbitrary data that populates the ViewModel and is then available for binding. */
    }
});