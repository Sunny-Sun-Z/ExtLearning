/**
 * Created by kkora on 12/21/2017.
 */
Ext.define('QuickStart.view.admin.exportimport.Grid', {
    extend: 'Ext.grid.Panel',
    cls: 'dcf-grid',

    xtype: 'exportimportgrid',

    requires: [
        'Ext.grid.column.RowNumberer',
        'Ext.grid.filters.Filters',
        'Ext.toolbar.Fill'
    ],
    title: 'Available Cases for Export',
    reference: 'exportImportGrid',
    bind: '{exportCases}',
    plugins: ['gridfilters'],
    selType: 'checkboxmodel',
    columns: [
        {xtype: 'rownumberer'},
        {
            text: 'RootID',
            dataIndex: 'CaseReviewRootID',
            filter: {
                // type: 'number',
                itemDefaults: {
                    xtype: 'numberfield',
                    emptyText: 'Search for...'
                }
            }
        },
        {
            text: 'Case ID',
            dataIndex: 'CaseID',
            filter: {
                // type: 'number',
                itemDefaults: {
                    xtype: 'numberfield',
                    emptyText: 'Search for...'
                }
            }
        },
        {
            menuDisabled: true,
            hidden: true,
            text: 'CaseReviewID',
            dataIndex: 'CaseReviewID'
        },
        {
            text: 'Case Name',
            flex: 2,
            dataIndex: 'CaseName',
            filter: {
                type: 'string',
                itemDefaults: {
                    emptyText: 'Search for...'
                }
            }
        },

        {
            menuDisabled: true,
            text: 'Status',
            hidden: true,
            flex: 1,
            dataIndex: 'CaseStatusCode',
            renderer: 'rendererCaseStatus'
        },
        {
            menuDisabled: true,
            text: 'Type',
            flex: 1,
            hidden: true,
            dataIndex: 'ReviewTypeID',
            renderer: 'rendererReviewType'
        },
        {
            menuDisabled: true,
            text: 'Sub Type',
            flex: 1,
            hidden: true,
            dataIndex: 'ReviewSubTypeID',
            renderer: 'rendererReviewSubType'
        },
        {
            menuDisabled: true,
            text: 'Review Start',
            hidden: true,
            flex: 1,
            dataIndex: 'ReviewStartDate',
            formatter: 'date("m/d/Y")'
        },
        {
            text: 'Review End',
            menuDisabled: true,
            hidden: true,
            flex: 1,
            dataIndex: 'ReviewCompleted',
            formatter: 'date("m/d/Y")'
        },
        {
            menuDisabled: true,
            hidden: true,
            text: 'Site Name',
            flex: 1,
            dataIndex: 'SiteCode',
            renderer: 'rendererSite'

        }
    ],

    dockedItems: [
        {
            xtype: 'toolbar',
            //  ui: 'footer',
            items: ['->', {
                ui: 'dcf',
                margin: '0 5 5 0',
                itemId: 'export',
                iconCls: 'x-fa fa-file-excel-o',
                handler: 'onCaseExport',
                bind: {
                    disabled: '{!exportImportGrid.selection}'
                },
                text: 'Export',
                //  bind: {hidden: '{!allowToExport}'}
            }
            ]
        },
        {
            xtype: 'pagingtoolbar',
            dock: 'bottom',
            itemId: 'userPaginationToolbar',
            displayInfo: true,
            bind: '{exportCases}'

        }]

});