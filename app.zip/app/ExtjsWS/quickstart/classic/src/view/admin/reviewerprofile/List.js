/**
 * Created by ssun on 12/02/2019.
 */

Ext.define('QuickStart.view.admin.reviewerprofile.List', {
    extend: 'Ext.grid.Panel',

    xtype: 'reviewerprofilelist',
    cls: 'user-grid dcf-grid',
    title: 'Reviewer Profiles',
    scrollable: true,
    headerBorders: false,
    enableColumnResize: false,
    enableColumnMove: false,
    bind: '{reviewerStore}',
    selModel: {selType: 'rowmodel'},
    columns: [
        {
            hidden: true,
            menuDisabled: true,
            width: 40,
            dataIndex: 'UserId',
            text: '#'
        },
        {
            menuDisabled: true,
            sortable: false,
            renderer: function (value, meta, rec) {
                if (value) {
                     var path = 'user/GetPicture?id=' + rec.get('LoginID') + '.png';
                    //console.log(path)
                    return "<img src='" + path + "' alt='Profile Pic' height='30px' width='30px'>";
                }
                return Ext.String.format("<div class='avatar-circle-grid'> <span class='initials'>{0}</span></div>", QuickStart.util.Global.string.initial(rec.data.Name));
            },
            width: 40,
            dataIndex: 'Avatar'
        },
        {
            cls: 'content-column boldFont',
            dataIndex: 'Name',
            menuDisabled: true,
            text: 'Name',
            flex: 1
        },
       
        {
            cls: 'content-column boldFont',
            dataIndex: 'SpecialConsideration',
            menuDisabled: true,
            text: 'Special Considerations',
            flex: 1
        },
        {
            cls: 'content-column boldFont',
            dataIndex: 'CurrentOffice',
            menuDisabled: true,
            text: 'Current Office',
            flex: 1
        },
        {
            cls: 'content-column boldFont',
            dataIndex: 'PreviousOffice',
            menuDisabled: true,
            text: 'Previous Office',
            flex: 1,
            renderer: 'rendererSite'
        },

        {
            cls: 'content-column boldFont',
            dataIndex: 'Hometown',
            menuDisabled: true,
            text: 'Home Town',
            flex: 1
        },

       
    ],
    
    listeners: {
        selectionchange: 'onUserSelection'
    }
});