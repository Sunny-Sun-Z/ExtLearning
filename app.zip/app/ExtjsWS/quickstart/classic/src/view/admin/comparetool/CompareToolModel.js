/**
 * Created by kkora on 4/5/2018.
 */
Ext.define('QuickStart.view.admin.comparetool.CompareToolModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.comparetool',

    stores: {
        cases: {
            model: 'QuickStart.model.Dashboard',
            autoLoad: true,
            pageSize: 20,
            remoteFilter: true,
            remoteSort: true,
            filters: [{property: 'name', value: ''}],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'case/GetCompareCases'
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            },
            listeners:{
                load:'onCasesLoad'
            }
        },

    },

    data: {
        caseList:[],
        caseNames:'',
        noOfCaseSelected:0
    },
    formulas:{


    }
});