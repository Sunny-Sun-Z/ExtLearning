Ext.define('QuickStart.view.admin.reviewerprofile.Panel', {
    extend: 'Ext.panel.Panel',
    xtype: 'reviewerprofilepanel',

    requires: [
        'Ext.form.field.Checkbox',
        'Ext.form.field.ComboBox',
        'Ext.grid.Panel',
        'Ext.grid.column.Date',
        'Ext.toolbar.Paging'
       
    ],

    cls: 'casereview-container',
    layout: 'hbox',
    defaults: {
        border: true
    },
    dockedItems: [
        {// ui:'footer',
            xtype: 'toolbar',
            items: [

                {
                    text: 'Add Profile',
                    ui: 'dcf',
                    iconCls: 'x-fa fa-plus light',
                    tooltip: 'Add a new Reviewer Profile',
                    handler: 'onAddProfile'
                },


                {
                    text: 'Edit',
                    bind: {
                        disabled: '{!reviewerprofileList.selection}'
                    },
                    iconCls: 'x-fa fa-pencil',
                    tooltip: 'Edit the Seleted Reviewer Profile',
                    handler: 'onEditProfile'
                },

               // '->',
               
                {
                    text: 'Delete Profile',
                    ui: 'soft-red',
                    itemId: 'delete',
                    bind: {
                        disabled: '{!reviewerprofileList.selection}'
                    },
                    disabled: true,
                    iconCls: 'x-fa fa-ban',
                    handler: 'onDeleteProfile'

                }, '->',

                {
                    xtype: 'textfield',
                    itemId: 'searchText',
                    emptyText: 'Search...',
                    flex: 1,
                    triggers: {
                        clear: {
                            weight: -1,
                            cls: 'x-form-clear-trigger',
                            handler: function () {
                                this.setValue('');
                            }
                        }
                    },
                    listeners: {
                        change: 'onSearchUser'
                    }

                }
            ]
        },
        {
            xtype: 'pagingtoolbar',
            // ui:'footer',
            dock: 'bottom',
            itemId: 'userPaginationToolbar',
            displayInfo: true,
            bind: '{reviewerStore}'
        }
    ],

    items: [
        {
            flex: 5,
            margin: '0 10 0 0',
            height: '100%',
            reference: 'reviewerprofileList',
            itemId: 'reviewerprofileList',
            xtype: 'reviewerprofilelist'


        },
        
    ]

})
;
