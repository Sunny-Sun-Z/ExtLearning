/**
 * Created by kkora on 9/22/2017.
 */

Ext.define('QuickStart.view.admin.exportimport.AssignUsers', {
    extend: 'QuickStart.view.common.BaseWindow',
    requires: [   ],
    alias: 'widget.assignusers',
    width: 800,
    layout: 'fit',
    resizable: true,
    maximized:false,
    constrain : true,
    defaults: {
        defaultFocus: 'textfield:not([value]):focusable:not([disabled])'
    },
    bind: {
        title: 'Complete Face Sheet for Selected Case(s)'
    },
	scrollable: 'y',
	items: [
        {
            scrollable: 'y',
            xtype:'form',
            modelValidation: true,
            defaults: {
                msgTarget: 'side',
				anchor: '100%',
				xtype: 'usertagfield',
				allowBlank: false,
				labelWidth:250,
				queryMode: 'local'

				//labelAlign:'top'

			},
            bodyPadding: 10,
            items: [
                {
                    xtype: 'numberfield',
                    fieldLabel: 'Case ID ',
					itemId:'CaseID',
					name:'CaseID',
					checkValidate: true,
                    minValue: 0,
					maxValue: 2147483647,
                    hideTrigger: true,
                    keyNavEnabled: false,
                    mouseWheelEnabled: false,
                    allowDecimals: false
                },
                 {
				     fieldLabel: 'Review Participants',
                     bind: {store: '{reviewers}'},
                     name: 'Reviewers',
                     listeners: {
                         beforeselect: function (combo, record, index, eOpts) {
                             if (combo.getValue().length >= 3)
                                 return false;
                         }
                     }
                 },
                {
                    fieldLabel: 'Initial QA completed by',
				    bind: {store: '{qas}'},
					name:'InitialQAUserID',
					queryMode: 'local',
					multiSelect: false,
                    selectOnFocus :false
                },
                 {
                     fieldLabel: 'Second Level QA completed by',
					  bind: {store: '{qas2}'},
					 name:'SecondQAUserID',
					 selectOnFocus :false,
                     multiSelect: false,
                     queryMode: 'local'
                 },
                {
                    fieldLabel: 'Secondary Oversight completed by',
					  bind: {store: '{oversights}'},
					name:'SecondaryOversightUserID',
					xtype: 'usertagfield',
                    selectOnFocus :false,
                    allowBlank: true,
                    multiSelect: false
                },
                {
                    fieldLabel: 'Secondary CT Oversight completed by',
                    bind: {store: '{ctoversights}'},
					name:'CtSecondaryOversightUserID',
					xtype: 'usertagfield',
                    selectOnFocus :false,
                    allowBlank: true,
                    multiSelect: false
                }
            ]
        }
    ],
	dockedItems: [{
		xtype: 'toolbar',
		dock: 'bottom',
		ui: 'footer',
		items: ['->', {
			text: 'Save',
			iconCls: 'x-fa fa-save',
		//	disabled: true,
			formBind: true,
			ui: 'soft-green',
			handler: 'onAssignUsers'
		}, {
			text: 'Cancel',
			iconCls: 'x-fa fa-close',
			ui: 'gray',
			handler: function(btn){
			    btn.up('window').close();
            }
		}]
	}]
});