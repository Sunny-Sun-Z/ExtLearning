/**
 * Created by kkora on 12/21/2017.
 */
Ext.define('QuickStart.view.admin.rule.Grid', {
    extend: 'Ext.grid.Panel',
    cls: 'dcf-grid',

    xtype: 'rulegrid',

    requires: [
        'Ext.grid.column.Action',
        'Ext.grid.column.RowNumberer',
        'Ext.grid.feature.Grouping',
        'Ext.grid.filters.Filters',
        'Ext.grid.plugin.RowExpander'
    ],

    plugins: [{
        ptype: 'rowexpander',
        rowBodyTpl: new Ext.XTemplate('<p><b>Error Message:</b> {ErrorMessage}</p>')
    }, 'gridfilters'],

    features: [{
        ftype: 'grouping',
        startCollapsed: true,
        groupHeaderTpl: '{columnName}: {name} ({rows.length} Rule{[values.rows.length > 1 ? "s" : ""]})'
    }],

    columns: [
        //{xtype: 'rownumberer'},
        {
            width: 50,
            text: '#',
            menuDisabled: true,
            dataIndex: 'Id',
            sortable: true,
            align: 'right'
        },
        {
            hidden: true,
            // menuDisabled:true,
            sortable: false,
            text: 'Begin Group',
            align: 'center',
            dataIndex: 'OpenBracket',
            groupable : false,
            renderer: function (val, meta, rec) {
                return val ? "Yes" : "No";
            }
        },
        {
            width: 80,
            text: 'Enabled',
            dataIndex: 'Enabled',
            //   menuDisabled:true,
            sortable: true,
            align: 'center',
            renderer: function (val, meta, rec) {
                return val ? "Yes" : "No";
            },
            filter: 'boolean'
        },
        {
            flex: 1,
            //  menuDisabled:true,
            sortable: false,
            text: 'PropertyName',
            dataIndex: 'PropertyName',
            groupable : false,
            filter: {
                type: 'string',
                itemDefaults: {
                    emptyText: 'Search for...'
                }
            }
        },
        {
            flex: 1,
            text: 'Operator',
            //   menuDisabled:true,
            sortable: false,
            groupable : false,
            dataIndex: 'Operator'
        },
        {
            flex: 1,
            text: 'TargetValue',
            dataIndex: 'TargetValue',
            //  menuDisabled:true,
            groupable : false,
            sortable: false,
            renderer: function (val, meta, rec) {
                return val || rec.get('TargetValue1');
            }
        },
        // {
        //     width: 100,
        //     align: 'center',
        //     text: 'Priority',
        //     //  menuDisabled:true,
        //     sortable: true,
        //     dataIndex: 'Priority'
        // },
        {
            flex: 1,
            text: 'RuleSetName',
            // menuDisabled:true,
            sortable: true,
            dataIndex: 'RuleSetName',
            filter: {
                type: 'string',
                itemDefaults: {
                    emptyText: 'Search for...'
                }
            }
        },
         {
            flex: 1,
            hidden: true,
            //  menuDisabled:true,
            sortable: false,
             groupable : false,
             text: 'CreatedBy',
            dataIndex: 'CreatedBy'
        },
        {
            xtype: 'datecolumn',
            hidden: true,
            width: 100,
            text: 'Created',
            groupable : false,
            dataIndex: 'Created',
            //  menuDisabled:true,
            sortable: true,
            formatter: 'date("m/d/Y")'
        },
        {
            width: 100,
            hidden: true,
            align: 'center',
            text: 'Mode',//server/client
            //  menuDisabled:true,
            groupable : false,
            sortable: false,
            dataIndex: 'Mode'
        },
        {
            width: 100,
            hidden: true,
            text: 'Category',//server/client
            //  menuDisabled:true,
            sortable: false,
            dataIndex: 'Category',
            filter: {
                type: 'string',
                itemDefaults: {
                    emptyText: 'Search for...'
                }
            }
        },
        {
            width: 100,
            align: 'center',
            text: 'Required?',
            dataIndex: 'Required',
            //   menuDisabled:true,
            sortable: true,
            renderer: function (val, meta, rec) {
                return val ? "Yes" : "No";
            },
            filter: 'boolean'
        },
        {
            width: 50,
            align: 'center',
            text: 'Op',
            dataIndex: 'LogicOperator',
            menuDisabled:true,
            groupable : false,
            sortable: false,
            renderer: function (val, meta, rec) {
                return val == 1 ? "OR" : "AND";
            }
        },
        {
            xtype: 'datecolumn',
            hidden: true,
            width: 100,
            text: 'Start Date',
            dataIndex: 'StartDate',
            //  menuDisabled:true,
            groupable : false,
            sortable: true,
            formatter: 'date("m/d/Y")'
            // , filter: true
        },
        {
            xtype: 'datecolumn',
            hidden: true,
            width: 100,
            text: 'End Date',
            groupable : false,
            dataIndex: 'EndDate',
            //  menuDisabled:true,
            sortable: true,
            formatter: 'date("m/d/Y")'
            //, filter: true
        },
        {
            hidden: true,
            // menuDisabled:true,
            sortable: false,
            text: 'End Group',
            align: 'center',
            groupable : false,
            dataIndex: 'CloseBracket',
            renderer: function (val, meta, rec) {
                return val ? "Yes" : "No";
            }
        },
        {
            xtype: 'actioncolumn',
            groupable : false,
            items: [
                {
                    iconCls: 'x-fa fa-pencil',
                    handler: 'onEditRule',
                    tooltip: 'Edit Rule'
                },
                {
                    iconCls: 'x-fa fa-trash',
                    handler: 'onDeleteRule',
                    tooltip: 'Delete Rule'
                }
            ],
            align: 'center',
            menuDisabled: true,
            width: 70,
            sortable: false,
            dataIndex: 'bool',
            tooltip: 'Actions '
        }
    ],
    getValue: function () {
        return [];
    }

});