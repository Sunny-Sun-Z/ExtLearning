/**
 * Created by kkora on 1/25/2018.
 */
Ext.define('QuickStart.view.admin.exportimport.Import', {
    extend: 'QuickStart.view.common.BaseWindow',
    alias: 'widget.importwindow',

    requires: [
        'Ext.form.Panel',
        'Ext.form.field.File'
    ],

    width: 600,
    layout: 'fit',
    resizable: true,
    maximized:false,
    // y: 1,
    defaults: {
        defaultFocus: 'textfield:not([value]):focusable:not([disabled])'
    },
    title: 'Import Case',
   // scrollable: 'y',
    items: [
        {
            xtype: 'form',
           // scrollable: 'y',
            // layout: {
            //     type:'vbox',
            //     align:'stretch'
            // },
            defaults: {
                labelAlign: 'top',
                anchor: '100%',
                padding: '10'
            },
            items: [
                {
                    allowBlank: false,
                    xtype: 'filefield',
                    msgTarget:'under',
                    hideLabel:true,
                    name:'file',
                    buttonText: "Select Case File...",
                    buttonConfig :{
                        iconCls: 'x-fa fa-file-excel-o'
                    },
                    regex: /^.*\.(xml|XML|Xml)$/,
                    regexText: 'Only XML files allowed',

                    listeners:{
                        afterrender:function(cmp){
                            cmp.fileInputEl.set({
                                accept:'xml/*' // or w/e type
                            });
                        }
                    }
                }],
            dockedItems: [
                {
                    xtype: 'toolbar',
                    dock: 'bottom',
                    ui: 'footer',
                    items: ['->', {
                        text: 'Upload',
                        ui: 'dcf',
                        iconCls: 'x-fa fa-upload',
                        formBind: true,
                        handler: 'onCaseImport'

                    }, {
                        text: 'Cancel',
                        ui: 'gray',
                        iconCls: 'x-fa fa-close',
                        handler: function (btn) {
                            btn.up('window').close();
                        }
                    }]
                }
            ]
        }
    ]
});