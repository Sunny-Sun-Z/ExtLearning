/**
 * Created by kkora on 12/21/2017.
 */
Ext.define('QuickStart.view.admin.rule.RuleModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.rule',

    stores: {
        rules: {
            model: 'QuickStart.model.Rule',
            autoLoad: true,
            // pageSize: 20,
            remoteFilter: true,
            remoteSort: true,
            filters: [{property: 'name', value: ''}],
         //   groupField: 'Category',
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'setting/GetRules'
                },
                //  actionMethods: {read: 'POST'},
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }

        },
        errors: {
            model: 'QuickStart.model.Rule',
            autoLoad: true,
            // pageSize: 20,
            remoteFilter: true,
            remoteSort: true,
            filters: [{property: 'name', value: ''}],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'setting/GetRules'
                },
                //  actionMethods: {read: 'POST'},
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }

        },
        predicates: {
            model: 'QuickStart.model.casereview.Lookup',
            autoLoad: true,
            proxy: {
                type: 'ajax',
                url: 'lookup/GetPredicates',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },

        operators: {
            model: 'QuickStart.model.casereview.Lookup',
            autoLoad: true,
            proxy: {
                type: 'ajax',
                url: 'lookup/GetOperators',
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },

        modes: {
            model: 'QuickStart.model.casereview.Lookup',
            data: [
                {name: "Server", code: 1},
                {name: "Client", code: 2}
            ]
        },
        logicOperators: {
            model: 'QuickStart.model.casereview.Lookup',
            data: [
                {name: "AND", code: 0},
                {name: "OR", code: 1}
            ]
        },
        targetValues: {
            model: 'QuickStart.model.casereview.Lookup',
            data: [
                {name: "*Empty*", code: "*Empty*"},
                {name: "*Null*", code:  "*Null*"}
                 ,
                 {name: "*Count > 0*", code:  "*Count > 0*"},
                 {name: "*Count > 1*", code:  "*Count > 1*"},
                // {name: "*Count > 2*", code:  "*Count > 2*"},
                // {name: "*Count > 3*", code:  "*Count > 3*"}
            ]
        },
        dataTypes: {
            model: 'QuickStart.model.casereview.Lookup',
            data: [
                {name: "Int", code: 1},
                {name: "String", code: 2},
                {name: "Date", code: 3},
                {name: "Boolean", code: 4},
                {name: "Json", code: 5},
                {name: "Array", code: 6},
                {name: "Class", code: 7}
            ]
        }
    },

    data: {
        rule: null,
        addNew: false,
        isEdit: false
    }
});