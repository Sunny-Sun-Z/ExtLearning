/**
 * Created by kkora on 9/13/2017.
 */
Ext.define('QuickStart.view.admin.comparetool.Grid', {
    extend: 'Ext.grid.Panel',

    requires: [
        'Ext.toolbar.Paging'
    ],

    alias: 'widget.comparecasegrid',

    reference: 'compareCaseGrid',
    bind: '{cases}',

   // headerBorders: false,
    columns: [
        {
          //  menuDisabled: true,
            text: 'Case ID',
            dataIndex: 'CaseID',
            filter: {
                // type: 'number',
                itemDefaults: {
                    xtype: 'numberfield',
                    emptyText: 'Search for...'
                }
            }
        },

        {
            text: 'Case Name',
           // menuDisabled: true,
            flex: 2,
            dataIndex: 'CaseName',
            filter: {
                type: 'string',
                itemDefaults: {
                    emptyText: 'Search for...'
                }
            }

        },
        {
            menuDisabled: true,
           // hidden: true,
            text: 'Type',
            flex: 1,
            dataIndex: 'ReviewTypeID',
            renderer: 'rendererReviewType'
        },
        {
            menuDisabled: true,
            text: 'Sub Type',
            flex: 1,
            dataIndex: 'ReviewSubTypeID',
            renderer: 'rendererReviewSubType'
        },
        {
            menuDisabled: true,
            text: 'Status',
            flex: 1,
            dataIndex: 'CaseStatusCode',
            renderer: 'rendererCaseStatus'
          },
        {
            menuDisabled: true,
            text: 'Review Start',
            //flex: 1,
            dataIndex: 'ReviewStartDate',
            formatter: 'date("m/d/Y")'
        },
        {
            text: 'Review End',
            menuDisabled: true,
           // flex: 1,
            dataIndex: 'ReviewCompleted',
            formatter: 'date("m/d/Y")'
        },
        {
            menuDisabled: true,
            text: 'Site Name',
            flex: 1,
            dataIndex: 'SiteCode',
            renderer: 'rendererSite'
        }
    ],
    selType: 'checkboxmodel',
    plugins: ['gridfilters'],

    viewConfig: {
        emptyText: '<div style="text-align:center;font-weight:bold"> No Record Found</div>',
        forceFit: true
    },
    dockedItems: [
       {
            xtype: 'pagingtoolbar',
            dock: 'bottom',
            itemId: 'paginationToolbar',
            displayInfo: true,
            bind: '{cases}'
        }
    ],
    listeners:{
        beforeselect:'onBeforeCaseSelect',
        deselect:'onCaseDeSelect',
        selectionchange:'onCaseSelectionChanged'
    }
});