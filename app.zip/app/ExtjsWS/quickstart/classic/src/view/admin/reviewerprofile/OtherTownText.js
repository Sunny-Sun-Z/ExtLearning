﻿/**
 * Created by ssun on 12/02/2019.
 */

Ext.define('QuickStart.view.admin.reviewerprofile.OtherTownText', {
    extend: 'Ext.form.field.Text',
    alias: 'widget.otherTownText',
    //config: {
    //    requireMe: false
    //},
    //updateRequireMe: function (value) {
    //    this.allowBlank = value;
    //  //  this.validate();
    //}

    setAllowBlank: function (value) {
        this.allowBlank = value;
        this.validate();
    }
}
)