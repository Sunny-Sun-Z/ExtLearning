/**
 * Created by kkora on 4/5/2018.
 */
Ext.define('QuickStart.view.admin.comparetool.CompareToolController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.comparetool',
    mixins: [
        'QuickStart.mixins.Global'
    ],
    /**
     * Called when the view is created
     */
    init: function () {

    },
    onCaseComparePreview: function (btn) {
        var me = this,
            win = me.getView().up('#mainView').down('#compareWindow'),
            vm = me.getViewModel(),
            caseList = vm.get('caseList'),
            params = {
                caseReviewId1: caseList[0].CaseReviewID,
                caseReviewId2: caseList[1].CaseReviewID
            },
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: win}),
            url = QuickStart.util.Global.getApi() + 'case/Compare2Cases';

        win.show(btn);

        myMask.show();
        Ext.Ajax.request({
            url: url,
            method: 'GET',
            params: params,
            success: function (response, opts) {
                myMask.hide();
                var result = Ext.decode(response.responseText);
                if (result != null) {
                    if (!Ext.isEmpty(result.data)) {

                        var record = Ext.create('QuickStart.model.casereview.Preview', result.data.Case);
                        var irrRecord = Ext.create('QuickStart.model.casereview.Preview', result.data.Irr);
                        var data = record.getData();
                        var rec = Ext.apply({}, data);
                        rec = Ext.apply(rec, {Irr: irrRecord.getData(),Case1HeaderTitle:caseList[0].CaseName,Case2HeaderTitle:caseList[1].CaseName});
                        win.down('casecomparecontainer').setData(rec);
                        console.log(rec);
                    }
                }
            },
            failure: function (response, opts) {

                myMask.hide();
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });


    },
    onBeforeCaseSelect: function (sm, record, index, eOpts) {
        // console.log('onBeforeCaseSelect', sm, record)
        var me = this,
            vm = me.getViewModel(),
            names = vm.get('caseList')
        ;

        if (names.length > 2 || (names.length == 2 && sm.selected.length == 0) || sm.selected.length > 1)
            QuickStart.util.Global.showMessage('Only 2 cases allow to select for comparing.');

        return (names.length > 2 || (names.length == 2 && sm.selected.length == 0) || sm.selected.length > 1) ? false : true;
    },
    onCaseDeSelect: function (sm, record, index, eOpts) {
        var me = this,
            vm = me.getViewModel(),
            names = vm.get('caseList'),
            caseNames = []
        ;

        var names = names.filter(function (n) {
            return n.CaseReviewID != record.get('CaseReviewID');
        });

        Ext.each(names, function (item, index) {
            caseNames.push((index + 1) + '. ' + item.CaseName);
        });
        vm.set('caseNames', '<strong>' + caseNames.join('<br/>') + '</strong>');
        vm.set('noOfCaseSelected', names.length)
        vm.set('caseList', names)
    },
    onCaseSelectionChanged: function (sm, selected, eOpts) {
        var me = this,
            vm = me.getViewModel(),
            names = vm.get('caseList') || [],
            caseNames = []
        ;

        if (names.length > 2)
            return false;

        if (selected && selected.length > 0) {

            Ext.each(selected, function (record, index) {
                // if (names.length < 2) {
                var exist = names.filter(function (n) {
                    return n.CaseReviewID === record.get('CaseReviewID');
                }).length > 0;
                if (!exist)
                    names.push(record.getData());
                //  }
            });
        }
        Ext.each(names, function (item, index) {
            caseNames.push((index + 1) + '. ' + item.CaseName);
        });
        vm.set('caseNames', '<strong>' + caseNames.join('<br/>') + '</strong>');
        vm.set('noOfCaseSelected', names.length);
        vm.set('caseList', names);

    },
    onCasesLoad: function (store) {
        var me = this,
            vm = me.getViewModel(),
            names = vm.get('caseList') || [],
            grid = me.lookupReference('compareCaseGrid'),
            sm = grid.getSelectionModel()
        ;
        if (store && store.getRange().length > 0 && names.length > 0) {
            Ext.each(store.getRange(), function (record, index) {
                var exist = names.filter(function (n) {
                    return n.CaseReviewID === record.get('CaseReviewID');
                }).length > 0;
                if (exist)
                    sm.select(index, true);
            });
        }
    },
    onCaseComparePreviewSelectionClear: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            store = vm.getStore('cases'),
            grid = me.lookupReference('compareCaseGrid'),
            sm = grid.getSelectionModel()

        ;

        vm.set('caseNames', '');
        vm.set('noOfCaseSelected', 0);
        vm.set('caseList', []);

        if (store && store.getRange().length > 0) {
            Ext.each(store.getRange(), function (record, index) {
                    sm.deselect(record, true);
            });
        }
    }
});