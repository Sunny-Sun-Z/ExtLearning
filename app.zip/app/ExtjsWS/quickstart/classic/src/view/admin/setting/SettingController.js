/**
 * Created by kkora on 12/21/2017.
 */
Ext.define('QuickStart.view.admin.setting.SettingController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.setting',

    /**
     * Called when the view is created
     */
    init: function () {

    },
    syncAdProfilePicture: function (btn) {
        var me = this,
            //  myMask = new Ext.LoadMask({msg: 'Please wait...', target: btn.getEl()}),
            action = 'setting/UpdateUserPictures'
        ;

        // myMask.show();
        btn.setDisabled(true);
        Ext.Ajax.request({
            url: QuickStart.util.Global.getApi() + action,
            method: 'GET',
            params: {
                userID: QuickStart.util.Global.getUser().id
            },
            timeout: 1000 * 60 * 10, //10 minutes
            success: function (response, opts) {
                // myMask.hide();
                btn.setDisabled(false);

                var result = Ext.decode(response.responseText);
                if (result != null) {
                    QuickStart.util.Global.showMessage(result.message);
                }
            },
            failure: function (response, opts) {
                //  myMask.hide();
                btn.setDisabled(false);
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });
    },
    onAddKeyValueRecord: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            store = vm.getStore('keyValues'),
            record = Ext.create('QuickStart.model.KeyValue')
        grid = this.getView().down('#keyValueGrid')
        ;
        store.insert(0, record);
        vm.set('addNew', true);
        grid.findPlugin('cellediting').startEdit(record, 0);
    },
    onSaveKeyValueRecord: function (btn) {

        var me = this,
            vm = me.getViewModel(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: me.getView()}),
            userID = QuickStart.util.Global.getUser().id,
            store = vm.getStore('keyValues'),
            records = store.getModifiedRecords(),
            data = Ext.Array.pluck(records, 'data'),
            url = QuickStart.util.Global.getApi() + 'setting/SaveKeyValues';

        myMask.show();

        Ext.Ajax.request({
            url: url,
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            params: {
                userID: QuickStart.util.Global.getUser().id
            },
            jsonData: data,
            success: function (response, opts) {
                myMask.hide();
                //  debugger
                var result = Ext.decode(response.responseText);
                console.log(result)
                if (result != null) {
                    if (result.success) {
                        QuickStart.util.Global.showMessage(result.message);
                        store.reload();
                    }
                }

            },
            failure: function (response, opts) {

                myMask.hide();
                //  debugger
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });
    },
    onDeleteKeyValue: function (grid, rowIndex, colIndex, cell, e, record, row) {
        var me = this,
            data = record.getData(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: me.getView()}),
            action = 'setting/DeleteKeyValue'
        ;
        // console.log(data)
        Ext.Msg.show({
            title: 'Delete?',
            message: "Are you sure do you want to delete?",
            buttons: Ext.Msg.YESNO,
            icon: Ext.Msg.QUESTION,
            fn: function (btn) {
                if (btn === 'yes') {
                    myMask.show();
                    Ext.Ajax.request({
                        url: QuickStart.util.Global.getApi() + action,
                        method: 'POST',
                        params: {
                            userID: QuickStart.util.Global.getUser().id
                        },
                        jsonData: data,
                        success: function (response, opts) {
                            myMask.hide();
                            var result = Ext.decode(response.responseText);
                            if (result != null) {
                                if (result.success) {
                                    QuickStart.util.Global.showMessage(result.message);
                                    grid.getStore().remove(record);
                                }
                            }
                        },
                        failure: function (response, opts) {
                            myMask.hide();
                            Ext.Msg.alert('Status', "failure");
                            console.log('server-side failure with status code ' + response.status);
                        },
                        scope: this
                    });
                }
            }
        }, this);
    },
    onAddAdhocReport: function (btn) {

        var me = this,
            win = me.getView().down('#addReportWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = Ext.create('QuickStart.model.Report', { Type: 'SSIS' });

        win.show(btn);
        form.reset();
        form.isValid();
        vm.set('current.Report', record);
        vm.set('current.reportAction', 'Add');

        win.setTitle('Add Report');
    },
    onEditAdhocReport: function (btn) {

        var me = this,
            win = me.getView().down('#addReportWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = vm.get('current.Report');

        win.show(btn);
        form.isValid();
        vm.set('current.Report', record);
        vm.set('current.reportAction', 'Edit');
        win.setTitle('Edit Report');
        

    },
    onDeleteAdhocReport:function (btn) {
        var me = this,
            vm = me.getViewModel(),
            store = vm.getStore('reports'),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: me.getView()}),
            action = 'report/DeleteReport',
            record = vm.get('current.Report'),
            data = record.getData()
        ;

        ;
        // console.log(data)
        Ext.Msg.show({
            title: 'Delete?',
            message: "Are you sure do you want to delete?",
            buttons: Ext.Msg.YESNO,
            icon: Ext.Msg.QUESTION,
            fn: function (btn) {
                if (btn === 'yes') {
                    myMask.show();
                    Ext.Ajax.request({
                        url: QuickStart.util.Global.getApi() + action,
                        method: 'POST',
                        params: {
                            userID: QuickStart.util.Global.getUser().id
                        },
                        jsonData: data,
                        success: function (response, opts) {
                            myMask.hide();
                            var result = Ext.decode(response.responseText);
                            if (result != null) {
                                if (result.success) {
                                    QuickStart.util.Global.showMessage(result.message);
                                    store.remove(record);
                                }
                            }
                        },
                        failure: function (response, opts) {
                            myMask.hide();
                            Ext.Msg.alert('Status', "failure");
                            console.log('server-side failure with status code ' + response.status);
                        },
                        scope: this
                    });
                }
            }
        }, this);
    },
    onReportSelection: function (sm, selected) {
        ///  console.log(arguments)

        var me = this,
            vm = me.getViewModel(),
            record = selected[0]
        ;
        if (record) {
            vm.set('current.Report', record);
        }
    },
    onSearchReports: function (field) {
        var me = this,
            searchText = field.getValue(),

            vm = me.getViewModel(),
            store = vm.getStore('reports'),
            filters = [];
        store.clearFilter();

        filters.push({ property: 'Name', value: searchText });
        store.setFilters(filters);
    },
    onSaveReport: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            reportStore = vm.getStore('reports'),
            store = vm.getStore('parameters'),
            parameters = store ? Ext.Array.pluck(store.getRange(), 'data') : [],
            win = btn.up('window'),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: win}),
            userID = QuickStart.util.Global.getUser().id,
            record = vm.get('current.Report'),
            data = record.getData(),
            url = QuickStart.util.Global.getApi() + 'report/SaveReport';

        data.Parameters = parameters;
        myMask.show();
        //    console.log(data);
        Ext.Ajax.request({
            url: url,
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            params: {
                userID: QuickStart.util.Global.getUser().id
            },
            jsonData: data,
            success: function (response, opts) {
                myMask.hide();
                //  debugger
                var result = Ext.decode(response.responseText);
                if (result != null) {
                    if (result.success) {
                        reportStore.reload();
                        if (win)
                            win.close();
                    }
                    QuickStart.util.Global.showMessage(result.message, null, '70%');
                }
            },
            failure: function (response, opts) {
                myMask.hide();
                //  debugger
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });

    },
    onExecuteReport: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            win = btn.up('window'),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: win}),
            userID = QuickStart.util.Global.getUser().id,
            record = vm.get('current.Report'),
            data = record.getData(),
            regex = /@[\w]+/gi,
            matches_array = data.Query.match(regex)
        ;

        console.log(matches_array);
    },

    onQueryChanged: function (field, newValue, oldValue) {
        var me = this,
            vm = me.getViewModel(),
            record = vm.get('current.Report'),
            store = vm.getStore('parameters'),
            parameters = store ? Ext.Array.pluck(store.getRange(), 'data') : [],
            win = field.up('window'),
            parameterGrid = win.down('#parameterGrid'),
            regex = /@[\w]+/gi,
            query = record.get('Query'),
            matches_array = query.match(regex),
            exist = matches_array && matches_array.length > 0,
            isAdhocReport = record.get('Type') == 'ADHOC',

            newParams = []
        ;

        parameterGrid.hide();
        // console.log(newValue,matches_array)

        if (exist && isAdhocReport) {
            parameterGrid.show();

            Ext.each(matches_array, function (p) {
                // var pExist = parameters.filter(function (pe) {return pe.Name == p; });
                // newParams.push(pExist && pExist.length > 0 ? pExist : {Name: p, DataType: 'String', FieldType: 'Text'});
                newParams.push({Name: p, DataType: 'String', FieldType: 'Text'});
            });
            // store.removeAll();
            store.setData(newParams);
        }
    },

    reportLookupRenderer: function (val) {
        var me = this,
            vm = me.getViewModel(),
            store = vm.getStore('reportLookup'),
            records
        ;

        records = store.queryRecordsBy(function (r) {
            return r.get('Key') == val;
        });
        if (records && records.length > 0) {
            return records[0].get('Value');
        }
        return val

    },
    onSmtpSettingClick: function (btn) {
        var me = this,
            win = me.getView().down('#smtpSettingWindow'),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: win}),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = Ext.create('QuickStart.model.Smtp'),
            url = QuickStart.util.Global.getApi() + 'setting/GetSmtp';


        win.show(btn);
        form.reset();
        form.isValid();
        vm.set('current.smtp', record);
        myMask.show();
        Ext.Ajax.request({
            url: url,
            method: 'GET',
            success: function (response, opts) {
                myMask.hide();
                //  debugger
                var result = Ext.decode(response.responseText);
                console.log(result)
                if (result != null) {
                    if (result.success && result.data) {
                        record = Ext.create('QuickStart.model.Smtp', result.data);
                        vm.set('current.smtp', record);
                    }
                }
            },
            failure: function (response, opts) {

                myMask.hide();
                //  debugger
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });
    },
    onSaveSmtpSetting: function (btn) {
        var me = this,
            win = btn.up('window'),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: win}),
            vm = me.getViewModel(),
            record = vm.get('current.smtp'),
            url = QuickStart.util.Global.getApi() + 'setting/SaveSmtp';

        Ext.Ajax.request({
            url: url,
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            params: {
                userID: QuickStart.util.Global.getUser().id
            },
            jsonData: record.getData(),
            success: function (response, opts) {
                myMask.hide();
                //  debugger
                var result = Ext.decode(response.responseText);
                if (result != null) {
                    if (result.success) {
                        QuickStart.util.Global.showMessage(result.message);
                        if (win)
                            win.close();
                    }
                }
            },
            failure: function (response, opts) {

                myMask.hide();
                //  debugger
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });
    },
    onSendTestMail: function (btn) {
        var me = this,
            win = btn.up('window'),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: win}),
            vm = me.getViewModel(),
            record = vm.get('current.smtp'),
            data = record.getData(),
            url = QuickStart.util.Global.getApi() + 'setting/SendTestMail';
        Ext.MessageBox.prompt("SMTP Test", "Enter your email", function (confirm,email) {
            if (confirm == 'ok') {

                Ext.Ajax.request({
                    url: url,
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    params: {
                        userID: QuickStart.util.Global.getUser().id,
                        email:email
                    },
                    jsonData: record.getData(),
                    success: function (response, opts) {
                        myMask.hide();
                        //  debugger
                        var result = Ext.decode(response.responseText);
                        if (result != null) {
                            if (result.success) {
                                QuickStart.util.Global.showMessage(result.message);
                                if (win)
                                    win.close();
                            }
                        }
                    },
                    failure: function (response, opts) {

                        myMask.hide();
                        //  debugger
                        Ext.Msg.alert('Status', "failure");
                        console.log('server-side failure with status code ' + response.status);
                    },
                    scope: this
                });
            }
        }, this);

    }
});