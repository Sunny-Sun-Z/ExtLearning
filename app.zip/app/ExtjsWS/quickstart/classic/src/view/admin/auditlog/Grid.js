/**
 * Created by kkora on 12/21/2017.
 */
Ext.define('QuickStart.view.admin.auditlog.Grid', {
    extend: 'Ext.grid.Panel',
    //    cls: 'dcf-grid',

    xtype: 'auditloggrid',

    requires: [
        'Ext.grid.column.RowNumberer',
        'Ext.grid.filters.Filters',
        'Ext.grid.plugin.RowExpander',
        'Ext.toolbar.Fill',
        'Ext.toolbar.Paging'
    ],
    title: 'Audit Logs',
    reference: 'auditLogGrid',
    bind: '{logs}',
    plugins: ['gridfilters',
        {
            ptype: 'rowexpander',
            rowBodyTpl: new Ext.XTemplate(
                '<p><b>Source:</b> {Source}</p>',
                '<span><b>Stack Trace:</b><span class="error-msg"> {StackTrace}</span></p>'
            )
        }
    ],
    selType: 'checkboxmodel',
    columns: [
        {xtype: 'rownumberer'},
        {
            text: 'Message',
            flex: 2,
            dataIndex: 'Message',
            filter: {
                type: 'string'
            }
        },
        {
            text: 'Type',
            flex: 1,
            align: 'center',
            dataIndex: 'Type',
            filter: {
               // type: 'number',
                itemDefaults: {
                    fieldLabel: 'Type',
                    anchor: '75%',
                    store:['All','DEBUG','INFO','WARNING','ERROR'],
                    xtype: 'combobox',
                    selectOnFocus: false,
                    multiSelect: false,
                    queryMode: 'local',
                    editable: false
                }
            },
            renderer:function (val, meta, rec) {
                switch (val) {
                    case 'DEBUG':
                        meta.style = 'color:#925e8b';
                        break;
                    case 'ERROR':
                        meta.style = 'color:#e44959';
                        break;
                    case 'WARNING':
                        meta.style = 'color:#ffc107';
                        break;
                    case 'INFO':
                        meta.style = 'color:#2eadf5';
                        break;
                }
                return val;
            }
        },
        {
            text: 'User',
            flex: 1,
            dataIndex: 'UserId',
            renderer: 'rendererUser',
            filter: {
              //  type: 'number',
                itemDefaults: {
                    fieldLabel: 'User',
                    anchor: '75%',
                    bind: {
                        store: '{users}'
                    },
                    xtype: 'usertagfield',
                    selectOnFocus: false,
                    multiSelect: false,
                    queryMode: 'local',
                    // editable: false
                }
            }
        },
        {
            text: 'Created On',
            flex: 1,
            align: 'center',
            dataIndex: 'Created',
            formatter: 'date("m/d/Y h:i:s A")',
           // renderer: 'datetimeRenderer',
            filter: {
                type: 'date'
            }
        }
    ],
    viewConfig: {
        emptyText: '<div style="text-align:center;font-weight:bold">No Log Found</div>',
        forceFit: true
    },
    dockedItems: [
        {
            xtype: 'pagingtoolbar',
            dock: 'bottom',
            itemId: 'paginationToolbar',
            displayInfo: true,
            bind: '{logs}',
            items: [
                //  '->',
                {
                    ui: 'soft-red',
                    text: 'Clear All Logs',
                    itemId: 'allLogs',
                    iconCls: 'x-fa fa-close',
                    hidden: true,
                    handler: 'onClearAllLogs'
                },
                {
                    ui: 'soft-red',
                    text: 'Clear Selected Logs',
                    itemId: 'selectedLogs',
                    iconCls: 'x-fa fa-close',
                    hidden: true,
                    bind: {
                        disabled: '{!auditLogGrid.selection}'
                    },
                    handler: 'onClearSelectedLogs'
                },
                {
                    ui: 'dcf',
                    margin: '0 5 5 0',
                    itemId: 'export',
                    hidden: true,
                    iconCls: 'x-fa fa-file-excel-o',
                    text: 'Export Logs',
                    bind: {
                        disabled: '{!auditLogGrid.selection}'
                    },
                    handler: 'onLogExport',

                }
            ]

        }]

});