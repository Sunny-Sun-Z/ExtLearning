/**
 * Created by kkora on 9/19/2017.
 */
Ext.define('QuickStart.view.admin.AdminController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.admin',

    /**
     * Called when the view is created
     */
    init: function () {

    },
    onNavigationTreeSelectionChange: function (tree, node, opt) {

        var me = this,
            vm = me.getViewModel(),
            refs = me.getReferences(),
            adminCardPanel = refs.adminCardPanel,
            layout = adminCardPanel.getLayout(),
            view = node.get('viewType'),
            lastView = me.lastView,

            existingItem = adminCardPanel.child('component[viewType=' + view + ']'),
            newView;

        if (!adminCardPanel)
            return;

        if (!existingItem) {
            newView = Ext.create({
                xtype: view,
                hideMode: 'offsets'
            });
        }
        lastView = layout.getActiveItem();

        if (!newView || !newView.isWindow) {
            // !newView means we have an existing view, but if the newView isWindow
            // we don't add it to the card layout.
            if (existingItem) {
                // We don't have a newView, so activate the existing view.
                if (existingItem !== lastView) {
                    layout.setActiveItem(existingItem);
                }
                newView = existingItem;
            }
            else {
                // newView is set (did not exist already), so add it and make it the
                // activeItem.
                Ext.suspendLayouts();
                layout.setActiveItem(adminCardPanel.add(newView));
                Ext.resumeLayouts(true);
            }
        }
        me.lastView = newView;
    },

    afterAdminPanelRender: function (pnl) {

       var  me = this,
           vm = me.getViewModel(),
           navigationList = pnl.down('#adminNavigationTreeList'),
            store = navigationList.getStore(),
            node = store.findNode('routeId', 'rule') || store.findNode('viewType', 'rule');

        if (node) {
            navigationList.setSelection(node);
        }

    },
    onLoadKeyValue:function (store) {
        var me = this,
            vm = me.getViewModel(),
            rec=   store.findRecord('Key','export-path');

        if(rec){
            vm.set('exportPath',rec.get('Value'));
        }
    }

});