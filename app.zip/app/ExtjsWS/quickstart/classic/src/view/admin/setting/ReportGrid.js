/**
 * Created by kkora on 1/23/2018.
 */
Ext.define('QuickStart.view.admin.setting.ReportGrid', {
    extend: 'Ext.grid.Panel',
    cls: 'user-grid dcf-grid',
    requires: [
        'Ext.grid.column.RowNumberer',
        'Ext.toolbar.Fill',
        'Ext.toolbar.Paging'
    ],
  
    xtype: 'reportsettinggrid',
    bind: '{reports}',
    columns: [
        { xtype: 'rownumberer' },
        {
            flex: 1,
            menuDisabled: true,
            text: 'Report Name',
            dataIndex: 'Description'
        }
    ],
    hideHeaders:true,
    dockedItems: [
      {// ui:'footer',
          xtype: 'toolbar',
          items: [{
              text: 'Add New Report',
              ui: 'dcf',
              iconCls: 'x-fa fa-plus light',
              tooltip: 'Add New Report',
              handler: 'onAddAdhocReport'
          },
              {
                  text: 'Edit Report',
                  bind: {
                      disabled: '{!reportSettingGrid.selection}'
                  },
                  iconCls: 'x-fa fa-pencil',
                  handler: 'onEditAdhocReport'

              }, {
                  text: 'Delete',
                 // ui: 'soft-red',
                  bind: {
                      disabled: '{!reportSettingGrid.selection}'
                  },
                  iconCls: 'x-fa fa-close',
                  handler: 'onDeleteAdhocReport'

              }, '->',

              {
                  xtype: 'textfield',
                  itemId: 'searchText',
                  emptyText: 'Search...',
                  flex: 1,
                  triggers: {
                      clear: {
                          weight: -1,
                          cls: 'x-form-clear-trigger',
                          handler: function () {
                              this.setValue('');
                          }
                      }
                  },
                  listeners: {
                      change: 'onSearchReports'
                  }

              }
          ]
      },
      {
          xtype: 'pagingtoolbar',
          dock: 'bottom',
          itemId: 'paginationToolbar',
          displayInfo: true,
          bind: '{reports}'

      }
    ],
    listeners: {
        selectionchange: 'onReportSelection'
    }
});