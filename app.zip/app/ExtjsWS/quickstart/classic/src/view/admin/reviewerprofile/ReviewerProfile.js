/**
 * Created by ssun on 12/02/2019.
 */

Ext.define('QuickStart.view.admin.reviewerprofile.ReviewerProfile', {
    extend: 'Ext.Container',
    xtype: 'reviewerprofile',

    requires: [
        'Ext.grid.Panel',
        'Ext.grid.column.Date',
        'Ext.toolbar.Paging',
        'QuickStart.view.admin.reviewerprofile.ReviewerProfileController',
        'QuickStart.view.admin.reviewerprofile.ReviewerProfileModel',
        'QuickStart.view.admin.reviewerprofile.Window'
    ],

    uses: [
       // 'QuickStart.view.user.permission.Grid'
    ],

    controller: 'reviewerprofile',
    viewModel: {
        type: 'reviewerprofile'
    },
    config: {
        highlightTitle: 'Security Management111'
    },

    margin: 20,
    cls: 'casereview-container',
    layout: 'hbox',
    defaults: {

    },

    items: [
        {
            flex: 2,
            margin: '0 10 0 0',
            height: '100%',
            itemId: 'reviewerprofilePanel',//'reviewerProfileList',
            reference: 'reviewerprofilePanel',//'reviewerProfileList',
            routeId: 'reviewerprofile',
            xtype: 'reviewerprofilepanel'
        },
        
        {
            xtype: 'reviewerprofilewindow',
            itemId: 'reviewerProfileWindow'
        },
        
    ],
    listeners:{
        afterrender:'onUserPanelRender'
    }

})
;
