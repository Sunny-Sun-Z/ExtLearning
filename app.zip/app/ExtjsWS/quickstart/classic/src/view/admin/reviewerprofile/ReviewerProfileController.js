/**
 * Created by ssun on 12/02/2019.
 */

Ext.define('QuickStart.view.admin.reviewerprofile.ReviewerProfileController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.reviewerprofile',
    mixins: [
        'QuickStart.mixins.Global'
    ],
    requires: [
        'QuickStart.model.ReviewerProfile',
        'QuickStart.model.User',
        'Ext.window.*'
    ],
    onSearchUser: function (field) {
        var me = this,
            toolbar = field.up(),
            showInActiveCheck = toolbar.down('#showInActiveCheck'),
            showCombo = toolbar.down('#show'),
            searchTextField = toolbar.down('#searchText'),
            searchText = searchTextField.getValue(),

            vm = me.getViewModel(),
            store = vm.getStore('reviewerStore'),
            filters = [];
        store.clearFilter();
        filters.push({property: 'Name', value: searchTextField.getValue()});
        store.setFilters(filters);
    },

    onAddProfile: function (grid, btn) {

        var me = this,
            win = me.getView().down('#reviewerProfileWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = Ext.create('QuickStart.model.ReviewerProfile');
            comboHome = me.getView().down('#hometown')
        win.show(btn);
        form.reset();
        form.isValid();
        vm.set('current.reviewerProfileSelected', vm.get('current.reviewerProfile'));
        console.log("pre", vm.get('current.reviewerProfile'));
        vm.set('current.reviewerProfile', record);
        vm.set('current.userAction', 'Add');
        vm.getStore('reviewerStore').insert(0, record);
        comboHome.setValue (-1);
    },

  

    onEditProfile: function (btn) {
        var me = this,
            win = me.getView().down('#reviewerProfileWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm()
            record = vm.get('current.reviewerProfileSelected');
            ;

        console.log('action', record);
        if (vm.get('current.userAction') == 'Add') {
            vm.set('current.reviewerProfile', record);
        }
        win.show(btn);
        form.isValid();
        vm.set('current.userAction', 'Edit');
    },

    onHometownChange: function (box) {
        
        var me = this,
            comboHome = me.getView().down('#hometown')
            textOther = me.getView().down('#otherHometown')
            ;

        console.log('blank',textOther.allowBlank)
        if (comboHome.getValue() === 999) {
            textOther.allowBlank = false;
            textOther.validate()
        }
        else {
            textOther.setValue('')
            textOther.allowBlank = true;
            textOther.validate();
        }
    },


    onSaveProfile: function (btn) {
        var me = this,

            win = btn.up('window'),
            form = win.down('form').getForm(),
            values = form.getValues(),
            vm = me.getViewModel(),
            record = vm.get('current.reviewerProfile'),
            data = record.getData(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: win}),
            action = 'user/UpdateReviewerProfile', // data.UserID > 0 ? 'user/UpdateReviewerProfile' : 'user/CreateReviewerProfile',
            isNew = vm.get('current.userAction') === 'Add'                 ////'Profile Edit'  this is the value need find
            ;
        myMask.show();
        Ext.Ajax.request({
            url: QuickStart.util.Global.getApi() + action,
            method: 'POST',
            params: {userID: QuickStart.util.Global.getUser().id},
            jsonData: data,
            success: function (response, opts) {
                myMask.hide();
                var result = Ext.decode(response.responseText);
                if (result != null) {
                    if (!Ext.isEmpty(result.data)) {
                        QuickStart.util.Global.showMessage(result.message);
                        if (isNew) {
                            record.set('UserID', result.data.UserID);
                            me.lookupReference('reviewerprofileList').getSelectionModel().select(0);
                            vm.set('current.userAction', 'Edit');
                            userstore = vm.getStore('userStore')
                            userstore.reload();
                        }
                        store = vm.getStore('reviewerStore');
                        store.reload();
                        record.commit();
                        win.close();
                    }
                }
            },
            failure: function (response, opts) {
                myMask.hide();
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });

    },
   

    onReviewerStoreLoad: function (store) {

        if (store.getCount() > 0) {
            this.lookupReference('reviewerprofileList').getSelectionModel().select(0);   ///
        }                         
    },
    

    onDeleteProfile: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            record = vm.get('current.reviewerProfile'),
            data = record.getData(),
            myMask = new Ext.LoadMask({ msg: 'Please wait...', target: me.getView() }),
            action = 'user/DeleteReviewerProfile'
            ;
        // console.log(data)
        Ext.Msg.show({
            title: 'Delete Profile?',
            message: "Are you sure do you want to delete the profile for '<b>" + record.get('Name') + "</b>' ?",  
            buttons: Ext.Msg.YESNO,
            icon: Ext.Msg.QUESTION,
            fn: function (btn) {
                if (btn === 'yes') {
                    myMask.show();
                    data.IsProfileActive = !data.IsProfileActive;
                    Ext.Ajax.request({
                        url: QuickStart.util.Global.getApi() + action,
                        method: 'POST',
                        params: {
                            userID: QuickStart.util.Global.getUser().id
                        },
                        jsonData: data,
                        success: function (response, opts) {
                            myMask.hide();
                            var result = Ext.decode(response.responseText);
                            if (result != null) {
                                if (!Ext.isEmpty(result.data)) {
                                    QuickStart.util.Global.showMessage(result.message);
                                    record.set('IsProfileActive', false);
                                    record.commit();
                                    me.filterByIsActiveProfile();
                                   // grid.getStore().remove(rec);
                                    userstore = vm.getStore('userStore')
                                    userstore.reload();
                                }
                            }
                        },
                        failure: function (response, opts) {
                            myMask.hide();
                            Ext.Msg.alert('Status', "failure");
                            console.log('server-side failure with status code ' + response.status);
                        },
                        scope: this
                    });
                }
            }
        }, this);
    },

    filterByIsActiveProfile: function () {
        var me = this,
            vm = me.getViewModel(),
            store = vm.getStore('reviewerStore')
            ;
        store.clearFilter();
        store.setFilters([{ property: 'IsProfileActive', value: true }]);

    },



    onUserSelection: function (sm, selected) {
        ///  console.log(arguments)
        // debugger;
        var me = this,
            view = me.getView(),
            //userRolesGrid = view.down('#userRoles'),
            //btnActivate = view.down('#activate'),
            //btnDeactivate = view.down('#delete'),
            //userPermissionsGrid = view.down('#userPermissions'),
            vm = me.getViewModel(),
            record = selected[0],
            data = record ? record.getData() : {}
            ;
        // btnActivate.setDisabled(record && record.get('IsActive'));
     
       // btnDeactivate.setDisabled(record && !record.get('IsProfileActive'));

       // console.log('on selection', record)
        if (record) {
            vm.set('current.reviewerProfile', record);
        }
    },

    

    onUserRecordCancel: function (owner) {
        var me = this,
            vm = me.getViewModel(),
            store = vm.getStore('reviewerStore');
        if (store && store.rejectChanges)
            store.rejectChanges();
        if (owner.isWindow)
            owner.hide();
        else
            owner.up('window').close();

    },
    onUserPanelRender: function () {

    },

    //setGridValues: function (gridItemId, values) {
    //    var view = this.getView(),
    //        grid = view.down('#' + gridItemId),
    //        sm = grid.getSelectionModel(),
    //        store = grid.getStore(),
    //        records = [],
    //        index;

    //    sm.deselectAll();

    //    if (values && values.length > 0) {
    //        Ext.each(values, function (v) {
    //            index =store.find('Id',v,0,false,true,true);//(prop,value, start, anymatch, caseSensitive, exactmatch)
    //            if (index > -1) {
    //                sm.select(index, true);
    //            }
    //        });
    //    }
    //}
})
;
