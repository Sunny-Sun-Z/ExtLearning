/**
 * Created by kkora on 4/5/2018.
 */
Ext.define('QuickStart.view.admin.previewtool.PreviewToolController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.previewtool',
    mixins: [
        'QuickStart.mixins.Global'
    ],
    /**
     * Called when the view is created
     */
    init: function () {

    },
    onCaseChanged: function (field) {

        var me = this,
            view = me.getView(),
            versionLabel = view.down('#versionLabel'),
            rec = field.getSelectedRecord(),
            data = rec.getData()
        ;
        me.preview(data.CaseReviewRootID, data.CaseReviewID);
        me.buildVersionButtons(data);
        versionLabel.show();
        versionLabel.setValue('<strong>Current</strong>');

    },
    buildVersionButtons: function (data) {
        var me = this,
            view = me.getView(),
            versionToolbar = view.down('#versionToolbar'),
            versionGroupButton = view.down('#versionGroup'),
            status = 0, ui, btn = {}, length = data.Versions.length,
            buttons = []
        ;
        if (versionGroupButton) {
            versionGroupButton.removeAll();

            for (var index = 0; index < length; index++) {
                btn = data.Versions[index];
                btn.index = index;
                btn.tooltip = btn.Status;
                btn.text = index == 0 ? 'Current' : index == length - 1 ? 'Case Created' : length - index;
                //  btn.ui = 'button-case-status-' + (status == btn.CaseStatusCode ? 'default' : btn.CaseStatusCode);
                btn.ui = 'button-case-status-' + btn.CaseStatusCode;
                status = btn.CaseStatusCode;
                versionGroupButton.add(btn);
            }


            // for (var index = length - 1; index > 0; index--) {
            //     btn = data.Versions[index];
            //     btn.index = index;
            //     btn.tooltip = btn.Status;
            //     btn.text = index == length - 1 ? 'Case Created' : index == 1 ? 'Current' : index;
            //     // btn.ui = 'button-case-status-' + (status == btn.CaseStatusCode ? 'default' : btn.CaseStatusCode);
            //     btn.ui = 'button-case-status-' + btn.CaseStatusCode;
            //     status = btn.CaseStatusCode;
            //     versionGroupButton.insert(0, btn);
            // }
        }
    },
    preview: function (rootId, caseReviewId) {
        var me = this,
            vm = me.getViewModel(),
            view = me.getView(),
            container = view.down('casepreviewcontainer'),
            params = {
                caseReviewRootId: rootId,
                caseReviewId: caseReviewId,
                userID: QuickStart.util.Global.getUser().id
            },
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: view}),
            url = QuickStart.util.Global.getApi() + 'case/GetPreview'
        ;
        myMask.show();
        Ext.Ajax.request({
            url: url,
            method: 'GET',
            params: params,
            success: function (response, opts) {
                myMask.hide();
                var result = Ext.decode(response.responseText);
                if (result != null) {
                    if (!Ext.isEmpty(result.data)) {
                        var rec = Ext.create('QuickStart.model.casereview.Preview', result.data);
                        container.setData(rec.getData());
                        container.show();
                    }
                }
            },
            failure: function (response, opts) {

                myMask.hide();
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });
    },

    onPreviewClick: function (btn) {
        var me = this,
        view = me.getView(),
            versionLabel = view.down('#versionLabel')
        ;
            me.preview(btn.CaseReviewRootID, btn.CaseReviewID);
        versionLabel.show();
        versionLabel.setValue('<strong>'+ btn.text +'</strong>')


    }
});