/**
 * Created by kkora on 1/26/2018.
 */
Ext.define('QuickStart.view.admin.setting.SmtpWindow', {
    extend: 'QuickStart.view.common.BaseWindow',
    requires: [
        'Ext.form.Panel',
        'Ext.form.field.*',
        'Ext.layout.container.VBox'
    ],

    alias: 'widget.smtpsettingwindow',
    width: 600,
    height: 500,
    layout: 'fit',
    resizable: true,
    maximized: true,
    constrain: true,
    defaults: {
        defaultFocus: 'textfield:not([value]):focusable:not([disabled])'
    },
    title: 'SMTP Setting',
    items: [{
        bodyPadding: '10 10 0 10',
        xtype: 'form',
        defaultType: 'textfield',
        defaults: {
            submitEmptyText: false,
            anchor: '100%',
            labelWidth: 100,
            fieldLabel: ' ',
            msgTarget: 'side'
        },
        layout: {
            type: 'vbox',
            align: 'stretch'
        },
        items: [
            {   xtype: 'fieldcontainer',
                layout:'hbox',
                fieldLabel: 'Server',
                items:[
                    {
                        allowBlank: false,
                        xtype: 'textfield',
                        flex:1,
                        bind: '{current.smtp.Server}'
                    },
                    {
                        xtype: 'numberfield',
                        labelAlign:'right',
                         fieldLabel: 'Port',
                        bind: '{current.smtp.Port}'
                    }
                ]
            },
            {
                fieldLabel: 'UserName',
                bind: '{current.smtp.UserName}'
            },
            {
                fieldLabel: 'Password',
                bind: '{current.smtp.Password}',
                inputType: 'password'
            },
            {
                xtype: 'checkbox',
                labelSeparator:'',
                boxLabel: 'Enable SSL',
                bind: '{current.smtp.EnableSsl}'
            },
            {
                fieldLabel: 'Sender Name',
                bind: '{current.smtp.SenderName}'
            },
            {
                fieldLabel: 'Sender Email',
                vtype: 'email',
                bind: '{current.smtp.SenderEmail}'
            }
        ],
        dockedItems: [
            {
                xtype: 'toolbar',
                dock: 'bottom',
                ui: 'footer',
                items: [ {
                    text: 'Test Mail',
                    formBind: true,
                    handler: 'onSendTestMail'

                }, '->', {
                    text: 'Save',
                    ui: 'soft-green',
                    iconCls: 'x-fa fa-save',
                    formBind: true,
                    handler: 'onSaveSmtpSetting'

                }, {
                    text: 'Cancel',
                    ui: 'gray',
                    iconCls: 'x-fa fa-close',
                    handler: function (btn) {
                        btn.up('window').close();
                    }
                }]
            }]
    }]
});