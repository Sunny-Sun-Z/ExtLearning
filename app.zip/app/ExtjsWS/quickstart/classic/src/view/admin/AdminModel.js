/**
 * Created by kkora on 9/19/2017.
 */
Ext.define('QuickStart.view.admin.AdminModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.admin',

    stores: {
        exportCases: {
            model: 'QuickStart.model.Dashboard',
            autoLoad: true,
            pageSize: 20,
            remoteFilter: true,
            remoteSort: true,
            filters: [{property: "crDs", value: ''}],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    //read: 'case/DashboardData'
                    read: 'setting/GetExportCaseAvailable'

                },
                //  actionMethods: {read: 'POST'},
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },
        processedCases: {
            model: 'QuickStart.model.Dashboard',
            autoLoad: true,
            pageSize: 20,
            remoteFilter: true,
            remoteSort: true,
            filters: [{property: "crDs", value: ''}],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    //read: 'case/DashboardData'
                    read: 'setting/GetProcessedExportCases'

                },
                //  actionMethods: {read: 'POST'},
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },
        keyValues: {
            model: 'QuickStart.model.KeyValue',
            autoLoad: true,
            // pageSize: 20,
            remoteFilter: true,
            remoteSort: true,
            filters: [{property: 'name', value: ''}],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'setting/GetKeyValueSettings'
                },
                //  actionMethods: {read: 'POST'},
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            },
            listeners:{
                load:'onLoadKeyValue'
            }

        },
        reportLookup: {
            model: 'QuickStart.model.KeyValue',
            autoLoad: true,
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'report/GetReportLookup'
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },
        parameters: {
            model: 'QuickStart.model.Parameter',
            autoLoad: true,
            proxy: {
                type: 'memory',
                reader: {
                    type: 'json'
                }
            }
        },
        reports: {
            model: 'QuickStart.model.Report',
            autoLoad: true,
            pageSize: 20,
            remoteFilter: true,
            remoteSort: true,
            filters: [{ property: 'name', value: '' }],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'report/GetReports'
                },
                //  actionMethods: {read: 'POST'},
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        }
    },

    data: {
        exportPath:null,
        current: {
            smtp:null,
            Report: null,
            reportAction: 'Edit',


        }
    },
    formulas: {

        ssisReportType: {
            bind: {bindTo: '{current.Report.Type}'},
            get: function (data) {
                return data == "SSIS";
            }
        },
        reportType: {
            bind: {bindTo: '{current.Report.Type}'},
            get: function (data) {
                return {Type: data};
            },
            set: function (data) {
                this.set('current.Report.Type', data.Type);

            }
        },
    }
});