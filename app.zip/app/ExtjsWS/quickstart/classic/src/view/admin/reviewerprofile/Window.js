/**
 * Created by ssun on 12/02/2019.
 */

Ext.define('QuickStart.view.admin.reviewerprofile.Window', {
    extend: 'QuickStart.view.common.BaseWindow',
    xtype: 'reviewerprofilewindow', 

    requires: [
        'Ext.form.field.Checkbox',
       // 'QuickStart.view.admin.reviewerprofile.OtherTownText'
    ],

    width: 500,
    layout: 'fit',
    defaults: {
        defaultFocus: 'textfield:not([value]):focusable:not([disabled])',
        defaultButton: 'userSaveButton'
    },
    bind: {
        title: '{current.userAction} Profile: {current.reviewerProfile.FirstName} {current.reviewerProfile.LastName}'
    },
    maximized: false,
    constrain: false,
    items: [
        {
            bodyPadding: '10 10 0 10',
            xtype: 'form',
            defaultType: 'textfield',
            defaults: {
                submitEmptyText: false,
                anchor: '100%',
               // labelWidth: 75,
                fieldLabel: ' ',
                msgTarget: 'side',
                allowBlank: false,
                editable: true

            },
            items: [
                {
                    xtype: 'combobox',   
                    fieldLabel: 'Reviewer Name',
                    bind: {
                        hidden: '{current.userAction=="Edit"}',
                        value: '{current.reviewerProfile.UserID}',
                        store: '{usersStore}'
                    },
                    displayField: 'Name',
                    valueField: 'UserID',  //'HometownName',// 'Id',
                    forceSelection: true,
                    name: 'UserToChoose',
                    queryMode: 'local',
                    allowBlank: '{current.userAction=="Edit"}'
                },

                {
                    xtype: 'textareafield',
                    blankText: 'Please specify the Special Considerations',
                    fieldLabel: 'Special Considerations',
                    maxLength: 1000,
                    maxRows: 3,
                    enforceMaxLength: true,
                    bind: '{current.reviewerProfile.SpecialConsideration}',
                    name: 'SpecialConsideration'
                },
               

                {
                    xtype: 'combobox',
                    fieldLabel: 'Current Office',
                    bind: {
                        value: '{current.reviewerProfile.CurrentOfficeID}',
                        store: '{currentOfficeStore}'
                    },
                    displayField: 'medium',
                    valueField: 'code',  //'HometownName',// 'Id',
                    forceSelection: true,
                    name: 'CurrentOffice',
                    queryMode: 'local',
                    //allowBlank: true
                },


                {
                    xtype: 'combobox',
                    fieldLabel: 'Previous Office',
                    bind: {
                        value: '{current.reviewerProfile.PreviousOfficeID}',
                        store: '{previousOfficeStore}'
                    },
                    displayField: 'medium',
                    valueField: 'code',  //'HometownName',// 'Id',
                    forceSelection: true,
                    name: 'PreviousOffice',
                    queryMode: 'local',
                   // allowBlank: true
                },

                
                {
                    xtype: 'combobox',
                    fieldLabel: 'Home Town',
                    bind: {
                        value: '{current.reviewerProfile.HometownID}',
                        store: '{hometownsStore}'
                    },
                    displayField: 'Name', 
                    valueField: 'Id',  //'HometownName',// 'Id',
                    forceSelection: true,
                    name: 'HometownName',
                    queryMode: 'local',
                    reference: 'cbHometown',
                  
                    itemId: 'hometown',
                    listeners: {
                        select: 'onHometownChange',

                    }

                },

                {
                    itemId: 'otherHometown',
                    //xtype: 'otherTownText',
                    blankText: 'Please specify  Other Hometown',
                    fieldLabel: 'Other Hometown',
                    maxLength: 100,
                    enforceMaxLength: true,
                    bind: {
                        hidden: '{current.reviewerProfile.HometownID!=999}',
                        value: '{current.reviewerProfile.OtherHometown}',
                        //requireMe: '{current.reviewerProfile.HometownID===999}'
                    },
                    name: 'OtherHometown',
                    allowBlank: true
                },

               
            ],
            dockedItems: [
                {
                    xtype: 'toolbar',
                    dock: 'bottom',
                    ui: 'footer',
                    items: ['->', {
                        text: 'Save',
                        ui: 'soft-green',
                        iconCls: 'x-fa fa-save',
                        reference: 'userSaveButton',
                        formBind: true,
                        handler: 'onSaveProfile'

                    }, {
                        text: 'Cancel',
                        ui: 'gray',
                        iconCls: 'x-fa fa-close',
                        handler: 'onUserRecordCancel'
                    }]
                }]

        }
    ],
    listeners: {
        close: 'onUserRecordCancel',
       
    }
});