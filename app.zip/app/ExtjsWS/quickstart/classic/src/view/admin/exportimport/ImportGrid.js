/**
 * Created by kkora on 12/21/2017.
 */
Ext.define('QuickStart.view.admin.exportimport.ImportGrid', {
	extend: 'Ext.grid.Panel',
	cls: 'dcf-grid',

	xtype: 'importgrid',

	requires: [
		'Ext.grid.column.RowNumberer',
		'Ext.grid.filters.Filters',
		'Ext.toolbar.Fill'
	],
	title: 'Imported Cases',
	reference: 'importGrid',
	bind: '{importCases}',
	plugins: ['gridfilters'],
	selType: 'checkboxmodel',
	columns: [
	//	{xtype: 'rownumberer'},
		{
			text: 'RootID',
			dataIndex: 'CaseReviewRootID',
			filter: {
				// type: 'number',
				itemDefaults: {
					xtype: 'numberfield',
					emptyText: 'Search for...'
				}
			}
		},
		{
			text: 'Case ID',
			dataIndex: 'CaseID',
		//	width: 80,
			filter: {
				// type: 'number',
				itemDefaults: {
					xtype: 'numberfield',
					emptyText: 'Search for...'
				}
			}
		},
		{
			menuDisabled: true,
			hidden: true,
			text: 'CaseReviewID',
			dataIndex: 'CaseReviewID'
		},
		{
			text: 'Case Name',
			width: 250,
			dataIndex: 'CaseName',
			filter: {
				type: 'string',
				itemDefaults: {
					emptyText: 'Search for...'
				}
			}
		},

		{
			menuDisabled: true,
			text: 'Status',
			width: 150,
			dataIndex: 'CaseStatusCode',
			renderer: 'rendererCaseStatus'
		},
		{
			menuDisabled: true,
			text: 'Type',
			width: 100,
			hidden: true,
			dataIndex: 'ReviewTypeID',
			renderer: 'rendererReviewType'
		},
		{
			menuDisabled: true,
			text: 'Sub Type',
			hidden: true,
			width: 100,
			dataIndex: 'ReviewSubTypeID',
			renderer: 'rendererReviewSubType'
		},
		{
			text: 'Reviewer & QA',
			defaults: {
				width: 200,
				sortable: false,
				menuDisabled: true,
				renderer: 'rendererUser'
			},
			columns: [
				{
					width: 300,
					text: 'Reviewer(s)',
					dataIndex: 'Reviewers',
					renderer: 'renderReviewers'

				},
				{
					text: 'Initial QA',
					dataIndex: 'InitialQAUserID'
				},
				{
					text: 'Second Level QA',
					dataIndex: 'SecondQAUserID',

				},
				{
					text: 'Secondary Oversight',
					dataIndex: 'SecondaryOversightUserID'
				},
				{
					text: 'Secondary CT Oversight',
					dataIndex: 'CtSecondaryOversightUserID'
				}
			]
		},
		{
			text: 'Imported Date',
			menuDisabled: true,
			width: 150,
			dataIndex: 'ImportedDate',
			formatter: 'date("m/d/Y")'
		},
		{
			menuDisabled: true,
			text: 'Import Source',
			width: 150,
			dataIndex: 'ImportSource'
		}
	],

	dockedItems: [
		{
			xtype: 'toolbar',
			//  ui: 'footer',
			items: ['->', {
				ui: 'dcf',
				margin: '0 5 5 0',
				itemId: 'assign',
				iconCls: 'x-fa fa-users',
				handler: 'onAssignUsersToCase',
				bind: {
					disabled: '{!importGrid.selection}'
				},
				text: 'Complete Face Sheet for Selected Case(s)'
			},
				{
					ui: 'dcf',
					text: 'Import',
					itemId: 'import',
					iconCls: 'x-fa fa-upload',
					handler: 'onCaseImportClick'
				}
			]
		},
		{
			xtype: 'pagingtoolbar',
			dock: 'bottom',
			itemId: 'userPaginationToolbar',
			displayInfo: true,
			bind: '{importCases}'

		}]

});