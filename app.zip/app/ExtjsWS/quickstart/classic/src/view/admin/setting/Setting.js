/**
 * Created by kkora on 12/21/2017.
 */
Ext.define('QuickStart.view.admin.setting.Setting', {
    extend: 'Ext.panel.Panel',

    requires: [
        'Ext.button.Button',
        'Ext.panel.Panel',
        'QuickStart.view.admin.setting.SettingController'
    ],

    xtype: 'setting',

    // viewModel: {
    //     type: 'setting'
    // },

    controller: 'setting',

    margin: 20,
    title: 'Settings',

    layout: 'hbox',
    items: [
        {
            width: '75%',
            itemId: 'keyValueGrid',
            xtype: 'keyvaluegrid',
            bind: '{keyValues}'
        },
        {
            width: '25%',
            xtype: 'panel',
            layout: {
                type: 'vbox',
                pack: 'center'
            },
            bodyPadding: 10,
            defaults: {
                width: '100%',
                margin: '0 0 10 0',
                xtype: 'button',
                scale: 'large'
            },
            items: [{
                text: 'AD Profile Picture Sync',
                handler: 'syncAdProfilePicture'
            }, {
                text: 'Add Report',
                handler: 'onAddAdhocReport'
            }, {
                text: 'Config SMTP',
                handler: 'onSmtpSettingClick'
            }]
        },
        {
            xtype: 'addreportwindow',
            itemId: 'addReportWindow'
        },
        {
            xtype: 'smtpsettingwindow',
            itemId: 'smtpSettingWindow'
        }
    ]
});