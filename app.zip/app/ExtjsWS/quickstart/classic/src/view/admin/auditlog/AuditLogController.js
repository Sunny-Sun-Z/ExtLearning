/**
 * Created by kkora on 4/9/2018.
 */
Ext.define('QuickStart.view.admin.auditlog.AuditLogController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.auditlog',
    mixins: ['QuickStart.mixins.Global'],

    /**
     * Called when the view is created
     */
    init: function() {

    },
    onClearAllLogs: function (btn) {

    },
    onClearSelectedLogs: function (btn) {

    },
    onLogExport: function (btn) {

    }
});