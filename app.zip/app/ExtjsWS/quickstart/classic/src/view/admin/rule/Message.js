/**
 * Created by kkora on 1/11/2018.
 */
Ext.define('QuickStart.view.admin.rule.Message', {
    extend: 'Ext.window.Window',

    xtype: 'messagewindow',

    requires: [
        'Ext.data.proxy.Memory',
        'Ext.data.reader.Json',
        'Ext.grid.Panel',
        'Ext.grid.column.RowNumberer',
        'Ext.toolbar.Fill'
    ],

    closeAction: 'close',
    resizable: true,
    modal: true,
    constrain: true,
    height: 400,
    width: 800,
    title: 'Error Messages',
    items: [
        {
            xtype: 'component',
            padding:10,
            itemId:'error',
            cls:'instruction-required',
            // style:{
            //     'color':'#fc8999'
            // },
            html: ''
        },
        {
            xtype: 'grid',
            width:'100%',
         //   hideHeaders: true,
            store: {
                model: 'QuickStart.model.Rule',
                autoLoad: true,
                proxy: {
                    type: 'memory',
                    reader: {
                        type: 'json'
                    }
                }
            },
            columns: [{xtype: 'rownumberer'},
                {
                    flex: 1,
                    text: 'Category',
                    dataIndex: 'ClassName',
                    renderer: function (v) {
                        return v.replace('Model', '');
                    }
                },
                {
                    flex: 2,
                    text: 'Error Message',
                    dataIndex: 'ErrorMessage'
                },
                {
                    width: 100,
                    text: 'Required',
                    dataIndex: 'Required',
                    align: 'center',
                    renderer: function (val, meta, rec) {
                        return val ? "Yes" : "No";
                    }
                }
            ]
        }
    ],
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'bottom',
        ui: 'footer',
        items: ['->', {
            text: 'Cancel',
            iconCls: 'x-fa fa-close',
            ui: 'gray',
            handler: function (btn) {
                btn.up('window').close();
            }
        }]
    }]
});