/**
 * Created by kkora on 12/21/2017.
 */
Ext.define('QuickStart.view.admin.rule.Rule', {
    extend: 'Ext.panel.Panel',

    requires: [
        'QuickStart.view.admin.rule.RuleModel',
        'QuickStart.view.admin.rule.RuleController'
    ],

    xtype: 'rule',
    viewModel: {
        type: 'rule'
    },
    controller: 'rule',

    margin: 20,
    // layout: 'fit',
    // items: [
    //     {
    //         title: 'Rule Engine',
    //         xtype: 'rulegrid',
    //         bind:  '{rules}',
    //         listeners: {
    //             addrecord: 'onAddRule',
    //             editrecord: 'onEditRule',
    //             deleterecord: 'onDeleteRule'
    //         }
    //     }
    // ]

    title: 'Rule Engine',

    layout: 'border',
    items: [
        {
            region: 'north',
            xtype: 'ruleform'
        },
        {
            region: 'center',
            xtype: 'rulegrid',
            bind: '{rules}',
            listeners: {
                addrecord: 'onAddRule',
                editrecord: 'onEditRule',
                deleterecord: 'onDeleteRule'
            }
        }
    ]
});