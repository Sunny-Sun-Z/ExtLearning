/**
 * Created by kkora on 12/21/2017.
 */
Ext.define('QuickStart.view.admin.setting.ReportPanel', {
    extend: 'Ext.panel.Panel',

    requires: [
        'Ext.button.Button',
        'Ext.panel.Panel',
        'QuickStart.view.admin.setting.SettingController'
    ],

    xtype: 'settingreportpanel',
    controller: 'setting',
    margin: 20,
    title: 'Reports',
    layout: 'fit',
    items: [
        {
            xtype: 'reportsettinggrid',
            itemId: 'reportSettingGrid',
            reference: 'reportSettingGrid'
        },        
        {
            xtype: 'addreportwindow',
            itemId: 'addReportWindow'
        }
    ]
});