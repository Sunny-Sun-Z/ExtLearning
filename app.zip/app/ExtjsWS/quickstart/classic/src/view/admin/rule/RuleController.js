/**
 * Created by kkora on 12/21/2017.
 */
Ext.define('QuickStart.view.admin.rule.RuleController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.rule',
    mixins: [
        'QuickStart.mixins.Global'
    ],

    /**
     * Called when the view is created
     */
    init: function () {

    },
    onAddRecord: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            record = Ext.create('QuickStart.model.Rule');

        vm.set('rule', record);
        vm.set('addNew', true);

    },
    onSaveRecord: function (btn) {
        var me = this,
            vm = me.getViewModel()
        ;
        me.saveRecord(vm.get('rule'), null, true);
    },
    onSaveAndAddNewRecord: function (btn) {
        var me = this,
            vm = me.getViewModel()
        ;
        me.saveRecord(vm.get('rule'));
    },
    onResetRecord: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            store=vm.getStore('rules')
        ;
        vm.set('rule', null);
        vm.set('addNew', false);

        store.rejectChanges();
    },
    saveRecord: function (record, view, closable) {
        var me = this,
            vm = me.getViewModel(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: view || me.getView()}),
            userID = QuickStart.util.Global.getUser().id,
            data = record.getData(),
            url = QuickStart.util.Global.getApi() + 'setting/SaveRule';

        myMask.show();

        Ext.Ajax.request({
            url: url,
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            params: {
                userID: QuickStart.util.Global.getUser().id
            },
            jsonData: data,
            success: function (response, opts) {
                myMask.hide();
                //  debugger
                var result = Ext.decode(response.responseText);
                console.log(result)
                if (result != null) {
                    if (!Ext.isEmpty(result.data)) {
                        QuickStart.util.Global.showMessage(result.message);
                        record = Ext.create('QuickStart.model.Rule');
                        vm.set('rule', record);

                        vm.getStore('rules').reload();
                    }
                }
                if (closable) {
                    vm.set('addNew', false);
                }
            },
            failure: function (response, opts) {

                myMask.hide();
                //  debugger
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });

    },
    onEditRule:function (grid, rowIndex, colIndex, cell, e, record, row) {
        var me = this,
            vm = me.getViewModel();

        vm.set('rule', record);
        vm.set('addNew', true);
        vm.set('isEdit', true);
    },
    onDeleteRule: function (grid, rowIndex, colIndex, cell, e, record, row) {
        var me = this,
            data = record.getData(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: me.getView()}),
            action = 'setting/DeleteRule'
        ;
        // console.log(data)
        Ext.Msg.show({
            title: 'Delete Rule?',
            message: "Are you sure do you want to delete rule?",
            buttons: Ext.Msg.YESNO,
            icon: Ext.Msg.QUESTION,
            fn: function (btn) {
                if (btn === 'yes') {
                    myMask.show();
                     Ext.Ajax.request({
                        url: QuickStart.util.Global.getApi() + action,
                        method: 'POST',
                        params: {
                            userID: QuickStart.util.Global.getUser().id
                        },
                        jsonData: data,
                        success: function (response, opts) {
                            myMask.hide();
                            var result = Ext.decode(response.responseText);
                            if (result != null) {
                                if (!Ext.isEmpty(result.data)) {
                                    QuickStart.util.Global.showMessage(result.message);
                                   grid.getStore().remove(record);
                                }
                            }
                        },
                        failure: function (response, opts) {
                            myMask.hide();
                            Ext.Msg.alert('Status', "failure");
                            console.log('server-side failure with status code ' + response.status);
                        },
                        scope: this
                    });
                }
            }
        }, this);


    },
    onCompileRecord:function (btn) {
        var me = this,
            vm = me.getViewModel(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target:  me.getView()}),
            userID = QuickStart.util.Global.getUser().id,
            url = QuickStart.util.Global.getApi() + 'setting/compile';

        myMask.show();

        Ext.Ajax.request({
            url: url,
            method: 'GET',
            headers: {'Content-Type': 'application/json'},
            params: {
                userID: userID
            },
            success: function (response, opts) {
                myMask.hide();
                //  debugger
                var result = Ext.decode(response.responseText);
                console.log(result)
                if (result != null) {
                    if (!Ext.isEmpty(result.data)) {
                        QuickStart.util.Global.showMessage(result.message);
                    }
                }
            },
            failure: function (response, opts) {

                myMask.hide();
                //  debugger
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });

    }

});