/**
 * Created by kkora on 12/21/2017.
 */
Ext.define('QuickStart.view.admin.setting.SettingModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.setting',

    stores: {
        keyValues: {
            model: 'QuickStart.model.KeyValue',
            autoLoad: true,
            // pageSize: 20,
            remoteFilter: true,
            remoteSort: true,
            filters: [{property: 'name', value: ''}],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'setting/GetKeyValueSettings'
                },
                //  actionMethods: {read: 'POST'},
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }

        },

        reportLookup: {
            model: 'QuickStart.model.KeyValue',
            autoLoad: true,
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'report/GetReportLookup'
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },
        parameters: {
            model: 'QuickStart.model.Parameter',
            autoLoad: true,
            proxy: {
                type: 'memory',
                reader: {
                    type: 'json'
                }
            }
        },

    },

    data: {

        current: {
            Report: null
        }
    },
    formulas: {

        ssisReportType: {
            bind: {bindTo: '{current.Report.Type}'},
            get: function (data) {
                return data == "SSIS";
            }
        },
        reportType: {
            bind: {bindTo: '{current.Report.Type}'},
            get: function (data) {
                return {Type: data};
            },
            set: function (data) {
                this.set('current.Report.Type', data.Type);

            }
        },
    }
});