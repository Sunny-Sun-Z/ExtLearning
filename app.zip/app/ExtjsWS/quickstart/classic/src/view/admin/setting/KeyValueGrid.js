/**
 * Created by kkora on 1/14/2018.
 */
Ext.define('QuickStart.view.admin.setting.KeyValueGrid', {
    extend: 'Ext.grid.Panel',
    cls: 'user-grid dcf-grid',
    requires: [
        'Ext.form.field.Text',
        'Ext.grid.column.Action',
        'Ext.grid.column.RowNumberer',
        'Ext.grid.plugin.CellEditing',
        'Ext.selection.CellModel'
    ],
    xtype: 'keyvaluegrid',
    selModel: {
        type: 'cellmodel'
    },
    plugins: [{
        ptype: 'cellediting',
        clicksToEdit: 1
    }],
    columns: [
        {xtype: 'rownumberer'},
        {
            flex: 1,
            text: 'Key',
            dataIndex: 'Key'
            //, editor: {xtype: 'textfield', allowBlank: false}
        }, {
            flex: 1,
            text: 'Value',
            dataIndex: 'Value',
            align: 'center',
            editor: {
                xtype: 'textfield',
                allowBlank: false
            }
        },
        {
            xtype: 'actioncolumn',
            items: [
                {
                    iconCls: 'x-fa fa-trash',
                    handler: 'onDeleteKeyValue',
                    tooltip: 'Delete'
                }
            ],
            hidden: true,
            align: 'center',
            menuDisabled: true,
            width: 70,
            sortable: false,
            dataIndex: 'bool',
            tooltip: 'Actions '
        }
    ],
    dockedItems: [
        {
            xtype: 'toolbar',
            ui: 'footer',
            items: [
                {
                    text: 'Add',
                    itemId: 'add',
                    iconCls: 'x-fa fa-plus light',
                    handler: 'onAddKeyValueRecord',
                    hidden:true
                }, '->',
                {
                    text: 'Save',
                    itemId: 'save',
                    formBind: true,
                    ui: 'soft-green',
                    iconCls: 'x-fa fa-save',
                    handler: 'onSaveKeyValueRecord'
                }]

        }]
});