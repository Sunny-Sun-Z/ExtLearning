﻿/**
 * Created by hlawrence on 12/13/2017.
 */
Ext.define('QuickStart.view.mixins.ItemStatus', {
    extend: 'Ext.Mixin',

    facesheetQuestions: [
        {
            errorsExist: false,
            itemCode: 23,
            itemName: 'facesheet',
            questions: [
                {
                    QuestionG1: {
                        required: false,
                        answered: false,
                        properties: {childDemographicStore: {isStore: true}}
                    }
                },
                {
                    QuestionG2: {
                        required: false,
                        answered: false,
                        properties: {caseParticipantStore: {isStore: true}}
                    }
                },
                //{
                //    QuestionG1QuestionG2Interviewed: {
                //        required: false,
                //        answered: false,
                //        properties: {},
                //        vm: {
                //            hasDemographicChildOrParticipantInterviewed: {
                //                value: false,
                //                depend: [{
                //                    hasCaseOrCaseInterviewNote: false
                //                }]
                //            }
                //        }
                //    }
                //},

                {
                    QuestionH: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsCaseOpenReasonOtherAbuseNeglect': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    QuestionI: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.FirstCaseOpeningDate': {type: 'date'}}
                    }
                },
                {
                    QuestionJ: {
                        required: true,
                        answered: false,
                        isMulti: false,
                        properties: {
                            'caseReview.FosterEntryDate': {type: 'date'},
                            'caseReview.IsFosterEntryDateNA': {type: 'int', value: [1, 2]}
                        }
                    }
                },
                {
                    QuestionK: {
                        required: true,
                        answered: false,
                        isMulti: false,
                        properties: {
                            'caseReview.EpisodeDischargeDate': {type: 'date'},
                            'caseReview.IsEpisodeDischargeDateNA': {type: 'int', value: [1, 2]},
                            'caseReview.IsEpisodeNotYetDischarged': {type: 'int', value: [1, 2]}
                        }
                    }
                },
                {
                    QuestionL: {
                        required: true,
                        answered: false,
                        isMulti: false,
                        properties: {
                            'caseReview.CaseClosureDate': {type: 'date'},
                            'caseReview.IsCaseClosureNotClosed': {type: 'int', value: [1, 2]}
                        }
                    }
                },
                {
                    QuestionM: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.CaseReasons': {
                                type: 'int',
                                value: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],
                                isMulti: true
                            }
                        }
                    }
                }
            ]
        }
    ],
    safetyQuestions: [
        {
            errorsExist: false,
            itemCode: 2,
            itemName: 'item1',
            applicabilityProp: 'caseReview.Item1IsApplicable',
            questions: [
                {
                    Applicability: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.Item1IsApplicable': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    Question1A: {
                        required: false,
                        answered: false,
                        properties: {'caseReview.ReportsNotInAccordance': {type: 'int'}}
                    }
                },
                {
                    Question1A1: {
                        required: true,
                        answered: false,
                        properties: {safetyReportStore: {isStore: true}}
                    }
                },
                {
                    Question1B: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.FaceToFaceReportsNotInAccordance': {type: 'int'}}
                    }
                },
                {
                    Question1C: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsDelayBeyondAgencyControl': {type: 'int', value: [1, 2, 3]}}
                    }
                }
            ]
        },
        {
            errorsExist: false,
            itemCode: 3,
            itemName: 'item2',
            applicabilityProp: 'caseReview.Item2IsApplicable',
            questions: [
                {
                    PreApplicability: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.ItemApplicability51': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability52': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability53': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability54': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability55': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability56': {type: 'int', value: [1, 2]}
                        }
                    }
                },
                {
                    Applicability: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.Item2IsApplicable': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    Question2A: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsEffortToPreventReEntry': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    Question2B: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsChildRemovedToEnsureSafety': {type: 'int', value: [1, 2, 3]}}
                    }
                }
            ]
        },
        {
            errorsExist: false,
            itemCode: 4,
            itemName: 'item3',
            applicabilityProp: 'caseReview.Item3IsApplicable',
            questions: [
                {
                    Question3A: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsInitialAssesmentForAllChildrenInHome': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question3A1: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsFamilyMaltreatmentAllegations': {type: 'int', value: [1, 2]},
                            'caseReview.IsMaltreatmentNotSubstantiated': {type: 'int', value: [1, 2]}
                        }
                    }
                },
                {
                    Question3B: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsOngoingAssesementForAllChildrenInHome': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question3C: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsSafetyPlanDevelopedAndMonitored': {type: 'int', value: [1, 2, 3]}}
                    }
                },
                {
                    Question3D: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsSafetyConcernForOtherChildren': {type: 'int', value: [1, 2, 3]}}
                    }
                },
                {
                    Question3D1: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.SafetyRelatedIncidents': {
                                type: 'int',
                                isMulti: true,
                                value: [86, 87, 88, 89, 90, 91]
                            }
                        }
                    }
                },
                {
                    Question3E: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsFosterSafetyConcernDuringVisitation': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question3E1: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.FosterSafety': {
                                type: 'int',
                                isMulti: true,
                                value: [92, 93, 94, 95, 96, 97]
                            }
                        }
                    }
                },
                {
                    Question3F: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsFosterSafetyConcernNotAddressed': {type: 'int', value: [1, 2, 3]}}
                    }
                },
                {
                    Question3F1: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.FosterPlacementConcern': {
                                type: 'int',
                                isMulti: true,
                                value: [98, 99, 100, 101, 102, 103, 104]
                            }
                        }
                    }
                }
            ]
        }
    ],
    permanencyQuestions: [
        {
            errorsExist: false,
            itemCode: 5,
            itemName: 'item4',
            applicabilityProp: 'caseReview.Item4IsApplicable',
            questions: [
                {
                    Question4A: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.NumberOfPlacementSettings': {type: 'int'}}
                    }
                },
                {
                    Question4A1: {
                        required: true,
                        answered: false,
                        properties: {placementStore: {isStore: true}}
                    }
                },
                {
                    Question4B: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.WereAllPlacementChangesPlanned': {type: 'int', value: [1, 2, 3]}}
                    }
                },
                {
                    Question4C: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsCurrentPlacementSettingStable': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    Question4C1: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.PlacementApplicableCircumstances': {
                                type: 'int',
                                isMulti: true,
                                value: [121, 122, 123, 124, 125, 126]
                            }
                        }
                    }
                }
            ]
        },
        {
            errorsExist: false,
            itemCode: 6,
            itemName: 'item5',
            applicabilityProp: 'caseReview.Item5IsApplicable',
            questions: [
                {
                    Applicability: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.Item5IsApplicable': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    Question5A1: {
                        required: true,
                        answered: false,
                        properties: {goalStore: {isStore: true}}
                    }
                },
                {
                    Question5A2: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.Goal1Code': {type: 'int', value: [127, 128, 129, 130]},
                            'caseReview.Goal2Code': {type: 'int', value: [127, 128, 129, 130, 310]}
                        }
                    }
                },
                {
                    Question5A3: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsGoalSpecified': {type: 'int', value: [1, 2, 3]}}
                    }
                },
                {
                    Question5B: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.WereAllGoalsInTimelyManner': {type: 'int', value: [1, 2, 3]}}
                    }
                },
                {
                    Question5C: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.WereAllGoalsAppropriate': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    Question5D: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsInFoster15OutOf22': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    Question5E: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.MeetsTerminationOfParentalRights': {type: 'int', value: [1, 2, 3]}}
                    }
                },
                {
                    Question5F: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsAgencyJointTerminationOfParentalRights': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question5G: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsExceptionForTermination': {type: 'int', value: [1, 2, 3]}}
                    }
                },
                {
                    Question5G1: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.TerminationExceptions': {
                                type: 'int',
                                isMulti: true,
                                value: [138, 139, 140, 141, 142]
                            }
                        }
                    }
                }
            ]
        },
        {
            errorsExist: false,
            itemCode: 7,
            itemName: 'item6',
            applicabilityProp: 'caseReview.Item6IsApplicable',
            questions: [
                {
                    Question6A1: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.ChildMostRecentFosterEntryDate': {type: 'date'}}
                    }
                },
                {
                    Question6A2: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.TimeInCare': {type: 'int'}}
                    }
                },
                {
                    Question6A3: {
                        required: true,
                        answered: false,
                        isMulti: false,
                        properties: {
                            'caseReview.DischargeDate': {type: 'date'},
                            'caseReview.IsDischargeDateNA': {type: 'int', value: [1, 2]}
                        }
                    }
                },
                {
                    Question6A4: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.PermanencyGoal1': {
                                type: 'int',
                                isMulti: true,
                                value: [127, 128, 129, 130]
                            }
                        }
                    }
                },
                {
                    Question6B: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsAgencyConcertedEfforts': {type: 'int', value: [1, 2, 3]}}
                    }
                },
                {
                    Question6C: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsOtherPlannedConcertedEffort': {type: 'int', value: [1, 2, 3]}}
                    }
                },
                {
                    Question6C1: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.LivingArrangementCode': {type: 'int', value: [1, 2, 3,4,5,6]}}
                    }
                },
                {
                    Question6C2: {
                        required: true,
                        answered: false,
                        isMulti: false,
                        properties: {
                            'caseReview.OtherPlannedArrangementDocumentationDate': {type: 'date'},
                            'caseReview.IsOtherPlannedArrangement': {type: 'int', value: [1, 4]}
                        }
                    }
                }
            ]
        },
        {
            errorsExist: false,
            itemCode: 8,
            itemName: 'item7',
            applicabilityProp: 'caseReview.Item7IsApplicable',
            questions: [
                {
                    Applicability: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.Item7IsApplicable': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    Question7A: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsPlacedWithAllSiblings': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    Question7B: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsValidReasonForSeparation': {type: 'int', value: [1, 2, 3]}}
                    }
                }
            ]
        },
        {
            errorsExist: false,
            itemCode: 9,
            itemName: 'item8',
            applicabilityProp: 'caseReview.Item8IsApplicable',
            questions: [
                {
                    PreApplicability: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.ItemApplicability57': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability58': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability59': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability60': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability61': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability62': {type: 'int', value: [1, 2]}
                        }
                    }
                },
                {
                    Applicability: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.Item8IsApplicable': {type: 'int', value: [1, 2]}}
                    }
                },
                //{
                //    ApplicabilityMother: {
                //        required: false,
                //        answered: false,
                //        groupId: 'item8ParticipantCheckboxGroupMother'
                //    }
                //},
                //{
                //    ApplicabilityFather: {
                //        required: false,
                //        answered: false,
                //        groupId: 'item8ParticipantCheckboxGroupFather'
                //    }
                //},
                //{
                //    MotherOrFatherApplicable: {
                //        required: true,
                //        answered: false,
                //        modelProperty: [
                //            { name: 'motherOrFatherApplicable', actionType: 'calculation', input: ['item8ParticipantCheckboxGroupMother', 'item8ParticipantCheckboxGroupFather'] }
                //        ]
                //    }
                //},
                {
                    Question8A: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsSufficientFrequencyForMotherVisitation': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question8A1: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.MotherVisitationFrequencyCode': {
                                type: 'int',
                                value: [1, 2, 3, 4, 5, 6, 7]
                            }
                        }
                    }
                },
                {
                    Question8B: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsSufficientFrequencyForFatherVisitation': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question8B1: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.FatherVisitationFrequencyCode': {
                                type: 'int',
                                value: [1, 2, 3, 4, 5, 6, 7]
                            }
                        }
                    }
                },
                {
                    Question8C: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsSufficientQualityForMotherVisitation': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question8D: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsSufficentQualityForFatherVisitation': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question8E: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsSufficientFrequencyForSiblingVisitation': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question8E1: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.SiblingVisitationFrequencyCode': {
                                type: 'int',
                                value: [1, 2, 3, 4, 5, 6, 7]
                            }
                        }
                    }
                },
                {
                    Question8F: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsSufficentQualityForSiblingVisitation': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                }
            ]
        },
        {
            errorsExist: false,
            itemCode: 10,
            itemName: 'item9',
            applicabilityProp: 'caseReview.Item9IsApplicable',
            questions: [
                {
                    Applicability: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.Item9IsApplicable': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    Question9A: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsConcertedEffortsForImportantConnections': {
                                type: 'int',
                                value: [1, 2]
                            }
                        }
                    }
                },
                {
                    Question9B: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsSufficientInquiryForIndianTribe': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    Question9C: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsTribeProvidedTimelyNotification': {type: 'int', value: [1, 2, 3]}}
                    }
                },
                {
                    Question9D: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsAccordanceWithIndianChildWelfareAct': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                }
            ]
        },
        {
            errorsExist: false,
            itemCode: 11,
            itemName: 'item10',
            applicabilityProp: 'caseReview.Item10IsApplicable',
            questions: [
                {
                    Applicability: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.Item10IsApplicable': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    Question10A1: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsRecentPlacementWithRelative': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    Question10A2: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsPlacementWithRelativeStable': {type: 'int', value: [1, 2, 3]}}
                    }
                },
                {
                    Question10B: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsConcertedEffortToLocateMaternalRelatives': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question10C: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsConcertedEffortToLocatePaternalRelatives': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                }
            ]
        },
        {
            errorsExist: false,
            itemCode: 12,
            itemName: 'item11',
            applicabilityProp: 'caseReview.Item11IsApplicable',
            questions: [
                {
                    PreApplicability: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.ItemApplicability63': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability64': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability65': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability66': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability67': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability261': {type: 'int', value: [1, 2]}
                        }
                    }
                },
                {
                    Applicability: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.Item11IsApplicable': {type: 'int', value: [1, 2]}}
                    }
                },
                //{
                //    ApplicabilityMother: {
                //        required: false,
                //        answered: false,
                //        groupId: 'item11ParticipantCheckboxGroupMother'
                //    }
                //},
                //{
                //    ApplicabilityFather: {
                //        required: false,
                //        answered: false,
                //        groupId: 'item11ParticipantCheckboxGroupFather'
                //    }
                //},
                //{
                //    MotherOrFatherApplicable: {
                //        required: true,
                //        answered: false,
                //        modelProperty: [
                //            { name: 'motherOrFatherApplicable', actionType: 'calculation', input: ['item11ParticipantCheckboxGroupMother', 'item11ParticipantCheckboxGroupFather'] }
                //        ]
                //    }
                //},
                {
                    Question11A: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsConcertedEffortMotherFosterRelationship': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question11A1: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.EffortsToSupportMotherFosterRelationship': {
                                type: 'int',
                                isMulti: true,
                                value: [164, 165, 166, 167, 168, 169, 170]
                            }
                        }
                    }
                },
                {
                    Question11B: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsConcertedEffortFatherFosterRelationship': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question11B1: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.EffortsToSupportFatherFosterRelationship': {
                                type: 'int',
                                isMulti: true,
                                value: [171, 172, 173, 174, 175, 176, 177]
                            }
                        }
                    }
                }
            ]
        }
    ],
    wellbeingQuestions: [
        {
            errorsExist: false,
            itemCode: 14,
            itemName: 'item12a',
            applicabilityProp: 'caseReview.Item12aIsApplicable',
            questions: [
                {
                    Question12A1: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsComprehensiveAssessementConducted': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    Question12A2: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsAppropriateServicesProvided': {type: 'int', value: [1, 2, 3]}}
                    }
                }
            ]
        },
        {
            errorsExist: false,
            itemCode: 15,
            itemName: 'item12b',
            applicabilityProp: 'caseReview.Item12bIsApplicable',
            questions: [
                {
                    PreApplicability: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.ItemApplicability68': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability69': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability70': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability71': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability72': {type: 'int', value: [1, 2]}
                        }
                    }
                },
                {
                    ApplicabilityMother: {
                        required: false,
                        answered: false,
                        properties: {'caseReview.IsNeedsServicesApplicableForMother': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    ApplicabilityFather: {
                        required: false,
                        answered: false,
                        properties: {'caseReview.IsNeedsServicesApplicableForFather': {type: 'int', value: [1, 2]}}
                    }
                },
                //{
                //    MotherSelected: {
                //        required: false,
                //        answered: false,
                //        modelProperty: undefined
                //    }
                //},
                //{
                //    FatherSelected: {
                //        required: false,
                //        answered: false,
                //        modelProperty: undefined
                //    }
                //},
                //{
                //    MotherOrFatherApplicable: {
                //        required: true,
                //        answered: false,
                //        modelProperty: [
                //            { name: 'motherOrFatherApplicable', actionType: 'calculation', input: ['item12BParticipantCheckboxGroupMother', 'item12BParticipantCheckboxGroupFather'] }
                //        ]
                //    }
                //},
                {
                    Question12B1: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsComprehensiveAssessementForMotherConducted': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question12B2: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsComprehensiveAssessementForFatherConducted': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question12B3: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsAppropriateServicesForMotherProvided': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question12B4: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsAppropriateServicesForFatherProvided': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                }
            ]
        },
        {
            errorsExist: false,
            itemCode: 16,
            itemName: 'item12c',
            applicabilityProp: 'caseReview.Item12cIsApplicable',
            questions: [
                {
                    Applicability: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.Item12cIsApplicable': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    Question12C1: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsNeedsOfFosterParentsAdequatelyAssessed': {
                                type: 'int',
                                value: [1, 2]
                            }
                        }
                    }
                },
                {
                    Question12C2: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsFosterParentsProvidedAppropriateServices': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                }
            ]
        },
        {
            errorsExist: false,
            itemCode: 17,
            itemName: 'item13',
            applicabilityProp: 'caseReview.Item13IsApplicable',
            questions: [
                {
                    PreApplicability: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.ItemApplicability73': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability74': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability75': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability292': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability76': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability77': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability78': {type: 'int', value: [1, 2]}
                        }
                    }
                },
                {
                    Applicability: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.Item13IsApplicable': {type: 'int', value: [1, 2]}}
                    }
                },
                //{
                //    Mother: {
                //        required: false,
                //        answered: false,
                //        modelProperty: undefined
                //    }
                //},
                //{
                //    Father: {
                //        required: false,
                //        answered: false,
                //        modelProperty: undefined
                //    }
                //},
                //{
                //    MotherOrFatherApplicable: {
                //        required: true,
                //        answered: false,
                //        modelProperty: [
                //            { name: 'motherOrFatherApplicable', actionType: 'calculation', input: ['item13ParticipantCheckboxGroupMother', 'item13ParticipantCheckboxGroupFather'] }
                //        ]
                //    }
                //},
                {
                    Question13A: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsAgencyConcertedEffortsToInvolveTheChild': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question13B: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsAgencyConcertedEffortsToInvolveTheMother': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question13C: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsAgencyConcertedEffortsToInvolveTheFather': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                }
            ]
        },
        {
            errorsExist: false,
            itemCode: 18,
            itemName: 'item14',
            applicabilityProp: 'caseReview.Item14IsApplicable',
            questions: [
                {
                    Question14A: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsResponsiblePartyVisitationFrequencySufficient': {
                                type: 'int',
                                value: [1, 2]
                            }
                        }
                    }
                },
                {
                    Question14A1: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.ResponsiblePartyVisitationFrequencyCode': {
                                type: 'int',
                                value: [1, 2, 3, 4, 5, 6, 7]
                            }
                        }
                    }
                },
                {
                    Question14B: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsResponsiblePartyVisitationQualitySufficient': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                }
            ]
        },
        {
            errorsExist: false,
            itemCode: 19,
            itemName: 'item15',
            applicabilityProp: 'caseReview.Item15IsApplicable',
            questions: [
                {
                    PreApplicability: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.ItemApplicability79': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability80': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability293': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability81': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability82': {type: 'int', value: [1, 2]},
                            'caseReview.ItemApplicability83': {type: 'int', value: [1, 2]}
                        }
                    }
                },
                {
                    Applicability: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.Item15IsApplicable': {type: 'int', value: [1, 2]}}
                    }
                },
                //{
                //    MotherSelected: {
                //        required: false,
                //        answered: false,
                //        modelProperty: undefined
                //    }
                //},
                //{
                //    FatherSelected: {
                //        required: false,
                //        answered: false,
                //        modelProperty: undefined
                //    }
                //},
                //{
                //    MotherOrFatherApplicable: {
                //        required: true,
                //        answered: false,
                //        modelProperty: [
                //            { name: 'motherOrFatherApplicable', actionType: 'calculation', input: ['item15ParticipantCheckboxGroupMother', 'item15ParticipantCheckboxGroupFather'] }
                //        ]
                //    }
                //},
                {
                    Question15A1: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.ResponsiblePartyVisitationFrequencyWithMotherCode': {
                                type: 'int',
                                value: [1, 2, 3, 4, 5, 6, 7]
                            }
                        }
                    }
                },
                {
                    Question15A2: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsResponsiblePartyVisitationFrequencyWithMotherSufficient': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question15B1: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.ResponsiblePartyVisitationFrequencyWithFatherCode': {
                                type: 'int',
                                value: [1, 2, 3, 4, 5, 6, 7]
                            }
                        }
                    }
                },
                {
                    Question15B2: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsResponsiblePartyVisitationFrequencyWithFatherSufficient': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question15C: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsResponsiblePartyVisitationQualityWithMotherSufficient': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question15D: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsResponsiblePartyVisitationQualityWithFatherSufficient': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                }
            ]
        },
        {
            errorsExist: false,
            itemCode: 20,
            itemName: 'item16',
            applicabilityProp: 'caseReview.Item16IsApplicable',
            questions: [
                {
                    Applicability: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.Item16IsApplicable': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    Question16A: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsAgencyAssessEducationNeeds': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    Question16A1: {
                        required: false,
                        answered: false,
                        properties: {educationStore: {isStore: true}}
                    }
                },
                {
                    Question16B: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsAgencyAddressEducationNeeds': {type: 'int', value: [1, 2, 3]}}
                    }
                }
            ]
        },
        {
            errorsExist: false,
            itemCode: 21,
            itemName: 'item17',
            applicabilityProp: 'caseReview.Item17IsApplicable',
            questions: [
                {
                    Applicability: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.Item17IsApplicable': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    Question17A1: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsAgencyAssessPhysicalHealthNeeds': {type: 'int', value: [1, 2, 3]}}
                    }
                },
                {
                    Question17A2: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsAgencyAssessDentalHealthNeeds': {type: 'int', value: [1, 2, 3]}}
                    }
                },
                {
                    Question17A3: {
                        required: false,
                        answered: false,
                        properties: {physicalDentalHealthStore: {isStore: true}}
                    }
                },
                {
                    Question17A4: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.FosterFederalCaseManagamentCriteria': {
                                type: 'int',
                                value: [178, 179, 180, 181, 182]
                            }
                        }
                    }
                },
                {
                    Question17B1: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsFosterOversightMedicationForPhysicalHealtyAppropriate': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question17B2: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsAppropriateSerivcesForAllPhysicalHealthNeeds': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question17B3: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsAppropriateServicesForAllDentalNeeds': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                }
            ]
        },
        {
            errorsExist: false,
            itemCode: 22,
            itemName: 'item18',
            applicabilityProp: 'caseReview.Item18IsApplicable',
            questions: [
                {
                    Applicability: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.Item18IsApplicable': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    Question18A: {
                        required: true,
                        answered: false,
                        properties: {'caseReview.IsAgencyAssessMentalHealthNeeds': {type: 'int', value: [1, 2]}}
                    }
                },
                {
                    Question18A1: {
                        required: false,
                        answered: false,
                        properties: {mentalHealthStore: {isStore: true}}
                    }
                },
                {
                    Question18B: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsFosterOversightMedicationForMentalHealtyAppropriate': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                },
                {
                    Question18C: {
                        required: true,
                        answered: false,
                        properties: {
                            'caseReview.IsAppropriateSerivcesForMentalHealthNeeds': {
                                type: 'int',
                                value: [1, 2, 3]
                            }
                        }
                    }
                }
            ]
        }
    ],
    isAnswerValid: function (values, ansObj) {
        var fResult = [],
            retval = false;

        if (ansObj.type === 'int') {
            if (Ext.isEmpty(ansObj.value)) {
                if (values.length > 0) {
                    return true;
                } else {
                    return false;
                }
            }

            Ext.each(values, function (value) {
                if (ansObj.value.indexOf(parseInt(value)) > -1) {
                    fResult.push(value);
                }
            });

            if (fResult.length > 0) {
                return true;
            } else {
                return false;
            }
        } else if (ansObj.type === 'date') {
            return Ext.isDate(values[0]);
        } else if (ansObj.isStore) {
            return values[0].count() > 0;
        }
    },
    allQuestionsAnswered: function (viewName, itemCode) {
        var me = this,
            items = [],
            answers = [],
            vm = me.getViewModel(),
            isQuestionAnswered = false,
            allQuestionsAnswered = true,
            valueObj, ans, values = [], result = {}, statCode, noQuestAnswered = 0;

        if (Ext.isEmpty(itemCode)) {
            if (Ext.isEmpty(viewName)) {
                items = me.facesheetQuestions.concat(me.safetyQuestions, me.permanencyQuestions, me.wellbeingQuestions);
            } else if (viewName === 'facesheet') {
                items = me.facesheetQuestions;
            } else if (viewName === 'safety') {
                items = me.safetyQuestions;
            } else if (viewName === 'permanency') {
                items = me.permanencyQuestions;
            } else if (viewName === 'wellbeing') {
                items = me.wellbeingQuestions;
            }
        } else if (itemCode == 23) {
            items = me.facesheetQuestions;
        } else if (itemCode > 1 && itemCode < 5) {
            items = me.safetyQuestions.filter(function (quest) {
                return quest.itemCode == itemCode;
            });
        } else if (itemCode > 4 && itemCode < 13) {

            items = me.permanencyQuestions.filter(function (quest) {
                return quest.itemCode == itemCode;
            });
        } else if (itemCode > 12 && itemCode < 23) {
            items = me.wellbeingQuestions.filter(function (quest) {
                return quest.itemCode == itemCode;
            });
        }

        Ext.each(items, function (item) {
            if (!allQuestionsAnswered) {
                return;
            }

            if (item.hasOwnProperty('applicabilityProp') && vm.get(item.applicabilityProp) == 2) {
                result[item.itemName] = {itemCode: item.itemCode, statusCode: 1};
                allQuestionsAnswered = true;
                noQuestAnswered = 0;
            } else {
                Ext.each(item.questions, function (ques) {
                    if (!allQuestionsAnswered) {
                        return;
                    }
                    //
                    // Just take 1st value. This is not the most efficient way to do this!!!!
                    //
                    if (Ext.Object.getSize(ques) > 0) {
                        valueObj = Ext.Object.getValues(ques)[0];
                    }

                    if (valueObj.hasOwnProperty('isMulti') && !valueObj.isMulti) {
                        for (var prop in valueObj.properties) {

                            //ans = vm.get(prop);
                            ans = me.getSelection(vm, prop);

                            if (!Ext.isEmpty(ans)) {
                                isQuestionAnswered = true;
                                break;
                            }
                        }
                        if (!isQuestionAnswered) {
                            allQuestionsAnswered = false;
                        }
                    }
                    else if (valueObj.hasOwnProperty('vm')) {
                      //console.log(valueObj.vm)
                        isQuestionAnswered = true;
                        for (var prop in valueObj.vm) {

                            //ans = vm.get(prop);
                            ans = me.getSelection(vm, prop);

                            if (ans == valueObj.vm[prop].value) {

                                Ext.each( valueObj.vm[prop].depend, function (d) {
                                    for (var p in d) {
                                        ans = me.getSelection(vm, p);
                                        if (ans != d[p]) {
                                            isQuestionAnswered = false;
                                            noQuestAnswered++;
                                            break;
                                        }
                                    }
                                });
                            }
                        }
                        if (!isQuestionAnswered) {
                            allQuestionsAnswered = false;
                        }
                    }
                    else {
                        if (valueObj.required) {
                            for (var prop in valueObj.properties) {

                                //ans = vm.get(prop);
                                ans = me.getSelection(vm, prop);
                                values = [];
                                answers = [];

                                if (valueObj.properties[prop].isStore) {
                                    values.push(ans);
                                } else {
                                    if (Ext.isObject(ans)) {
                                        for (var prop2 in ans) {
                                            values.push(ans[prop2]);
                                        }
                                    } else {
                                        values.push(ans);
                                    }
                                }

                                if (me.isAnswerValid(values, valueObj.properties[prop])) {
                                    answers.push(values);
                                }

                                if (answers.length == 0) {
                                    allQuestionsAnswered = false;
                                }

                                if (allQuestionsAnswered) {
                                    noQuestAnswered++;
                                }
                            }
                        }
                    }
                });

                if (allQuestionsAnswered) {
                    statCode = 1;
                } else if (noQuestAnswered == 0) {
                    statCode = 3;
                } else {
                    statCode = 2;
                }

                result[item.itemName] = {itemCode: item.itemCode, statusCode: statCode};
                allQuestionsAnswered = true;
                noQuestAnswered = 0;
            }
        });

        return result;
    },
    getItemStatus: function (itemCode) {

        var result = this.allQuestionsAnswered(null, itemCode),
            statusCode;

        for (var prop in result) {
            statusCode = result[prop].statusCode;
            break;
        }

        return statusCode;
    },
    getDataEntryCaseStatus: function (dataIn) {
        var vm = me.getViewModel(),
            data,
            outcomes = [],
            record = vm.get('caseReview'),
            statusCode, allItemsComplete = true, facesheetComplete = false;

        if (record) {
            data = !Ext.isEmpty(dataIn) ? dataIn : record.getData();

            if (data.CaseStatusCode > 3) {
                // Return case status code if case in QA.
                return data.CaseStatusCode;
            }

            outcomes = data.CR_Outcome_Collection;

            Ext.each(outcomes, function (outcome) {
                Ext.each(outcome.CR_Item_Collection, function (item) {
                    if (outcome.OutcomeCode == 21 && item.StatusCode == 1) {
                        facesheetComplete = true;
                    } else if (!(item.StatusCode == 1 || item.StatusCode == 4)) { //StatusCode == 1(Complete) || item.StatusCode == 4(Not Applicable)
                        allItemsComplete = false;
                    }
                });
            });

            if (allItemsComplete) {
                statusCode = 1;
            } else if (facesheetComplete) {
                statusCode = 2;
            } else {
                statusCode = 3;
            }
        }

        return statusCode;
    },
    getSelection: function (vModel, prop) {
        var answer = vModel.get(prop);
        return answer;
    }
});