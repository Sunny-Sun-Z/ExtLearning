/**
 * Created by kkora on 1/24/2018.
 */
Ext.define('QuickStart.view.mixins.Permission', {
    extend: 'Ext.Mixin'

});