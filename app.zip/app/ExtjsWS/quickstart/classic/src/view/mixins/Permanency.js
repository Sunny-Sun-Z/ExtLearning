/**
 * Created by kkora on 10/24/2017.
 */

Ext.define('QuickStart.view.mixins.Permanency', {
    extend: 'Ext.Mixin',
    onAddPlacement: function (grid, btn) {

        var me = this,
            win = me.getView().down('#placementWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = Ext.create('QuickStart.model.casereview.Placement');

        win.show(btn);

        vm.set('current.placement', record);
        vm.set('current.placementAction', 'Add');
		vm.getStore('placementStore').add(record);
		form.reset();
		form.isValid();
    },
    onEditPlacement: function (grid, btn, rec) {

        var me = this,
            win = me.getView().down('#placementWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = rec;

        win.show(btn);
        form.isValid();
        vm.set('current.placementEdited', record.getData());
        vm.set('current.placement', record);
        vm.set('current.placementAction', 'Edit');
    },
    onDeletePlacement: function (grid, btn, rec) {
        var me = this,
            vm = me.getViewModel(),
            store = grid.getStore();
        Ext.MessageBox.confirm('Confirm?', 'Are you sure do you want to remove this?', function (btn) {
            if (store.getCount() == 1) {
                me.setDeferMessage(vm, 'Placements', "This row cannot be deleted from table 4A1. Please click on the placement date to edit.");
                return;
            }
            store.remove(rec);
            if (store.getCount() == 0) {
                var s = vm.get('caseReview.Permanency');
                s.CR_Placement_Collection = [];
                vm.set('caseReview.Permanency', s);
            }
        });
    },
    onSavePlacement: function (btn) {
        //console.log('onSavePlacement');
        var me = this,
            win = btn.up('window'),
            form = win.down('form').getForm(),
            values = form.getValues(),
            vm = me.getViewModel(),
            record = vm.get('current.placement'),
            data = record.getData()
        ;

		if(btn.type=='addnew'){
			var newrecord = Ext.create('QuickStart.model.casereview.Placement');
			vm.set('current.placement', newrecord);
			vm.set('current.placementAction', 'Add');
			vm.getStore('placementStore').add(newrecord);
			form.reset();
			form.isValid();
		}
		else{
			win.close();
		}
    },
    onPlacementDataChanged: function (store) {
       //  console.log('onPlacementDataChanged');

        var me = this,
            vm = me.getViewModel(),
			comboStore=vm.getStore('numberTablePlacementStore')
            combo = me.lookupReference('numberOfPlacementSettingsRef'),
            value = combo ? combo.getValue() : undefined
        ;
		if( store.getCount()>0 && combo){
				comboStore.removeAll();
				for (var i = 0; i <= store.getCount(); i++) {
					 comboStore.insert(i, {id: i});
				}
				combo.setValue(value)

		}

    },
    onPlacementDataLoad: function (store) {
        console.log('onPlacementDataLoad', arguments);
    },

    onAddGoal: function (grid, btn) {

        var me = this,
            win = me.getView().down('#goalWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = Ext.create('QuickStart.model.casereview.Goal');

        win.show(btn);
        vm.set('current.goal', record);
        vm.set('current.goalAction', 'Add');
		vm.getStore('goalStore').add(record);
		form.reset();
		form.isValid();
    },
    onEditGoal: function (grid, btn, rec) {

        var me = this,
            win = me.getView().down('#goalWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = rec;

        win.show(btn);
        form.isValid();
        vm.set('current.goalEdited', record.getData());
        vm.set('current.goal', record);
        vm.set('current.goalAction', 'Edit');
    },
    onDeleteGoal: function (grid, btn, rec) {
        var me = this,
            vm = me.getViewModel(),
            store = grid.getStore();

        Ext.MessageBox.confirm('Confirm?', 'Are you sure do you want to remove this?', function (btn) {
            if (store.getCount() == 1) {
                me.setDeferMessage(vm, 'Goals', "This row cannot be deleted from table 5A1. Please click on the goal to edit.");
                return;
            }
            store.remove(rec);
            if (store.getCount() == 0) {
                me.updateCurrentGoals();
                var s = vm.get('caseReview.Permanency');
                s.CR_Goal_Collection = [];
                vm.set('caseReview.Permanency', s);
            }
        });

    },
    onSaveGoal: function (btn) {
        var me = this,
            win = btn.up('window'),
            form = win.down('form').getForm(),
            values = form.getValues(),
            vm = me.getViewModel(),
            record = vm.get('current.goal'),
            store = vm.getStore('goalStore'),
            data = record.getData()
        ;
        //    console.log(data);
        record.set('IsCurrentGoal', values.IsCurrentGoal === 1 ? 1 : 2);
        me.updateCurrentGoals();

		if(btn.type=='addnew'){
			var newrecord = Ext.create('QuickStart.model.casereview.Goal');
			vm.set('current.goal', newrecord);
			vm.set('current.goalAction', 'Add');
			vm.getStore('goalStore').add(newrecord);
			form.reset();
			form.isValid();
		}
		else{
			win.close();
		}
    },
    updateCurrentGoals: function () {
        var me = this,
            vm = me.getViewModel(),
            store = vm.getStore('goalStore');

        if (store.getCount() > 0) {
            var first = store.getAt(0);
            vm.set('caseReview.Goal1Code', first.get('GoalCode'));
            if (store.getCount() > 1) {
                var sec = store.getAt(1);
                vm.set('caseReview.Goal2Code', sec.get('GoalCode'));
            }
            else {
                vm.set('caseReview.Goal2Code', null);
            }
        }
        else {
            vm.set('caseReview.Goal1Code', null);
            vm.set('caseReview.Goal2Code', null);
        }
    },
    onGoalDataChanged: function (store) {
        // console.log('onGoalDataChanged', arguments);
        var me = this,
            vm = me.getViewModel(),
            combo = me.lookupReference('numberOfGoalSettingsRef'),
            value = combo ? combo.getValue() : undefined

        ;
        if (combo) {
            var comboStore = combo.getStore();
            comboStore.removeAll();
            for (var i = 0; i <= store.getCount(); i++) {
                comboStore.insert(i, {id: i});
            }
            combo.setValue(value)
        }
    },
    onGoalDataLoad: function (store) {
        console.log('onGoalDataChangeda', arguments);
    },
	onCancelPlacement: function (btn) {
		var me = this,
			vm = me.getViewModel(),
			record = vm.get('current.placement'),
		    edited = vm.get('current.placementEdited'),
			store = vm.getStore('placementStore');

		if (vm.get('current.placementAction') === 'Add')
			store.remove(record);
		else {
		    record.set(edited);
		}
		btn.up('window').close();
	},
	onCancelGoal: function (btn) {
		var me = this,
			vm = me.getViewModel(),
			record = vm.get('current.goal'),
		    edited = vm.get('current.goalEdited'),
			store = vm.getStore('goalStore');

		if (vm.get('current.goalAction') === 'Add')
			store.remove(record);
		else {
		    record.set(edited);
		}
		btn.up('window').close();
	}
});