/**
 * Created by kkora on 9/22/2017.
 */

Ext.define('QuickStart.view.mixins.Note', {
    extend: 'Ext.Mixin',

    requires: [
        'QuickStart.model.casereview.Note',
        'QuickStart.util.Global'
    ],
    onRespondNote: function (record, index, target, notepanel) {

        var me = this,
            win = me.getView().down('#noteWindow'),
            // notepanel = me.getView().down('notepanel'),
            outcomeCode = notepanel.getOutcomeCode(),
            itemCode = notepanel.getItemCode(),
            storeName = notepanel.getStoreName(),
            vm = me.getViewModel(),
            store = vm.getStore('noteStore'),
            count = store.getCount(),
            newRespondId = count - 100,
            newRecord = Ext.create('QuickStart.model.casereview.Note', {
                NoteID: record.get('NoteID'),
                NoteType: record.get('NoteType'),
                TempID: record.get('TempID'),
                //  ResponseID: newRespondId,
                IsResponse: true,
                LastModifiedUserID: QuickStart.util.Global.getUser().id,
                ReviewerType: vm.getReviewerTypeByUserId(QuickStart.util.Global.getUser().id),
                OutcomeCode: outcomeCode,
                ItemCode: itemCode
            })
        ;
        console.log(record.getData())
        vm.set('current.noteAction', 'Respond');
        vm.set('current.note', newRecord);
        win.down('noteform').show();
        win.show(target);
        win.hideSubject();
    },
    onCreateNote: function (btn) {

        var me = this,
            vm = me.getViewModel(),
            refs = me.getReferences(),
            caseContainer = refs.caseContainer,
            isCaseType = btn.type === 'CASE',
            win = me.getView().down('#noteWindow'),
            outcomeCode = null, itemCode = 1,
            store, storeName, record,
            count, newNoteId, newNoteId, notepanel, noteform

        ;

        store = vm.getStore('noteStore');
        notepanel = btn.up('notepanel');
        noteform = notepanel.down('noteform');
        outcomeCode = notepanel.getOutcomeCode();
        itemCode = notepanel.getItemCode();
        storeName = notepanel.getStoreName();

        count = store.getCount() || 0;
        newNoteId = count - 100;
        record = Ext.create('QuickStart.model.casereview.Note', {
            // NoteID: newNoteId,
            NoteType: notepanel.getNoteType(),
            TempID: newNoteId,
            OutcomeCode: outcomeCode,
            LastModifiedUserID: QuickStart.util.Global.getUser().id,
            ReviewerType: vm.getReviewerTypeByUserId(QuickStart.util.Global.getUser().id),
            ItemCode: itemCode
        });

        vm.set('current.noteAction', 'Add');
        vm.set('current.note', record);
       // noteform.show();
        win.down('noteform').show();        win.show(btn);        win.showSubject();
        if (vm.getStore(storeName).getCount() == 0)
            caseContainer.scrollBy(0, 200);

        // noteform.getForm().reset();
    },

    onResolvedNote: function (record, index) {

        record.set('IsResolved', record.get('IsResolved') === 1 ? 2 : 1);
    },
    onDeleteNote: function (record, index) {

        var vm = this.getViewModel(),
            store = vm.getStore('noteStore');
        if (store) {
            var records = store.queryRecords('NoteID', record.get('NoteID'));
            Ext.each(records, function (rec) {
                store.remove(rec);
            });
        }
    },
    onDeleteRespondNote: function (record, index) {

        var vm = this.getViewModel(),
            store = vm.getStore('noteStore');
        if (store)
            store.remove(record);

    },
    onEditNote: function (record, index, target) {

        var me = this,
            win = me.getView().down('#noteWindow'),
            vm = this.getViewModel()
        ;
        vm.set('current.noteAction', 'Edit');
        vm.set('current.note', record);
        win.down('noteform').show();
        win.show(target);
        win.showSubject();
    },
    onEditRespondNote: function (record, index, target) {
        var me = this,
            win = me.getView().down('#noteWindow'),
            vm = this.getViewModel()
        ;
        vm.set('current.noteAction', 'Edit');
        vm.set('current.note', record);
        win.down('noteform').show();
        win.show(target);
        win.hideSubject();

    },
    onCreateNoteOld: function (btn) {

        var me = this,
            vm = me.getViewModel(),
            isCaseType = btn.type === 'CASE',
            win = me.getView().down('#noteWindow'),
            outcomeCode = null, itemCode = 1,
            store, storeName, record,
            count, newNoteId, newNoteId, notepanel

        ;

        store = vm.getStore('noteStore');
        notepanel = btn.up('notepanel');
        outcomeCode = notepanel.getOutcomeCode();
        itemCode = notepanel.getItemCode();
        storeName = notepanel.getStoreName();

        count = store.getCount();
        newNoteId = count - 100;
        record = Ext.create('QuickStart.model.casereview.Note', {
            NoteID: newNoteId,
            OutcomeCode: outcomeCode,
            ItemCode: itemCode
        });

        vm.set('current.noteAction', 'Add');
        vm.set('current.note', record);
        win.show(btn);
        win.showSubject();
    },

    onSaveNote: function (btn) {
        var win = btn.up('window'),
            formpanel = btn.up('noteform'),
            form = formpanel.getForm(),
            values = form.getValues(),
            vm = this.getViewModel(),
            record = vm.get('current.note'),
            noteAction = vm.get('current.noteAction'),
            store = vm.getStore('noteStore'),
            user = QuickStart.util.Global.getUser() || {},
            reviewerType=vm.getReviewerTypeByUserId(user.id);
        // record.set('LastModifiedDate', new Date());
        record.set('LastModifiedUserID', user.id);
        record.set('ReviewerType', reviewerType);

        record.set('Name', user.name);
        //   record.set('Subject', values.Subject);
        // record.set('Description', values.Description);
        if (store) {
            if (noteAction === 'Add' || noteAction === 'Respond') {
                //Fixed by Ravi K on 2018-07-25
                //As per Janet G, CRS should not ask to resolve the QA notes, if entered by QA because OMS does not required to resolved QA notes.
                //Set the resolved in case of notes entered by other than Reviewer.
                if (reviewerType != 'Reviewer')
                    record.set('IsResolved', 1);
                record.set('LastModifiedDate', new Date());
                store.insert(0, record);
            }
        }
        record.commit();
        if (win)
            win.close();
        if (formpanel) {
            formpanel.hide();
        }
        // console.log(record.getData())

    },
    onSearchNote: function (btn) {
        console.log('onSearchNote')
        var me = this,
            vm = me.getViewModel(),
            toolbar = btn.up('toolbar'),
            notepanel = toolbar.up('caseqanotescontainer'),
            noteResolvedCombo = toolbar.down('#noteResolvedCombo'),
            noteItemNameCombo = toolbar.down('#noteItemNameCombo'),
            noteUserCombo = toolbar.down('#noteUserCombo'),
            resolved = noteResolvedCombo.getValue(),
            item = noteItemNameCombo.getValue(),
            user = noteUserCombo.getValue(),
            store = vm.getStore(notepanel.getNoteType() == 2 ? 'caseInterviewNoteStore' : 'caseNoteStore'),
            filters = []
        ;

        store.clearFilter();
        //   console.log(resolved, item, user)


        if (!Ext.isEmpty(resolved) && resolved != 0 && resolved != 'Any')
            filters.push({property: 'IsResolved', value: parseInt(resolved)});
        if (!Ext.isEmpty(item) && item != 0 && item != 'Any') {
            if (item === 1) {
                filters.push({property: 'Type', value: 'CASE'});
            }
            else {
                filters.push({property: 'ItemCode', value: item});
            }
        }

        filters.push({
            property: 'NoteType',
            value: 2,
            operator: notepanel.getNoteType() == 2 ? "=" : "!="
        });

        if (!Ext.isEmpty(user) && user != 0 && user != 'Any')
            filters.push({property: 'LastModifiedUserID', value: parseInt(user)});
        store.setFilters(filters);

    },
    onResetNote: function (btn) {
        var me = this,
            vm = this.getViewModel(),
            toolbar = btn.up('toolbar'),
            notepanel = toolbar.up('caseqanotescontainer'),
            noteResolvedCombo = toolbar.down('#noteResolvedCombo'),
            noteItemNameCombo = toolbar.down('#noteItemNameCombo'),
            noteUserCombo = toolbar.down('#noteUserCombo'),
            store = vm.getStore(notepanel.getNoteType() == 2 ? 'caseInterviewNoteStore' : 'caseNoteStore'),
            filters = []
        ;

        noteResolvedCombo.setValue();
        noteItemNameCombo.setValue();
        noteUserCombo.setValue();


        store.clearFilter();
        filters.push({property: 'Type', value: 'CASE'});
        filters.push({
            property: 'NoteType',
            value: 2,
            operator: notepanel.getNoteType() == 2 ? "=" : "!="
        });

        store.setFilters(filters);
    },
    onCancelClick: function (btn) {
        var win = btn.up('window'),
            formpanel = btn.up('noteform'),
            vm = this.getViewModel(),
            record = vm.get('current.note');
        record.reject();
        if (btn.up('window'))
            btn.up('window').close();
        else {
            btn.up('noteform').hide();
        }
    },
    getNotesByItemCode: function (notes, itemCode) {
        var cn = [], rn = [];
        if (notes) {
            var arr = notes.filter(function (item) {
                return item.ItemCode == itemCode;
            });
            //building notes

            Ext.each(arr, function (item) {

                // item.DataState = item.TempID > 0 ? 2 : 0;
                item.DataState = 0;

                item.TS_CR = item.LastModifiedDate;
                item.TS_UP = item.LastModifiedDate;
                item.ID_UP = item.LastModifiedUserID;
                item.ID_CR = item.LastModifiedUserID;

                //delete item.LastModifiedDate;
                //  delete item.LastModifiedUserID;
                // delete item.ItemCode;
                // delete item.ItemID;
                delete item.ItemName;
                delete item.Name;
                delete item.OutcomeCode;
                delete item.Time;
                delete item.Type;
                delete item.id;

                if (item.IsResponse == true) {
                    delete item.Subject;
                    delete item.IsResolved;
                    delete item.CaseReviewID;
                    item.DataState = 0;
                    rn.push(item)
                }
                else {
                    delete item.ResponseID;

                    if (itemCode == null)
                        item.CR_CaseNote_Response_Collection = [];
                    else
                        item.CR_Response_Collection = [];
                    cn.push(item)
                }
            });

            //building responnse
            Ext.each(cn, function (item) {
                if (itemCode == null)
                    item.CR_CaseNote_Response_Collection = [];
                else
                    item.CR_Response_Collection = [];

                var res = rn.filter(function (r) {
                    return item.TempID == r.TempID;
                });

                if (res && res.length > 0) {
                    if (itemCode == null)
                        item.CR_CaseNote_Response_Collection = res;
                    else
                        item.CR_Response_Collection = res;
                }
            });
        }
        return cn;
    },

    onNoteTabContainerRender: function (tabpanel) {

        if (!QuickStart.util.Global.permissions.allowInterviewNote())
            tabpanel.child('#caseInterviewNote').tab.hide();
    }

});