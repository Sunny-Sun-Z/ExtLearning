/**
 * Created by kkora on 1/24/2018.
 */
Ext.define('QuickStart.view.mixins.ExportImport', {
    extend: 'Ext.Mixin',

    onImport: function (data) {
        console.log('onCaseImport')

    },
    onExport: function (id, name, view) {
        var myMask = new Ext.LoadMask({msg: 'Please wait...', target: view});

        myMask.show();

        Ext.Ajax.request({
            url: QuickStart.util.Global.getApi() + 'setting/export',
            method: 'GET',
            params: {
                userID: QuickStart.util.Global.getUser().id,
                Id: id,
                Name: name
            },
            timeout: 1000 * 60 * 10, //10 minutes
            success: function (response, opts) {
                myMask.hide();

                var result = Ext.decode(response.responseText);
                if (result != null) {
                    QuickStart.util.Global.showMessage(result.message, null, 400);
                }
            },
            failure: function (response, opts) {
                myMask.hide();
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });
    },
    onExportMultiple: function (list, view) {

        var myMask = new Ext.LoadMask({msg: 'Please wait...', target: view});

        myMask.show();

        Ext.Ajax.request({
            url: QuickStart.util.Global.getApi() + 'setting/exportmultiple',
            method: 'POST',
            jsonData: list,
            timeout: 1000 * 60 * 10, //10 minutes
            success: function (response, opts) {
                myMask.hide();

                var result = Ext.decode(response.responseText);
                if (result != null) {
                    QuickStart.util.Global.showMessage(result.message, null, '75%');
                }
            },
            failure: function (response, opts) {
                myMask.hide();
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });
    },

    download: function (config) {
        config = config || {};
        var url = config.url,
            method = config.method || 'POST',// Either GET or POST. Default is POST.
            params = config.params || {};

        var form = Ext.create('Ext.form.Panel', {
            standardSubmit: true,
            url: url,
            method: method
        });

        // Call the submit to begin the file download.
        form.submit({
            target: '_blank', // Avoids leaving the page.
            params: params,
            timeout: 1000 * 60, //1 minutes
            // waitMsg: 'Downloading Case file...',
            headers: {'Content-Type': 'text/plain'}
        });

        // Clean-up the form after 100 milliseconds.
        // Once the submit is called, the browser does not care anymore with the form object.
        Ext.defer(function () {
            form.close();
        }, 100);

    },
    downloadFile: function (url) {
       // console.log(url)
        var body = Ext.getBody(),
            frame=Ext.get('hidden-iframe');

        if(frame){			frame.destroy();        }
        try {
			frame = body.createChild({
				tag: 'iframe',
				cls: 'x-hidden',
				id: 'hidden-iframe',
				name: 'iframe',
				src:url
			});
        }
        catch (e) {
            console.log(e);
        }


    }
});