/**
 * Created by kkora on 9/22/2017.
 */
Ext.define('QuickStart.view.mixins.FaceSheet', {
    extend: 'Ext.Mixin',

    onAddChildDemographic: function (grid, btn) {

        var me = this,
            win = me.getView().down('#childDemographicWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = Ext.create('QuickStart.model.casereview.ChildDemographic');

        win.show(btn);
        vm.set('current.childDemographic', record);
        vm.set('current.childDemographicAction', 'Add');
		vm.getStore('childDemographicStore').add(record);
		form.reset();
		form.isValid();
    },
    onEditChildDemographic: function (grid, btn, rec) {

        var me = this,
            win = me.getView().down('#childDemographicWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            raceCodeChecks = me.lookupReference('childDemographicRaceCodes'),
            record = rec;

        // form.reset();
        win.show(btn);
        form.isValid();
        vm.set('current.childDemographic', record);
		vm.set('current.childDemographicEdited', record.getData());
		raceCodeChecks.setValue({RaceCode: record.get('RaceCodes')});
        vm.set('current.childDemographicAction', 'Edit');
    },
    onDeleteChildDemographic: function (grid, btn, rec) {
        var me = this,
            vm = me.getViewModel(),
            store = grid.getStore()
        ;
        Ext.MessageBox.confirm('Confirm?', 'Are you sure do you want to remove this?', function (btn) {

            if (btn === 'yes') {

                if (store.getCount() == 1) {
                    me.setDeferMessage(vm, 'ChildDemographics', "This row cannot be deleted from table G1. Please click on the child's name to edit.");
                    return;
                }
                else if (me.hasChildReferenceInReportTable(rec.get('ChildDemographicID'))) {
                    me.setDeferMessage(vm, 'ChildDemographics', "Child cannot be deleted because this child is referenced in item 1 table 1A1.");
                    return;
                }
                else if (me.hasChildReferenceInItem('Item12aParticipantChild', rec.get('ChildDemographicID'))) {
                    me.setDeferMessage(vm, 'ChildDemographics', "Child cannot be deleted because this child is referenced in case applicability for sub-item 12A");
                    return;
                }
                else if (me.hasChildReferenceInItem('Item13ParticipantChild', rec.get('ChildDemographicID'))) {
                    me.setDeferMessage(vm, 'ChildDemographics', "Child cannot be deleted because this child is referenced in case applicability for item 13");
                    return;
                }
                else if (me.hasChildReferenceInItem('Item16ParticipantChild', rec.get('ChildDemographicID'))) {
                    me.setDeferMessage(vm, 'ChildDemographics', "Child cannot be deleted because this child is referenced in case applicability for item 16");
                    return;
                }
                else if (me.hasChildReferenceInItem('Item17ParticipantChild', rec.get('ChildDemographicID'))) {
                    me.setDeferMessage(vm, 'ChildDemographics', "Child cannot be deleted because this child is referenced in case applicability for item 17");
                    return;
                }
                else if (me.hasChildReferenceInItem('Item18ParticipantChild', rec.get('ChildDemographicID'))) {
                    me.setDeferMessage(vm, 'ChildDemographics', "Child cannot be deleted because this child is referenced in case applicability for item 18");
                    return;
                }

                store.remove(rec);
                if (store.getCount() == 0) {
                    var fs = vm.get('caseReview.FaceSheet');
                    fs.CR_ChildDemographic_Collection = [];
                    vm.set('caseReview.FaceSheet', fs);
                }
            }
        });

    },
    onSaveChildDemographic: function (btn) {
        var me = this,
            win = btn.up('window'),
            form = win.down('form').getForm(),
            values = form.getValues(),
            vm = me.getViewModel(),
            record = vm.get('current.childDemographic'),
            data = record.getData(),
            raceCodeObjects = [],
            raceCodes = [],
            ageValue = ''
        ;

        if (vm.get('hasSingleDemographicTargetChildRow') &&  values.IsTargetChild === 1 && vm.get('current.childDemographicAction') !='Edit' ) {
			QuickStart.util.Global.showErrors('For table G1, you enter more than one target child. Please ensure that only one child has been identified as the target child.');
		    return;
        }
        if (Ext.isArray(values.RaceCode)) {
            Ext.each(values.RaceCode, function (code) {
                raceCodeObjects.push({RaceCode: code});
                raceCodes.push(code);
            });
        }
        else {
            raceCodeObjects.push({RaceCode: values.RaceCode});
            raceCodes.push(values.RaceCode);
        }

        if (!Ext.isEmpty(vm.get('caseReview.ReviewCompleted'))) {
            var dob = record.get("DateOfBirth"),
                reviewCompletedDate = new Date(vm.get('caseReview.ReviewCompleted')),
                age = me.getAgeInYmd(dob, reviewCompletedDate);

            if (Ext.isEmpty(age)) {
                ageValue = "0 years 0 months";
            } else {
                ageValue = age.Year + "y " + age.Month + "m " + age.Day + "d";
            }
        }

        record.set("AgeObj", age);
        record.set("Age", ageValue);
        record.set('IsTargetChild', values.IsTargetChild === 1 ? 1 : 2);
        record.set('IsInterviewed', values.IsInterviewed === 1 ? 1 : 2);
        record.set('CR_ChildRace_Collection', raceCodeObjects);
        record.set('RaceCodes', raceCodes);
       // if (vm.get('current.childDemographicAction') === 'Add')
         //   vm.getStore('childDemographicStore').add(record);

        vm.set('caseReview.TS_CR', new Date());

        if(btn.type=='addnew'){
			var newrecord = Ext.create('QuickStart.model.casereview.ChildDemographic');
			vm.set('current.childDemographic', newrecord);
			vm.set('current.childDemographicAction', 'Add');
			vm.getStore('childDemographicStore').add(newrecord);
			form.reset();
			form.isValid();
        }
        else{
			win.close();
        }
    },

    onAddCaseParticipant: function (grid, btn) {

        var me = this,
            win = me.getView().down('#caseParticipantWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = Ext.create('QuickStart.model.casereview.CaseParticipant');

        win.show(btn);
        vm.set('current.caseParticipant', record);
        vm.set('current.caseParticipantAction', 'Add');
		vm.getStore('caseParticipantStore').add(record);
		form.reset();
		form.isValid();
    },
    onEditCaseParticipant: function (grid, btn, rec) {
        var me = this,
            win = me.getView().down('#caseParticipantWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = rec;

        //   form.reset();
        win.show(btn);
        form.isValid();
		vm.set('current.caseParticipantEdited', record.getData());
		vm.set('current.caseParticipant', record);
		vm.set('current.caseParticipantAction', 'Edit');
    },
    onDeleteCaseParticipant: function (grid, btn, rec) {
        var me = this,
            vm = me.getViewModel(),
            store = grid.getStore()
        ;
        Ext.MessageBox.confirm('Confirm?', 'Are you sure do you want to remove this?', function (btn) {

            if (btn === 'yes') {
                var id = rec.get('CaseParticipantID');
                if (store.getCount() == 1) {
                    me.setDeferMessage(vm, 'CaseParticipants', "This row cannot be deleted from table G2. Please click on the participant's name to edit");
                    return;
                }
                else if (me.hasChildReferenceInItem('Item8ParticipantMother', id) || me.hasChildReferenceInItem('Item8ParticipantFather', id)) {
                    me.setDeferMessage(vm, 'CaseParticipants', "Participant cannot be deleted because this participant is referenced in case applicability for item 8.");
                    return;
                }
                else if (me.hasChildReferenceInItem('Item11ParticipantMother', id) || me.hasChildReferenceInItem('Item11ParticipantFather', id)) {
                    me.setDeferMessage(vm, 'CaseParticipants', "Participant cannot be deleted because this participant is referenced in case applicability for item 11.");
                    return;
                }
                else if (me.hasChildReferenceInItem('Item12bParticipantMother', id) || me.hasChildReferenceInItem('Item12bParticipantFather', id)) {
                    me.setDeferMessage(vm, 'CaseParticipants', "Participant cannot be deleted because this participant is referenced in case applicability for item 12B.");
                    return;
                }
                else if (me.hasChildReferenceInItem('Item13ParticipantMother', id) || me.hasChildReferenceInItem('Item13ParticipantFather', id)) {
                    me.setDeferMessage(vm, 'CaseParticipants', "Participant cannot be deleted because this participant is referenced in case applicability for item 13.");
                    return;
                }
                else if (me.hasChildReferenceInItem('Item15ParticipantMother', id) || me.hasChildReferenceInItem('Item15ParticipantFather', id)) {
                    me.setDeferMessage(vm, 'CaseParticipants', "Participant cannot be deleted because this participant is referenced in case applicability for item 15.");
                    return;
                }

                store.remove(rec);
                if (store.getCount() == 0) {
                    var fs = vm.get('caseReview.FaceSheet');
                    fs.CR_CaseParticipant_Collection = [];
                    vm.set('caseReview.FaceSheet', fs);
                }
            }
        });
    },
    onSaveCaseParticipant: function (btn) {
        var me = this,
            win = btn.up('window'),
            form = win.down('form').getForm(),
            values = form.getValues(),
            vm = me.getViewModel(),
            record = vm.get('current.caseParticipant'),
            id = record.get('CaseParticipantID');
        ;
        record.set('IsInterviewed', values.IsInterviewed === 1 ? 1 : 2);

        if (vm.get('current.caseParticipantAction') === 'Add') {
         //   vm.getStore('caseParticipantStore').add(record);
        }
        else if (vm.get('current.caseParticipantAction') === 'Edit') {
            var msg=null;
            if (record.isModified('RoleCode') && (record.modified.RoleCode == 1 || record.modified.RoleCode == 2 || record.modified.RoleCode == 6)) {
                if (me.hasChildReferenceInItem('Item8ParticipantMother', id) || me.hasChildReferenceInItem('Item8ParticipantFather', id)) {
                    msg= "Participant's Role cannot be changed because this participant is referenced in case applicability for item 8.";
                }
                else if (me.hasChildReferenceInItem('Item11ParticipantMother', id) || me.hasChildReferenceInItem('Item11ParticipantFather', id)) {
                    msg="Participant's Role cannot be changed because this participant is referenced in case applicability for item 11.";
                }
                else if (me.hasChildReferenceInItem('Item12bParticipantMother', id) || me.hasChildReferenceInItem('Item12bParticipantFather', id)) {
                    msg= "Participant's Role cannot be changed because this participant is referenced in case applicability for item 12B.";
                }
                else if (me.hasChildReferenceInItem('Item13ParticipantMother', id) || me.hasChildReferenceInItem('Item13ParticipantFather', id)) {
                    msg= "Participant's Role cannot be changed because this participant is referenced in case applicability for item 13.";
                }
                else if (me.hasChildReferenceInItem('Item15ParticipantMother', id) || me.hasChildReferenceInItem('Item15ParticipantFather', id)) {
                    msg= "Participant's Role cannot be changed because this participant is referenced in case applicability for item 15.";
                }
            }
            if(!Ext.isEmpty(msg)){
                me.setDeferMessage(vm, 'CaseParticipants', msg);
                record.reject();
            }
        }
		if(btn.type=='addnew'){
			var newrecord = Ext.create('QuickStart.model.casereview.CaseParticipant');
			vm.set('current.caseParticipant', newrecord);
			vm.set('current.caseParticipantAction', 'Add');
			vm.getStore('caseParticipantStore').add(newrecord);
			form.reset();
			form.isValid();
		}
		else{
			win.close();
		}
    },
    onCaseParticipantDataChanged: function (store) {
        var me = this,
            vm = me.getViewModel();
		vm.set('caseReview.TS_CR', new Date());

    },
    onChildDemographicDataChanged: function (store) {
        var me = this,
            vm = me.getViewModel();

        vm.set('caseReview.TS_CR', new Date());
    },
    hasChildReferenceInReportTable: function (childId) {
        var me = this,
            vm = me.getViewModel(),
            safetyReportStore = vm.getStore('safetyReportStore'),
            safetyReports = vm.get('caseReview.Safety.CR_SafetyReport_Collection'),
            rows = false;
        if (safetyReportStore && safetyReportStore.getCount() > 0) {
            rows = Ext.Array.pluck(safetyReportStore.getRange(), 'data').filter(function (item) {
                return item.ChildDemographicID == childId;
            }).length > 0;
        }
        else {
            if (safetyReports && safetyReports.length > 0) {
                rows = safetyReports.filter(function (item) {
                    return item.ChildDemographicID == childId;
                }).length > 0;
            }
        }
        return rows;
    },
    hasChildReferenceInItem: function (itemName, childId) {

        var me = this,
            vm = me.getViewModel(),
            participants = vm.get('caseReview.' + itemName),
            rows = false;
        console.log('participants', participants)
        rows = participants.filter(function (item) {
            return item == childId;
        }).length > 0;

        return rows;
    },
    //property = component itemid
    setDeferMessage: function (vm, property, message, delay) {
        vm.set('error.enabledDelayedMsg', true);
        vm.set('error.' + property, message);
        Ext.defer(function () {
            vm.set('error.' + property, null);
            vm.set('error.enabledDelayedMsg', false);
            vm.set('caseReview.TS_CR', new Date());
        }, delay || QuickStart.util.Global.getDelayed(), this);
    },
    onCancelCaseParticipant: function (btn) {
		var me = this,
			vm = me.getViewModel(),
			record = vm.get('current.caseParticipant'),
			edited = vm.get('current.caseParticipantEdited'),
			store = vm.getStore('caseParticipantStore');
       
		if (vm.get('current.caseParticipantAction') === 'Add')
			store.remove(record);
		else
        {
          //  console.log(edited, record.getData())
			record.set(edited);
        }
		btn.up('window').close();
	},
	onCancelChildDemographic: function (btn) {
		var me = this,
			vm = me.getViewModel(),
			record = vm.get('current.childDemographic'),
			edited = vm.get('current.childDemographicEdited'),
			store = vm.getStore('childDemographicStore');

	  	if (vm.get('current.childDemographicAction') === 'Add')
			store.remove(record);
		else
		{
			//console.log(edited, record.getData())
			record.set(edited);
		}
		btn.up('window').close();
	}
});