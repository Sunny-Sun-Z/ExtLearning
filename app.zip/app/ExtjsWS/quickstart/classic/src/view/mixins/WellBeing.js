/**
 * Created by kkora on 10/26/2017.
 */
Ext.define('QuickStart.view.mixins.WellBeing', {
    extend: 'Ext.Mixin',
    onAddMentalHealth: function (grid, btn) {

        var me = this,
            win = me.getView().down('#mentalHealthWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = Ext.create('QuickStart.model.casereview.HealthNeed');

        win.show(btn);
        vm.set('current.mentalHealth', record);
        vm.set('current.mentalHealthAction', 'Add');
        vm.getStore('mentalHealthStore').add(record);
        form.reset();
        form.isValid();
    },
    onEditMentalHealth: function (grid, btn, rec) {

        var me = this,
            win = me.getView().down('#mentalHealthWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = rec;

        // console.log('onEditMentalHealth', rec.getData());
        win.show(btn);
        form.isValid();
        vm.set('current.mentalHealthEdited', record.getData());
        vm.set('current.mentalHealth', record);
        vm.set('current.mentalHealthAction', 'Edit');
    },
    onDeleteMentalHealth: function (grid, btn, rec) {
        var me = this,
            vm = me.getViewModel(),
            store = grid.getStore()
        ;
        Ext.MessageBox.confirm('Confirm?', 'Are you sure do you want to remove this?', function (btn) {
            if (btn === 'yes') {

                if (store.getCount() == 1) {
                    me.setDeferMessage(vm, 'MentalBehavirolHealths', "This row cannot be deleted from table 18A1. Please click on the mental/behavioral health need identified to edit. ");
                    return;
                }

                store.remove(rec);

                if (store.getCount() == 0) {
                    var s = vm.get('caseReview.WellBeing');
                    //remove MentalBehavirolHealths record from CR_Health_Collection (HealthNeedCode=2 is for MentalBehavirolHealths )
                    s.CR_Health_Collection = s.CR_Health_Collection.filter(function (value) { return value.HealthNeedCode==1; });
                    vm.set('caseReview.WellBeing', s);
                }
            }
        });
    },
    onSaveMentalHealth: function (btn) {
        var me = this,
            win = btn.up('window'),
            form = win.down('form').getForm(),
            values = form.getValues(),
            vm = me.getViewModel(),
            record = vm.get('current.mentalHealth')
        ;
        record.set('HealthNeedCode', 2);

		if(btn.type=='addnew'){
			var newrecord = Ext.create('QuickStart.model.casereview.HealthNeed');
			vm.set('current.mentalHealth', newrecord);
			vm.set('current.mentalHealthAction', 'Add');
			vm.getStore('mentalHealthStore').add(newrecord);
			form.reset();
			form.isValid();
		}
		else{
			win.close();
		}
    },

    onAddPhysicalDentalHealth: function (grid, btn) {

        var me = this,
            win = me.getView().down('#physicalDentalHealthWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = Ext.create('QuickStart.model.casereview.HealthNeed');

        win.show(btn);
        vm.set('current.physicalDentalHealth', record);
        vm.set('current.physicalDentalHealthAction', 'Add');
        vm.getStore('physicalDentalHealthStore').add(record);
        form.reset();
        form.isValid();
    },
    onEditPhysicalDentalHealth: function (grid, btn, rec) {

        var me = this,
            win = me.getView().down('#physicalDentalHealthWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = rec;

        // console.log('onEditPhysicalDentalHealth', rec.getData());
        win.show(btn);
        form.isValid();
        vm.set('current.physicalDentalHealthEdited', record.getData());
        vm.set('current.physicalDentalHealth', record);
        vm.set('current.physicalDentalHealthAction', 'Edit');
    },
    onDeletePhysicalDentalHealth: function (grid, btn, rec) {
        Ext.MessageBox.confirm('Confirm?', 'Are you sure do you want to remove this?', function (btn) {
            if (btn === 'yes') {
                grid.getStore().remove(rec);
            }
        });
    },
    onSavePhysicalDentalHealth: function (btn) {
        var me = this,
            win = btn.up('window'),
			form = win.down('form').getForm(),
			vm = me.getViewModel(),
            record = vm.get('current.physicalDentalHealth')
        ;
        record.set('HealthNeedCode', 1);
		if(btn.type=='addnew'){
			var newrecord = Ext.create('QuickStart.model.casereview.HealthNeed');
			vm.set('current.physicalDentalHealth', newrecord);
			vm.set('current.physicalDentalHealthAction', 'Add');
			vm.getStore('physicalDentalHealthStore').add(newrecord);
			form.reset();
			form.isValid();
		}
		else{
			win.close();
		}
    },

    onAddEducation: function (grid, btn) {

        var me = this,
            win = me.getView().down('#educationWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = Ext.create('QuickStart.model.casereview.Education');

        win.show(btn);
        vm.set('current.education', record);
        vm.set('current.educationAction', 'Add');
        vm.getStore('educationStore').add(record);
        form.reset();
        form.isValid();
    },
    onEditEducation: function (grid, btn, rec) {

        var me = this,
            win = me.getView().down('#educationWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = rec;

        // console.log('onEditEducation', rec.getData());
        win.show(btn);
        form.isValid();
        vm.set('current.educationEdited', record.getData());
        vm.set('current.education', record);
        vm.set('current.educationAction', 'Edit');
    },
    onDeleteEducation: function (grid, btn, rec) {
        Ext.MessageBox.confirm('Confirm?', 'Are you sure do you want to remove this?', function (btn) {
            if (btn === 'yes') {
                grid.getStore().remove(rec);
            }
        });
    },
    onSaveEducation: function (btn) {
        var me = this,
            win = btn.up('window'),
			form = win.down('form').getForm(),
			vm = me.getViewModel(),
            record = vm.get('current.education')
        ;

		if(btn.type=='addnew'){
			var newrecord = Ext.create('QuickStart.model.casereview.Education');
			vm.set('current.education', newrecord);
			vm.set('current.educationAction', 'Add');
			vm.getStore('educationStore').add(newrecord);
			form.reset();
			form.isValid();
		}
		else{
			win.close();
		}
    },
    onCancelEducation: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            record = vm.get('current.education'),
            edited = vm.get('current.educationEdited'),
            store = vm.getStore('educationStore');

        if (vm.get('current.educationAction') === 'Add')
            store.remove(record);
        else {
            record.set(edited);
        }
        btn.up('window').close();
    },
    onCancelPhysicalDentalHealth: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            record = vm.get('current.physicalDentalHealth'),
            edited = vm.get('current.physicalDentalHealthEdited'),
            store = vm.getStore('physicalDentalHealthStore');

        if (vm.get('current.physicalDentalHealthAction') === 'Add')
            store.remove(record);
        else {
            record.set(edited);
        }
        btn.up('window').close();
    },
    onCancelMentalHealth: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            record = vm.get('current.mentalHealth'),
            edited = vm.get('current.mentalHealthEdited'),
            store = vm.getStore('mentalHealthStore');

        if (vm.get('current.mentalHealthAction') === 'Add')
            store.remove(record);
        else {
            record.set(edited);
        }
        btn.up('window').close();
    }


});