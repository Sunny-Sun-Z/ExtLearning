/**
 * Created by kkora on 10/11/2017.
 */

Ext.define('QuickStart.view.mixins.Safety', {
	extend: 'Ext.Mixin',
	onAddSafetyReport: function (grid, btn) {

		var me = this,
			win = me.getView().down('#safetyReportWindow'),
			vm = me.getViewModel(),
			form = win.down('form').getForm(),
			record = Ext.create('QuickStart.model.casereview.SafetyReport');

		win.show(btn);
		vm.set('current.safetyReport', record);
		vm.set('current.safetyReportAction', 'Add');
		vm.getStore('safetyReportStore').add(record);
		form.reset();
		form.isValid();


	},
	onEditSafetyReport: function (grid, btn, rec) {

		var me = this,
			win = me.getView().down('#safetyReportWindow'),
			vm = me.getViewModel(),
			form = win.down('form').getForm(),
			safetyReportAllegationCodeChecks = me.lookupReference('safetyReportAllegationCode'),
			record = rec;

		//  console.log('onEditSafetyReport', rec.getData());
		win.show(btn);
		form.isValid();
		vm.set('current.safetyReportEdited', record.getData());
		vm.set('current.safetyReport', record);
		safetyReportAllegationCodeChecks.setValue({SafetyReportAllegationCode: record.get('SafetyReportAllegationCode')});
		vm.set('current.safetyReportAction', 'Edit');
	},
	onDeleteSafetyReport: function (grid, btn, rec) {
		var me = this,
			vm = me.getViewModel(),
			store = grid.getStore();
		Ext.MessageBox.confirm('Confirm?', 'Are you sure do you want to remove this?', function (btn) {
			if (btn === 'yes') {
				if (store.getCount() == 1) {
					me.setDeferMessage(vm, 'SafetyReports', "This row cannot be deleted from table 1A1. Please double click on the report row to edit or edit buuton. ");
					return;
				}
				else if (me.hasChildReferenceInItem('Item8ParticipantMother', id) || me.hasChildReferenceInItem('Item8ParticipantFather', id)) {
					me.setDeferMessage(vm, 'SafetyReports', "Participant cannot be deleted because this participant is referenced in case applicability for item 8.");
					return;
				}

				store.remove(rec);

				if (store.getCount() == 0) {
					var s = vm.get('caseReview.Safety');
					s.CR_SafetyReport_Collection = [];
					vm.set('caseReview.Safety', s);
				}
			}
		});
	},
	onSaveSafetyReport: function (btn) {
		var me = this,
			win = btn.up('window'),
			form = win.down('form').getForm(),
			values = form.getValues(),
			vm = me.getViewModel(),
			record = vm.get('current.safetyReport'),
			data = record.getData(),
			allegationObjects = [],
			allegationCodes = []
		;
		//  console.log(data);

		if (Ext.isArray(values.SafetyReportAllegationCode)) {
			Ext.each(values.SafetyReportAllegationCode, function (code) {
				allegationObjects.push({SafetyReportAllegationCode: code});
				allegationCodes.push(code);
			});
		}
		else {
			allegationObjects.push({SafetyReportAllegationCode: values.SafetyReportAllegationCode});
			allegationCodes.push(values.SafetyReportAllegationCode);
		}
		var otherExist = allegationCodes.filter(function (item) {
			return item == 14;
		}).length > 0;
		if (!otherExist) {
			record.set('AllegationOther', null);
		}
		if (values.PerpetratorChildRelationshipCode != 7) {
			record.set('PerpetratorChildRelationshipOther', null);
		}

		record.set('CR_SafetyReport_Allegation_Collection', allegationObjects);
		record.set('SafetyReportAllegationCode', allegationCodes);
		record.set('IsAssigned', values.IsAssigned === 1 ? 1 : 2);
		record.set('IsInitiated', values.IsInitiated === 1 ? 1 : 2);
		record.set('IsFaceToFaceContact', values.IsFaceToFaceContact === 1 ? 1 : 2);

		if (values.IsAssigned == 1) record.set('DateAssessmentAssigned', null);
		if (values.IsInitiated == 1) record.set('DateAssessmentInitiated', null);
		if (values.IsFaceToFaceContact == 1) record.set('DateFaceToFaceContact', null);

		if (btn.type == 'addnew') {
			var newrecord = Ext.create('QuickStart.model.casereview.SafetyReport');
			vm.set('current.safetyReport', newrecord);
			vm.set('current.safetyReportAction', 'Add');
			vm.getStore('safetyReportStore').add(newrecord);
			form.reset();
			form.isValid();
		}
		else {
			win.close();
		}
	},
	onSafetyReportDataChanged: function (store) {
		//  console.log('onSafetyReportDataChangeda', arguments);
		var me = this,
			vm = me.getViewModel(),
			numberTableStore = vm.getStore('numberTableStore'),
			reportsNotInAccordanceCombo = me.lookupReference('reportsNotInAccordance'),
			faceToFaceReportsNotInAccordanceCombo = me.lookupReference('faceToFaceReportsNotInAccordance'),
			reportsNotInAccordanceValue = reportsNotInAccordanceCombo ? reportsNotInAccordanceCombo.getValue() : undefined,
			faceToFaceReportsNotInAccordanceValue = faceToFaceReportsNotInAccordanceCombo ? faceToFaceReportsNotInAccordanceCombo.getValue() : undefined

		;

		numberTableStore.removeAll();
		for (var i = 0; i <= store.getCount(); i++) {
			numberTableStore.insert(i, {id: i});
		}
		if (reportsNotInAccordanceCombo)
			reportsNotInAccordanceCombo.setValue(reportsNotInAccordanceValue);
		if (faceToFaceReportsNotInAccordanceCombo)
			faceToFaceReportsNotInAccordanceCombo.setValue(faceToFaceReportsNotInAccordanceValue);

		vm.set('caseReview.TS_CR', new Date());
	},
	onSafetyReportDataLoad: function (store) {
		console.log('onSafetyReportDataChangeda', arguments);

	},
	rendererChildDemographic: function (val, meta, rec) {

		var me = this,
			vm = me.getViewModel(),
			store = vm.getStore('childDemographicStore'),
			index = store.find('ChildDemographicID', val, 0, false, true, true),//(prop,value, start, anymatch, caseSensitive, exactmatch)
			name = val
		;
		if (index > -1) {
			var record = store.getAt(index);
			name = record.get('Name') + ' ' + record.get('Age');
		}
		return name;
	},
	onCancelSafetyReport: function (btn) {
		var me = this,
			vm = me.getViewModel(),
			record = vm.get('current.safetyReport'),
			edited = vm.get('current.safetyReportEdited'),
			store = vm.getStore('safetyReportStore');

		if (vm.get('current.safetyReportAction') === 'Add')
			store.remove(record);
		else {
			record.set(edited);
		}
		btn.up('window').close();
	}
});