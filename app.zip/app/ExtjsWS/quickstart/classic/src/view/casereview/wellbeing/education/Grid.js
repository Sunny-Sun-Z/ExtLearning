/**
 * Created by kkora on 9/8/2017.
 */

Ext.define('QuickStart.view.casereview.wellbeing.education.Grid', {
    extend: 'QuickStart.view.common.CrudGrid',
    xtype: 'educationgrid',

    columns: [
        {
            flex: 1,
            text: 'Education Needs',
            dataIndex: 'Needs',
            cellWrap : true
         },
         {
            flex: 1,
            text: 'Services Provided',
            dataIndex: 'ServicesProvided',
            cellWrap: true
         },
        {
            flex: 1,
            text: 'Services Needed But Not Provided',
            dataIndex: 'ServicesNeededNotProvided',
            cellWrap: true
        }
    ],
    getValue: function () {

        var me=this,
            store = this.getStore(),
            modifiedRecords = store.getModifiedRecords(),
            records = [];

        Ext.each(modifiedRecords, function (rec) {
            var data = rec.getData();
            delete data.id;
            data.DataState = me.dataState.Added;
            records.push(data);
        });
        return records;
    }

});