/**
 * Created by kkora on 10/12/2017.
 */
Ext.define('QuickStart.view.casereview.items.Item12a', {
    extend: 'QuickStart.view.common.BaseItem',
    xtype: 'item12acontainer',

    requires: [
        'Ext.form.CheckboxGroup'
    ],

    routeId: 'item12a',
    items: [
        {
            title: 'Sub-Item 12A: Needs Assessment and Services to Children',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.item12a(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [{
                xtype: 'component',
                html: '<strong> Item 12 Applicable Cases:</strong><br/>' +
                '<ul><li>All cases are applicable for an assessment of this sub-item</li></ul>'
            },
                {
                    xtype: 'fieldcontainer',
                    labelAlign: 'top',
                    fieldLabel: 'For in home services cases, indicate the name(s) of the child(ren) who were included in the assessment',
                    layout: 'hbox',
                    defaults: {
                        xtype: 'checkboxgroup', disabledCls: 'disable-item',
                        flex: 1,
                        columns: 1,
                        labelWidth: 75,
                        vertical: true,
                        items: [{}],
                        listeners: {
                            change: 'onItemParticipantChanged'
                        }
                    },
                    bind: {
                        hidden: '{isFosterCareCase}'
                    },
                    items: [{
                        defaults: {name: 'Item12aParticipantChild'},
                        name: 'Item12aParticipantChild',
                        itemId: 'item12aParticipantChild'
                    }]
                },
                {
                    xtype: 'narrativefield',
                    bind: '{caseReview.Item12aComments}'
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.Item12aIsApplicable==""}',
                        html: '{error.Item12aIsApplicable}'
                    }
                }]
        },
        {
            title: 'Question 12A1',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question12a1(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [
                {
                    xtype: 'yesnoradiogroup',
                    name: 'IsComprehensiveAssessementConducted',
                    bind: '{isComprehensiveAssessementConducted}',
                    fieldLabel: QuickStart.util.Resources.questions.wellbeing.question12A1()
                }, {
                    xtype: 'yesnonarrativefield',
                    bind: {
                        value: '{caseReview.ComprehensiveAssessmentExplained}',
                        disabled: '{caseReview.IsComprehensiveAssessementConducted != 2}'
                    }
                }]
        },
        {
            title: 'Question 12A2',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question12a2(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [
                {
                    xtype: 'yesnonaradiogroup',
                    name: 'IsAppropriateServicesProvided',
                    bind: '{isAppropriateServicesProvided}',
                    fieldLabel: QuickStart.util.Resources.questions.wellbeing.question12A2()
                }, {
                    xtype: 'yesnonarrativefield',
                    bind: {
                        value: '{caseReview.AppropriateServicesProvidedExplained}',
                        disabled: '{caseReview.IsAppropriateServicesProvided != 2}'
                    }
                }]
        },
        {
            title: 'Sub Item 12A Rating Criteria',
            xtype: 'rating',
            itemId: 'rating12a',
            bind: {
				disabled: '{disabledItem}',
				rating: '{caseReview.Item12a}'
            },
            text: QuickStart.util.Resources.instructions.wellbeing.rating.item12a()
        },
        {
            title: 'Sub Item 12A - QA Notes',
            xtype: 'notepanel',
            itemId: 'item12aNotePanel',
            noteType: 1,
            itemCode: 14,
            outcomeCode: 5,
            storeName: 'item12aNoteStore',
            margin: '0 20 20 0',
            bind: {
                disabled: '{disabledNotes}'
            }
        },
        {
            bind: {
                hidden: '{!allowedInterviewNote}',
                disabled: '{disabledNotes}'
            },
            title: 'Sub Item 12A - Interview Notes',
            xtype: 'notepanel',
            noteType: 2,
            itemCode: 14,
            outcomeCode: 5,
            storeName: 'item12aInterviewNoteStore',
            margin: '0 20 20 0'
        }
    ],
    listeners: {
        afterrender: 'onAfterRenderItem12a'
    }
});