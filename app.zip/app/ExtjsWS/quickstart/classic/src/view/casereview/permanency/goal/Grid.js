/**
 * Created by kkora on 9/8/2017.
 */
Ext.define('QuickStart.view.casereview.permanency.goal.Grid', {
    extend: 'QuickStart.view.common.CrudGrid',
    xtype: 'goalgrid',

    columns: [

        {
            flex: 1,
            text: 'Permanency Goal',
            dataIndex: 'GoalCode',
            cellWrap : true,
            renderer: 'rendererPermanencyGoal1'
        },
        {
            flex: 1,
            text: 'Date Established',
            dataIndex: 'DateEstablished',
            formatter: 'date("m/d/Y")'
        },
        {
            flex: 1,
            text: 'Time in Foster Care <br>Before Goal Established',
            dataIndex: 'TimeInFosterCare',
            renderer: 'rendererTimeInFosterCare'
        },
        {
            flex: 1,
            text: 'Date Goal Changed',
            dataIndex: 'DateGoalChanged',
            cellWrap: true,
            renderer: function (val, meta, rec) {
                 if (rec.get('IsCurrentGoal') == 1)
                    return "NA. This is/was the current goal.";
                return Ext.Date.format(val, "m/d/Y");
            }
        },
        {
            flex: 2,
            text: 'Reason for <br> Goal Change',
            dataIndex: 'ReasonForGoalChange',
            cellWrap: true
        }
    ],
    getValue: function () {
        var me=this,
            store = this.getStore(),
            modifiedRecords = store.getModifiedRecords(),
            records = [];
        Ext.each(modifiedRecords, function (rec) {
            var data = rec.getData();
            delete data.IsInterviewedCheck;
            delete data.id;
            //data.DataState = me.dataState.Added;
            if (rec.isDirty()) {
                data.DataState = me.dataState.Modified;
            }
            records.push(data);
        });
        return records;
    }

});