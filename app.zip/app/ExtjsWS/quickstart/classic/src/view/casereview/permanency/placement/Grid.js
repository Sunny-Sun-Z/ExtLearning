/**
 * Created by kkora on 9/8/2017.
 */
Ext.define('QuickStart.view.casereview.permanency.placement.Grid', {
    extend: 'QuickStart.view.common.CrudGrid',
    xtype: 'placementgrid',
    columns: [
        {
            flex: 1,
            text: 'Placement Date',
            dataIndex: 'Date',
            formatter: 'date("m/d/Y")'
        },
        {
            flex: 1,
            text: 'Placement Type',
            dataIndex: 'TypeCode',
            cellWrap: true,
            renderer: 'rendererPlacementType'

        },
        {
            flex: 3,
            text: 'Reason for Change in Placement Setting',
            dataIndex: 'ChangeReasonCode',
            cellWrap : true,
            renderer: 'rendererPlacementChangeReason'

        }
    ],
    getValue: function () {
        var me=this,
            store = this.getStore(),
            modifiedRecords = store.getModifiedRecords(),
            records = [];
        Ext.each(modifiedRecords, function (rec) {
            var data = rec.getData();
            delete data.IsInterviewedCheck;
            delete data.id;
            //data.DataState = me.dataState.Added;
            if (rec.isDirty()) {
                data.DataState = me.dataState.Modified;
            }
            records.push(data);
        });
        return records;
    }

});