/**
 * Created by kkora on 9/22/2017.
 */

Ext.define('QuickStart.view.casereview.item.CaseContainer', {
    extend: 'Ext.Container',
    xtype: 'casecontainer',
    margin: '20 0 0 20',
    flex: 1,
    region: 'center',
    scrollable: 'y',
    layout: 'card',
    // layout: 'auto',
    items: [
        {
            xtype: 'facesheetcontainer'
           // xtype: 'overviewcontainer'
        },
        {
            xtype: 'casereviewsetup',
            itemId: 'casereviewSetupWindow'
        },

        {
            xtype: 'notewindow',
            itemId: 'noteWindow'
        }
    ]
});