/**
 * Created by kkora on 10/3/2017.
 */
Ext.define('QuickStart.view.casereview.window.Preview', {
    extend: 'QuickStart.view.common.BaseWindow',
    alias: 'widget.previewwindow',

    requires: [
        'Ext.layout.container.Fit',
        'Ext.toolbar.Fill'
    ],

    layout: 'fit',
    title: 'Preview Case',
    scrollable: 'y',
    resizable: true,
    maximizable:true,

    items: [
        {
            margin: 0,
            title: null,
            xtype: 'casepreviewcontainer'
        }
    ],
    dockedItems: [
        {
            xtype: 'toolbar',
            dock: 'bottom',
            ui: 'footer',
            items: ['->', {
                text: 'Cancel',
                ui: 'gray',
                iconCls: 'x-fa fa-close',
                handler: function (btn) {
                    btn.up('window').close();
                }
            }]
        }
    ]
});