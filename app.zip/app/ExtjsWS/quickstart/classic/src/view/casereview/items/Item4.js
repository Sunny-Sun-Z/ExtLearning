/**
 * Created by kkora on 10/12/2017.
 */

Ext.define('QuickStart.view.casereview.items.Item4', {
    extend: 'QuickStart.view.common.BaseItem',
    xtype: 'item4container',
    routeId: 'item4',
    items: [
        {
            title: 'Item 4: Stability of Foster Care Placement',
            xtype: 'panel',
            margin: '0 20 0 0'
        },
        {
            xtype: 'panel',
            items: [{
                title: 'A1. Placement Table',
                xtype: 'placementgrid',
                itemId: 'placementGrid',
                bind: '{placementStore}',
                listeners: {
                    addrecord: 'onAddPlacement',
                    editrecord: 'onEditPlacement',
                    deleterecord: 'onDeletePlacement'
                }
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.Placements==""}',
                    html: '{error.Placements}'
                }
            }]
        },
        {
            title: 'Question 4A',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question4a(),
            defaults: {margin: 10, disabledCls: 'disable-item'},
            layout: 'anchor',
            bind: {
                disabled: '{disabledItem || !hasPlacementRows}'
            },
            items: [{
                xtype: 'fieldcontainer',
                labelAlign: 'top',
                labelSeparator: '',
                items: [{
                    xtype: 'combobox',
                    minChars: 0,
                    editable: false,
                    forceSelection: true,
                    publishes: 'value',
                    reference: 'numberOfPlacementSettingsRef',
                    valueField: 'id',
                    displayField: 'id',
                    bind: {
                        store: '{numberTablePlacementStore}',
                        value: '{numberOfPlacementSettings}'
                    },
                    queryMode: 'local'
                }],
                fieldLabel: QuickStart.util.Resources.questions.permanency.question4A()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.NumberOfPlacementSettings==""}',
                    html: '{error.NumberOfPlacementSettings}'
                }
            }]
        },
        {
            title: 'Question 4B',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question4b(),
            defaults: {margin: 10},
            bind: {disabled: '{disabledItem || !hasPlacementRows}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'WereAllPlacementChangesPlanned',
                bind: '{wereAllPlacementChangesPlanned}',
                fieldLabel: QuickStart.util.Resources.questions.permanency.question4B()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.WereAllPlacementChangesPlanned==""}',
                    html: '{error.WereAllPlacementChangesPlanned}'
                }
            }]
        },
        {
            xtype: 'panel',
            defaults: {margin: 10, disabledCls: 'disable-item'},
            layout: 'anchor',
            items: [
                {
                    xtype: 'checkboxgroup',
                    labelAlign: 'top',
                    defaults: {
                        margin: '0 10 0 0',
                        name: 'PlacementApplicableCircumstances'
                    },
                    labelSeparator: '',
                    layout: 'anchor',
                    bind: {
                        value: '{placementApplicableCircumstances}',
                        disabled: '{disabledItem || !hasPlacementRows}'
                    },
                    items: [
                        {
                            xtype: 'component',
                            html: '<strong>Select all that apply:</strong>'
                        },
                        {
                            boxLabel: 'None apply, placement is stable',
                            reference: 'placementApplicableCircumstancesNone',
                            inputValue: 121
                        },
                        {
                            boxLabel: "The child's current placement is in a temporary shelter or other temporary setting.",
                            inputValue: 122,
                            bind: {disabled: '{placementApplicableCircumstancesNone.checked}'}
                        },
                        {
                            boxLabel: "There is information indicating that the child's current substitute care provider may not be able to continue to care for the child.",
                            inputValue: 123,
                            bind: {disabled: '{placementApplicableCircumstancesNone.checked}'}
                        },
                        {
                            boxLabel: "There are problems in the current placement threatening its stability that the agency is not addressing.",
                            inputValue: 124,
                            bind: {disabled: '{placementApplicableCircumstancesNone.checked}'}
                        },
                        {
                            boxLabel: "The child has run away from this placement more than once in the past, or is in runaway status at the time of the review.",
                            inputValue: 125,
                            bind: {disabled: '{placementApplicableCircumstancesNone.checked}'}
                        },
                        {
                            boxLabel: "Other (describe reasons why the current placement is not stable):",
                            reference: 'PlacementApplicableCircumstancesRef',
                            inputValue: 126,
                            bind: {disabled: '{placementApplicableCircumstancesNone.checked}'}
                        },
                        {
                            xtype: 'textarea',
                            fieldLabel: '',
                            hideLabel: true,
                            anchor: '100%',
                            maxLength: 100,
                            bind: {
                                disabled: '{!PlacementApplicableCircumstancesRef.checked}',
                                allowBlank: '{!PlacementApplicableCircumstancesRef.checked}',
                                value: '{caseReview.PlacementApplicableCircumstancesOther}'
                            },
                            msgTarget: 'side',
                            setAllowBlank: function (value) {
                                this.allowBlank = value;
                                this.isValid();
                            },
                            name: 'txt-other'
                        }
                    ],
                    fieldLabel: QuickStart.util.Resources.questions.permanency.question4C1()
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.PlacementApplicableCircumstances==""}',
                        html: '{error.PlacementApplicableCircumstances}'
                    }
                }]
        },
        {
            title: 'Question 4C',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question4c(),
            defaults: {margin: 10},
            bind: {disabled: '{disabledItem || !hasPlacementRows}'},
            items: [{
                xtype: 'yesnoradiogroup',
                name: 'IsCurrentPlacementSettingStable',
                bind: '{isCurrentPlacementSettingStable}',
                fieldLabel: QuickStart.util.Resources.questions.permanency.question4C()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsCurrentPlacementSettingStable==""}',
                    html: '{error.IsCurrentPlacementSettingStable}'
                }
            }]
        },
        {
            title: 'Item 4 Rating Criteria',
            xtype: 'rating',
            itemId: 'rating4',
            bind: {
               // disabled: '{disabledItem || !hasPlacementRows}',
				disabled: '{disabledItem}',
				overrideRatingPermission: '{overrideRatingPermission}',
                rating: '{caseReview.Item4}'
            },
            text: QuickStart.util.Resources.instructions.permanency.rating.item4()
        },
        {
            title: 'Item 4 - QA Notes',
            xtype: 'notepanel',
            itemId: 'item4NotePanel',
            noteType: 1,
            itemCode: 5,
            outcomeCode: 3,
            storeName: 'item4NoteStore',
            margin: '0 20 20 0',
            bind: {
                disabled: '{disabledNotes}'
            }
        },
        {
            bind: {
                hidden: '{!allowedInterviewNote}',
                disabled: '{disabledNotes}'
            },
            title: 'Item 4 - Interview Notes',
            xtype: 'notepanel',
            noteType: 2,
            itemCode: 5,
            outcomeCode: 3,
            storeName: 'item4InterviewNoteStore',
            margin: '0 20 20 0'
        }
    ]
});