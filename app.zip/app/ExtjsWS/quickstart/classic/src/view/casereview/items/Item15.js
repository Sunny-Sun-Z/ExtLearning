/**
 * Created by kkora on 10/12/2017.
 */

Ext.define('QuickStart.view.casereview.items.Item15', {
    extend: 'QuickStart.view.common.BaseItem',
    xtype: 'item15container',

    requires: [
        'Ext.form.RadioGroup'
    ],

    routeId: 'item15',
    items: [
        {
            title: 'Item 15: Caseworker Visits With Parents',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.item15(),
            defaults: {
                margin: 10,
                xtype: 'radiogroup',
                labelAlign: 'top',
                layout: 'hbox', disabledCls: 'disable-item',
                items: [{
                    boxLabel: 'Yes',
                    inputValue: 1
                }, {
                    boxLabel: 'No',
                    inputValue: 2
                }]
            },
            layout: 'anchor',
            items: [
                {
                    xtype: 'component',
                    html: '<strong> Item 15 Applicable Cases:</strong><br/>'
                },
                {
                    xtype: 'component',
                    html: '<ul><li>Because multiple case participants can be assessed in these questions, consider applicability for all appropriate case participants before determining that the rating should be Not Applicable. ' +
                    'All cases are applicable for an assessment of this item except cases in which all parents being assessed as Mother and Father meet any of the following criteria (check Yes for any that apply and No for those that do not):</li>' +
                    '</ul>'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability79'},
                    bind: {
                        disabled: '{!isFosterCareCase}',
                        value: '{item15Applicability79}'
                    },
                    fieldLabel: 'Parental rights remained terminated during the entire period under review'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability80'},
                    bind: {
                        disabled: '{!isFosterCareCase}',
                        value: '{item15Applicability80}'
                    },
                    fieldLabel: 'Parent’s whereabouts were not known during the entire period under review despite agency efforts to locate the parent'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability293'},
                    bind: {
                        disabled: '{!isFosterCareCase}',
                        value: '{item15Applicability293}'
                    },
                    fieldLabel: 'The Reviewer has determined that Item 12B is rated as an Area Needing Improvement due to lack of concerted efforts to find applicable parents'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability81'},
                    bind: {
                        disabled: '{!isFosterCareCase}',
                        value: '{item15Applicability81}'
                    },
                    fieldLabel: 'Parent was deceased during the entire period under review'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability82'},
                    bind: {
                        disabled: '{!isFosterCareCase}',
                        value: '{item15Applicability82}'
                    },
                    fieldLabel: 'During the entire period under review it was documented in the case file that it was not in the child’s best interests to involve the parent in case planning'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability83'},
                    bind: {
                        disabled: '{!isFosterCareCase}',
                        value: '{item15Applicability83}'
                    },
                    fieldLabel: 'During the entire period under review the parent has indicated he/she does not want to be involved in the child’s life and this was documented in the case file'
                },
                {
                    xtype: 'component',
                    html: '<strong> Select the appropriate response.</strong> If the response is No, the case will be rated as Not Applicable in the ratings section for this sub item.'

                }, {
                    xtype: 'yesnoradiogroup',
                    labelAlign: 'left',
                    name: 'Item15IsApplicable',
                    bind: '{item15IsApplicable}',
                    labelWidth: 200,
                    fieldLabel: 'Is this case applicable?'
                }, {
                    xtype: 'component',
                    bind: {hidden: '{caseReview.Item15IsApplicable != 1}'},
                    html: 'Indicate the case participants who are included in this item as Mother and Father'
                }, {
                    xtype: 'fieldcontainer',
                    labelAlign: 'top',
                    labelSeparator: '',
                    layout: 'hbox',
                    defaults: {
                        xtype: 'checkboxgroup', disabledCls: 'disable-item',
                        flex: 1,
                        columns: 1,
                        labelWidth: 75,
                        vertical: true,
                        items: [{}],
                        listeners: {
                            change: 'onItemParticipantChanged'
                        }
                    },
                    bind: {hidden: '{caseReview.Item15IsApplicable != 1}'},
                    items: [{
                        defaults: {name: 'Item15ParticipantMother'},
                        fieldLabel: 'Mother',
                        name: 'Item15ParticipantMother',
                        itemId: 'item15ParticipantMother',
						bind: { hidden: '{!hasMotherAndOtherParticipant}' }

					}, {
						fieldLabel: 'Mother',
						xtype: 'displayfield',
						value: 'There are no case participants in Face Sheet table G2 that can be assessed as Mother',
						bind: { hidden: '{hasMotherAndOtherParticipant}' }
					}, {
						defaults: { name: 'Item15ParticipantFather' },
						fieldLabel: 'Father',
						name: 'Item15ParticipantFather',
						itemId: 'item15ParticipantFather',
						bind: { hidden: '{!hasFatherAndOtherParticipant}' }
					}, {
						fieldLabel: 'Father',
						xtype: 'displayfield',
						value: 'There are no case participants in Face Sheet table G2 that can be assessed as Father',
						bind: { hidden: '{hasFatherAndOtherParticipant}' }
					}]


                }, {
                    xtype: 'narrativefield',
                    bind: '{caseReview.Item15Comments}'
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.Item15IsApplicable==""}',
                        html: '{error.Item15IsApplicable}'
                    }
                }]
        },

        {
            title: 'Question 15A1',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question15a1(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item15IsApplicable != 1}'},
            items: [{
                xtype: 'visitationfrequencydiogroup',
                defaults: {name: 'ResponsiblePartyVisitationFrequencyWithMotherCode'},
                bind: {
                    disabled: '{item15ApplicabilityNoMotherParticipant}',
                    value: '{responsiblePartyVisitationFrequencyWithMotherCode}'
                },
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question15A1()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.ResponsiblePartyVisitationFrequencyWithMotherCode==""}',
                    html: '{error.ResponsiblePartyVisitationFrequencyWithMotherCode}'
                }
            }]
        },
        {
            title: 'Question 15A2',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question15a2(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item15IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsResponsiblePartyVisitationFrequencyWithMotherSufficient',
                bind: {
                    disabled: '{item15ApplicabilityNoMotherParticipant}',
                    value: '{isResponsiblePartyVisitationFrequencyWithMotherSufficient}'
                },
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question15A2()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsResponsiblePartyVisitationFrequencyWithMotherSufficient==""}',
                    html: '{error.IsResponsiblePartyVisitationFrequencyWithMotherSufficient}'
                }
            }]
        },

        {
            title: 'Question 15B1',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question15b1(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item15IsApplicable != 1}'},
            items: [{
                xtype: 'visitationfrequencydiogroup',
                defaults: {name: 'ResponsiblePartyVisitationFrequencyWithFatherCode'},
                bind: {
                    disabled: '{item15ApplicabilityNoFatherParticipant}',
                    value: '{responsiblePartyVisitationFrequencyWithFatherCode}'
                },
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question15B1()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.ResponsiblePartyVisitationFrequencyWithFatherCode==""}',
                    html: '{error.ResponsiblePartyVisitationFrequencyWithFatherCode}'
                }
            }]
        },
        {
            title: 'Question 15B2',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question15b2(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item15IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsResponsiblePartyVisitationFrequencyWithFatherSufficient',
                bind: {
                    disabled: '{item15ApplicabilityNoFatherParticipant}',
                    value: '{isResponsiblePartyVisitationFrequencyWithFatherSufficient}'
                },
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question15B2()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsResponsiblePartyVisitationFrequencyWithFatherSufficient==""}',
                    html: '{error.IsResponsiblePartyVisitationFrequencyWithFatherSufficient}'
                }
            }]
        },

        {
            title: 'Question 15C',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question15c(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item15IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsResponsiblePartyVisitationQualityWithMotherSufficient',
                bind: {
                    disabled: '{item15ApplicabilityNoMotherParticipant}',
                    value: '{isResponsiblePartyVisitationQualityWithMotherSufficient}'
                },
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question15C()
            }, {
                xtype: 'yesnonarrativefield',
                bind: {
                    value: '{caseReview.ResponsiblePartyVisitationQualityWithMotherExplained}',
                    disabled: '{caseReview.IsResponsiblePartyVisitationQualityWithMotherSufficient != 2 }'
                }
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsResponsiblePartyVisitationQualityWithMotherSufficient==""}',
                    html: '{error.IsResponsiblePartyVisitationQualityWithMotherSufficient}'
                }
            }]
        },
        {
            title: 'Question 15D',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question15d(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item15IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsResponsiblePartyVisitationQualityWithFatherSufficient',
                bind: {
                    disabled: '{item15ApplicabilityNoFatherParticipant}',
                    value: '{isResponsiblePartyVisitationQualityWithFatherSufficient}'
                },
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question15D()
            }, {
                xtype: 'yesnonarrativefield',
                bind: {
                    value: '{caseReview.ResponsiblePartyVisitationQualityWithFatherExplained}',
                    disabled: '{caseReview.IsResponsiblePartyVisitationQualityWithFatherSufficient != 2 }'
                }
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsResponsiblePartyVisitationQualityWithFatherSufficient==""}',
                    html: '{error.IsResponsiblePartyVisitationQualityWithFatherSufficient}'
                }
            }]
        },

        {
            title: 'Item 15 Rating Criteria',
            xtype: 'rating',
            itemId: 'rating15',
            bind: {
               // disabled: '{disabledItem|| caseReview.Item15IsApplicable != 1}',
				disabled: '{disabledItem}',
				overrideRatingPermission: '{overrideRatingPermission}',
                rating: '{caseReview.Item15}'
            },
            text: QuickStart.util.Resources.instructions.wellbeing.rating.item15()
        },
        {
            title: 'Item 15 - QA Notes',
            xtype: 'notepanel',
            itemId: 'item15NotePanel',
            noteType: 1,
            itemCode: 19,
            outcomeCode: 5,
            storeName: 'item15NoteStore',
            margin: '0 20 20 0',
            bind: {
                disabled: '{disabledNotes}'
            }
        },
        {
            bind: {
                hidden: '{!allowedInterviewNote}',
                disabled: '{disabledNotes}'
            },
            title: 'Item 15 - Interview Notes',
            xtype: 'notepanel',
            noteType: 2,
            itemCode: 19,
            outcomeCode: 5,
            storeName: 'item15InterviewNoteStore',
            margin: '0 20 20 0'
        }
    ],
    listeners: {
        afterrender: 'onAfterRenderItem15'
    }
});