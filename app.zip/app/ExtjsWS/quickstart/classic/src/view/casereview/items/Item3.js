/**
 * Created by kkora on 10/16/2017.
 */


Ext.define('QuickStart.view.casereview.items.Item3', {
    extend: 'QuickStart.view.common.BaseItem',
    xtype: 'item3container',
    routeId: 'item3',
    items: [
        {
            title: 'Item 3: Risk and Safety Assessment and Management',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.safety.outcome2Item3(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [{
                xtype: 'component',
                html: '<strong> Item 3 Applicable Cases:</strong><br/><ul><li>All cases are applicable for an assessment of this item.</li></ul>'
            }]
        },
        {
            title: 'Question 3A1',
            xtype: 'panel',
            defaults: {margin: 10},
            layout: 'anchor',
            items: [{
                xtype: 'component',
                html: '<strong>A1. Did any of the following concerns exist during the period under review?</strong>'
            },
                {
                    xtype: 'yesnoradiogroup',
                    name: 'IsFamilyMaltreatmentAllegations',
                    bind: '{isFamilyMaltreatmentAllegations}',
                    fieldLabel: 'There were maltreatment allegations about the family but they were never formally reported or formally investigated/assessed.'
                },
                {
                    xtype: 'yesnoradiogroup',
                    name: 'IsMaltreatmentNotSubstantiated',
                    bind: '{isMaltreatmentNotSubstantiated}',
                    fieldLabel: 'There were maltreatment allegations that were not substantiated despite evidence that would support substantiation.'
                }
            ]
        },
        {
            title: 'Question 3A',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.safety.question3a(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsInitialAssesmentForAllChildrenInHome',
                bind: '{isInitialAssesmentForAllChildrenInHome}',
                fieldLabel: QuickStart.util.Resources.questions.safety.question3A()
            }, {
                xtype: 'yesnonarrativefield',
                bind: {
                    value: '{caseReview.InitialAssesmentForAllChildrenInHomeExplained}',
                    disabled: '{caseReview.IsInitialAssesmentForAllChildrenInHome != 2}'
                }
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsInitialAssesmentForAllChildrenInHome==""}',
                    html: '{error.IsInitialAssesmentForAllChildrenInHome}'
                }
            }]
        },
        {
            title: 'Question 3B',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.safety.question3b(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsOngoingAssesementForAllChildrenInHome',
                bind: '{isOngoingAssesementForAllChildrenInHome}',
                fieldLabel: QuickStart.util.Resources.questions.safety.question3B()
            }, {
                xtype: 'yesnonarrativefield',
                bind: {
                    value: '{caseReview.OngoingAssessmentForAllChildrenInHomeExplained}',
                    disabled: '{caseReview.IsOngoingAssesementForAllChildrenInHome != 2}'
                }
            }]
        },
        {
            title: 'Question 3C',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.safety.question3c(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsSafetyPlanDevelopedAndMonitored',
                bind: '{isSafetyPlanDevelopedAndMonitored}',
                fieldLabel: QuickStart.util.Resources.questions.safety.question3C()
            }, {
                xtype: 'yesnonarrativefield',
                bind: {
                    value: '{caseReview.SafetyPlanDevelopedAndMonitoredExplained}',
                    disabled: '{caseReview.IsSafetyPlanDevelopedAndMonitored != 2}'
                }
            }]
        },
        {
            title: 'Question 3 D1',
            xtype: 'panel',
            defaults: {margin: 10, disabledCls: 'disable-item'},
            layout: 'anchor',
            items: [
                {
                    xtype: 'checkboxgroup',
                    labelAlign: 'top',
                    defaults: {margin: '0 10 0 0', name: 'SafetyRelatedIncidents'},
                    labelSeparator: '',
                    layout: 'anchor',
                    bind: {value: '{safetyRelatedIncidents}'},
                    items: [
                        {
                            xtype: 'component',
                            html: '<strong>Select all that apply:</strong>'
                        },
                        {
                            boxLabel: 'NA (no safety issues were present during the period under review).',
                            reference: 'safetyRelatedIncidentNa',
                            inputValue: 86,
                            bind: {disabled: '{safetyRelatedIncidentNoSafety.checked}'}
                        },
                        {
                            boxLabel: 'No safety-related incidents occurred that were not adequately addressed by the agency.',
                            reference: 'safetyRelatedIncidentNoSafety',
                            inputValue: 87,
                            bind: {disabled: '{safetyRelatedIncidentNa.checked}'}
                        },
                        {
                            boxLabel: 'Recurring maltreatment: There was at least one substantiated or indicated maltreatment report on any child in the family during the period under review AND there was another substantiated report within a 6-month period before or after that report that involved the same or similar circumstances. In determining the similarity of the circumstances, consider the perpetrator of the maltreatment and other individuals involved in the incident.',
                            inputValue: 88,
                            bind: {
                                disabled: '{ !hasSubstantiatedReport || caseReview.Item1IsApplicable==2 ||safetyRelatedIncidentNoSafety.checked || safetyRelatedIncidentNa.checked}'
                            }
                        },
                        {
                            boxLabel: 'Recurring safety concerns: There was at least one maltreatment report involving any child in the family during the period under review that was handled by an alternative response and resulted in opening the case for services to address safety concerns (this decision may have been made by the agency or by a private provider under contract with the agency) AND there was at least one additional maltreatment report within a 6-month period before or after that report that was handled by an alternative response and resulted in a decision to open the case for services to address the same or similar safety concerns (the case may have been opened for services by the agency or by a private provider under contract with the agency). In determining the similarity of the concerns, consider the perpetrator of the maltreatment, other individuals involved in the incident, and the type of safety issues that existed.',
                            inputValue: 89,
                            bind: {
                                disabled: '{!hasOpenedForServicesReport || caseReview.Item1IsApplicable==2 || safetyRelatedIncidentNoSafety.checked || safetyRelatedIncidentNa.checked}'
                            }
                        },
                        {
                            boxLabel: 'The case was closed while significant safety concerns that were not adequately addressed still existed in the home.',
                            inputValue: 90,
                            bind: {
                                disabled: '{safetyRelatedIncidentNoSafety.checked || safetyRelatedIncidentNa.checked}'
                            }
                        },
                        {
                            boxLabel: 'Other (describe any other safety-related incidents that were not adequately addressed by the agency):',
                            reference: 'safetyRelatedIncidentRef',
                            inputValue: 91,
                            bind: {
                                disabled: '{safetyRelatedIncidentNoSafety.checked || safetyRelatedIncidentNa.checked}'
                            }

                        },
                        {
                            xtype: 'textarea',
                            fieldLabel: '',
                            hideLabel: true,
                            anchor: '100%', maxLength: 100,
                            msgTarget: 'side',
                            bind: {
                                disabled: '{!safetyRelatedIncidentRef.checked}',
                                allowBlank: '{!safetyRelatedIncidentRef.checked}',
                                value: '{caseReview.OtherSafetyConcernExplained}'
                            },
                            blankText: 'For question 3D1, please fill out the narrative field for a response of Other',
                            setAllowBlank: function (value) {
                                this.allowBlank = value;
                                this.isValid();
                            },
                            name: 'txt-other'

                        }
                    ],
                    //fieldLabel: 'D1. Indicate whether any safety-related incidents occurred during the period under review.'
                    fieldLabel: QuickStart.util.Resources.questions.safety.question3D1()
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.SafetyRelatedIncidents==""}',
                        html: '{error.SafetyRelatedIncidents}'
                    }
                }]
        },
        {
            title: 'Question 3D',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.safety.question3d(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsSafetyConcernForOtherChildren',
                bind: {
                    value: '{isSafetyConcernForOtherChildren}',
                    disabled: '{safetyRelatedIncidentNa.checked}'
                },
                fieldLabel: QuickStart.util.Resources.questions.safety.question3D()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsSafetyConcernForOtherChildren==""}',
                    html: '{error.IsSafetyConcernForOtherChildren}'
                }
            }]
        },
        {
            title: 'Question 3 E1',
            xtype: 'panel',
            defaults: {margin: 10, disabledCls: 'disable-item'},
            layout: 'anchor',
            items: [{
                xtype: 'checkboxgroup',
                labelAlign: 'top',
                defaults: {margin: '0 10 0 0', name: 'FosterSafety'},
                labelSeparator: '',
                layout: 'anchor',
                bind: {value: '{fosterSafety}'},
                items: [
                    {
                        boxLabel: 'NA (this is an in-home services case, or the target child did not have any visitation).',
                        reference: 'fosterSafetyNa',
                        bind: {disabled: '{!isFosterCareCase || fosterSafetyNo.checked }'},
                        inputValue: 92
                    },
                    {
                        boxLabel: 'No unmitigated safety concerns related to visitation were present.',
                        reference: 'fosterSafetyNo',
                        bind: {disabled: '{!isFosterCareCase || fosterSafetyNa.checked }'},
                        inputValue: 93
                    },
                    {
                        boxLabel: 'Sufficient monitoring of visitation by parents/caretakers or other family members was not ensured.',
                        bind: {disabled: '{!isFosterCareCase || fosterSafetyNo.checked|| fosterSafetyNa.checked }'},
                        inputValue: 94
                    },
                    {
                        boxLabel: 'Unsupervised visitation was allowed when it was not appropriate.',
                        bind: {disabled: '{!isFosterCareCase|| fosterSafetyNo.checked|| fosterSafetyNa.checked}'},
                        inputValue: 95
                    },
                    {
                        boxLabel: 'Visitation was court-ordered despite safety concerns that could not be controlled with supervision.',
                        bind: {disabled: '{!isFosterCareCase|| fosterSafetyNo.checked|| fosterSafetyNa.checked}'},
                        inputValue: 96
                    },
                    {
                        boxLabel: 'Other (describe the safety concerns that existed with visitation):',
                        reference: 'fosterSafetyOtherRef',
                        bind: {disabled: '{!isFosterCareCase|| fosterSafetyNo.checked|| fosterSafetyNa.checked}'},
                        inputValue: 97
                    }, {
                        xtype: 'textarea',
                        fieldLabel: '',
                        hideLabel: true, maxLength: 100,
                        anchor: '100%',
                        bind: {
                            disabled: '{!fosterSafetyOtherRef.checked}',
                            allowBlank: '{!fosterSafetyOtherRef.checked}',
                            value: '{caseReview.FosterSafetyOtherExplained}'
                        },
                        msgTarget: 'side',
                        setAllowBlank: function (value) {
                            this.allowBlank = value;
                            this.isValid();
                        },
                        name: 'txt-other'
                    }
                ],
                fieldLabel: QuickStart.util.Resources.questions.safety.question3E1()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.FosterSafety==""}',
                    html: '{error.FosterSafety}'
                }
            }]
        },
        {
            title: 'Question 3E',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.safety.question3e(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsFosterSafetyConcernDuringVisitation',
                bind: {
                    value: '{isFosterSafetyConcernDuringVisitation}',
                    disabled: '{!isFosterCareCase}'
                },
                fieldLabel: QuickStart.util.Resources.questions.safety.question3E()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsFosterSafetyConcernDuringVisitation==""}',
                    html: '{error.IsFosterSafetyConcernDuringVisitation}'
                }
            }]
        },
        {
            title: 'Question 3 F1',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.safety.question3f1(),
            defaults: {margin: 10, disabledCls: 'disable-item'},
            layout: 'anchor',
            items: [
                {
                    xtype: 'checkboxgroup',
                    labelAlign: 'top',
                    defaults: {margin: '0 10 0 0', name: 'FosterPlacementConcern'},
                    labelSeparator: '',
                    layout: 'anchor',
                    bind: {value: '{fosterPlacementConcern}'},
                    items: [
                        {
                            boxLabel: 'NA (this is an in-home services case).',
                            reference: 'fosterPlacementConcernNA',
                            disabled: true,
                            // bind: {
                            //     disabled: '{!isFosterCareCase}',
                            //     // checked: '{isHomeServiceCase}'
                            // },
                            inputValue: 98
                        },
                        {
                            boxLabel: 'No safety concerns existed for the target child while in foster care placement that were not adequately addressed.',
                            reference: 'fosterPlacementConcernNo',
                            bind: {disabled: '{!isFosterCareCase}'},
                            inputValue: 99
                        },
                        {
                            boxLabel: 'There was a substantiated allegation of maltreatment of the child by a foster parent (including a relative foster parent) or facility staff member that could have been prevented if the agency had taken appropriate actions.',
                            bind: {disabled: '{ !isFosterCareCase || !hasSubstantiatedReport || caseReview.Item1IsApplicable==2  || fosterPlacementConcernNA.checked ||fosterPlacementConcernNo.checked}'},
                            inputValue: 100
                        },
                        {
                            boxLabel: 'There was a critical incident report or other major issue relevant to noncompliance by foster parents or facility staff that could potentially make the child unsafe, and the agency could have prevented it or did not provide an adequate response after it occurred.',
                            bind: {disabled: '{!isFosterCareCase|| fosterPlacementConcernNA.checked ||fosterPlacementConcernNo.checked}'},
                            inputValue: 101
                        },
                        {
                            boxLabel: 'The child’s placement during the period under review presented other risks to the child that are not being addressed, even though no allegation was made and no critical incident reports were filed.',
                            bind: {disabled: '{!isFosterCareCase|| fosterPlacementConcernNA.checked ||fosterPlacementConcernNo.checked}'},
                            inputValue: 102
                        },
                        {
                            boxLabel: 'You discover that there are safety concerns related to the child in the foster home of which the agency is unaware because of inadequate monitoring.',
                            bind: {disabled: '{!isFosterCareCase|| fosterPlacementConcernNA.checked ||fosterPlacementConcernNo.checked}'},
                            inputValue: 103
                        },
                        {
                            boxLabel: 'Other (describe any other safety concerns that existed with the child’s foster placement):',
                            reference: 'fosterPlacementConcernOtherRef',
                            bind: {disabled: '{!isFosterCareCase|| fosterPlacementConcernNA.checked ||fosterPlacementConcernNo.checked}'},
                            inputValue: 104
                        },
                        {
                            xtype: 'textarea',
                            fieldLabel: '',
                            hideLabel: true,
                            anchor: '100%', maxLength: 100,
                            bind: {
                                disabled: '{!fosterPlacementConcernOtherRef.checked}',
                                allowBlank: '{!fosterPlacementConcernOtherRef.checked}',
                                value: '{caseReview.FosterPlacementConcerOtherExplained}'
                            },
                            msgTarget: 'side',
                            setAllowBlank: function (value) {
                                this.allowBlank = value;
                                this.isValid();
                            },
                            name: 'txt-other'
                        }
                    ],
                    fieldLabel: QuickStart.util.Resources.questions.safety.question3F1()
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.FosterPlacementConcern==""}',
                        html: '{error.FosterPlacementConcern}'
                    }
                }
            ]
        },
        {
            title: 'Question 3F',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.safety.question3f(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsFosterSafetyConcernNotAddressed',
                bind: {
                    value: '{isFosterSafetyConcernNotAddressed}',
                    disabled: '{!isFosterCareCase}'
                },
                fieldLabel: QuickStart.util.Resources.questions.safety.question3F()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsFosterSafetyConcernNotAddressed==""}',
                    html: '{error.IsFosterSafetyConcernNotAddressed}'
                }
            }]
        },
        {
            title: 'Item 3 Rating Criteria',
            xtype: 'rating',
            itemId: 'rating3',
            bind: {
				disabled: '{disabledItem}',
				overrideRatingPermission: '{overrideRatingPermission}',
                rating: '{caseReview.Item3}'
            },
            text: QuickStart.util.Resources.instructions.safety.item3Rating()
        },
        {
            title: 'Safety - Item 3 - QA Notes',
            xtype: 'notepanel',
            itemId: 'item3NotePanel',
            noteType: 1,
            itemCode: 4,
            outcomeCode: 2,
            storeName: 'item3NoteStore',
            margin: '0 20 20 0',
            bind: {
                disabled: '{disabledNotes}'
            }
        },
        {
            bind: {
                hidden: '{!allowedInterviewNote}',
                disabled: '{disabledNotes}'
            },
            title: 'Safety - Item 3 - Interview Notes',
            xtype: 'notepanel',
            noteType: 2,
            itemCode: 4,
            outcomeCode: 2,
            storeName: 'item3InterviewNoteStore',
            margin: '0 20 20 0'
        }

    ]
});