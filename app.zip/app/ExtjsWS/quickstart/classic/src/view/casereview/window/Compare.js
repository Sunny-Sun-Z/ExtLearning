/**
 * Created by kkora on 2/25/2018.
 */
Ext.define('QuickStart.view.casereview.window.Compare', {
    extend: 'QuickStart.view.common.BaseWindow',
    alias: 'widget.comparewindow',

    requires: [
        'Ext.layout.container.Fit',
        'Ext.toolbar.Fill'
    ],

    layout: 'fit',
    title: 'Compare Cases',
    scrollable: 'y',
    resizable: true,
    maximizable:true,

    items: [
        {
            margin: 0,
            title: null,
            xtype: 'casecomparecontainer'
        }
    ],
    dockedItems: [
        {
            xtype: 'toolbar',
            dock: 'bottom',
            ui: 'footer',
            items: ['->', {
                text: 'Cancel',
                ui: 'gray',
                iconCls: 'x-fa fa-close',
                handler: function (btn) {
                    btn.up('window').close();
                }
            }]
        }
    ]
});