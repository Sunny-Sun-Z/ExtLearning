/**
 * Created by kkora on 9/7/2017.
 */

Ext.define('QuickStart.view.casereview.facesheet.caseparticipant.Window', {
    extend: 'QuickStart.view.common.BaseWindow',

    alias: 'widget.caseparticipantwindow',

	requires: [
		'Ext.form.field.*'
	],

	width: 600,
    layout: 'fit',
    defaults: {
        defaultFocus: 'textfield:not([value]):focusable:not([disabled])',
        defaultButton: 'caseParticipantSaveButton'
    },
    bind: {
        title: '{current.caseParticipantAction} Case Participant'
    },
    scrollable: 'y',
    items: [
        {
            bodyPadding: '10 10 0 10',
            xtype: 'form',
            scrollable: 'y',
            defaultType: 'textarea',
            defaults: {
                submitEmptyText: false,
                anchor: '100%',
                labelWidth: 150,
                fieldLabel: ' ',
                msgTarget: 'side'
            },
            items: [
                    {
                    xtype: 'combobox',
                    allowBlank: false,
                    blankText: 'Please specify the Participant\'s Role.',
                    fieldLabel: 'Participant\'s Role',
                    bind: {
                        value: '{current.caseParticipant.RoleCode}',
                        store: '{participantRoleStore}'
                    },
                    displayField: 'large',
                    valueField: 'code',
                    forceSelection: true,
                  //  editable: false,
                    name: 'RoleCode',
                    queryMode: 'local'

                },
                {
                    itemId: 'participantsRoleOther',
                    fieldLabel: 'Participant\'s  Role(Other)',
                    maxLength: 100,
                    enforceMaxLength: true,
                    bind: {
                        value: '{current.caseParticipant.OtherRole}',
                        disabled: '{otherCaseParticipantRoleCode}',
                        allowBlank: '{otherCaseParticipantRoleCode}'

                    },
                    setAllowBlank:function (value) {
                        this.allowBlank=value;
                        this.isValid();
                    },
                    name: 'OtherRole',
                    blankText: 'Please fill out the Participant\'s Role narrative field for a response of Other.'
                },
				{
					xtype: 'textfield',
					allowBlank: false,
					blankText: 'Please specify the Participant\'s Name',
					itemId: 'participantsName',
					fieldLabel: 'Participant\'s Name',
					maxLength: 100,
					enforceMaxLength: true,
					bind: '{current.caseParticipant.Name}',
					name: 'Name'
				},
				{
                    fieldLabel: 'Relationship to Child',
                    maxLength: 100,
                    enforceMaxLength: true,
                    bind: '{current.caseParticipant.RelationshipToChild}',
                    name: 'RelationshipToChild',
                    allowBlank: false,
                    blankText: 'Please specify the Relationship to Child.'
                },
                {
                    labelSeparator: '',
                    bind: {
                        value: '{current.caseParticipant.IsInterviewedCheck}'
                    },
                    xtype: 'checkbox',
                    boxLabel: 'Is Interviewed',
                    name: 'IsInterviewed',
                    inputValue: 1,
                    uncheckedValue: 2
                }
            ],
            dockedItems: [
                {
                    xtype: 'toolbar',
                    dock: 'bottom',
                    ui: 'footer',
                    items: ['->', {
						text: 'Update & Add More',
						ui: 'soft-green',
						iconCls: 'x-fa fa-save',
						type:'addnew',
						formBind: true,
						handler: 'onSaveCaseParticipant'

					}, {
						text: 'Add/Update',
						ui: 'soft-green',
						iconCls: 'x-fa fa-save',
						reference: 'caseParticipantSaveButton',
						type:'add',
						formBind: true,
						handler: 'onSaveCaseParticipant'

					}, {
						text: 'Cancel',
                        ui: 'gray',
                        iconCls: 'x-fa fa-close',
                        handler: 'onCancelCaseParticipant'
                    }]
                }]

        }
    ]

});