/**
 * Created by kkora on 9/7/2017.
 */

Ext.define('QuickStart.view.casereview.note.Window', {
    extend: 'QuickStart.view.common.BaseWindow',

    xtype: 'notewindow',
    width: 600,
    layout: 'fit',
    scrollable: 'y',
    defaults: {
        defaultFocus: 'textfield:not([value]):focusable:not([disabled])',
        defaultButton: 'noteSaveButton'
    },
    bind: {
        title: '{current.noteAction} {current.note.NoteType==2?"Interview " :""}Note: {current.note.Subject}'
    },
    items: [
        {
            scrollable: 'y',
            xtype: 'noteform'
        }
    ],
    hideSubject: function (hide) {
        var formPanel = this.down('form'),
            nameField = formPanel.down('#subject'),
            subjectCharsContainer = formPanel.down('#subjectCharsContainer');

        nameField.allowBlank = true;
        nameField.hide();
        subjectCharsContainer.hide();

    },
    showSubject: function (hide) {
        var formPanel = this.down('form'),
            nameField = formPanel.down('#subject'),
            subjectCharsContainer = formPanel.down('#subjectCharsContainer');

        nameField.allowBlank = false;
        nameField.show();

        subjectCharsContainer.show();

    }

});