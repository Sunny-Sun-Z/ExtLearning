/**
 * Created by kkora on 9/8/2017.
 */
Ext.define('QuickStart.view.casereview.wellbeing.mentalhealth.Grid', {
    extend: 'QuickStart.view.common.CrudGrid',
    xtype: 'mentalhealthgrid',

    columns: [
        {
            flex: 1,
            text: 'Identified Mental / Behavioral Health Needs',
            dataIndex: 'HealthNeeds',
            cellWrap : true
         },
         {
            flex: 1,
            text: 'Services Provided',
            dataIndex: 'ServicesProvided',
            cellWrap: true
         },
        {
            flex: 1,
            text: 'Services Needed But Not Provided',
            dataIndex: 'ServicesNeededNotProvided',
            cellWrap: true
        },
        {
            text: 'Health Need',
            dataIndex: 'HealthNeedCode',
            hidden : true
        }
    ],
    getValue: function () {

        var me=this,
            store = this.getStore(),
            modifiedRecords =store.getRange(),
            records = [];
        Ext.each(modifiedRecords, function (rec) {
            var data = rec.getData();
            delete data.id;
            data.DataState = me.dataState.Added;
            records.push(data);
        });
        return records;
    }

});