/**
 * Created by kkora on 10/12/2017.
 */


Ext.define('QuickStart.view.casereview.items.Item7', {
    extend: 'QuickStart.view.common.BaseItem',
    xtype: 'item7container',
    routeId: 'item7',
    items: [
        {
            title: 'Item 7: Placement With Siblings',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.item7(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [{
                xtype: 'component',
                html: '<strong> Item 7 Applicable Cases:</strong><br/>' +
                '<ul><li>Cases applicable for an assessment of this item include all foster care cases in which the child has one or more siblings who are (or were) also in foster care during the period under review. ' +
                'If the child has no siblings in foster care during the period under review, the case is Not Applicable for an assessment of this item. ' +
                'For example, if the child in foster care has an older sibling who was in foster care at one time, but not during the period under review, this case would be Not Applicable.</li></ul>'
            }, {
                xtype: 'component',
                html: '<strong> Select the appropriate response.</strong> If the response is No, the case will be rated as Not Applicable in the ratings section for this item.'

            }, {
                xtype: 'yesnoradiogroup',
                labelAlign: 'left',
                name: 'Item7IsApplicable',
                 bind: {
                    disabled: '{!hasSibling}',
                    value: '{item7IsApplicable}'
                },
                labelWidth: 200,
                fieldLabel: 'Is this case applicable?'
            }, {
                xtype: 'narrativefield',
                bind: '{caseReview.Item7Comments}'
            }]
        },
        {
            title: 'Question 7A',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question7a(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item7IsApplicable != 1}'},
            items: [{
                xtype: 'yesnoradiogroup',
                name: 'IsPlacedWithAllSiblings',
                bind: '{isPlacedWithAllSiblings}',
                labelWidth: '100%',
                fieldLabel: QuickStart.util.Resources.questions.permanency.question7A()
            }]
        },
        {
            title: 'Question 7B',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question7b(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item7IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsValidReasonForSeparation',
                bind: {
                    value: '{isValidReasonForSeparation}',
                    disabled: '{caseReview.IsPlacedWithAllSiblings==1 }'
                },
                fieldLabel: QuickStart.util.Resources.questions.permanency.question7B()
            }, {
                xtype: 'yesnonarrativefield',
                bind: {
                    value: '{caseReview.ValidReasonForSeparationExplained}',
                    disabled: '{caseReview.IsValidReasonForSeparation != 2 }'
                }
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsValidReasonForSeparation==""}',
                    html: '{error.IsValidReasonForSeparation}'
                }
            }]
        },
        {
            title: 'Item 7 Rating Criteria',
            xtype: 'rating',
            itemId: 'rating7',
            bind: {
               // disabled: '{caseReview.Item7IsApplicable != 1}',
				disabled: '{disabledItem}',
				overrideRatingPermission: '{overrideRatingPermission}',
                rating: '{caseReview.Item7}'
            },
            text: QuickStart.util.Resources.instructions.permanency.rating.item7()
        },
        {
            title: 'Item 7 - QA Notes',
            xtype: 'notepanel',
            itemId: 'item7NotePanel',
            noteType: 1,
            itemCode: 8,
            outcomeCode: 4,
            storeName: 'item7NoteStore',
            margin: '0 20 20 0',
            bind: {
                disabled: '{disabledNotes}'
            }
        },
        {
            bind: {
                hidden: '{!allowedInterviewNote}',
                disabled: '{disabledNotes}'
            },
            title: 'Item 7 - Interview Notes',
            xtype: 'notepanel',
            noteType: 2,
            itemCode: 8,
            outcomeCode: 4,
            storeName: 'item7InterviewNoteStore',
            margin: '0 20 20 0'
        }
    ]
});