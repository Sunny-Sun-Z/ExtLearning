/**
 * Created by kkora on 2/25/2018.
 */
Ext.define('QuickStart.view.casereview.irr.IrrModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.irr',

    stores: {
        irrStore: {
            model: 'QuickStart.model.Dashboard',
            autoLoad: true,
            pageSize: 20,
            remoteFilter: true,
            remoteSort: true,
            filters: [{property: 'crDs', value: ''}],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'case/IrrDashboard'
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },
        cases: {
            model: 'QuickStart.model.BaseLookup',
            autoLoad: false,
            pageSize: 20,
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'lookup/GetCases'
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },
        users: {
            model: 'QuickStart.model.BaseLookup',           
            autoLoad: true,
            filters: [{ property: 'IsIRR', value: true }],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'lookup/GetAllUsers'
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        }

    },
    formulas:{
        allowedCreateIRRCase: {
            bind: {bindTo: '{irrStore}'},
            get: function (val) {
                return QuickStart.util.Global.permissions.allowCreateIRRCase();
            }
        }

    },
    data: {
     current:{
         irr:null
     }
    }
});