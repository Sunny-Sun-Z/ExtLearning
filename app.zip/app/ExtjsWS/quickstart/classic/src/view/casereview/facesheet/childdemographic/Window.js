/**
 * Created by kkora on 9/7/2017.
 */

Ext.define('QuickStart.view.casereview.facesheet.childdemographic.Window', {
    extend: 'QuickStart.view.common.BaseWindow',

    alias: 'widget.childdemographicwindow',

	requires: [
		'Ext.form.field.*'
	],

	width: 500,
    layout: 'fit',
    maximized:true,
    // maximizable:true,
    // y: 1,
    constrain : true,
    defaults: {
        defaultFocus: 'textfield:not([value]):focusable:not([disabled])',
        defaultButton: 'childDemographicSaveButton'
    },
    bind: {
        title: '{current.childDemographicAction} Child Demographic'
    },
    scrollable: 'y',
    items: [
        {
            bodyPadding: '0 10',
            xtype: 'form',
            scrollable: 'y',
            defaultType: 'combobox',
            defaults: {
                submitEmptyText: false,
                anchor: '100%',
                fieldLabel: ' ',
                msgTarget: 'side'

            },
            items: [
                {
                    labelSeparator: '',
                    xtype: 'checkbox',
                    boxLabel: 'Is Target Child',
                    bind: {
                        disabled: '{!isFosterCareCase || (hasSingleDemographicTargetChildRow && !current.childDemographic.IsTargetChildCheck) }',
                        value: '{current.childDemographic.IsTargetChildCheck}'
                    },
                    name: 'IsTargetChild',
                    inputValue: 1,
                    uncheckedValue: 2

                },
                {
                    xtype: 'textfield',
                    fieldLabel: 'Child Name',
                    maxLength: 100,
                    enforceMaxLength: true,
                    name: 'Name',
                    allowBlank: false,
                    bind: '{current.childDemographic.Name}',
                    blankText: 'Please specify the childs name'
                },
                {
                    xtype: 'checkboxgroup',
                    allowBlank: false,
                    fieldLabel: 'Race',
                    layout: 'vbox',
                    vertical: true,
                    reference: 'childDemographicRaceCodes',
                    blankText: 'Please select at least one race',
                    // bind: {
                    //     values:'{current.childDemographic.RaceCodes}'
                    // },
                    defaults: {name: 'RaceCode'},
                    items: [
                        {
                            boxLabel: 'American Indian or Alaskan Native', inputValue: 1
                        },
                        {
                            boxLabel: 'Asian', inputValue: 2
                        },
                        {
                            boxLabel: 'Black or African American', inputValue: 3
                        },
                        {
                            boxLabel: 'Native Hawaiian or Other Pacific Islander', inputValue: 4
                        },
                        {
                            boxLabel: 'White', inputValue: 5
                        },
                        {
                            boxLabel: 'Unknown or Unable to Determine', inputValue: 6
                        }
                    ]
                },
                {
                    allowBlank: false,
                    blankText: 'Please select ethnicity',
                    fieldLabel: 'Ethnicity',
                    bind: {
                        value: '{current.childDemographic.EthnicityCode}',
                        store: '{ethnicityStore}'
                    },
                    name: 'EthnicityCode',
                    displayField: 'large',
                    valueField: 'groupId',
                    triggerAction: 'all',
                    editable: false,
                    lastQuery: '',
                    forceSelection: true

                },
                {
                    bind: '{current.childDemographic.DateOfBirth}',
                    xtype: 'datefield',//neeed to restrict format
                    fieldLabel: 'Date of Birth',
                    allowBlank: false,
					blankText: 'Please specify date of birth',
                    name: 'DateOfBirth',
                    maxValue: new Date()

                },
                {
                    bind: {
                        value: '{current.childDemographic.GenderCode}',
                        store: '{genderStore}'
                    },
                    name: 'GenderCode',
                    allowBlank: false,
                    blankText: 'Please select gender',
                    fieldLabel: 'Gender',
                    displayField: 'large',
                    valueField: 'groupId',
                    editable: false,
                    triggerAction: 'all',
                    lastQuery: '',
                    forceSelection: true
                },
                {
                    bind: {
                        value: '{current.childDemographic.IsInterviewedCheck}'
                    },
                    name: 'IsInterviewed',
                    labelSeparator: '',
                    xtype: 'checkbox',
                    boxLabel: 'Is Interviewed',
                    inputValue: 1,
                    uncheckedValue: 2
                }
            ],
            dockedItems: [
                {
                    xtype: 'toolbar',
                    dock: 'bottom',
                    ui: 'footer',
                    items: ['->', {
						text: 'Update & Add More',
						ui: 'soft-green',
						iconCls: 'x-fa fa-save',
						type:'addnew',
					//	reference: 'childDemographicSaveButton',
						formBind: true,
						handler: 'onSaveChildDemographic'
					}, {
						text: 'Add/Update',
						ui: 'soft-green',
                        type:'add',
						iconCls: 'x-fa fa-save',
						reference: 'childDemographicSaveButton',
						formBind: true,
						handler: 'onSaveChildDemographic'
					}, {
						text: 'Cancel',
                        ui: 'gray',
                        iconCls: 'x-fa fa-close',
                        handler: 'onCancelChildDemographic'
                    }]
                }]

        }
    ]

});