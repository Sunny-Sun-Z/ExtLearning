/**
 * Created by kkora on 2/25/2018.
 */
Ext.define('QuickStart.view.casereview.irr.IrrController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.irr',
    mixins: [
        'QuickStart.mixins.Global'
    ],

    /**
     * Called when the view is created
     */
    init: function () {

    },
    onAddIrrCaseClick: function (btn) {

        var me = this,
            win = me.getView().down('#irrWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = Ext.create('QuickStart.model.BaseLookup');

        win.show(btn);
        form.reset();
        form.isValid();
        vm.set('current.irr', record);
    },
    onSearch: function (field) {

        var me = this,
            value = field.getValue(),
            vm = me.getViewModel(),
            store = vm.getStore('irrStore'),
            filters = []
        ;

        filters.push({property: 'name', value:value});
        store.clearFilter();
        store.setFilters(filters);
    },
    onCreateIrrCase: function (btn) {
        var me = this,
            win = btn.up('window'),
            vm = me.getViewModel(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: win}),
            userID = QuickStart.util.Global.getUser().id,
            form = win.down('form').getForm(),
            data = form.getValues(),
            url = QuickStart.util.Global.getApi() + 'case/CreateIRRCase';

       // vm.getStore('cases').reload();
       // vm.getStore('users').reload();
        myMask.show();

        Ext.Ajax.request({
            url: url,
            method: 'GET',
            params: data,
            success: function (response, opts) {
                myMask.hide();
                var result = Ext.decode(response.responseText);

                if (result != null) {

                    if (result.success && !Ext.isEmpty(result.data)) {
                        //this.redirectTo('#case/' + result.data.CaseReviewRootID + '/' + result.data.CaseReviewID);
                        QuickStart.util.Global.showMessage(result.message);
                        win.close();
                        vm.getStore('irrStore').reload()
                    }
                    else if (!result.success) {
                        QuickStart.util.Global.showErrors(result.message);
                    }
                }
            },
            failure: function (response, opts) {

                myMask.hide();
                //  debugger
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });
    }
});