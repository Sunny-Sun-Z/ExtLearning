/**
 * Created by kkora on 10/12/2017.
 */

Ext.define('QuickStart.view.casereview.items.Item17', {
    extend: 'QuickStart.view.common.BaseItem',
    xtype: 'item17container',

    requires: [
        'Ext.form.CheckboxGroup',
        'Ext.layout.container.VBox',
        'Ext.panel.Panel'
    ],

    routeId: 'item17',

    items: [
        {
            title: 'Item 17: Physical Health of the Child',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.item17(),
            defaults: {
                margin: 10, disabledCls: 'disable-item'
            },
            layout: 'anchor',
            items: [
                {
                    xtype: 'component',
                    html: '<strong> Item 17 Applicable Cases:</strong><br/>'
                },
                {
                    xtype: 'component',
                    html: '<ul>' +
                    '<li>All foster care cases are applicable for an assessment of this item.</li>' +
                    '<li>In-home services cases are applicable for an assessment of this item if (1) physical/dental health issues were relevant to the reason for the agency’s involvement with the family, and/or (2) it is reasonable to expect that the agency would address physical/dental health issues given the circumstances of the case. For example, it is reasonable to expect that the agency would address physical health issues in a case in which a child is the subject of a substantiated maltreatment report of physical neglect; and there is reason to suspect that, during the period under review, the neglect may have affected the child’s physical health.</li>' +
                    '<li>In-home services cases are Not Applicable for an assessment of this item if you determine that there is no reason to expect that the agency would address physical and dental health issues for any children in the family, given the reason for agency involvement or the circumstances of the case. This "non-applicability" applies even if there is evidence in the case file that the agency has learned that the parent is effective in taking care of the children’s physical and dental health needs.</li>' +
                    '</ul>'
                },
                {
                    xtype: 'component',
                    html: '<strong> Select the appropriate response.</strong> If the response is No, the case will be rated as Not Applicable in the ratings section for this sub item.'

                },
                {
                    xtype: 'yesnoradiogroup',
                    labelAlign: 'left',
                    name: 'Item17IsApplicable',
                    bind: {
                        value: '{item17IsApplicable}',
                        disabled: '{isFosterCareCase}'
                    },
                    labelWidth: 200,
                    fieldLabel: 'Is this case applicable?'
                },
                {
                    xtype: 'fieldcontainer',
                    labelAlign: 'top',
                    fieldLabel: 'For in home services cases, indicate the name(s) of the child(ren) who were included in the assessment',
                    layout: 'hbox',
                    defaults: {
                        xtype: 'checkboxgroup', disabledCls: 'disable-item',
                        flex: 1,
                        columns: 1,
                        labelWidth: 75,
                        vertical: true,
                        items: [{}],
                        listeners: {
                            change: 'onItemParticipantChanged'
                        }
                    },
                    bind: {hidden: '{isFosterCareCase || caseReview.Item17IsApplicable != 1}'},
                    items: [{
                        defaults: {name: 'Item17ParticipantChild'},
                        name: 'Item17ParticipantChild',
                        itemId: 'item17ParticipantChild'
                    }]
                },
                {
                    xtype: 'narrativefield',
                    bind: '{caseReview.Item17Comments}'
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.Item17IsApplicable==""}',
                        html: '{error.Item17IsApplicable}'
                    }
                }]
        },
        {
            title: 'Question 17A1',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question17a1(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item17IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsAgencyAssessPhysicalHealthNeeds',
                bind: '{isAgencyAssessPhysicalHealthNeeds}',
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question17A1()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsAgencyAssessPhysicalHealthNeeds==""}',
                    html: '{error.IsAgencyAssessPhysicalHealthNeeds}'
                }
            }]
        },
        {
            title: 'Question 17A2',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question17a2(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item17IsApplicable != 1}'},
            items: [
                {
                    xtype: 'yesnonaradiogroup',
                    name: 'IsAgencyAssessDentalHealthNeeds',
                    bind: '{isAgencyAssessDentalHealthNeeds}',
                    fieldLabel: QuickStart.util.Resources.questions.wellbeing.question17A2()
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.IsAgencyAssessDentalHealthNeeds==""}',
                        html: '{error.IsAgencyAssessDentalHealthNeeds}'
                    }
                }]
        },
        {
            xtype: 'panel',
            bind: {hidden: '{caseReview.Item17IsApplicable != 1}'},
            items: [{
                title: 'A3. Physical And Dental Health Table',
                itemId: 'physicalDentalHealthGrid',
                xtype: 'physicaldentalhealthgrid',
                bind: {store: '{physicalDentalHealthStore}'},
                listeners: {
                    addrecord: 'onAddPhysicalDentalHealth',
                    editrecord: 'onEditPhysicalDentalHealth',
                    deleterecord: 'onDeletePhysicalDentalHealth'
                }
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.PhysicalDentalHealthHealths==""}',
                    html: '{error.PhysicalDentalHealthHealths}'
                }
            }]
        },
        {
            title: 'Question 17A4',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question17a4(),
            defaults: {margin: 10, disabledCls: 'disable-item'},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item17IsApplicable != 1}'},
            items: [{
                xtype: 'checkboxgroup',
                defaults: {margin: '0 0 0 10', name: 'FosterFederalCaseManagamentCriteria'},
                labelAlign: 'top',
                layout: 'vbox',
                bind: {
                    value: '{fosterFederalCaseManagamentCriteria}'
                },
                items: [
                    {
                        boxLabel: 'NA (this is an in-home services case).',
                        reference: 'fosterFederalCaseManagamentCriteriaNa',
                        disabled: true,
                        //  bind: {disabled: '{!isFosterCareCase || fosterFederalCaseManagamentCriteriaNo.checked}'},
                        inputValue: 178
                    },
                    {
                        boxLabel: 'No evidence found.',
                        reference: 'fosterFederalCaseManagamentCriteriaNo',
                        bind: {disabled: '{!isFosterCareCase || fosterFederalCaseManagamentCriteriaNa.checked}'},
                        inputValue: 179
                    },
                    {
                        boxLabel: "To the extent available and accessible, the child’s health records are up to date and included in the case file [Social Security Act § 475(1)(C)].",
                        bind: {disabled: '{!isFosterCareCase || fosterFederalCaseManagamentCriteriaNa.checked || fosterFederalCaseManagamentCriteriaNo.checked}'},
                        inputValue: 180
                    },
                    {
                        boxLabel: "The case plan addresses the issue of health and dental care needs [Social Security Act § 475(1)(C)].",
                        bind: {disabled: '{!isFosterCareCase|| fosterFederalCaseManagamentCriteriaNa.checked|| fosterFederalCaseManagamentCriteriaNo.checked}'},
                        inputValue: 181
                    },
                    {
                        boxLabel: "To the extent available and accessible, foster parents or foster care providers are provided with the child’s health records [Social Security Act § 475(5)(D)].",
                        bind: {disabled: '{!isFosterCareCase|| fosterFederalCaseManagamentCriteriaNa.checked|| fosterFederalCaseManagamentCriteriaNo.checked}'},
                        inputValue: 182
                    }
                ],
                labelSeparator: '',
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question17A4()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.FosterFederalCaseManagamentCriteria==""}',
                    html: '{error.FosterFederalCaseManagamentCriteria}'
                }
            }]
        },
        {
            title: 'Question 17B1',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question17b1(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item17IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsFosterOversightMedicationForPhysicalHealtyAppropriate',
                bind: {
                    value: '{isFosterOversightMedicationForPhysicalHealtyAppropriate}',
                    disabled: '{!isFosterCareCase}'
                },

                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question17B1()
            }]
        },
        {
            title: 'Question 17B2',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question17b2(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item17IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsAppropriateSerivcesForAllPhysicalHealthNeeds',
                bind: '{isAppropriateSerivcesForAllPhysicalHealthNeeds}',
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question17B2()
            }]
        },
        {
            title: 'Question 17B3',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question17b3(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item17IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsAppropriateServicesForAllDentalNeeds',
                bind: '{isAppropriateServicesForAllDentalNeeds}',
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question17B3()
            }]
        },

        {
            title: 'Item 17 Rating Criteria',
            xtype: 'rating',
            itemId: 'rating17',
            bind: {
              //  disabled: '{disabledItem|| caseReview.Item17IsApplicable != 1}',
				disabled: '{disabledItem}',
				overrideRatingPermission: '{overrideRatingPermission}',
                rating: '{caseReview.Item17}'
            },
            text: QuickStart.util.Resources.instructions.wellbeing.rating.item17()
        },
        {
            title: 'Item 17 - QA Notes',
            xtype: 'notepanel',
            itemId: 'item17NotePanel',
            noteType: 1,
            itemCode: 21,
            outcomeCode: 7,
            storeName: 'item17NoteStore',
            margin: '0 20 20 0',
            bind: {
                disabled: '{disabledNotes}'
            }
        },
        {
            bind: {
                hidden: '{!allowedInterviewNote}',
                disabled: '{disabledNotes}'
            },
            title: 'Item 17 - Interview Notes',
            xtype: 'notepanel',
            noteType: 2,
            itemCode: 21,
            outcomeCode: 7,
            storeName: 'item17InterviewNoteStore',
            margin: '0 20 20 0'
        }
    ],
    listeners: {
        afterrender: 'onAfterRenderItem17'
    }
});