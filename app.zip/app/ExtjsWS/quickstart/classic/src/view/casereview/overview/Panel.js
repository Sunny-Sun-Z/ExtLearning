/**
 * Created by kkora on 9/25/2017.
 */
Ext.define('QuickStart.view.casereview.overview.Panel', {
    extend: 'Ext.panel.Panel',

    xtype: 'overviewpanel',
    tpl: new Ext.XTemplate(
        '<div class="overview">',
        '<tpl for=".">',
        '<tpl if="this.isHeader(name)">',
        '<div class="header"> {name} <span class="rating">{rating:this.outcomeRatingText} {overriddenRating:this.outcomeOverrideRatingText}</span></div>',
        '<div class="subheader">{desc}</div>',
        '</tpl>',
        '<table style="width: 100%;">',
        '<tpl for="items">',
        '<tr>',
        '<td class="name"> {name:this.itemName} </td>',
        '<td class="description">{desc}</td>',
        '<td class="status"> {status:this.statusText} </td>',
        '<td class="rating"> {rating:this.ratingText} {overriddenRating:this.overrideRatingText}</td>',
        '</tr>',
        '</tpl>',
        '</table>',
        '</tpl>',

        '</div>',
        {
            isHeader: function (val) {
                return !Ext.isEmpty(val)
            },
            itemName: function (val) {
                return Ext.isEmpty(val) ? '' : val + ':';
            },
            statusText: function (val) {
                if (val == -1)
                    return '';
                switch (val) {
                    case 0:
                    case 3:
                        return '<span>Status: </span>Not Started';
                    case 1:
                        return '<span>Status: </span>Completed';
                    case 2:
                        return '<span>Status: </span>In Progress';
                    case 4:
                        return '<span>Status: </span>Not Applicable';
                    default:
                        return '';
                }
                //return '<span>Status:</span>' + ( val == 0 ? 'Not Started' : this.getLookupDataValue('ItemStatus', val, 'large'));
            },
            ratingText: function (val) {
                if (Ext.isEmpty(val))
                    return '';
                var value = '';
                switch (val) {
                    case 0:
                        return '<span>Rating: </span><i class="x-fa fa-star na">Not Yet Rated</i>';
                    case 1:
                        return '<span>Rating: </span><i class="x-fa fa-star boldFont strength"> ' + this.getLookupDataValue('ItemRating', val, 'large') + '</i>';
                    case 2:
                    case 3:
                        return '<span>Rating: </span><i class="x-fa fa-star weak">' + this.getLookupDataValue('ItemRating', val, 'large') + '</i>';                    
                    case 4:
                        //return '<span>Rating: </span><i class="x-fa fa-star weak">Unable to Rate</i>';
                        return '<span>Rating: </span><i class="x-fa fa-star">NA</i>';
                    case 5:
                        return '<span>Rating: </span><i class="x-fa fa-star weak">Not Applicable</i>';
                    default:
                        return '';
                }
            },
			outcomeRatingText: function (val) {
				if (val == -1)
					return '';
				return Ext.isEmpty(val) ? '' : val == 0 ? ' <span>Rating: </span> Not Yet Determined ' :
					val == 5 ? ' <span>Rating: </span> Not Applicable' : ' <span>Rating: </span> ' + this.getLookupDataValue('OutcomeRating', val, 'large') ;
			},
			overrideRatingText: function (val) {
				if (Ext.isEmpty(val) || val <1)
					return '';
				switch (val) {
					case 0:
						return '<br/><span>Rating override: </span><i class="x-fa fa-star na">Not Yet Rated</i>';
					case 1:
						return '<br/><span>Rating override: </span><i class="x-fa fa-star boldFont strength"> ' + this.getLookupDataValue('ItemRating', val, 'large') + '</i>';
					case 2:
					case 3:
						return '<br/><span>Rating override: </span><i class="x-fa fa-star weak">' + this.getLookupDataValue('ItemRating', val, 'large') + '</i>';
					case 4:
						return '<br/><span>Rating override: </span><i class="x-fa fa-star weak">Unable to Rate</i>';
					case 5:
						return '<br/><span>Rating override: </span><i class="x-fa fa-star weak">Not Applicable</i>';
					default:
						return '';
				}
			},

			outcomeOverrideRatingText: function (val) {
				return Ext.isEmpty(val) || val <1 ? '': '<span style="padding-left: 20px;">Rating override: </span> ' + this.getLookupDataValue('OutcomeRating', val, 'large') ;
			},
			getLookupData: function (group, groupId) {
                var store = Ext.getStore('Lookups');
                if (store) {
                    var record = store.queryRecordsBy(function (r) {
                        return r.get('group') === group && r.get('groupId') === groupId;
                    });
                    if (record && record.length > 0) {
                        return record[0].getData();
                    }
                }
                return null;
            },
            getLookupDataValue: function (group, groupId, returnValue) {
                
                if (group == 'ItemRating' && groupId == 4) {
                    return 'Unable to Rate';
                }

                var data = this.getLookupData(group, groupId);
                if (data) {
                    return data[returnValue || 'name'] || '';
                }

                return '';
            }
        }
    )
});