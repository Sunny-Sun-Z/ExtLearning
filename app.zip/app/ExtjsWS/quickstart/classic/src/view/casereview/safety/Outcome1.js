/**
 * Created by kkora on 10/19/2017.
 */
Ext.define('QuickStart.view.casereview.safety.Outcome1', {
    extend: 'QuickStart.view.common.InstructionPanel',

    xtype: 'safetyoutcome1container',

	requires: [
		'Ext.form.field.Display'
	],

	routeId: 'safetyoutcome1',

    title: 'Outcome 1: Children are, first and foremost, protected from abuse and neglect',
    text: QuickStart.util.Resources.instructions.safety.outcome1(),
    margin: '0 20 20 0',
    defaults: {margin: 10},
    items: [{
        xtype: 'component',
        html: '<strong>Item 1:</strong>  Timeliness of Initiating Investigations of Reports of Child Maltreatment<br/>What is the level of outcome achievement that best describes the extent to which this outcome is being or has been achieved, based on the rating for item 1?'

    }, {
        xtype: 'displayfield',
        labelWidth: '100%',
        fieldLabel: 'Level of Outcome Achievement',
        bind: '{caseReview.Outcome1.RatingDesc}'
    }, {
        xtype: 'displayfield',
        labelWidth: '100%',
        fieldLabel: 'Outcome Rating Override',
        bind: {
            value: '{caseReview.Outcome1.RatingDesc}',
            hidden: '{caseReview.Outcome1.OverrideRatingDesc==""}'
        }
    }]
});