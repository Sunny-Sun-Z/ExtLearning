/**
 * Created by kkora on 10/12/2017.
 */


Ext.define('QuickStart.view.casereview.items.Item8', {
    extend: 'QuickStart.view.common.BaseItem',
    xtype: 'item8container',

	requires: [
		'Ext.form.field.Display'
	],

	routeId: 'item8',
    items: [
        {
            title: 'Item 8: Visiting With Parents and Siblings in Foster Care',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.item8(),
            defaults: {
                margin: 10,
                xtype: 'radiogroup',
                labelAlign: 'top',
                layout: 'hbox',
                disabledCls: 'disable-item',

                items: [{
                    boxLabel: 'Yes',
                    inputValue: 1
                }, {
                    boxLabel: 'No',
                    inputValue: 2
                }]
            },
            layout: 'anchor',
            items: [
                {
                    xtype: 'component',
                    html: '<strong> Item 8 Applicable Cases:</strong><br/>'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability57'},
                    bind: {
                      //  disabled: '{hasSingleChildOnly && caseReview.ItemApplicability57 != null}',
                        value: '{item8Applicability57}'
                    },
                    fieldLabel: 'The child has at least one sibling in foster care who is in a different placement setting'
                },
                {
                    xtype: 'component',
                    html: '<ul><li> Cases are Not Applicable for assessment if the child has no siblings placed separately in foster care, AND any of the following apply (check Yes for any that apply and No for any that do not apply):</li></ul>'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability58'},
                    bind: '{item8Applicability58}',
                    fieldLabel: 'There is documentation in the case file indicating that contact between the child and both of his or her parents is not in the child’s best interests'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability59'},
                    bind: '{item8Applicability59}',
                    fieldLabel: 'The whereabouts of both parents are unknown despite documented concerted agency efforts to locate the parents'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability60'},
                    bind: '{item8Applicability60}',
                    fieldLabel: 'Both parents were deceased during the entire period under review'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability61'},
                    bind: '{item8Applicability61}',
                    fieldLabel: 'The parental rights of both parents remained terminated during the entire period under review'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability62'},
                    bind: '{item8Applicability62}',
                    fieldLabel: 'The only parent(s) being assessed in this item do not meet the definition of Mother/Father for this item'
                },
                {
                    xtype: 'component',
                    html: '<strong> Select the appropriate response.</strong> If the response is No, the case will be rated as Not Applicable in the ratings section for this item.'

                }, {
                    xtype: 'yesnoradiogroup',
                    labelAlign: 'left',
                    name: 'Item8IsApplicable',
                    bind: '{item8IsApplicable}',
                    labelWidth: 200,
                    fieldLabel: 'Is this case applicable?'
                }, {
                    xtype: 'component',
                    bind: {hidden: '{caseReview.Item8IsApplicable != 1}'},
                    html: 'Indicate the case participants who are included in this item as Mother and Father'
                }, {
                    xtype: 'fieldcontainer',
                    labelAlign: 'top',
                    labelSeparator: '',
                    layout: 'hbox',
                    defaults: {
                        xtype: 'checkboxgroup',
                        disabledCls: 'disable-item',
                        flex: 1,
                        columns: 1,
                        labelWidth: 75,
                        vertical: true,
                        items: [{}],
                        listeners: {
                            change: 'onItemParticipantChanged'
                        }
                    },
                    bind: {hidden: '{caseReview.Item8IsApplicable != 1}'},
                    items: [{
                        defaults: {name: 'Item8ParticipantMother'},
                        fieldLabel: 'Mother',
                        name: 'Item8ParticipantMother',
                        itemId: 'item8ParticipantMother',
                        bind: { hidden: '{!hasMotherAndOtherParticipant}' }

					}, {
						fieldLabel: 'Mother',
						xtype: 'displayfield',
						value: 'There are no case participants in Face Sheet table G2 that can be assessed as Mother',
						bind: { hidden: '{hasMotherAndOtherParticipant}' }
					}, {
                        defaults: { name: 'Item8ParticipantFather' },
                        fieldLabel: 'Father',
                        name: 'Item8ParticipantFather',
                        itemId: 'item8ParticipantFather',
                        bind: { hidden: '{!hasFatherAndOtherParticipant}' }
                    }, {
                        fieldLabel: 'Father',
						xtype: 'displayfield',
						value: 'There are no case participants in Face Sheet table G2 that can be assessed as Father',
                        bind: { hidden: '{hasFatherAndOtherParticipant}' }
                    }]

                }, {
                    xtype: 'narrativefield',
                    bind: '{caseReview.Item8Comments}'
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.Item8IsApplicable==""}',
                        html: '{error.Item8IsApplicable}'
                    }
                }]
        },
        {
            title: 'Question 8A1',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question8a1(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item8IsApplicable != 1}'},
            items: [{
                xtype: 'visitationfrequencydiogroup',
                defaults: {name: 'MotherVisitationFrequencyCode'},
                bind: {
                    disabled: '{item8ApplicabilityNoMotherParticipant}',
                    value: '{motherVisitationFrequencyCode}'
                },
                fieldLabel: QuickStart.util.Resources.questions.permanency.question8A1()
            }]
        },
        {
            title: 'Question 8A',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question8a(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item8IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsSufficientFrequencyForMotherVisitation',
                bind: {
                    disabled: '{item8ApplicabilityNoMotherParticipant}',
                    value: '{isSufficientFrequencyForMotherVisitation}'
                }, fieldLabel: QuickStart.util.Resources.questions.permanency.question8A()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsSufficientFrequencyForMotherVisitation==""}',
                    html: '{error.IsSufficientFrequencyForMotherVisitation}'
                }
            }]
        },
		{
			title: 'Question 8C',
			xtype: 'instructionpanel',
			text: QuickStart.util.Resources.instructions.permanency.question8c(),
			defaults: {margin: 10},
			layout: 'anchor',
			bind: {hidden: '{caseReview.Item8IsApplicable != 1}'},
			items: [{
				xtype: 'yesnonaradiogroup',
				name: 'IsSufficientQualityForMotherVisitation',
				bind: {
					disabled: '{item8ApplicabilityNoMotherParticipant}',
					value: '{isSufficientQualityForMotherVisitation}'
				},
				fieldLabel: QuickStart.util.Resources.questions.permanency.question8C()
			}, {
				xtype: 'component',
				cls: 'error-msg',
				bind: {
					hidden: '{error.IsSufficientQualityForMotherVisitation==""}',
					html: '{error.IsSufficientQualityForMotherVisitation}'
				}
			}]
		},

		{
            title: 'Question 8B1',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question8b1(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item8IsApplicable != 1}'},
            items: [{
                xtype: 'radiogroup',
                labelAlign: 'top',
                defaults: {margin: '0 10 0 0', name: 'FatherVisitationFrequencyCode'},
                layout: 'vbox',
                bind: {
                    disabled: '{item8ApplicabilityNoFatherParticipant}',
                    value: '{fatherVisitationFrequencyCode}'
                },
                items: [
                    {
                        boxLabel: 'NA',
                        inputValue: 1
                    },
                    {
                        boxLabel: 'More than once a week',
                        inputValue: 2
                    },
                    {
                        boxLabel: 'Once a week',
                        inputValue: 3
                    },
                    {
                        boxLabel: 'Less than once a week, but at least twice a month',
                        inputValue: 4
                    },
                    {
                        boxLabel: 'Less than twice a month, but at least once a month',
                        inputValue: 5
                    },
                    {
                        boxLabel: 'Less than once a month',
                        inputValue: 6
                    },
                    {
                        boxLabel: 'Never',
                        inputValue: 7
                    }
                ],
                labelSeparator: '',
                fieldLabel: QuickStart.util.Resources.questions.permanency.question8B1()
            }]
        },
        {
            title: 'Question 8B',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question8b(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item8IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsSufficientFrequencyForFatherVisitation',
                bind: {
                    disabled: '{item8ApplicabilityNoFatherParticipant}',
                    value: '{isSufficientFrequencyForFatherVisitation}'
                },
                fieldLabel: QuickStart.util.Resources.questions.permanency.question8B()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsSufficientFrequencyForFatherVisitation==""}',
                    html: '{error.IsSufficientFrequencyForFatherVisitation}'
                }
            }]
        },
        {
            title: 'Question 8D',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question8d(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item8IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsSufficentQualityForFatherVisitation',
                bind: {
                    disabled: '{item8ApplicabilityNoFatherParticipant}',
                    value: '{isSufficentQualityForFatherVisitation}'
                },
                fieldLabel: QuickStart.util.Resources.questions.permanency.question8D()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsSufficentQualityForFatherVisitation==""}',
                    html: '{error.IsSufficentQualityForFatherVisitation}'
                }
            }]
        },

        {
            title: 'Question 8E1',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question8e1(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item8IsApplicable != 1}'},
            items: [{
                xtype: 'visitationfrequencydiogroup',
                defaults: {name: 'SiblingVisitationFrequencyCode'},
                bind: {
                    disabled: '{item8OneChildOrPlacedWithAllSiblings}',
                    value: '{siblingVisitationFrequencyCode}'
                },
                fieldLabel: QuickStart.util.Resources.questions.permanency.question8E1()
            }]
        },
        {
            title: 'Question 8E',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question8e(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item8IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsSufficientFrequencyForSiblingVisitation',
                bind: {
                    disabled: '{item8OneChildOrPlacedWithAllSiblings}',
                    value: '{isSufficientFrequencyForSiblingVisitation}'
                },
                fieldLabel: QuickStart.util.Resources.questions.permanency.question8E()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsSufficientFrequencyForSiblingVisitation==""}',
                    html: '{error.IsSufficientFrequencyForSiblingVisitation}'
                }
            }]
        },

        {
            title: 'Question 8F',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question8f(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item8IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsSufficentQualityForSiblingVisitation',
                bind: {
                    disabled: '{item8OneChildOrPlacedWithAllSiblings}',
                    value: '{isSufficentQualityForSiblingVisitation}'
                },
                fieldLabel: QuickStart.util.Resources.questions.permanency.question8F()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsSufficentQualityForSiblingVisitation==""}',
                    html: '{error.IsSufficentQualityForSiblingVisitation}'
                }
            }]
        },

        {
            title: 'Item 8 Rating Criteria',
            xtype: 'rating',
            itemId: 'rating8',
            bind: {
               // disabled: '{disabledItem || caseReview.Item8IsApplicable != 1}',
				disabled: '{disabledItem}',
				overrideRatingPermission: '{overrideRatingPermission}',
                rating: '{caseReview.Item8}'
            },
            text: QuickStart.util.Resources.instructions.permanency.rating.item8()
        },
        {
            title: 'Item 8 - QA Notes',
            xtype: 'notepanel',
            itemId: 'item8NotePanel',
            noteType: 1,
            itemCode: 9,
            outcomeCode: 4,
            storeName: 'item8NoteStore',
            margin: '0 20 20 0',
            bind: {
                disabled: '{disabledNotes}'
            }
        },
        {
            bind: {
                hidden: '{!allowedInterviewNote}',
                disabled: '{disabledNotes}'
            },
            title: 'Item 8 - Interview Notes',
            xtype: 'notepanel',
            noteType: 2,
            itemCode: 9,
            outcomeCode: 4,
            storeName: 'item8InterviewNoteStore',
            margin: '0 20 20 0'
        }
    ],
    listeners: {
        afterrender: 'onAfterRenderItem8'
    }
});