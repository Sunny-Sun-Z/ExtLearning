/**
 * Created by kkora on 9/18/2017.
 */

Ext.define('QuickStart.view.casereview.note.Panel', {
    extend: 'Ext.panel.Panel',
    xtype: 'notepanel',
    requires: [
        'Ext.grid.plugin.Exporter'
    ],
    config: {
        type: 'ITEM',
        noteType: null,
        storeName: null,
        outcomeCode: null,
        itemCode: null
    },
    title: 'QA Notes',
    // collapsed: true,
    collapsible: true,
    titleCollapse: true,
    dockedItems: [
        {
            // bind: {                hidden: '{disabledItem}'            },
            xtype: 'toolbar',
            ui: 'footer',
            items: [
                {
                    bind: {
                        hidden: '{!allowedAddEditQANote}'
                    },
                    text: 'Create Note',
                    iconCls: 'x-fa fa-plus',
                    ui: 'dcf',
                    handler: 'onCreateNote'
                }]
        }
    ],
    cls: 'userProfile-container',
    initComponent: function () {

        var me = this;
        Ext.apply(this, {
            items: [
                {
                    hidden: true,
                    xtype: 'grid',
                    title: 'Notes',
                    bind: {
                        store: '{' + me.storeName + '}'
                    },
                    plugins: 'gridexporter',
                    listeners: {
                        // this event notifies us when the document was saved
                        documentsave: 'onDocumentSave',
                        beforedocumentsave: 'onBeforeDocumentSave',
                        dataready: 'onDataReady'
                    },
                    dockedItems: [{
                        xtype: 'toolbar',
                        ui: 'footer',

                        itemPosition: 1, // after title before collapse tool
                        items: [{
                            ui: 'default-toolbar',
                            xtype: 'button',
                            text: 'Export to ...',
                            menu: {
                                defaults: {
                                    handler: 'exportTo'
                                },
                                items: [{
                                    text: 'Excel xlsx',
                                    cfg: {
                                        type: 'excel07',
                                        ext: 'xlsx'
                                    }
                                }, {
                                    text: 'Excel xml',
                                    cfg: {
                                        type: 'excel03',
                                        ext: 'xml'
                                    }
                                }, {
                                    text: 'CSV',
                                    cfg: {
                                        type: 'csv'
                                    }
                                }, {
                                    text: 'TSV',
                                    cfg: {
                                        type: 'tsv',
                                        ext: 'csv'
                                    }
                                }, {
                                    text: 'HTML',
                                    cfg: {
                                        type: 'html'
                                    }
                                }]
                            }
                        }]
                    }],
                    columns: [
                        {
                            text: 'ItemName',
                            cls: 'content-column boldFont',
                            dataIndex: 'ItemName'
                        }, {
                            cls: 'content-column boldFont',
                            flex: 1,
                            text: 'Subject',
                            dataIndex: 'Subject',
                            renderer: function (val, meta, rec) {
                                return !Ext.isEmpty(val) ? val : 'Respond';
                            }
                        }, {
                            flex: 3,
                            text: 'Description',
                            dataIndex: 'Description'
                        }, {
                            cls: 'content-column boldFont',
                            text: 'Resolved',
                            align: 'center',
                            dataIndex: 'IsResolved',
                            renderer: 'rendererYesNoNa'
                        }, {
                            cls: 'content-column boldFont',
                            text: 'Last Modified Date',
                            dataIndex: 'LastModifiedDate',
                            flex: 1,
                            renderer: function (val, meta, rec) {
                                if (Ext.isEmpty(val))
                                    return '';
                                return Ext.Date.format(val, "M d, Y g:i:s A");
                            }
                        }, {
                            cls: 'content-column boldFont',
                            text: 'User Name',
                            dataIndex: 'Name'
                        }]
                },
                {
                    hidden: true,
                    padding:'10px 2px',
                    xtype: 'noteform'
                },
                {
                    xtype: 'notelistview',
                    userCls: 'big-100 small-100 shadow',
                    bind: {
                        store: '{' + me.storeName + '}'
                        // store: '{noteStore}'
                    },
                    // store: {
                    //     type: 'chained',
                    //     source: '{notes}',
                    //     filters: [
                    //         {property: 'OutcomeCode', value: me.OutcomeCode},
                    //         {property: 'ItemCode', value: me.ItemCode}
                    //     ]
                    // },
                    listeners: {
                        itemclick: function (me, record, item, index, e, eOpts) {

                            var target = Ext.get(e.target),
                                dom = target.dom,
                                elementType = dom.type,
                                action = dom.getAttribute('data-note-type'),
                                isRespondNote = record.get('IsResponse') == true,
                                note = this
                            ;

                            if (elementType === 'button') {
                                switch (action) {
                                    case 'delete-note':
                                        note.fireEvent(isRespondNote ? 'deleterespondnote' : 'deletenote', record, index, target, note.up('panel'));
                                        break;
                                    case 'edit-note':
                                        note.fireEvent(isRespondNote ? 'editrespondnote' : 'editnote', record, index, target, note.up('panel'));
                                        break;
                                    case 'resolved-note':
                                        note.fireEvent('resolvednote', record, index, target, note.up('panel'));
                                        break;
                                    case 'respond-note':
                                        note.fireEvent('respondnote', record, index, target, note.up('panel'));
                                        break;
                                }
                            }
                        },
                        respondnote: 'onRespondNote',
                        resolvednote: 'onResolvedNote',
                        editnote: 'onEditNote',
                        deletenote: 'onDeleteNote',
                        editrespondnote: 'onEditRespondNote',
                        deleterespondnote: 'onDeleteRespondNote'
                    }
                }
            ]
        });
        this.callParent();
    }
});