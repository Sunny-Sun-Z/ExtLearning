/**
 * Created by kkora on 9/7/2017.
 */
Ext.define('QuickStart.view.casereview.wellbeing.physicaldentalhealth.Window', {
    extend: 'QuickStart.view.common.BaseWindow',
    alias: 'widget.physicaldentalhealthwindow',
    width: 750,
    layout: 'fit',
    defaults: {
        defaultFocus: 'textfield:not([value]):focusable:not([disabled])',
        defaultButton: 'physicalDentalHealthSaveButton'
    },
    bind: {
        title: '{current.physicalDentalHealthAction} Physical And Dental Health'
    },
    scrollable: 'y',
    items: [
        {
            bodyPadding: '10 10 0 10',
            xtype: 'form',
            scrollable: 'y',
            cls: 'casereview-container',

            defaultType: 'textarea',
            defaults: {
                submitEmptyText: false,
                anchor: '100%',
                labelAlign: 'top',
                fieldLabel: ' ',
                maxLength: 500,
                enforceMaxLength: true,
                allowBlank: false,
                msgTarget: 'side'
            },
            items: [
                {
                    fieldLabel: 'Identified Physical/Dental Health Needs',
                    name: 'HealthNeeds',
                    blankText: 'You have not entered any identified mental/behavioral health needs. Please enter identified mental/behavioral health needs or enter None',
                    bind: '{current.physicalDentalHealth.HealthNeeds}'
                },
                {
                    fieldLabel: 'Services Provided',
                    name: 'ServicesProvided',
                    blankText: 'You have not entered any services provided. Please enter services provided or enter None',
                    bind: '{current.physicalDentalHealth.ServicesProvided}'
                },
                {
                    fieldLabel: 'Services Needed but Not Provided',
                    name: 'ServicesNeededNotProvided',
                    blankText: 'You have not entered any services needed but not provided. Please enter services needed but not provided or enter None',
                    bind: '{current.physicalDentalHealth.ServicesNeededNotProvided}'
                },
                {
                    xtype: 'hiddenfield',
                    name: 'HealthNeedCode',
                    allowBlank: true,
                    value: 1
                }
            ],
            dockedItems: [
                {
                    xtype: 'toolbar',
                    dock: 'bottom',
                    ui: 'footer',
                    items: ['->', {
						text: 'Update & Add More',
						ui: 'soft-green',
						iconCls: 'x-fa fa-save',
						type:'addnew',
						formBind: true,
						handler: 'onSavePhysicalDentalHealth'
					}, {
						text: 'Add/Update',
                        ui: 'soft-green',
                        iconCls: 'x-fa fa-save',
                        reference: 'physicalDentalHealthSaveButton',
                        formBind: true,
                        handler: 'onSavePhysicalDentalHealth'

                    }, {
                        text: 'Cancel',
                        ui: 'gray',
                        iconCls: 'x-fa fa-close',
                        handler: 'onCancelPhysicalDentalHealth'
                    }]
                }]
        }
    ]

});