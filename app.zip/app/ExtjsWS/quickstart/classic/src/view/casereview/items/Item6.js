/**
 * Created by kkora on 10/12/2017.
 */

Ext.define('QuickStart.view.casereview.items.Item6', {
    extend: 'QuickStart.view.common.BaseItem',
    xtype: 'item6container',
    routeId: 'item6',
    items: [
        {
            title: 'Item 6: Achieving Reunification, Guardianship, Adoption, or Other Planned Permanent Living Arrangement',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.item6(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [{
                xtype: 'component',
                html: '<strong> Item 6 Applicable Cases:</strong><br/><ul><li>All foster care cases are applicable for an assessment of this item.</li></ul>'
            }]
        },
        {
            title: 'Question 6A1',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question6a1(),
            defaults: {margin: 10, disabledCls: 'disable-item'},
            items: [{
                xtype: 'fieldcontainer',
                labelAlign: 'top',
                labelSeparator: '',
                items: [{
                    xtype: 'datefield',
                    bind: '{caseReview.ChildMostRecentFosterEntryDate}'
                }],
                fieldLabel: QuickStart.util.Resources.questions.permanency.question6A1()
            }]
        },
        {
            title: 'Question 6A2',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question6a2(),
            defaults: {margin: 10, disabledCls: 'disable-item'},
            layout: 'anchor',
            items: [{
                xtype: 'fieldcontainer',
                labelAlign: 'top',
                labelSeparator: '',
                items: [{
                    xtype: 'numberfield',
                    keyNavEnabled: false,
                    mouseWheelEnabled: false,
                    maxValue: 99,
                    minValue: 0,
                    allowDecimals: false,
                    disabled:true,
                    bind: '{caseReview.TimeInCare}'
                }],
                fieldLabel: QuickStart.util.Resources.questions.permanency.question6A2()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.TimeInCare==""}',
                    html: '{error.TimeInCare}'
                }
            }]
        },
        {
            title: 'Question 6A3',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question6a3(),
            defaults: {margin: 10, disabledCls: 'disable-item'},
            layout: 'anchor',
            items: [{
                xtype: 'fieldcontainer',
                labelAlign: 'top',
                defaults: {margin: '0 10 0 0'},
                labelSeparator: '',
                layout: 'hbox',
                items: [{
                    xtype: 'datefield',
                    bind: '{caseReview.DischargeDate}'
                }, {
                    xtype: 'checkbox',
                    inputValue: 1,
                    uncheckedValue: 2,
                    boxLabel: 'NA',
                    bind: {
                        value: '{isDischargeDateNACheck}',
                        disabled: '{caseReview.EpisodeDischargeDate}'
                    }
                }],
                fieldLabel: QuickStart.util.Resources.questions.permanency.question6A3()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.DischargeDate==""}',
                    html: '{error.DischargeDate}'
                }
            }]
        },
        {
            title: 'Question 6A4',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question6a4(),
            defaults: {margin: 10, disabledCls: 'disable-item'},
            layout: 'anchor',
            items: [{
                xtype: 'checkboxgroup',
                labelAlign: 'top',
                defaults: {margin: '0 10 0 0', name: 'PermanencyGoal1'},
                labelSeparator: '',
                layout: 'anchor',
                disabled: true,
                bind: {value: '{permanencyGoal1}'},
                items: [
                    {
                        xtype: 'component',
                        html: 'Question 6A4 is answered using data from item 5, question 5A1.<br/>Please complete item 5 to generate an answer to question 6A4.'
                    },
                    {
                        boxLabel: 'Reunification', inputValue: 127
                    },
                    {
                        boxLabel: 'Guardianship', inputValue: 128
                    },
                    {
                        boxLabel: 'Adoption', inputValue: 129
                    },
                    {
                        boxLabel: 'Other Planned Permanent Living Arrangement', inputValue: 130
                    }
                ],
                fieldLabel: QuickStart.util.Resources.questions.permanency.question6A4()
            }]
        },
        {
            title: 'Question 6B',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question6b(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [
                {
                    xtype: 'yesnonaradiogroup',
                    name: 'IsAgencyConcertedEfforts',
                    bind: {
                        disabled:'{isAgencyConcertedEffortsDisabled}',
                        value:'{isAgencyConcertedEfforts}'
					},
                    fieldLabel: QuickStart.util.Resources.questions.permanency.question6B()
                },
                {
                    xtype: 'yesnonarrativefield',
                    bind: {
                        value: '{caseReview.AgencyConcertedEffortsExplained}',
                        disabled: '{caseReview.IsAgencyConcertedEfforts != 2 }'
                    },
                    labelAlign: 'top',
                    fieldLabel: 'If No, explain any concerns in the narrative field below'
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.IsAgencyConcertedEfforts==""}',
                        html: '{error.IsAgencyConcertedEfforts}'
                    }
                }]
        },
        {
            title: 'Question 6C1',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question6c1(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [{
                xtype: 'fieldcontainer',
                labelAlign: 'top',
                labelSeparator: '',
                layout: 'anchor',
                items: [{
                    anchor: '50%',
                    xtype: 'combobox',
                    publishes: 'value',
                    fieldLabel: 'Select One',
                    labelWidth: 75,
                    bind: {
                        store: '{livingArrangementStore}',
                        value: '{livingArrangementCode}',
                        disabled: '{isNonOPPLA==true}'
                    },
                    queryMode: 'local',
                    displayField: 'medium',
                    valueField: 'code',
                    editable: false,
                    forceSelection: true
                }],
                fieldLabel: QuickStart.util.Resources.questions.permanency.question6C1()
            }, {
                xtype: 'textarea',
                anchor: '100%',
                bind: {
                    value: '{caseReview.LivingArrangementExplained}',
                    allowBlank: '{livingArrangementCode != 6}',
                    disabled: '{livingArrangementCode != 6}'
                },
                msgTarget: 'side',
                setAllowBlank: function (value) {
                    this.allowBlank = value;
                    this.isValid();
                },
                labelAlign: 'top',
                fieldLabel: 'If Other is selected, describe the child\'s permanent living arrangement.'
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.LivingArrangementCode==""}',
                    html: '{error.LivingArrangementCode}'
                }
            }]
        },
        {
            title: 'Question 6C2',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question6c2(),
            defaults: {margin: 10, disabledCls: 'disable-item'},
            layout: 'anchor',
            items: [{
                xtype: 'fieldcontainer',
                labelAlign: 'top',
                defaults: {margin: '0 10 0 0'},
                labelSeparator: '',
                layout: 'hbox',
                items: [
                    {
                        xtype: 'datefield',
                        bind: {
                            value: '{caseReview.OtherPlannedArrangementDocumentationDate}',
                            disabled: '{isNonOPPLA==true}'
                        },
                        minValue: '{targetChildDOB}',
                        maxValue: '{caseReview.ReviewCompleted}',
                        listeners: {
                            change: function (field) {
                                if (!Ext.isEmpty(field.getValue())) {
                                    var rgrp = field.up('fieldcontainer').down('#isOtherPlannedArrangement');
                                    if (rgrp)
                                        rgrp.reset();
                                }
                            }
                        }
                    },
                    {
                        xtype: 'radiogroup',
                        labelAlign: 'top',
                        publishes: 'value',
                        layout: 'hbox',
                        itemId: 'isOtherPlannedArrangement',
                        defaults: {margin: '0 10 0 0', name: 'IsOtherPlannedArrangement'},
                        bind: {
                            value: '{isOtherPlannedArrangement}',
                            disabled: '{isNonOPPLA==true}'
                        },
                        items: [{
                            boxLabel: 'NA',
                            inputValue: 1
                        }, {
                            boxLabel: 'No Date',
                            inputValue: 4
                        }]
                    }],
                fieldLabel: QuickStart.util.Resources.questions.permanency.question6C2()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.OtherPlannedArrangementDocumentationDate==""}',
                    html: '{error.OtherPlannedArrangementDocumentationDate}'
                }
            }]
        },
        {
            title: 'Question 6C',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question6c(),
            defaults: {margin: 10, disabledCls: 'disable-item'},
            layout: 'anchor',
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsOtherPlannedConcertedEffort',
                bind: {
                    value: '{isOtherPlannedConcertedEffort}',
                    disabled: '{isNonOPPLA==true}'
                },
                fieldLabel: QuickStart.util.Resources.questions.permanency.question6C()
            }, {
                xtype: 'yesnonarrativefield',
                bind: {
                    value: '{caseReview.OtherPlannedConcertedEffortExplained}',
                    disabled: '{caseReview.IsOtherPlannedConcertedEffort != 2 }'
                }
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsOtherPlannedConcertedEffort==""}',
                    html: '{error.IsOtherPlannedConcertedEffort}'
                }
            }]
        },
        {
            title: 'Item 6 Rating Criteria',
            xtype: 'rating',
            itemId: 'rating6',
            bind: {
                overrideRatingPermission: '{overrideRatingPermission}',
				disabled: '{disabledItem}',
				rating: '{caseReview.Item6}'
            },
            text: QuickStart.util.Resources.instructions.permanency.rating.item6()
        },
        {
            title: 'Item 6 - QA Notes',
            xtype: 'notepanel',
            itemId: 'item6NotePanel',
            noteType: 1,
            itemCode: 7,
            outcomeCode: 3,
            storeName: 'item6NoteStore',
            margin: '0 20 20 0',
            bind: {
                disabled: '{disabledNotes}'
            }
        },
        {
            bind: {
                hidden: '{!allowedInterviewNote}',
                disabled: '{disabledNotes}'
            },
            title: 'Item 6 - Interview Notes',
            xtype: 'notepanel',
            noteType: 2,
            itemCode: 7,
            outcomeCode: 3,
            storeName: 'item6InterviewNoteStore',
            margin: '0 20 20 0'
        }
    ]
});