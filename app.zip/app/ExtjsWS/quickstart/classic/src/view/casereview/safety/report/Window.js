/**
 * Created by kkora on 9/7/2017.
 */

Ext.define('QuickStart.view.casereview.safety.report.Window', {
    extend: 'QuickStart.view.common.BaseWindow',
    alias: 'widget.safetyreportwindow',

    requires: [
        'Ext.form.Panel',
        'Ext.form.field.*'
    ],

    width: 750,
    layout: 'fit',
   // resizable: true,
  //  maximized: false,
    // defaults: {
    //     defaultFocus: 'textfield:not([value]):focusable:not([disabled])',
    //     defaultButton: 'reportTableSaveButton'
    // },
    bind: {
        title: '{current.safetyReportAction} Safety Report'
    },
    // scrollable: 'y',
    items: [
        {
            bodyPadding: '10 10 0 10',
            xtype: 'form',
            scrollable: 'y',
            cls: 'casereview-container',
            height: 600,
            defaultType: 'fieldcontainer',
            defaults: {
                defaultFocus: 'textfield:not([value]):focusable:not([disabled])',
                defaultButton: 'safetyReportSaveButton',
                submitEmptyText: false,
                anchor: '100%',
                labelWidth: 333,
                fieldLabel: ' ',
                msgTarget: 'side'
            },
            items: [
                {
                    labelWidth: 100,
                    defaults: {
                        allowBlank: false,
                        msgTarget: 'side'
                    },
                    fieldLabel: 'Name of Child',
                    layout: 'hbox',
                    items: [
                        {
                            flex: 3,
                            xtype: 'combobox',
                            blankText: 'You have not selected the child. Please select a child who was the subject of the report.',
                            tpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '<div class="x-boundlist-item">{Name} {Age}</div>', '</tpl>'),
                            displayTpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '{Name} {Age}', '</tpl>'),
                            bind: {
                                value: '{current.safetyReport.ChildDemographicID}',
                                store: '{childDemographicStore}'
                            },
                            valueField: 'ChildDemographicID',
                            forceSelection: true,
                            editable: false,
                            queryMode: 'local'
                        },
                        {
                            margin: '0 0 0 10',
                            flex: 2,
                            bind: {
                                value: '{current.safetyReport.ReportDate}',
                                minValue: '{caseReview.ReviewStartDate}',
                                maxValue: '{caseReview.ReviewCompleted}'
                            },
                            xtype: 'datefield',
                            blankText: 'Please enter a report date that is during the PUR.',
                            fieldLabel: 'Report Date',
                            labelAlign: 'right',
                            //   maxValue: new Date(),
                            //   minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30),
                            name: 'ReportDate'
                        }]

                },

                {
                    xtype: 'checkboxgroup',
                    fieldLabel: 'Allegation',
                    labelWidth: '100%',
                    labelAlign: 'top',
                    columns: 2,
                    vertical: true,
                    reference: 'safetyReportAllegationCode',
                    defaults: {
                        name: 'SafetyReportAllegationCode', width: '100%'
                    },
                    allowBlank: false,
                    blankText: 'You have not selected an Allegation. Please select an Allegation for this report.',
                    bind: {
                        // value: '{safetyReportAllegationCode}'
                    },
                    items: [
                        {
                            boxLabel: 'Physical abuse', inputValue: 1
                        },
                        {
                            boxLabel: 'Sexual abuse', inputValue: 2
                        },
                        {
                            boxLabel: 'Emotional maltreatment', inputValue: 3
                        },
                        {
                            boxLabel: 'Neglect (not including medical neglect)', inputValue: 4
                        },
                        {
                            boxLabel: 'Medical neglect', inputValue: 5
                        },
                        {
                            boxLabel: 'Abandonment', inputValue: 6
                        },
                        {
                            boxLabel: 'Mental/physical health of parent', inputValue: 7
                        },
                        {
                            boxLabel: 'Mental/physical health of child', inputValue: 8
                        },
                        {
                            boxLabel: 'Substance abuse by parent(s)', inputValue: 9
                        },
                        {
                            boxLabel: 'Child\'s behavior', inputValue: 10
                        },
                        {
                            boxLabel: 'Substance abuse by child', inputValue: 11
                        },
                        {
                            boxLabel: 'Domestic violence in child\'s home', inputValue: 12
                        },
                        {
                            boxLabel: 'Child in juvenile justice system', inputValue: 13
                        },
                        {
                            boxLabel: 'Other (specify)', inputValue: 14, reference: 'AllegationOtherRef'
                        },
                        {
                            xtype: 'textarea',
                            height: 20,
                            maxLength: 100,
                            emptyText: 'Allegation(Other)',
                            blankText: 'For Allegation, please fill out the narrative field for a response of Other.',
                            bind: {
                                disabled: '{!AllegationOtherRef.checked}',
                                allowBlank: '{!AllegationOtherRef.checked}',
                                value: '{current.safetyReport.AllegationOther}'
                            },
                            setAllowBlank: function (value) {
                                this.allowBlank = value;
                                this.isValid();  this.up('form').isValid();
                            },
                            name: 'txt-other'
                        }
                    ]
                },
                {
                    xtype: 'combobox',
                    itemId: 'PriorityLevel',
                    name: 'PriorityLevel',
                    fieldLabel: 'Priority Level (Response Time)',
                    bind: {
                        store: '{priorityStore}',
                        value: '{current.safetyReport.PriorityLevel}'
                    },
                    displayField: 'large',
                    valueField: 'code',
                    allowBlank: false,
                    editable: false,
                    queryMode: 'local',
                    blankText: 'You have not selected Assessment or Investigation. Please select Assessment or Investigation for this report.'
                },
                {
                    xtype: 'combobox',
                    name: 'AssessmentCode',
                    fieldLabel: 'Assessment or Investigation (Intake Track)',
                    bind: {
                        store: '{assessmentTypeStore}',
                        value: '{current.safetyReport.AssessmentCode}'
                    },
                    displayField: 'large',
                    valueField: 'code',
                    allowBlank: false,
                    editable: false,
                    queryMode: 'local',
                    blankText: 'You have not selected Assessment or Investigation. Please select Assessment or Investigation for this report.'
                },
                {
                    fieldLabel: 'Date Assigned for an Investigation or Assessment',
                    defaults: {
                        allowBlank: false,
                        msgTarget: 'side',
                        flex: 1
                    },
                    layout: 'hbox',
                    items: [
                        {
                            xtype: 'datefield',
                            maxValue: new Date(),
                            //  minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30),
                            blankText: 'Please select either a date or Did not occur.',
                            minText: 'Please enter a date assigned for investigation that is on or after the report date.',
                            bind: {
                                disabled: '{isAssignedDateAssessmentAssigned.checked}',
                                allowBlank: '{isAssignedDateFaceToFaceContact.checked}',
                                minValue: '{current.safetyReport.ReportDate}',
                                value: '{current.safetyReport.DateAssessmentAssigned}'
                            },
                            setAllowBlank: function (value) {
                                this.allowBlank = value;
                                this.isValid();
								this.up('form').isValid();
                            }
                        },
                        {
                            xtype: 'checkbox',
                            labelSeparator: '',
                            boxLabel: 'Did not occur',
                            margin: '0 0 0 10',
                            name: 'IsAssigned',
                            reference: 'isAssignedDateAssessmentAssigned',
                            inputValue: 1,
                            uncheckedValue: 2,
                            bind: '{safetyReportIsAssignedCheck}',
                            listeners: {
                                change: function (field, checked) {
                                    if (checked) {
                                        field.up('fieldcontainer').down('datefield').setValue();
                                    }
                                }
                            }
                        }
                    ]
                },
                {
                    fieldLabel: 'Date Investigation or Assessment Initiated',
                    defaults: {
                        allowBlank: false,
                        msgTarget: 'side',
                        flex: 1
                    },
                    layout: 'hbox',
                    items: [
                        {
                            xtype: 'datefield',
                            maxValue: new Date(),
                            //  minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30),
                            blankText: 'Please select either a date or Did not occur.',
                            minText: 'Please enter a date investigation or assessment was initiated that is on or after the report date',
                            bind: {
                                disabled: '{isInitiatedDateAssessmentInitiated.checked}',
                                allowBlank: '{isInitiatedDateAssessmentInitiated.checked}',
                                minValue: '{current.safetyReport.DateAssessmentAssigned || current.safetyReport.ReportDate}',
                                value: '{current.safetyReport.DateAssessmentInitiated}'

                            },
                            setAllowBlank: function (value) {
                                this.allowBlank = value;
                                this.isValid();
								this.up('form').isValid();
                            }
                        },
                        {
                            xtype: 'checkbox',
                            boxLabel: 'Did not occur',
                            labelSeparator: '',
                            margin: '0 0 0 10',
                            name: 'IsInitiated',
                            reference: 'isInitiatedDateAssessmentInitiated',
                            inputValue: 1,
                            uncheckedValue: 2,
                            bind: {value: '{safetyReportIsInitiatedCheck}'},
                            listeners: {
                                change: function (field, checked) {
                                    if (checked) {
                                        field.up('fieldcontainer').down('datefield').setValue();
                                    }
                                }
                            }
                        }
                    ]
                },
                {
                    fieldLabel: 'Date of Face-to-Face Contact with Child',
                    defaults: {
                        allowBlank: false,
                        msgTarget: 'side',
                        flex: 1
                    },
                    layout: 'hbox',
                    items: [
                        {
                            xtype: 'datefield',
                            maxValue: new Date(),
                            // minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30),
                            blankText: 'Please select either a date or Did not occur.',
                            bind: {
                                disabled: '{isDateFaceToFaceContact.checked}',
                                allowBlank: '{isDateFaceToFaceContact.checked}',
                                minValue: '{current.safetyReport.DateAssessmentInitiated || current.safetyReport.ReportDate}',
                                value: '{current.safetyReport.DateFaceToFaceContact}'
                            },
                            setAllowBlank: function (value) {
                                this.allowBlank = value;
                                this.isValid();
								this.up('form').isValid();
                            }

                        },
                        {
                            xtype: 'checkbox',
                            labelSeparator: '',
                            boxLabel: 'Did not occur',
                            margin: '0 0 0 10',
                            name: 'IsFaceToFaceContact',
                            reference: 'isDateFaceToFaceContact',
                            inputValue: 1,
                            uncheckedValue: 2,
                            bind: {value: '{safetyReportIsFaceToFaceContactCheck}'},
                            listeners: {
                                change: function (field, checked) {
                                    if (checked) {
                                        field.up('fieldcontainer').down('datefield').setValue();
                                    }
                                }
                            }
                        }
                    ]
                },
                {
                    xtype: 'combobox',
                  //  editable: false,
					forceSelection: true,
					fieldLabel: 'Relationship of Alleged Perpetrator(s) to Child',
                    reference: 'perpetratorChildRelationship',
                    name: 'PerpetratorChildRelationshipCode',
                    bind: {
                        store: '{perpetratorChildRelationshipStore}',
                        value: '{current.safetyReport.PerpetratorChildRelationshipCode}'
                    },
					setAllowBlank: function (value) {
						this.allowBlank = value;
						this.isValid();
						this.up('form').isValid();
					},
					allowBlank: false,
					publishes: 'value',
                    displayField: 'large',
                    valueField: 'code',
                    blankText: 'You have not selected the Relationship of Alleged Perpetrator to Child. Please select the Relationship of Alleged Perpetrator to Child for this report',
                    queryMode: 'local'
                },
                {
                    xtype: 'textarea',
                    fieldLabel: 'Relationship of Alleged Perpetrator to Child(Other)',
                    name: 'PerpetratorChildRelationshipOther',
                    maxLength: 100,
                    height: 20,
                    enforceMaxLength: true,
                    bind: {
                        disabled: '{perpetratorChildRelationship.value != 7}',
                        allowBlank: '{perpetratorChildRelationship.value != 7}',
                        value: '{current.safetyReport.PerpetratorChildRelationshipOther}'
                    },
                    setAllowBlank: function (value) {
                        this.allowBlank = value;
                        this.isValid();
                        this.up('form').isValid();
                    },
                    blankText: 'For Relationship of Alleged Perpetrator to Child, please fill out the narrative field for a response of Other'

                },
                {
                    xtype: 'combobox',
                    fieldLabel: 'DispositionCode',
                    name: 'DispositionCode',
                    editable: false,
                    bind: {
                        store: '{dispositionStore}',
                        value: '{current.safetyReport.DispositionCode}'
                    },
					setAllowBlank: function (value) {
						this.allowBlank = value;
						this.isValid();
						this.up('form').isValid();
					},
					allowBlank: false,
					displayField: 'large',
                    valueField: 'code',
                    queryMode: 'local',
                    blankText: 'You have not selected the DispositionCode. Please select the DispositionCode of this report'

                }
            ],
            dockedItems: [
                {
                    xtype: 'toolbar',
                    dock: 'bottom',
                    ui: 'footer',
                    items: ['->', {
						text: 'Update & Add More',
						ui: 'soft-green',
						iconCls: 'x-fa fa-save',
						type:'addnew',
						formBind: true,
						handler: 'onSaveSafetyReport'

					}, {
						text: 'Add/Update',
						ui: 'soft-green',
						iconCls: 'x-fa fa-save',
						type:'add',
						reference: 'reportTableSaveButton',
						formBind: true,
						handler: 'onSaveSafetyReport'

					}, {
						text: 'Cancel',
                        ui: 'gray',
                        iconCls: 'x-fa fa-close',
                        handler: 'onCancelSafetyReport'
                    }]
                }]
        }
    ]

});