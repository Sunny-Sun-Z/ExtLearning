/**
 * Created by kkora on 9/22/2017.
 */
Ext.define('QuickStart.view.casereview.note.CaseQaNotes', {
    extend: 'QuickStart.view.casereview.note.Panel',

    alias: 'widget.caseqanotescontainer',

    requires: [
        'Ext.button.Button',
        'Ext.form.field.ComboBox',
        'Ext.toolbar.Fill'
    ],

    routeId: 'caseqanotes',
    title: 'Case QA Notes',
    scrollable: 'y',
    cls: 'casereview-container userProfile-container',
    //margin: '0 20 20 0',
    storeName: 'caseNoteStore',
    dockedItems: [
        {
            xtype: 'toolbar',
            ui: 'footer',
            items: [
                {
                    text: 'Create Note',
                    iconCls: 'x-fa fa-plus',
                    ui: 'dcf',
                    type: 'CASE',
                    handler: 'onCreateNote',
                    hidden:true,
                    bind: {
                        hidden: '{!allowedAddEditQANote}'
                    }
                },
                '->',
                {
                    xtype: 'button',
                    iconCls: 'x-fa fa-filter',
                    ui: 'gray',
                    reference: 'caseNoteFilters',
                    enableToggle: true,
                    pressed: true,
                    hidden:true,
                    bind: {
                        text: '{caseNoteFilters.pressed?"Hide Filters": "Show Filters"}'
                    }
                }]
        },
        {
            xtype: 'toolbar',
            ui: 'footer',
            bind: {hidden: '{!caseNoteFilters.pressed}'},
            defaults: {
                xtype: 'combobox',
                //  labelAlign: 'top',
                labelWidth: 60,
                editable: true,
                queryMode: 'local',
                displayField: 'name',
                valueField: 'code',
                emptyText: 'Any',
                forceSelection: true
            },
            itemId:'filterToolbar',
            items: [
                {
                    bind: {store: '{resolvedStore}'},
                    itemId: 'noteResolvedCombo',
                    fieldLabel: 'Resolved',
                    flex: 1
                },
                {
                    bind: {store: '{itemNameStore}'},
                    itemId: 'noteItemNameCombo',
                    fieldLabel: 'Item',
                    labelAlign: 'right',
                    flex: 1
                },
                {
                    bind: {store: '{userStore}'},
                    itemId: 'noteUserCombo',
                    labelAlign: 'right',
                    fieldLabel: 'Creator',
                    flex: 1
                },
                //  '->',
                {
                    xtype: 'button',
                    iconCls: 'x-fa fa-search',
                    ui: 'dcf',
                    //  text: 'Search',
                    tooltip: 'Search',
                    handler: 'onSearchNote'
                },
                {
                    xtype: 'button',
                    iconCls: 'x-fa fa-close',
                    ui: 'gray',
                    //text: 'Reset',
                    tooltip: 'Reset',
                    handler: 'onResetNote'
                }
            ]
        }
    ]

});