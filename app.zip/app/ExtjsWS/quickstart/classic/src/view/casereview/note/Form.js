/**
 * Created by kkora on 10/17/2017.
 */

Ext.define('QuickStart.view.casereview.note.Form', {
    extend: 'Ext.form.Panel',
    xtype: 'noteform',

    requires: [
        'Ext.form.field.*',
        'Ext.layout.container.HBox',
        'Ext.toolbar.Fill'
    ],

    bodyPadding: '10 10 0 10',
    defaultType: 'fieldcontainer',
    defaults: {
        submitEmptyText: false,
        anchor: '100%'
    },
    items: [
        {
            layout: 'hbox',
            itemId: 'subjectCharsContainer',
            items: [
                {
                margin: '0 10 0 0',
                xtype: 'textfield',
                fieldLabel: 'Subject',
                name: 'Subject',
                itemId: 'subject',
                maxLength: 200,
                enforceMaxLength: true,
                allowBlank: false,
                flex: 1,
                bind: '{current.note.Subject}',
                listeners: {
                    change: function (field) {
                        var label = field.getName() + 'Chars',
                            countLabel = field.up('form').down('[name=' + label + ']');
                        countLabel.setValue('<b>'+ (field.getValue().length + '/' + field.maxLength) + ' chars</b>');
                    }
                }
             },
                {
                xtype: 'displayfield',
                labelSeparator: '',
                width:100,
                name: 'SubjectChars',
                value: '0/200 chars'
            }
            ]
        },
        {
            layout: 'hbox',
            items: [
                {
                margin: '0 10 0 0',
                xtype: 'textarea',
                fieldLabel: 'Comments',
                name: 'Description',
                maxLength: 10000,
                enforceMaxLength: true,
                allowBlank: false,
                bind: '{current.note.Description}',
                flex: 1,
                listeners: {
                    change: function (field) {
                        var label = field.getName() + 'Chars',
                            countLabel = field.up('form').down('[name=' + label + ']');
                        countLabel.setValue('<b>'+ (field.getValue().length + '/' + field.maxLength) + ' chars</b>');
                    }
                }
               },
                {
                xtype: 'displayfield',
                labelSeparator: '',
                width:100,
                name: 'DescriptionChars',
                value: '0/10000 chars'
            }
            ]
        }
    ],
    dockedItems: [
        {
            xtype: 'toolbar',
            dock: 'bottom',
            ui: 'footer',
            items: ['->', {
                text: 'Add',
                ui: 'dcf',
                iconCls: 'x-fa fa-save',
                formBind: true,
                handler: 'onSaveNote'

            }, {
                text: 'Cancel',
                ui: 'gray',
                iconCls: 'x-fa fa-close',
                handler:'onCancelClick'
            }]
        }]

});