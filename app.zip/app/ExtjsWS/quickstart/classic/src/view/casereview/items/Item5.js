/**
 * Created by kkora on 10/12/2017.
 */

Ext.define('QuickStart.view.casereview.items.Item5', {
    extend: 'QuickStart.view.common.BaseItem',
    xtype: 'item5container',

    requires: [
        'Ext.panel.Panel'
    ],

    routeId: 'item5',
    items: [
        {
            title: 'Item 5: Permanency Goal for Child',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.item5(),
            defaults: {margin: 10, disabledCls: 'disable-item'},
            layout: 'anchor',
            items: [{
                xtype: 'component',
                html: '<strong> Item 5 Applicable Cases:</strong><br/><ul><li>All foster care cases are applicable for assessment of this item, unless the child has not been in foster care long enough (at least 60 days) for the agency to have developed a case plan and established a permanency goal. ' +
                'If the child has been in foster care for less than 60 days, but a permanency goal has been established, the case is applicable for assessment.</li></ul>'
            }, {
                xtype: 'component',
                html: '<strong> Select the appropriate response.</strong> If the response is No, the case will be rated as Not Applicable in the ratings section for this item.'

            }, {
                xtype: 'yesnoradiogroup',
                labelAlign: 'left',
                name: 'Item5IsApplicable',
                bind: '{item5IsApplicable}',
                labelWidth: 200,
                fieldLabel: 'Is this case applicable?'
            }, {
                xtype: 'textarea',
                flex: 1,
                anchor: '100%',
                bind: '{caseReview.Item5Comments}',
                labelAlign: 'top',
                fieldLabel: 'Provide comments in the narrative field below <strong>(Optional)</strong>'
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.Item5IsApplicable==""}',
                    html: '{error.Item5IsApplicable}'
                }
            }]
        },
        {
            xtype: 'panel',
            bind: {hidden: '{caseReview.Item5IsApplicable == 2}'},
            items: [{
                title: 'A1. Permanency Goal Table',
                xtype: 'goalgrid',
                itemId: 'goalGrid',
                bind: {store: '{goalStore}'},
                listeners: {
                    addrecord: 'onAddGoal',
                    editrecord: 'onEditGoal',
                    deleterecord: 'onDeleteGoal'
                }
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.Goals==""}',
                    html: '{error.Goals}'
                }
            }]
        },
        {
            xtype: 'panel',
            defaults: {
                margin: 10,
                xtype: 'combobox',
                queryMode: 'local',
                displayField: 'medium',
                valueField: 'codeId',
                labelWidth: 150,
                allowBlank: false,
                editable: false,
                forceSelection: true
            },
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item5IsApplicable != 1}'},
            items: [
                {
                    xtype: 'component',
                    html: '<strong>' + QuickStart.util.Resources.questions.permanency.question5A2() + '</strong>'
                },
                {
                    anchor: '50%', fieldLabel: 'Permanency Goal 1',
                    disabled: true,
                    bind: {
                        store: '{permanencyGoal1Store}',
                        value: '{caseReview.Goal1Code}'
                    }
                    //
                }, {
                    anchor: '50%', fieldLabel: 'Permanency Goal 2',
                    disabled: true,
                    bind: {
                        // store: '{permanencyGoal2Store}',
                        store: '{permanencyGoal1Store}',
                        value: '{caseReview.Goal2Code}'
                    }
                }
            ]
        },
        {
            title: 'Question 5A3',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question5a3(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {
                hidden: '{caseReview.Item5IsApplicable != 1}',
                disabled: '{disabledItem || !hasGoalRows}'
            },
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsGoalSpecified',
                bind: '{isGoalSpecified}',
                fieldLabel: QuickStart.util.Resources.questions.permanency.question5A3()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsGoalSpecified==""}',
                    html: '{error.IsGoalSpecified}'
                }
            }]
        },
        {
            title: 'Question 5B',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question5b(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {
                hidden: '{caseReview.Item5IsApplicable != 1}',
                disabled: '{disabledItem || !hasGoalRows}'
            },
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'WereAllGoalsInTimelyManner',
                bind: '{wereAllGoalsInTimelyManner}',
                fieldLabel: QuickStart.util.Resources.questions.permanency.question5B()
            }, {
                xtype: 'yesnonarrativefield',
                bind: {
                    value: '{caseReview.AllGoalsInTimelyMannerExplained}',
                    disabled: '{caseReview.WereAllGoalsInTimelyManner != 2 }'
                }
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.WereAllGoalsInTimelyManner==""}',
                    html: '{error.WereAllGoalsInTimelyManner}'
                }
            }]
        },
        {
            title: 'Question 5C',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question5c(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {
                hidden: '{caseReview.Item5IsApplicable != 1}',
                disabled: '{disabledItem || !hasGoalRows}'
            },
            items: [{
                xtype: 'yesnoradiogroup',
                name: 'WereAllGoalsAppropriate',
                bind: '{wereAllGoalsAppropriate}',
                fieldLabel: QuickStart.util.Resources.questions.permanency.question5C()
            }, {
                xtype: 'yesnonarrativefield',
                bind: {
                    value: '{caseReview.AllGoalsAppropriateExplained}',
                    disabled: '{caseReview.WereAllGoalsAppropriate != 2 }'
                }
            }]
        },
        {
            title: 'Question 5D',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question5d(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {
                hidden: '{caseReview.Item5IsApplicable != 1}',
                disabled: '{disabledItem || !hasGoalRows}'
            },
            items: [{
                xtype: 'yesnoradiogroup',
                name: 'IsInFoster15OutOf22',
                bind: '{isInFoster15OutOf22}',
                fieldLabel: QuickStart.util.Resources.questions.permanency.question5D()
            }]
        },
        {
            title: 'Question 5E',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question5e(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {
                hidden: '{caseReview.Item5IsApplicable != 1}',
                disabled: '{disabledItem || !hasGoalRows}'
            },
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'MeetsTerminationOfParentalRights',
                bind: '{meetsTerminationOfParentalRights}',
                fieldLabel: QuickStart.util.Resources.questions.permanency.question5E()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.MeetsTerminationOfParentalRights==""}',
                    html: '{error.MeetsTerminationOfParentalRights}'
                }
            }]
        },
        {
            title: 'Question 5F',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question5f(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {
                hidden: '{caseReview.Item5IsApplicable != 1}',
                disabled: '{disabledItem || !hasGoalRows}'
            },
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsAgencyJointTerminationOfParentalRights',
                bind: '{isAgencyJointTerminationOfParentalRights}',
                fieldLabel: QuickStart.util.Resources.questions.permanency.question5F()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsAgencyJointTerminationOfParentalRights==""}',
                    html: '{error.IsAgencyJointTerminationOfParentalRights}'
                }
            }]
        },
        {
            title: 'Question 5G1',
            text: QuickStart.util.Resources.instructions.permanency.question5g1(),
            xtype: 'instructionpanel',
            defaults: {margin: 10, disabledCls: 'disable-item'},
            layout: 'anchor',
            bind: {
                hidden: '{caseReview.Item5IsApplicable != 1}',
                disabled: '{disabledItem || !hasGoalRows}'
            },
            items: [
                {
                    xtype: 'checkboxgroup',
                    labelAlign: 'top',
                    defaults: {margin: '0 10 0 0', name: 'TerminationExceptions'},
                    labelSeparator: '',
                    layout: 'anchor',
                    bind: {value: '{terminationExceptions}'},
                    items: [
                        {
                            boxLabel: 'NA',
                            reference: 'terminationExceptionsNA',
                            bind: {disabled: '{terminationExceptionsNo.checked}'},
                            inputValue: 138
                        },
                        {
                            boxLabel: "No exceptions apply.",
                            reference: 'terminationExceptionsNo',
                            bind: {disabled: '{terminationExceptionsNA.checked}'},
                            inputValue: 139
                        },
                        {
                            boxLabel: "(1) At the option of the state, the child is being cared for by a relative at the 15/22-month time frame.",
                            inputValue: 140,
                            bind: {disabled: '{terminationExceptionsNA.checked || terminationExceptionsNo.checked }'}
                        },
                        {
                            boxLabel: "(2) The agency documented in the case plan a compelling reason for determining that termination of parental rights would not be in the best interests of the child.",
                            inputValue: 141,
                            bind: {disabled: '{terminationExceptionsNA.checked || terminationExceptionsNo.checked }'}
                        },
                        {
                            boxLabel: "(3) The state has not provided to the family the services that the state deemed necessary for the safe return of the child to the child's home.",
                            inputValue: 142,
                            bind: {disabled: '{terminationExceptionsNA.checked || terminationExceptionsNo.checked }'}
                        }
                    ],
                    fieldLabel: QuickStart.util.Resources.questions.permanency.question5G1()
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.TerminationExceptions==""}',
                        html: '{error.TerminationExceptions}'
                    }
                }]
        },
        {
            title: 'Question 5G',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question5g(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {
                hidden: '{caseReview.Item5IsApplicable != 1}',
                disabled: '{disabledItem || !hasGoalRows}'
            },
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsExceptionForTermination',
                bind: '{isExceptionForTermination}',
                fieldLabel: QuickStart.util.Resources.questions.permanency.question5G()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsExceptionForTermination==""}',
                    html: '{error.IsExceptionForTermination}'
                }
            }]
        },
        {
            title: 'Item 5 Rating Criteria',
            xtype: 'rating',
            itemId: 'rating5',
            bind: {
               // disabled: '{disabledItem || !hasGoalRows || caseReview.Item5IsApplicable != 1}',
				disabled: '{disabledItem}',
				overrideRatingPermission: '{overrideRatingPermission}',
                rating: '{caseReview.Item5}'
            },
            text: QuickStart.util.Resources.instructions.permanency.rating.item5()
        },
        {
            title: 'Item 5 - QA Notes',
            xtype: 'notepanel',
            itemId: 'item5NotePanel',
            noteType: 1,
            itemCode: 6,
            outcomeCode: 3,
            storeName: 'item5NoteStore',
            margin: '0 20 20 0',
            bind: {
                disabled: '{disabledNotes}'
            }
        },
        {
            bind: {
                hidden: '{!allowedInterviewNote}',
                disabled: '{disabledNotes}'
            },
            title: 'Item 5 - Interview Notes',
            xtype: 'notepanel',
            noteType: 2,
            itemCode: 6,
            outcomeCode: 3,
            storeName: 'item5InterviewNoteStore',
            margin: '0 20 20 0'
        }
    ]
});