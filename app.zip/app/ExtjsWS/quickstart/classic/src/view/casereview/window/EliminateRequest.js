/**
 * Created by kkora on 10/3/2017.
 */
Ext.define('QuickStart.view.casereview.window.EliminateRequest', {
    extend: 'QuickStart.view.common.BaseWindow',
    alias: 'widget.eliminaterequestwindow',

    requires: [
        'Ext.form.FieldContainer',
        'Ext.form.FieldSet',
        'Ext.form.Panel',
        'Ext.form.field.*',
        'Ext.layout.container.Fit',
        'Ext.layout.container.HBox',
        'Ext.layout.container.VBox',
        'Ext.toolbar.Fill'
    ],

    width: 600,
    layout: 'fit',
    resizable: true,
    // y: 1,
    defaults: {
        defaultFocus: 'textfield:not([value]):focusable:not([disabled])'
    },
    title: 'CASE ELIMINATION REQUEST FORM',
    scrollable: 'y',
    items: [
        {
            xtype: 'form',
            cls: 'casereview-container',
            scrollable: 'y',
            defaults: {
                labelWidth: 140,
                margin: '0 10 10 10'
            },
            defaultType: 'checkbox',
            items: [
                {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{!current.eliminationRequest.RequestedDate}',
                        html: '<div style="text-align: center;">Case elimination has been already requested on {current.eliminationRequest.RequestedDate:date("m/d/Y")}</div>'
                    }
                },
                {
                    xtype: 'component',
                    html: '<div style="text-align: center;"><strong> ELIMINATION REQUEST REASON</strong></div>'
                },
                {
                    bind: '{current.eliminationRequest.IsIdentifyKeyIndividual}',
                    boxLabel: "The *key individuals in a case are unavailable or unwilling to be interviewed. Sufficient information and perspectives cannot be obtained from available parties.  "
                },
                {
                    margin: '0 10 0 50',
                    labelWidth: '100%',
                    labelAlign: 'top',
                    fieldLabel: '*Identify key individuals unable/unwilling to be interviewed',
                    xtype: 'textarea',
                    anchor: '100%',
                    bind: {
                        disabled: '{!current.eliminationRequest.IsIdentifyKeyIndividual}',
                        value: '{current.eliminationRequest.IdentifyKeyIndividualExplain}'
                    }
                },
                {
                    xtype: 'fieldcontainer',
                    margin: '0 10 0 50',
                    labelWidth: '100%',
                    fieldLabel: 'Identify all reasonable efforts to engage/make contact',
                    defaults: {margin: '0 0 0 25'},
                    layout: 'vbox',
                    labelAlign: 'top',
                    items: [{
                        xtype: 'checkbox',
                        bind: '{current.eliminationRequest.IsIdentifyPhoneCall}',
                        boxLabel: "Phone Calls (list dates, person contacted/attempted and results) "
                    }, {
                        fieldLabel: 'Details',
                        labelAlign: 'right',
                        width: '100%',
                        xtype: 'textarea',
                        bind: {
                            disabled: '{!current.eliminationRequest.IsIdentifyPhoneCall}',
                            value: '{current.eliminationRequest.IdentifyPhoneCallExplain}'
                        }
                    }],
                    bind: {disabled: '{!current.eliminationRequest.IsIdentifyKeyIndividual}'}
                }, {
                    margin: '0 10 0 50',
                    xtype: 'fieldcontainer',
                    labelSeparator: '',
                    layout: 'vbox',
                    defaults: {margin: '0 0 0 25'},
                    items: [{
                        xtype: 'checkbox',
                        bind: '{current.eliminationRequest.IsIdentifyLetter}',
                        boxLabel: "Letters (dates sent, results)"
                    }, {
                        width: '100%',
                        labelAlign: 'right',
                        fieldLabel: 'Details',
                        xtype: 'textarea',
                        bind: {
                            disabled: '{!current.eliminationRequest.IsIdentifyLetter}',
                            value: '{current.eliminationRequest.IdentifyLetterExplain}'
                        }
                    }],
                    bind: {disabled: '{!current.eliminationRequest.IsIdentifyKeyIndividual}'}
                }, {
                    xtype: 'fieldcontainer',
                    margin: '0 10 0 50',
                    labelSeparator: '',
                    defaults: {margin: '0 0 0 25'},
                    layout: 'vbox',
                    items: [{
                        xtype: 'checkbox',
                        bind: '{current.eliminationRequest.IsIdentifyCpsStaff}',
                        boxLabel: "Prior CPS staff engaged in attempts to contact key individuals (calls/letters)"
                    }, {
                        width: '100%',
                        labelAlign: 'right',
                        fieldLabel: 'Details',
                        xtype: 'textarea',
                        bind: {
                            disabled: '{!current.eliminationRequest.IsIdentifyCpsStaff}',
                            value: '{current.eliminationRequest.IdentifyCpsStaffExplain}'
                        }
                    }],
                    bind: {disabled: '{!current.eliminationRequest.IsIdentifyKeyIndividual}'}
                },
                {
                    bind: '{current.eliminationRequest.IsCaseAppearedMultipleTimes}',
                    boxLabel: "A case appeared multiple times in the sample, either involves siblings in foster care in separate cases or an in-home services case that was opened more than one time during a sampling period."
                }, {
                    margin: '0 10 0 50',
                    anchor: '100%',
                    fieldLabel: 'Details',
                    xtype: 'textarea',
                    bind: {
                        disabled: '{!current.eliminationRequest.IsCaseAppearedMultipleTimes}',
                        value: '{current.eliminationRequest.CaseAppearedMultipleTimesExplain}'
                    }
                }, {
                    bind: '{current.eliminationRequest.IsHomeServiceCaseDuringPUR}',
                    boxLabel: "An in-home services case open for fewer than 45 consecutive days during the period under review."
                }, {
                    margin: '0 0 0 50',
                    fieldLabel: 'Date case opened',
                    labelWidth: 140,
                    xtype: 'datefield',
                    readOnly:true,
                    bind: {
                        disabled: '{!current.eliminationRequest.IsHomeServiceCaseDuringPUR}',
                        value: '{current.eliminationRequest.HomeServiceCaseOpenedDuringPUR}'
                    }
                }, {
                    margin: '10 0 0 50',
                    fieldLabel: 'Date case closed',
                    xtype: 'datefield',
                    readOnly:true,
                    bind: {
                        disabled: '{!current.eliminationRequest.IsHomeServiceCaseDuringPUR}',
                        value: '{current.eliminationRequest.HomeServiceCaseClosedDuringPUR}'
                    }
                }, {
                    bind: '{current.eliminationRequest.IsChildEntryInFosterCare}',
                    boxLabel: "An in-home case in which any child in the family was in foster care for more than 24 hours during PUR."
                }, {
                    margin: '0 0 0 50',
                    fieldLabel: 'Date entry into care',
                    xtype: 'datefield',
                    readOnly:true,
                    bind: {
                        disabled: '{!current.eliminationRequest.IsChildEntryInFosterCare}',
                        value: '{current.eliminationRequest.ChildEntryInFosterCareDate}'
                    }
                }, {
                    bind: '{current.eliminationRequest.IsFosterCareCaseClosed}',
                    boxLabel: "A foster care case was closed according to agency policy before the sample period began."
                }, {
                    margin: '0 0 0 50',
                    fieldLabel: 'Date case closed',
                    xtype: 'datefield',
                    readOnly:true,
                    bind: {
                        disabled: '{!current.eliminationRequest.IsFosterCareCaseClosed}',
                        value: '{current.eliminationRequest.FosterCareCaseClosedDate}'
                    }
                }, {
                    bind: '{current.eliminationRequest.IsTargetChildTurned18}',
                    boxLabel: "The target child reached the age of majority before the period under review."
                }, {
                    margin: '0 0 0 50',
                    fieldLabel: 'Date child turned 18',
                    xtype: 'datefield',
                    readOnly:true,
                    bind: {
                        disabled: '{!current.eliminationRequest.IsTargetChildTurned18}',
                        value: '{current.eliminationRequest.TargetChildTurned18Date}'
                    }
                }, {
                    bind: '{current.eliminationRequest.IsTargetChildPlacementOfAnotherState}',
                    boxLabel: "The target child is or was in the placement and care responsibility of another state, the case is being supervised through an Interstate Compact for the Placement of Children agreement."
                }, {
                    margin: '0 10 0 50',
                    fieldLabel: 'Explain',
                    xtype: 'textarea',
                    anchor: '100%',
                    bind: {
                        disabled: '{!current.eliminationRequest.IsTargetChildPlacementOfAnotherState}',
                        value: '{current.eliminationRequest.TargetChildPlacementOfAnotherStateExplain}'
                    }
                }, {
                    bind: '{current.eliminationRequest.IsChildAdoptionOrGuardianshipFinalize}',
                    boxLabel: "A foster care case in which the child’s adoption or guardianship was finalized before the period under review and the child is no longer in foster care."
                }, {
                    margin: '0 0 0 50',
                    fieldLabel: 'Date of finalization',
                    xtype: 'datefield',
                    readOnly:true,
                    bind: {
                        disabled: '{!current.eliminationRequest.IsChildAdoptionOrGuardianshipFinalize}',
                        value: '{current.eliminationRequest.ChildAdoptionOrGuardianshipDateFinalize}'
                    }
                }, {
                    margin: '10 10 0 50',
                    fieldLabel: 'Explain',
                    xtype: 'textarea',
                    anchor: '100%',
                    bind: {
                        disabled: '{!current.eliminationRequest.IsChildAdoptionOrGuardianshipFinalize}',
                        value: '{current.eliminationRequest.ChildAdoptionOrGuardianshipFinalizeExplain}'
                    }
                }, {
                    bind: '{current.eliminationRequest.IsCaseOpenForSubsidizedAdoptionOrGuardianship}',
                    boxLabel: "A case was open for subsidized adoption or guardianship payment only and not open to other services."
                }, {
                    xtype: 'fieldset',
                    title: '<strong>Initial QA Team</strong>',
                    titleAlign: 'center',
                    items: [{
                        xtype: 'checkbox',
                        bind: '{current.eliminationRequest.IsQaTeamForEliminationRequest}',
                        boxLabel: "QA Team Summary of case circumstances and rationale for elimination request."
                    }, {
                        fieldLabel: 'Explain',
                        xtype: 'textarea',
                        flex: 1,
                        anchor: '100%',
                        bind: {
                            disabled: '{!current.eliminationRequest.IsQaTeamForEliminationRequest}',
                            value: '{current.eliminationRequest.QaTeamForEliminationRequestExplain}'
                        }
                    }]
                }, {
                    xtype: 'fieldset',
                    title: '<strong>FOR STATEWIDE QA STAFF ONLY</strong>',
                    titleAlign: 'center',
                    items: [{
                        xtype: 'fieldcontainer',
                        defaults: {xtype: 'checkbox'},
                        layout: 'hbox',
                        items: [{
                            bind: '{caseMeetEliminationCriteria}',
                            boxLabel: "Case meets elimination criteria"
                        }, {
                            bind: '{caseDoesNotMeetEliminationCriteria}',
                            margin: '0 0 0 20',
                            boxLabel: "Case does not meet criteria."
                        }, {
                            labelAlign: 'right',
                            fieldLabel: 'Reason',
                            xtype: 'textarea',
                            flex: 1,
                            anchor: '100%',
                            bind: {
                                disabled: '{!caseDoesNotMeetEliminationCriteria}',
                                value: '{current.eliminationRequest.CaseMeetEliminationCriteriaReason}'
                            }
                        }]
                    }, {
                        fieldLabel: 'Date approved by Federal Team',
                        labelWidth: '100%',
                        xtype: 'datefield',
                        bind: {
                            disabled: '{!current.eliminationRequest.RequestedDate}',
                            value: '{current.eliminationRequest.ApprovedDate}'
                        }
                    }]
                }],
            dockedItems: [
                {
                    xtype: 'toolbar',
                    dock: 'bottom',
                    ui: 'footer',
                    items: [
                        {
                            xtype: 'component',
                            cls: 'error-msg',
                            bind: {
                                hidden: '{!current.eliminationRequest.ApprovedDate}',
                                html: '<div style="text-align: center;">Case elimination has been already approved on {current.eliminationRequest.ApprovedDate:date("m/d/Y")}.</div>'
                            }
                        },
                        '->', {

                            text: 'Send',
                            ui: 'soft-green',
                            iconCls: 'x-fa fa-paper-plane',
                            //    disabled: true,
                            //    formBind: true,
                            bind: {
                                disabled: '{current.eliminationRequest.EliminatedDate}'
                            },
                            handler: 'onCaseEliminateGenerateFederalRequestSubmit'

                        }, {
                            text: 'Cancel',
                            ui: 'gray',
                            iconCls: 'x-fa fa-close',
                            handler: function (btn) {
                                btn.up('window').close();
                            }
                        }]
                }
            ]
        }
    ]
});