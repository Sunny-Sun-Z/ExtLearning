/**
 * Created by kkora on 10/23/2017.
 */
Ext.define('QuickStart.view.casereview.wellbeing.OverView', {
    extend: 'QuickStart.view.casereview.overview.Panel',

    xtype: 'wellbeingoverviewcontainer',
    routeId: 'wellbeingoverview',

    title: 'Section III: Child and Family Well-Being',
    margin: '0 20 20 0',
    bind: {data: '{wellbeingSectionOverview}'}
});