/**
 * Created by kkora on 9/12/2017.
 */

Ext.define('QuickStart.view.casereview.newcase.NewCaseModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.newcase',

    requires: [
        'QuickStart.store.GroupLookups'
    ],

    stores: {
        siteStore: {
            type: 'grouplookups',
            filters: [{property: 'group', value: 'Site'}]
        },
        caseReviewQaStore: {
            type: 'grouplookups',
            filters: [{property: 'group', value: 'CaseReviewQA'}]
        },
        caseReviewSecondaryOversightStore: {
            type: 'grouplookups',
            filters: [{property: 'group', value: 'CaseReviewSecondaryOversight'}]
        },
        users: {
            model: 'QuickStart.model.BaseLookup',
            autoLoad: true,
            filters: [{ property: 'name', value: '' }],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'lookup/GetAllUsers'
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },
        reviewers: {
            type: 'chained',
            source: '{users}',
            filters: [{ property: 'IsReviewer', value: true }]
        },
        qas: {
            type: 'chained',
            source: '{users}',
            filters: [{ property: 'IsQa', value: true }]
        },
        oversights: {
            type: 'chained',
            source: '{users}',
            filters: [{ property: 'IsOversight', value: true }]
        },
        qas2: {
            type: 'chained',
            source: '{users}',
            filters: [{ property: 'IsQa', value: true }]
        },
        ctoversights: {
            type: 'chained',
            source: '{users}',
            filters: [{ property: 'IsOversight', value: true }]
        }


    },
    formulas: {
        reviewSubTypeID: {
            bind: {
                bindTo: '{caseReview.ReviewSubTypeID}'
            },
            get: function (data) {
                return {ReviewSubTypeID: data};
            },
            set: function (data) {
                this.set('caseReview.ReviewSubTypeID', data.ReviewSubTypeID);
            }
        },
        isPIPMonitored: {
            bind: {
                bindTo: '{caseReview.IsPIPMonitored}'
            },
            get: function (data) {
                return {IsPIPMonitored: data};
            },
            set: function (data) {
                this.set('caseReview.IsPIPMonitored', data.IsPIPMonitored);
            }
        },
        iRRReviewerID: {
            bind: '{caseReview.IRRReviewerID}',
            get: function (data) {
                if (Ext.isEmpty(data))
                    return null;
                var name = this.getLookupDataValue('CrSecurityUser', data);
                return Ext.isEmpty(name) ? null : name;
            }
        }
    },
    data: {
        editedItems: [],
        isSetupWindow: false,
        caseReview: null
    },
    getLookupData: function (group, groupId) {
        var store = Ext.getStore('Lookups');
        if (store) {
            var record = store.queryRecordsBy(function (r) {
                return r.get('group') === group && r.get('groupId') === groupId;
            });
            if (record && record.length > 0) {
                return record[0].getData();
            }
        }
        return null;
    },
    getLookupDataValue: function (group, groupId, returnValue) {
        var data = this.getLookupData(group, groupId);
        if (data) {
            return data[returnValue || 'name'] || '';
        }

        return '';
    }
});