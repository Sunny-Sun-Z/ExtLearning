/**
 * Created by kkora on 10/12/2017.
 */


Ext.define('QuickStart.view.casereview.items.Item11', {
    extend: 'QuickStart.view.common.BaseItem',
    xtype: 'item11container',

    requires: [
		'Ext.form.CheckboxGroup',
		'Ext.form.field.Display'
	],

    routeId: 'item11',
    items: [
        {
            title: 'Item 11: Relationship of Child in Care With Parents',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.item11(),
            defaults: {
                margin: 10,
                xtype: 'radiogroup',
                labelAlign: 'top',
                layout: 'hbox',
                disabledCls: 'disable-item',
                items: [{
                    boxLabel: 'Yes',
                    inputValue: 1
                }, {
                    boxLabel: 'No',
                    inputValue: 2
                }]
            },
            layout: 'anchor',
            items: [
                {
                    xtype: 'component',
                    html: '<strong> Item 11 Applicable Cases:</strong><br/>'
                },
                {
                    xtype: 'component',
                    html: '<ul><li>All foster care cases are applicable for assessment of this item unless any of the following apply (check Yes for any that apply and No for any that do not apply):</li></ul>'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability63'},
                    bind: '{item11Applicability63}',
                    fieldLabel: 'The parental rights for both parents remained terminated during the entire period under review'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability64'},
                    bind: '{item11Applicability64}',
                    fieldLabel: 'The child was abandoned and neither parent could be located'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability65'},
                    bind: '{item11Applicability65}',
                    fieldLabel: 'The whereabouts of both parents were not known during the entire period under review despite documented concerted agency efforts to locate both parents'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability66'},
                    bind: '{item11Applicability66}',
                    fieldLabel: 'Contact with both parents was considered to be not in the child’s best interests and this is documented in the case record'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability67'},
                    bind: '{item11Applicability67}',
                    fieldLabel: 'During the entire period under review, both parents were deceased'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability261'},
                    bind: '{item11Applicability261}',
                    fieldLabel: 'The only parent(s) being assessed in this item do not meet the definition of Mother/Father for this item'
                },
                {
                    xtype: 'component',
                    html: '<strong> Select the appropriate response.</strong> If the response is No, the case will be rated as Not Applicable in the ratings section for this item.'

                }, {
                    xtype: 'yesnoradiogroup',
                    labelAlign: 'left',
                    name: 'Item11IsApplicable',
                    bind: '{item11IsApplicable}',
                    labelWidth: 200,
                    fieldLabel: 'Is this case applicable?'
                }, {
                    xtype: 'component',
                  //  bind: {hidden: '{caseReview.Item11IsApplicable != 1}'},
                    html: 'Indicate the case participants who are included in this item as Mother and Father'
                }, {
                    xtype: 'fieldcontainer',
                    labelAlign: 'top',
                    labelSeparator: '',
                    layout: 'hbox',
                    defaults: {
                        xtype: 'checkboxgroup',
                        disabledCls: 'disable-item',
                        flex: 1,
                        columns: 1,
                        labelWidth: 75,
                        vertical: true,
                        items: [{}],
                        listeners: {
                            change: 'onItemParticipantChanged'
                        }
                    },
                  //  bind: {hidden: '{caseReview.Item11IsApplicable != 1}'},
                    items: [{
                        defaults: {name: 'Item11ParticipantMother'},
                        fieldLabel: 'Mother',
                        name: 'Item11ParticipantMother',
                        itemId: 'item11ParticipantMother',
						bind: { hidden: '{!hasMotherAndOtherParticipant}' }
                    }, {
						fieldLabel: 'Mother',
						xtype: 'displayfield',
						value: 'There are no case participants in Face Sheet table G2 that can be assessed as Mother',
						bind: { hidden: '{hasMotherAndOtherParticipant}' }
					}, {
						defaults: { name: 'Item11ParticipantFather' },
						fieldLabel: 'Father',
						name: 'Item11ParticipantFather',
						itemId: 'item11ParticipantFather',
						bind: { hidden: '{!hasFatherAndOtherParticipant}' }
					}, {
						fieldLabel: 'Father',
						xtype: 'displayfield',
						value: 'There are no case participants in Face Sheet table G2 that can be assessed as Father',
						bind: { hidden: '{hasFatherAndOtherParticipant}' }
					}]

                }, {
                    xtype: 'narrativefield',
                    bind: '{caseReview.Item11Comments}'
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.Item11IsApplicable==""}',
                        html: '{error.Item11IsApplicable}'
                    }
                }]
        },
        {
            title: 'Question 11A',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question11a(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item11IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsConcertedEffortMotherFosterRelationship',
				bind: {
					disabled: '{item11ApplicabilityNoMotherParticipant}',
					value: '{isConcertedEffortMotherFosterRelationship}'
				},
                fieldLabel: QuickStart.util.Resources.questions.permanency.question11A()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsConcertedEffortMotherFosterRelationship==""}',
                    html: '{error.IsConcertedEffortMotherFosterRelationship}'
                }
            }]
        },
        {
            title: 'Question 11A1',
            xtype: 'instructionpanel',
            defaults: {margin: 10, disabledCls: 'disable-item'},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item11IsApplicable != 1}'},
            items: [
                {
                    xtype: 'checkboxgroup',
                    labelAlign: 'top',
                    defaults: {margin: '0 10 0 0', name: 'EffortsToSupportMotherFosterRelationship'},
                    labelSeparator: '',
                    layout: 'anchor',
                    bind: {
                        disabled: '{item11ApplicabilityNoMotherParticipant}',
                        value: '{effortsToSupportMotherFosterRelationship}'
                    },
                    items: [
                        {
                            boxLabel: 'NA',
                            reference: 'effortsToSupportMotherFosterRelationshipNa',
                            inputValue: 164
                        },
                        {
                            boxLabel: 'Encouraged the mother’s participation in school activities and case conferences, attendance at doctors’ appointments with the child, or engagement in the child’s after-school or sports activities?',
                            bind: {disabled: '{effortsToSupportMotherFosterRelationshipNa.checked}'},
                            inputValue: 165
                        },
                        {
                            boxLabel: 'Provided or arranged for transportation or provided funds for transportation so that the mother could attend the child’s special activities and doctors’ appointments?',
                            bind: {disabled: '{effortsToSupportMotherFosterRelationshipNa.checked}'},
                            inputValue: 166
                        },
                        {
                            boxLabel: 'Provided opportunities for therapeutic situations to help the mother and child strengthen their relationship?',
                            bind: {disabled: '{effortsToSupportMotherFosterRelationshipNa.checked}'},
                            inputValue: 167
                        },
                        {
                            boxLabel: 'Encouraged the foster parents to provide mentoring or serve as role models to the mother to assist her in appropriate parenting?',
                            bind: {disabled: '{effortsToSupportMotherFosterRelationshipNa.checked}'},
                            inputValue: 168
                        },
                        {
                            boxLabel: 'Encouraged and facilitated contact with a mother not living in close proximity to the child?',
                            bind: {disabled: '{effortsToSupportMotherFosterRelationshipNa.checked}'},
                            inputValue: 169
                        },
                        {
                            reference: 'effortsToSupportMotherFosterRelationshipOtherRef',
                            boxLabel: 'Other (describe other concerted efforts made)',
                            bind: {disabled: '{effortsToSupportMotherFosterRelationshipNa.checked}'},
                            inputValue: 170
                        },
                        {
                            xtype: 'textarea',
                            fieldLabel: '',
                            hideLabel: true, maxLength: 100,
                            anchor: '100%',
                            bind: {
                                disabled: '{!effortsToSupportMotherFosterRelationshipOtherRef.checked}',
                                allowBlank: '{!effortsToSupportMotherFosterRelationshipOtherRef.checked}',
                                value: '{caseReview.EffortsMotherFosterOther}'
                            },
                            msgTarget: 'side',
                            setAllowBlank: function (value) {
                                this.allowBlank = value;
                                this.isValid();
                            },
                            name: 'txt-other'
                        }
                    ],
                    fieldLabel: QuickStart.util.Resources.questions.permanency.question11A1()
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.EffortsToSupportMotherFosterRelationship==""}',
                        html: '{error.EffortsToSupportMotherFosterRelationship}'
                    }
                }]
        },
        {
            title: 'Question 11B',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question11b(),
            defaults: {margin: 10, disabledCls: 'disable-item'},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item11IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsConcertedEffortFatherFosterRelationship',
				bind: {
					disabled: '{item11ApplicabilityNoFatherParticipant}',
					value: '{isConcertedEffortFatherFosterRelationship}'
				},
                fieldLabel: QuickStart.util.Resources.questions.permanency.question11B()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsConcertedEffortFatherFosterRelationship==""}',
                    html: '{error.IsConcertedEffortFatherFosterRelationship}'
                }
            }]
        },
        {
            title: 'Question 11B1',
            xtype: 'instructionpanel',
            defaults: {margin: 10, disabledCls: 'disable-item'},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item11IsApplicable != 1}'},
            items: [
                {
                    xtype: 'checkboxgroup',
                    labelAlign: 'top',
                    defaults: {margin: '0 10 0 0', name: 'EffortsToSupportFatherFosterRelationship'},
                    labelSeparator: '',
                    layout: 'anchor',
                    bind: {
                        disabled: '{item11ApplicabilityNoFatherParticipant}',
                        value: '{effortsToSupportFatherFosterRelationship}'
                    },
                    items: [
                        {
                            boxLabel: 'NA',
                            reference: 'effortsToSupportFatherFosterRelationshipNA',
                            inputValue: 171
                        },
                        {
                            boxLabel: 'Encouraged the mother’s participation in school activities and case conferences, attendance at doctors’ appointments with the child, or engagement in the child’s after-school or sports activities?',
                            bind: {disabled: '{effortsToSupportFatherFosterRelationshipNA.checked}'},
                            inputValue: 172
                        },
                        {
                            boxLabel: 'Provided or arranged for transportation or provided funds for transportation so that the mother could attend the child’s special activities and doctors’ appointments?',
                            bind: {disabled: '{effortsToSupportFatherFosterRelationshipNA.checked}'},
                            inputValue: 173
                        },
                        {
                            boxLabel: 'Provided opportunities for therapeutic situations to help the mother and child strengthen their relationship?',
                            bind: {disabled: '{effortsToSupportFatherFosterRelationshipNA.checked}'},
                            inputValue: 174
                        },
                        {
                            boxLabel: 'Encouraged the foster parents to provide mentoring or serve as role models to the mother to assist her in appropriate parenting?',
                            bind: {disabled: '{effortsToSupportFatherFosterRelationshipNA.checked}'},
                            inputValue: 175
                        },
                        {
                            boxLabel: 'Encouraged and facilitated contact with a mother not living in close proximity to the child?',
                            bind: {disabled: '{effortsToSupportFatherFosterRelationshipNA.checked}'},
                            inputValue: 176
                        },
                        {
                            reference: 'effortsToSupportFatherFosterRelationshipOtherRef',
                            boxLabel: 'Other (describe other concerted efforts made)',
                            bind: {disabled: '{effortsToSupportFatherFosterRelationshipNA.checked}'},
                            inputValue: 177
                        },
                        {
                            xtype: 'textarea',
                            fieldLabel: '',
                            hideLabel: true, maxLength: 100,
                            anchor: '100%',
                            bind: {
                                disabled: '{!effortsToSupportFatherFosterRelationshipOtherRef.checked}',
                                allowBlank: '{!effortsToSupportFatherFosterRelationshipOtherRef.checked}',
                                value: '{caseReview.EffortFatherFosterRelationshipOther}'
                            },
                            msgTarget: 'side',
                            setAllowBlank: function (value) {
                                this.allowBlank = value;
                                this.isValid();
                            },
                            name: 'txt-other'
                        }
                    ],
                    fieldLabel: QuickStart.util.Resources.questions.permanency.question11B1()
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.EffortsToSupportFatherFosterRelationship==""}',
                        html: '{error.EffortsToSupportFatherFosterRelationship}'
                    }
                }]
        },
        {
            title: 'Item 11 Rating Criteria',
            xtype: 'rating',
            itemId: 'rating11',
            bind: {
               // disabled: '{disabledItem||caseReview.Item11IsApplicable != 1}',
				disabled: '{disabledItem}',
				overrideRatingPermission: '{overrideRatingPermission}',
                rating: '{caseReview.Item11}'
            },
            text: QuickStart.util.Resources.instructions.permanency.rating.item11()
        },
        {
            title: 'Item 11 - QA Notes',
            xtype: 'notepanel',
            itemId: 'item11NotePanel',
            noteType: 1,
            itemCode: 12,
            outcomeCode: 4,
            storeName: 'item11NoteStore',
            margin: '0 20 20 0',
            bind: {
                disabled: '{disabledNotes}'
            }
        },
        {
            bind: {
                hidden: '{!allowedInterviewNote}',
                disabled: '{disabledNotes}'
            },
            title: 'Item 11 - Interview Notes',
            xtype: 'notepanel',
            noteType: 2,
            itemCode: 12,
            outcomeCode: 4,
            storeName: 'item11InterviewNoteStore',
            margin: '0 20 20 0'
        }
    ],
    listeners: {
        afterrender: 'onAfterRenderItem11'
    }
});