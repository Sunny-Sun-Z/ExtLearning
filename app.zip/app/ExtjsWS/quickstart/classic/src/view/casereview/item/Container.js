/**
 * Created by kkora on 9/22/2017.
 */
Ext.define('QuickStart.view.casereview.item.Container', {
    extend: 'Ext.Container',

    xtype: 'itemcontainer',

    requires: [
        'Ext.button.Button',
        'Ext.button.Segmented',
        'Ext.toolbar.Fill',
        'QuickStart.view.casereview.CaseInfo',
        'QuickStart.view.casereview.Setup',
        'QuickStart.view.casereview.item.CaseContainer'
    ],

    region: 'center',
    flex: 4,
    title: 'center',
    defaults: {
        xtype: 'panel'
    },
    layout: 'border',
    // cls: 'wizards',
    items: [
        {
            // margin: '0 20 0 20',
            region: 'north',
            cls: 'readonly',
            hidden: true,
            itemId: 'readOnlyPanel',
            title: 'READ ONLY CASE',
            titleAlign: 'center'
        },
        {
            // hidden:true,
            cls: 'wizardtwo shadow',
            // colorScheme: 'soft-purple',
            margin: '0 20 0 20',
            region: 'north',
            bind: {
                disabled: '{caseReview.CaseStatusCode==6}',
                title: 'Case: {caseReview.CaseName} ({caseReview.CaseID})'
            },
            disabledCls: 'disable-item',
            maskOnDisable: false,
            header: {
                padding: '5 10',
                items: [
                    {
                        xtype: 'tbfill'
                    },
                    {
                        xtype: 'button',
                        ui: 'dcf',
                        margin: '0 5 5 0',
                        iconCls: 'x-fa fa-arrow-left',
                        handler: 'onCaseStatusUpdate',
                        hidden: true,
                        direction: 'prev',
                        bind: {
                            text: '{qaWorkflowBackwardText}',
                            hidden: '{qaWorkflowBackwardText=="" || !canReturnToQaReviewer}'
                        }
                    },
                    {
                        xtype: 'button',
                        ui: 'dcf',
                        margin: '0 5 5 0',
                        iconCls: 'x-fa fa-arrow-right',
                        iconAlign: 'right',
                        handler: 'onCaseStatusUpdate',
                        hidden: true,
                        direction: 'next',
                        bind: {
                            text: '{qaWorkflowForwardText}',
                            hidden: '{qaWorkflowForwardText=="" || !canParticipateFurtherInQA}'
                        }
                    },
                    {
                        xtype: 'button',
                        text: 'Case Setup',
                        ui: 'dcf',
                        margin: '0 5 5 0',
                        iconCls: 'x-fa fa-wrench',
                        handler: 'onCaseSetup',
                        hidden: true,
                        bind: {
                            hidden: '{caseStatusReadOnly || !allowedEditCaseSetup }'
                        }
                    },
                    {
                        xtype: 'button',
                        text: 'Eliminate Case',
                        ui: 'soft-red',
                        margin: '0 5 5 0',
                        iconCls: 'x-fa fa-trash',
                        handler: 'onCaseEliminate',
                        hidden: true,
                        bind: {
                            hidden: '{!requestApproveElimination || disabledItem}'
                        }
                    },
                    {
                        xtype: 'button',
                        text: 'Save Case/Notes',
                        ui: 'soft-green',
                        margin: '0 5 5 0',
                        iconCls: 'x-fa fa-save',
                        handler: 'onCaseUpdate',
                        hidden: true,
                        bind: {hidden: '{!enabledSave}'}
                    },
                    {
                        xtype: 'splitbutton',
                        ui: 'dcf',
                        margin: '0 5 5 0',
                        iconCls: 'x-fa fa-file-pdf',
                        handler: 'onCaseExport',
                        text: 'Export',
                        hidden: true,
                        format: 'PDF',
                        bind: { hidden: '{!allowedExport}' },
                        menu: [
                            {
                                iconCls: 'x-fa fa-file-pdf',
                                format: 'PDF',
                                text:'Export PDF',
                                handler: 'onCaseExport'
                            },
                            {
                                iconCls: 'x-fa fa-file-excel',
                                format: 'EXCEL',
                                text: 'Export EXCEL',
                                handler: 'onCaseExport'
                            },
                            {
                                iconCls: 'x-fa fa-file-word',
                                format: 'WORD',
                                text: 'Export WORD',
                                handler: 'onCaseExport'
                            }
                        ]
                    },
                    {
                        hidden: true,
                        xtype: 'button',
                        text: 'Preview',
                        ui: 'soft-purple',
                        margin: '0 5 5 0',
                        iconCls: 'x-fa fa-search',
                        handler: 'onCasePreview'
                    },
                    {
                        hidden: true,
                        bind: {
                            hidden: '{!enabledCaseCompare}'
                        },
                        xtype: 'button',
                        text: 'Case Compare',
                        ui: 'soft-purple',
                        margin: '0 5 5 0',
                        iconCls: 'x-fa fa-clone',
                        handler: 'onCaseComparePreview'
                    },
                    {
                        xtype: 'segmentedbutton',
                        margin: '0 0 5 20',
                        hidden: true,
                        items: [
                            {
                                iconCls: 'x-fa fa-list',
                                ui: 'dcf',
                                pressed: true,
                                tooltip: 'Flat View',
                                type: 'auto',
                                handler: 'onSwitchCaseReviewLayout'
                            },
                            {
                                ui: 'dcf',
                                iconCls: 'x-fa fa-list-alt',
                                tooltip: 'Wizard View',
                                type: 'card',
                                handler: 'onSwitchCaseReviewLayout'
                            }
                        ]

                    }
                ]
            },

            bodyPadding: 10,
            items: [{
                bind: '{caseReview}',
                xtype: 'caseinfo'
            }],
            bbar: {
                reference: 'caseProgress',
                defaultButtonUI: 'wizard-soft-purple',
                cls: 'wizardprogressbar caseprogressbar',
                defaults: {
                     flex:1,
                    disabled: true,
                    enableToggle: true,
                    iconAlign: 'right',
                    padding:'7px 10px 7px 7px',
                    iconCls: 'x-fa fa-chevron-right'
                    // iconCls: 'x-fa fa-angle-right'
                },
                padding:0,
                layout: {
                    pack: 'center'
                },
                items: [
                    {
                        statusCode: 3,
                        text: 'Not Started',
                        tooltip:'Not Started'
                    },
                    {
                        statusCode: 2,
                        //   pressed: true,
                        text: 'In Progress',
                        tooltip: 'In Progress'
                    },
                    {
                        statusCode: 1,
                        text: 'Data Entry Complete',
                        tooltip: 'Data Entry Complete'
                    },
                    {
                        statusCode: 4,
                        text: 'QA in Progress',
                        tooltip: 'QA in Progress'
                    },
                    {
                        statusCode: 5,
                        text: 'Finalized (Pending Approval)',
                        tooltip: 'Finalized (Pending Approval)'
                    },
                    {
                        hidden: true,
                        statusCode: 6,
                        text: 'Case Eliminated',
                        tooltip: 'Case Eliminated'
                    },
                    {
                        iconCls: null,
                        statusCode: 7,
                        text: 'Approved & Final',
                        tooltip: 'Approved & Final'
                    }
                ]
            }

        },
        {
            xtype: 'casecontainer',
            itemId: 'caseContainer',
            reference: 'caseContainer'
        },
        {
            xtype: 'childdemographicwindow',
            itemId: 'childDemographicWindow'
        },
        {
            xtype: 'caseparticipantwindow',
            itemId: 'caseParticipantWindow'
        },
        {
            xtype: 'eliminatewindow',
            itemId: 'eliminateWindow'
        },
        {
            xtype: 'eliminaterequestwindow',
            itemId: 'eliminateRequestWindow'
        },
        {
            xtype: 'safetyreportwindow',
            itemId: 'safetyReportWindow'
        },
        {
            xtype: 'placementwindow',
            itemId: 'placementWindow'
        },
        {
            xtype: 'goalwindow',
            itemId: 'goalWindow'
        },
        {
            xtype: 'mentalhealthwindow',
            itemId: 'mentalHealthWindow'
        },
        {
            xtype: 'physicaldentalhealthwindow',
            itemId: 'physicalDentalHealthWindow'
        },
        {
            xtype: 'educationwindow',
            itemId: 'educationWindow'
        }
    ]
});
