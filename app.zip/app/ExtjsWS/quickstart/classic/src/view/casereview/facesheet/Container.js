/**
 * Created by kkora on 9/20/2017.
 */


Ext.define('QuickStart.view.casereview.facesheet.Container', {
    extend: 'QuickStart.view.common.BaseCaseContainer',
    xtype: 'facesheetcontainer',
    requires: [
        'Ext.form.CheckboxGroup',
        'Ext.form.FieldContainer',
        'Ext.layout.container.HBox',
        'QuickStart.util.Resources',
        'QuickStart.view.casereview.note.Panel',
        'QuickStart.view.common.DateContainer',
        'QuickStart.view.common.InstructionPanel'
    ],

    margin: '0 20 20 0',
    routeId: 'facesheet',
    bind: {
       // disabled: '{disabledItem}'
    },
    disabledCls: 'disable-item',
    maskOnDisable: false,
    items: [
        {
            xtype: 'panel',
            title: 'Face Sheet',
            margin: 0
        },
        {
            itemId: 'childDemographicPanel',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.facesheet.g1ChildTable(),
            title: 'G1. Child Table',
            items: [{
                xtype: 'childdemographicgrid',
                bind: {
                    store: '{childDemographicStore}'
                },
                listeners: {
                    addrecord: 'onAddChildDemographic',
                    editrecord: 'onEditChildDemographic',
                    deleterecord: 'onDeleteChildDemographic'
                }
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.ChildDemographics==""}',
                    html: '{error.ChildDemographics}'
                }
            }]
        },
        {
            itemId: 'caseParticipantPanel',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.facesheet.g2CaseParticipantTable(),
            title: 'G2. Case Participant Table',
            items: [{
                xtype: 'caseparticipantgrid',
                bind: {
                    store: '{caseParticipantStore}'
                },
                listeners: {
                    addrecord: 'onAddCaseParticipant',
                    editrecord: 'onEditCaseParticipant',
                    deleterecord: 'onDeleteCaseParticipant'
                }
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.CaseParticipants==""}',
                    html: '{error.CaseParticipants}'
                }
            }]
        },
        {
            itemId: 'questionHPanel',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.facesheet.questionH(),
            title: 'Question H',
            defaults: {margin: 10},
            items: [{
                bind: {
                    disabled: '{!hasDemographicAndParticipantRows}',
                    value: '{isCaseOpenReasonOtherAbuseNeglect}'
                },
                xtype: 'yesnoradiogroup',
                name: 'IsCaseOpenReasonOtherAbuseNeglect',
                labelSeparator: '',
                fieldLabel: QuickStart.util.Resources.questions.facesheet.questionH()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsCaseOpenReasonOtherAbuseNeglect==""}',
                    html: '{error.IsCaseOpenReasonOtherAbuseNeglect}'
                }
            }]
        },
        {
            itemId: 'questionIPanel',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.facesheet.questionI(),
            title: 'Question I',
            defaults: {margin: 10,disabledCls: 'disable-item'},
            items: [{
                xtype: 'fieldcontainer',
                labelWidth: '100%',
                labelAlign: 'top',
                layout: 'hbox',
                defaults: { margin: '0 20 0 0',  msgTarget: 'side' },
                bind: {disabled: '{!hasDemographicAndParticipantRows}'},
                items: [{
                    xtype: 'datefield',
                    bind: {
                        value: '{caseReview.FirstCaseOpeningDate}',
                        // minValue:'{caseReview.ReviewStartDate}',
                        maxValue: '{caseReview.ReviewCompleted}'
                    }
                }],
                labelSeparator: '',
                fieldLabel: QuickStart.util.Resources.questions.facesheet.questionI()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.FirstCaseOpeningDate==""}',
                    html: '{error.FirstCaseOpeningDate}'
                }
            }]
        },
        {
            itemId: 'questionJPanel',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.facesheet.questionJ(),
            title: 'Question J',
            defaults: {margin: 10,disabledCls: 'disable-item'},
            items: [{
                xtype: 'fieldcontainer',
                labelWidth: '100%',
                labelAlign: 'top',
                layout: 'hbox',
                defaults: {margin: '0 20 0 0', msgTarget: 'side'},
                bind: {
                    disabled: '{!hasDemographicAndParticipantRows}'
                },
                items: [{
                    xtype: 'datefield',
                    bind: {
                        disabled: '{isHomeServiceCase}', //home service
                        minValue: '{caseReview.FirstCaseOpeningDate}',
                        maxValue: '{caseReview.ReviewCompleted}',
                        value: '{caseReview.FosterEntryDate}'
                    }
                }, {
                    xtype: 'checkbox',
                    inputValue: 1,
                    uncheckedValue: 2,
                    boxLabel: 'NA',
                    bind: {
                        disabled: '{isHomeServiceCase ||isFosterCareCase}',
                        value: '{isFosterEntryDateNA}'
                    }
                }],
                labelSeparator: '',
                fieldLabel: QuickStart.util.Resources.questions.facesheet.questionJ()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.FosterEntryDate==""}',
                    html: '{error.FosterEntryDate}'
                }
            }]
        },
        {
            itemId: 'questionKPanel',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.facesheet.questionK(),
            title: 'Question K',
            defaults: {margin: 10,disabledCls: 'disable-item'},
            items: [{
                xtype: 'fieldcontainer',
                labelWidth: '100%',
                labelAlign: 'top',
                layout: 'hbox',
                defaults: {margin: '0 20 0 0', msgTarget: 'side'},
                bind: {
                    disabled: '{!hasDemographicAndParticipantRows}'
                },
                items: [
                    {
                        xtype: 'datefield',
                        bind: {
                            disabled: '{!hasDemographicAndParticipantRows || isHomeServiceCase}', //home service
                            value: '{caseReview.EpisodeDischargeDate}',
                            maxValue: '{caseReview.ReviewCompleted}'
                        }
                    }, {
                        xtype: 'checkbox',
                        inputValue: 1,
                        uncheckedValue: 2,
                        boxLabel: 'NA',
                        bind: {
                            disabled: '{isHomeServiceCase || isFosterCareCase}', //isHomeServiceCase or FosterCareCase
                            value: '{isEpisodeDischargeDateNA}'
                        }
                    }, {
                        xtype: 'checkbox',
                        inputValue: 1,
                        uncheckedValue: 2,
                        boxLabel: 'Not Yet Discharged',
                        bind: {
                            disabled: '{!hasDemographicAndParticipantRows || isHomeServiceCase}', //home service
                            value: '{isEpisodeNotYetDischarged}'
                        }
                    }],
                //fieldLabel: 'What is the date of discharge from foster care for the most recent foster care episode?'
                labelSeparator: '',
                fieldLabel: QuickStart.util.Resources.questions.facesheet.questionK()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.EpisodeDischargeDate==""}',
                    html: '{error.EpisodeDischargeDate}'
                }
            }]

        },
        {
            itemId: 'questionLPanel',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.facesheet.questionL(),
            title: 'Question L',
            defaults: {margin: 10,disabledCls: 'disable-item'},
            items: [{
                xtype: 'fieldcontainer',
                labelWidth: '100%',
                labelAlign: 'top',
                layout: 'hbox',
                defaults: { margin: '0 20 0 0',  msgTarget: 'side' },
                bind: {
                    disabled: '{!hasDemographicAndParticipantRows}'
                },
                items: [{
                    xtype: 'datefield',
                    maxValue: new Date(),
                    bind: {
                        minValue: '{caseReview.FosterEntryDate}',
                        maxValue: '{caseReview.ReviewCompleted}',
                        value: '{caseReview.CaseClosureDate}'
                    }
                }, {
                    xtype: 'checkbox',
                    inputValue: 1,
                    uncheckedValue: 2,
                    bind: '{isCaseClosureNotClosed}',
                    boxLabel: 'Case not closed by time of review'
                }],
                //fieldLabel: 'What is the date of the most recent case closure during the period under review?'
                labelSeparator: '',
                fieldLabel: QuickStart.util.Resources.questions.facesheet.questionL()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.CaseClosureDate==""}',
                    html: '{error.CaseClosureDate}'
                }
            }]
        },
        {
            itemId: 'questionMPanel',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.facesheet.questionM(),
            title: 'Question M',
            defaults: {margin: 10,disabledCls: 'disable-item'},
            items: [
                //     {
                //     xtype: 'checkboxstoregroup',
                //     fieldLabel: 'Why was/were the case(s) opened for services?',
                //     labelSeparator: '',
                //     labelWidth: '100%',
                //     labelAlign: 'top',
                //     columns: 2,
                //     vertical: true,
                //     defaults: {
                //         width: '100%'
                //     },
                //     labelField: 'name',
                //     valueField: 'code',
                //     itemId: 'questionM',
                //     store: 'CaseReasonLookups',
                //     //  store:'Lookups',
                //     allowOther: true,
                //    // value:[1,2,3],
                //     bind: {
                //         value1:'{caseReview.CaseReasons}'
                //     },
                //     name: 'questionM',
                //     fieldName: 'questionM'
                // }

                {
                    xtype: 'checkboxgroup',
                    //fieldLabel: 'Why was/were the case(s) opened for services?',
                    fieldLabel: QuickStart.util.Resources.questions.facesheet.questionM(),
                    labelSeparator: '',
                    labelWidth: '100%',
                    labelAlign: 'top',
                    columns: 2,
                    vertical: true,
                    defaults: {name: 'CaseReasons', width: '100%'},
                    labelField: 'name',
                    valueField: 'code',
                    allowOther: true,
                    bind: {
                        disabled: '{!hasDemographicAndParticipantRows}',
                        value: '{caseReasons}'
                    },
                    items: [
                        {boxLabel: 'Physical abuse', inputValue: 1},
                        {boxLabel: 'Sexual abuse', inputValue: 2},
                        {boxLabel: 'Emotional maltreatment', inputValue: 3},
                        {boxLabel: 'Neglect (not including medical neglect)', inputValue: 4},
                        {boxLabel: 'Medical neglect', inputValue: 5},
                        {boxLabel: 'Abandonment', inputValue: 6},
                        {boxLabel: 'Mental/physical health of parent', inputValue: 7},
                        {boxLabel: 'Mental/physical health of child', inputValue: 8},
                        {boxLabel: 'Substance abuse by parent(s)', inputValue: 9},
                        {boxLabel: 'Child\'s behavior', inputValue: 10},
                        {boxLabel: 'Substance abuse by child', inputValue: 11},
                        {boxLabel: 'Domestic violence in child\'s home', inputValue: 12},
                        {boxLabel: 'Child in juvenile justice system', inputValue: 13},
                        {boxLabel: 'Other (specify)', reference: 'CaseReasonOtherRef', inputValue: 14},
                        {
                            xtype: 'textarea',
                            maxLength: 100,
                            msgTarget: 'side',
                            bind: {
                                disabled: '{!CaseReasonOtherRef.checked}',
                                value: '{caseReview.OtherCaseReason}',
                                allowBlank: '{!CaseReasonOtherRef.checked}'
                            },
                            blankText:'For question M, please fill out the narrative field for a response of Other.',
                            setAllowBlank: function (value) {
                                this.allowBlank = value;
                                this.isValid();
                            },
                            name: 'txt-other'
                        }
                    ]
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.CaseReasons==""}',
                        html: '{error.CaseReasons}'
                    }
                }]

        },
        {
            itemId: 'notePanel',
            xtype: 'notepanel',
            title: 'Face Sheet - QA Notes',
            noteType: 1,
            itemCode: 23,
            outcomeCode: 21,
            storeName: 'faceSheetNoteStore'
        },
        {
            bind: { hidden: '{!allowedInterviewNote}' },
            xtype: 'notepanel',
            title: 'Face Sheet - Interview Notes',
            noteType: 2,
            itemCode: 23,
            outcomeCode: 21,
            storeName: 'faceSheetInterviewNoteStore'
        }

    ],
    getValue: function () {
        var childDemographicPanel = this.down('#childDemographicPanel'),
            caseParticipantPanel = this.down('#caseParticipantPanel'),
            childDemographicValues = [], caseParticipantValues = [],
            grid
        ;
        if (childDemographicPanel) {
            grid = childDemographicPanel.down('grid');
            childDemographicValues = grid.getValue();
        }

        if (caseParticipantPanel) {
            grid = caseParticipantPanel.down('grid');
            caseParticipantValues = grid.getValue();
        }

        var record = this.getRecord();

        if (record) {
            var fs = record.get('FaceSheet');
            var caseReasons = [];
            Ext.each(record.get('CaseReasons'), function (item) {
                caseReasons.push({
                    GroupName: 'CaseReason',
                    DataState: 0,
                    AnswerCode: 1,
                    CodeDescriptionID: item
                })
            });
            Ext.apply(fs, {
                DataState: 0,
                CR_CaseParticipant_Collection: caseParticipantValues,
                CR_ChildDemographic_Collection: childDemographicValues,
                EpisodeDischargeDate: record.get('EpisodeDischargeDate'),
                FirstCaseOpeningDate: record.get('FirstCaseOpeningDate'),
                CaseClosureDate: record.get('CaseClosureDate'),
                FosterEntryDate: record.get('FosterEntryDate'),
                IsCaseClosureNotClosed: record.get('IsCaseClosureNotClosed'),
                IsCaseOpenReasonOtherAbuseNeglect: record.get('IsCaseOpenReasonOtherAbuseNeglect'),
                IsEpisodeDischargeDateNA: record.get('IsEpisodeDischargeDateNA'),
                IsEpisodeNotYetDischarged: record.get('IsEpisodeNotYetDischarged'),
                IsFosterEntryDateNA: record.get('IsFosterEntryDateNA'),
                OtherCaseReason: record.get('OtherCaseReason'),
                // IsEpisodeNotYetDischarged: record.get('IsEpisodeNotYetDischarged'),
                CaseReasons: caseReasons
            });
        }
        return fs;
    }
});