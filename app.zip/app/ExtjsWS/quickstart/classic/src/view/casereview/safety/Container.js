/**
 * Created by kkora on 9/22/2017.
 */
Ext.define('QuickStart.view.casereview.safety.Container', {
    extend: 'QuickStart.view.common.BaseCaseContainer',

    xtype: 'safetycontainer',

    requires: [],

    routeId: 'safety',

    items: [
        // {
        //     title: 'Section I: Safety',
        //     xtype: 'overviewpanel',
        //     margin: '0 20 20 0',
        //     bind: {data: '{safetySection1Overview}'}
        // },
        {xtype: 'safetyoverviewcontainer', margin: '0 20 20 0'},

        {xtype: 'safetyoutcome1container', margin: '0 20 20 0'},
        {title: 'Item 1', xtype: 'item1container'},
        {xtype: 'safetyoutcome2container', margin: '0 20 20 0'},
        {title: 'Item 2', xtype: 'item2container'},
        {title: 'Item 3', xtype: 'item3container'}

    ],
    getValue: function () {
        var childDemographicPanel = this.down('#childDemographicPanel'),
            caseParticipantPanel = this.down('#caseParticipantPanel'),
            childDemographicValues = [], caseParticipantValues = [],
            grid
        ;
        if (childDemographicPanel) {
            grid = childDemographicPanel.down('grid');
            childDemographicValues = grid.getValue();
        }

        if (caseParticipantPanel) {
            grid = caseParticipantPanel.down('grid');
            caseParticipantValues = grid.getValue();
        }

        var record = this.getRecord();

        if (record) {
            var fs = record.get('FaceSheet');
            var caseReasons = [];
            Ext.each(record.get('CaseReasons'), function (item) {
                caseReasons.push({
                    GroupName: 'CaseReason',
                    DataState: 0,
                    AnswerCode: 1,
                    CodeDescriptionID: item
                })
            });
            Ext.apply(fs, {
                CR_CaseParticipant_Collection: caseParticipantValues,
                CR_ChildDemographic_Collection: childDemographicValues,
                EpisodeDischargeDate: record.get('EpisodeDischargeDate'),
                FirstCaseOpeningDate: record.get('FirstCaseOpeningDate'),
                FosterEntryDate: record.get('FosterEntryDate'),
                IsCaseClosureNotClosed: record.get('IsCaseClosureNotClosed'),
                IsCaseOpenReasonOtherAbuseNeglect: record.get('IsCaseOpenReasonOtherAbuseNeglect'),
                IsEpisodeDischargeDateNA: record.get('IsEpisodeDischargeDateNA'),
                IsEpisodeNotYetDischarged: record.get('IsEpisodeNotYetDischarged'),
                IsFosterEntryDateNA: record.get('IsFosterEntryDateNA'),
                OtherCaseReason: record.get('OtherCaseReason'),
                IsEpisodeNotYetDischarged: record.get('IsEpisodeNotYetDischarged'),
                CaseReasons: caseReasons
            });
        }
        return fs;
    }
});