/**
 * Created by kkora on 9/19/2017.
 */

Ext.define('QuickStart.view.casereview.Case', {
    extend: 'Ext.Container',

    xtype: 'case',
    requires: [
        'Ext.layout.container.Border'
    ],

    controller: 'casereview',
    viewModel: {
        type: 'casereview'
    },
    layout: 'border',
    cls: 'casereview-container',
    items: [
        {
            xtype: 'itemmenucontainer'
        },
        {
            xtype: 'itemcontainer'
        },
        {
            xtype: 'previewwindow',
            itemId: 'previewWindow'
        },
        {
            xtype: 'comparewindow',
            itemId: 'compareWindow'
        }
    ],
    listeners: {
        afterrender: 'onAfterRenderCaseReview',
        loadcase:'onLoadCase'
    }
});