/**
 * Created by kkora on 10/3/2017.
 */
Ext.define('QuickStart.view.casereview.window.Eliminate', {
    extend: 'QuickStart.view.common.BaseWindow',
    alias: 'widget.eliminatewindow',

    requires: [
        'Ext.form.Panel',
        'Ext.form.field.*',
        'Ext.layout.container.Fit',
        'Ext.toolbar.Fill'
    ],

    width: 600,
    layout: 'fit',
    resizable: true,
    defaults: {
        defaultFocus: 'textfield:not([value]):focusable:not([disabled])'
    },
    title: 'Eliminate Case',
    scrollable: 'y',
    items: [
        {
            xtype: 'form',
            scrollable: 'y',
            defaults: {
                labelAlign: 'top',
                anchor: '100%',
                margin: '0 10'
            },
            items: [
                {
                    xtype: 'combobox',
                    fieldLabel: "Reason Case Eliminated",
                    displayField: 'large',
                    editable: false,
                    valueField: 'code',
                    queryMode: 'local',
                    allowBlank: false,
                    msgTarget: 'side',
                    publishes:['value'],
                    name:'EliminationReasonCode',
                    flex: 1,
                    bind: {
                        store: '{caseEliminationReasonStore}',
                        value: '{current.elimination.EliminationReasonCode}'
                    }

                },
                {
                    xtype: 'textarea',
                    fieldLabel: "Please explain below",
                    //   fieldLabel: "If this case should not be in the sample, please explain below",
                    setAllowBlank: function (value) {
                        this.allowBlank = value;
                        this.isValid();
                    },
                    bind: {
                      //  disabled:'{!caseEliminationReason}',
                        allowBlank:'{!caseEliminationReason}',
                        value: '{current.elimination.EliminationReasonExplained}'
                    },
                    msgTarget: 'side',
                    name:'EliminationReasonExplained',
                    flex: 1
                },
                {
                    xtype: 'checkbox',
                    boxLabel: "I have reviewed the narrative above(if any) and confirm that the case elimination explanation does not contain the proper names",
                    msgTarget: 'side',
                    fieldLabel: 'QA SignOff',
                    margin: '10 10 20 10',
                    flex: 1,
                    bind: {
                        value: '{current.elimination.QaSignOff}'
                    }
                }
                ],
            dockedItems: [
                {
                    xtype: 'toolbar',
                    dock: 'bottom',
                    ui: 'footer',
                    items: [{
                        bind: {
                            // disabled:'{!hasQaPermission}'
                        },
                        text: 'Generate Federal Request',
                        ui: 'dcf',
                        iconCls: 'x-fa fa-id-card',
                        handler: 'onCaseEliminateGenerateFederalRequestClick'

                    }, '->', {
                        bind: {
                            disabled: '{!validElimination}'
                        },
                        text: 'Approve and Eliminate',
                        ui: 'soft-green',
                        iconCls: 'x-fa fa-save',
                        handler: 'onApproveCaseEliminate'

                    }, {
                        text: 'Cancel',
                        ui: 'gray',
                        iconCls: 'x-fa fa-close',
                        handler: function (btn) {
                            btn.up('window').close();
                        }
                    }]
                }
            ]
        }
    ]
});