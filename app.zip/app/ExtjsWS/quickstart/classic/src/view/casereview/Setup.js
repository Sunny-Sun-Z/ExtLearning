/**
 * Created by kkora on 9/22/2017.
 */

Ext.define('QuickStart.view.casereview.Setup', {
    extend: 'QuickStart.view.common.BaseWindow',
    requires: [
        'QuickStart.view.casereview.newcase.Form'
    ],

    alias: 'widget.casereviewsetup',
    width: 800,
    height: 700,
    layout: 'fit',
    resizable: true,
    maximized:true,
    // maximizable:true,
   // y: 1,
    constrain : true,
    defaults: {
        defaultFocus: 'textfield:not([value]):focusable:not([disabled])'
    },
    bind: {
        title: 'Case Setup: Face Sheet Question A-F'
    },

    items: [
        {
            scrollable: true,
            xtype: 'casereviewform'
        }
    ]
});