/**
 * Created by kkora on 9/6/2017.
 */
Ext.define('QuickStart.view.casereview.CaseInfo', {
    extend: 'Ext.Component',
    xtype: 'caseinfo',

    tpl: [

        "<div class='caseinfo'>",
        "<div class='column'>",
        "<div><label>Case ID:</label>{CaseID}</div>",
        "<div><label>Case Name:</label>{CaseName}</div>",
        "<div><label class='status-badge-{CaseStatusCode}'>Status:</label></div>",
        "<div><label>Office Name:</label>{SiteCode:this.siteCodeText}</div>",
        "</div>",
        "<div class='column'>",
        "<div><label>Reviewer(s):</label>{CR_Reviewer_Collection:this.reviewers}</div>",
        "<div><label>Initial QA:</label>{InitialQAUserID:this.qaUser}</div>",
        "<div><label>Second Level QA:</label>{SecondQAUserID:this.qaUser}</div>",
       // '<tpl if="this.hasValue(IRRReviewerID)">',
        "<div class='{[values.IRRReviewerID === null ? 'x-hidden' : '' ]}' ><label>IRR Reviewer:</label>{IRRReviewerID:this.qaUser}</div>",
      //  "</tpl>",

        "</div>",
        "<div class='column'>",
        "<div><label>Case Type:</label>{ReviewSubTypeID:this.reviewSubType}</div>",
        "<div><label>Period under Review:</label>{ReviewStartDate:this.getDate} - {ReviewCompleted:this.getDate}</div>",
        "<div><label>Secondary Oversight:</label>{SecondaryOversightUserID:this.qaUser}</div>",
        "<div><label>CT Secondary Oversight:</label>{CtSecondaryOversightUserID:this.qaUser}</div>",
        "</div>",
        "</div>",
        {
            hasValue: function (val) {
                return !Ext.isEmpty(val);
            },
            getDate: function (val) {
                if (Ext.isEmpty(val))
                    return '';
                return Ext.Date.format(new Date(val), 'm/d/Y');
            },
            caseStatusText: function (val) {
                var data = this.getLookupData('CaseStatus', val) || {};
                return data.large || val;
            },
            reviewSubType: function (val) {
                var data = this.getLookupData('CrReviewSubType', val) || {};
                return data.name || val;
            },
            reviewType: function (val) {
                if (Ext.isEmpty(val) || val === 0)
                    return '';
                var data = this.getLookupData('CrReviewType', val) || {};
                return Ext.isEmpty(data.name) ? '' : '(<strong>' + data.name + '</strong>)';
            },
            siteCodeText: function (val) {
                var data = this.getLookupData('Site', val) || {};
                return data.medium || val;
            },
            qaUser: function (val) {
                var data = this.getLookupData('CrSecurityUser', val) || {};
                return data.name || val;
            },
            reviewers: function (val) {
                // console.log('reviewers', val)
                if (Ext.isEmpty(val))
                    return '';
                var reviewerNames = [];
                Ext.each(val, function (rev) {

                    var data = this.getLookupData('CrSecurityUser', rev.UserID);
                    if (!Ext.isEmpty(data.name))
                        reviewerNames.push(data.name);
                }, this);
                return reviewerNames.join(', ');
            },

            getLookupData: function (group, groupId) {
                var store = Ext.getStore('Lookups');

                if (store) {
                    var record = store.queryRecordsBy(function (r) {
                        return r.get('group') === group && r.get('groupId') === groupId;
                    });
                    if (record && record.length > 0) {
                        return record[0].getData();
                    }
                }
                return {};
            }
        }
    ]
});