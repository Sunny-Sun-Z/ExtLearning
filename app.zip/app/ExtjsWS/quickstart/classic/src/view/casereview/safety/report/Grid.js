/**
 * Created by kkora on 9/8/2017.
 */

Ext.define('QuickStart.view.casereview.safety.report.Grid', {
    extend: 'QuickStart.view.common.CrudGrid',
    xtype: 'safetyreportgrid',
    columns: [
        {
            xtype: 'rownumberer'
        },
        {
            menuDisabled: true,
            sortable: false,
            width: 100,
            align: 'center',
            text: 'Report Date',
            tooltip: 'Report Date',
            dataIndex: 'ReportDate',
            formatter: 'date("m/d/Y")'

        },
        {
            menuDisabled: true,
            sortable: false,
            flex: 1,
            align: 'center',
            text: 'Name of Child',
            tooltip: 'Name of Child',
            dataIndex: 'ChildDemographicID',
            renderer: 'rendererChildDemographic'

        },
        {
            menuDisabled: true,
            sortable: false,
            flex: 2,
            align: 'center',
            text: 'Allegation',
            tooltip: 'Allegation',
            cellWrap: true,
            dataIndex: 'SafetyReportAllegationCode',
            renderer: 'rendererAllegations'
        },
        {
            menuDisabled: true,
            sortable: false,
            width: 100,
            align: 'center',
            text: "Priority Level<br>(if applicable)",
            tooltip: "Priority Level (if applicable)",
            dataIndex: 'PriorityLevel',
            renderer: 'rendererPriorityLevel'
        },
        {
            menuDisabled: true,
            sortable: false,

            align: 'center',
            text: 'Assessment or Investigation',
            tooltip: 'Assessment or Investigation',
            columns: [
                {
                    menuDisabled: true,
                    sortable: false,
                    width: 120,
                    align: 'center',
                    text: 'Ass./Inv.',
                    tooltip: 'Assessment or Investigation',
                    dataIndex: 'AssessmentCode',
                    renderer: 'rendererAssessmentType'

                },
                {
                    menuDisabled: true,
                    sortable: false,
                    flex: 1,
                    align: 'center',
                    text: 'Date Assigned',
                    tooltip: 'Date Assigned',
                    dataIndex: 'DateAssessmentAssigned',
                    //  formatter: 'date("m/d/Y")',
                    renderer: 'rendererReportDate'
                },
                {
                    menuDisabled: true,
                    sortable: false,
                    flex: 1,
                    align: 'center',
                    text: "Date Initiated",
                    tooltip: "Date Initiated",
                    dataIndex: 'DateAssessmentInitiated',
                    // formatter: 'date("m/d/Y")',
                    renderer: 'rendererReportDate'
                }
            ]
        },

        {
            menuDisabled: true,
            sortable: false,
            flex: 1,
            align: 'center',
            text: 'Date Face-to-Face <br>Contact With Child',
            tooltip: 'Date Face-to-Face Contact With Child',
            dataIndex: 'DateFaceToFaceContact',
            //  formatter: 'date("m/d/Y")',
            renderer: 'rendererReportDate'

        },
        {
            menuDisabled: true,
            sortable: false,
            flex: 1,
            align: 'center',
            text: 'Relationship of <br>Alleged Perpetrator <br>to Child',
            tooltip: 'Relationship of Alleged Perpetrator to Child',
            dataIndex: 'PerpetratorChildRelationshipCode',
            renderer: 'rendererPerpetratorChildRelationship'

        },
        {
            menuDisabled: true,
            sortable: false,
            flex: 1,
            align: 'center',
            text: 'Disposition Code',
            text: 'Disposition Code',
            dataIndex: 'DispositionCode',
            renderer: 'rendererDisposition'
        }
    ],


    getValue: function () {

        var me = this,
            store = this.getStore(),
            modifiedRecords = store.getModifiedRecords(),
            records = [];
        Ext.each(modifiedRecords, function (rec) {
            var data = rec.getData();
            delete data.IsFaceToFaceContactCheck;
            delete data.IsInitiatedCheck;
            delete data.IsAssignedCheck;
            delete data.AllegationCodes;
            delete data.SafetyReportAllegationCode;
            delete data.id;
            //data.DataState = me.dataState.Added;
            if (rec.isDirty()) {
                data.DataState = me.dataState.Modified;
            }

            var allegations = data.CR_SafetyReport_Allegation_Collection;
            var tempAllegations = [];
            if (allegations && allegations.length > 0) {
                Ext.each(allegations, function (item) {
                    if (Ext.isObject(item)) {
                        tempAllegations.push({
                            SafetyReportAllegationCode: item.SafetyReportAllegationCode,
                            DataState: me.dataState.Added
                        })
                    }
                });
            }
            data.CR_SafetyReport_Allegation_Collection = tempAllegations;
            records.push(data);
        });

        return records;
    }
});