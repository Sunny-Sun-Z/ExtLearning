/**
 * Created by kkora on 9/7/2017.
 */

Ext.define('QuickStart.view.casereview.permanency.placement.Window', {
    extend: 'QuickStart.view.common.BaseWindow',

    alias: 'widget.placementwindow',
    width: 600,
    layout: 'fit',
    defaults: {
        defaultFocus: 'textfield:not([value]):focusable:not([disabled])',
        defaultButton: 'placementSaveButton'
    },
    bind: {
        title: '{current.placementAction} Placement'
    },
    scrollable: 'y',
    items: [
        {
            bodyPadding: '10 10 0 10',
            xtype: 'form',
            scrollable: 'y',
            cls: 'casereview-container',

            defaultType: 'combobox',
            defaults: {
                submitEmptyText: false,
                labelWidth: 150,
                fieldLabel: ' ',
                msgTarget: 'side'
            },
            items: [
                {
                    fieldLabel: 'Placement Date',
                    xtype: 'datefield',
                    allowBlank: false,
                    maxValue: new Date(),
                  //  minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30),
                    blankText: 'You have not selected a placement date. Please select a placement date.',
					minText:'Please enter a placement date that is on or after the date of birth [{0}] of the target child.',
					bind: {
                          value: '{current.placement.Date}',
                          minValue: '{targetChildDOB}',
                          maxValue: '{caseReview.CaseClosureDate || caseReview.ReviewCompleted}'

                    }
                },
                {
                    fieldLabel: 'Placement Type',
                    blankText: 'You have not selected a placement type. Please select a placement type.',
                   // editable: false,
					forceSelection: true,
					anchor: '100%',
                    displayField: 'large',
                    valueField: 'code',
                    allowBlank: false,
                    queryMode: 'local',
                    bind: {
                        value: '{placementTypeCode}',
                        store: '{placementTypeStore}'
                    }
                },
                {
                    fieldLabel: 'Placement Type (Other)',
                    xtype: 'textarea',
                    anchor: '100%',
                    maxLength: 100,
                    enforceMaxLength: true,
                    blankText: 'For Placement Type, please fill out the narrative field for a response of Other.',
                     bind: {
                        value: '{current.placement.TypeOther}',
                        disabled: '{placementTypeCode != 7}',
                        allowBlank: '{placementTypeCode != 7}'
                    },
                    setAllowBlank: function (value) {
                        this.allowBlank = value;
                        this.isValid();
                        this.up('form').isValid();
                    }
                },
                {
                    fieldLabel: 'Reason for Change',
                  //  editable: false,
					forceSelection: true,
					anchor: '100%',
                    displayField: 'large',
                    allowBlank: false,
                    valueField: 'code',
                    queryMode: 'local',
                    blankText: 'Please enter a Reason for Change or indicate that this is the current placement.',
                    bind: {
                        value: '{placementChangeReasonCode}',
                        store: '{placementChangeReasonStore}'
                    }
                },
                {
                    fieldLabel: 'Change Reason (Other)',
                    xtype: 'textarea',
                    anchor: '100%',
                    maxLength: 100,
                    enforceMaxLength: true,
                    blankText: 'For Reason for Change in Placement Setting, please fill out the narrative field for a response of Other.',
                    bind: {
                        value: '{current.placement.ChangeReasonOther}',
                        disabled: '{placementChangeReasonCode != 8}',
                        allowBlank: '{placementChangeReasonCode != 8}'
                    },
                    setAllowBlank: function (value) {
                        this.allowBlank = value;
                        this.isValid();
                        this.up('form').isValid();
                        console.log(value)
                    }
                }
            ],
            dockedItems: [
                {
                    xtype: 'toolbar',
                    dock: 'bottom',
                    ui: 'footer',
                    items: ['->', {
						text: 'Update & Add More',
						ui: 'soft-green',
						iconCls: 'x-fa fa-save',
						type:'addnew',
						formBind: true,
						handler: 'onSavePlacement'
					}, {
                        text: 'Add/Update',
                        ui: 'soft-green',
                        iconCls: 'x-fa fa-save',
                        reference: 'placementSaveButton',
                        formBind: true,
                        handler: 'onSavePlacement'

                    }, {
                        text: 'Cancel',
                        ui: 'gray',
                        iconCls: 'x-fa fa-close',
                        handler: 'onCancelPlacement'
                    }]
                }]
        }
    ]

});