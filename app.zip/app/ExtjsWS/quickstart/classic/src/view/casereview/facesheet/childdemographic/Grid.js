/**
 * Created by kkora on 9/8/2017.
 */
Ext.define('QuickStart.view.casereview.facesheet.childdemographic.Grid', {
    extend: 'QuickStart.view.common.CrudGrid',
    xtype: 'childdemographicgrid',
    columns: [
        {
            xtype: 'rownumberer'
        },
        {
            menuDisabled: true,
            sortable: false,
            text: 'Target Child',
            tooltip: 'Target Child',
            flex: 1,
            dataIndex: 'IsTargetChild',
            renderer: 'rendererYesNoNa'
        },
        {
            menuDisabled: true,
            sortable: false,
            text: 'Child Name',
            tooltip: 'Child Name',
            dataIndex: 'Name',
            cellWrap: true,
            flex: 2
        },
        {
            menuDisabled: true,
            sortable: false,
            text: "Race",
            tooltip: "Race",
            flex: 2,
            dataIndex: 'RaceCodes',
            cellWrap: true,
            renderer: 'rendererRaceNames'
        },
        {
            menuDisabled: true,
            sortable: false,
            text: 'Ethnicity',
            tooltip: 'Ethnicity',
            flex: 1,
            dataIndex: 'EthnicityCode',
            cellWrap: true,
            renderer: 'rendererEthnicity'
        },
        {
            menuDisabled: true,
            sortable: false,
            text: 'Date of Birth',
            tooltip: 'Date of Birth',
            dataIndex: 'DateOfBirth',
            flex: 1,
            formatter: 'date("m/d/Y")'
            //renderer: Ext.util.Format.dateRenderer('m/d/Y')
        },
        {
            menuDisabled: true,
            sortable: false,
            text: "Age on PUR completed",
            tooltip: "Age on PUR completed",
            flex: 1,
            dataIndex: 'Age'
        },
        {
            menuDisabled: true,
            sortable: false,
            text: 'Gender',
            tooltip: 'Gender',
            flex: 1,
            dataIndex: 'GenderCode',
            renderer: 'rendererGender'
        },
        {
            menuDisabled: true,
            sortable: false,
            text: 'Interviewed',
            tooltip: 'Interviewed',
            flex: 1,
            align: 'center',
            dataIndex: 'IsInterviewed',
            renderer: 'rendererYesNoNa'
        }
    ],
    getValue: function () {
        var me=this,
            store = this.getStore(),
            modifiedRecords = store.getModifiedRecords(),
            records = [];
        Ext.each(modifiedRecords, function (rec) {
            var data = rec.getData();
            delete data.IsInterviewedCheck;
            delete data.IsTargetChildCheck;
            delete data.RaceCodes;
            delete data.id;
            //data.DataState = me.dataState.Added;
            if (rec.isDirty()) {
                data.DataState = me.dataState.Modified;
            }

            var races = data.CR_ChildRace_Collection;
            var tempRaces = [];
            if (races && races.length > 0) {
                Ext.each(races, function (race) {
                    if (Ext.isObject(race)) {
                        tempRaces.push( {
                            RaceCode: race.RaceCode,
                            DataState: me.dataState.Added
                        })
                    }
                });
            }
            data.CR_ChildRace_Collection=tempRaces;
            records.push(data);
        });

        return records;
    }
});