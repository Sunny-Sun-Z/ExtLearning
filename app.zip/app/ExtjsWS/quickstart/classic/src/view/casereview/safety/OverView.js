/**
 * Created by kkora on 10/23/2017.
 */
Ext.define('QuickStart.view.casereview.safety.OverView', {
    extend: 'QuickStart.view.casereview.overview.Panel',

    xtype: 'safetyoverviewcontainer',
    routeId: 'safetyoverview',
    margin: '0 20 20 0',
    title: 'Section I: Safety',
    bind: {data: '{safetySection1Overview}'}
});