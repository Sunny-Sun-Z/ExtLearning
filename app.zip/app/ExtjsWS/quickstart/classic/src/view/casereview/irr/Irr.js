/**
 * Created by kkora on 2/25/2018.
 */
Ext.define('QuickStart.view.casereview.irr.Irr', {
    extend: 'Ext.Container',

    requires: [
        'Ext.layout.container.Fit',
        'QuickStart.view.casereview.irr.IrrController',
        'QuickStart.view.casereview.irr.IrrModel'
    ],

    xtype: 'irr',

    viewModel: {
        type: 'irr'
    },

    controller: 'irr',
    margin: 20,
    //scrollable: 'y',
    config: {
        highlightTitle: 'Create Case Review'
    },
    layout: 'fit',
    border:false,

    items: [
        {xtype:'irrgrid'},
        {
            xtype: 'irrwindow',
            itemId: 'irrWindow'
        }
    ]
});