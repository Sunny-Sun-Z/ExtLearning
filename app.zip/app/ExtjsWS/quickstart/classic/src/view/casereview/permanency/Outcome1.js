/**
 * Created by kkora on 10/19/2017.
 */
Ext.define('QuickStart.view.casereview.permanency.Outcome1', {
    extend: 'QuickStart.view.common.InstructionPanel',

    xtype: 'permanencyoutcome1container',
    routeId: 'permanencyoutcome1',
    margin: '0 20 20 0',

    title: 'Outcome 1: Children have permanency and stability in their living situations',
    text: QuickStart.util.Resources.instructions.permanency.outcome1(),
    defaults: {margin: 10},
    items: [{
        xtype: 'component',
        html: 'What is the level of outcome achievement that best describes the extent to which this outcome is being or has been achieved, based on the ratings for items 4, 5, and 6?'

    }, {
        xtype: 'displayfield',
        labelWidth: '100%',
        fieldLabel: 'Level of Outcome Achievement',
        bind: '{caseReview.Outcome3.RatingDesc}'
    }, {
        xtype: 'displayfield',
        labelWidth: '100%',
        fieldLabel: 'Outcome Rating Override',
        bind: {
            value: '{caseReview.Outcome3.RatingDesc}',
            hidden: '{caseReview.Outcome3.OverrideRatingDesc==""}'
        }
    }]
});