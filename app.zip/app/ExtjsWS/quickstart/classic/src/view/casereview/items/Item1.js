/**
 * Created by kkora on 10/16/2017.
 */

Ext.define('QuickStart.view.casereview.items.Item1', {
    extend: 'QuickStart.view.common.BaseItem',
    xtype: 'item1container',

    requires: [
        'Ext.form.RadioGroup',
        'Ext.panel.Panel'
    ],

    routeId: 'item1',

    items: [
        {
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.safety.outcome1Item1(),
            title: 'Item 1: Timeliness of Initiating Investigations of Reports of Child Maltreatment',
            defaults: { margin: 10, disabledCls: 'disable-item' },
            layout: 'anchor',
            items: [{
                xtype: 'component',
                html: '<strong> Select the appropriate response.</strong> If the response is No, the case will be rated as Not Applicable in the ratings section for this item.'

            }, {
                xtype: 'yesnoradiogroup',
                name: 'Item1IsApplicable',
                reference: 'item1IsApplicableRef',
                labelAlign: 'left',
                bind: '{item1IsApplicable}',
                labelWidth: 200,
                fieldLabel: 'Is this case applicable?'
            }, {
                xtype: 'narrativefield',
                bind: '{caseReview.Item1Comments}'
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.Item1IsApplicable==""}',
                    html: '{error.Item1IsApplicable}'
                }
            }]
        },
        {
            xtype: 'panel',
            bind: {
                hidden: '{caseReview.Item1IsApplicable != 1}',
                disabled: '{disabledItem}'
            },
            items: [{
                xtype: 'safetyreportgrid',
                itemId: 'safetyReportGrid',
                title: 'A1. Reports Table',
                bind: {
                    store: '{safetyReportStore}',
                    // disabled: '{disabledItem || caseReview.Item1IsApplicable != 1}'
                },
                listeners: {
                    addrecord: 'onAddSafetyReport',
                    editrecord: 'onEditSafetyReport',
                    deleterecord: 'onDeleteSafetyReport'
                }
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.SafetyReports==""}',
                    html: '{error.SafetyReports}'
                }
            }]
        },
        {
            xtype: 'panel',
            disabledCls: 'disable-item',
            defaults: {
                disabledCls: 'disable-item',
                margin: 10,
                xtype: 'fieldcontainer',
                labelSeparator: '',
                labelAlign: 'top'
            },
            layout: 'anchor',
            bind: {
                disabled: '{disabledItem || !hasSafetyReportRows}',
                hidden: '{caseReview.Item1IsApplicable != 1}'
            },
            items: [
                {
                    items: [{
                        xtype: 'combobox',
                        minChars: 0,
                       // typeAhead: true,
                      //  forceSelection: true,
                        publishes: 'value',
                        reference: 'reportsNotInAccordance',
                        valueField: 'id',
                        displayField: 'id',
                        bind: {
                            store: '{numberTableStore}',
                            value: '{caseReview.ReportsNotInAccordance}'
                        },
                        queryMode: 'local',
                        editable: false,
                        allowBlank: false,
                        msgTarget: 'side',
                        blankText: 'For question 1A, please select a number. '

                    }],
                    fieldLabel: QuickStart.util.Resources.questions.safety.question1A()
                },
                {
                    items: [{
                        xtype: 'combobox',
                        minChars: 0,
                      //  typeAhead: true,
                     //   forceSelection: true,
                        publishes: 'value',
                        reference: 'faceToFaceReportsNotInAccordance',
                        valueField: 'id',
                        displayField: 'id',
                        bind: {
                            store: '{numberTableStore}',
                            value: '{caseReview.FaceToFaceReportsNotInAccordance}'
                        },
                        queryMode: 'local',
                        allowBlank: false,
                        editable: false,
                        msgTarget: 'side',
                        blankText: 'For question 1B, please select a number. '

                    }],
                    fieldLabel: QuickStart.util.Resources.questions.safety.question1B()
                },
                {
                    xtype: 'textarea',
                    maxLength: 4100,
                    anchor: '100%',
                    msgTarget: 'side',
                    bind: {
                        disabled: '{!(caseReview.ReportsNotInAccordance>0 || caseReview.FaceToFaceReportsNotInAccordance>0)}',
                        allowBlank: '{!(caseReview.ReportsNotInAccordance>0 || caseReview.FaceToFaceReportsNotInAccordance>0)}',
                        value: '{caseReview.DelayReason}'
                    },
                    setAllowBlank: function (value) {
                        this.allowBlank = value;
                        this.isValid();
                    },
                    blankText: 'Please fill out the narrative field if question 1A or 1B is greater than zero.',
                    fieldLabel: 'Explain the reason for any delays related to reports identified in A and B in the narrative field below'
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.DelayReason==""}',
                        html: '{error.DelayReason}'
                    }
                }]
        },
        {
            title: 'Question 1C',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.safety.question1c(),
            defaults: { margin: 10, disabledCls: 'disable-item' },
            bind: {
                disabled: '{disabledItem || !hasSafetyReportRows}',
                hidden: '{caseReview.Item1IsApplicable != 1}'
            },
            items: [
                {
                    xtype: 'radiogroup',
                    labelAlign: 'top',
                    labelSeparator: '',
                    layout: 'hbox',
                    defaults: { margin: '0 10 0 0', name: 'IsDelayBeyondAgencyControl' },
                    bind: {
                        value: '{isDelayBeyondAgencyControl}'
                    },

                    items: [{
                        boxLabel: 'Yes',
                        bind: { disabled: '{reportsNotInAccordance.value==0 && faceToFaceReportsNotInAccordance.value==0}' },
                        inputValue: 1
                    }, {
                        boxLabel: 'No',
                        bind: { disabled: '{reportsNotInAccordance.value==0 && faceToFaceReportsNotInAccordance.value==0}' },
                        inputValue: 2
                    }, {
                        boxLabel: 'NA',
                        bind: { disabled: '{reportsNotInAccordance.value!=0 || faceToFaceReportsNotInAccordance.value!=0}' },
                        inputValue: 3
                    }],
                    //fieldLabel: 'C. For all reports identified in A and B, were the reasons for the delays due to circumstances beyond the control of the agency?'
                    fieldLabel: QuickStart.util.Resources.questions.safety.question1C()
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.IsDelayBeyondAgencyControl==""}',
                        html: '{error.IsDelayBeyondAgencyControl}'
                    }

                }]
        },
        {
            title: 'Item 1 Rating Criteria',
            xtype: 'rating',
            itemId: 'rating1',
            disabledCls: 'disable-item',
            bind: {
                rating: '{caseReview.Item1}',//, overrideRatingPermission: '{overrideRatingPermission}'
				disabled: '{disabledItem}'
				//disabled: '{disabledItem || !hasSafetyReportRows || caseReview.Item1IsApplicable != 1}'
            },
            text: QuickStart.util.Resources.instructions.safety.item1Rating()

        },
        {
            title: 'Safety - Item 1 - QA Notes',
            xtype: 'notepanel',
            itemId: 'item1NotePanel',
            noteType: 1,
            itemCode: 2,
            outcomeCode: 1,
            storeName: 'item1NoteStore',
            margin: '0 20 20 0',
            bind: {
                //hidden: '{caseReview.Item1IsApplicable != 1}',
                disabled: '{disabledNotes}'
            }
        },
        {
            bind: {
                hidden: '{!allowedInterviewNote}',
                disabled: '{disabledNotes}'
            },
            title: 'Safety - Item 1 - Interview Notes',
            xtype: 'notepanel',
            noteType: 2,
            itemCode: 2,
            outcomeCode: 1,
            storeName: 'item1InterviewNoteStore',
            margin: '0 20 20 0'
        }

    ],
    getValue: function () {

    }
});