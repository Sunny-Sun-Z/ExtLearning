/**
 * Created by kkora on 10/12/2017.
 */


Ext.define('QuickStart.view.casereview.items.Item9', {
    extend: 'QuickStart.view.common.BaseItem',
    xtype: 'item9container',
    routeId: 'item9',
    items: [
        {
            title: 'Item 9: Preserving Connections',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.item9(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [{
                xtype: 'component',
                html: '<strong> Item 9 Applicable Cases:</strong><br/>' +
                '<ul><li>Almost all foster care cases are applicable for an assessment of this item. ' +
                'A possible exception may be the situation of an abandoned infant where the agency has no information about the child’s extended family or connections.</li></ul>'
            }, {
                xtype: 'component',
                html: '<strong> Select the appropriate response.</strong> If the response is No, the case will be rated as Not Applicable in the ratings section for this item.'

            }, {
                xtype: 'yesnoradiogroup',
                labelAlign: 'left',
                labelWidth: 200,
                name: 'Item9IsApplicable',
                bind: '{item9IsApplicable}',
                fieldLabel: 'Is this case applicable?'
            }, {
                xtype: 'narrativefield',
                bind: '{caseReview.Item9Comments}'
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.Item9IsApplicable==""}',
                    html: '{error.Item9IsApplicable}'
                }
            }]
        },
        {
            title: 'Question 9A',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question9a(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item9IsApplicable != 1}'},
            items: [{
                xtype: 'yesnoradiogroup',
                name: 'IsConcertedEffortsForImportantConnections',
                bind: '{isConcertedEffortsForImportantConnections}',
                fieldLabel: QuickStart.util.Resources.questions.permanency.question9A()
            }]
        },
        {
            title: 'Question 9B',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question9b(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item9IsApplicable != 1}'},
            items: [{
                xtype: 'yesnoradiogroup',
                name: 'IsSufficientInquiryForIndianTribe',
                bind: '{isSufficientInquiryForIndianTribe}',
                fieldLabel: QuickStart.util.Resources.questions.permanency.question9B()
            }]
        },
        {
            title: 'Question 9C',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question9c(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item9IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsTribeProvidedTimelyNotification',
                bind: '{isTribeProvidedTimelyNotification}',
                fieldLabel: QuickStart.util.Resources.questions.permanency.question9C()
            }]
        },
        {
            title: 'Question 9D',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question9d(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item9IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsAccordanceWithIndianChildWelfareAct',
                bind: '{isAccordanceWithIndianChildWelfareAct}',
                fieldLabel: QuickStart.util.Resources.questions.permanency.question9D()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsAccordanceWithIndianChildWelfareAct==""}',
                    html: '{error.IsAccordanceWithIndianChildWelfareAct}'
                }
            }]
        },
        {
            title: 'Item 9 Rating Criteria',
            xtype: 'rating',
            itemId: 'rating9',
            bind: {
				disabled: '{disabledItem}',
				//disabled: '{caseReview.Item9IsApplicable != 1}',
                overrideRatingPermission: '{overrideRatingPermission}',
                rating: '{caseReview.Item9}'
            },
            text: QuickStart.util.Resources.instructions.permanency.rating.item9()
        },
        {
            title: 'Item 9 - QA Notes',
            xtype: 'notepanel',
            itemId: 'item9NotePanel',
            noteType: 1,
            itemCode: 10,
            outcomeCode: 4,
            storeName: 'item9NoteStore',
            margin: '0 20 20 0',
            bind: {
                disabled: '{disabledNotes}'
            }
        },
        {
            bind: {
                hidden: '{!allowedInterviewNote}',
                disabled: '{disabledNotes}'
            },
            title: 'Item 9 - Interview Notes',
            xtype: 'notepanel',
            noteType: 2,
            itemCode: 10,
            outcomeCode: 4,
            storeName: 'item9InterviewNoteStore',
            margin: '0 20 20 0'
        }
    ]
});