/**
 * Created by kkora on 9/12/2017.
 */

Ext.define('QuickStart.view.casereview.newcase.NewCase', {
    extend: 'Ext.Container',

    requires: [
        'QuickStart.view.casereview.newcase.Form',
        'QuickStart.view.casereview.newcase.NewCaseController',
        'QuickStart.view.casereview.newcase.NewCaseModel'
    ],

    xtype: 'newcase',
    viewModel: {
        type: 'newcase'
    },

    controller: 'newcase',
    margin: 20,
    //scrollable: 'y',
    config: {
        highlightTitle: 'Create Case Review'
    },
    layout: 'fit',
    border:false,
    items: [
        {
            title: 'Create New Case Review',
            xtype: 'casereviewform'
        }
    ],
    listeners: {
        loadsamplecase: 'onLoadSampleCase'
    }
});