/**
 * Created by kkora on 9/22/2017.
 */
Ext.define('QuickStart.view.casereview.permanency.Container', {
    extend: 'QuickStart.view.common.BaseCaseContainer',

    xtype: 'permanencycontainer',

    requires: [
        'QuickStart.util.Resources',
        'QuickStart.view.common.InstructionPanel'
    ],

    routeId: 'permanency',

    items: [
        // {
        //     title: 'Section II: Permanency',
        //     xtype: 'overviewpanel',
        //     margin: '0 20 20 0',
        //     bind: {data: '{permanencySectionOverview}'}
        // },
        {xtype: 'permanencyoverviewcontainer', margin: '0 20 20 0'},
        {xtype: 'permanencyoutcome1container', margin: '0 20 20 0'},

        {title: 'Item 4', xtype: 'item4container'},
        {title: 'Item 5', xtype: 'item5container'},
        {title: 'Item 6', xtype: 'item6container'},
        {xtype: 'permanencyoutcome2container', margin: '0 20 20 0'},

        {title: 'Item 7', xtype: 'item7container'},
        {title: 'Item 8', xtype: 'item8container'},
        {title: 'Item 9', xtype: 'item9container'},
        {title: 'Item 10', xtype: 'item10container'},
        {title: 'Item 11', xtype: 'item11container'}
    ]
});