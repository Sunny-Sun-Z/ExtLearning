/**
 * Created by kkora on 9/8/2017.
 */

Ext.define('QuickStart.view.casereview.newcase.Form', {
	extend: 'Ext.form.Panel',

	alias: 'widget.casereviewform',

	requires: [
		'Ext.form.RadioGroup',
		'Ext.form.field.*',
		'Ext.layout.container.Anchor',
		'Ext.layout.container.HBox',
		'Ext.toolbar.Fill'
	],

	scrollable: 'y',
	border: false,
	cls: 'casereview-container',
	modelValidation: true,
	defaults: {
		msgTarget: 'side'
	},
	bodyPadding: 10,
	items: [
		{
			xtype: 'numberfield',
			fieldLabel: 'Case ID ',
            bind: {
                value: '{caseReview.CaseID}',
                disabled: '{caseReview.SampleReviewId > 0 || caseReview.CaseReviewID > 0 }'
            },
			checkValidate: true,
			labelWidth: 300,
			minValue: 0,
			margin: '5 0 5 0',
			maxValue: 999999,
			allowBlank: false,
			hideTrigger: true,
			keyNavEnabled: false,
			mouseWheelEnabled: false,
			allowDecimals: false
		},
		{
			itemId: 'questionIPanel',
			xtype: 'instructionpanel',
			text: QuickStart.util.Resources.instructions.newCase.questionA(),
			title: 'Definition and Instructions for Questions A through F',
			defaults: {
				margin: '10 0 10 0',
				labelWidth: 300, msgTarget: 'side'
			},
			layout: 'anchor',
			defaultType: 'combobox',
			bodyPadding: 0,
			bind: {disabled: false},
			items: [
				{
					xtype: 'component',
					html: QuickStart.util.Resources.tips.newCase.questionA()
				},
				{
					fieldLabel: 'A. Office Name',
					bind: {
						store: '{siteStore}',
                        value: '{caseReview.SiteCode}',
                        disabled: '{caseReview.SampleReviewId > 0 || caseReview.CaseReviewID > 0 }'
					},
					allowBlank: false,
					queryMode: 'local',
                    displayField: 'medium',
					valueField: 'code',
					editable: false,
					checkValidate: true,
					anchor: '75%'
				},
				{
					xtype: 'textfield',
					allowBlank: false,
					fieldLabel: 'B. Case Name',
					checkValidate: true,
					anchor: '75%',
                    bind: {
                        value: '{caseReview.CaseName}',
                        disabled: '{caseReview.SampleReviewId > 0 || caseReview.CaseReviewID > 0 }'
                    }
				},
				{
					xtype: 'component',
					html: QuickStart.util.Resources.tips.newCase.questionC()
				},
				{
					xtype: 'datefield',
                    fieldLabel: 'C. Period under review begins on',
                    bind: {
                        value: '{caseReview.ReviewStartDate}',
                        disabled: '{caseReview.SampleReviewId > 0 || caseReview.CaseReviewID > 0 }'
                    },
					allowBlank: false,
					maxValue: new Date(),
					minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30)
				},
				{
					anchor: '75%',
					xtype: 'usertagfield',
					fieldLabel: 'D. Reviewer Name(s)',
					allowBlank: false,
					bind: {
						store: '{reviewers}',
						value: '{caseReview.Reviewers}'
					},
					name: 'Reviewers',
					queryMode: 'local',
					listeners: {
						beforeselect: function (combo, record, index, eOpts) {
							if (combo.getValue().length >= 3)
								return false;
						}
					}

				},
				{
					fieldLabel: 'Initial QA completed by',
					anchor: '75%',
					allowBlank: false,
					bind: {
						store: '{qas}',
						value: '{caseReview.InitialQAUserID}'
					},
					queryMode: 'local',
					//  editable: false,
					xtype: 'usertagfield',
					selectOnFocus: false,
					multiSelect: false
				},
				{
					fieldLabel: 'IRR Reviewer',
					anchor: '75%',
					bind: {
						value: '<strong>{iRRReviewerID}</strong>',
						hidden: '{caseReview.IRRReviewerID==null}'
					},
					xtype: 'displayfield'
				},
				{
					fieldLabel: 'Second Level QA completed by',
					anchor: '75%',
					allowBlank: false,
					bind: {
						store: '{qas2}',
						value: '{caseReview.SecondQAUserID}'
					},
					xtype: 'usertagfield',
					selectOnFocus: false,
					multiSelect: false,
					queryMode: 'local'
					//  editable: false
				},
				{
					fieldLabel: 'Secondary Oversight completed by',
					anchor: '75%',
                    allowBlank: true,
					bind: {
						store: '{oversights}',
						value: '{caseReview.SecondaryOversightUserID}'
					},
					xtype: 'usertagfield',
					selectOnFocus: false,
					multiSelect: false,
					queryMode: 'local'
					//editable: false
				},

				{
					fieldLabel: 'Secondary CT Oversight completed by',
					anchor: '75%',
                    allowBlank: true,
					bind: {
						store: '{ctoversights}',
						value: '{caseReview.CtSecondaryOversightUserID}'
					},
					xtype: 'usertagfield',
					selectOnFocus: false,
					multiSelect: false,
					queryMode: 'local'
					// editable: false

				}, {
					fieldLabel: 'E. Date case review was completed',
					xtype: 'datefield',
					allowBlank: false,
					maxValue: new Date(),
					//  minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30),
					bind: {
						minValue: '{caseReview.ReviewStartDate}',
						value: '{caseReview.ReviewCompleted}'
					}
				}
			]
		},
        {
            itemId: 'questionFPanel',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.newCase.questionF(),
            title: 'Question F',
            defaults: {
                labelWidth: 300
            },
            bind: { disabled: false },
            layout: 'anchor',
            bodyPadding: 0,
            items: [
                {
                    xtype: 'component',
                    flex: 1,
                    html: QuickStart.util.Resources.tips.newCase.questionC()
                }, {
                    xtype: 'radiogroup',
                    fieldLabel: 'F. What is the type of case reviewed',
                    //bind: '{reviewSubTypeId}',
                    //  anchor: '75%',
                    layout: 'hbox',
                    msgTarget: 'side',
                    name: 'ReviewSubTypeID',
                    bind:
                    {
                        value: '{reviewSubTypeID}'
                        //disabled: '{(caseReview.SampleReviewId > 0 || caseReview.CaseReviewID > 0) && caseReview.ReviewSubTypeID === 20}'
                    },

                    items: [{
                        boxLabel: '<strong>Foster Care</strong>',
                        name: 'ReviewSubTypeID',
                        padding: '0 20 0 0',
                        inputValue: 20,
                        bind:
                        {
                            disabled: '{(caseReview.SampleReviewId > 0 || caseReview.CaseReviewID > 0) &&  caseReview.ReviewSubTypeID !== 20}'
                        }
                    }, {
                        boxLabel: '<strong>In-Home Services</strong>',
                        name: 'ReviewSubTypeID',
                        checked: true,
                        padding: '0 20 0 0',
                        inputValue: 19,
                        bind:
                        {
                            disabled: '{(caseReview.SampleReviewId > 0 || caseReview.CaseReviewID > 0) && caseReview.ReviewSubTypeID === 20}'
                        }
                    }, {
                        boxLabel: '<strong>In-Home Services – DR/AR </strong>',
                        name: 'ReviewSubTypeID',
                        inputValue: 21,
                        bind:
                        {
                            disabled: '{(caseReview.SampleReviewId > 0 || caseReview.CaseReviewID > 0) && caseReview.ReviewSubTypeID === 20}'
                        }
                    }]
                }]
        },
		{
			itemId: 'pipPanel',
			xtype: 'instructionpanel',
			text: QuickStart.util.Resources.instructions.newCase.pip(),
			title: 'PIP Monitored',
			defaults: {
				labelWidth: 300, msgTarget: 'side'
			},
			bind: {disabled: false},
			bodyPadding: 0,
			items: [{
				xtype: 'yesnoradiogroup',
				fieldLabel: 'PIP Monitored',
				labelAlign: 'left',
				name: 'IsPIPMonitored',
				bind: '{isPIPMonitored}',
				no: {
					checked: false
				}
			}]

		}
	],
	dockedItems: [{
		xtype: 'toolbar',
		dock: 'bottom',
		ui: 'footer',
		items: ['->', {
			text: 'Save',
			iconCls: 'x-fa fa-save',
			btype: 'createcase',
			disabled: true,
			formBind: true,
			ui: 'soft-green',
			handler: 'onSaveCase'
		}, {
			text: 'Cancel',
			btype: 'cancelcase',
			iconCls: 'x-fa fa-close',
			ui: 'gray',
			handler: 'onCancelCase'
		}]
	}],
    listeners: {
        afterrender: function (p) {
            var form = p.getForm();
            form.isValid();
        }
    }
});