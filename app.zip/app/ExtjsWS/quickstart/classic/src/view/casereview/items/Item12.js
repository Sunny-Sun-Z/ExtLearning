/**
 * Created by kkora on 10/12/2017.
 */

Ext.define('QuickStart.view.casereview.items.Item12', {
    extend: 'QuickStart.view.common.BaseItem',
    xtype: 'item12container',
    routeId: 'item12',
    items: [
        {
            title: 'Item 12: Needs and Services of Child, Parents, and Foster Parents',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.item12(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [{
                xtype: 'component',
                html: '<strong> Item 12 Applicable Cases:</strong><br/><ul><li>Most cases are applicable for an assessment of this item because Sub-Item 12A is typically applicable to all cases. Sub-Items 12B and 12C may not be applicable to all cases, and instructions for applicability are provided before each sub-item.</li></ul>'
            }]
        },
        {
            title: 'Item 12 Rating Criteria',
            xtype: 'rating',
            itemId: 'rating12',
            bind: {
				disabled: '{disabledItem}',
				rating: '{caseReview.Item12}'
            },
            text: QuickStart.util.Resources.instructions.wellbeing.rating.item12()
        }
    ]
});