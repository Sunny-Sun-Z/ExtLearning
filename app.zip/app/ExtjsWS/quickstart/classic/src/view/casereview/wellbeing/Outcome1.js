/**
 * Created by kkora on 10/19/2017.
 */
Ext.define('QuickStart.view.casereview.wellbeing.Outcome1', {
    extend: 'QuickStart.view.common.InstructionPanel',

    xtype: 'wellbeingoutcome1container',
    routeId: 'wellbeingoutcome1',
    margin: '0 20 20 0',

    title: 'Outcome 1: Families have enhanced capacity to provide for their children\'s needs',
    text: QuickStart.util.Resources.instructions.wellbeing.outcome1(),
    defaults: {margin: 10},
    items: [{
        xtype: 'component',
        html: 'What is the level of outcome achievement that best describes the extent to which this outcome is being or has been achieved, based on the ratings for items 12 through 15?'

    }, {
        xtype: 'displayfield',
        labelWidth: '100%',
        fieldLabel: 'Level of Outcome Achievement',
        bind: '{caseReview.Outcome5.RatingDesc}'
    }, {
        xtype: 'displayfield',
        labelWidth: '100%',
        fieldLabel: 'Outcome Rating Override',
        bind: {
            value: '{caseReview.Outcome5.RatingDesc}',
            hidden: '{caseReview.Outcome5.OverrideRatingDesc==""}'
        }
    }]
});