/**
 * Created by kkora on 9/8/2017.
 */

Ext.define('QuickStart.view.casereview.note.ListView', {
    extend: 'Ext.DataView',
    xtype: 'notelistview',
    cls: 'user-notifications',
    scrollable: false,
    // bind: {
    //     store: '{noteStore}'
    // },

    itemSelector: '.comments',

    itemTpl: [
        "<div class='comments {IsResponse:this.isResponseNote}'>",
        // "<img src='{Name:this.resourcesPath}/images/user-profile/default.png' alt='Smiley face' class='profile-icon'>",
        //Fixed by Ravi Kumar on 2018-07-25
        //Only state administrator and assigned users on case can see the Interview notes
        '<tpl if="NoteType != 2 || this.allowedViewInterviewNotes()">',
        "<img src='user/GetProfilePicture?id={LastModifiedUserID}' alt='Smiley face' class='profile-icon'>",
        "<div class='content-wrap'>",
        "<div>",
        "<h4 class='profilenotifications-username'>{Name}</h4> <span class='item-name'>Type: {ItemName}</span>",
        // "<h4 class='profilenotifications-username'>{Name}<span class='{[values.IsResolved === 1 ? 'x-fa fa-check-square-o' : '']}'> </span> {[ values.IsResolved === 1 ? 'Resolved' : values.NoteID === values.ResponseID ? 'Unresolved' :'']}</h4>",
        "<span class='from-now'><span class='x-fa fa-clock-o'></span>{LastModifiedDate:this.modifiedDate} ({LastModifiedDate:this.timeSince} ago)</span>",
        "</div>",
        "<h4 class='reviewer'>{ReviewerType}</h4>",
        "<h4 class='content'>{Subject}</h4>",
        "<div class='content'>{Description}</div>",
        '<tpl if="ReviewerType == \'Reviewer\'">',
        "<h4 class='profilenotifications-username'>{[!values.IsResponse && values.IsResolved === 1 ? 'Resolved : Yes' : !values.IsResponse  ? 'Resolved : No' :'']}</h4>",
        '</tpl>',
        "<div class='like-comment-btn-wrap'>",
        // "<button type='button' data-note-type='respond-note' onclick='' class='{[values.ResponseID === null ? 'x-fa fa-comments' :'x-hidden' ]}'>Respond</button>",
        // "<button type='button' data-note-type='edit-note' class='x-fa fa-pencil' onclick=''>Edit</button>",
        // "<button type='button' data-note-type='delete-note' class='x-fa fa-trash' onclick=''>Delete</button>",
        // "<button type='button' data-note-type='resolved-note' onclick='' class='{[values.ResponseID !== null ? 'x-hidden' : values.IsResolved === 1  ? 'x-fa fa-check-circle-o' : 'x-fa fa-check-circle' ]}'>{[values.IsResolved === 1 ? 'Unresolved' : 'Resolved' ]}</button>",

         '<tpl if="this.hasEnabledCase()">',

            '<tpl if="this.allowedAddEditQANote()">',
                "<button type='button' title='Respond' data-note-type='respond-note' onclick='' class='{[values.IsResponse ? 'x-hidden' : 'x-fa fa-comments' ]}' ></button>",
            '</tpl>',
            '<tpl if="this.allowedAddEditQANoteAndOwnNote(LastModifiedUserID)">',
                "<button type='button' title='Edit' data-note-type='edit-note' class='x-fa fa-pencil' onclick='' ></button>",
                "<button type='button' title='Delete' data-note-type='delete-note' class='x-fa fa-trash' onclick='' ></button>",
            '</tpl>',
            //Fixed by Ravi Kumar on 2018-07-25
            //Notes entered by Reviewer need to resolve only
            '<tpl if="this.allowedAddEditQANote() && ReviewerType == \'Reviewer\'">',
                "<button type='button' title='{[values.IsResolved === 1 ? 'Unresolved' :'Resolved' ]}' data-note-type='resolved-note' onclick='' class='{[ values.IsResponse ? 'x-hidden' : values.IsResolved === 1  ? 'x-fa fa-square-o' : 'x-fa fa-check-square'  ]}'></button>",
            '</tpl>',

        '</tpl>',


        "<br/>",
        "</div>",
        "</div>",
        '</tpl>',
        "</div>",
        {
            resourcesPath: function (value) {
                return QuickStart.util.Global.getResources();
            },
            hasEnabledCase: function () {
              
                var status = this.owner.up('case').getViewModel().get('caseReview.CaseStatusCode');
                //console.log(status)
                return status!= 6 && status!= 7 && status!= 8;
            },
            allowedAddEditQANote: function (value) {
                return QuickStart.util.Global.permissions.allowAddEditQANote();
            },
            allowedAddEditQANoteAndOwnNote: function (value) {
                if (QuickStart.util.Global.permissions.allowAddEditQANote() && QuickStart.util.Global.getUser().id == value)
                    return true;
                return false;
            },
            allowedViewInterviewNotes:function()
            {
                var vm = this.owner.up('case').getViewModel();
                return (QuickStart.util.Global.permissions.isAdmin() || vm.hasUserInCaseReview(QuickStart.util.Global.getUser().id));
            },
            allowedAddEditQANote1: function (value) {
                if (!QuickStart.util.Global.permissions.allowAddEditQANote() )
                    return 'disabled';
                return '';
            },
            allowedAddEditQANoteAndOwnNote1: function (value) {
                if (!QuickStart.util.Global.permissions.allowAddEditQANote() || QuickStart.util.Global.getUser().id != value)
                    return 'disabled';
                return '';
            },
            isResponseNote: function (value, record, previous, index, count) {
                return value ? 'sub-comments' : '';
            },
            cls: function (value, record, previous, index, count) {
                var cls = '';

                if (!index) {
                    cls += ' timeline-item-first';
                }
                if (index + 1 === count) {
                    cls += ' timeline-item-last';
                }

                return cls;
            },

            elapsed: function (value) {

                var now = Date.now();
                // now = +new Date('2015/08/23 21:15:00'); // 9:15 PM (For demo only)
                // console.log(value)
                var seconds = Math.floor((now - value) / 1000),
                    minutes = Math.floor(seconds / 60),
                    hours = Math.floor(minutes / 60),
                    days = Math.floor(hours / 24),
                    weeks = Math.floor(days / 7),
                    months = Math.floor(days / 30),
                    years = Math.floor(days / 365),
                    ret;

                months %= 12;
                weeks %= 52;
                days %= 365;
                hours %= 24;
                minutes %= 60;
                seconds %= 60;

                if (years) {
                    ret = this.part(years, 'Year');
                    ret += this.part(months, 'Month', ' ');
                } else if (months) {
                    ret = this.part(months, 'Month');
                    ret += this.part(days, 'Day', ' ');
                } else if (weeks) {
                    ret = this.part(weeks, 'Week');
                    ret += this.part(days, 'Day', ' ');
                } else if (days) {
                    ret = this.part(days, 'Day');
                    ret += this.part(hours, 'Hour', ' ');
                } else if (hours) {
                    ret = this.part(hours, 'Hour');
                } else if (minutes) {
                    ret = this.part(minutes, ' Minute');
                } else {
                    ret = this.part(seconds, 'Second');
                }

                return ret;
            },
            modifiedDate: function (date) {
                return Ext.Date.format(date, "M d, Y g:i:s A");
            },
            timeSince: function (date) {
                var now = Date.now();

                var seconds = Math.floor((now - date) / 1000);
                var interval = Math.floor(seconds / 31536000);
                if (interval > 1) {
                    return Ext.util.Format.plural(interval, 'year');
                }
                interval = Math.floor(seconds / 2592000);
                if (interval > 1) {
                    return Ext.util.Format.plural(interval, 'month');
                }
                interval = Math.floor(seconds / 86400);
                if (interval > 1) {
                    return Ext.util.Format.plural(interval, 'day');
                }
                interval = Math.floor(seconds / 3600);
                if (interval > 1) {
                    return Ext.util.Format.plural(interval, 'hour');
                }
                interval = Math.floor(seconds / 60);
                if (interval > 1) {
                    return Ext.util.Format.plural(interval, 'minute');
                }
                return Ext.util.Format.plural(Math.floor(seconds), 'second');
            },
            epoch: function (value, record, previous, index, count) {
                var previousValue = previous &&
                    (previous.isModel ? previous.data : previous)['date'];

                // TODO use previousValue and value to determine "Yesterday", "Last week",
                // "Last month", etc...

                if (index === 4) {
                    return '<div class="timeline-epoch">Yesterday</div>';
                }

                return '';
            },

            part: function (value, type, gap) {
                var ret = value ? (gap || '') + value + ' ' + type : '';
                if (value > 1) {
                    ret += 's';
                }
                return ret;
            }

        }
    ]

});