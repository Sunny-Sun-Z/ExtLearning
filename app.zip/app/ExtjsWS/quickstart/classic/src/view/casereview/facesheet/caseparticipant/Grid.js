/**
 * Created by kkora on 9/8/2017.
 */
Ext.define('QuickStart.view.casereview.facesheet.caseparticipant.Grid', {
    extend: 'QuickStart.view.common.CrudGrid',
    xtype: 'caseparticipantgrid',
    columns: [
        {
            xtype: 'rownumberer'
        },
        {
            menuDisabled: true,
            sortable: false,
            text: "Participant's Name",
            tooltip: "Participant's Name",
            dataIndex: 'Name',
            cellWrap: true,
            flex: 2
        },
        {
            menuDisabled: true,
            sortable: false,
            text: "Participant's Role",
            tooltip: "Participant's Role",
            dataIndex: 'RoleCode',
            flex: 2,
            cellWrap: true,
            renderer:'rendererParticipantRole'
        },
        {
            menuDisabled: true,
            sortable: false,
            text: "Relationship to Child",
            tooltip: "Relationship to Child",
            dataIndex: 'RelationshipToChild',
            cellWrap: true,
            flex: 2
        },
        {
            menuDisabled: true,
            sortable: false,
            text: 'Interviewed',
            tooltip: 'Interviewed',
            flex: 1,
            align: 'center',
            dataIndex: 'IsInterviewed',
            renderer: 'rendererYesNoNa'
        }
    ],
    getValue: function () {
        var me=this,
            store = this.getStore(),
            modifiedRecords = store.getModifiedRecords(),
            records = [];
        Ext.each(modifiedRecords, function (rec) {
            var data = rec.getData();
            delete data.IsInterviewedCheck;
            delete data.id;
            //data.DataState = me.dataState.Added;
            if (rec.isDirty()) {
                data.DataState = me.dataState.Modified;
            }
            records.push(data);
        });
        return records;
    }

});