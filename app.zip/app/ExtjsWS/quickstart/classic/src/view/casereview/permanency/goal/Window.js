/**
 * Created by kkora on 9/7/2017.
 */

Ext.define('QuickStart.view.casereview.permanency.goal.Window', {
    extend: 'QuickStart.view.common.BaseWindow',

    alias: 'widget.goalwindow',
    width: 600,
    layout: 'fit',
    defaults: {
        defaultFocus: 'textfield:not([value]):focusable:not([disabled])',
        defaultButton: 'goalSaveButton'
    },
    bind: {
        title: '{current.goalAction} Goal'
    },
    scrollable: 'y',
    items: [
        {
            bodyPadding: '10 10 0 10',
            xtype: 'form',
            scrollable: 'y',
            cls: 'casereview-container',

            defaultType: 'datefield',
            defaults: {
                submitEmptyText: false,
                labelWidth: 175,
                fieldLabel: ' ',
                msgTarget: 'side'
            },
            items: [
                {
                    anchor: '100%',
                    xtype: 'combobox',
                    itemId: 'PriorityLevel',
                    fieldLabel: 'Permanency Goal',
                    editable: false,
                    bind: {
                        value: '{current.goal.GoalCode}',
                        store: '{permanencyGoal1Store}'
                    },
                    displayField: 'large',
                    valueField: 'codeId',
                    allowBlank: false,
                    queryMode: 'local',
                    blankText: 'You have not selected a Permanency Goal. Please select a Permanency Goal.'

                },
                {
                    xtype: 'datefield',
                    blankText: 'Please enter a date the goal was established that is on or before the last day of the PUR.',
                    fieldLabel: 'Date Established',
                    allowBlank: false,
					minText:'Please enter a date the goal was established that is on or after the date of birth [{0}] of the target child.',
                    // minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30),
                    bind: {
                      //  value: '{current.goal.DateEstablished}',
                        value: '{goalDateEstablished}',
                        minValue: '{targetChildDOB}',
                        maxValue: '{caseReview.ReviewCompleted}'
                    }
                },
                {
                    anchor: '100%',
                    defaults: {
                        allowBlank: false,
                        msgTarget: 'side'
                    },
                    fieldLabel: 'Time in Foster Care Before Goal Established',
                    layout: 'hbox',
                    xtype: 'fieldcontainer',

                    items: [{
                        allowDecimals: false,
                        allowExponential: false,
                        blankText: 'Please enter a numeric value.',
                        flex: 1,
                        minValue:0,
                        xtype: 'numberfield',
                        bind: '{current.goal.TimeInFosterCare}'
                    },
                        {
                            margin: '0 0 0 10',
                            flex: 2,
                            xtype: 'combobox',
                            blankText: 'Please select a value.',
                            bind: {
                                value: '{current.goal.TimeUnitCode}',
                                store: '{timeUnitStore}'
                            },
                            displayField: 'large',
                            valueField: 'code',
                            forceSelection: true,
                            editable: false,
                            name: 'RoleCode',
                            queryMode: 'local'
                        }]

                },
                {
                    xtype: 'checkbox',
                    labelSeparator: '',
                    boxLabel: 'NA. This is/was the current goal',
                    inputValue: 1,
                    uncheckedValue: 2,
                    name: 'IsCurrentGoal',
                    reference: 'isCurrentGoalRef',
                    bind: {value: '{isCurrentGoalCheck}'}
                },

                {
                    blankText: 'Please select either a date or select NA. This is/was the current goal.',
                    fieldLabel: 'Date Goal Changed',
                    xtype: 'datefield',
                    allowBlank: false,
                   // minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30),
                    setAllowBlank: function (value) {
                        this.allowBlank = value;
                        this.isValid();
                        this.up('form').isValid();
                    },
                    bind: {
                        value: '{current.goal.DateGoalChanged}',
                        disabled: '{isCurrentGoalRef.checked}',
                        allowBlank: '{isCurrentGoalRef.checked}',
                        minValue: '{current.goal.DateEstablished}',
                        maxValue: '{caseReview.ReviewCompleted}'
                    }
                },
                {
                    xtype: 'textarea',
                    anchor: '100%',
                    fieldLabel: 'Reason for Goal Change',
                    maxLength: 100,
                    allowBlank: false,
                    enforceMaxLength: true,
                    blankText: 'Please select either a date or select NA. This is/was the current goal.',
                    setAllowBlank: function (value) {
                        this.allowBlank = value;
                        this.isValid();
                        this.up('form').isValid();
                    },
                    bind: {
                        value: '{current.goal.ReasonForGoalChange}',
                        disabled: '{isCurrentGoalRef.checked}',
                        allowBlank: '{isCurrentGoalRef.checked}'
                    }
                }
            ],
            dockedItems: [
                {
                    xtype: 'toolbar',
                    dock: 'bottom',
                    ui: 'footer',
                    items: ['->', {
						text: 'Update & Add More',
						ui: 'soft-green',
						iconCls: 'x-fa fa-save',
						type:'addnew',
						formBind: true,
						handler: 'onSaveGoal'
					}, {
						text: 'Add/Update',
                        ui: 'soft-green',
                        iconCls: 'x-fa fa-save',
                        reference: 'goalSaveButton',
                        formBind: true,
                        handler: 'onSaveGoal'

                    }, {
                        text: 'Cancel',
                        ui: 'gray',
                        iconCls: 'x-fa fa-close',
                        handler: 'onCancelGoal'
                    }]
                }]
        }
    ]

});