/**
* Created by kkora on 9/6/2017.
*/

Ext.define('QuickStart.view.casereview.CaseReviewModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.casereview',
    requires: [
        'QuickStart.model.casereview.Note',
        'QuickStart.model.casereview.Lookup',
        'QuickStart.model.casereview.ChildDemographic',
        'QuickStart.model.casereview.CaseParticipant'
    ],
    data: {
        editedItems: [],
        isCaseNote: false,
        isSetupWindow: true,
        caseReview: null,
        caseReviewOriginalState: null,
        current: {
            childDemographicAction: 'Edit',
            caseParticipantAction: 'Edit',
            childDemographic: null,
            caseParticipant: null,
            safetyReportAction: 'Edit',
            safetyReport: null,
            placementAction: 'Edit',
            placement: null,
            goalAction: 'Edit',
            goal: null,
            physicalDentalHealthAction: 'Edit',
            physicalDentalHealth: null,
            mentalHealthAction: 'Edit',
            mentalHealth: null,
            educationAction: 'Edit',
            education: null,
            noteAction: 'Edit',
            note: null,
            eliminationRequest: null,
            elimination: null
        },
        isRespondNote: false,
        overrideRatingPermission: false,
        error: {
            enabledDelayedMsg: false,
            ChildDemographics: null,
            CaseParticipants: null,
            IsCaseOpenReasonOtherAbuseNeglect: null,
            FirstCaseOpeningDate: null,
            FosterEntryDate: null,
            EpisodeDischargeDate: null,
            CaseClosureDate: null,
            CaseReasons: null,
            Item1IsApplicable: null,
            SafetyReports: null,
            DelayReason: null,
            IsDelayBeyondAgencyControl: null,

            Item2IsApplicable: null,
            IsChildRemovedToEnsureSafety: null,

            IsInitialAssesmentForAllChildrenInHome: null,
            SafetyRelatedIncidents: null,
            IsSafetyConcernForOtherChildren: null,
            FosterSafety: null,
            IsFosterSafetyConcernDuringVisitation: null,
            FosterPlacementConcern: null,
            IsFosterSafetyConcernNotAddressed: null,

            Placements: null,
            NumberOfPlacementSettings: null,
            WereAllPlacementChangesPlanned: null,
            PlacementApplicableCircumstances: null,
            IsCurrentPlacementSettingStable: null,

            Item5IsApplicable: null,
            Goals: null,
            IsGoalSpecified: null,
            WereAllGoalsInTimelyManner: null,
            MeetsTerminationOfParentalRights: null,
            IsAgencyJointTerminationOfParentalRights: null,
            TerminationExceptions: null,
            IsExceptionForTermination: null,

            TimeInCare: null,
            AgencyConcertedEffortsExplained: null,
            LivingArrangementCode: null,
            OtherPlannedArrangementDocumentationDate: null,
            IsOtherPlannedConcertedEffort: null,

            IsValidReasonForSeparation: null,

            Item8IsApplicable: null,
            IsSufficientFrequencyForMotherVisitation: null,
            IsSufficientFrequencyForFatherVisitation: null,
            IsSufficientQualityForMotherVisitation: null,
            IsSufficentQualityForFatherVisitation: null,
            IsSufficientFrequencyForSiblingVisitation: null,
            IsSufficentQualityForSiblingVisitation: null,

            Item9IsApplicable: null,
            IsAccordanceWithIndianChildWelfareAct: null,

            Item10IsApplicable: null,
            IsRecentPlacementWithRelative: null,
            IsPlacementWithRelativeStable: null,
            IsConcertedEffortToLocateMaternalRelatives: null,
            IsConcertedEffortToLocatePaternalRelatives: null,

            Item11IsApplicable: null,
            IsConcertedEffortMotherFosterRelationship: null,
            EffortsToSupportMotherFosterRelationship: null,
            IsConcertedEffortFatherFosterRelationship: null,
            EffortsToSupportFatherFosterRelationship: null,

            Item12aIsApplicable: null,

            Item12bIsApplicable: null,
            IsComprehensiveAssessementForMotherConducted: null,
            IsComprehensiveAssessementForFatherConducted: null,

            Item12cIsApplicable: null,


            Item13IsApplicable: null,
            IsAgencyConcertedEffortsToInvolveTheChild: null,
            IsAgencyConcertedEffortsToInvolveTheMother: null,
            IsAgencyConcertedEffortsToInvolveTheFather: null,

            IsResponsiblePartyVisitationFrequencySufficient: null,
            IsResponsiblePartyVisitationQualitySufficient: null,

            Item15IsApplicable: null,
            ResponsiblePartyVisitationFrequencyWithMotherCode: null,
            IsResponsiblePartyVisitationFrequencyWithMotherSufficient: null,
            ResponsiblePartyVisitationFrequencyWithFatherCode: null,
            IsResponsiblePartyVisitationFrequencyWithFatherSufficient: null,
            IsResponsiblePartyVisitationQualityWithMotherSufficient: null,
            IsResponsiblePartyVisitationQualityWithFatherSufficient: null,

            Item16IsApplicable: null,
            Item17IsApplicable: null,
            IsAgencyAssessPhysicalHealthNeeds: null,
            IsAgencyAssessDentalHealthNeeds: null,
            PhysicalDentalHealthHealths: null,
            FosterFederalCaseManagamentCriteria: null,

            Item18IsApplicable: null,
            MentalBehavirolHealths: null

        }
    },
    formulas: {
        caseReviewUpdate: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                if (data) {
                    //   console.log('caseReviewUpdate')

                    this.set('caseReview.ChildMostRecentFosterEntryDate', this.get('caseReview.FosterEntryDate'));
                    this.set('caseReview.DischargeDate', this.get('caseReview.EpisodeDischargeDate'));
                    this.set('caseReview.IsDischargeDateNA', Ext.isEmpty(this.get('caseReview.EpisodeDischargeDate')) ? 1 : 2);

                    var arr = [], goalTable = this.getCurrentGoalTableValue();

                    if (this.get('caseReview.Item5IsApplicable') === 2)
                        arr = [127];//Reunification
                    else {
                        if (goalTable !== null && goalTable.length > 0) {
                            arr = goalTable;
                            if (this.get('isNonOPPLA')) {
                                this.set('caseReview.LivingArrangementCode', 1);

                                this.set('caseReview.IsOtherPlannedArrangement', 1);

                                this.set('caseReview.IsOtherPlannedArrangementNA', 1);
                                this.set('caseReview.IsOtherPlannedArrangementNoDate', null);
                                this.set('caseReview.OtherPlannedArrangementDocumentationDate', null);

                                this.set('caseReview.IsOtherPlannedConcertedEffort', 3);

                            }
                        }
                    }
                    if (arr.length > 0)
                        this.set('caseReview.PermanencyGoal1', arr);
                    var goalColl = this.get('caseReview.Permanency.CR_Goal_Collection'),
                        totalGoalRows = this.toArray(this.get('totalGoalRows')),
                        isAgencyConcertedEfforts = this.get('caseReview.IsAgencyConcertedEfforts'),

                        goals = goalTable && goalTable.length > 0 ? goalTable : Ext.Array.pluck(this.toArray(goalColl), 'GoalCode'),
                        goal1 = null, goal2 = null;

                    if (goals && goals.length > 0) {
                        goal1 = goals[0];
                        if (goals.length > 1)
                            goal2 = goals[1];
                        else
                            goal2 = 310; //310=NA
                    }

                    this.set('caseReview.Goal1Code', goal1);
                    this.set('caseReview.Goal2Code', goal2);

                    if (!Ext.isEmpty(this.get('caseReview.FosterEntryDate')))
                        this.set('caseReview.IsFosterEntryDateNA', 2);
                    if (!Ext.isEmpty(this.get('caseReview.EpisodeDischargeDate'))) {
                        this.set('caseReview.IsEpisodeDischargeDateNA', 2);
                        this.set('caseReview.IsEpisodeNotYetDischarged', 2);
                    }
                    if (!Ext.isEmpty(this.get('caseReview.CaseClosureDate')))
                        this.set('caseReview.IsCaseClosureNotClosed', 2);

                    /*if (this.get('hasNoOpenedForServicesReport')) {
                    
                    }*/
                    if (this.get('caseReview.ReportsNotInAccordance') === 0 && this.get('caseReview.FaceToFaceReportsNotInAccordance') === 0) {
                        this.set('caseReview.DelayReason', null);
                    }

                    //if (isAgencyConcertedEfforts != 3 && !this.get('isNonOPPLA') && totalGoalRows.length === 1) {
                    //	this.set('caseReview.IsAgencyConcertedEfforts', 3);
                    //}
                    // if (this.get('caseReview.ItemApplicability51') === 1 && this.get('caseReview.ItemApplicability52') === 1 && this.get('caseReview.ItemApplicability53') === 1 && this.get('caseReview.ItemApplicability54') === 1 && this.get('caseReview.ItemApplicability55') === 1 && this.get('caseReview.ItemApplicability56') === 2)
                    //     this.set('caseReview.Item2IsApplicable', 1);
                    // else if (this.get('caseReview.ItemApplicability51') === 1 && this.get('caseReview.ItemApplicability52') === 1 && this.get('caseReview.ItemApplicability53') === 1 && this.get('caseReview.ItemApplicability54') === 1 && this.get('caseReview.ItemApplicability55') === 1 && this.get('caseReview.ItemApplicability56') === 1)
                    //     this.set('caseReview.Item2IsApplicable', 2);
                    // else if (this.get('caseReview.ItemApplicability51') === 2 && this.get('caseReview.ItemApplicability52') === 2 && this.get('caseReview.ItemApplicability53') === 2 && this.get('caseReview.ItemApplicability54') === 2 && this.get('caseReview.ItemApplicability55') === 2 && this.get('caseReview.ItemApplicability56') === 1)
                    //     this.set('caseReview.Item2IsApplicable', 2);
                    // else if (this.get('caseReview.ItemApplicability51') === 2 && this.get('caseReview.ItemApplicability52') === 2 && this.get('caseReview.ItemApplicability53') === 2 && this.get('caseReview.ItemApplicability54') === 2 && this.get('caseReview.ItemApplicability55') === 2 && this.get('caseReview.ItemApplicability56') === 2)
                    //     this.set('caseReview.Item2IsApplicable', 2);

                    var fosterEntry = this.get('caseReview.FosterEntryDate'),
                        episodeDischargeDate = this.get('caseReview.EpisodeDischargeDate'),
                        reviewCompleted = this.get('caseReview.ReviewCompleted'),
                        dt = Ext.isEmpty(episodeDischargeDate) ? reviewCompleted : episodeDischargeDate;
                    if (fosterEntry && dt) {
                        var month = Ext.Date.diff(fosterEntry, dt, 'mo');
                        this.set('caseReview.TimeInCare', month);

                    }

                }
                return true;
            },
            set: function (data) {
            }
        },
        validationErrMsg: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var msg = "",
                    isFosterCareCase = this.get('isFosterCareCase'),
                    isHomeServiceCase = this.get('isHomeServiceCase'),
                    fosterEntryDate = this.get('caseReview.FosterEntryDate'),
                    episodeDischargeDate = this.get('caseReview.EpisodeDischargeDate'),
                    reviewCompleted = this.get('caseReview.ReviewCompleted'),
                    targetChildDOB = this.get('targetChildDOB');

                if (Ext.isEmpty(this.get('caseReview.IsCaseOpenReasonOtherAbuseNeglect')))
                    this.set('error.IsCaseOpenReasonOtherAbuseNeglect', 'Please answer question H');

                if (this.get('caseReview.FirstCaseOpeningDate') > this.get('caseReview.ReviewCompleted'))
                    this.set('error.FirstCaseOpeningDate', 'For question I, please enter a date of case opening that is before the last day of the PUR.');
                //console.log('validationErrMsg')
                //question k
                if (this.get('caseReview.IsFosterEntryDateNA') === 1)
                    this.set('error.FosterEntryDate', null);
                else if (Ext.isEmpty(this.get('caseReview.FosterEntryDate')) && this.get('caseReview.IsFosterEntryDateNA') != 1)
                    this.set('error.FosterEntryDate', 'For question J, please either specify a date or choose NA');
                else if (Ext.isEmpty(this.get('caseReview.FosterEntryDate')) && this.get('caseReview.IsFosterEntryDateNA') != 1)
                    this.set('error.FosterEntryDate', 'For question J, please enter the date of the child\'s most recent entry into foster care. ');
                else if (this.get('caseReview.FosterEntryDate') > this.get('caseReview.ReviewCompleted'))
                    this.set('error.FosterEntryDate', 'For question J, please enter a date for the target child’s most recent entry into foster care that is before the last day of the PUR.');
                else if (this.get('caseReview.FosterEntryDate') < this.get('caseReview.FirstCaseOpeningDate'))
                    this.set('error.FosterEntryDate', 'For question J, please enter a date that is on or after the date of case opening recorded in question I.');
                else if (targetChildDOB && this.get('caseReview.FosterEntryDate') < targetChildDOB)
                    this.set('error.FosterEntryDate', 'For question J, please enter a date for the target child’s most recent entry into foster care that is on or after the date of birth of the target child.');
                else
                    this.set('error.FosterEntryDate', null);

                //question k
                if (this.get('caseReview.IsEpisodeNotYetDischarged') === 1)
                    this.set('error.EpisodeDischargeDate', null);
                else if (Ext.isEmpty(this.get('caseReview.EpisodeDischargeDate')) && this.get('caseReview.IsEpisodeDischargeDateNA') != 1 && this.get('caseReview.IsEpisodeNotYetDischarged') != 1)
                    this.set('error.EpisodeDischargeDate', 'For question K, please either specify a date or choose NA or Not Yet Discharged.');
                //RK: Dated - 07/18/18 Discharge date must be after entry date and can not be same.
                else if (!Ext.isEmpty(this.get('caseReview.FosterEntryDate')) && this.get('caseReview.EpisodeDischargeDate') <= this.get('caseReview.FosterEntryDate'))
                    this.set('error.EpisodeDischargeDate', 'For question K, please enter a date of discharge that is after the target child’s most recent entry into foster care.');
                else if (targetChildDOB && this.get('caseReview.EpisodeDischargeDate') <= targetChildDOB)
                    this.set('error.EpisodeDischargeDate', 'For question K, please enter a date of discharge that is after the date of birth of the target child.');
                else
                    this.set('error.EpisodeDischargeDate', null);

                if (this.get('isFosterCareCase') && Ext.isEmpty(this.get('caseReview.EpisodeDischargeDate')) && this.get('caseReview.IsEpisodeNotYetDischarged') != 1 && !Ext.isEmpty(this.get('caseReview.CaseClosureDate')))
                    this.set('error.EpisodeDischargeDate', 'For question K, if case is closed, please enter discharge date.');
                //question L

                else if (Ext.isEmpty(this.get('caseReview.CaseClosureDate')) && this.get('caseReview.IsCaseClosureNotClosed') !== 1)
                    this.set('error.CaseClosureDate', 'For question L, please either specify a date or choose Case not closed by time of review.');
                else if (this.get('isFosterCareCase') && this.get('caseReview.IsEpisodeNotYetDischarged') === 1 && this.get('caseReview.IsCaseClosureNotClosed') != 1)
                    this.set('error.CaseClosureDate', 'For question L, please select Case not closed by time of review since question K is Not Yet Discharged. ');
                else if (!Ext.isEmpty(this.get('caseReview.CaseClosureDate')) && this.get('caseReview.CaseClosureDate') < this.get('caseReview.ReviewStartDate'))
                    this.set('error.CaseClosureDate', 'For Question L, please enter the date of the most recent case closure that is on or after the first day of the PUR. ');
                else if (!this.get('isFosterCareCase') && this.get('caseReview.IsCaseClosureNotClosed') != 1 && this.get('caseReview.CaseClosureDate') < this.get('caseReview.FirstCaseOpeningDate'))
                    this.set('error.CaseClosureDate', 'For question L, please enter the date of the most recent case closure that is after the date the case was opened for services during the PUR.');
                else if (this.get('isFosterCareCase') && targetChildDOB && !Ext.isEmpty(this.get('caseReview.CaseClosureDate')) && this.get('caseReview.CaseClosureDate') < targetChildDOB)
                    this.set('error.CaseClosureDate', 'For question L, please enter the date of the most recent case closure that is after the date of birth of the target child');
                else
                    this.set('error.CaseClosureDate', null);


                //question M
                if (this.get('caseReview.CaseReasons') === null || this.get('caseReview.CaseReasons').length === 0)
                    this.set('error.CaseReasons', 'Please answer question M. ');
                else if (Ext.isEmpty(this.get('caseReview.OtherCaseReason')) && this.get('caseReview.CaseReasons') && this.get('caseReview.CaseReasons').filter(function (item) {
                    return item === 14;
                }).length > 0)
                    this.set('error.CaseReasons', 'For question M, please fill out the narrative field for a response of Other. ');
                else
                    this.set('error.CaseReasons', null);

                //Item 1
                if (this.get('caseReview.Item1IsApplicable') === null)
                    this.set('error.Item1IsApplicable', 'Please select Yes or No.');
                else
                    this.set('error.Item1IsApplicable', null);

                if (this.get('caseReview.Item1IsApplicable') === 1 && (this.get('caseReview.ReportsNotInAccordance') > 0 || this.get('caseReview.FaceToFaceReportsNotInAccordance') > 0) && Ext.isEmpty(this.get('caseReview.DelayReason')))
                    this.set('error.DelayReason', 'Please fill out the narrative field if question 1A or 1B is greater than zero.');
                else
                    this.set('error.DelayReason', null);

                if (this.get('caseReview.Item1IsApplicable') === 1) {
                    if (!(this.get('caseReview.ReportsNotInAccordance') > 0 || this.get('caseReview.FaceToFaceReportsNotInAccordance') > 0) && this.get('caseReview.IsDelayBeyondAgencyControl') != 3)
                        this.set('error.IsDelayBeyondAgencyControl', 'For question 1C, please select NA since both questions 1A and 1B are zero. ');
                    else if ((this.get('caseReview.ReportsNotInAccordance') > 0 || this.get('caseReview.FaceToFaceReportsNotInAccordance') > 0) && (this.get('caseReview.IsDelayBeyondAgencyControl') != 1 && this.get('caseReview.IsDelayBeyondAgencyControl') != 2))
                        this.set('error.IsDelayBeyondAgencyControl', 'For question 1C, please select Yes or No since delays related to reports are indicated in question 1A or 1B.');
                    else
                        this.set('error.IsDelayBeyondAgencyControl', null);
                }
                else
                    this.set('error.IsDelayBeyondAgencyControl', null);

                //item 2
                var app2 = this.get('caseReview.Item2IsApplicable'),
                    app51 = this.get('caseReview.ItemApplicability51'),
                    app52 = this.get('caseReview.ItemApplicability52'),
                    app53 = this.get('caseReview.ItemApplicability53'),
                    app54 = this.get('caseReview.ItemApplicability54'),
                    app55 = this.get('caseReview.ItemApplicability55'),
                    app56 = this.get('caseReview.ItemApplicability56');

                if (app51 === null || app52 === null || app53 === null || app54 === null || app55 === null || app56 === null)
                    this.set('error.Item2IsApplicable', 'Please answer all questions on this page.');
                else if (this.get('caseReview.Item2IsApplicable') === null)
                    this.set('error.Item2IsApplicable', 'Please select Yes or No.');
                else if (app51 === 1 && app52 === 1 && app53 === 1 && app54 === 1 && app55 === 1 && app56 === 2 && app2 !== 1)
                    this.set('error.Item2IsApplicable', 'The answers above indicate that this case is applicable. Please review answers above');
                else if (app51 === 1 && app52 === 1 && app53 === 1 && app54 === 1 && app55 === 1 && app56 === 1 && app2 !== 2)
                    this.set('error.Item2IsApplicable', 'The answers above indicate that this case is not applicable. Please review answers above');
                else if (app51 === 2 && app52 === 2 && app53 === 2 && app54 === 2 && app55 === 2 && app56 === 1 && app2 !== 2)
                    this.set('error.Item2IsApplicable', 'The answers above indicate that this case is not applicable. Please review answers above');
                else if (app51 === 2 && app52 === 2 && app53 === 2 && app54 === 2 && app55 === 2 && app56 === 2 && app2 !== 2)
                    this.set('error.Item2IsApplicable', 'The answers above indicate that this case is not applicable. Please review answers above');
                else if ((app51 === 1 || app52 === 1 || app53 === 1 || app54 === 1 || app55 === 1) && app56 === 1 && app2 !== 2)
                    this.set('error.Item2IsApplicable', 'The answers above indicate that this case is not applicable. Please review answers above');
                else
                    this.set('error.Item2IsApplicable', null);

                if (this.get('caseReview.IsEffortToPreventReEntry') === 1 && this.get('caseReview.IsChildRemovedToEnsureSafety') === 2)
                    this.set('error.IsChildRemovedToEnsureSafety', 'The answer to question 2B cannot be No if the answer to question 2A is Yes. Please review your answers and refer to the instructions for guidance. ');
                else
                    this.set('error.IsChildRemovedToEnsureSafety', null);

                //Item 3
                var naSafetyRelatedIncidents = this.hasValueInArray(this.get('caseReview.SafetyRelatedIncidents'), 86),
                    noSafetyRelatedIncidents = this.hasValueInArray(this.get('caseReview.SafetyRelatedIncidents'), 87),
                    safetyRelatedIncidentsExist = this.get('caseReview.SafetyRelatedIncidents') && this.get('caseReview.SafetyRelatedIncidents').length > 1,
                    safetyRelatedIncidentsExist1 = this.get('caseReview.SafetyRelatedIncidents') && this.get('caseReview.SafetyRelatedIncidents').length > 0,

                    isSafetyConcernForOtherChildren = this.get('caseReview.IsSafetyConcernForOtherChildren');

                if (this.get('caseReview.IsInitialAssesmentForAllChildrenInHome') === 3 && this.get('caseReview.IsOngoingAssesementForAllChildrenInHome') === 3)
                    this.set('error.IsInitialAssesmentForAllChildrenInHome', 'Please change question 3A or 3B so that both are not NA');
                else
                    this.set('error.IsInitialAssesmentForAllChildrenInHome', null);

                if (this.hasValueInArray(this.get('caseReview.SafetyRelatedIncidents'), 87) && this.get('caseReview.SafetyRelatedIncidents').length > 1)
                    this.set('error.SafetyRelatedIncidents', 'For question 3D1, if you have selected "No safety-related incidents occurred that were not adequately addressed by the agency", please ensure that no other selections were made.');
                else if (this.hasValueInArray(this.get('caseReview.SafetyRelatedIncidents'), 86) && this.get('caseReview.SafetyRelatedIncidents').length > 1)
                    this.set('error.SafetyRelatedIncidents', 'For question 3D1, if you have selected NA, please ensure that no other selections were made.');
                else
                    this.set('error.SafetyRelatedIncidents', null);

                if (naSafetyRelatedIncidents && isSafetyConcernForOtherChildren !== 3)
                    this.set('error.IsSafetyConcernForOtherChildren', 'For question 3D, please select NA since NA is selected in question 3D1.');
                else if (!naSafetyRelatedIncidents && !noSafetyRelatedIncidents && safetyRelatedIncidentsExist1 && isSafetyConcernForOtherChildren && isSafetyConcernForOtherChildren !== 1)
                    this.set('error.IsSafetyConcernForOtherChildren', 'For question 3D, please select Yes since safety-related incidents were identified in question 3D1. ');
                else if ((naSafetyRelatedIncidents || noSafetyRelatedIncidents) && isSafetyConcernForOtherChildren === 1)
                    this.set('error.IsSafetyConcernForOtherChildren', 'For question 3D, please select Yes only if a safety concern was identified in question 3D1.');
                else
                    this.set('error.IsSafetyConcernForOtherChildren', null);


                var fosterCareExist = this.get('caseReview.FosterSafety') && this.get('caseReview.FosterSafety').length > 1,
                    fosterCareExist1 = this.get('caseReview.FosterSafety') && this.get('caseReview.FosterSafety').length > 0,
                    naFoster = this.hasValueInArray(this.get('caseReview.FosterSafety'), 92),
                    noFoster = this.hasValueInArray(this.get('caseReview.FosterSafety'), 93);

                if (noFoster && fosterCareExist)//no
                    this.set('error.FosterSafety', 'For question 3E1, if you have selected "No safety concerns related to visitation were present", please ensure that no other selections were made.');
                else if (naFoster && fosterCareExist)//na
                    this.set('error.FosterSafety', 'For question 3E1, if you have selected NA, please ensure that no other selections were made.');
                else
                    this.set('error.FosterSafety', null);

                if (!naFoster && !noFoster && fosterCareExist1 && this.get('caseReview.IsFosterSafetyConcernDuringVisitation') && this.get('caseReview.IsFosterSafetyConcernDuringVisitation') != 1)
                    this.set('error.IsFosterSafetyConcernDuringVisitation', 'For question 3E, please select Yes since safety concerns were identified in question 3E1.');
                else if ((naFoster || noFoster) && this.get('caseReview.IsFosterSafetyConcernDuringVisitation') === 1)//
                    this.set('error.IsFosterSafetyConcernDuringVisitation', 'For question 3E1, question 3E cannot be Yes if no safety-related incidents are identified.');
                else
                    this.set('error.IsFosterSafetyConcernDuringVisitation', null);


                var fosterPlacementConcernExist = this.get('caseReview.FosterPlacementConcern') && this.get('caseReview.FosterPlacementConcern').length > 1,
                    fosterPlacementConcernExist1 = this.get('caseReview.FosterPlacementConcern') && this.get('caseReview.FosterPlacementConcern').length > 0,
                    naFosterPlacementConcern = this.hasValueInArray(this.get('caseReview.FosterPlacementConcern'), 98),
                    noFosterPlacementConcern = this.hasValueInArray(this.get('caseReview.FosterPlacementConcern'), 99),
                    value = this.get('caseReview.IsFosterSafetyConcernNotAddressed');

                if (isFosterCareCase && value === 3)//
                    this.set('error.IsFosterSafetyConcernNotAddressed', 'For question 3F, please select Yes or No since this is a foster care case.');
                else if (!naFosterPlacementConcern && !noFosterPlacementConcern && fosterPlacementConcernExist1 && value && value !== 1)
                    this.set('error.IsFosterSafetyConcernNotAddressed', 'For question 3F, please select Yes since concerns were identified in question 3F1. ');
                else if ((naFosterPlacementConcern || noFosterPlacementConcern) && value && value === 1)
                    this.set('error.IsFosterSafetyConcernNotAddressed', 'For question 3F, please select Yes only if a safety concern was identified in question 3F1.');
                else
                    this.set('error.IsFosterSafetyConcernNotAddressed', null);


                //Item 4
                var numberOfPlacementSettings = this.get('caseReview.NumberOfPlacementSettings'),
                    wereAllPlacementChangesPlanned = this.get('caseReview.WereAllPlacementChangesPlanned'),
                    placementApplicableCircumstances = this.get('caseReview.PlacementApplicableCircumstances'),
                    isCurrentPlacementSettingStable = this.get('caseReview.IsCurrentPlacementSettingStable'),
                    placementApplicableCircumstancesNone = this.hasValueInArray(this.toArray(placementApplicableCircumstances), 121)
                    ;
                if (Ext.isEmpty(numberOfPlacementSettings))
                    this.set('error.NumberOfPlacementSettings', 'For question 4A, please enter a number.');
                else
                    this.set('error.NumberOfPlacementSettings', null);

                if (numberOfPlacementSettings === 1 && wereAllPlacementChangesPlanned !== 3)
                    this.set('error.WereAllPlacementChangesPlanned', 'For question 4B, please select NA since there was only one placement indicated in question 4A.');
                else if (numberOfPlacementSettings > 1 && wereAllPlacementChangesPlanned === 3)
                    this.set('error.WereAllPlacementChangesPlanned', 'For question 4B, please select Yes or No since there was more than one placement indicated in question 4A');
                else
                    this.set('error.WereAllPlacementChangesPlanned', null);

                if (placementApplicableCircumstances && placementApplicableCircumstances.length > 0 && !placementApplicableCircumstancesNone && isCurrentPlacementSettingStable === 1)
                    this.set('error.IsCurrentPlacementSettingStable', 'For question 4C, please select No since case circumstances were identified in question 4C1.');
                else if (placementApplicableCircumstances && placementApplicableCircumstances.length > 0 && placementApplicableCircumstancesNone && isCurrentPlacementSettingStable === 2)
                    this.set('error.IsCurrentPlacementSettingStable', 'For question 4C, please select Yes since "None apply, placement is stable" is selected in question 4C1.');
                else
                    this.set('error.IsCurrentPlacementSettingStable', null);

                //Item 5

                var goals = this.toArray(this.get('totalGoalRows')),
                    totalCurrentGoals = goals.filter(function (item) {
                        return item.IsCurrentGoal === 1;
                    }),
                    currentGoalCodes = Ext.Array.pluck(totalCurrentGoals, 'GoalCode'),
                    hasDuplicateCurrentGoal = currentGoalCodes.length !== Ext.Array.unique(currentGoalCodes).length,
                    isCurrentGoal = totalCurrentGoals.length > 0,
                    isGoalSpecified = this.get('caseReview.IsGoalSpecified'),
                    wereAllGoalsInTimelyManner = this.get('caseReview.WereAllGoalsInTimelyManner'),
                    isInFoster15OutOf22 = this.get('caseReview.IsInFoster15OutOf22'),
                    meetsTerminationOfParentalRights = this.get('caseReview.MeetsTerminationOfParentalRights'),
                    isAgencyJointTerminationOfParentalRights = this.get('caseReview.IsAgencyJointTerminationOfParentalRights'),
                    isExceptionForTermination = this.get('caseReview.IsExceptionForTermination'),
                    terminationExceptions = this.toArray(this.get('caseReview.TerminationExceptions')),
                    terminationExceptionsNA = this.hasValueInArray(terminationExceptions, 138),
                    terminationExceptionsNo = this.hasValueInArray(terminationExceptions, 139);


                if (this.get('caseReview.Item5IsApplicable') === null)
                    this.set('error.Item5IsApplicable', 'Please select Yes or No.');
                else if (this.get('caseReview.Item5IsApplicable') !== 1 && isFosterCareCase && Ext.Date.diff(fosterEntryDate, episodeDischargeDate, 'd') > 60)
                    this.set('error.Item5IsApplicable', 'You indicated on the Face Sheet that the child has been in foster care more than 60 days. Please answer Yes to the question of applicability for item 5.');
                else if (this.get('caseReview.Item5IsApplicable') !== 1 && isFosterCareCase && Ext.Date.diff(fosterEntryDate, reviewCompleted, 'd') > 60)
                    this.set('error.Item5IsApplicable', 'You indicated on the Face Sheet that the child has been in foster care more than 60 days. Please answer Yes to the question of applicability for item 5.');
                else
                    this.set('error.Item5IsApplicable', null);

                if (!isCurrentGoal)
                    this.set('error.Goals', 'For table 5A1, please ensure that one of the rows indicates that this is the current goal.');
                else if (totalCurrentGoals.length > 2)
                    this.set('error.Goals', 'For table 5A1, please complete Date Goal Changed and Reason for Goal Change for all non-current goals. Please record only two concurrent goals.');
                else if (hasDuplicateCurrentGoal)
                    this.set('error.Goals', 'For table 5A1, please complete Date Goal Changed and Reason for Goal Change for all non-current goals. Please do not list two concurrent goals that are the same');
                else
                    this.set('error.Goals', null);


                if (isGoalSpecified === 3)
                    this.set('error.IsGoalSpecified', 'If question 5A3 is NA, item 5 is not applicable for assessment. Please return to the applicability page for item 5 and select No.');
                else if (Ext.isEmpty(isGoalSpecified) && isFosterCareCase && Ext.Date.diff(fosterEntryDate, episodeDischargeDate, 'd') > 60)
                    this.set('error.IsGoalSpecified', 'You indicated on the Face Sheet that the child has been in foster care more than 60 days. Please answer Yes or No to question 5A3.');
                else if (Ext.isEmpty(isGoalSpecified) && isFosterCareCase && Ext.Date.diff(fosterEntryDate, reviewCompleted, 'd') > 60)
                    this.set('error.IsGoalSpecified', 'You indicated on the Face Sheet that the child has been in foster care more than 60 days. Please answer Yes or No to question 5A3.');
                else
                    this.set('error.IsGoalSpecified', null);


                if (wereAllGoalsInTimelyManner === 3)
                    this.set('error.WereAllGoalsInTimelyManner', 'If question 5B is NA, item 5 is not applicable for assessment. Please return to the applicability page for item 5 and select No.');
                else if (Ext.isEmpty(wereAllGoalsInTimelyManner) && isFosterCareCase && Ext.Date.diff(fosterEntryDate, episodeDischargeDate, 'd') > 60)
                    this.set('error.WereAllGoalsInTimelyManner', 'You indicated on the Face Sheet that the child has been in foster care more than 60 days. Please answer Yes or No to question 5B.');
                else if (Ext.isEmpty(wereAllGoalsInTimelyManner) && isFosterCareCase && Ext.Date.diff(fosterEntryDate, reviewCompleted, 'd') > 60)
                    this.set('error.WereAllGoalsInTimelyManner', 'You indicated on the Face Sheet that the child has been in foster care more than 60 days. Please answer Yes or No to question 5B.');
                else
                    this.set('error.WereAllGoalsInTimelyManner', null);

                if (isInFoster15OutOf22 === 2 && meetsTerminationOfParentalRights === 3)
                    this.set('error.MeetsTerminationOfParentalRights', 'For question 5E, please answer Yes or No since No is selected in question 5D.');
                else if (isInFoster15OutOf22 === 1 && meetsTerminationOfParentalRights && meetsTerminationOfParentalRights !== 3)
                    this.set('error.MeetsTerminationOfParentalRights', 'For question 5E, please select NA since Yes is selected in question 5D.');
                else
                    this.set('error.MeetsTerminationOfParentalRights', null);


                if (isInFoster15OutOf22 === 2 && meetsTerminationOfParentalRights === 2 && isAgencyJointTerminationOfParentalRights && isAgencyJointTerminationOfParentalRights !== 3)
                    this.set('error.IsAgencyJointTerminationOfParentalRights', 'For question 5F, please select NA since No is selected for both questions 5D and 5E.');
                else
                    this.set('error.IsAgencyJointTerminationOfParentalRights', null);

                if (isAgencyJointTerminationOfParentalRights === 1 && !terminationExceptionsNA)
                    this.set('error.TerminationExceptions', 'For question 5G1, please select NA since Yes is selected for question 5F.');
                else if (isAgencyJointTerminationOfParentalRights === 3 && !terminationExceptionsNA)
                    this.set('error.TerminationExceptions', 'For question 5G1, please select NA since NA is selected for question 5F.');
                else if (isAgencyJointTerminationOfParentalRights === 2 && terminationExceptionsNA)
                    this.set('error.TerminationExceptions', 'For question 5G1, please do not select NA since the answer to question 5F is No. ');
                //else if (isInFoster15OutOf22 === 2 && meetsTerminationOfParentalRights === 2 && terminationExceptionsNA !== 1)
                //    this.set('error.TerminationExceptions', 'For question 5G1, please select NA since No is selected for both questions 5D and 5E.');
                else
                    this.set('error.TerminationExceptions', null);


                if (isAgencyJointTerminationOfParentalRights === 2 && isExceptionForTermination === 3)
                    this.set('error.IsExceptionForTermination', 'For question 5G, please select Yes or No since the answer to question 5F is No.');
                else if (terminationExceptionsNo && isExceptionForTermination && isExceptionForTermination !== 1)
                    this.set('error.IsExceptionForTermination', 'For question 5G, please select Yes since exceptions were selected in question 5G1. ');
                else if (terminationExceptionsNA && isExceptionForTermination && isExceptionForTermination === 1)
                    this.set('error.IsExceptionForTermination', 'For question 5G, please do not select Yes since question 5G1 was answered NA.');
                else if (isAgencyJointTerminationOfParentalRights === 1 && isExceptionForTermination && isExceptionForTermination !== 3)
                    this.set('error.IsExceptionForTermination', 'For question 5G, please select NA since Yes is selected for question 5F. ');
                else if (isAgencyJointTerminationOfParentalRights === 3 && isExceptionForTermination && isExceptionForTermination !== 3)
                    this.set('error.IsExceptionForTermination', 'For question 5G, please select NA since NA is selected for question 5F. ');
                else
                    this.set('error.IsExceptionForTermination', null);

                //Item 6
                var timeInCare = this.get('caseReview.TimeInCare'),
                    agencyConcertedEffortsExplained = this.get('caseReview.AgencyConcertedEffortsExplained'),
                    livingArrangementCode = this.get('caseReview.LivingArrangementCode'),
                    otherPlannedArrangementDocumentationDate = this.get('caseReview.OtherPlannedArrangementDocumentationDate'),
                    isOtherPlannedArrangement = this.get('caseReview.IsOtherPlannedArrangement'),
                    isOtherPlannedConcertedEffort = this.get('caseReview.IsOtherPlannedConcertedEffort'),
                    isAgencyConcertedEfforts = this.get('caseReview.IsAgencyConcertedEfforts'),
                    isNonOPPLA = this.get('isNonOPPLA')

                    ;
                if (isAgencyConcertedEfforts !== 3 && !isNonOPPLA)
                    this.set('error.IsAgencyConcertedEfforts', 'For question 6B, please select NA. since OPPLA is the only goal selected in question 6A4.');
                else if (isAgencyConcertedEfforts === 3 && isNonOPPLA)
                    this.set('error.IsAgencyConcertedEfforts', 'Please select Yes or No for question 6B, since OPPLA was not selected as a goal in question 6A4.');
                else
                    this.set('error.IsAgencyConcertedEfforts', null);

                if (livingArrangementCode === 1 && !isNonOPPLA)
                    this.set('error.LivingArrangementCode', 'For question 6C1, please select an answer other than NA since OPPLA was selected as a goal in question 6A4.');
                else
                    this.set('error.LivingArrangementCode', null);

                //Dated 07/19/18 Added by RK, Ritesh reported issue in export validation. At least one value must be selected.
                if (!isOtherPlannedArrangement && Ext.isEmpty(otherPlannedArrangementDocumentationDate))
                    this.set('error.OtherPlannedArrangementDocumentationDate', 'For question 6C2, please select an answer planned documentation date, NA or no date.');
                else if (isOtherPlannedArrangement === 1 && !Ext.isEmpty(otherPlannedArrangementDocumentationDate))
                    this.set('error.OtherPlannedArrangementDocumentationDate', 'For question 6C2, please choose NA or Date, but not both.');
                else if (isOtherPlannedArrangement === 4 && !Ext.isEmpty(otherPlannedArrangementDocumentationDate))
                    this.set('error.OtherPlannedArrangementDocumentationDate', 'For question 6C2, please choose No Date or Date, but not both.');
                else if (isOtherPlannedArrangement === 1 && !isNonOPPLA)
                    this.set('error.OtherPlannedArrangementDocumentationDate', 'For question 6C2, please select an answer other than NA since OPPLA was selected as a goal in question 6A4.');
                else
                    this.set('error.OtherPlannedArrangementDocumentationDate', null);

                if (isOtherPlannedConcertedEffort === 3 && !isNonOPPLA)
                    this.set('error.IsOtherPlannedConcertedEffort', 'For question 6C, please select an answer other than NA since OPPLA was selected as a goal in question 6A4.');
                else
                    this.set('error.IsOtherPlannedConcertedEffort', null);


                //item 7
                var item7IsApplicable = this.get('caseReview.Item7IsApplicable'),
                    isPlacedWithAllSiblings = this.get('caseReview.IsPlacedWithAllSiblings'),
                    isValidReasonForSeparation = this.get('caseReview.IsValidReasonForSeparation');

                if (isPlacedWithAllSiblings === 1 && isValidReasonForSeparation && isValidReasonForSeparation !== 3)
                    this.set('error.IsValidReasonForSeparation', 'For question 7B, please select NA since Yes is selected in question 7A. ');
                else if (isPlacedWithAllSiblings === 2 && isValidReasonForSeparation && isValidReasonForSeparation === 3)
                    this.set('error.IsValidReasonForSeparation', 'For question 7B, please select Yes or No since No is selected in question 7A.');
                else
                    this.set('error.IsValidReasonForSeparation', null);

                //Item 8

                var item8Applicability57 = this.get('caseReview.ItemApplicability57'),
                    item8Applicability58 = this.get('caseReview.ItemApplicability58'),
                    item8Applicability59 = this.get('caseReview.ItemApplicability59'),
                    item8Applicability60 = this.get('caseReview.ItemApplicability60'),
                    item8Applicability61 = this.get('caseReview.ItemApplicability61'),
                    item8Applicability62 = this.get('caseReview.ItemApplicability62'),
                    item8IsApplicable = this.get('caseReview.Item8IsApplicable'),
                    totalCaseParticipantRows = this.toArray(this.get('totalCaseParticipantRows')),
                    hasMotherOrOther = totalCaseParticipantRows.filter(function (item) {
                        return item.RoleCode === 1 || item.RoleCode === 6;
                    }).length > 0,
                    hasFatherOrOther = totalCaseParticipantRows.filter(function (item) {
                        return item.RoleCode === 2 || item.RoleCode === 6;
                    }).length > 0,
                    hasMotherOrFather = totalCaseParticipantRows.filter(function (item) {
                        return item.RoleCode === 1 || item.RoleCode === 2;
                    }).length > 0,
                    hasAssessment = false,
                    hasMotherAssessment = false,
                    hasSibling = this.get('hasSibling'),
                    item8ParticipantMother = this.get('caseReview.Item8ParticipantMother'),
                    item8ParticipantFather = this.get('caseReview.Item8ParticipantFather'),
                    hasDuplicateParticipantInMotherFather = this.checkDuplicateParticipantInMotherFather(item8ParticipantMother, item8ParticipantFather),
                    hasItem8MotherParticipant = this.hasItemParticipant(item8ParticipantMother),
                    hasItem8FatherParticipant = this.hasItemParticipant(item8ParticipantFather),
                    motherVisitationFrequencyCode = this.get('caseReview.MotherVisitationFrequencyCode'),
                    isSufficientFrequencyForMotherVisitation = this.get('caseReview.IsSufficientFrequencyForMotherVisitation'),
                    isSufficientQualityForMotherVisitation = this.get('caseReview.IsSufficientQualityForMotherVisitation'),

                    fatherVisitationFrequencyCode = this.get('caseReview.FatherVisitationFrequencyCode'),
                    isSufficientFrequencyForFatherVisitation = this.get('caseReview.IsSufficientFrequencyForFatherVisitation'),
                    isSufficentQualityForFatherVisitation = this.get('caseReview.IsSufficentQualityForFatherVisitation'),
                    siblingVisitationFrequencyCode = this.get('caseReview.SiblingVisitationFrequencyCode'),
                    isSufficientFrequencyForSiblingVisitation = this.get('caseReview.IsSufficientFrequencyForSiblingVisitation'),
                    isSufficentQualityForSiblingVisitation = this.get('caseReview.IsSufficentQualityForSiblingVisitation')
                    ;


                if (item8Applicability57 === null || item8Applicability58 === null || item8Applicability59 === null || item8Applicability60 === null || item8Applicability61 === null || item8Applicability62 === null) {

                    this.set('error.Item8IsApplicable', 'Please answer all questions on this page.');
                }
                else if (item8IsApplicable === null)
                    this.set('error.Item8IsApplicable', 'Please select Yes or No.');
                // else if (item8Applicability57 === 1 && item8IsApplicable != 1) {
                // 	this.set('error.Item8IsApplicable', isPlacedWithAllSiblings === 1 ? 'The answers above indicate that this case is applicable. Please review answers above.' : null);
                // }
                else if (isPlacedWithAllSiblings === 1 && item8Applicability57 === 1 && item7IsApplicable === 1)
                    this.set('error.Item8IsApplicable', 'Please answer No to applicability question #1 since question 7A is Yes.');
                else if (isPlacedWithAllSiblings === 2 && item8Applicability57 !== 1 && item7IsApplicable === 1)
                    this.set('error.Item8IsApplicable', 'Please answer Yes to applicability question #1 since question 7A is No.');
                else if (item8Applicability57 === 2 && item8Applicability58 === 2 && item8Applicability59 === 2 && item8Applicability60 === 2 && item8Applicability61 === 2 && item8Applicability62 === 2 && item8IsApplicable !== 1)
                    this.set('error.Item8IsApplicable', 'The answers above indicate that this case is applicable. Please review answers above. ');
                else if (item8Applicability57 === 2 && (item8Applicability58 === 1 || item8Applicability59 === 1 || item8Applicability60 === 1 || item8Applicability61 === 1 || item8Applicability62 === 1) && item8IsApplicable !== 2)
                    this.set('error.Item8IsApplicable', 'The answers above indicate that this case is not applicable. Please review answers above. ');

                else if (item8Applicability57 === 2 && item8Applicability58 === 2 && item8Applicability59 === 2 && item8Applicability60 === 2 && item8Applicability61 === 2 && item8Applicability62 === 1 && item8IsApplicable != 2)
                    this.set('error.Item8IsApplicable', 'The answers above indicate that this case is not applicable. Please review answers above. ');
                else if (!hasMotherOrOther && !hasFatherOrOther && item8IsApplicable === 1)
                    this.set('error.Item8IsApplicable', 'There are no case participants in Face Sheet table G2 that can be assessed as Mother/Father.');

                else if (!hasSibling && item8IsApplicable === 1 && !(hasItem8MotherParticipant || hasItem8FatherParticipant))
                    this.set('error.Item8IsApplicable', 'Please select No since there are no siblings listed in this case and no case participants are included in this item as Mother or Father. ');
                else if (item8IsApplicable === 2 && hasItem8MotherParticipant)
                    this.set('error.Item8IsApplicable', 'Please do not select case participant(s) who are included in this item as Mother because you indicated that this case is not applicable for an assessment of this item.');
                else if (item8IsApplicable === 2 && hasItem8FatherParticipant)
                    this.set('error.Item8IsApplicable', 'Please do not select case participant(s) who are included in this item as Father because you indicated that this case is not applicable for an assessment of this item. ');
                else if (hasDuplicateParticipantInMotherFather)
                    this.set('error.Item8IsApplicable', ' Please select different case participants for Mother and Father');
                else if (item8IsApplicable === 1 && !(hasItem8MotherParticipant || hasItem8FatherParticipant))
                    this.set('error.Item8IsApplicable', 'Please select case participant(s) as Mother and/or Father because you indicated that this case is applicable for an assessment of this item.');
                else
                    this.set('error.Item8IsApplicable', null);

                if (motherVisitationFrequencyCode === 1 && isSufficientFrequencyForMotherVisitation != 3)
                    this.set('error.IsSufficientFrequencyForMotherVisitation', 'For question 8A, please select NA since NA is selected in question 8A1.');
                else if (motherVisitationFrequencyCode != 1 && isSufficientFrequencyForMotherVisitation && isSufficientFrequencyForMotherVisitation === 3)
                    this.set('error.IsSufficientFrequencyForMotherVisitation', 'For question 8A, please select Yes or No since NA is not selected in question 8A1. ');
                else
                    this.set('error.IsSufficientFrequencyForMotherVisitation', null);

                if (isSufficientFrequencyForMotherVisitation === 3 && isSufficientQualityForMotherVisitation != 3)
                    this.set('error.IsSufficientQualityForMotherVisitation', 'For question 8C, please select NA since NA is selected in question 8A. ');
                else if (motherVisitationFrequencyCode === 7 && isSufficientQualityForMotherVisitation && isSufficientQualityForMotherVisitation != 3)
                    this.set('error.IsSufficientQualityForMotherVisitation', 'For question 8C, please select NA since Never is selected in question 8A1.');
                else
                    this.set('error.IsSufficientQualityForMotherVisitation', null);


                if (fatherVisitationFrequencyCode === 1 && isSufficientFrequencyForFatherVisitation !== 3)
                    this.set('error.IsSufficientFrequencyForFatherVisitation', 'For question 8B, please select NA since NA is selected in question8B1.');
                else if (fatherVisitationFrequencyCode !== 1 && isSufficientFrequencyForFatherVisitation && isSufficientFrequencyForFatherVisitation === 3)
                    this.set('error.IsSufficientFrequencyForFatherVisitation', 'For question 8B, please select Yes or No since NA is not selected in question 8B1.');
                else
                    this.set('error.IsSufficientFrequencyForFatherVisitation', null);


                if (isSufficientFrequencyForFatherVisitation === 3 && isSufficentQualityForFatherVisitation != 3)
                    this.set('error.IsSufficentQualityForFatherVisitation', 'For question 8D, please select NA since NA is selected in question 8B.');
                else if (fatherVisitationFrequencyCode === 7 && isSufficentQualityForFatherVisitation && isSufficentQualityForFatherVisitation === 3)
                    this.set('error.IsSufficentQualityForFatherVisitation', 'For question 8D, please select NA since Never is selected in question 8B1.');
                else
                    this.set('error.IsSufficentQualityForFatherVisitation', null);

                if (siblingVisitationFrequencyCode === 1 && isSufficientFrequencyForSiblingVisitation === 3 && !this.get('item8OneChildOrPlacedWithAllSiblings'))
                    this.set('error.IsSufficientFrequencyForSiblingVisitation', 'For question 8E, please select Yes or No since NA is selected in question 8E1.');
                else if (siblingVisitationFrequencyCode === 7 && isSufficientFrequencyForSiblingVisitation != 2)
                    this.set('error.IsSufficientFrequencyForSiblingVisitation', 'For question 8E, please select No since Never is selected in question 8E1.');
                else
                    this.set('error.IsSufficientFrequencyForSiblingVisitation', null);

                if (isSufficientFrequencyForSiblingVisitation === 3 && isSufficentQualityForSiblingVisitation != 3 && !this.get('item8OneChildOrPlacedWithAllSiblings'))
                    this.set('error.IsSufficentQualityForSiblingVisitation', 'For question 8F, please select NA since NA is selected in question 8E.');
                else
                    this.set('error.IsSufficentQualityForSiblingVisitation', null);

                //Item 9

                var item9IsApplicable = this.get('caseReview.Item9IsApplicable'),
                    isTribeProvidedTimelyNotification = this.get('caseReview.IsTribeProvidedTimelyNotification'),
                    isAccordanceWithIndianChildWelfareAct = this.get('caseReview.IsAccordanceWithIndianChildWelfareAct');

                if (item9IsApplicable === null)
                    this.set('error.Item9IsApplicable', 'Please select Yes or No.');
                else
                    this.set('error.Item9IsApplicable', null);

                if (isTribeProvidedTimelyNotification === 3 && isAccordanceWithIndianChildWelfareAct && isAccordanceWithIndianChildWelfareAct != 3)
                    this.set('error.IsAccordanceWithIndianChildWelfareAct', 'For question 9D, please select NA since NA is selected in question 9C.');
                else
                    this.set('error.IsAccordanceWithIndianChildWelfareAct', null);


                //Item 9

                var item10IsApplicable = this.get('caseReview.Item10IsApplicable'),
                    isRecentPlacementWithRelative = this.get('caseReview.IsRecentPlacementWithRelative'),
                    isPlacementWithRelativeStable = this.get('caseReview.IsPlacementWithRelativeStable'),
                    isConcertedEffortToLocateMaternalRelatives = this.get('caseReview.IsConcertedEffortToLocateMaternalRelatives'),
                    hasPlacementEffortConcernsMother = this.toArray(this.get('caseReview.PlacementEffortConcernsMother')).length > 0,
                    isConcertedEffortToLocatePaternalRelatives = this.get('caseReview.IsConcertedEffortToLocatePaternalRelatives'),
                    hasPlacementEffortConcernsFather = this.toArray(this.get('caseReview.PlacementEffortConcernsFather')).length > 0,
                    hasPlacementRows = this.get('hasPlacementRows')
                    ;

                if (item10IsApplicable === null)
                    this.set('error.Item10IsApplicable', 'Please select Yes or No.');
                else
                    this.set('error.Item10IsApplicable', null);

                if (!hasPlacementRows)
                    this.set('error.IsRecentPlacementWithRelative', 'Please complete table 4A1 before answering questions in this item.');
                else
                    this.set('error.IsRecentPlacementWithRelative', null);

                if (isRecentPlacementWithRelative === 2 && isPlacementWithRelativeStable && isPlacementWithRelativeStable != 3)
                    this.set('error.IsPlacementWithRelativeStable', 'For question 10A2, please select NA since No is selected in question 10A1.');
                else if (isRecentPlacementWithRelative === 1 && isPlacementWithRelativeStable && isPlacementWithRelativeStable === 3)
                    this.set('error.IsPlacementWithRelativeStable', 'For question 10A2, please select Yes or No since Yes is selected in question 10A1.');
                else
                    this.set('error.IsPlacementWithRelativeStable', null);


                if (isConcertedEffortToLocateMaternalRelatives && isConcertedEffortToLocateMaternalRelatives != 2 && hasPlacementEffortConcernsMother)
                    this.set('error.IsConcertedEffortToLocateMaternalRelatives', 'Please specify concerns only if your answer to question 10B is No.');
                else if (isRecentPlacementWithRelative === 1 && isPlacementWithRelativeStable === 1 && isConcertedEffortToLocateMaternalRelatives != 3)
                    this.set('error.IsConcertedEffortToLocateMaternalRelatives', 'For question 10B, please select NA since Yes is selected in both questions 10A1 and 10A2.');
                else if (isConcertedEffortToLocateMaternalRelatives === 2 && !hasPlacementEffortConcernsMother)
                    this.set('error.IsConcertedEffortToLocateMaternalRelatives', 'For question 10B, please specify the area in which concerns existed for a response of No.');
                else
                    this.set('error.IsConcertedEffortToLocateMaternalRelatives', null);


                if (isConcertedEffortToLocatePaternalRelatives && isConcertedEffortToLocatePaternalRelatives != 2 && hasPlacementEffortConcernsFather)
                    this.set('error.IsConcertedEffortToLocatePaternalRelatives', 'Please specify concerns only if your answer to question 10C is No.');
                else if (isRecentPlacementWithRelative === 1 && isPlacementWithRelativeStable === 1 && isConcertedEffortToLocatePaternalRelatives != 3)
                    this.set('error.IsConcertedEffortToLocatePaternalRelatives', 'For question 10C, please select NA since Yes is selected in both questions 10A1 and 10A2.');
                else if (isConcertedEffortToLocatePaternalRelatives === 2 && !hasPlacementEffortConcernsFather)
                    this.set('error.IsConcertedEffortToLocatePaternalRelatives', 'For question 10C, please specify the area in which concerns existed for a response of No.');
                else
                    this.set('error.IsConcertedEffortToLocatePaternalRelatives', null);

                //Item 11

                var item11Applicability63 = this.get('caseReview.ItemApplicability63'),
                    item11Applicability64 = this.get('caseReview.ItemApplicability64'),
                    item11Applicability65 = this.get('caseReview.ItemApplicability65'),
                    item11Applicability66 = this.get('caseReview.ItemApplicability66'),
                    item11Applicability67 = this.get('caseReview.ItemApplicability67'),
                    item11Applicability261 = this.get('caseReview.ItemApplicability261'),
                    item11IsApplicable = this.get('caseReview.Item11IsApplicable'),
                    item11ParticipantMother = this.get('caseReview.Item11ParticipantMother'),
                    item11ParticipantFather = this.get('caseReview.Item11ParticipantFather'),
                    hasItem11MotherParticipant = this.hasItemParticipant(item11ParticipantMother),
                    hasItem11FatherParticipant = this.hasItemParticipant(item11ParticipantFather),
                    isConcertedEffortMotherFosterRelationship = this.get('caseReview.IsConcertedEffortMotherFosterRelationship'),
                    effortsToSupportMotherFosterRelationship = this.toArray(this.get('caseReview.EffortsToSupportMotherFosterRelationship')),
                    effortsToSupportMotherFosterRelationshipNA = this.hasValueInArray(effortsToSupportMotherFosterRelationship, 164),
                    isConcertedEffortFatherFosterRelationship = this.get('caseReview.IsConcertedEffortFatherFosterRelationship'),
                    effortsToSupportFatherFosterRelationship = this.toArray(this.get('caseReview.EffortsToSupportFatherFosterRelationship')),
                    effortsToSupportFatherFosterRelationshipNA = this.hasValueInArray(effortsToSupportFatherFosterRelationship, 171);

                hasDuplicateParticipantInMotherFather = this.checkDuplicateParticipantInMotherFather(item11ParticipantMother, item11ParticipantFather);

                if (item11Applicability63 === null || item11Applicability64 === null || item11Applicability65 === null || item11Applicability66 === null || item11Applicability67 === null || item11Applicability261 === null) {
                    this.set('error.Item11IsApplicable', 'Please answer all questions on this page.');
                }
                else if (item11IsApplicable === null)
                    this.set('error.Item11IsApplicable', 'Please select Yes or No.');

                else if ((item11Applicability63 === 1 || item11Applicability64 === 1 || item11Applicability65 === 1 || item11Applicability66 === 1 || item11Applicability67 === 1 || item11Applicability261 === 1) && item11IsApplicable === 1) {
                    this.set('error.Item11IsApplicable', 'The answers above indicate that this case is not applicable. Please review answers above. ');
                }
                else if ((item11Applicability63 === 2 && item11Applicability64 === 2 && item11Applicability65 === 2 && item11Applicability66 === 2 && item11Applicability67 === 2 && item11Applicability261 === 2) && item11IsApplicable === 2) {
                    this.set('error.Item11IsApplicable', 'The answers above indicate that this case is applicable. Please review answers above.');
                }
                else if (!hasMotherOrOther && !hasFatherOrOther)
                    this.set('error.Item11IsApplicable', 'There are no case participants in Face Sheet table G2 that can be assessed as Mother/Father.');
                else if (item11IsApplicable === 1 && !(hasItem11MotherParticipant || hasItem11FatherParticipant))
                    this.set('error.Item11IsApplicable', 'Please select case participant(s) as Mother and/or Father because you indicated that this case is applicable for an assessment of this item.');
                else if (item11IsApplicable === 2 && hasItem11MotherParticipant)
                    this.set('error.Item11IsApplicable', 'Please do not select case participant(s) who are included in this item as Mother because you indicated that this case is not applicable for an assessment of this item.');
                else if (item11IsApplicable === 2 && hasItem11FatherParticipant)
                    this.set('error.Item11IsApplicable', 'Please do not select case participant(s) who are included in this item as Father because you indicated that this case is not applicable for an assessment of this item. ');
                else if (hasDuplicateParticipantInMotherFather)
                    this.set('error.Item11IsApplicable', ' Please select different case participants for Mother and Father');
                else
                    this.set('error.Item11IsApplicable', null);

                if (hasItem11MotherParticipant && isConcertedEffortMotherFosterRelationship && isConcertedEffortMotherFosterRelationship === 3)
                    this.set('error.IsConcertedEffortMotherFosterRelationship', 'For question 11A, please do not select NA since a case participant was selected as Mother and marked applicable for assessment in this item.');
                else
                    this.set('error.IsConcertedEffortMotherFosterRelationship', null);

                if (isConcertedEffortMotherFosterRelationship === 1 && effortsToSupportMotherFosterRelationshipNA)
                    this.set('error.EffortsToSupportMotherFosterRelationship', 'For question 11A1, please select a response other than NA since question 11A is Yes.');
                else if (isConcertedEffortMotherFosterRelationship === 2 && !effortsToSupportMotherFosterRelationshipNA)
                    this.set('error.EffortsToSupportMotherFosterRelationship', 'For question 11A1, please select NA since No is selected in question 11A. ');
                else if (effortsToSupportMotherFosterRelationshipNA && effortsToSupportMotherFosterRelationship.length > 1)
                    this.set('error.EffortsToSupportMotherFosterRelationship', 'For question 11A1, if you have selected NA, please ensure that no other selections were made. ');
                else
                    this.set('error.EffortsToSupportMotherFosterRelationship', null);

                if (hasItem11FatherParticipant && isConcertedEffortFatherFosterRelationship && isConcertedEffortFatherFosterRelationship === 3)
                    this.set('error.IsConcertedEffortFatherFosterRelationship', 'For question 11B, please do not select NA since a case participant was selected as Father and marked applicable for assessment in this item');
                else
                    this.set('error.IsConcertedEffortFatherFosterRelationship', null);


                if (isConcertedEffortFatherFosterRelationship === 1 && effortsToSupportFatherFosterRelationshipNA)
                    this.set('error.EffortsToSupportFatherFosterRelationship', 'For question 11B1, please select a response other than NA since question 11B is Yes.');
                else if (isConcertedEffortFatherFosterRelationship === 2 && !effortsToSupportFatherFosterRelationshipNA)
                    this.set('error.EffortsToSupportFatherFosterRelationship', 'For question 11B1, please select NA since No is selected in question 11B. ');
                else
                    this.set('error.EffortsToSupportFatherFosterRelationship', null);

                //Item 12A
                var item12aParticipantChild = this.hasItemParticipant(this.get('caseReview.Item12aParticipantChild'));

                if (isHomeServiceCase && !item12aParticipantChild)
                    this.set('error.Item12aIsApplicable', 'Please indicate the name of at least one child who is included in an assessment of this item. ');
                else
                    this.set('error.Item12aIsApplicable', null);

                //Item 12B
                var item12bApp68 = this.get('caseReview.ItemApplicability68'),
                    item12bApp69 = this.get('caseReview.ItemApplicability69'),
                    item12bApp70 = this.get('caseReview.ItemApplicability70'),
                    item12bApp71 = this.get('caseReview.ItemApplicability71'),
                    item12bApp72 = this.get('caseReview.ItemApplicability72'),
                    isNeedsServicesApplicableForMother = this.get('caseReview.IsNeedsServicesApplicableForMother'),
                    isNeedsServicesApplicableForFather = this.get('caseReview.IsNeedsServicesApplicableForFather'),
                    item12bParticipantMother = this.get('caseReview.Item12bParticipantMother'),
                    item12bParticipantFather = this.get('caseReview.Item12bParticipantFather'),
                    hasItem12bMotherParticipant = this.hasItemParticipant(item12bParticipantMother),
                    hasItem12bFatherParticipant = this.hasItemParticipant(item12bParticipantFather),

                    q12b1 = this.get('caseReview.IsComprehensiveAssessementForMotherConducted'),
                    q12b2 = this.get('caseReview.IsComprehensiveAssessementForFatherConducted');

                hasDuplicateParticipantInMotherFather = this.checkDuplicateParticipantInMotherFather(item12bParticipantMother, item12bParticipantFather);
                if (item12bApp68 === null || item12bApp69 === null || item12bApp70 === null || item12bApp71 === null || item12bApp72 === null) {
                    this.set('error.Item12bIsApplicable', 'Please answer all questions on this page.');
                }
                else if (isNeedsServicesApplicableForMother === null) {
                    this.set('error.Item12bIsApplicable', 'Please select Yes or No.');
                }
                else if (isNeedsServicesApplicableForFather === null)
                    this.set('error.Item12bIsApplicable', 'Please select Yes or No.');
                else if ((item12bApp68 === 1 || item12bApp69 === 1 || item12bApp70 === 1 || item12bApp71 === 1 || item12bApp72 === 1) && (isNeedsServicesApplicableForMother === 1 && isNeedsServicesApplicableForFather === 1)) {
                    this.set('error.Item12bIsApplicable', 'The answers above indicate that this case is not applicable. Please review answers above.');
                }
                else if (item12bApp68 === 2 && item12bApp69 === 2 && item12bApp70 === 2 && item12bApp71 === 2 && item12bApp72 === 2 && (isNeedsServicesApplicableForMother === 2 && isNeedsServicesApplicableForFather === 2)) {
                    this.set('error.Item12bIsApplicable', 'The answers above indicate that this case is applicable. Please review answers above. ');
                }
                else if (!hasMotherOrOther && !hasFatherOrOther)
                    this.set('error.Item12bIsApplicable', 'There are no case participants in Face Sheet table G2 that can be assessed as Mother/Father.');
                else if (isNeedsServicesApplicableForMother === 2 && hasItem12bMotherParticipant)
                    this.set('error.Item12bIsApplicable', 'Please do not select case participant(s) who are included in this sub-item as Mother because you indicated that sub-item 12B is not applicable for Mother.');
                else if (isNeedsServicesApplicableForFather === 2 && hasItem12bFatherParticipant)
                    this.set('error.Item12bIsApplicable', 'Please do not select case participant(s) who are included in this sub-item as Mother because you indicated that sub-item 12B is not applicable for Father. ');
                else if (isNeedsServicesApplicableForMother === 1 && !hasItem12bMotherParticipant)
                    this.set('error.Item12bIsApplicable', 'Please select case participant(s) to be included in this sub-item as Mother.');
                else if (isNeedsServicesApplicableForFather === 1 && !hasItem12bFatherParticipant)
                    this.set('error.Item12bIsApplicable', 'Please select case participant(s) to be included in this sub-item as Father. ');
                else if (hasDuplicateParticipantInMotherFather)
                    this.set('error.Item12bIsApplicable', ' Please select different case participants for Mother and Father');
                else
                    this.set('error.Item12bIsApplicable', null);


                if (isNeedsServicesApplicableForMother === 1 && q12b1 === 3)
                    this.set('error.IsComprehensiveAssessementForMotherConducted', 'For question 12B1, please do not select NA since a case participant was selected as Mother and marked applicable for assessment in this item.');
                else
                    this.set('error.IsComprehensiveAssessementForMotherConducted', null);

                if (isNeedsServicesApplicableForFather === 1 && q12b2 === 3)
                    this.set('error.IsComprehensiveAssessementForFatherConducted', 'For question 12B2, please do not select NA since a case participant was selected as Father and marked applicable for assessment in this item. ');
                else
                    this.set('error.IsComprehensiveAssessementForFatherConducted', null);

                //Item 12C
                var item12cIsApplicable = this.get('caseReview.Item12cIsApplicable');

                if (item12cIsApplicable === null)
                    this.set('error.Item12cIsApplicable', 'Please select Yes or No.');
                else
                    this.set('error.Item12cIsApplicable', null);

                //Item 13
                var item13App73 = this.get('caseReview.ItemApplicability73'),
                    item13App74 = this.get('caseReview.ItemApplicability74'),
                    item13App75 = this.get('caseReview.ItemApplicability75'),
                    item13App292 = this.get('caseReview.ItemApplicability292'),
                    item13App76 = this.get('caseReview.ItemApplicability76'),
                    item13App77 = this.get('caseReview.ItemApplicability77'),
                    item13App78 = this.get('caseReview.ItemApplicability78'),
                    item13IsApplicable = this.get('caseReview.Item13IsApplicable'),
                    item13ParticipantChild = this.hasItemParticipant(this.get('caseReview.Item13ParticipantChild')),
                    item13ParticipantMother = this.get('caseReview.Item13ParticipantMother'),
                    item13ParticipantFather = this.get('caseReview.Item13ParticipantFather'),
                    hasItem13MotherParticipant = this.hasItemParticipant(item13ParticipantMother),
                    hasItem13FatherParticipant = this.hasItemParticipant(item13ParticipantFather),

                    q13a = this.get('caseReview.IsAgencyConcertedEffortsToInvolveTheChild'),
                    q13b = this.get('caseReview.IsAgencyConcertedEffortsToInvolveTheMother'),
                    q13c = this.get('caseReview.IsAgencyConcertedEffortsToInvolveTheFather');

                hasDuplicateParticipantInMotherFather = this.checkDuplicateParticipantInMotherFather(item13ParticipantMother, item13ParticipantFather);

                if (item13App73 === null || item13App74 === null || item13App75 === null || item13App76 === null || item13App77 === null || item13App78 === null || item13App292 === null) {
                    this.set('error.Item13IsApplicable', 'Please answer all questions on this page.');
                }
                else if (item13App73 === null) {
                    this.set('error.Item13IsApplicable', 'Please select Yes or No.');
                }
                else if (item13IsApplicable === null)
                    this.set('error.Item13IsApplicable', 'Please select Yes or No.');

                else if (item13App73 === 1 && (item13App74 === 2 || item13App75 === 2 || item13App292 === 2 || item13App76 === 2 || item13App77 === 2 || item13App78 === 2) && item13IsApplicable != 2) {
                    this.set('error.Item13IsApplicable', 'The answers above indicate that this case is not applicable. Please review answers above.');
                }
                else if (item13App73 === 2 && item13IsApplicable != 1) {
                    this.set('error.Item13IsApplicable', 'The answers above indicate that this case is applicable. Please review answers above. ');
                }
                else if (item13IsApplicable === 1 && (item13App74 === 1 || item13App75 === 1 || item13App292 === 1 || item13App76 === 1 || item13App77 === 1 || item13App78 === 1) && hasItem13MotherParticipant) {
                    this.set('error.Item13IsApplicable', 'Please select NA for case participants who are included in this item as Mother because you indicated that this case is not applicable for an assessment of this item. ');
                }
                else if (item13IsApplicable === 1 && (item13App74 === 1 || item13App75 === 1 || item13App292 === 1 || item13App76 === 1 || item13App77 === 1 || item13App78 === 1) && hasItem13FatherParticipant) {
                    this.set('error.Item13IsApplicable', 'Please select NA for case participants who are included in this item as Father because you indicated that this case is not applicable for an assessment of this item.');
                }
                else if (item13App74 === 2 && item13App75 === 2 && item13App292 === 2 && item13App76 === 2 && item13App77 === 2 && item13App78 === 2 && item13IsApplicable != 1) {
                    this.set('error.Item13IsApplicable', 'The answers above indicate that this case is applicable. Please review answers above. ');
                }
                else if (item13App74 === 2 && item13App75 === 2 && item13App292 === 2 && item13App76 === 2 && item13App77 === 2 && item13App78 === 2 && item13IsApplicable === 1 && !(hasItem13MotherParticipant || hasItem13FatherParticipant)) {
                    this.set('error.Item13IsApplicable', 'Please select a case participant to be included in this item as Mother or Father.');
                }
                else if (item13IsApplicable === 2 && hasItem13MotherParticipant)
                    this.set('error.Item13IsApplicable', 'Please do not select case participant(s) who are included in this item as Mother because you indicated that this case is not applicable for an assessment of this item.');
                else if (item13IsApplicable === 2 && hasItem13FatherParticipant)
                    this.set('error.Item13IsApplicable', 'Please do not select case participant(s) who are included in this item as Father because you indicated that this case is not applicable for an assessment of this item. ');
                else if (item13IsApplicable === 1 && !(hasItem13MotherParticipant || hasItem13FatherParticipant))
                    this.set('error.Item13IsApplicable', 'Please select case participant(s) as Mother and/or Father because you indicated that this case is applicable for an assessment of this item.');
                else if (!hasMotherOrOther && !hasFatherOrOther)
                    this.set('error.Item13IsApplicable', 'There are no case participants in Face Sheet table G2 that can be assessed as Mother/Father.');
                else if (isHomeServiceCase && item13IsApplicable === 1 && item13App73 === 1 && item13ParticipantChild)
                    this.set('error.Item13IsApplicable', 'Please do not select a child who is included in an assessment of this item since answers to the questions above indicate that the case is not applicable for assessment of a child.');
                else if (isHomeServiceCase && item13IsApplicable === 1 && item13App73 === 2 && !item13ParticipantChild)
                    this.set('error.Item13IsApplicable', 'Please indicate the name of at least one child who is included in an assessment of this item.');
                else if (isHomeServiceCase && item13IsApplicable === 2 && item13ParticipantChild)
                    this.set('error.Item13IsApplicable', 'Please do not select a child who is included in an assessment of this item if the case is not applicable.');
                else if (hasDuplicateParticipantInMotherFather)
                    this.set('error.Item13IsApplicable', ' Please select different case participants for Mother and Father');
                else
                    this.set('error.Item13IsApplicable', null);


                if (item13App73 === 2 && item13IsApplicable === 1 && !(hasItem13MotherParticipant || hasItem13FatherParticipant) && q13a === 3)
                    this.set('error.IsAgencyConcertedEffortsToInvolveTheChild', 'When question 13A is NA and no case participants are included in this item as Mother or Father, item 13 is not applicable for assessment. Please return to the applicability page for item 13 and select No. ');
                else
                    this.set('error.IsAgencyConcertedEffortsToInvolveTheChild', null);


                if (hasItem13MotherParticipant && q13b === 3)
                    this.set('error.IsAgencyConcertedEffortsToInvolveTheMother', 'For question 13B, please do not select NA since a case participant was selected as Mother and marked applicable for assessment in this item.');
                else
                    this.set('error.IsAgencyConcertedEffortsToInvolveTheMother', null);

                if (hasItem13FatherParticipant && q13c === 3)
                    this.set('error.IsAgencyConcertedEffortsToInvolveTheFather', 'For question 13C, please do not select NA since a case participant was selected as Father and marked applicable for assessment in this item.');
                else
                    this.set('error.IsAgencyConcertedEffortsToInvolveTheFather', null);


                //Item 14
                var q14a1 = this.get('caseReview.ResponsiblePartyVisitationFrequencyCode'),
                    q14a = this.get('caseReview.IsResponsiblePartyVisitationFrequencySufficient'),
                    q14b = this.get('caseReview.IsResponsiblePartyVisitationQualitySufficient')
                    ;

                if (q14a1 === 7 && q14a != 2)
                    this.set('error.IsResponsiblePartyVisitationFrequencySufficient', 'For question 14A, please select No since Never is selected in question 14A1. ');
                else
                    this.set('error.IsResponsiblePartyVisitationFrequencySufficient', null);


                if (q14a1 === 7 && q14b != 3)
                    this.set('error.IsResponsiblePartyVisitationQualitySufficient', 'For question 14B, please select NA since Never is selected in question 14A1.');
                else if (q14a === 1 && q14b === 3)
                    this.set('error.IsResponsiblePartyVisitationQualitySufficient', 'For question 14B, please select Yes or No since Yes is selected in question 14A.');
                else
                    this.set('error.IsResponsiblePartyVisitationQualitySufficient', null);


                //Item 15
                var item15App79 = this.get('caseReview.ItemApplicability79'),
                    item15App80 = this.get('caseReview.ItemApplicability80'),
                    item15App293 = this.get('caseReview.ItemApplicability293'),
                    item15App81 = this.get('caseReview.ItemApplicability81'),
                    item15App82 = this.get('caseReview.ItemApplicability82'),
                    item15App83 = this.get('caseReview.ItemApplicability83'),
                    item15IsApplicable = this.get('caseReview.Item15IsApplicable'),
                    item15ParticipantMother = this.get('caseReview.Item15ParticipantMother'),
                    item15ParticipantFather = this.get('caseReview.Item15ParticipantFather'),
                    hasItem15MotherParticipant = this.hasItemParticipant(item15ParticipantMother),
                    hasItem15FatherParticipant = this.hasItemParticipant(item15ParticipantFather),

                    q15a1 = this.get('caseReview.ResponsiblePartyVisitationFrequencyWithMotherCode'),
                    q15a2 = this.get('caseReview.IsResponsiblePartyVisitationFrequencyWithMotherSufficient'),
                    q15b1 = this.get('caseReview.ResponsiblePartyVisitationFrequencyWithFatherCode'),
                    q15b2 = this.get('caseReview.IsResponsiblePartyVisitationFrequencyWithFatherSufficient'),
                    q15c = this.get('caseReview.IsResponsiblePartyVisitationQualityWithMotherSufficient'),
                    q15d = this.get('caseReview.IsResponsiblePartyVisitationQualityWithFatherSufficient');

                hasDuplicateParticipantInMotherFather = this.checkDuplicateParticipantInMotherFather(item15ParticipantMother, item15ParticipantFather);

                if (item15App79 === null || item15App80 === null || item15App293 === null || item15App81 === null || item15App82 === null || item15App83 === null) {
                    this.set('error.Item15IsApplicable', 'Please answer all questions on this page.');
                }
                else if (item15IsApplicable === null)
                    this.set('error.Item15IsApplicable', 'Please select Yes or No.');

                else if ((item15App79 === 1 || item15App80 === 1 || item15App293 === 1 || item15App81 === 1 || item15App82 === 1 || item15App83 === 1) && item15IsApplicable === 1) {
                    this.set('error.Item15IsApplicable', 'The answers above indicate that this case is not applicable. Please review answers above. ');
                }
                else if ((item15App79 === 2 && item15App80 === 2 && item15App293 === 2 && item15App81 === 2 || item15App82 === 2 || item15App83 === 2) && item15IsApplicable === 2) {
                    this.set('error.Item15IsApplicable', 'The answers above indicate that this case is applicable. Please review answers above.');
                }
                else if (!hasMotherOrOther && !hasFatherOrOther)
                    this.set('error.Item15IsApplicable', 'There are no case participants in Face Sheet table G2 that can be assessed as Mother/Father.');
                else if (item15IsApplicable === 1 && !(hasItem15MotherParticipant || hasItem15FatherParticipant))
                    this.set('error.Item15IsApplicable', 'Please select case participant(s) as Mother and/or Father because you indicated that this case is applicable for an assessment of this item.');
                else if (item15IsApplicable === 2 && hasItem15MotherParticipant)
                    this.set('error.Item15IsApplicable', 'Please do not select case participant(s) who are included in this item as Mother because you indicated that this case is not applicable for an assessment of this item.');
                else if (item15IsApplicable === 2 && hasItem15FatherParticipant)
                    this.set('error.Item15IsApplicable', 'Please do not select case participant(s) who are included in this item as Father because you indicated that this case is not applicable for an assessment of this item. ');
                else if (hasDuplicateParticipantInMotherFather)
                    this.set('error.Item15IsApplicable', ' Please select different case participants for Mother and Father');
                else
                    this.set('error.Item15IsApplicable', null);


                if (hasItem15MotherParticipant && q15a1 && q15a1 === 1)
                    this.set('error.ResponsiblePartyVisitationFrequencyWithMotherCode', 'For question 15A1, please do not select NA since a case participant was selected as Mother and marked applicable for assessment in this item.');
                else
                    this.set('error.ResponsiblePartyVisitationFrequencyWithMotherCode', null);

                if (hasItem15MotherParticipant && q15a2 && q15a2 === 3)
                    this.set('error.IsResponsiblePartyVisitationFrequencyWithMotherSufficient', 'For question 15A2, please do not select NA since a case participant was selected as Mother and marked applicable for assessment in this item');
                else if (q15a1 === 1 && q15a2 != 3)
                    this.set('error.IsResponsiblePartyVisitationFrequencyWithMotherSufficient', 'For question 15A2, please select NA since NA is selected in question 15A1.');
                else
                    this.set('error.IsResponsiblePartyVisitationFrequencyWithMotherSufficient', null);


                if (hasItem15FatherParticipant && q15b1 && q15b1 === 1)
                    this.set('error.ResponsiblePartyVisitationFrequencyWithFatherCode', 'For question 15B1, please do not select NA since a case participant was selected as Father and marked applicable for assessment in this item');
                else
                    this.set('error.ResponsiblePartyVisitationFrequencyWithFatherCode', null);

                if (hasItem15FatherParticipant && q15b2 && q15b2 === 3)
                    this.set('error.IsResponsiblePartyVisitationFrequencyWithFatherSufficient', 'For question 15B2, please do not select NA since a case participant was selected as Mother and marked applicable for assessment in this item');
                else if (q15b1 === 1 && q15b2 != 3)
                    this.set('error.IsResponsiblePartyVisitationFrequencyWithFatherSufficient', 'For question 15B2, please select NA since NA is selected in question 15B1.');
                else
                    this.set('error.IsResponsiblePartyVisitationFrequencyWithFatherSufficient', null);


                if (q15a1 === 1 && q15c != 3)
                    this.set('error.IsResponsiblePartyVisitationQualityWithMotherSufficient', 'For question 15C, please select NA since NA is selected in question 15A1.');
                else if (q15a1 === 7 && q15c != 3)
                    this.set('error.IsResponsiblePartyVisitationQualityWithMotherSufficient', 'For question 15C, please select NA since Never is selected in question 15A1.');
                else
                    this.set('error.IsResponsiblePartyVisitationQualityWithMotherSufficient', null);


                if (q15b1 === 1 && q15d != 3)
                    this.set('error.IsResponsiblePartyVisitationQualityWithFatherSufficient', 'For question 15D, please select NA since NA is selected in question 15B1.');
                else if (q15b1 === 7 && q15d != 3)
                    this.set('error.IsResponsiblePartyVisitationQualityWithFatherSufficient', 'For question 15D, please select NA since Never is selected in question 15B1.');
                else
                    this.set('error.IsResponsiblePartyVisitationQualityWithFatherSufficient', null);


                //Item 16
                var item16IsApplicable = this.get('caseReview.Item16IsApplicable'),
                    hasItem16ParticipantChild = this.hasItemParticipant(this.get('caseReview.Item16ParticipantChild'))
                    ;

                if (item16IsApplicable === null)
                    this.set('error.Item16IsApplicable', 'Please select Yes or No.');
                else if (isFosterCareCase && targetChildDOB && item16IsApplicable != 1 && ((episodeDischargeDate && Ext.Date.diff(targetChildDOB, episodeDischargeDate, 'y') >= 3) || Ext.Date.diff(targetChildDOB, reviewCompleted, 'y') >= 3))
                    this.set('error.Item16IsApplicable', 'Please select Yes. This case is applicable for assessment because this is a foster care case of a child age three or older. ');

                else if (isHomeServiceCase && item16IsApplicable === 1 && !hasItem16ParticipantChild)
                    this.set('error.Item16IsApplicable', 'Please indicate the name of at least one child who is included in an assessment of this item.');
                else if (isHomeServiceCase && item16IsApplicable === 2 && hasItem16ParticipantChild)
                    this.set('error.Item16IsApplicable', 'Please indicate the name of at least one child who is included in an assessment of this item.');
                else
                    this.set('error.Item16IsApplicable', null);


                //Item 17
                var item17IsApplicable = this.get('caseReview.Item17IsApplicable'),
                    isAgencyAssessPhysicalHealthNeeds = this.get('caseReview.IsAgencyAssessPhysicalHealthNeeds'),
                    isAgencyAssessDentalHealthNeeds = this.get('caseReview.IsAgencyAssessDentalHealthNeeds'),
                    hasItem17ParticipantChild = this.hasItemParticipant(this.get('caseReview.Item17ParticipantChild')),
                    fosterFederalCaseManagamentCriteria = this.toArray(this.get('caseReview.FosterFederalCaseManagamentCriteria')),
                    fosterFederalCaseManagamentCriteriaNA = this.hasValueInArray(fosterFederalCaseManagamentCriteria, 178),
                    fosterFederalCaseManagamentCriteriaNo = this.hasValueInArray(fosterFederalCaseManagamentCriteria, 179)

                    ;
                if (item17IsApplicable === null)
                    this.set('error.Item17IsApplicable', 'Please select Yes or No.');
                else if (isHomeServiceCase && item17IsApplicable === 1 && !hasItem17ParticipantChild)
                    this.set('error.Item17IsApplicable', 'Please indicate the name of at least one child who is included in an assessment of this item.');
                else if (isHomeServiceCase && item17IsApplicable === 2 && hasItem17ParticipantChild)
                    this.set('error.Item17IsApplicable', 'Please indicate the name of at least one child who is included in an assessment of this item.');
                else
                    this.set('error.Item17IsApplicable', null);


                if (isFosterCareCase && isAgencyAssessPhysicalHealthNeeds === 3)
                    this.set('error.IsAgencyAssessPhysicalHealthNeeds', 'For question 17A1, for foster care cases, please answer Yes or No.');
                else
                    this.set('error.IsAgencyAssessPhysicalHealthNeeds', null);

                if (isHomeServiceCase && item17IsApplicable === 1 && hasItem17ParticipantChild && isAgencyAssessPhysicalHealthNeeds === 3 && isAgencyAssessDentalHealthNeeds === 3)
                    this.set('error.IsAgencyAssessDentalHealthNeeds', 'For questions 17A1 and 17A2, please answer Yes or No to at least one question since a child was selected as applicable for assessment in this item.');
                else
                    this.set('error.IsAgencyAssessDentalHealthNeeds', null);

                if (isFosterCareCase && fosterFederalCaseManagamentCriteriaNA)
                    this.set('error.FosterFederalCaseManagamentCriteria', 'For question 17A4, please do not select NA since this is a foster care case. ');
                else if (isFosterCareCase && fosterFederalCaseManagamentCriteriaNo && fosterFederalCaseManagamentCriteria.length > 1)
                    this.set('error.FosterFederalCaseManagamentCriteria', 'For question 17A4, if you have selected "No evidence found", please ensure that no other selections were made.');
                else
                    this.set('error.FosterFederalCaseManagamentCriteria', null);


                //Item 18
                var item18IsApplicable = this.get('caseReview.Item18IsApplicable'),
                    hasItem18ParticipantChild = this.hasItemParticipant(this.get('caseReview.Item18ParticipantChild'));

                if (item18IsApplicable === null)
                    this.set('error.Item18IsApplicable', 'Please select Yes or No.');
                else if (isHomeServiceCase && item18IsApplicable === 1 && !hasItem18ParticipantChild)
                    this.set('error.Item18IsApplicable', 'Please indicate the name of at least one child who is included in an assessment of this item.');
                else if (isHomeServiceCase && item18IsApplicable === 2 && hasItem18ParticipantChild)
                    this.set('error.Item18IsApplicable', 'Please indicate the name of at least one child who is included in an assessment of this item.');
                else
                    this.set('error.Item18IsApplicable', null);

                return msg;
            }
        },
        disabledItem: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (record) {
                var userId = QuickStart.util.Global.getUser().id;

                var flag = (record && (record.get('CaseStatusCode') === 6 || record.get('CaseStatusCode') === 7 || record.get('CaseStatusCode') === 8)) ||
                    !(
                        //(QuickStart.util.Global.permissions.allowEditIRRCase() && this.hasUserInCaseReview(userId)) ||
                        //(QuickStart.util.Global.permissions.allowEditCaseData() && this.hasUserInCaseReview(userId))
                        (QuickStart.util.Global.permissions.allowEditIRRCase() && this.hasUserInCaseReviewer(userId)) ||
                        (QuickStart.util.Global.permissions.allowEditCaseData() && this.hasUserInCaseReviewer(userId))
                    );
                return flag;
            }
        },
        disabledNotes:
        {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (record) {
                var userId = QuickStart.util.Global.getUser().id;
                return !this.hasUserInCaseReview(userId);
            }
        },
        enabledSave: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (record) {
                var userId = QuickStart.util.Global.getUser().id;

                var flag = !(record && (record.get('CaseStatusCode') === 6 || record.get('CaseStatusCode') === 7 || record.get('CaseStatusCode') === 8)) &&  // case not eliminated
                    this.hasUserInCaseReview(userId) &&                                                             // user must be is case
                    (
                        QuickStart.util.Global.permissions.allowEditIRRCase() ||         //if case should be IRR and user has  Edit  Irr case permission
                        QuickStart.util.Global.permissions.allowEditCaseData() ||                                    //user has edit case permission
                        QuickStart.util.Global.permissions.allowAddEditQANote()                                     //user has edit qa note permission

                    );
                return flag;
            }
        },
        caseStatusReadOnly: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (record) {

                var flag = (record && (record.get('CaseStatusCode') === 6 || record.get('CaseStatusCode') === 7 || record.get('CaseStatusCode') === 8));
                return flag;
            }
        },
        enabledCaseCompare: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (record) {
                var userId = QuickStart.util.Global.getUser().id;

                var flag = (record && record.get('CaseStatusCode') === 7) &&  // case approved
                    record.get('IRRReviewerID') === userId && record.get('IsIRR') === true       //if case should be IRR and user has  Edit  Irr case permission
                    ;
                return flag;
            }
        },

        hasUserInCaseReview: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var userId = QuickStart.util.Global.getUser().id;
                return (data && data.get('CaseStatusCode') != 6) && this.hasUserInCaseReview(userId);
            }
        },
        hasDemographicAndParticipantRows: {
            bind: {
                bindTo: '{caseReview}',
                deep: true
            },
            get: function (data) {
                var childDemographicStore = this.getStore('childDemographicStore'),
                    caseParticipantStore = this.getStore('caseParticipantStore'),
                    caseParticipants = this.get('caseReview.FaceSheet.CR_CaseParticipant_Collection'),
                    childDemographics = this.get('caseReview.FaceSheet.CR_ChildDemographic_Collection'),
                    rows = childDemographicStore && childDemographicStore.getCount() > 0 && caseParticipantStore && caseParticipantStore.getCount() > 0;

                if (childDemographicStore === null && caseParticipantStore === null) {
                    rows = caseParticipants && childDemographics && caseParticipants.length > 0 && childDemographics.length > 0;
                }
                if (data != null)
                    this.set('caseReview.TS_CR', new Date());
                return rows;
            }
        },
        totalDemographicRows: {
            bind: {
                bindTo: '{caseReview}',
                deep: true
            },
            get: function (data) {
                var childDemographicStore = this.getStore('childDemographicStore'),
                    childDemographics = this.get('caseReview.FaceSheet.CR_ChildDemographic_Collection'),
                    rows = [];
                if (childDemographicStore) {
                    rows = Ext.Array.pluck(childDemographicStore.getRange(), 'data');
                }
                if (childDemographicStore === null && childDemographics != null) {
                    rows = childDemographics;
                }
                return rows;
            }
        },
        totalDemographicTargetChildRows: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var totalDemographicRows = this.get('totalDemographicRows'), rows = [];
                if (totalDemographicRows)
                    rows = this.get('totalDemographicRows').filter(function (item) {
                        return item.IsTargetChild === 1;
                    });
                return rows;
            }
        },

        targetChildDOB: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {

                var totalDemographicRows = this.get('totalDemographicRows'), rows = [];
                if (totalDemographicRows)
                    rows = this.get('totalDemographicRows').filter(function (item) {
                        return item.IsTargetChild === 1;
                    });
                if (rows.length > 0 && !Ext.isEmpty(rows[0].DateOfBirth)) {
                    if (Ext.isDate(rows[0].DateOfBirth)) {
                        return rows[0].DateOfBirth;
                    }
                    else {
                        return new Date(rows[0].DateOfBirth);
                    }
                }

                return null;
            }
        },
        hasSingleDemographicTargetChildRow: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                return this.get('totalDemographicTargetChildRows') && this.get('totalDemographicTargetChildRows').length === 1;
            }
        },
        hasMultiDemographicTargetChildRow: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                return this.get('totalDemographicTargetChildRows') && this.get('totalDemographicTargetChildRows').length > 1;
            }
        },
        hasInvalidDobDemographicChildRows: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var totalDemographicRows = this.get('totalDemographicRows'), rows = [];
                if (totalDemographicRows)
                    rows = rows.filter(function (item) {
                        return item.AgeObj && item.AgeObj.Year >= 18 && item.AgeObj.Month > 0 && item.AgeObj.Day > 0;
                    });
                return rows.length > 0;
            }
        },
        hasDemographicChildInterviewed: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var totalDemographicRows = this.get('totalDemographicRows'), rows = [];
                if (totalDemographicRows)
                    var rows = this.get('totalDemographicRows').filter(function (item) {
                        return item.IsInterviewed === 1;
                    });
                return rows.length > 0;
            }
        },
        hasCaseOrCaseInterviewNote: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (record) {
                var caseNoteStore = this.getStore('caseNoteStore'),
                    caseNotes = caseNoteStore && caseNoteStore.getCount() > 0,
                    caseInterviewNoteStore = this.getStore('caseInterviewNoteStore'),
                    caseInterviewNotes = caseInterviewNoteStore && caseInterviewNoteStore.getCount() > 0,
                    hasNote = caseNotes || caseInterviewNotes;

                return hasNote;
            }
        },
        hasDemographicChildOrParticipantInterviewed: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (record) {
                return this.get('hasDemographicChildInterviewed') || this.get('hasParticipantInterviewed');
            }
        },

        childDemographicErrMsg: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var msg = "",
                    hasNote = this.get('hasCaseOrCaseInterviewNote');

                if (this.get('totalDemographicRows').length === 0)
                    msg = "For table G1, you have not entered any children. Please enter at least one child.";
                else if (this.get('hasMultiDemographicTargetChildRow'))
                    msg = "For table G1, you entered more than one target child. Please ensure that only one child has been identified as the target child.";
                else if (!this.get('hasSingleDemographicTargetChildRow') && this.get('isFosterCareCase'))
                    msg = "For table G1, you have not selected a target child. Please select a target child.";
                else if (this.get('hasInvalidDobDemographicChildRows'))
                    msg = "The date of birth you have entered indicates that the child is over 18. Please ensure that this date is correct. Cases involving children over the age of 18 at the beginning of the PUR are not eligible for assessment.";
                //else if (this.get('hasDemographicChildInterviewed') && !hasNote) {
                //	msg = "For table G1, you entered Interviewed for child. Please enter at least one Case QA/Interview Notes.";
                //}
                if (!this.get('error.enabledDelayedMsg'))
                    this.set('error.ChildDemographics', msg);
                return msg;
            }
        },
        totalCaseParticipantRows: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var caseParticipantStore = this.getStore('caseParticipantStore'),
                    caseParticipants = this.get('caseReview.FaceSheet.CR_CaseParticipant_Collection'),
                    rows = [];
                if (caseParticipantStore) {
                    rows = Ext.Array.pluck(caseParticipantStore.getRange(), 'data');
                }
                if (caseParticipantStore === null && caseParticipants != null) {
                    rows = caseParticipants;
                }
                return rows;
            }
        },
        hasParticipantInterviewed: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var totalCaseParticipantRows = this.get('totalCaseParticipantRows'), rows = [];
                if (totalCaseParticipantRows)
                    rows = totalCaseParticipantRows.filter(function (item) {
                        return item.IsInterviewed === 1;
                    });
                return rows.length > 0;
            }
        },
        hasMotherAndOtherParticipant: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var totalCaseParticipantRows = this.get('totalCaseParticipantRows'), rows = [];
                if (totalCaseParticipantRows)
                    rows = totalCaseParticipantRows.filter(function (item) {
                        return item.RoleCode === 1 || item.RoleCode === 6;
                    });
                return rows.length > 0;
            }
        },
        hasFatherAndOtherParticipant: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var totalCaseParticipantRows = this.get('totalCaseParticipantRows'), rows = [];
                if (totalCaseParticipantRows)
                    rows = totalCaseParticipantRows.filter(function (item) {
                        return item.RoleCode === 2 || item.RoleCode === 6;
                    });
                return rows.length > 0;
            }
        },

        caseParticipantErrMsg: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var msg = "",
                    hasNote = this.get('hasCaseOrCaseInterviewNote');

                if (this.get('totalCaseParticipantRows') && this.get('totalCaseParticipantRows').length === 0)
                    msg = "For table G2, you have not entered any participants. Please enter at least one participant.";
                //else if (this.get('hasParticipantInterviewed') && !hasNote)
                //	msg = "For table G2, you entered Interviewed for participant. Please enter at least one Case QA/Interview Notes.";

                if (!this.get('error.enabledDelayedMsg'))
                    this.set('error.CaseParticipants', msg);
                return msg;
            }
        },

        hasSingleChildOnly: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var rows = this.get('totalDemographicRows').length === 1;
                if (data != null)
                    this.set('caseReview.TS_CR', new Date());
                return rows;
            }
        },
        hasSibling: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var rows = this.get('totalDemographicRows').length > 1;

                if (data != null)
                    this.set('caseReview.TS_CR', new Date());
                return rows;
            }
        },
        totalSafetyReportRows: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var safetyReportStore = this.getStore('safetyReportStore'),
                    safetyReports = this.get('caseReview.Safety.CR_SafetyReport_Collection'),
                    rows = [];

                if (safetyReportStore) {
                    rows = Ext.Array.pluck(safetyReportStore.getRange(), 'data');
                }
                if (safetyReportStore === null && safetyReports != null) {
                    rows = safetyReports;
                }
                return rows || [];
            }
        },

        hasSafetyReportRows: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var rows = this.get('totalSafetyReportRows'),
                    flag = rows && rows.length > 0;
                if (data != null)
                    this.set('caseReview.TS_CR', new Date());
                return flag;
            }
        },
        hasNoSubstantiatedReport: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var safetyReports = this.get('totalSafetyReportRows'),
                    rows = safetyReports && safetyReports.filter(function (item) {
                        return item.DispositionCode === 2;
                    }).length > 0;

                if (data != null)
                    this.set('caseReview.TS_CR', new Date());
                return rows;
            }
        },
        hasSubstantiatedReport: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var safetyReports = this.get('totalSafetyReportRows'),
                    rows = safetyReports && safetyReports.filter(function (item) {
                        return item.DispositionCode === 1;
                    }).length > 0;

                if (data != null)
                    this.set('caseReview.TS_CR', new Date());
                return rows;
            }
        },
        hasNoOpenedForServicesReport: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var safetyReports = this.get('totalSafetyReportRows'),
                    rows = safetyReports && safetyReports.filter(function (item) {
                        return item.DispositionCode === 5;
                    }).length > 0;

                if (data != null)
                    this.set('caseReview.TS_CR', new Date());
                return rows;
            }
        },
        hasOpenedForServicesReport: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var safetyReports = this.get('totalSafetyReportRows'),
                    rows = safetyReports && safetyReports.filter(function (item) {
                        return item.DispositionCode === 4;
                    }).length > 0;

                if (data !== null)
                    this.set('caseReview.TS_CR', new Date());
                return rows;
            }
        },
        safetyReportErrMsg: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var msg = "",
                    safetyReports = this.get('totalSafetyReportRows'),
                    safetyRelatedIncidents = this.get('caseReview.SafetyRelatedIncidents'),
                    fosterPlacementConcern = this.toArray(this.get('caseReview.FosterPlacementConcern')),
                    ques3D1SafetyRelatedIncidents = safetyRelatedIncidents && safetyRelatedIncidents.filter(function (item) {
                        return item === 88;
                    }).length > 0,
                    ques3F1FosterPlacementConcern = fosterPlacementConcern && fosterPlacementConcern.filter(function (item) {
                        return item === 100;
                    }).length > 0;

                if (this.get('caseReview.Item1IsApplicable') === 1) {
                    if (safetyReports && safetyReports.length === 0)
                        msg = "Please complete the reports table before answering questions for this item.";
                    else if (ques3D1SafetyRelatedIncidents && this.get('hasNoSubstantiatedReport'))
                        msg = "You indicated in question 3D1 that there was a substantiated or indicated maltreatment report. Please compare the information you have in table 1A1 to ensure that you selected substantiated or indicated for the disposition of a report during the PUR.";
                    else if (ques3D1SafetyRelatedIncidents && this.get('caseReview.Item1IsApplicable') != 1)
                        msg = "You indicated in question 3D1 that there were maltreatment reports during the PUR. Please change your answers to question 3D1 or mark item 1 as applicable.";
                    else if (ques3F1FosterPlacementConcern && this.get('caseReview.Item1IsApplicable') != 1)
                        msg = "You indicated in question 3F1 that there were maltreatment reports during the PUR. Please change your answers to question 3F1 or mark item 1 as applicable.";

                    else if (!this.isValidDatesInReport(safetyReports, 'DateAssessmentAssigned', 'ReportDate', 'IsAssigned'))
                        msg = "Please enter a date assigned for investigation that is on or after the report date.";
                    else if (!this.isValidDatesInReport(safetyReports, 'DateAssessmentInitiated', 'ReportDate', 'IsInitiated'))
                        msg = "Please enter a date investigation or assessment was initiated that is on or after the report date.";
                    else if (!this.isValidDatesInReport(safetyReports, 'DateAssessmentInitiated', 'DateAssessmentAssigned', 'IsInitiated'))
                        msg = "Please enter a date investigation or assessment was initiated that is on or after the date assigned for investigation";
                    else if (!this.isValidDatesInReport(safetyReports, 'DateFaceToFaceContact', 'DateAssessmentAssigned', 'IsFaceToFaceContact'))
                        msg = "Please enter a date of face-to-face contact that is on or after the date investigation or assessment was initiated. ";
                    else if (this.hasDuplicateChildReport(safetyReports))
                        msg = "You have entered two rows with the same child, report date, allegation, relationship of alleged perpetrator, and disposition. Please change the data or return to item 1.";
                    else if (this.get('hasInvalidDobDemographicChildRows'))
                        msg = "The date of birth you have entered indicates that the child is over 18. Please ensure that this date is correct. Cases involving children over the age of 18 at the beginning of the PUR are not eligible for assessment.";

                }
                if (!this.get('error.enabledDelayedMsg'))
                    this.set('error.SafetyReports', msg);
                return msg;
            }
        },
        currentSafetyReportUpdate: {
            bind: { bindTo: '{current.safetyReport}', deep: true },
            get: function (data) {
                //console.log('current.safetyReport')
            }
        },
        safetyReportIsAssignedCheck: {
            bind: { bindTo: '{current.safetyReport.IsAssigned}' },
            get: function (data) {
                return data === 1;
            },
            set: function (data) {
                this.set('current.safetyReport.IsAssigned', data);
                if (data === 1) {
                    this.set('current.safetyReport.DateAssessmentAssigned', null);
                }
            }
        },
        safetyReportIsInitiatedCheck: {
            bind: { bindTo: '{current.safetyReport.IsInitiated}' },
            get: function (data) {
                return data === 1;
            },
            set: function (data) {
                this.set('current.safetyReport.IsInitiated', data);
                if (data === 1) {
                    this.set('current.safetyReport.DateAssessmentInitiated', null);
                }
            }
        },
        safetyReportIsFaceToFaceContactCheck: {
            bind: { bindTo: '{current.safetyReport.IsFaceToFaceContact}' },
            get: function (data) {
                return data === 1;
            },
            set: function (data) {
                this.set('current.safetyReport.IsFaceToFaceContact', data);
                if (data === 1) {
                    this.set('current.safetyReport.DateFaceToFaceContact', null);
                }
            }
        },

        totalPlacementRows: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var store = this.getStore('placementStore'),
                    arr = this.get('caseReview.Permanency.CR_Placement_Collection'),
                    rows = [];
                if (store) {
                    rows = Ext.Array.pluck(store.getRange(), 'data');
                }
                if (store === null && arr != null) {
                    rows = arr;
                }
                return rows;
            }
        },
        hasPlacementRows: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var rows = this.get('totalPlacementRows'),
                    flag = rows && rows.length > 0;
                if (data != null)
                    this.set('caseReview.TS_CR', new Date());
                return flag;
            }
        },
        placementErrMsg: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var msg = "",
                    placements = this.toArray(this.get('totalPlacementRows')),
                    targetChildDOB = this.get('targetChildDOB'),
                    validPlacementDateForDob = targetChildDOB && placements.filter(function (item) {
                        return item.Date < targetChildDOB;
                    }).length === 0,
                    caseClosureDate = this.get('caseReview.CaseClosureDate'),

                    validPlacementDateForCaseClosure = caseClosureDate && placements.filter(function (item) {
                        return item.Date < caseClosureDate;
                    }).length > 0,
                    reviewCompleted = this.get('caseReview.ReviewCompleted'),
                    validPlacementDateForPUR = reviewCompleted && placements.filter(function (item) {
                        return item.Date < reviewCompleted;
                    }).length > 0,
                    recentPlacements = placements.filter(function (item) {
                        return item.ChangeReasonCode === 9;
                    }).length

                    ;

                if (placements.length === 0)
                    msg = "You have not completed table 4A1. Please complete table 4A1.";
                else if (targetChildDOB && !validPlacementDateForDob)
                    msg = "Please enter a placement date that is on or after the date of birth of the target child.";
                else if (caseClosureDate && !validPlacementDateForCaseClosure)
                    msg = "Please enter a placement date that is before the date of case closure listed in Face Sheet question L.";
                else if (caseClosureDate === null && reviewCompleted && !validPlacementDateForPUR)
                    msg = "Please enter a placement date that is before the end of the PUR.";
                else if (recentPlacements > 1)
                    msg = "Table 4A1 shows more than one placement as the current or most recent placement. Please enter a reason for change for all but the current or most recent placement";
                else if (recentPlacements === 0)
                    msg = "Table 4A1 should reflect the child's current or most recent placement and therefore should not show a reason it has changed. Please indicate that this is the current or most recent placement in the Reason for Change in Placement Setting field or, if this is not the current or most recent placement, enter a new row and indicate the current or most recent placement there";

                if (!this.get('error.enabledDelayedMsg'))
                    this.set('error.Placements', msg);
                return msg;
            }
        },
        placementTypeCode: {
            bind: { bindTo: '{current.placement.TypeCode}' },
            get: function (data) {
                if (data != 7)
                    this.set('current.placement.TypeOther', null);
                return data;
            },
            set: function (data) {
                this.set('current.placement.TypeCode', data);
                if (data != 7) {
                    this.set('current.placement.TypeOther', null);
                }
            }
        },
        placementChangeReasonCode: {
            bind: { bindTo: '{current.placement.ChangeReasonCode}' },
            get: function (data) {
                if (data != 8)
                    this.set('current.placement.ChangeReasonOther', null);
                return data;
            },
            set: function (data) {
                this.set('current.placement.ChangeReasonCode', data);

                if (data != 8) {
                    this.set('current.placement.ChangeReasonOther', null);
                }
            }
        },

        totalGoalRows: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var store = this.getStore('goalStore'),
                    arr = this.get('caseReview.Permanency.CR_Goal_Collection'),
                    rows = [];
                if (store) {
                    rows = Ext.Array.pluck(store.getRange(), 'data');
                }
                if (store === null && arr != null) {
                    rows = arr;
                }
                return rows;
            }
        },
        hasGoalRows: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var rows = this.get('totalGoalRows').length > 0;
                if (data !== null)
                    this.set('caseReview.TS_CR', new Date());
                return rows;
            }
        },

        goalErrMsg: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var msg = "",
                    me = this,
                    item5IsApplicable = me.get('caseReview.Item5IsApplicable'),
                    goals = this.toArray(this.get('totalGoalRows')),
                    dateEstablished = this.get('current.goal.DateEstablished'),
                    dateGoalChanged = this.get('current.goal.DateGoalChanged'),
                    targetChildDOB = this.get('targetChildDOB'),
                    reviewCompleted = this.get('caseReview.ReviewCompleted'),
                    validGoalDateForDob = targetChildDOB && goals.filter(function (item) {
                        return !Ext.isEmpty(item.DateEstablished) && item.DateEstablished < targetChildDOB;
                    }).length === 0,
                    validDateGoalChangedForDob = targetChildDOB && goals.filter(function (item) {
                        return !Ext.isEmpty(item.DateGoalChanged) && item.DateGoalChanged < targetChildDOB;
                    }).length === 0,
                    inValidDateGoalChangedForPUR = reviewCompleted && goals.filter(function (item) {
                        return !Ext.isEmpty(item.DateGoalChanged) && item.DateGoalChanged >= reviewCompleted;
                    }).length > 0,

                    totalCurrentGoals = goals.filter(function (item) {
                        return item.IsCurrentGoal === 1;
                    }),
                    currentGoalCodes = Ext.Array.pluck(totalCurrentGoals, 'GoalCode'),
                    hasDuplicateCurrentGoal = currentGoalCodes.length !== Ext.Array.unique(currentGoalCodes).length,
                    isCurrentGoal = totalCurrentGoals.length > 0;

                if (item5IsApplicable && item5IsApplicable === 1) {
                    if (goals.length === 0)
                        msg = "You have not completed table 5A1. Please complete table 5A1.";
                    else if (!isCurrentGoal)
                        msg = 'For table 5A1, please ensure that one of the rows indicates that this is the current goal.';
                    else if (totalCurrentGoals.length > 2)
                        msg = 'For table 5A1, please complete Date Goal Changed and Reason for Goal Change for all non-current goals. Please record only two concurrent goals.';
                    else if (hasDuplicateCurrentGoal)
                        msg = 'For table 5A1, please complete Date Goal Changed and Reason for Goal Change for all non-current goals. Please do not list two concurrent goals that are the same';
                    else if (targetChildDOB && !validGoalDateForDob)
                        msg = "Please enter a date the goal was established that is on or after the date of birth of the target child.";
                    else if (targetChildDOB && !validDateGoalChangedForDob)
                        msg = "Please enter a date the goal changed that is after the date of birth of the target child. ";
                    else if (reviewCompleted && inValidDateGoalChangedForPUR)
                        msg = "Please enter a date the goal changed that is before the last day of the PUR.";
                    else if (dateEstablished && dateGoalChanged && dateEstablished > dateGoalChanged)
                        msg = "Please enter a date the goal changed that is after the date it was established.";
                }
                if (!this.get('error.enabledDelayedMsg'))
                    this.set('error.Goals', msg);
                return msg;
            }
        },
        isCurrentGoalCheck: {
            bind: { bindTo: '{current.goal.IsCurrentGoal}' },
            get: function (data) {
                if (data === 1) {
                    this.set('current.goal.DateGoalChanged', null);
                    this.set('current.goal.ReasonForGoalChange', null);
                }
                return data;
            },
            set: function (data) {

                this.set('current.goal.IsCurrentGoal', data ? 1 : 2);
                if (data) {
                    this.set('current.goal.DateGoalChanged', null);
                    this.set('current.goal.ReasonForGoalChange', null);
                }
            }
        },
        hasMentalHealthRows: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var mentalHealthStore = this.getStore('mentalHealthStore'),
                    rows = mentalHealthStore && mentalHealthStore.getCount() > 0;

                if (data != null)
                    this.set('caseReview.TS_CR', new Date());
                return rows;
            }
        },
        mentalHealthErrMsg: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var msg = "",
                    hasMentalHealthRows = this.get('hasMentalHealthRows')

                if (this.get('caseReview.Item18IsApplicable') === 1 && !hasMentalHealthRows)
                    msg = "Please complete the table before answering questions for this item";

                if (!this.get('error.enabledDelayedMsg'))
                    this.set('error.MentalBehavirolHealths', msg);
                return msg;
            }
        },

        isTargetChildDisabled: {
            bind: { bindTo: '{caseReview.ReviewSubTypeID}' },
            get: function (data) {
                return data && (data != 18 && data != 20 && data != 26);
            }
        },
        otherCaseParticipantRoleCode: {
            bind: {
                bindTo: '{current.caseParticipant.RoleCode}'
            },
            get: function (data) {
                if (data != 6)
                    this.set('current.caseParticipant.OtherRole', null);
                return data && data != 6;
            }
        },
        notes: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (rec) {

                if (Ext.isEmpty(rec))
                    return [];

                var me = this,
                    caseNotes = rec.get('CR_CaseNote_Collection') || [],
                    outcomes = rec.get('CR_Outcome_Collection') || [],
                    data = [],
                    store = this.getStore('noteStore'),
                    noteCount = store ? store.getCount() : 0

                if (noteCount > 0)
                    return;
                //case notes
                Ext.each(caseNotes, function (note) {
                    if (!Ext.isEmpty(note.NoteID)) {

                        var userData = me.getLookupData('CrSecurityUser', note.LastModifiedUserID || note.ID_UP) || {};
                        var n = {
                            CaseReviewID: note.CaseReviewID,
                            NoteID: note.NoteID,
                            TempID: note.NoteID,
                            Subject: note.Subject,
                            IsResolved: note.IsResolved,
                            Description: note.Description,
                            NoteType: note.NoteType,
                            LastModifiedDate: note.LastModifiedDate || note.TS_UP,
                            LastModifiedUserID: note.LastModifiedUserID || note.ID_UP,
                            Name: userData.name,
                            ItemID: null,
                            ItemCode: null,
                            OutcomeCode: null,
                            ResponseID: null
                        };
                        n.ReviewerType = me.getReviewerTypeByUserId(n.LastModifiedUserID);
                        data.push(n);
                        var resNotes = note.CR_CaseNote_Response_Collection;
                        Ext.each(resNotes, function (response) {
                            if (!Ext.isEmpty(response.ResponseID)) {
                                var userData = me.getLookupData('CrSecurityUser', response.LastModifiedUserID || response.ID_UP) || {};
                                var r = {
                                    CaseReviewID: note.CaseReviewID,
                                    ResponseID: response.ResponseID,
                                    NoteID: response.NoteID,
                                    TempID: response.NoteID,
                                    NoteType: note.NoteType,
                                    IsResponse: true,
                                    Description: response.Description,
                                    LastModifiedDate: response.LastModifiedDate || response.TS_UP,
                                    LastModifiedUserID: response.LastModifiedUserID || response.ID_UP,
                                    Name: userData.name,
                                    Subject: null,
                                    IsResolved: null,
                                    ItemID: null,
                                    ItemCode: null,
                                    OutcomeCode: null

                                };
                                r.ReviewerType = me.getReviewerTypeByUserId(r.LastModifiedUserID);

                                data.push(r);
                            }
                        });
                    }
                });

                //items notes
                Ext.each(outcomes, function (outcome) {
                    var items = outcome.CR_Item_Collection;

                    Ext.each(items, function (item) {
                        var notes = item.CR_Note_Collection;

                        Ext.each(notes, function (note) {
                            if (!Ext.isEmpty(note.NoteID)) {

                                var userData = me.getLookupData('CrSecurityUser', note.LastModifiedUserID) || {};

                                var n = {
                                    CaseReviewID: outcome.CaseReviewID,
                                    OutcomeCode: outcome.OutcomeCode,
                                    ItemID: item.ItemID,
                                    ItemCode: item.ItemCode,
                                    NoteID: note.NoteID,
                                    TempID: note.NoteID,
                                    Subject: note.Subject,
                                    IsResolved: note.IsResolved,
                                    Description: note.Description,
                                    NoteType: note.NoteType,
                                    LastModifiedDate: note.LastModifiedDate,
                                    LastModifiedUserID: note.LastModifiedUserID,
                                    Name: userData.name,
                                    ResponseID: null
                                };
                                n.ReviewerType = me.getReviewerTypeByUserId(n.LastModifiedUserID);

                                data.push(n);
                                var resNotes = note.CR_Response_Collection;
                                Ext.each(resNotes, function (response) {
                                    if (!Ext.isEmpty(response.ResponseID)) {
                                        var userData = me.getLookupData('CrSecurityUser', response.LastModifiedUserID) || {};

                                        var r = {
                                            CaseReviewID: outcome.CaseReviewID,
                                            OutcomeCode: outcome.OutcomeCode,
                                            ItemID: item.ItemID,
                                            ItemCode: item.ItemCode,
                                            ResponseID: response.ResponseID,
                                            NoteID: response.NoteID,
                                            TempID: response.NoteID,
                                            NoteType: note.NoteType,
                                            IsResponse: true,
                                            Description: response.Description,
                                            LastModifiedDate: response.LastModifiedDate,
                                            LastModifiedUserID: response.LastModifiedUserID,
                                            Name: userData.name,
                                            Subject: null,
                                            IsResolved: null
                                        };
                                        r.ReviewerType = me.getReviewerTypeByUserId(r.LastModifiedUserID);

                                        data.push(r);
                                    }
                                });
                            }
                        });
                    });
                });
                // console.log('notes data', data)
                return data;
            }
        },
        reviewSubTypeText: {
            bind: {
                bindTo: '{caseReview.ReviewSubTypeID}'
            },
            get: function (val) {
                var data = this.getLookupData('CrReviewSubType', val) || {};
                return data.name || val;
            }
        },
        initialQaUser: {
            bind: {
                bindTo: '{caseReview.InitialQAUserID}'
            },
            get: function (val) {
                var data = this.getLookupData('CrSecurityUser', val) || {};
                return data.name || val;
            }
        },
        secondQaUser: {
            bind: {
                bindTo: '{caseReview.SecondQAUserID}'
            },
            get: function (val) {
                var data = this.getLookupData('CrSecurityUser', val) || {};
                return data.name || val;
            }
        },
        secondaryOversightUser: {
            bind: {
                bindTo: '{caseReview.SecondaryOversightUserID}'
            },
            get: function (val) {
                var data = this.getLookupData('CrSecurityUser', val) || {};
                return data.name || val;
            }
        },

        reviewPeriod: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (rec) {
                if (Ext.isEmpty(rec)) return '';
                return Ext.Date.format(new Date(rec.get('ReviewStartDate')), 'm/d/Y') + ' - ' + Ext.Date.format(new Date(rec.get('ReviewCompleted')), 'm/d/Y');
            }
        },
        ctSecondaryOversightUser: {
            bind: { bindTo: '{caseReview.CtSecondaryOversightUserID}' },
            get: function (val) {
                var data = this.getLookupData('CrSecurityUser', val) || {};
                return data.name || val;
            }
        },
        isHomeServiceCase: {
            bind: { bindTo: '{caseReview.ReviewSubTypeID}' },
            get: function (data) {
                return (data === 17 || data === 19 || data === 25 || data === 21 || data === 22 || data === 27); //home service
            }
        },
        isFosterCareCase: {
            bind: { bindTo: '{caseReview.ReviewSubTypeID}' },
            get: function (data) {
                return (data === 18 || data === 20 || data === 26); //foster case service
            }
        },
        reviewSubTypeID: {
            bind: { bindTo: '{caseReview.ReviewSubTypeID}' },
            get: function (data) {
                return { ReviewSubTypeID: data };
            },
            set: function (data) {
                this.set('caseReview.ReviewSubTypeID', data.ReviewSubTypeID);
            }
        },
        isPIPMonitored: {
            bind: { bindTo: '{caseReview.IsPIPMonitored}' },
            get: function (data) {
                return { IsPIPMonitored: data };
            },
            set: function (data) {
                this.set('caseReview.IsPIPMonitored', data.IsPIPMonitored);
            }
        },
        iRRReviewerID: {
            bind: '{caseReview.IRRReviewerID}',
            get: function (data) {
                if (Ext.isEmpty(data))
                    return null;
                var name = this.getLookupDataValue('CrSecurityUser', data);
                return Ext.isEmpty(name) ? null : name;
            }
        },
        isNonOPPLA: {
            bind: {
                bindTo: '{caseReview}',
                deep: true
            },
            get: function (data) {
                if (data) {
                    var arr = [];

                    var goalTable = this.getGoalTableValue();
                    if (goalTable != null && goalTable.length > 0) {
                        arr = goalTable;
                        var oppla = arr.filter(function (item) {
                            return item === 130;//Other Planned Permanent Living Arrangement
                        });
                        return (oppla.length === 0);
                    }
                }
                return null;
            }
        },
        hasOPPLA: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                if (data) {
                    var totalGoalRows = this.toArray(this.get('totalGoalRows'));

                    var hasOPPLA = totalGoalRows && totalGoalRows.filter(function (item) {
                        return item === 130;//Other Planned Permanent Living Arrangement
                    }).length > 0;
                    return hasOPPLA;
                }
                return null;
            }
        },

        isFosterEntryDateNA: {
            bind: { bindTo: '{caseReview.IsFosterEntryDateNA}' },
            get: function (data) {

                if (this.get('isHomeServiceCase')) //home service
                {
                    this.set('caseReview.IsFosterEntryDateNA', 1);
                    return true;
                }
                return data === 1;
            },
            set: function (data) {
                this.set('caseReview.IsFosterEntryDateNA', data ? 1 : 2);
                if (data === 1)
                    this.set('caseReview.FosterEntryDate', null);
            }
        },
        isEpisodeDischargeDateNA: {
            bind: { bindTo: '{caseReview.IsEpisodeDischargeDateNA}' },
            get: function (data) {
                if (this.get('isHomeServiceCase')) //home service
                {
                    this.set('caseReview.IsEpisodeDischargeDateNA', 1);
                    return true;
                }
                return data === 1;
            },
            set: function (data) {
                this.set('caseReview.IsEpisodeDischargeDateNA', data ? 1 : 2);
                if (data === 1) {
                    this.set('caseReview.EpisodeDischargeDate', null);
                    this.set('caseReview.IsEpisodeNotYetDischarged', 2);
                }
            }
        },
        isEpisodeNotYetDischarged: {
            bind: { bindTo: '{caseReview.IsEpisodeNotYetDischarged}' },
            get: function (data) {
                return data === 1;
            },
            set: function (data) {
                this.set('caseReview.IsEpisodeNotYetDischarged', data ? 1 : 2);
                if (data === 1) {
                    this.set('caseReview.EpisodeDischargeDate', null);
                    this.set('caseReview.IsEpisodeDischargeDateNA', 2);
                    this.set('caseReview.IsCaseClosureNotClosed', 1);

                }
            }
        },
        isCaseClosureNotClosed: {
            bind: { bindTo: '{caseReview.IsCaseClosureNotClosed}' },
            get: function (data) {
                return data === 1;
            },
            set: function (data) {
                this.set('caseReview.IsCaseClosureNotClosed', data ? 1 : 2);
                if (data === 1)
                    this.set('caseReview.CaseClosureDate', null);
            }
        },
        isCaseOpenReasonOtherAbuseNeglect: {
            bind: { bindTo: '{caseReview.IsCaseOpenReasonOtherAbuseNeglect}' },
            get: function (data) {
                this.set('error.IsCaseOpenReasonOtherAbuseNeglect', data ? '' : 'Please answer question H');
                return { IsCaseOpenReasonOtherAbuseNeglect: data };
            },
            set: function (data) {
                this.set('caseReview.IsCaseOpenReasonOtherAbuseNeglect', data.IsCaseOpenReasonOtherAbuseNeglect);
                this.set('error.IsCaseOpenReasonOtherAbuseNeglect', data.IsCaseOpenReasonOtherAbuseNeglect ? '' : 'Please answer question H');
            }
        },
        caseReasons: {
            bind: { bindTo: '{caseReview.CaseReasons}', deep: true },
            get: function (data) {
                var arr = [];
                if (data) {
                    arr = data;
                }
                return { CaseReasons: arr };
            },
            set: function (data) {
                var arr = [];
                if (!Ext.isArray(data.CaseReasons)) {
                    arr.push(data.CaseReasons);
                }
                else {
                    arr = data.CaseReasons
                }
                this.set('caseReview.CaseReasons', arr);
                //14=Other Case Reason option
                if (arr.filter(function (item) {
                    return item === 14;
                }).length === 0) {
                    this.set('caseReview.OtherCaseReason', null);
                }
            }
        },
        overview: {
            bind: {
                bindTo: '{caseReview.CR_Outcome_Collection}',
                deep: true
            },
            get: function (collection) {

                var me = this,
                    obj = { facesheet: [], safety: [], permanency: [], wellbeing: [] },
                    outcomes = me.getOverviewOutComes(),
                    items = me.getOverviewItems(), oc, ic, ocItems
                    ;
                Ext.each(outcomes, function (col) {
                    oc = {};
                    if (collection) {
                        oc = me.collectionFilter(collection, 'OutcomeCode', col.code, true);
                    }
                    col.rating = oc.OutcomeRatingCode || 0;
                    col.overriddenRating = oc.OverriddenOutcomeRatingCode || 0;
                    ocItems = me.collectionFilter(items, 'outcome', col.code);

                    Ext.each(ocItems, function (item) {

                        ic = {};
                        if (oc.CR_Item_Collection) {
                            ic = me.collectionFilter(oc.CR_Item_Collection, 'ItemCode', item.code, true);
                        }
                        item.rating = ic.ItemRatingCode || 0;
                        item.overriddenRating = ic.OverriddenRatingCode || 0;
                        item.status = ic.StatusCode || 0;
                        if (item.code === 23)
                            item.rating = null;
                        col.items.push(item);
                    });

                    switch (col.code) {
                        case 1:
                        case 2:
                            obj.safety.push(col);
                            break;
                        case 3:
                        case 4:
                            obj.permanency.push(col);
                            break;
                        case 5:
                        case 6:
                        case 7:
                            obj.wellbeing.push(col);
                            break;
                        case 21:
                            col.rating = '';
                            col.name = '';
                            obj.facesheet.push(col);
                            break;
                    }
                });
                return obj;
            }
        },
        facesheetOverview: {
            bind: {
                bindTo: '{overview}',
                deep: true
            },
            get: function (rec) {
                //   console.log('facesheetOverview',rec)
                return rec.facesheet;
            }
        },
        safetyOverview: {
            bind: {
                bindTo: '{overview}',
                deep: true
            },
            get: function (rec) {
                //   console.log('safetyOverview',rec)
                return rec.safety;
            }
        },
        safetySection1Overview: {
            bind: {
                bindTo: '{overview}',
                deep: true
            },
            get: function (rec) {
                var temp = [];
                Ext.each(rec.safety, function (col) {
                    var t = {
                        code: col.code,
                        name: col.name,
                        items: [],
                        desc: col.desc,
                        rating: -1
                    };

                    Ext.each(col.items, function (item) {
                        t.items.push({
                            outcome: item.outcome,
                            code: item.code,
                            name: item.name,
                            desc: item.desc,
                            rating: -1,
                            status: -1
                        });
                    });
                    temp.push(t);
                });

                return temp;
            }
        },
        permanencyOverview: {
            bind: {
                bindTo: '{overview}',
                deep:
                    true
            }
            ,
            get: function (rec) {
                // console.log('permanencyOverview', rec)
                return rec.permanency;
            }
        },
        permanencySectionOverview: {
            bind: {
                bindTo: '{overview}',
                deep: true
            },
            get: function (rec) {
                var temp = [];

                Ext.each(rec.permanency, function (col) {
                    var t = {
                        code: col.code,
                        name: col.name,
                        items: [],
                        desc: col.desc,
                        rating: -1
                    };

                    Ext.each(col.items, function (item) {
                        t.items.push({
                            outcome: item.outcome,
                            code: item.code,
                            name: item.name,
                            desc: item.desc,
                            rating: -1,
                            status: -1
                        });
                    });
                    temp.push(t);
                });

                return temp;
            }
        },
        wellbeingOverview: {
            bind: {
                bindTo: '{overview}',
                deep: true
            },
            get: function (rec) {
                // console.log('wellbeingOverview',rec)
                return rec.wellbeing;
            }
        },
        wellbeingSectionOverview: {
            bind: {
                bindTo: '{overview}',
                deep: true
            },
            get: function (rec) {
                var temp = [];

                Ext.each(rec.wellbeing, function (col) {
                    var t = {
                        code: col.code,
                        name: col.name,
                        items: [],
                        desc: col.desc,
                        rating: -1
                    };

                    Ext.each(col.items, function (item) {
                        t.items.push({
                            outcome: item.outcome,
                            code: item.code,
                            name: item.name,
                            desc: item.desc,
                            rating: -1,
                            status: -1
                        });
                    });
                    temp.push(t);
                });

                return temp;
            }
        },
        safetyReportAllegations: {
            bind: {
                bindTo: '{caseReview.CR_SafetyReport_Allegation_Collection}',
                deep: true
            },
            get: function (data) {
                var caseReasons = [];
                if (data) {
                    caseReasons = data.filter(function (item) {
                        return item.GroupName === 'CaseReason';
                    });

                    caseReasons = Ext.Array.pluck(caseReasons, 'CodeDescriptionID');

                }
                return { CaseReasons: caseReasons };
            },
            set: function (data) {
                this.set('caseReview.CaseReasons', data.CaseReasons);
            }
        },
        item1IsApplicable: {
            bind: { bindTo: '{caseReview.Item1IsApplicable}' },
            get: function (data) {
                return { Item1IsApplicable: data };
            },
            set: function (data) {
                this.set('caseReview.Item1IsApplicable', data.Item1IsApplicable);
            }
        },
        item2IsApplicable: {
            bind: { bindTo: '{caseReview.Item2IsApplicable}' },
            get: function (data) {
                return { Item2IsApplicable: data };
            },
            set: function (data) {
                this.set('caseReview.Item2IsApplicable', data.Item2IsApplicable);
            }
        },
        item2Applicability51: {
            bind: { bindTo: '{caseReview.ItemApplicability51}' },
            get: function (data) {
                if (this.get('isFosterCareCase')) {//fostercare case
                    this.set('caseReview.ItemApplicability51', 2);
                    return { ItemApplicability51: 2 };
                }
                return { ItemApplicability51: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability51', data.ItemApplicability51);
            }
        },
        item2Applicability52: {
            bind: { bindTo: '{caseReview.ItemApplicability52}' },

            get: function (data) {
                if (this.get('isFosterCareCase')) {//fostercare case
                    this.set('caseReview.ItemApplicability52', 2);
                    return { ItemApplicability52: 2 };
                }
                return { ItemApplicability52: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability52', data.ItemApplicability52);
            }
        },
        item2Applicability53: {
            bind: { bindTo: '{caseReview.ItemApplicability53}' },
            get: function (data) {
                if (this.get('isHomeServiceCase') || this.get('isFosterCareCase') &&
                    this.get('caseReview.FosterEntryDate') < this.get('caseReview.ReviewStartDate')) {//fostercare case
                    this.set('caseReview.ItemApplicability53', 2);
                    return { ItemApplicability53: 2 };
                }
                return { ItemApplicability53: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability53', data.ItemApplicability53);
            }
        },
        item2Applicability54: {
            bind: { bindTo: '{caseReview.ItemApplicability54}' },
            get: function (data) {
                if (this.get('isHomeServiceCase')) {//home service case
                    this.set('caseReview.ItemApplicability54', 2);
                    return { ItemApplicability54: 2 };
                }
                return { ItemApplicability54: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability54', data.ItemApplicability54);
            }
        },
        item2Applicability55: {
            bind: { bindTo: '{caseReview.ItemApplicability55}' },
            get: function (data) {

                if (this.get('isHomeServiceCase') || this.get('isFosterCareCase') &&
                    (this.get('caseReview.EpisodeDischargeDate') != null ||
                        (this.get('caseReview.FosterEntryDate') > this.get('caseReview.ReviewStartDate') &&
                            this.get('caseReview.FosterEntryDate') < this.get('caseReview.ReviewCompleted')))
                ) {//fostercare case
                    this.set('caseReview.ItemApplicability55', 2);
                    return { ItemApplicability55: 2 };
                }

                return { ItemApplicability55: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability55', data.ItemApplicability55);
            }
        },
        item2Applicability55Disabled: {
            bind: { bindTo: '{caseReview.ItemApplicability55}' },
            get: function (data) {

                return (this.get('isHomeServiceCase') ||
                    this.get('isFosterCareCase') && (this.get('caseReview.EpisodeDischargeDate') != null || (this.get('caseReview.FosterEntryDate') > this.get('caseReview.ReviewStartDate') && this.get('caseReview.FosterEntryDate') < this.get('caseReview.ReviewCompleted')))
                );

            },
            set: function (data) {
                this.set('caseReview.ItemApplicability55', data.ItemApplicability55);
            }
        },
        item2Applicability56: {
            bind: { bindTo: '{caseReview.ItemApplicability56}' },
            get: function (data) {

                return { ItemApplicability56: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability56', data.ItemApplicability56);
            }
        },
        isEffortToPreventReEntry: {
            bind: { bindTo: '{caseReview.IsEffortToPreventReEntry}' },
            get: function (data) {
                return { IsEffortToPreventReEntry: data };
            }
            ,
            set: function (data) {
                this.set('caseReview.IsEffortToPreventReEntry', data.IsEffortToPreventReEntry);
                if (data.IsEffortToPreventReEntry != 2) this.set('caseReview.EffortToPreventReEntryExplained', null);

            }
        },
        isChildRemovedToEnsureSafety: {
            bind: { bindTo: '{caseReview.IsChildRemovedToEnsureSafety}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//non-foster care case
                    this.set('caseReview.IsChildRemovedToEnsureSafety', 3);
                    return { IsChildRemovedToEnsureSafety: 3 };
                }
                return { IsChildRemovedToEnsureSafety: data };
            },
            set: function (data) {
                this.set('caseReview.IsChildRemovedToEnsureSafety', data.IsChildRemovedToEnsureSafety);
                if (data.IsChildRemovedToEnsureSafety != 2) this.set('caseReview.ChildRemovedToEnsureSafetyExplained', null);
            }
        },
        isDelayBeyondAgencyControl: {
            bind: { bindTo: '{caseReview.IsDelayBeyondAgencyControl}' },
            get: function (data) {
                return { IsDelayBeyondAgencyControl: data };
            },
            set: function (data) {
                this.set('caseReview.IsDelayBeyondAgencyControl', data.IsDelayBeyondAgencyControl);
            }
        },

        item3IsApplicable: {
            bind: { bindTo: '{caseReview.Item3IsApplicable}' },
            get: function (data) {
                return { Item3IsApplicable: data };
            },
            set: function (data) {
                this.set('caseReview.Item3IsApplicable', data.Item3IsApplicable);
            }
        },
        isFamilyMaltreatmentAllegations: {
            bind: {
                bindTo: '{caseReview.IsFamilyMaltreatmentAllegations}'
            },
            get: function (data) {
                return { IsFamilyMaltreatmentAllegations: data };
            }
            ,
            set: function (data) {
                this.set('caseReview.IsFamilyMaltreatmentAllegations', data.IsFamilyMaltreatmentAllegations);
            }
        },
        isMaltreatmentNotSubstantiated: {
            bind: { bindTo: '{caseReview.IsMaltreatmentNotSubstantiated}' },
            get: function (data) {
                return { IsMaltreatmentNotSubstantiated: data };
            },
            set: function (data) {

                this.set('caseReview.IsMaltreatmentNotSubstantiated', data.IsMaltreatmentNotSubstantiated);
            }
        },
        isInitialAssesmentForAllChildrenInHome: {
            bind: { bindTo: '{caseReview.IsInitialAssesmentForAllChildrenInHome}' },
            get: function (data) {
                return { IsInitialAssesmentForAllChildrenInHome: data };
            },
            set: function (data) {
                this.set('caseReview.IsInitialAssesmentForAllChildrenInHome', data.IsInitialAssesmentForAllChildrenInHome);
                if (data.IsInitialAssesmentForAllChildrenInHome != 2) this.set('caseReview.InitialAssesmentForAllChildrenInHomeExplained', null);
            }
        },
        isOngoingAssesementForAllChildrenInHome: {
            bind: { bindTo: '{caseReview.IsOngoingAssesementForAllChildrenInHome}' },
            get: function (data) {
                return { IsOngoingAssesementForAllChildrenInHome: data };
            },
            set: function (data) {
                this.set('caseReview.IsOngoingAssesementForAllChildrenInHome', data.IsOngoingAssesementForAllChildrenInHome);
                if (data.IsOngoingAssesementForAllChildrenInHome != 2) this.set('caseReview.OngoingAssessmentForAllChildrenInHomeExplained', null);
            }
        },
        isSafetyPlanDevelopedAndMonitored: {
            bind: { bindTo: '{caseReview.IsSafetyPlanDevelopedAndMonitored}' },
            get: function (data) {
                return { IsSafetyPlanDevelopedAndMonitored: data };
            },
            set: function (data) {
                this.set('caseReview.IsSafetyPlanDevelopedAndMonitored', data.IsSafetyPlanDevelopedAndMonitored);
                if (data.IsSafetyPlanDevelopedAndMonitored != 2) this.set('caseReview.SafetyPlanDevelopedAndMonitoredExplained', null);
            }
        },

        safetyRelatedIncidents: {
            bind: { bindTo: '{caseReview.SafetyRelatedIncidents}', deep: true },
            get: function (data) {
                var arr = this.toArray(data);
                if (this.get('hasNoSubstantiatedReport') || this.get('caseReview.Item1IsApplicable') === 2) {
                    //remove 88 value from array
                    var index = arr.indexOf(88);
                    if (index > -1)
                        arr.splice(index, 1);
                }
                if (!this.get('hasNoOpenedForServicesReport') || this.get('caseReview.Item1IsApplicable') === 2) {
                    //if (this.get('hasNoOpenedForServicesReport') || this.get('caseReview.Item1IsApplicable') === 2) {
                    //remove 89 value from array
                    var index = arr.indexOf(89);
                    if (index > -1)
                        arr.splice(index, 1);

                }
                return { SafetyRelatedIncidents: arr };
            },
            set: function (data) {
                var arr = this.toArray(data.SafetyRelatedIncidents);

                if (!this.hasValueInArray(arr, 91)) {
                    this.set('caseReview.OtherSafetyConcernExplained', null);
                }
                if (this.hasValueInArray(arr, 86)) {
                    arr = [86];
                    this.set('caseReview.IsSafetyConcernForOtherChildren', 3);
                    this.set('caseReview.OtherSafetyConcernExplained', null);
                }
                if (this.hasValueInArray(arr, 87)) {
                    arr = [87];
                    this.set('caseReview.OtherSafetyConcernExplained', null);
                }
                this.set('caseReview.SafetyRelatedIncidents', arr);
            }
        },
        isSafetyConcernForOtherChildren: {
            bind: { bindTo: '{caseReview.IsSafetyConcernForOtherChildren}' },
            get: function (data) {
                return { IsSafetyConcernForOtherChildren: data };
            },
            set: function (data) {
                this.set('caseReview.IsSafetyConcernForOtherChildren', data.IsSafetyConcernForOtherChildren);
            }
        },
        fosterSafety: {
            bind: { bindTo: '{caseReview.FosterSafety}', deep: true },
            get: function (data) {
                var arr = this.toArray(data);
                if (!this.get('isFosterCareCase')) {
                    arr = [];
                    arr.push(92);
                    this.set('caseReview.FosterSafetyOtherExplained', null);
                }
                if (arr.length > 0)
                    this.set('caseReview.FosterSafety', arr);
                return { FosterSafety: arr };
            },
            set: function (data) {
                var arr = this.toArray(data.FosterSafety);
                if (!this.hasValueInArray(arr, 97)) {
                    this.set('caseReview.FosterSafetyOtherExplained', null);
                }
                if (this.hasValueInArray(arr, 92)) { //92=na
                    arr = [92];
                    this.set('caseReview.FosterSafetyOtherExplained', null);
                }
                if (this.hasValueInArray(arr, 93)) {//93=no
                    arr = [93];
                    this.set('caseReview.FosterSafetyOtherExplained', null);
                }
                this.set('caseReview.FosterSafety', arr);
            }
        },
        isFosterSafetyConcernDuringVisitation: {
            bind: { bindTo: '{caseReview.IsFosterSafetyConcernDuringVisitation}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//fostercare case
                    this.set('caseReview.IsFosterSafetyConcernDuringVisitation', 3);
                    return { IsFosterSafetyConcernDuringVisitation: 3 };
                }
                return { IsFosterSafetyConcernDuringVisitation: data };
            },
            set: function (data) {
                this.set('caseReview.IsFosterSafetyConcernDuringVisitation', data.IsFosterSafetyConcernDuringVisitation);
            }
        },
        fosterPlacementConcern: {
            bind: { bindTo: '{caseReview.FosterPlacementConcern}', deep: true },
            get: function (data) {
                var arr = this.toArray(data);
                if (this.get('hasNoSubstantiatedReport') || this.get('caseReview.Item1IsApplicable') === 2) {
                    //remove 100 value from array
                    var index = arr.indexOf(100);
                    if (index > -1)
                        arr.splice(index, 1);
                }
                if (this.get('isFosterCareCase')) {
                    //remove 98=na value from array
                    var index = arr.indexOf(98);
                    if (index > -1)
                        arr.splice(index, 1);
                }

                if (this.get('isHomeServiceCase')) //home service
                {
                    arr = [];
                    arr.push(98);
                    this.set('caseReview.FosterPlacementConcerOtherExplained', null);
                }
                this.set('caseReview.FosterPlacementConcern', arr);
                return { FosterPlacementConcern: arr };
            },
            set: function (data) {

                var arr = this.toArray(data.FosterPlacementConcern);
                if (!this.hasValueInArray(arr, 104)) {
                    this.set('caseReview.FosterPlacementConcerOtherExplained', null);
                }
                if (this.hasValueInArray(arr, 98)) { //98=na
                    arr = [98];
                    this.set('caseReview.FosterPlacementConcerOtherExplained', null);
                }
                if (this.hasValueInArray(arr, 99)) {//99=no
                    arr = [99];
                    this.set('caseReview.FosterPlacementConcerOtherExplained', null);
                }
                this.set('caseReview.FosterPlacementConcern', arr);
            }
        },
        isFosterSafetyConcernNotAddressed: {
            bind: { bindTo: '{caseReview.IsFosterSafetyConcernNotAddressed}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//fostercare case
                    this.set('caseReview.IsFosterSafetyConcernNotAddressed', 3);
                    return { IsFosterSafetyConcernNotAddressed: 3 };
                }
                return { IsFosterSafetyConcernNotAddressed: data };
            },
            set: function (data) {
                this.set('caseReview.IsFosterSafetyConcernNotAddressed', data.IsFosterSafetyConcernNotAddressed);
            }
        },

        numberOfPlacementSettings: {
            bind: '{caseReview.NumberOfPlacementSettings}',
            get: function (data) {

                return data;
            },
            set: function (data) {
                this.set('caseReview.NumberOfPlacementSettings', data);
                if (data === null || data <= 1)
                    this.set('caseReview.WereAllPlacementChangesPlanned', 3);
            }
        },
        wereAllPlacementChangesPlanned: {
            bind: {
                bindTo: '{caseReview.WereAllPlacementChangesPlanned}'
            },
            get: function (data) {
                return { WereAllPlacementChangesPlanned: data };
            }
            ,
            set: function (data) {
                this.set('caseReview.WereAllPlacementChangesPlanned', data.WereAllPlacementChangesPlanned);
            }
        },
        placementApplicableCircumstances: {
            bind: { bindTo: '{caseReview.PlacementApplicableCircumstances}', deep: true },
            get: function (data) {
                var arr = this.toArray(data);
                if (this.hasValueInArray(arr, 121)) { //121=none
                    arr = [121];
                    this.set('caseReview.PlacementApplicableCircumstancesOther', null);
                    this.set('caseReview.IsCurrentPlacementSettingStable', 1);
                }
                return { PlacementApplicableCircumstances: arr };
            },
            set: function (data) {
                var arr = this.toArray(data.PlacementApplicableCircumstances);

                if (!this.hasValueInArray(arr, 126)) {//other
                    this.set('caseReview.PlacementApplicableCircumstancesOther', null);
                }
                if (this.hasValueInArray(arr, 121)) { //121=none
                    arr = [121];
                    this.set('caseReview.PlacementApplicableCircumstancesOther', null);
                    this.set('caseReview.IsCurrentPlacementSettingStable', 1);
                }
                else {
                    this.set('caseReview.IsCurrentPlacementSettingStable', 2);
                }
                this.set('caseReview.PlacementApplicableCircumstances', arr);
            }
        },
        isCurrentPlacementSettingStable: {
            bind: { bindTo: '{caseReview.IsCurrentPlacementSettingStable}' },
            get: function (data) {
                return { IsCurrentPlacementSettingStable: data };
            },
            set: function (data) {
                this.set('caseReview.IsCurrentPlacementSettingStable', data.IsCurrentPlacementSettingStable);
            }
        },

        item5IsApplicable: {
            bind: { bindTo: '{caseReview.Item5IsApplicable}' },
            get: function (data) {
                return { Item5IsApplicable: data };
            },
            set: function (data) {
                this.set('caseReview.Item5IsApplicable', data.Item5IsApplicable);
            }
        },
        isGoalSpecified: {
            bind: { bindTo: '{caseReview.IsGoalSpecified}' },
            get: function (data) {
                return { IsGoalSpecified: data };
            },
            set: function (data) {
                this.set('caseReview.IsGoalSpecified', data.IsGoalSpecified);
            }
        },
        wereAllGoalsInTimelyManner: {
            bind: { bindTo: '{caseReview.WereAllGoalsInTimelyManner}' },
            get: function (data) {
                return { WereAllGoalsInTimelyManner: data };
            },
            set: function (data) {
                this.set('caseReview.WereAllGoalsInTimelyManner', data.WereAllGoalsInTimelyManner);
                if (data.WereAllGoalsInTimelyManner != 2) this.set('caseReview.AllGoalsInTimelyMannerExplained', null);
            }
        },
        wereAllGoalsAppropriate: {
            bind: { bindTo: '{caseReview.WereAllGoalsAppropriate}' },
            get: function (data) {
                return { WereAllGoalsAppropriate: data };
            },
            set: function (data) {
                this.set('caseReview.WereAllGoalsAppropriate', data.WereAllGoalsAppropriate);
                if (data.WereAllGoalsAppropriate != 2) this.set('caseReview.AllGoalsAppropriateExplained', null);
            }
        },
        isInFoster15OutOf22: {
            bind: { bindTo: '{caseReview.IsInFoster15OutOf22}' },
            get: function (data) {
                return { IsInFoster15OutOf22: data };
            },
            set: function (data) {
                if (data.IsInFoster15OutOf22 === 1)
                    this.set('caseReview.MeetsTerminationOfParentalRights', 3);
                else if (data.IsInFoster15OutOf22 === 2 && this.get('caseReview.MeetsTerminationOfParentalRights') === 2) {
                    this.set('caseReview.IsAgencyJointTerminationOfParentalRights', 3);
                    this.set('caseReview.TerminationExceptions', [138]);
                }
                this.set('caseReview.IsInFoster15OutOf22', data.IsInFoster15OutOf22);
            }
        },
        meetsTerminationOfParentalRights: {
            bind: { bindTo: '{caseReview.MeetsTerminationOfParentalRights}' },
            get: function (data) {
                return { MeetsTerminationOfParentalRights: data };
            },
            set: function (data) {

                if (data.MeetsTerminationOfParentalRights === 2 && this.get('caseReview.IsInFoster15OutOf22') === 2) {
                    this.set('caseReview.IsAgencyJointTerminationOfParentalRights', 3);
                    this.set('caseReview.TerminationExceptions', [138]);
                }
                this.set('caseReview.MeetsTerminationOfParentalRights', data.MeetsTerminationOfParentalRights);
            }
        },
        isAgencyJointTerminationOfParentalRights: {
            bind: { bindTo: '{caseReview.IsAgencyJointTerminationOfParentalRights}' },
            get: function (data) {
                return { IsAgencyJointTerminationOfParentalRights: data };
            },
            set: function (data) {
                var val = data.IsAgencyJointTerminationOfParentalRights;
                if (val === 1 || val === 3) {
                    this.set('caseReview.TerminationExceptions', [138]);
                    this.set('caseReview.IsExceptionForTermination', 3);
                }
                this.set('caseReview.IsAgencyJointTerminationOfParentalRights', val);
            }
        },
        terminationExceptions: {
            bind: { bindTo: '{caseReview.TerminationExceptions}', deep: true },
            get: function (data) {
                var arr = this.toArray(data);
                if (this.hasValueInArray(arr, 138)) { //na
                    arr = [138];
                }
                else if (this.hasValueInArray(arr, 139)) { //no
                    arr = [139];
                }
                return { TerminationExceptions: arr };
            },
            set: function (data) {
                var arr = this.toArray(data.TerminationExceptions);
                if (this.hasValueInArray(arr, 138)) { //na
                    arr = [138];
                }
                else if (this.hasValueInArray(arr, 139)) { //no
                    arr = [139];
                    this.set('caseReview.IsExceptionForTermination', 1);
                }
                this.set('caseReview.TerminationExceptions', arr);
            }
        },
        isExceptionForTermination: {
            bind: { bindTo: '{caseReview.IsExceptionForTermination}' },
            get: function (data) {
                return { IsExceptionForTermination: data };
            },
            set: function (data) {
                this.set('caseReview.IsExceptionForTermination', data.IsExceptionForTermination);
            }
        },

        item6IsApplicable: {
            bind: { bindTo: '{caseReview.Item6IsApplicable}' },
            get: function (data) {
                return { Item6IsApplicable: data };
            },
            set: function (data) {
                this.set('caseReview.Item6IsApplicable', data.Item6IsApplicable);
            }
        },
        permanencyGoal1: {
            bind: { bindTo: '{caseReview.PermanencyGoal1}', deep: true },
            get: function (data) {
                var arr = this.toArray(data);
                return { PermanencyGoal1: arr };
            },
            set: function (data) {
                var arr = this.toArray(data.PermanencyGoal1);
                this.set('caseReview.PermanencyGoal1', arr);
            }
        },
        isAgencyConcertedEfforts: {
            bind: { bindTo: '{caseReview.IsAgencyConcertedEfforts}' },
            get: function (data) {

                if (this.get('hasOPPLA')) {
                    this.set('caseReview.IsAgencyConcertedEfforts', 3);
                    data = 3;
                }
                return { IsAgencyConcertedEfforts: data };
            },
            set: function (data) {
                this.set('caseReview.IsAgencyConcertedEfforts', data.IsAgencyConcertedEfforts);
                if (data.IsAgencyConcertedEfforts != 2) this.set('caseReview.AgencyConcertedEffortsExplained', null);
            }
        },
        isAgencyConcertedEffortsDisabled: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var goals = this.toArray(this.get('totalGoalRows')),
                    hasOPPLA = this.get('hasOPPLA')
                    ;
                return hasOPPLA && !Ext.isEmpty(this.get('caseReview.IsAgencyConcertedEfforts'));
            }
        },
        livingArrangementCode: {
            bind: { bindTo: '{caseReview.LivingArrangementCode}' },
            get: function (data) {
                return data;
            },
            set: function (data) {
                this.set('caseReview.LivingArrangementCode', data);
                if (data != 6) this.set('caseReview.LivingArrangementExplained', null);
            }
        },
        isDischargeDateNACheck: {
            bind: { bindTo: '{caseReview.IsDischargeDateNA}' },
            get: function (val) {
                return val === 1;
            },
            set: function (val) {
                this.set('caseReview.IsDischargeDateNA', val ? 1 : 2);
            }
        },

        isOtherPlannedArrangement: {
            bind: { bindTo: '{caseReview.IsOtherPlannedArrangement}' },
            get: function (data) {
                if (this.get('hasOPPLA')) {
                    this.set('caseReview.IsOtherPlannedArrangement', 1);
                    this.set('caseReview.IsOtherPlannedArrangementNA', 1);
                    this.set('caseReview.IsOtherPlannedArrangementNoDate', null);
                    this.set('caseReview.OtherPlannedArrangementDocumentationDate', null);
                    return { IsOtherPlannedArrangement: 1 };
                }
                // var val = data.IsOtherPlannedArrangementNA ? 1 : data.IsOtherPlannedArrangementNA ? 4 : null

                if (Ext.isEmpty(this.get('caseReview.OtherPlannedArrangementDocumentationDate'))) {
                    if (this.get('caseReview.IsOtherPlannedArrangementNoDate') === 1) {
                        data = 4;
                    }
                    else {
                        data = 1;
                        this.set('caseReview.IsOtherPlannedArrangementNA', 1)
                    }
                }

                return { IsOtherPlannedArrangement: data };
            },
            set: function (data) {
                this.set('caseReview.IsOtherPlannedArrangement', data.IsOtherPlannedArrangement);
                this.set('caseReview.IsOtherPlannedArrangementNA', data.IsOtherPlannedArrangement === 1 ? 1 : null);
                this.set('caseReview.IsOtherPlannedArrangementNoDate', data.IsOtherPlannedArrangement === 4 ? 1 : null);

                if (data.IsOtherPlannedArrangement === 1 || data.IsOtherPlannedArrangement === 4) {
                    this.set('caseReview.OtherPlannedArrangementDocumentationDate', null);
                }
            }
        },

        isOtherPlannedConcertedEffort: {
            bind: { bindTo: '{caseReview.IsOtherPlannedConcertedEffort}' },
            get: function (data) {
                if (this.get('isNonOPPLA')) {
                    this.set('caseReview.IsOtherPlannedConcertedEffort', 3);
                    return { IsOtherPlannedConcertedEffort: 3 };
                }
                return { IsOtherPlannedConcertedEffort: data };
            },
            set: function (data) {
                this.set('caseReview.IsOtherPlannedConcertedEffort', data.IsOtherPlannedConcertedEffort);
                if (data.IsOtherPlannedConcertedEffort != 2) this.set('caseReview.OtherPlannedConcertedEffortExplained', null);
            }
        },
        item7IsApplicable: {
            bind: { bindTo: '{caseReview.Item7IsApplicable}' },
            get: function (data) {
                if (!this.get('hasSibling')) {
                    this.set('caseReview.Item7IsApplicable', 2);
                    return { Item7IsApplicable: 2 };
                }
                return { Item7IsApplicable: data === null ? 2 : data };
            },
            set: function (data) {
                this.set('caseReview.Item7IsApplicable', data.Item7IsApplicable);
            }
        },
        isPlacedWithAllSiblings: {
            bind: { bindTo: '{caseReview.IsPlacedWithAllSiblings}' },
            get: function (data) {
                return { IsPlacedWithAllSiblings: data };
            },
            set: function (data) {
                if (data.IsPlacedWithAllSiblings === 1) {
                    this.set('caseReview.IsValidReasonForSeparation', 3);
                    this.set('caseReview.ValidReasonForSeparationExplained', null);
                }
                this.set('caseReview.IsPlacedWithAllSiblings', data.IsPlacedWithAllSiblings);
            }
        },
        isValidReasonForSeparation: {
            bind: { bindTo: '{caseReview.IsValidReasonForSeparation}' },
            get: function (data) {
                return { IsValidReasonForSeparation: data };
            },
            set: function (data) {
                this.set('caseReview.IsValidReasonForSeparation', data.IsValidReasonForSeparation);
                if (data.IsValidReasonForSeparation != 2) this.set('caseReview.ValidReasonForSeparationExplained', null);
            }
        },
        item8IsApplicable: {
            bind: { bindTo: '{caseReview.Item8IsApplicable}' },
            get: function (data) {
                return { Item8IsApplicable: data };
            },
            set: function (data) {
                this.set('caseReview.Item8IsApplicable', data.Item8IsApplicable);
                if (data.Item8IsApplicable === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item8ParticipantMother')))//mother
                    {
                        this.set('caseReview.MotherVisitationFrequencyCode', 1);
                        this.set('caseReview.IsSufficientFrequencyForMotherVisitation', 3);
                        this.set('caseReview.IsSufficientQualityForMotherVisitation', 3);
                    }
                    if (!this.hasItemParticipant(this.get('caseReview.Item8ParticipantFather')))//father
                    {
                        this.set('caseReview.FatherVisitationFrequencyCode', 1);
                        this.set('caseReview.IsSufficientFrequencyForFatherVisitation', 3);
                        this.set('caseReview.IsSufficentQualityForFatherVisitation', 3);
                    }
                }
            }
        },
        item8OneChildOrPlacedWithAllSiblings: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var flag = (this.get('hasSingleChildOnly') || this.get('caseReview.IsPlacedWithAllSiblings') === 1);
                if (flag) {
                    this.set('caseReview.SiblingVisitationFrequencyCode', 1);
                    this.set('caseReview.IsSufficientFrequencyForSiblingVisitation', 3);
                    this.set('caseReview.IsSufficentQualityForSiblingVisitation', 3);
                }
                return flag;
            }
        },
        item8ApplicabilityNoMotherParticipant: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                return this.get('caseReview.Item8IsApplicable') === 1 && !this.hasItemParticipant(this.get('caseReview.Item8ParticipantMother'));
            }
        },
        item8ApplicabilityNoFatherParticipant: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                return this.get('caseReview.Item8IsApplicable') === 1 && !this.hasItemParticipant(this.get('caseReview.Item8ParticipantFather'));
            }
        },

        item8Applicability57: {
            bind: { bindTo: '{caseReview.ItemApplicability57}' },
            get: function (data) {
                //  console.log(this.get('hasSingleChildOnly'));
                if (this.get('hasSingleChildOnly')) {
                    this.set('caseReview.ItemApplicability57', 2);
                    return { ItemApplicability57: 2 };
                }
                return { ItemApplicability57: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability57', data.ItemApplicability57);
            }
        },
        item8Applicability58: {
            bind: { bindTo: '{caseReview.ItemApplicability58}' },
            get: function (data) {
                return { ItemApplicability58: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability58', data.ItemApplicability58);
            }
        },
        item8Applicability59: {
            bind: { bindTo: '{caseReview.ItemApplicability59}' },
            get: function (data) {
                return { ItemApplicability59: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability59', data.ItemApplicability59);
            }
        },
        item8Applicability60: {
            bind: { bindTo: '{caseReview.ItemApplicability60}' },
            get: function (data) {
                return { ItemApplicability60: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability60', data.ItemApplicability60);
            }
        },
        item8Applicability61: {
            bind: { bindTo: '{caseReview.ItemApplicability61}' },
            get: function (data) {
                return { ItemApplicability61: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability61', data.ItemApplicability61);
            }
        },
        item8Applicability62: {
            bind: { bindTo: '{caseReview.ItemApplicability62}' },
            get: function (data) {
                return { ItemApplicability62: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability62', data.ItemApplicability62);
            }
        },

        motherVisitationFrequencyCode: {
            bind: { bindTo: '{caseReview.MotherVisitationFrequencyCode}' },
            get: function (data) {

                if (this.get('caseReview.Item8IsApplicable') === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item8ParticipantMother')))//mother
                        this.set('caseReview.MotherVisitationFrequencyCode', 1);
                }
                return { MotherVisitationFrequencyCode: data };
            },
            set: function (data) {
                this.set('caseReview.MotherVisitationFrequencyCode', data.MotherVisitationFrequencyCode);
            }
        },
        fatherVisitationFrequencyCode: {
            bind: { bindTo: '{caseReview.FatherVisitationFrequencyCode}' },
            get: function (data) {
                if (this.get('caseReview.Item8IsApplicable') === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item8ParticipantFather')))//father
                        this.set('caseReview.FatherVisitationFrequencyCode', 1);
                }
                return { FatherVisitationFrequencyCode: data };
            },
            set: function (data) {
                this.set('caseReview.FatherVisitationFrequencyCode', data.FatherVisitationFrequencyCode);
            }
        },
        isSufficientFrequencyForMotherVisitation: {
            bind: { bindTo: '{caseReview.IsSufficientFrequencyForMotherVisitation}' },
            get: function (data) {
                if (this.get('caseReview.Item8IsApplicable') === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item8ParticipantMother')))//mother
                        this.set('caseReview.IsSufficientFrequencyForMotherVisitation', 3);
                }
                return { IsSufficientFrequencyForMotherVisitation: data };
            },
            set: function (data) {
                this.set('caseReview.IsSufficientFrequencyForMotherVisitation', data.IsSufficientFrequencyForMotherVisitation);
            }
        },
        isSufficientQualityForMotherVisitation: {
            bind: { bindTo: '{caseReview.IsSufficientQualityForMotherVisitation}' },
            get: function (data) {
                if (this.get('caseReview.Item8IsApplicable') === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item8ParticipantMother')))//mother
                        this.set('caseReview.IsSufficientQualityForMotherVisitation', 3);
                }
                return { IsSufficientQualityForMotherVisitation: data };
            },
            set: function (data) {
                this.set('caseReview.IsSufficientQualityForMotherVisitation', data.IsSufficientQualityForMotherVisitation);
            }
        },
        isSufficientFrequencyForFatherVisitation: {
            bind: { bindTo: '{caseReview.IsSufficientFrequencyForFatherVisitation}' },
            get: function (data) {
                if (this.get('caseReview.Item8IsApplicable') === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item8ParticipantFather')))//father
                        this.set('caseReview.IsSufficientFrequencyForFatherVisitation', 3);
                }
                return { IsSufficientFrequencyForFatherVisitation: data };
            },
            set: function (data) {
                this.set('caseReview.IsSufficientFrequencyForFatherVisitation', data.IsSufficientFrequencyForFatherVisitation);
            }
        },
        isSufficentQualityForFatherVisitation: {
            bind: { bindTo: '{caseReview.IsSufficentQualityForFatherVisitation}' },
            get: function (data) {
                if (this.get('caseReview.Item8IsApplicable') === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item8ParticipantFather')))//father
                        this.set('caseReview.IsSufficentQualityForFatherVisitation', 3);
                }
                return { IsSufficentQualityForFatherVisitation: data };
            },
            set: function (data) {
                this.set('caseReview.IsSufficentQualityForFatherVisitation', data.IsSufficentQualityForFatherVisitation);
            }
        },
        siblingVisitationFrequencyCode: {
            bind: { bindTo: '{caseReview.SiblingVisitationFrequencyCode}' },
            get: function (data) {
                if (this.get('item8OneChildOrPlacedWithAllSiblings')) {
                    this.set('caseReview.SiblingVisitationFrequencyCode', 1);
                }
                return { SiblingVisitationFrequencyCode: data };
            },
            set: function (data) {
                this.set('caseReview.SiblingVisitationFrequencyCode', data.SiblingVisitationFrequencyCode);
            }
        },
        isSufficientFrequencyForSiblingVisitation: {
            bind: { bindTo: '{caseReview.IsSufficientFrequencyForSiblingVisitation}' },
            get: function (data) {
                if (this.get('item8OneChildOrPlacedWithAllSiblings')) {
                    this.set('caseReview.IsSufficientFrequencyForSiblingVisitation', 3);
                }
                return { IsSufficientFrequencyForSiblingVisitation: data };
            },
            set: function (data) {
                this.set('caseReview.IsSufficientFrequencyForSiblingVisitation', data.IsSufficientFrequencyForSiblingVisitation);
            }
        },
        isSufficentQualityForSiblingVisitation: {
            bind: { bindTo: '{caseReview.IsSufficentQualityForSiblingVisitation}' },
            get: function (data) {
                if (this.get('item8OneChildOrPlacedWithAllSiblings')) {
                    this.set('caseReview.IsSufficentQualityForSiblingVisitation', 3);
                }
                return { IsSufficentQualityForSiblingVisitation: data };
            },
            set: function (data) {
                this.set('caseReview.IsSufficentQualityForSiblingVisitation', data.IsSufficentQualityForSiblingVisitation);
            }
        },
        item9IsApplicable: {
            bind: { bindTo: '{caseReview.Item9IsApplicable}' },
            get: function (data) {
                return { Item9IsApplicable: data };
            },
            set: function (data) {
                this.set('caseReview.Item9IsApplicable', data.Item9IsApplicable);
            }
        },
        isConcertedEffortsForImportantConnections: {
            bind: { bindTo: '{caseReview.IsConcertedEffortsForImportantConnections}' },
            get: function (data) {
                return { IsConcertedEffortsForImportantConnections: data };
            },
            set: function (data) {
                this.set('caseReview.IsConcertedEffortsForImportantConnections', data.IsConcertedEffortsForImportantConnections);
            }
        },
        isSufficientInquiryForIndianTribe: {
            bind: { bindTo: '{caseReview.IsSufficientInquiryForIndianTribe}' },
            get: function (data) {
                return { IsSufficientInquiryForIndianTribe: data };
            },
            set: function (data) {
                this.set('caseReview.IsSufficientInquiryForIndianTribe', data.IsSufficientInquiryForIndianTribe);
            }
        },
        isTribeProvidedTimelyNotification: {
            bind: { bindTo: '{caseReview.IsTribeProvidedTimelyNotification}' },
            get: function (data) {
                return { IsTribeProvidedTimelyNotification: data };
            },
            set: function (data) {
                this.set('caseReview.IsTribeProvidedTimelyNotification', data.IsTribeProvidedTimelyNotification);
            }
        },
        isAccordanceWithIndianChildWelfareAct: {
            bind: { bindTo: '{caseReview.IsAccordanceWithIndianChildWelfareAct}' },
            get: function (data) {
                return { IsAccordanceWithIndianChildWelfareAct: data };
            },
            set: function (data) {
                this.set('caseReview.IsAccordanceWithIndianChildWelfareAct', data.IsAccordanceWithIndianChildWelfareAct);
            }
        },
        item10IsApplicable: {
            bind: { bindTo: '{caseReview.Item10IsApplicable}' },
            get: function (data) {
                return { Item10IsApplicable: data };
            },
            set: function (data) {
                this.set('caseReview.Item10IsApplicable', data.Item10IsApplicable);
            }
        },
        isRecentPlacementWithRelative: {
            bind: { bindTo: '{caseReview.IsRecentPlacementWithRelative}' },
            get: function (data) {
                return { IsRecentPlacementWithRelative: data };
            },
            set: function (data) {
                this.set('caseReview.IsRecentPlacementWithRelative', data.IsRecentPlacementWithRelative);
            }
        },
        isPlacementWithRelativeStable: {
            bind: { bindTo: '{caseReview.IsPlacementWithRelativeStable}' },
            get: function (data) {
                return { IsPlacementWithRelativeStable: data };
            },
            set: function (data) {
                this.set('caseReview.IsPlacementWithRelativeStable', data.IsPlacementWithRelativeStable);
            }
        },
        isConcertedEffortToLocateMaternalRelatives: {
            bind: {
                bindTo: '{caseReview.IsConcertedEffortToLocateMaternalRelatives}'
            },
            get: function (data) {
                if (data != 2) {
                    var arr = this.toArray(this.get('caseReview.PlacementEffortConcernsMother'));
                    if (arr.length > 0)
                        this.set('caseReview.PlacementEffortConcernsMother', []);
                }
                return { IsConcertedEffortToLocateMaternalRelatives: data };
            },
            set: function (data) {
                if (data.IsConcertedEffortToLocateMaternalRelatives != 2) {
                    this.set('caseReview.PlacementEffortConcernsMother', []);
                }
                this.set('caseReview.IsConcertedEffortToLocateMaternalRelatives', data.IsConcertedEffortToLocateMaternalRelatives);
            }
        },
        placementEffortConcernsMother: {
            bind: { bindTo: '{caseReview.PlacementEffortConcernsMother}', deep: true },
            get: function (data) {
                var arr = this.toArray(data);
                return { PlacementEffortConcernsMother: arr };
            },
            set: function (data) {
                var arr = this.toArray(data.PlacementEffortConcernsMother);
                this.set('caseReview.PlacementEffortConcernsMother', arr);
            }
        },
        isConcertedEffortToLocatePaternalRelatives: {
            bind: { bindTo: '{caseReview.IsConcertedEffortToLocatePaternalRelatives}' },
            get: function (data) {
                if (data != 2) {
                    var arr = this.toArray(this.get('caseReview.PlacementEffortConcernsFather'));
                    if (arr.length > 0)
                        this.set('caseReview.PlacementEffortConcernsFather', []);
                }
                return { IsConcertedEffortToLocatePaternalRelatives: data };
            },
            set: function (data) {
                if (data.IsConcertedEffortToLocatePaternalRelatives != 2) {
                    this.set('caseReview.PlacementEffortConcernsFather', []);
                }
                this.set('caseReview.IsConcertedEffortToLocatePaternalRelatives', data.IsConcertedEffortToLocatePaternalRelatives);
            }
        },
        placementEffortConcernsFather: {
            bind: { bindTo: '{caseReview.PlacementEffortConcernsFather}', deep: true },
            get: function (data) {
                var arr = this.toArray(data);
                return { PlacementEffortConcernsFather: arr };
            },
            set: function (data) {
                var arr = this.toArray(data.PlacementEffortConcernsFather);
                this.set('caseReview.PlacementEffortConcernsFather', arr);
            }
        },

        item11IsApplicable: {
            bind: { bindTo: '{caseReview.Item11IsApplicable}' },
            get: function (data) {
                return { Item11IsApplicable: data };
            },
            set: function (data) {
                this.set('caseReview.Item11IsApplicable', data.Item11IsApplicable);
                if (!this.get('item11ApplicabilityNoMotherParticipant')) {
                    this.set('caseReview.IsConcertedEffortMotherFosterRelationship', 3);
                }
                if (!this.get('item11ApplicabilityNoFatherParticipant')) {
                    this.set('caseReview.IsConcertedEffortFatherFosterRelationship', 3);
                }
            }
        },
        item11ApplicabilityNoMotherParticipant: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                return this.get('caseReview.Item11IsApplicable') === 1 && !this.hasItemParticipant(this.get('caseReview.Item11ParticipantMother'));
            }
        },

        item11ApplicabilityNoFatherParticipant: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                return this.get('caseReview.Item11IsApplicable') === 1 && !this.hasItemParticipant(this.get('caseReview.Item11ParticipantFather'));
            }
        },
        item11Applicability63: {
            bind: { bindTo: '{caseReview.ItemApplicability63}' },
            get: function (data) {
                return { ItemApplicability63: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability63', data.ItemApplicability63);
            }
        },
        item11Applicability64: {
            bind: { bindTo: '{caseReview.ItemApplicability64}' },
            get: function (data) {
                return { ItemApplicability64: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability64', data.ItemApplicability64);
            }
        },
        item11Applicability65: {
            bind: { bindTo: '{caseReview.ItemApplicability65}' },
            get: function (data) {
                return { ItemApplicability65: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability65', data.ItemApplicability65);
            }
        },
        item11Applicability66: {
            bind: { bindTo: '{caseReview.ItemApplicability66}' },
            get: function (data) {
                return { ItemApplicability66: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability66', data.ItemApplicability66);
            }
        },
        item11Applicability67: {
            bind: { bindTo: '{caseReview.ItemApplicability67}', },
            get: function (data) {
                return { ItemApplicability67: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability67', data.ItemApplicability67);
            }
        },
        item11Applicability261: {
            bind: { bindTo: '{caseReview.ItemApplicability261}' },
            get: function (data) {
                return { ItemApplicability261: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability261', data.ItemApplicability261);
            }
        },
        isConcertedEffortMotherFosterRelationship: {
            bind: { bindTo: '{caseReview.IsConcertedEffortMotherFosterRelationship}' },
            get: function (data) {
                //	console.log(this.get('caseReview.Item11IsApplicable'), this.hasItemParticipant(this.get('caseReview.Item11ParticipantMother')))
                if (this.get('caseReview.Item11IsApplicable') === 1 && !this.hasItemParticipant(this.get('caseReview.Item11ParticipantMother'))) {
                    this.set('caseReview.IsConcertedEffortMotherFosterRelationship', 3);
                    data = 3;
                }
                return { IsConcertedEffortMotherFosterRelationship: data };
            },
            set: function (data) {
                this.set('caseReview.IsConcertedEffortMotherFosterRelationship', data.IsConcertedEffortMotherFosterRelationship);
            }
        },
        effortsToSupportMotherFosterRelationship: {
            bind: { bindTo: '{caseReview.EffortsToSupportMotherFosterRelationship}', deep: true },
            get: function (data) {
                var arr = this.toArray(data);

                if (this.get('caseReview.Item11IsApplicable') === 1) {
                    var p = this.get('caseReview.Item11ParticipantMother');
                    if (!this.hasItemParticipant(p))//mother
                    {
                        arr = [164];
                        this.set('caseReview.EffortsMotherFosterOther', null);
                    }
                }

                if (this.hasValueInArray(arr, 164)) { //164=NA
                    arr = [164];
                    this.set('caseReview.EffortsMotherFosterOther', null);
                }
                if (!this.hasValueInArray(arr, 170)) { //170=other
                    this.set('caseReview.EffortsMotherFosterOther', null);
                }
                this.set('caseReview.EffortsToSupportMotherFosterRelationship', arr);
                return { EffortsToSupportMotherFosterRelationship: arr };
            },
            set: function (data) {
                var arr = this.toArray(data.EffortsToSupportMotherFosterRelationship);
                if (this.hasValueInArray(arr, 164)) { //164=NA
                    arr = [164];
                    this.set('caseReview.EffortsMotherFosterOther', null);
                }
                if (!this.hasValueInArray(arr, 170)) { //170=other
                    this.set('caseReview.EffortsMotherFosterOther', null);
                }

                this.set('caseReview.EffortsToSupportMotherFosterRelationship', arr);
            }
        },

        isConcertedEffortFatherFosterRelationship: {
            bind: { bindTo: '{caseReview.IsConcertedEffortFatherFosterRelationship}' },
            get: function (data) {
                if (this.get('caseReview.Item11IsApplicable') === 1 && !this.hasItemParticipant(this.get('caseReview.Item11ParticipantFather'))) {
                    this.set('caseReview.IsConcertedEffortFatherFosterRelationship', 3);
                    data = 3;
                }
                return { IsConcertedEffortFatherFosterRelationship: data };
            },
            set: function (data) {
                this.set('caseReview.IsConcertedEffortFatherFosterRelationship', data.IsConcertedEffortFatherFosterRelationship);
            }
        },
        effortsToSupportFatherFosterRelationship: {
            bind: { bindTo: '{caseReview.EffortsToSupportFatherFosterRelationship}', deep: true },
            get: function (data) {
                var arr = this.toArray(data);

                if (this.get('caseReview.Item11IsApplicable') === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item11ParticipantFather')))//father
                    {
                        arr = [171];
                        this.set('caseReview.EffortFatherFosterRelationshipOther', null);
                    }
                }

                if (this.hasValueInArray(arr, 171)) { //171=NA
                    arr = [171];
                    this.set('caseReview.EffortFatherFosterRelationshipOther', null);
                }
                if (!this.hasValueInArray(arr, 177)) { //177=other
                    this.set('caseReview.EffortFatherFosterRelationshipOther', null);
                }
                this.set('caseReview.EffortsToSupportFatherFosterRelationship', arr);
                return { EffortsToSupportFatherFosterRelationship: arr };
            },
            set: function (data) {
                var arr = this.toArray(data.EffortsToSupportFatherFosterRelationship);
                if (this.hasValueInArray(arr, 171)) { //171=NA
                    arr = [171];
                    this.set('caseReview.EffortFatherFosterRelationshipOther', null);
                }
                if (!this.hasValueInArray(arr, 177)) { //177=other
                    this.set('caseReview.EffortFatherFosterRelationshipOther', null);
                }

                this.set('caseReview.EffortsToSupportFatherFosterRelationship', arr);

            }
        },

        //item 12a
        isComprehensiveAssessementConducted: {
            bind: { bindTo: '{caseReview.IsComprehensiveAssessementConducted}' },
            get: function (data) {
                return { IsComprehensiveAssessementConducted: data };
            },
            set: function (data) {
                this.set('caseReview.IsComprehensiveAssessementConducted', data.IsComprehensiveAssessementConducted);
                if (data.IsComprehensiveAssessementConducted != 2) this.set('caseReview.ComprehensiveAssessmentExplained', null);
            }
        },
        isAppropriateServicesProvided: {
            bind: { bindTo: '{caseReview.IsAppropriateServicesProvided}' },
            get: function (data) {
                return { IsAppropriateServicesProvided: data };
            },
            set: function (data) {
                this.set('caseReview.IsAppropriateServicesProvided', data.IsAppropriateServicesProvided);
                if (data.IsAppropriateServicesProvided != 2) this.set('caseReview.AppropriateServicesProvidedExplained', null);
            }
        },

        //item 12b
        item12bApplicability68: {
            bind: { bindTo: '{caseReview.ItemApplicability68}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//none foster care case
                    this.set('caseReview.ItemApplicability68', 2);
                    return { ItemApplicability68: 2 };
                }
                return { ItemApplicability68: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability68', data.ItemApplicability68);
            }
        },
        item12bApplicability69: {
            bind: { bindTo: '{caseReview.ItemApplicability69}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//none foster care case
                    this.set('caseReview.ItemApplicability69', 2);
                    return { ItemApplicability69: 2 };
                }
                return { ItemApplicability69: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability69', data.ItemApplicability69);
            }
        },
        item12bApplicability70: {
            bind: { bindTo: '{caseReview.ItemApplicability70}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//none foster care case
                    this.set('caseReview.ItemApplicability70', 2);
                    return { ItemApplicability70: 2 };
                }
                return { ItemApplicability70: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability70', data.ItemApplicability70);
            }
        },
        item12bApplicability71: {
            bind: { bindTo: '{caseReview.ItemApplicability71}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//none foster care case
                    this.set('caseReview.ItemApplicability71', 2);
                    return { ItemApplicability71: 2 };
                }
                return { ItemApplicability71: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability71', data.ItemApplicability71);
            }
        },
        item12bApplicability72: {
            bind: { bindTo: '{caseReview.ItemApplicability72}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//none foster care case
                    this.set('caseReview.ItemApplicability72', 2);
                    return { ItemApplicability72: 2 };
                }
                return { ItemApplicability72: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability72', data.ItemApplicability72);
            }
        },

        isNeedsServicesApplicableForMother: {
            bind: { bindTo: '{caseReview.IsNeedsServicesApplicableForMother}' },
            get: function (data) {
                if (!this.get('hasMotherAndOtherParticipant')) {
                    this.set('caseReview.IsNeedsServicesApplicableForMother', 2);
                    data = 2;
                }
                if (data != 1) {
                    this.set('caseReview.IsComprehensiveAssessementForMotherConducted', 3);
                    this.set('caseReview.IsAppropriateServicesForMotherProvided', 3);
                    this.set('caseReview.Item12bParticipantMother', [])
                }
                return { IsNeedsServicesApplicableForMother: data };
            },
            set: function (data) {
                this.set('caseReview.IsNeedsServicesApplicableForMother', data.IsNeedsServicesApplicableForMother);
                if (data.IsNeedsServicesApplicableForMother === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item12bParticipantMother')))//mother
                    {
                        this.set('caseReview.IsComprehensiveAssessementForMotherConducted', 3);
                        this.set('caseReview.IsAppropriateServicesForMotherProvided', 3);
                    }
                }
                else {
                    this.set('caseReview.IsComprehensiveAssessementForMotherConducted', 3);
                    this.set('caseReview.IsAppropriateServicesForMotherProvided', 3);
                    this.set('caseReview.Item12bParticipantMother', [])
                }
            }
        },

        isNeedsServicesApplicableForFather: {
            bind: { bindTo: '{caseReview.IsNeedsServicesApplicableForFather}' },
            get: function (data) {
                if (!this.get('hasFatherAndOtherParticipant')) {
                    this.set('caseReview.IsNeedsServicesApplicableForFather', 2);
                    data = 2;
                }

                if (data != 1) {
                    this.set('caseReview.IsComprehensiveAssessementForFatherConducted', 3);
                    this.set('caseReview.IsAppropriateServicesForFatherProvided', 3);
                    this.set('caseReview.Item12bParticipantFather', [])
                }
                return { IsNeedsServicesApplicableForFather: data };
            },
            set: function (data) {
                this.set('caseReview.IsNeedsServicesApplicableForFather', data.IsNeedsServicesApplicableForFather);
                if (data.IsNeedsServicesApplicableForFather === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item12bParticipantFather')))//father
                    {
                        this.set('caseReview.IsComprehensiveAssessementForFatherConducted', 3);
                        this.set('caseReview.IsAppropriateServicesForFatherProvided', 3);
                    }
                }
                else {
                    this.set('caseReview.IsComprehensiveAssessementForFatherConducted', 3);
                    this.set('caseReview.IsAppropriateServicesForFatherProvided', 3);
                    this.set('caseReview.Item12bParticipantFather', [])
                }
            }
        },

        item12bApplicabilityNoMotherParticipant: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var applicable = this.get('caseReview.IsNeedsServicesApplicableForMother') === 1;
                return !applicable || !this.hasItemParticipant(this.get('caseReview.Item12bParticipantMother'));
            }
        },

        item12bApplicabilityNoFatherParticipant: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var applicable = this.get('caseReview.IsNeedsServicesApplicableForFather') === 1;
                return !applicable || !this.hasItemParticipant(this.get('caseReview.Item12bParticipantFather'));
            }
        },

        isComprehensiveAssessementForMotherConducted: {
            bind: { bindTo: '{caseReview.IsComprehensiveAssessementForMotherConducted}' },
            get: function (data) {
                if (!this.hasItemParticipant(this.get('caseReview.Item12bParticipantMother')))//mother
                    this.set('caseReview.IsComprehensiveAssessementForMotherConducted', 3);
                return { IsComprehensiveAssessementForMotherConducted: data };
            },
            set: function (data) {
                this.set('caseReview.IsComprehensiveAssessementForMotherConducted', data.IsComprehensiveAssessementForMotherConducted);
                if (data.IsComprehensiveAssessementForMotherConducted != 2) this.set('caseReview.ComprehensiveAssessementForMotherExplained', null);
            }
        },
        isComprehensiveAssessementForFatherConducted: {
            bind: { bindTo: '{caseReview.IsComprehensiveAssessementForFatherConducted}' },
            get: function (data) {
                if (!this.hasItemParticipant(this.get('caseReview.Item12bParticipantFather')))//mother
                    this.set('caseReview.IsComprehensiveAssessementForFatherConducted', 3);

                return { IsComprehensiveAssessementForFatherConducted: data };
            },
            set: function (data) {
                this.set('caseReview.IsComprehensiveAssessementForFatherConducted', data.IsComprehensiveAssessementForFatherConducted);
                if (data.IsComprehensiveAssessementForFatherConducted != 2) this.set('caseReview.ComprehensiveAssessementforFatherConductedExplained', null);
            }
        },
        isAppropriateServicesForMotherProvided: {
            bind: { bindTo: '{caseReview.IsAppropriateServicesForMotherProvided}' },
            get: function (data) {
                if (!this.hasItemParticipant(this.get('caseReview.Item12bParticipantMother')))//mother
                    this.set('caseReview.IsAppropriateServicesForMotherProvided', 3);
                return { IsAppropriateServicesForMotherProvided: data };
            },
            set: function (data) {
                this.set('caseReview.IsAppropriateServicesForMotherProvided', data.IsAppropriateServicesForMotherProvided);
                if (data.IsAppropriateServicesForMotherProvided != 2) this.set('caseReview.AppropriateServicesForMotherExplained', null);
            }
        },
        isAppropriateServicesForFatherProvided: {
            bind: { bindTo: '{caseReview.IsAppropriateServicesForFatherProvided}' },
            get: function (data) {
                if (!this.hasItemParticipant(this.get('caseReview.Item12bParticipantFather')))//father
                    this.set('caseReview.IsAppropriateServicesForFatherProvided', 3);
                return { IsAppropriateServicesForFatherProvided: data };
            },
            set: function (data) {
                this.set('caseReview.IsAppropriateServicesForFatherProvided', data.IsAppropriateServicesForFatherProvided);
                if (data.IsAppropriateServicesForFatherProvided != 2) this.set('caseReview.AppropriateServicesForFatherExplained', null);
            }
        },

        //item 12c
        item12cIsApplicable: {
            bind: { bindTo: '{caseReview.Item12cIsApplicable}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//none foster care case
                    this.set('caseReview.Item12cIsApplicable', 2);
                    return { Item12cIsApplicable: 2 };
                }
                return { Item12cIsApplicable: data };
            },
            set: function (data) {
                this.set('caseReview.Item12cIsApplicable', data.Item12cIsApplicable);
            }
        },
        isNeedsOfFosterParentsAdequatelyAssessed: {
            bind: { bindTo: '{caseReview.IsNeedsOfFosterParentsAdequatelyAssessed}' },
            get: function (data) {
                return { IsNeedsOfFosterParentsAdequatelyAssessed: data };
            },
            set: function (data) {
                this.set('caseReview.IsNeedsOfFosterParentsAdequatelyAssessed', data.IsNeedsOfFosterParentsAdequatelyAssessed);
                if (data.IsNeedsOfFosterParentsAdequatelyAssessed != 2) this.set('caseReview.NeedsOfFosterParentsAdequatelyAssessedExplained', null);
            }
        },
        isFosterParentsProvidedAppropriateServices: {
            bind: { bindTo: '{caseReview.IsFosterParentsProvidedAppropriateServices}' },
            get: function (data) {
                return { IsFosterParentsProvidedAppropriateServices: data };
            },
            set: function (data) {
                this.set('caseReview.IsFosterParentsProvidedAppropriateServices', data.IsFosterParentsProvidedAppropriateServices);
                if (data.IsFosterParentsProvidedAppropriateServices != 2) this.set('caseReview.FosterParentsProvidedAppropriateServicesExplained', null);
            }
        },

        //item 13
        item13IsApplicable: {
            bind: { bindTo: '{caseReview.Item13IsApplicable}' },
            get: function (data) {
                return { Item13IsApplicable: data };
            },
            set: function (data) {
                this.set('caseReview.Item13IsApplicable', data.Item13IsApplicable);
                if (data.Item13IsApplicable === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item13ParticipantChild')) && !this.get('isFosterCareCase'))//child
                    {
                        this.set('caseReview.IsAgencyConcertedEffortsToInvolveTheChild', 3);
                    }
                    if (!this.hasItemParticipant(this.get('caseReview.Item13ParticipantMother')))//Mother
                    {
                        this.set('caseReview.IsAgencyConcertedEffortsToInvolveTheMother', 3);
                    }
                    if (!this.hasItemParticipant(this.get('caseReview.Item13ParticipantFather')))//father
                    {
                        this.set('caseReview.IsAgencyConcertedEffortsToInvolveTheFather', 3);
                    }
                }
            }
        },
        item13ApplicabilityNoChildParticipant: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                var flag = this.get('caseReview.Item13IsApplicable') === 1 && !this.hasItemParticipant(this.get('caseReview.Item13ParticipantChild')) && !this.get('isFosterCareCase');
                //	console.log(flag)
                return flag;
            }
        },
        item13ApplicabilityNoMotherParticipant: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                return this.get('caseReview.Item13IsApplicable') === 1 && !this.hasItemParticipant(this.get('caseReview.Item13ParticipantMother'));
            }
        },
        item13ApplicabilityNoFatherParticipant: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                return this.get('caseReview.Item13IsApplicable') === 1 && !this.hasItemParticipant(this.get('caseReview.Item13ParticipantFather'));
            }
        },
        item13Applicability73: {
            bind: { bindTo: '{caseReview.ItemApplicability73}' },
            get: function (data) {

                if (!this.get('isFosterCareCase')) {//none foster care case
                    this.set('caseReview.ItemApplicability73', 2);
                    return { ItemApplicability73: 2 };
                }
                return { ItemApplicability73: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability73', data.ItemApplicability73);
            }
        },
        item13Applicability74: {
            bind: { bindTo: '{caseReview.ItemApplicability74}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//none foster care case
                    this.set('caseReview.ItemApplicability74', 2);
                    return { ItemApplicability74: 2 };
                }
                return { ItemApplicability74: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability74', data.ItemApplicability74);
            }
        },
        item13Applicability75: {
            bind: { bindTo: '{caseReview.ItemApplicability75}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//none foster care case
                    this.set('caseReview.ItemApplicability75', 2);
                    return { ItemApplicability75: 2 };
                }
                return { ItemApplicability75: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability75', data.ItemApplicability75);
            }
        },
        item13Applicability76: {
            bind: { bindTo: '{caseReview.ItemApplicability76}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//none foster care case
                    this.set('caseReview.ItemApplicability76', 2);
                    return { ItemApplicability76: 2 };
                }
                return { ItemApplicability76: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability76', data.ItemApplicability76);
            }
        },
        item13Applicability77: {
            bind: { bindTo: '{caseReview.ItemApplicability77}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//none foster care case
                    this.set('caseReview.ItemApplicability77', 2);
                    return { ItemApplicability77: 2 };
                }
                return { ItemApplicability77: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability77', data.ItemApplicability77);
            }
        },
        item13Applicability78: {
            bind: { bindTo: '{caseReview.ItemApplicability78}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//none foster care case
                    this.set('caseReview.ItemApplicability78', 2);
                    return { ItemApplicability78: 2 };
                }
                return { ItemApplicability78: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability78', data.ItemApplicability78);
            }
        },
        item13Applicability292: {
            bind: { bindTo: '{caseReview.ItemApplicability292}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//none foster care case
                    this.set('caseReview.ItemApplicability292', 2);
                    return { ItemApplicability292: 2 };
                }
                return { ItemApplicability292: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability292', data.ItemApplicability292);
            }
        },
        isAgencyConcertedEffortsToInvolveTheChild: {
            bind: { bindTo: '{caseReview.IsAgencyConcertedEffortsToInvolveTheChild}' },
            get: function (data) {
                if (this.get('caseReview.Item13IsApplicable') === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item13ParticipantChild')) && !this.get('isFosterCareCase'))//child
                        this.set('caseReview.IsAgencyConcertedEffortsToInvolveTheChild', 3);
                }
                return { IsAgencyConcertedEffortsToInvolveTheChild: data };
            },
            set: function (data) {
                this.set('caseReview.IsAgencyConcertedEffortsToInvolveTheChild', data.IsAgencyConcertedEffortsToInvolveTheChild);
                if (data != 2) this.set('caseReview.AgencyConcertedEffortsToInvolveTheChildExplained', null);
            }
        },

        isAgencyConcertedEffortsToInvolveTheMother: {
            bind: { bindTo: '{caseReview.IsAgencyConcertedEffortsToInvolveTheMother}' },
            get: function (data) {
                if (this.get('caseReview.Item13IsApplicable') === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item13ParticipantMother')))//mother
                        this.set('caseReview.IsAgencyConcertedEffortsToInvolveTheMother', 3);
                }
                return { IsAgencyConcertedEffortsToInvolveTheMother: data };
            },
            set: function (data) {
                this.set('caseReview.IsAgencyConcertedEffortsToInvolveTheMother', data.IsAgencyConcertedEffortsToInvolveTheMother);
                if (data != 2) this.set('caseReview.AgencyConcertedEffortsToInvolveTheMotherExplained', null);
            }
        },

        isAgencyConcertedEffortsToInvolveTheFather: {
            bind: { bindTo: '{caseReview.IsAgencyConcertedEffortsToInvolveTheFather}' },
            get: function (data) {

                if (this.get('caseReview.Item13IsApplicable') === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item13ParticipantFather')))//father
                        this.set('caseReview.IsAgencyConcertedEffortsToInvolveTheFather', 3);
                }
                return { IsAgencyConcertedEffortsToInvolveTheFather: data };
            },
            set: function (data) {
                this.set('caseReview.IsAgencyConcertedEffortsToInvolveTheFather', data.IsAgencyConcertedEffortsToInvolveTheFather);
                if (data != 2) this.set('caseReview.AgencyConcertedEffortsToInvolveTheFatherExplained', null);
            }
        },

        //item 14
        responsiblePartyVisitationFrequencyCode: {
            bind: { bindTo: '{caseReview.ResponsiblePartyVisitationFrequencyCode}' },
            get: function (data) {
                return { ResponsiblePartyVisitationFrequencyCode: data };
            },
            set: function (data) {
                this.set('caseReview.ResponsiblePartyVisitationFrequencyCode', data.ResponsiblePartyVisitationFrequencyCode);
            }
        },
        isResponsiblePartyVisitationFrequencySufficient: {
            bind: { bindTo: '{caseReview.IsResponsiblePartyVisitationFrequencySufficient}' },
            get: function (data) {
                return { IsResponsiblePartyVisitationFrequencySufficient: data };
            },
            set: function (data) {
                this.set('caseReview.IsResponsiblePartyVisitationFrequencySufficient', data.IsResponsiblePartyVisitationFrequencySufficient);
            }
        },
        isResponsiblePartyVisitationQualitySufficient: {
            bind: { bindTo: '{caseReview.IsResponsiblePartyVisitationQualitySufficient}' },
            get: function (data) {
                return { IsResponsiblePartyVisitationQualitySufficient: data };
            },
            set: function (data) {
                this.set('caseReview.IsResponsiblePartyVisitationQualitySufficient', data.IsResponsiblePartyVisitationQualitySufficient);
                if (data.IsResponsiblePartyVisitationQualitySufficient != 2) this.set('caseReview.ResponsiblePartyVisitationQualityExplained', null);
            }
        }
        ,

        item15IsApplicable: {
            bind: { bindTo: '{caseReview.Item15IsApplicable}' },
            get: function (data) {
                return { Item15IsApplicable: data };
            },
            set: function (data) {
                this.set('caseReview.Item15IsApplicable', data.Item15IsApplicable);

                if (data.Item15IsApplicable === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item15ParticipantMother')))//Mother
                    {
                        this.set('caseReview.ResponsiblePartyVisitationFrequencyWithMotherCode', 1);
                        this.set('caseReview.IsResponsiblePartyVisitationFrequencyWithMotherSufficient', 3);
                        this.set('caseReview.IsResponsiblePartyVisitationQualityWithMotherSufficient', 3);
                    }
                    if (!this.hasItemParticipant(this.get('caseReview.Item15ParticipantFather')))//father
                    {
                        this.set('caseReview.ResponsiblePartyVisitationFrequencyWithFatherCode', 1);
                        this.set('caseReview.IsResponsiblePartyVisitationFrequencyWithFatherSufficient', 3);
                        this.set('caseReview.IsResponsiblePartyVisitationQualityWithFatherSufficient', 3);
                    }
                }
            }
        },
        item15Applicability293: {
            bind: { bindTo: '{caseReview.ItemApplicability293}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//none foster care case
                    this.set('caseReview.ItemApplicability293', 2);
                    return { ItemApplicability293: 2 };
                }
                return { ItemApplicability293: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability293', data.ItemApplicability293);
            }
        },
        item15Applicability79: {
            bind: { bindTo: '{caseReview.ItemApplicability79}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//none foster care case
                    this.set('caseReview.ItemApplicability79', 2);
                    return { ItemApplicability79: 2 };
                }
                return { ItemApplicability79: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability79', data.ItemApplicability79);
            }
        },
        item15Applicability80: {
            bind: { bindTo: '{caseReview.ItemApplicability80}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//none foster care casethis.get('caseReview.ReviewSubTypeID') != 20
                    this.set('caseReview.ItemApplicability80', 2);
                    return { ItemApplicability80: 2 };
                }
                return { ItemApplicability80: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability80', data.ItemApplicability80);
            }
        },
        item15Applicability81: {
            bind: { bindTo: '{caseReview.ItemApplicability81}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//none foster care case
                    this.set('caseReview.ItemApplicability81', 2);
                    return { ItemApplicability81: 2 };
                }
                return { ItemApplicability81: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability81', data.ItemApplicability81);
            }
        },
        item15Applicability82: {
            bind: { bindTo: '{caseReview.ItemApplicability82}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//none foster care case
                    this.set('caseReview.ItemApplicability82', 2);
                    return { ItemApplicability82: 2 };
                }
                return { ItemApplicability82: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability82', data.ItemApplicability82);
            }
        },
        item15Applicability83: {
            bind: { bindTo: '{caseReview.ItemApplicability83}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//none foster care case
                    this.set('caseReview.ItemApplicability83', 2);
                    return { ItemApplicability83: 2 };
                }
                return { ItemApplicability83: data };
            },
            set: function (data) {
                this.set('caseReview.ItemApplicability83', data.ItemApplicability83);
            }
        },
        item15ApplicabilityNoMotherParticipant: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                return this.get('caseReview.Item15IsApplicable') === 1 && !this.hasItemParticipant(this.get('caseReview.Item15ParticipantMother'));
            }
        },
        item15ApplicabilityNoFatherParticipant: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                return this.get('caseReview.Item15IsApplicable') === 1 && !this.hasItemParticipant(this.get('caseReview.Item15ParticipantFather'));
            }
        },

        responsiblePartyVisitationFrequencyWithMotherCode: {
            bind: { bindTo: '{caseReview.ResponsiblePartyVisitationFrequencyWithMotherCode}' },
            get: function (data) {

                if (this.get('caseReview.Item15IsApplicable') === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item15ParticipantMother')))//mother
                        this.set('caseReview.ResponsiblePartyVisitationFrequencyWithMotherCode', 1);
                }
                return { ResponsiblePartyVisitationFrequencyWithMotherCode: data };
            },
            set: function (data) {

                this.set('caseReview.ResponsiblePartyVisitationFrequencyWithMotherCode', data.ResponsiblePartyVisitationFrequencyWithMotherCode);
            }
        },
        responsiblePartyVisitationFrequencyWithFatherCode: {
            bind: { bindTo: '{caseReview.ResponsiblePartyVisitationFrequencyWithFatherCode}' },
            get: function (data) {
                if (this.get('caseReview.Item15IsApplicable') === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item15ParticipantFather')))//father
                        this.set('caseReview.ResponsiblePartyVisitationFrequencyWithFatherCode', 1);
                }
                return { ResponsiblePartyVisitationFrequencyWithFatherCode: data };
            },
            set: function (data) {
                this.set('caseReview.ResponsiblePartyVisitationFrequencyWithFatherCode', data.ResponsiblePartyVisitationFrequencyWithFatherCode);
            }
        },

        isResponsiblePartyVisitationFrequencyWithMotherSufficient: {
            bind: { bindTo: '{caseReview.IsResponsiblePartyVisitationFrequencyWithMotherSufficient}' },
            get: function (data) {
                if (this.get('caseReview.Item15IsApplicable') === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item15ParticipantMother')))//mother
                        this.set('caseReview.IsResponsiblePartyVisitationFrequencyWithMotherSufficient', 3);
                }
                return { IsResponsiblePartyVisitationFrequencyWithMotherSufficient: data };
            },
            set: function (data) {
                this.set('caseReview.IsResponsiblePartyVisitationFrequencyWithMotherSufficient', data.IsResponsiblePartyVisitationFrequencyWithMotherSufficient);
            }
        },
        isResponsiblePartyVisitationFrequencyWithFatherSufficient: {
            bind: { bindTo: '{caseReview.IsResponsiblePartyVisitationFrequencyWithFatherSufficient}' },
            get: function (data) {

                if (this.get('caseReview.Item15IsApplicable') === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item15ParticipantFather')))//father
                        this.set('caseReview.IsResponsiblePartyVisitationFrequencyWithFatherSufficient', 3);
                }
                return { IsResponsiblePartyVisitationFrequencyWithFatherSufficient: data };
            },
            set: function (data) {
                this.set('caseReview.IsResponsiblePartyVisitationFrequencyWithFatherSufficient', data.IsResponsiblePartyVisitationFrequencyWithFatherSufficient);
            }
        },

        isResponsiblePartyVisitationQualityWithMotherSufficient: {
            bind: { bindTo: '{caseReview.IsResponsiblePartyVisitationQualityWithMotherSufficient}' },
            get: function (data) {
                if (this.get('caseReview.Item15IsApplicable') === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item15ParticipantMother')))//mother
                        this.set('caseReview.IsResponsiblePartyVisitationQualityWithMotherSufficient', 3);
                }
                return { IsResponsiblePartyVisitationQualityWithMotherSufficient: data };
            },
            set: function (data) {
                this.set('caseReview.IsResponsiblePartyVisitationQualityWithMotherSufficient', data.IsResponsiblePartyVisitationQualityWithMotherSufficient);
                if (data != 2) this.set('caseReview.ResponsiblePartyVisitationQualityWithMotherExplained', null);
            }
        },
        isResponsiblePartyVisitationQualityWithFatherSufficient: {
            bind: { bindTo: '{caseReview.IsResponsiblePartyVisitationQualityWithFatherSufficient}' },
            get: function (data) {
                if (this.get('caseReview.Item15IsApplicable') === 1) {
                    if (!this.hasItemParticipant(this.get('caseReview.Item15ParticipantFather')))//father
                        this.set('caseReview.IsResponsiblePartyVisitationQualityWithFatherSufficient', 3);
                }
                return { IsResponsiblePartyVisitationQualityWithFatherSufficient: data };
            },
            set: function (data) {
                this.set('caseReview.IsResponsiblePartyVisitationQualityWithFatherSufficient', data.IsResponsiblePartyVisitationQualityWithFatherSufficient);
                if (data != 2) this.set('caseReview.ResponsiblePartyVisitationQualityWithFatherExplained', null);
            }
        },

        item16IsApplicable: {
            bind: { bindTo: '{caseReview.Item16IsApplicable}' },
            get: function (data) {
                return { Item16IsApplicable: data };
            },
            set: function (data) {
                this.set('caseReview.Item16IsApplicable', data.Item16IsApplicable);
            }
        },
        isAgencyAssessEducationNeeds: {
            bind: { bindTo: '{caseReview.IsAgencyAssessEducationNeeds}' },
            get: function (data) {
                return { IsAgencyAssessEducationNeeds: data };
            },
            set: function (data) {
                this.set('caseReview.IsAgencyAssessEducationNeeds', data.IsAgencyAssessEducationNeeds);
            }
        },
        isAgencyAddressEducationNeeds: {
            bind: { bindTo: '{caseReview.IsAgencyAddressEducationNeeds}' },
            get: function (data) {
                return { IsAgencyAddressEducationNeeds: data };
            },
            set: function (data) {
                this.set('caseReview.IsAgencyAddressEducationNeeds', data.IsAgencyAddressEducationNeeds);
            }
        },
        item17IsApplicable: {
            bind: { bindTo: '{caseReview.Item17IsApplicable}' },
            get: function (data) {

                if (this.get('isFosterCareCase')) {// foster care case
                    this.set('caseReview.Item17IsApplicable', 1);
                    return { Item17IsApplicable: 1 };
                }
                return { Item17IsApplicable: data };
            },
            set: function (data) {
                this.set('caseReview.Item17IsApplicable', data.Item17IsApplicable);
            }
        },
        isAgencyAssessPhysicalHealthNeeds: {
            bind: { bindTo: '{caseReview.IsAgencyAssessPhysicalHealthNeeds}' },
            get: function (data) {
                return { IsAgencyAssessPhysicalHealthNeeds: data };
            },
            set: function (data) {
                this.set('caseReview.IsAgencyAssessPhysicalHealthNeeds', data.IsAgencyAssessPhysicalHealthNeeds);
            }
        },
        isAgencyAssessDentalHealthNeeds: {
            bind: { bindTo: '{caseReview.IsAgencyAssessDentalHealthNeeds}' },
            get: function (data) {
                return { IsAgencyAssessDentalHealthNeeds: data };
            },
            set: function (data) {
                this.set('caseReview.IsAgencyAssessDentalHealthNeeds', data.IsAgencyAssessDentalHealthNeeds);
            }
        },
        isFosterOversightMedicationForPhysicalHealtyAppropriate: {
            bind: { bindTo: '{caseReview.IsFosterOversightMedicationForPhysicalHealtyAppropriate}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//none fostercare case
                    this.set('caseReview.IsFosterOversightMedicationForPhysicalHealtyAppropriate', 3);
                    return { IsFosterOversightMedicationForPhysicalHealtyAppropriate: 3 };
                }
                return { IsFosterOversightMedicationForPhysicalHealtyAppropriate: data };
            },
            set: function (data) {
                this.set('caseReview.IsFosterOversightMedicationForPhysicalHealtyAppropriate', data.IsFosterOversightMedicationForPhysicalHealtyAppropriate);
            }
        },
        isAppropriateSerivcesForAllPhysicalHealthNeeds: {
            bind: { bindTo: '{caseReview.IsAppropriateSerivcesForAllPhysicalHealthNeeds}' },
            get: function (data) {
                return { IsAppropriateSerivcesForAllPhysicalHealthNeeds: data };
            },
            set: function (data) {
                this.set('caseReview.IsAppropriateSerivcesForAllPhysicalHealthNeeds', data.IsAppropriateSerivcesForAllPhysicalHealthNeeds);
            }
        },
        isAppropriateServicesForAllDentalNeeds: {
            bind: { bindTo: '{caseReview.IsAppropriateServicesForAllDentalNeeds}' },
            get: function (data) {
                return { IsAppropriateServicesForAllDentalNeeds: data };
            },
            set: function (data) {
                this.set('caseReview.IsAppropriateServicesForAllDentalNeeds', data.IsAppropriateServicesForAllDentalNeeds);
            }
        },
        fosterFederalCaseManagamentCriteria: {
            bind: { bindTo: '{caseReview.FosterFederalCaseManagamentCriteria}' },
            get: function (data) {
                var arr = this.toArray(data);

                if (!this.get('isFosterCareCase')) {//none fostercare case
                    arr = [178];
                }
                else if (this.hasValueInArray(arr, 179)) {
                    arr = [179];
                }

                this.set('caseReview.FosterFederalCaseManagamentCriteria', arr);
                return { FosterFederalCaseManagamentCriteria: arr };
            }
            ,
            set: function (data) {
                var arr = this.toArray(data.FosterFederalCaseManagamentCriteria);
                if (!this.get('isFosterCareCase')) {//none fostercare case
                    arr = [178];
                }
                else if (this.hasValueInArray(arr, 179)) {
                    arr = [179];
                }

                this.set('caseReview.FosterFederalCaseManagamentCriteria', arr);
            }
        },

        item18IsApplicable: {
            bind: { bindTo: '{caseReview.Item18IsApplicable}' },
            get: function (data) {
                return { Item18IsApplicable: data };
            },
            set: function (data) {
                this.set('caseReview.Item18IsApplicable', data.Item18IsApplicable);
            }
        },
        isAgencyAssessMentalHealthNeeds: {
            bind: { bindTo: '{caseReview.IsAgencyAssessMentalHealthNeeds}' },
            get: function (data) {
                return { IsAgencyAssessMentalHealthNeeds: data };
            },
            set: function (data) {
                this.set('caseReview.IsAgencyAssessMentalHealthNeeds', data.IsAgencyAssessMentalHealthNeeds);
            }
        },
        isFosterOversightMedicationForMentalHealtyAppropriate: {
            bind: { bindTo: '{caseReview.IsFosterOversightMedicationForMentalHealtyAppropriate}' },
            get: function (data) {
                if (!this.get('isFosterCareCase')) {//none fostercare case
                    this.set('caseReview.IsFosterOversightMedicationForMentalHealtyAppropriate', 3);
                    return { IsFosterOversightMedicationForMentalHealtyAppropriate: 3 };
                }
                return { IsFosterOversightMedicationForMentalHealtyAppropriate: data };
            },
            set: function (data) {
                this.set('caseReview.IsFosterOversightMedicationForMentalHealtyAppropriate', data.IsFosterOversightMedicationForMentalHealtyAppropriate);
            }
        },
        isAppropriateSerivcesForMentalHealthNeeds: {
            bind: { bindTo: '{caseReview.IsAppropriateSerivcesForMentalHealthNeeds}' },
            get: function (data) {
                return { IsAppropriateSerivcesForMentalHealthNeeds: data };
            },
            set: function (data) {
                this.set('caseReview.IsAppropriateSerivcesForMentalHealthNeeds', data.IsAppropriateSerivcesForMentalHealthNeeds);
            }
        },

        outcome1Rating: {
            bind: {
                bindTo: '{caseReview.Outcome1}',
                deep: true
            }
            ,
            get: function (val) {
                var data = this.getLookupData('OutComeRating', val) || {};
                return data.name || 'Not Yet Determined';
            }
        }
        ,
        outcome2Rating: {
            bind: {
                bindTo: '{caseReview.Outcome2}',
                deep: true
            }
            ,
            get: function (val) {
                var data = this.getLookupData('OutComeRating', val) || {};
                return data.name || 'Not Yet Determined';
            }
        }
        ,
        outcome3Rating: {
            bind: {
                bindTo: '{caseReview.Outcome3}',
                deep: true
            }
            ,
            get: function (val) {
                var data = this.getLookupData('OutComeRating', val) || {};
                return data.name || 'Not Yet Determined';
            }
        }
        ,
        outcome4Rating: {
            bind: {
                bindTo: '{caseReview.Outcome4}',
                deep: true
            }
            ,
            get: function (val) {
                var data = this.getLookupData('OutComeRating', val) || {};
                return data.name || 'Not Yet Determined';
            }
        }
        ,
        outcome5Rating: {
            bind: {
                bindTo: '{caseReview.Outcome5}',
                deep: true
            }
            ,
            get: function (val) {
                var data = this.getLookupData('OutComeRating', val) || {};
                return data.name || 'Not Yet Determined';
            }
        }
        ,
        outcome6Rating: {
            bind: {
                bindTo: '{caseReview.Outcome6}',
                deep: true
            }
            ,
            get: function (val) {
                var data = this.getLookupData('OutComeRating', val) || {};
                return data.name || 'Not Yet Determined';
            }
        }
        ,
        outcome7Rating: {
            bind: { bindTo: '{caseReview.Outcome7}', deep: true },
            get: function (val) {
                var data = this.getLookupData('OutComeRating', val) || {};
                return data.name || 'Not Yet Determined';
            }
        },

        validateItem1IsApplicable: {
            bind: { bindTo: '{caseReview.Item1IsApplicable}' },
            get: function (data) {
                return data === 1 && this.storeInfo.safetyReportStore && this.storeInfo.safetyReportStore.getCount() > 0;
            }
        },
        qaWorkflowBackwardText: {
            bind: { bindTo: '{caseReview.CaseStatusCode}' },
            get: function (statusCode) {

                if (QuickStart.util.Global.permissions.allowTransferBackToDataEntryMode() && statusCode === 4)
                    return 'Return to Reviewer';
                else if (QuickStart.util.Global.permissions.allowSubmitBackToQA() && statusCode === 5)
                    return 'Return to QA';
                else if (QuickStart.util.Global.permissions.allowSubmitBackToQA() && statusCode === 7)
                    return 'Return to QA';
                else
                    return '';
            }
        },
        qaWorkflowForwardText: {
            bind: { bindTo: '{caseReview.CaseStatusCode}' },
            get: function (statusCode) {

                if (QuickStart.util.Global.permissions.allowSubmitCaseToQA() && statusCode === 1)
                    return 'Submit to QA';
                else if (QuickStart.util.Global.permissions.allowSubmitToFinalize() && statusCode === 4)
                    return 'Submit to Secondary QA';
                else if (QuickStart.util.Global.permissions.allowFinalizeCase() && statusCode === 5)
                    return 'Finalize Case';
                else
                    return '';
            }
        },
        canParticipateFurtherInQA: {
            bind: { bindTo: '{caseReview.CaseStatusCode}' },
            get: function (statusCode) {

                if (statusCode === 1) {
                    return QuickStart.util.Global.permissions.allowSubmitCaseToQA();
                } else if (statusCode === 4) {
                    return QuickStart.util.Global.permissions.allowSubmitToFinalize();
                } else if (statusCode === 5) {
                    return QuickStart.util.Global.permissions.allowFinalizeCase();
                }
            }
        },
        canReturnToQaReviewer: {
            bind: { bindTo: '{caseReview.CaseStatusCode}' },
            get: function (statusCode) {
                if (statusCode === 4) {
                    return QuickStart.util.Global.permissions.allowTransferBackToDataEntryMode();
                } else if (statusCode === 7) {
                    return QuickStart.util.Global.permissions.allowSubmitBackToQA();
                }
            }
        },
        requestApproveElimination: {
            bind: { bindTo: '{caseReview.CaseStatusCode}' },
            get: function (statusCode) {
                var val = false;

                if (statusCode === 8 && QuickStart.util.Global.permissions.allowApproveEliminatedCase()) {
                    val = true;
                    return val;
                } else if (statusCode === 6 || statusCode === 7) {
                    return val;
                } else if (QuickStart.util.Global.permissions.allowEliminateCase()) {
                    val = true;
                }
                return val;
            }
        },
        allowedEditCaseSetup: {
            bind: { bindTo: '{caseReview}' },
            get: function (record) {
                return !(record && (record.get('CaseStatusCode') === 6 || record.get('CaseStatusCode') === 7 || record.get('CaseStatusCode') === 8)) && (record && record.get('IsIRR') != true) && QuickStart.util.Global.permissions.allowEditCaseSetup();
            }
        },
        allowedFinalizeImportCases: {
            bind: { bindTo: '{caseReview}' },
            get: function (record) {
                //	console.log(QuickStart.util.Global.permissions.allowFinalizeImportCases(), QuickStart.util.Global.permissions.allowEditCaseSetup(),this.get('isCaseImported'),this.get('caseStatusReadOnly'),this.get('caseStatusReadOnly'))
                return QuickStart.util.Global.permissions.allowFinalizeImportCases() && QuickStart.util.Global.permissions.allowEditCaseSetup() && this.get('isCaseImported');
            }
        },
        allowedSetupCase: {
            bind: { bindTo: '{caseReview}' },
            get: function (record) {
                //	console.log(QuickStart.util.Global.permissions.allowFinalizeImportCases(), QuickStart.util.Global.permissions.allowEditCaseSetup(),this.get('isCaseImported'),this.get('caseStatusReadOnly'),this.get('caseStatusReadOnly'))
                if (this.get('allowedFinalizeImportCases'))
                    return true;
                else if (this.get('caseStatusReadOnly'))
                    return false;
                else
                    return this.get('allowedEditCaseSetup');

            }
        },

        allowedAddEditQANote: {
            bind: { bindTo: '{caseReview}' },
            get: function (record) {
                var userId = QuickStart.util.Global.getUser().id;

                return !(record && (record.get('CaseStatusCode') === 6 || record.get('CaseStatusCode') === 7 || record.get('CaseStatusCode') === 8)) && QuickStart.util.Global.permissions.allowAddEditQANote() && this.hasUserInCaseReview(userId);
            }
        },
        allowedEditCaseData: {
            bind: { bindTo: '{caseReview}' },
            get: function (record) {
                var userId = QuickStart.util.Global.getUser().id;

                return !(record && (record.get('CaseStatusCode') === 6 || record.get('CaseStatusCode') === 7 || record.get('CaseStatusCode') === 8)) && QuickStart.util.Global.permissions.allowEditCaseData() && this.hasUserInCaseReview(userId);
            }
        },
        allowedCreateIRRCase: {
            bind: { bindTo: '{caseReview}' },
            get: function (record) {
                return QuickStart.util.Global.permissions.allowCreateIRRCase();
            }
        },
        allowedSubmitCaseToQA: {
            bind: { bindTo: '{caseReview}' },
            get: function (record) {
                return QuickStart.util.Global.permissions.allowSubmitCaseToQA();
            }
        },
        allowedInterviewNote: {
            bind: { bindTo: '{caseReview}' },
            get: function (record) {
                return QuickStart.util.Global.permissions.allowInterviewNote();
            }
        },
        allowedExport: {
            bind: { bindTo: '{caseReview.CaseStatusCode}' },
            get: function (data) {
                return (data === 7 && QuickStart.util.Global.permissions.allowExportCase());
            }
        },

        //elimination request form
        eliminationRequest: {
            bind: { bindTo: '{current.eliminationRequest}', deep: true },
            get: function (rec) {
                if (rec) {
                    var data = rec.getData();

                    if (!data.IsIdentifyKeyIndividual) {
                        this.set('current.eliminationRequest.IdentifyKeyIndividualExplain', null)
                        this.set('current.eliminationRequest.IsIdentifyPhoneCall', null)
                        this.set('current.eliminationRequest.IdentifyPhoneCallExplain', null)
                        this.set('current.eliminationRequest.IsIdentifyLetter', null)
                        this.set('current.eliminationRequest.IdentifyLetterExplain', null)
                        this.set('current.eliminationRequest.IsIdentifyCpsStaff', null)
                        this.set('current.eliminationRequest.IdentifyCpsStaffExplain', null)
                    }
                    else {
                        if (!data.IsIdentifyPhoneCall) {
                            this.set('current.eliminationRequest.IdentifyPhoneCallExplain', null)
                        }
                        if (!data.IsIdentifyLetter) {
                            this.set('current.eliminationRequest.IdentifyLetterExplain', null)
                        }
                        if (!data.IsIdentifyCpsStaff) {
                            this.set('current.eliminationRequest.IdentifyCpsStaffExplain', null)
                        }

                    }

                    if (!data.IsCaseAppearedMultipleTimes) {
                        this.set('current.eliminationRequest.CaseAppearedMultipleTimesExplain', null)
                    }

                    if (!data.IsHomeServiceCaseDuringPUR) {
                        this.set('current.eliminationRequest.HomeServiceCaseOpenedDuringPUR', null)
                        this.set('current.eliminationRequest.HomeServiceCaseClosedDuringPUR', null)
                    }
                    else {
                        var firstCaseOpeningDate = this.get('caseReview.FirstCaseOpeningDate'),
                            caseClosureDate = this.get('caseReview.CaseClosureDate');
                        if (firstCaseOpeningDate)
                            this.set('current.eliminationRequest.HomeServiceCaseOpenedDuringPUR', firstCaseOpeningDate);
                        if (caseClosureDate)
                            this.set('current.eliminationRequest.HomeServiceCaseClosedDuringPUR', caseClosureDate);
                    }
                    if (!data.IsChildEntryInFosterCare) {
                        this.set('current.eliminationRequest.ChildEntryInFosterCareDate', null)
                    }
                    else {
                        var fosterEntryDate = this.get('caseReview.FosterEntryDate');
                        if (fosterEntryDate)
                            this.set('current.eliminationRequest.ChildEntryInFosterCareDate', fosterEntryDate);
                    }
                    if (!data.IsFosterCareCaseClosed) {
                        this.set('current.eliminationRequest.FosterCareCaseClosedDate', null)
                    }
                    else {
                        var episodeDischargeDate = this.get('caseReview.EpisodeDischargeDate');
                        if (episodeDischargeDate)

                            this.set('current.eliminationRequest.FosterCareCaseClosedDate', episodeDischargeDate);
                    }
                    if (!data.IsTargetChildTurned18) {
                        this.set('current.eliminationRequest.TargetChildTurned18Explain', null)
                    }
                    else {

                        var rows = this.get('totalDemographicTargetChildRows');
                        if (rows && rows.length > 0) {
                            var targetChildDOB = rows[0].DateOfBirth;
                            var targetChildTurned18 = new Date(targetChildDOB.getYear() + 18, targetChildDOB.getMonth(), targetChildDOB.getDay());

                            //  this.set('current.eliminationRequest.TargetChildTurned18Date', Ext.Date.format(targetChildTurned18, 'm/d/Y'));
                            this.set('current.eliminationRequest.TargetChildTurned18Date', targetChildTurned18);
                        }
                    }
                    if (!data.IsTargetChildPlacementOfAnotherState) {
                        this.set('current.eliminationRequest.TargetChildPlacementOfAnotherStateExplain', null)
                    }

                    if (!data.IsChildAdoptionOrGuardianshipFinalize) {
                        this.set('current.eliminationRequest.ChildAdoptionOrGuardianshipFinalizeExplain', null);
                        this.set('current.eliminationRequest.ChildAdoptionOrGuardianshipDateFinalize', null);
                    }
                    else {
                        //  this.set('current.eliminationRequest.ChildAdoptionOrGuardianshipDateFinalize', targetChildTurned18);
                    }
                    if (!data.IsQaTeamForEliminationRequest) {
                        this.set('current.eliminationRequest.QaTeamForEliminationRequestExplain', null)
                    }

                }
                return null;
            }
        },

        caseMeetEliminationCriteria: {
            bind: '{current.eliminationRequest.IsCaseMeetEliminationCriteria}',
            get: function (data) {
                return data === true;
            },
            set: function (data) {
                if (data) {
                    this.set('current.eliminationRequest.IsCaseMeetEliminationCriteria', true);
                    this.set('current.eliminationRequest.CaseMeetEliminationCriteriaReason', null);
                }
            }
        },
        caseDoesNotMeetEliminationCriteria: {
            bind: '{current.eliminationRequest.IsCaseMeetEliminationCriteria}',
            get: function (data) {
                return data === false;
            },
            set: function (data) {
                this.set('current.eliminationRequest.IsCaseMeetEliminationCriteria', !data);
            }
        },
        //case Elimination
        caseEliminationReason: {
            bind: '{current.elimination.EliminationReasonCode}',
            get: function (data) {
                this.set('current.elimination.EliminationReasonExplained', null);
                return data && data >= 5 && data != 6;
            },
            set: function (data) {
                // if (!(data && data >= 5 && data != 6))
                this.set('current.elimination.EliminationReasonExplained', null);
            }
        },
        validElimination: {
            bind: { bindTo: '{current.elimination}', deep: true },
            get: function (rec) {

                var valid = false, dirty = false, elReCode, elReExplain, signOff;
                if (rec) {
                    dirty = rec.isDirty();
                    elReCode = rec.get('EliminationReasonCode');
                    elReExplain = rec.get('EliminationReasonExplained');
                    signOff = rec.get('QaSignOff');

                    valid = dirty && !Ext.isEmpty(elReCode) && signOff;
                    if ((elReCode >= 5 && elReCode != 6) && Ext.isEmpty(elReExplain)) {
                        valid = false;
                    }
                }
                return valid;
            }
        },
        safetyReportAllegationCode: {
            bind: '{current.safetyReport.SafetyReportAllegationCode}',
            get: function (data) {

                return data;
            },
            set: function (data) {
                // if (!(data && data >= 5 && data != 6))
                this.set('current.safetyReport.SafetyReportAllegationCode', data);
            }
        },
        goalDateEstablished: {
            bind: '{current.goal.DateEstablished}',
            get: function (data) {
                return data;
            },
            set: function (data) {
                var dateEstablished = data,
                    fosterEntry = this.get('caseReview.FosterEntryDate');

                if (dateEstablished && fosterEntry) {
                    var diff = Ext.Date.diff(fosterEntry, dateEstablished, 'd') + 1;
                    this.set('current.goal.TimeInFosterCare', diff < 0 ? '' : diff);
                    this.set('current.goal.TimeUnitCode', 1);
                }
                this.set('current.goal.DateEstablished', dateEstablished);
            }
        },


        isCaseImported: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (record) {
                if (record === null)
                    return false;
                var data = {};
                if (record) {
                    data = record.getData();
                }
                return Ext.isEmpty(data.CaseID) &&
                    (Ext.isEmpty(data.InitialQAUserID) || data.InitialQAUserID === 0) &&
                    (Ext.isEmpty(data.SecondQAUserID) || data.SecondQAUserID === 0) &&
                    (Ext.isEmpty(data.SecondaryOversightUserID) || data.SecondaryOversightUserID === 0) &&
                    (Ext.isEmpty(data.CtSecondaryOversightUserID) || data.CtSecondaryOversightUserID === 0);
            }
        },
        itemRating: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (record) {

                if (record === null)
                    return false;
                var rating = {}, me = this;
                rating["2"] = me.get('caseReview.Item1IsApplicable') != 1 || !me.get('hasSafetyReportRows');
                rating["3"] = me.get('caseReview.Item2IsApplicable') != 1;
                rating["4"] = false;
                rating["5"] = !me.get('hasPlacementRows');
                rating["6"] = me.get('caseReview.Item5IsApplicable') != 1 || !me.get('hasGoalRows');
                rating["7"] = false;
                rating["8"] = me.get('caseReview.Item7IsApplicable') != 1;
                rating["9"] = me.get('caseReview.Item8IsApplicable') != 1;
                rating["10"] = me.get('caseReview.Item9IsApplicable') != 1;
                rating["11"] = me.get('caseReview.Item10IsApplicable') != 1 || !me.get('hasPlacementRows');
                rating["12"] = me.get('caseReview.Item11IsApplicable') != 1;
                rating["13"] = false;
                rating["14"] = false; //12a
                rating["15"] = me.get('caseReview.IsNeedsServicesApplicableForMother') != 1 && me.get('caseReview.IsNeedsServicesApplicableForFather') != 1; //12b
                rating["16"] = me.get('caseReview.Item12cIsApplicable') != 1; //12c
                rating["17"] = me.get('caseReview.Item13IsApplicable') != 1;
                rating["18"] = false;
                rating["19"] = me.get('caseReview.Item15IsApplicable') != 1;
                rating["20"] = me.get('caseReview.Item16IsApplicable') != 1;
                rating["21"] = me.get('caseReview.Item17IsApplicable') != 1;
                rating["22"] = me.get('caseReview.Item18IsApplicable') != 1 || !me.get('hasMentalHealthRows');

                //console.log('CaseReviewModel.itemRating', rating)
                return rating;
            },
            set: function (data) {
                console.log('itemRating', data)
            }
        },
        unresolvedTab: {
            bind: { bindTo: '{caseReview}', deep: true },
            get: function (data) {
                ///console.log('resolveTab fired');
                var me = this,
                    errors = me.get('error'),
                    isFosterCareCase = me.get('isFosterCareCase'),
                    isHomeServiceCase = me.get('isHomeServiceCase'),
                    map = new Ext.util.HashMap(),
                    tabFieldMap = me.getFieldTabMapList();
                for (var prop in errors) {
                    if (!Ext.isEmpty(errors[prop])) {
                        //if (tabFieldMap.containsKey(prop)) {
                        key = me.getFieldTabMapByItem(tabFieldMap, prop);
                        if (key != null) {
                            if (isHomeServiceCase && tabFieldMap[key].itemCode >= 5 && tabFieldMap[key].itemCode <= 12)
                                continue;
                            //var arr = [], key = tab.get(prop);
                            var arr = [];
                            if (map.containsKey(key)) {
                                arr = map.get(key);
                                arr.push({ key: prop, value: errors[prop] });
                                map.replace(key, arr);
                            }
                            else {
                                arr.push({ key: prop, value: errors[prop] });
                                map.add(key, arr);
                            }
                        }
                    }
                }
                //console.log(map.getArray(false).sort());
                return map;
            }
        }

    },
    stores: {
        caseParticipantStore: {
            model: 'QuickStart.model.casereview.CaseParticipant',
            data: '{caseReview.FaceSheet.CR_CaseParticipant_Collection}',
            listeners:
            {
                datachanged: 'onCaseParticipantDataChanged',
                load: 'onCaseParticipantDataChanged'
            }
        },
        childDemographicStore: {
            model: 'QuickStart.model.casereview.ChildDemographic',
            data: '{caseReview.FaceSheet.CR_ChildDemographic_Collection}',
            listeners:
            {
                datachanged: 'onChildDemographicDataChanged',
                load: 'onCaseParticipantDataChanged'
            }
        },
        safetyReportStore: {
            model: 'QuickStart.model.casereview.SafetyReport',
            data: '{caseReview.Safety.CR_SafetyReport_Collection}',
            listeners:
            {
                datachanged: 'onSafetyReportDataChanged',
                load: 'onSafetyReportDataLoad'
            }
        },
        placementStore: {
            model: 'QuickStart.model.casereview.Placement',
            data: '{caseReview.Permanency.CR_Placement_Collection}',
            listeners:
            {
                datachanged: 'onPlacementDataChanged',
                load: 'onPlacementDataLoad'
            }
        },
        goalStore: {
            model: 'QuickStart.model.casereview.Goal',
            data: '{caseReview.Permanency.CR_Goal_Collection}',
            listeners:
            {
                datachanged: 'onGoalDataChanged',
                load: 'onGoalDataLoad'
            }
        },
        healthNeedStore: {
            model: 'QuickStart.model.casereview.HealthNeed',
            data: '{caseReview.WellBeing.CR_Health_Collection}'
        },
        mentalHealthStore: {
            type: 'chained',
            source: '{healthNeedStore}',
            filters: [{ property: 'HealthNeedCode', value: 2 }]
        },
        physicalDentalHealthStore: {
            type: 'chained',
            source: '{healthNeedStore}',
            filters: [{ property: 'HealthNeedCode', value: 1 }]
        },
        educationStore: {
            model: 'QuickStart.model.casereview.Education',
            data: '{caseReview.WellBeing.CR_Education_Collection}'
        },

        noteStore: {
            model: 'QuickStart.model.casereview.Note',
            sorters:
                [{
                    property: 'NoteID', direction: 'asc'
                }, {
                    property: 'LastModifiedDate', direction: 'asc'
                }],
            data: '{notes}'
        },
        caseNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [{ property: 'Type', value: 'CASE' },
            { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        faceSheetNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 21 },
                { property: 'ItemCode', value: 23 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item1NoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 1 },
                { property: 'ItemCode', value: 2 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item2NoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 2 },
                { property: 'ItemCode', value: 3 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item3NoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 2 },
                { property: 'ItemCode', value: 4 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item4NoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 3 },
                { property: 'ItemCode', value: 5 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item5NoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 3 },
                { property: 'ItemCode', value: 6 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item6NoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 3 },
                { property: 'ItemCode', value: 7 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item7NoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 4 },
                { property: 'ItemCode', value: 8 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item8NoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 4 },
                { property: 'ItemCode', value: 9 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item9NoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 4 },
                { property: 'ItemCode', value: 10 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item10NoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 4 },
                { property: 'ItemCode', value: 11 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item11NoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 4 },
                { property: 'ItemCode', value: 12 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item12NoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 5 },
                { property: 'ItemCode', value: 13 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item12aNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 5 },
                { property: 'ItemCode', value: 14 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item12bNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 5 },
                { property: 'ItemCode', value: 15 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item12cNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 5 },
                { property: 'ItemCode', value: 16 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item13NoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 5 },
                { property: 'ItemCode', value: 17 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item14NoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 5 },
                { property: 'ItemCode', value: 18 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item15NoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 5 },
                { property: 'ItemCode', value: 19 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item16NoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 6 },
                { property: 'ItemCode', value: 20 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item17NoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 7 },
                { property: 'ItemCode', value: 21 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        item18NoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 7 },
                { property: 'ItemCode', value: 22 },
                { property: 'NoteType', value: 2, operator: '!=' }
            ]
        },
        caseInterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [{ property: 'Type', value: 'CASE' },
            { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        interviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        faceSheetInterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 21 },
                { property: 'ItemCode', value: 23 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item1InterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 1 },
                { property: 'ItemCode', value: 2 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item2InterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 2 },
                { property: 'ItemCode', value: 3 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item3InterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 2 },
                { property: 'ItemCode', value: 4 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item4InterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 3 },
                { property: 'ItemCode', value: 5 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item5InterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 3 },
                { property: 'ItemCode', value: 6 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item6InterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 3 },
                { property: 'ItemCode', value: 7 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item7InterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 4 },
                { property: 'ItemCode', value: 8 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item8InterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 4 },
                { property: 'ItemCode', value: 9 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item9InterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 4 },
                { property: 'ItemCode', value: 10 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item10InterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 4 },
                { property: 'ItemCode', value: 11 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item11InterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 4 },
                { property: 'ItemCode', value: 12 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item12InterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 5 },
                { property: 'ItemCode', value: 13 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item12aInterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 5 },
                { property: 'ItemCode', value: 14 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item12bInterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 5 },
                { property: 'ItemCode', value: 15 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item12cInterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 5 },
                { property: 'ItemCode', value: 16 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item13InterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 5 },
                { property: 'ItemCode', value: 17 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item14InterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 5 },
                { property: 'ItemCode', value: 18 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item15InterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 5 },
                { property: 'ItemCode', value: 19 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item16InterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 6 },
                { property: 'ItemCode', value: 20 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item17InterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 7 },
                { property: 'ItemCode', value: 21 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },
        item18InterviewNoteStore: {
            type: 'chained',
            source: '{noteStore}',
            filters: [
                { property: 'OutcomeCode', value: 7 },
                { property: 'ItemCode', value: 22 },
                { property: 'NoteType', value: 2, operator: '=' }
            ]
        },

        users: {
            model: 'QuickStart.model.BaseLookup',
            autoLoad: true,
            filters: [{ property: 'name', value: '' }],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'lookup/GetAllUsers'
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },
        reviewers: {
            type: 'chained',
            source: '{users}',
            filters: [{ property: 'IsReviewer', value: true }]
        },
        qas: {
            type: 'chained',
            source: '{users}',
            filters: [{ property: 'IsQa', value: true }]
        },
        oversights: {
            type: 'chained',
            source: '{users}',
            filters: [{ property: 'IsOversight', value: true }]
        },
        qas2: {
            type: 'chained',
            source: '{users}',
            filters: [{ property: 'IsQa', value: true }]
        },
        ctoversights: {
            type: 'chained',
            source: '{users}',
            filters: [{ property: 'IsOversight', value: true }]
        },

        siteStore: {
            type: 'grouplookups',
            filters: [{ property: 'group', value: 'Site', operator: '=' }]
        },
        caseReviewQaStore: {
            type: 'grouplookups',
            filters: [{ property: 'group', value: 'CaseReviewQA', operator: '=' }]
        },
        caseReviewSecondaryOversightStore: {
            type: 'grouplookups',
            filters: [{ property: 'group', value: 'CaseReviewSecondaryOversight', operator: '=' }]
        },
        ethnicityStore: {
            type: 'grouplookups',
            filters: [{ property: 'group', value: 'Ethnicity', operator: '=' }]
        },
        genderStore: {
            type: 'grouplookups',
            filters: [{ property: 'group', value: 'Gender', operator: '=' }]
        },
        participantRoleStore: {
            type: 'grouplookups',
            filters: [{ property: 'group', value: 'ParticipantRole', operator: '=' }]
        },
        caseEliminationReasonStore: {
            type: 'grouplookups',
            filters: [{ property: 'group', value: 'CaseEliminationReason' }]
        },
        resolvedStore: {
            model: 'QuickStart.model.casereview.Lookup',
            data: [
                { name: "Any", code: 0 },
                { name: "Yes", code: 1 },
                { name: "No", code: 2 }
            ]
        },
        userStore: {
            type: 'grouplookups',
            filters: [{ property: 'group', value: 'CrSecurityUser' }]
            //sorters: {direction: 'ASC', property: 'name'}
        },
        priorityStore: {
            type: 'grouplookups',
            filters: [{ property: 'group', value: 'PriorityLevel' }]
            //sorters: {direction: 'ASC', property: 'name'}
        },
        assessmentTypeStore: {
            type: 'grouplookups',
            filters: [{ property: 'group', value: 'AssessmentType' }]
            //sorters: {direction: 'ASC', property: 'name'}
        },
        perpetratorChildRelationshipStore: {
            type: 'grouplookups',
            filters: [{ property: 'group', value: 'PerpetratorChildRelationship' }]
            //sorters: {direction: 'ASC', property: 'name'}
        },
        dispositionStore: {
            type: 'grouplookups',
            filters: [{ property: 'group', value: 'Disposition' }]
            //sorters: {direction: 'ASC', property: 'name'}
        },
        placementTypeStore: {
            type: 'grouplookups',
            filters: [{ property: 'group', value: 'PlacementType' }]
            //sorters: {direction: 'ASC', property: 'name'}
        },
        placementChangeReasonStore: {
            type: 'grouplookups',
            filters: [{ property: 'group', value: 'PlacementChangeReason' }]
            //sorters: {direction: 'ASC', property: 'name'}
        },
        permanencyGoal1Store: {
            type: 'grouplookups',
            filters: [{ property: 'group', value: 'PermanencyGoal1' }]
            //sorters: {direction: 'ASC', property: 'name'}
        },
        permanencyGoal2Store: {
            type: 'grouplookups',
            filters: [{ property: 'group', value: 'PermanencyGoal2' }]
        },
        timeUnitStore: {
            type: 'grouplookups',
            filters: [{ property: 'group', value: 'TimeUnit' }]
        },
        livingArrangementStore: {
            type: 'grouplookups',
            filters: [{ property: 'group', value: 'LivingArrangement' }]
        },

        itemNameStore: {
            model: 'QuickStart.model.casereview.Lookup',
            data:
                [
                    { name: "Any", code: 0 },
                    { name: "case", code: 1 },
                    { name: "facesheet", code: 23 },
                    { name: "item1", code: 2 },
                    { name: "item2", code: 3 },
                    { name: "item3", code: 4 },
                    { name: "item4", code: 5 },
                    { name: "item5", code: 6 },
                    { name: "item6", code: 7 },
                    { name: "item7", code: 8 },
                    { name: "item8", code: 9 },
                    { name: "item9", code: 10 },
                    { name: "item10", code: 11 },
                    { name: "item11", code: 12 },
                    { name: "item12", code: 13 },
                    { name: "item12A", code: 14 },
                    { name: "item12B", code: 15 },
                    { name: "item12C", code: 16 },
                    { name: "item13", code: 17 },
                    { name: "item14", code: 18 },
                    { name: "item15", code: 19 },
                    { name: "item16", code: 20 },
                    { name: "item17", code: 21 },
                    { name: "item18", code: 22 }
                ]
        },
        overviewStore: {
            model: 'QuickStart.model.Overview',
            groupField: 'Header',
            data: [
                {
                    ItemName: "Item 1",
                    Description: 'items 1',
                    Header: 'Safety Outcome 1',
                    SubHeader: 'Sub Header',
                    Rating: 1,
                    Status: 1
                },
                {
                    ItemName: "Item 2",
                    Description: 'items 2',
                    Header: 'Safety Outcome 2',
                    SubHeader: 'Sub Header',
                    Rating: 1,
                    Status: 1
                }
            ]
        },
        numberTableStore: {
            fields: ['id'], data: []
        },
        numberTablePlacementStore: {
            fields: ['id'], data: []
        }
    },
    getLookupData: function (group, groupId) {
        var store = Ext.getStore('Lookups');
        if (store) {
            var record = store.queryRecordsBy(function (r) {
                return r.get('group') === group && r.get('groupId') === groupId;
            });
            if (record && record.length > 0) {
                return record[0].getData();
            }
        }
        return null;
    },
    getLookupDataValue: function (group, groupId, returnValue) {
        var data = this.getLookupData(group, groupId);
        if (data) {
            return data[returnValue || 'name'] || '';
        }

        return '';
    },
    getReviewerTypeByUserId: function (userId) {
        var rec = this.get('caseReview'), data = null, val, type;
        if (rec) {
            data = rec.getData() || {};
            val = data.CR_Reviewer_Collection.filter(function (item) {
                return item.UserID === userId;
            }).length > 0;
            if (val)
                return "Reviewer";
            if (data.InitialQAUserID === userId)
                return "QA";
            else if (data.SecondQAUserID === userId)
                return "Secondary QA";
            else if (data.SecondaryOversightUserID === userId)
                return "Secondary Oversight";
            else if (data.CtSecondaryOversightUserID === userId)
                return " CT Secondary Oversight";
        }
        return '';
    },
    hasUserInCaseReview: function (userId) {

        var rec = this.get('caseReview'), data = null, val, type;
        if (rec) {

            data = rec.getData() || {};
            val = data.CR_Reviewer_Collection.filter(function (item) {
                return item.UserID === userId;
            }).length > 0;
            return (val || data.InitialQAUserID === userId || data.SecondQAUserID === userId || data.SecondaryOversightUserID === userId || data.CtSecondaryOversightUserID === userId || (data.IRRReviewerID === userId && data.IsIRR === true));
        }
        return false;
    },
    hasUserInCaseReviewer: function (userId) {
        var rec = this.get('caseReview'), data = null, val, type;
        if (rec) {

            data = rec.getData() || {};
            val = data.CR_Reviewer_Collection.filter(function (item) {
                return item.UserID === userId;
            }).length > 0;
            //return (val || data.InitialQAUserID === userId || data.SecondQAUserID === userId || data.SecondaryOversightUserID === userId || data.CtSecondaryOversightUserID === userId || (data.IRRReviewerID === userId && data.IsIRR === true));
            return val;
        }
        return false;
    },
    getOverviewOutComes: function () {
        var outcomes = [
            {
                code: 1, name: 'Outcome 1', items: [],
                desc: 'Children are, first and foremost, protected from abuse and neglect.'
            },
            {
                code: 2, name: 'Outcome 2', items: [],
                desc: 'Children are safely maintained in their homes whenever possible and appropriate.'
            },
            {
                code: 3, name: 'Outcome 1', items: [],
                desc: 'Children have permanency and stability in their living situations.'
            },
            {
                code: 4, name: 'Outcome 2', items: [],
                desc: 'The continuity of family relationships and connections is preserved for children.'
            },
            {
                code: 5, name: 'Outcome 1', items: [],
                desc: 'Families have enhanced capacity to provide for their children\'s needs.'
            },
            {
                code: 6, name: 'Outcome 2', items: [],
                desc: 'Children receive appropriate services to meet their educational needs.'
            },
            {
                code: 7, name: 'Outcome 3', items: [],
                desc: 'Children receive adequate services to meet their physical and mental health needs.'
            },
            {
                code: 21, name: 'Facesheet', items: [], desc: ''
            }
        ];
        return outcomes;
    },
    getOverviewItems: function () {
        var items = [
            {
                code: 2, name: 'Item 1', outcome: 1,
                desc: 'Timeliness of Initiating Investigations of Reports of Child Maltreatment'
            },
            {
                code: 3, name: 'Item 2', outcome: 2,
                desc: 'Services to Family to Protect Child(ren) in the Home and Prevent Removal or Re-Entry Into Foster Care'
            },
            {
                code: 4, name: 'Item 3', outcome: 2, desc: 'Risk and Safety Assessment and Management'
            },
            {
                code: 5, name: 'Item 4', outcome: 3, desc: 'Stability of Foster Care Placement'
            },
            {
                code: 6, name: 'Item 5', outcome: 3, desc: 'Permanency Goal for Child'
            },
            {
                code: 7, name: 'Item 6', outcome: 3,
                desc: 'Achieving Reunification, Guardianship, Adoption, or Other Planned Permanent Living Arrangement'
            },
            {
                code: 8, name: 'Item 7', outcome: 4, desc: 'Placement With Siblings'
            },
            {
                code: 9, name: 'Item 8', outcome: 4, desc: 'Visiting With Parents and Siblings in Foster Care'
            },
            {
                code: 10, name: 'Item 9', outcome: 4, desc: 'Preserving Connections'
            },
            {
                code: 11, name: 'Item 10', outcome: 4, desc: 'Relative Placement'
            },
            {
                code: 12, name: 'Item 11', outcome: 4, desc: 'Relationship of Child in Care With Parents'
            },
            {
                code: 13,
                name: 'Item 12',
                outcome: 5,
                desc: 'Needs and Services of Child, Parents, and Foster Parents'
            },
            {
                code: 14, name: 'Sub-Item 12A', outcome: 5, desc: 'Needs Assessment and Services to Children'
            },
            {
                code: 15, name: 'Sub-Item 12B', outcome: 5, desc: 'Needs Assessment and Services to Parents'
            },
            {
                code: 16, name: 'Sub-Item 12C', outcome: 5, desc: 'Needs Assessment and Services to Foster Parents'
            },
            {
                code: 17, name: 'Item 13', outcome: 5, desc: 'Child and Family Involvement in Case Planning'
            },
            {
                code: 18, name: 'Item 14', outcome: 5, desc: 'Caseworker Visits With Child'
            },
            {
                code: 19, name: 'Item 15', outcome: 5, desc: 'Caseworker Visits With Parents'
            },
            {
                code: 20, name: 'Item 16', outcome: 6, desc: 'Educational Needs of the Child'
            },
            {
                code: 21, name: 'Item 17', outcome: 7, desc: 'Physical Health of the Child'
            },
            {
                code: 22, name: 'Item 18', outcome: 7, desc: 'Mental/Behavioral Health of the Child'
            },
            {
                code: 23, name: '', outcome: 21, desc: ''
            }
        ];
        return items;
    },
    collectionFilter: function (arr, property, value, returnInObject) {
        var results = arr.filter(function (item) {
            return item[property] === value;
        });

        if (returnInObject) {
            return results[0] || {};
        }
        return results;
    },
    getMultiAnswerValue: function (arr, group, codeDescId) {
        var val = undefined;
        if (arr) {
            if (!Ext.isArray(arr)) {
                arr = [arr];
            }
            var data = arr.filter(function (item) {
                return item.GroupName === group && item.CodeDescriptionID === codeDescId;
            });
            if (!Ext.isEmpty(data) && Ext.isArray(data) && data.length > 0) {
                val = data[0].AnswerCode
            }
        }
        return val;
    },

    hasItemParticipant: function (item) {
        return item != null && item.length > 0;
    },
    getGoalTableValue: function () {
        var goalStore = this.getStore('goalStore'),
            rows = [];
        if (goalStore && goalStore.getCount() > 0) {
            rows = Ext.Array.pluck(Ext.Array.pluck(goalStore.getRange(), 'data'), 'GoalCode');
            return rows;
        }
        return null;
    },
    getCurrentGoalTableValue: function () {
        var goalStore = this.getStore('goalStore'),
            rows = [];
        if (goalStore && goalStore.getCount() > 0) {
            var goals = Ext.Array.pluck(goalStore.getRange(), 'data');
            goals = goals.filter(function (g) {
                return g.IsCurrentGoal === 1;
            });
            rows = Ext.Array.pluck(goals, 'GoalCode');
            return rows
        }
        return null;
    },

    hasDuplicateChildReport: function (safetyReports) {
        var duplicate = false;
        if (safetyReports === null)
            return duplicate;
        for (var i = 0; i < safetyReports.length - 1; i++) {
            for (var j = i + 1; j < safetyReports.length; j++) {

                if (safetyReports[i].ChildDemographicID === safetyReports[j].ChildDemographicID &&
                    !Ext.isEmpty(safetyReports[i].ReportDate) &&
                    !Ext.isEmpty(safetyReports[j].ReportDate) &&
                    !Ext.isEmpty(safetyReports[i].SafetyReportAllegationCode) &&
                    !Ext.isEmpty(safetyReports[j].SafetyReportAllegationCode) &&
                    safetyReports[i].ReportDate.toString() === safetyReports[j].ReportDate.toString() &&
                    safetyReports[i].SafetyReportAllegationCode.toString() === safetyReports[j].SafetyReportAllegationCode.toString() &&
                    safetyReports[i].PerpetratorChildRelationshipCode === safetyReports[j].PerpetratorChildRelationshipCode &&
                    safetyReports[i].DispositionCode === safetyReports[j].DispositionCode
                ) {
                    duplicate = true;
                    break;
                }
            }
            if (duplicate)
                break;
        }
        return duplicate;
    },
    isValidDatesInReport: function (safetyReports, date1, date2, check) {
        var valid = true;
        if (safetyReports === null)
            return valid;
        for (var i = 0; i < safetyReports.length; i++) {
            var field1 = safetyReports[i][date1], field2 = safetyReports[i][date2],
                field3 = safetyReports[i][check];

            if (field3 != 1 && !Ext.isEmpty(field1) && !Ext.isEmpty(field2) && field1 < field2) {
                valid = false;
                break;
            }
        }
        return valid;
    },
    hasValueInArray: function (arr, value, prop) {
        if (arr === null)
            return false;
        if (!Ext.isArray(arr))
            arr = arr[arr];

        return arr.filter(function (item) {
            if (prop)
                return item[prop] === value;
            return item === value;
        }).length > 0;
    },
    toArray: function (value) {
        if (Ext.isEmpty(value))
            return [];
        if (!Ext.isArray(value))
            return [value];
        return value;
    },
    checkDuplicateParticipantInMotherFather: function (mothers, fathers) {
        if (!Ext.isEmpty(mothers) && !Ext.isEmpty(fathers)) {
            var exist = mothers.filter(function (val) {
                return fathers.indexOf(val) > -1;
            }).length > 0;
            return exist;
        }
        return false;
    },
    checkDirty: function () {
        var me = this,
            dirty = true,

            caseReviewOriginalState = me.get('caseReviewOriginalState'),
            childDemographicStore = me.getStore('childDemographicStore'),
            caseParticipantStore = me.getStore('caseParticipantStore'),
            safetyReportStore = me.getStore('safetyReportStore'),
            placementStore = me.getStore('placementStore'),
            goalStore = me.getStore('goalStore'),
            healthNeedStore = me.getStore('healthNeedStore'),
            educationStore = me.getStore('educationStore');
        //noteStore = me.getStore('caseNoteStore');

        if (!QuickStart.util.Global.objects.equals(caseReviewOriginalState.FaceSheet.CR_ChildDemographic_Collection, Ext.Array.pluck(childDemographicStore.getRange(), 'data')))
            return true;

        if (!QuickStart.util.Global.objects.equals(caseReviewOriginalState.FaceSheet.CR_CaseParticipant_Collection, Ext.Array.pluck(caseParticipantStore.getRange(), 'data')))
            return true;

        if (!QuickStart.util.Global.objects.equals(caseReviewOriginalState.Safety.CR_SafetyReport_Collection, Ext.Array.pluck(safetyReportStore.getRange(), 'data')))
            return true;

        if (!QuickStart.util.Global.objects.equals(caseReviewOriginalState.Permanency.CR_Placement_Collection, Ext.Array.pluck(placementStore.getRange(), 'data')))
            return true;

        if (!QuickStart.util.Global.objects.equals(caseReviewOriginalState.Permanency.CR_Goal_Collection, Ext.Array.pluck(goalStore.getRange(), 'data')))
            return true;

        if (!QuickStart.util.Global.objects.equals(caseReviewOriginalState.WellBeing.CR_Health_Collection, Ext.Array.pluck(healthNeedStore.getRange(), 'data')))
            return true;

        if (!QuickStart.util.Global.objects.equals(caseReviewOriginalState.WellBeing.CR_Education_Collection, Ext.Array.pluck(educationStore.getRange(), 'data')))
            return true;

        //if (!QuickStart.util.Global.objects.equals(caseReviewOriginalState.CR_CaseNote_Collection, Ext.Array.pluck(noteStore.getRange(), 'data')))
        //    return true;

        return me.isModelDirty(caseReviewOriginalState);
    },
    isModelDirty: function (caseReviewOriginalState) {
        var me = this,
            caseReview = me.get('caseReview'),
            skipPropArray = ['IsComprehensiveAssessementForMotherConducted', 'IsAppropriateServicesForMotherProvided', 'IsComprehensiveAssessementForFatherConducted', 'IsAppropriateServicesForFatherProvided', 'IsOtherPlannedArrangement', 'TS_CR', 'TS_UP', 'IsChildRemovedToEnsureSafety', 'IsFosterOversightMedicationForMentalHealtyAppropriate', 'IsFosterOversightMedicationForPhysicalHealtyAppropriate', 'PermanencyGoal1', 'SiblingVisitationFrequencyCode', 'IsSufficientFrequencyForSiblingVisitation', 'IsSufficentQualityForSiblingVisitation', 'IsNeedsServicesApplicableForMother'];

        if (caseReview.CaseStatusCode >= 6)
            return false;

        for (var prop in caseReview.modified) {
            if (skipPropArray.indexOf(prop) === -1) {
                if (!QuickStart.util.Global.objects.equals(caseReview.data[prop], caseReviewOriginalState[prop])) {
                    console.log('property name :  ' + prop + ' old value : ' + caseReviewOriginalState[prop] + ' , new value : ' + caseReview.data[prop]);
                    return true;
                }
            }
        }
        return false;
    },
    getFieldTabMapList: function () {
        var fieldMap =
        {
            facesheet: { itemCode: 23, fields: ['ChildDemographics', 'CaseParticipants', 'IsCaseOpenReasonOtherAbuseNeglect', 'FirstCaseOpeningDate', 'FosterEntryDate', 'EpisodeDischargeDate', 'CaseClosureDate', 'CaseReasons'] },
            item1: { itemCode: 2, fields: ['Item1IsApplicable', 'SafetyReports', 'DelayReason', 'IsDelayBeyondAgencyControl'] },
            item2: { itemCode: 3, fields: ['Item2IsApplicable', 'IsChildRemovedToEnsureSafety'] },
            item3: { itemCode: 4, fields: ['IsInitialAssesmentForAllChildrenInHome', 'SafetyRelatedIncidents', 'IsSafetyConcernForOtherChildren', 'FosterSafety', 'IsFosterSafetyConcernDuringVisitation', 'FosterPlacementConcern', 'IsFosterSafetyConcernNotAddressed'] },
            item4: { itemCode: 5, fields: ['Placements', 'NumberOfPlacementSettings', 'WereAllPlacementChangesPlanned', 'PlacementApplicableCircumstances', 'IsCurrentPlacementSettingStable'] },
            item5: { itemCode: 6, fields: ['Item5IsApplicable', 'Goals', 'IsGoalSpecified', 'WereAllGoalsInTimelyManner', 'MeetsTerminationOfParentalRights', 'IsAgencyJointTerminationOfParentalRights', 'TerminationExceptions', 'IsExceptionForTermination'] },
            item6: { itemCode: 7, fields: ['TimeInCare', 'IsAgencyConcertedEfforts', 'AgencyConcertedEffortsExplained', 'LivingArrangementCode', 'OtherPlannedArrangementDocumentationDate', 'IsOtherPlannedConcertedEffort'] },
            item7: { itemCode: 8, fields: ['IsValidReasonForSeparation'] },
            item8: { itemCode: 9, fields: ['Item8IsApplicable', 'IsSufficientFrequencyForMotherVisitation', 'IsSufficientFrequencyForFatherVisitation', 'IsSufficientQualityForMotherVisitation', 'IsSufficentQualityForFatherVisitation', 'IsSufficientFrequencyForSiblingVisitation', 'IsSufficentQualityForSiblingVisitation'] },
            item9: { itemCode: 10, fields: ['Item9IsApplicable', 'IsAccordanceWithIndianChildWelfareAct'] },
            item10: { itemCode: 11, fields: ['Item10IsApplicable', 'IsRecentPlacementWithRelative', 'IsPlacementWithRelativeStable', 'IsConcertedEffortToLocateMaternalRelatives', 'IsConcertedEffortToLocatePaternalRelatives'] },
            item11: { itemCode: 12, fields: ['Item11IsApplicable', 'IsConcertedEffortMotherFosterRelationship', 'EffortsToSupportMotherFosterRelationship', 'IsConcertedEffortFatherFosterRelationship', 'EffortsToSupportFatherFosterRelationship'] },
            item12a: { itemCode: 14, fields: ['Item12aIsApplicable'] },
            item12b: { itemCode: 15, fields: ['Item12bIsApplicable', 'IsComprehensiveAssessementForMotherConducted', 'IsComprehensiveAssessementForFatherConducted'] },
            item12c: { itemCode: 16, fields: ['Item12cIsApplicable'] },
            item13: { itemCode: 17, fields: ['Item13IsApplicable', 'IsAgencyConcertedEffortsToInvolveTheChild', 'IsAgencyConcertedEffortsToInvolveTheMother', 'IsAgencyConcertedEffortsToInvolveTheFather'] },
            item14: { itemCode: 18, fields: ['IsResponsiblePartyVisitationFrequencySufficient', 'IsResponsiblePartyVisitationQualitySufficient'] },
            item15: { itemCode: 19, fields: ['Item15IsApplicable', 'ResponsiblePartyVisitationFrequencyWithMotherCode', 'IsResponsiblePartyVisitationFrequencyWithMotherSufficient', 'ResponsiblePartyVisitationFrequencyWithFatherCode', 'IsResponsiblePartyVisitationFrequencyWithFatherSufficient', 'IsResponsiblePartyVisitationQualityWithMotherSufficient', 'IsResponsiblePartyVisitationQualityWithFatherSufficient'] },
            item16: { itemCode: 20, fields: ['Item16IsApplicable'] },
            item17: { itemCode: 21, fields: ['Item17IsApplicable', 'IsAgencyAssessPhysicalHealthNeeds', 'IsAgencyAssessDentalHealthNeeds', 'PhysicalDentalHealthHealths', 'FosterFederalCaseManagamentCriteria'] },
            item18: { itemCode: 22, fields: ['Item18IsApplicable', 'MentalBehavirolHealths'] }
        };
        return fieldMap;
    },
    getFieldTabMapByItem: function (tabFields, item) {
        for (tab in tabFields) {
            if (Ext.Array.contains(tabFields[tab].fields, item))
                return tab;
        }
        return null;
    }
});