/**
 * Created by kkora on 9/22/2017.
 */
Ext.define('QuickStart.view.casereview.overview.Container', {
    extend: 'QuickStart.view.common.BaseCaseContainer',

    xtype: 'overviewcontainer',

    margin: '0 20 20 0',
    requires: [
        'Ext.panel.Panel'
    ],

    routeId: 'overview',
    items: [
        {
            xtype: 'panel',
            title: 'Case Overview',
            margin: 0
        },
        {
            title: 'Face Sheet',
            xtype: 'overviewpanel',
            bind: {data: '{facesheetOverview}'}
        },
        {
            title: 'Section I: Safety',
            xtype: 'overviewpanel',
            bind: {data: '{safetyOverview}'}
        },
        {
            title: 'Section II: Permanency',
            xtype: 'overviewpanel',
            bind: {data: '{permanencyOverview}'}
        },
        {
            title: 'Section III: Child and Family Well-Being',
            xtype: 'overviewpanel',
            bind: {data: '{wellbeingOverview}'}
        }
    ]
});