/**
 * Created by kkora on 2/21/2018.
 */
Ext.define('QuickStart.view.casereview.note.NoteTabContainer', {
    extend: 'Ext.tab.Panel',

    xtype: 'notetabcontainer',
    routeId: 'notetab',
    margin: '0 20 20 0',
    activeTab:0,
    items: [
        {
            title: 'Case QA Notes',
            xtype: 'caseqanotescontainer',
            noteType: 1,
            storeName: 'caseNoteStore'
        }, {
            title: 'Case Related Interview Notes',
            xtype: 'caseqanotescontainer',
            itemId: 'caseInterviewNote',
            noteType: 2,
            storeName: 'caseInterviewNoteStore'
        }
    ],
    listeners: {
        afterrender: 'onNoteTabContainerRender'
    }
});