/**
 * Created by kkora on 10/19/2017.
 */
Ext.define('QuickStart.view.casereview.safety.Outcome2', {
    extend: 'QuickStart.view.common.InstructionPanel',
    xtype: 'safetyoutcome2container',
    routeId: 'safetyoutcome2',
    margin: '0 20 20 0',

    title: 'Outcome 2: Children are safely maintained in their homes whenever possible and appropriate',
    text: QuickStart.util.Resources.instructions.safety.outcome2(),
    defaults: {margin: 10},
    items: [{
        xtype: 'component',
        html: '<p><strong>Item 2:</strong> Services to Family to Protect Child(ren) in the Home and Prevent Removal or Re-Entry Into Foster Care</p>' +
        '<p><strong>Item 3:</strong> Risk and Safety Assessment and Management</p>' +
        '<p>What is the level of outcome achievement that best describes the extent to which this outcome is being or has been achieved, based on the ratings for items 2 and 3?</p>'

    }, {
        xtype: 'displayfield',
        labelWidth: '100%',
        fieldLabel: 'Level of Outcome Achievement',
        bind: '{caseReview.Outcome2.RatingDesc}'
    }, {
        xtype: 'displayfield',
        labelWidth: '100%',
        fieldLabel: 'Outcome Rating Override',
        bind: {
            value: '{caseReview.Outcome2.RatingDesc}',
            hidden: '{caseReview.Outcome2.OverrideRatingDesc==""}'
        }
    }]
});