/**
 * Created by kkora on 9/19/2017.
 */

Ext.define('QuickStart.view.casereview.irr.Window', {
    extend: 'QuickStart.view.common.BaseWindow',
    xtype: 'irrwindow',

    requires: [
        'Ext.form.Panel',
        'Ext.form.field.ComboBox',
        'Ext.toolbar.Fill'
    ],

    width: 600,
    layout: 'fit',
    defaults: {
        defaultFocus: 'textfield:not([value]):focusable:not([disabled])'
    },
    bind: {
        title: "Create IRR Case"
    },
    maximized: false,
    constrain: false,
    items: [
        {
            bodyPadding: '10 10 0 10',
            xtype: 'form',
            defaultType: 'combobox',
            defaults: {
                submitEmptyText: false,
                anchor: '100%',
                labelWidth: 80,
                msgTarget: 'side',
                displayField: 'Name',
                valueField: 'Id',
                forceSelection: true,
                queryMode: 'remote',
                allowBlank: false,
                minChars: 1,
                triggerAction: 'all',
                listeners: {
                    beforequery: function (queryPlan, eOpts) {
                        queryPlan.combo.lastQuery = null;
                    }
                }
            },
            items: [
                {
                    fieldLabel: 'Case Name',
                    bind: { store: '{cases}' },
                    name: 'CaseId',
                    pageSize: 25,
                    tpl: new Ext.create('Ext.XTemplate',
                        '<tpl for=".">',
                        '<div class="x-boundlist-item">',
                        '<div ><strong>{Id} - {Name}</strong></div>',
                        '<div >Type : {Type}</div>',
                        '<div>Status : <span class="status-color-{CaseStatusCode}">{Status}</span></div><hr>',
                        '</div>',
                        '</tpl>'
                    )
                },
                {
                    xtype: 'usertagfield',
                    selectOnFocus :false,
                    multiSelect: false,
                    fieldLabel: 'IRR User',
                    bind: { store: '{users}' },
                    name: 'UserId',
                    queryMode: 'local'                   
                }

            ],
            dockedItems: [
                {
                    xtype: 'toolbar',
                    dock: 'top',
                    ui: 'footer',
                    items: ['->', {
                        text: 'Save',
                        ui: 'soft-green',
                        iconCls: 'x-fa fa-save',
                        formBind: true,
                        handler: 'onCreateIrrCase'

                    }, {
                        text: 'Cancel',
                        ui: 'gray',
                        iconCls: 'x-fa fa-close',
                        handler: function (btn) {
                            btn.up('window').close();
                        }
                    }]
                }]

        }
    ]
});