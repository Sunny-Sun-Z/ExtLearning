/**
 * Created by kkora on 10/12/2017.
 */

Ext.define('QuickStart.view.casereview.items.Item12c', {
    extend: 'Ext.Container',
    xtype: 'item12ccontainer',

    requires: [
        'Ext.form.RadioGroup',
        'Ext.layout.container.Anchor'
    ],

    routeId: 'item12c',
    defaults: {margin: '0 20 20 0'},

    items: [
        {
            title: 'Sub-Item 12C: Needs Assessment and Services to Foster Parents',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.item12c(),
            defaults: {
                margin: 10,
                xtype: 'radiogroup',
                labelAlign: 'top',
                layout: 'hbox',
                items: [{
                    boxLabel: 'Yes',
                    inputValue: 1
                }, {
                    boxLabel: 'No',
                    inputValue: 2
                }]
            },
            layout: 'anchor',
            items: [
                {
                    xtype: 'component',
                    html: '<strong> Sub Item 12C Applicable Cases:</strong><br/>'
                },
                {
                    xtype: 'component',
                    html: '<ul><li>In-home cases are not applicable for an assessment of this sub-item.</li>' +
                    '<li>All foster care cases are applicable for assessment of this sub-item unless, during the entire period under review, the child was in out-of-home care in a residential facility or similar placement, but does not have foster parents.</li>' +
                    '</ul>'
                },
                {
                    xtype: 'component',
                    html: '<strong> Select the appropriate response.</strong> If the response is No, the case will be rated as Not Applicable in the ratings section for this sub item.'

                },
                {
                    xtype: 'yesnoradiogroup',
                    labelAlign: 'left',
                    name: 'Item12cIsApplicable',
                    bind: {
                        disabled: '{!isFosterCareCase}',
                        value: '{item12cIsApplicable}'
                    },
                    labelWidth: 200,
                    fieldLabel: 'Is this case applicable?'
                },
                {
                    xtype: 'narrativefield',
                    bind: '{caseReview.Item12cComments}'
                },
                {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.Item12cIsApplicable==""}',
                        html: '{error.Item12cIsApplicable}'
                    }
                }]
        },
        {
            title: 'Question 12C1',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question12c1(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item12cIsApplicable != 1}'},
            items: [{
                xtype: 'yesnoradiogroup',
                name: 'IsNeedsOfFosterParentsAdequatelyAssessed',
                bind: '{isNeedsOfFosterParentsAdequatelyAssessed}',
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question12C1()
            }, {
                xtype: 'yesnonarrativefield',
                bind: {
                    value: '{caseReview.NeedsOfFosterParentsAdequatelyAssessedExplained}',
                    disabled: '{caseReview.IsNeedsOfFosterParentsAdequatelyAssessed != 2 }'
                }
            }]
        },
        {
            title: 'Question 12C2',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question12c2(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item12cIsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsFosterParentsProvidedAppropriateServices',
                bind: '{isFosterParentsProvidedAppropriateServices}',
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question12C2()
            }, {
                xtype: 'yesnonarrativefield',
                bind: {
                    value: '{caseReview.FosterParentsProvidedAppropriateServicesExplained}',
                    disabled: '{caseReview.IsFosterParentsProvidedAppropriateServices != 2 }'
                }
            }]
        },
        {
            title: 'Sub Item 12C Rating Criteria',
            xtype: 'rating',
            itemId: 'rating12c',
            bind: {
				disabled: '{disabledItem}',
				rating: '{caseReview.Item12c}'
              //  disabled: '{disabledItem||caseReview.Item12cIsApplicable != 1}'
            },
            text: QuickStart.util.Resources.instructions.wellbeing.rating.item12c()
        },
        {
            title: 'Sub Item 12C - QA Notes',
            xtype: 'notepanel',
            itemId: 'item12cNotePanel',
            noteType: 1,
            itemCode: 16,
            outcomeCode: 5,
            storeName: 'item12cNoteStore',
            margin: '0 20 20 0',
            bind: {
                disabled: '{disabledNotes}'
            }
        },
        {
            bind: {
                hidden: '{!allowedInterviewNote}',
                disabled: '{disabledNotes}'
            },
            title: 'Sub Item 12C - Interview Notes',
            xtype: 'notepanel',
            noteType: 2,
            itemCode: 16,
            outcomeCode: 5,
            storeName: 'item12cInterviewNoteStore',
            margin: '0 20 20 0'
        }

    ]

});