/**
 * Created by kkora on 9/22/2017.
 */
Ext.define('QuickStart.view.casereview.wellbeing.Container', {
    extend: 'QuickStart.view.common.BaseCaseContainer',

    xtype: 'wellbeingcontainer',
    routeId: 'wellbeing',

    requires: [
        'QuickStart.util.Resources',
        'QuickStart.view.casereview.items.*'
    ],


    items: [
        // {
        //     title: 'Section III: Child and Family Well-Being',
        //     xtype: 'overviewpanel',
        //     bind: {data: '{wellbeingSectionOverview}'}
        // },
        {xtype: 'permanencyoverviewcontainer', margin: '0 20 20 0'},
        {xtype: 'wellbeingoutcome1container', margin: '0 20 20 0'},

        {title: 'Item 12', xtype: 'item12container'},
        {title: 'Item 12A', xtype: 'item12acontainer'},
        {title: 'Item 12B', xtype: 'item12bcontainer'},
        {title: 'Item 12C', xtype: 'item12ccontainer'},
        {title: 'Item 13', xtype: 'item13container'},
        {title: 'Item 14', xtype: 'item14container'},
        {title: 'Item 15', xtype: 'item15container'},

        {xtype: 'wellbeingoutcome2container', margin: '0 20 20 0'},
        {title: 'Item 16', xtype: 'item16container'},

        {xtype: 'wellbeingoutcome3container', margin: '0 20 20 0'},

        {title: 'Item 17', xtype: 'item17container'},
        {title: 'Item 18', xtype: 'item18container'}

    ]
});