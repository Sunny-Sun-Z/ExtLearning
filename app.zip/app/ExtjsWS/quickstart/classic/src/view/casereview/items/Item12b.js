/**
 * Created by kkora on 10/12/2017.
 */

Ext.define('QuickStart.view.casereview.items.Item12b', {
    extend: 'QuickStart.view.common.BaseItem',
    xtype: 'item12bcontainer',

    requires: [
        'Ext.form.CheckboxGroup',
        'Ext.form.RadioGroup',
        'Ext.layout.container.HBox'
    ],

    routeId: 'item12b',
    items: [
        {
            title: 'Sub-Item 12B: Needs Assessment and Services to Parents',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.item12b(),
            defaults: {
                margin: 10,
                xtype: 'radiogroup',
                labelAlign: 'top',
                layout: 'hbox',
                disabledCls: 'disable-item',
                items: [{
                    boxLabel: 'Yes',
                    inputValue: 1
                }, {
                    boxLabel: 'No',
                    inputValue: 2
                }]
            },
            layout: 'anchor',
            items: [
                {
                    xtype: 'component',
                    html: '<strong> Sub Item 12B Applicable Cases:</strong><br/>'
                },
                {
                    xtype: 'component',
                    html: '<ul><li>Because multiple case participants can be assessed in these questions, consider applicability for all appropriate case participants before determining that the rating should be Not Applicable.</li>' +
                    '<li>Questions in sub-item B for either parent should be answered Not Applicable if any of the following applies to all parents being assessed as Mother or Father in this sub-item (check Yes for any that apply for all parents being assessed as Mother or Father and No for any that do not apply to all parents being assessed as Mother or Father):</li>' +
                    '</ul>'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability68'},
                    bind: {
                        disabled: '{!isFosterCareCase}',
                        value: '{item12bApplicability68}'
                    }, fieldLabel: 'Parental rights remained terminated during the entire period under review'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability69'},
                    bind: {
                        disabled: '{!isFosterCareCase}',
                        value: '{item12bApplicability69}'
                    },
                    fieldLabel: 'Parent’s whereabouts were not known during the entire period under review despite agency efforts to locate the parent'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability70'},
                    bind: {
                        disabled: '{!isFosterCareCase}',
                        value: '{item12bApplicability70}'
                    }, fieldLabel: 'Parent was deceased during the entire period under review'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability71'},
                    bind: {
                        disabled: '{!isFosterCareCase}',
                        value: '{item12bApplicability71}'
                    },
                    fieldLabel: 'During the entire period under review it was documented in the case file that it was not in the child’s best interests to involve the parent in case planning'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability72'},
                    bind: {
                        disabled: '{!isFosterCareCase}',
                        value: '{item12bApplicability72}'
                    },
                    fieldLabel: 'During the entire period under review the parent has indicated he/she does not want to be involved in the child’s life and this was documented in the case file'
                },
                {
                    xtype: 'component',
                    html: '<strong> Select the appropriate response.</strong> If the response is No, the case will be rated as Not Applicable in the ratings section for this sub item.'

                }, {
                    xtype: 'yesnoradiogroup',
                    labelAlign: 'left',
                    name: 'IsNeedsServicesApplicableForMother',
                  	bind: {
						disabled: '{!hasMotherAndOtherParticipant}',
						value: '{isNeedsServicesApplicableForMother}'
					},
                    labelWidth: 250,
                    fieldLabel: 'Is sub-item 12B applicable for Mother?',
					listeners: {
						change: 'onItem12bMotherApplicabilityChanged'
					}
                }, {
                    xtype: 'yesnoradiogroup',
                    labelAlign: 'left',
                    name: 'IsNeedsServicesApplicableForFather',
                    bind: {
						disabled: '{!hasFatherAndOtherParticipant}',
						value: '{isNeedsServicesApplicableForFather}'
					},
                    labelWidth: 250,
                    fieldLabel: 'Is sub-item 12B applicable for Father?',
					listeners: {
						change: 'onItem12bFatherApplicabilityChanged'
					}
                }, {
                    xtype: 'component',
                    bind: {hidden: '{caseReview.IsNeedsServicesApplicableForMother != 1 && caseReview.IsNeedsServicesApplicableForFather != 1}'},
                    html: 'Indicate the case participants who are included in this item as Mother and Father'
                },
                {
                    xtype: 'fieldcontainer',
                    labelAlign: 'top',
                    labelSeparator: '',
                    layout: 'hbox',
                    defaults: {
                        xtype: 'checkboxgroup',
                        disabledCls: 'disable-item',
                        flex: 1,
                        columns: 1,
                        labelWidth: 75,
                        vertical: true,
                        items: [{}],
                        listeners: {
                            change: 'onItemParticipantChanged'
                        }
                    },
                    items: [{
                        defaults: {name: 'Item12bParticipantMother'},
                        fieldLabel: 'Mother',
                        bind: {hidden: '{!hasMotherAndOtherParticipant || caseReview.IsNeedsServicesApplicableForMother != 1 }'},
                        name: 'Item12bParticipantMother',
                        itemId: 'item12bParticipantMother'

                    }, {
                        fieldLabel: 'Mother',
						xtype: 'displayfield',
						value: 'There are no case participants in Face Sheet table G2 that can be assessed as Mother',
						bind: { hidden: '{hasMotherAndOtherParticipant || caseReview.IsNeedsServicesApplicableForMother != 1 }' }
					}, {
						defaults: {name: 'Item12bParticipantFather'},
						bind: {hidden: '{!hasFatherAndOtherParticipant || caseReview.IsNeedsServicesApplicableForFather != 1}'},
						fieldLabel: 'Father',
						name: 'Item12bParticipantFather',
						itemId: 'item12bParticipantFather'
					}, {
						fieldLabel: 'Father',
						xtype: 'displayfield',
						value: 'There are no case participants in Face Sheet table G2 that can be assessed as Father',
						bind: { hidden: '{hasFatherAndOtherParticipant || caseReview.IsNeedsServicesApplicableForFather != 1}' }
					}]
                }, {
                    xtype: 'narrativefield',
                    bind: '{caseReview.Item12bComments}'
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.Item12bIsApplicable==""}',
                        html: '{error.Item12bIsApplicable}'
                    }
                }]
        },
        {
            title: 'Question 12B1',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question12b1(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.IsNeedsServicesApplicableForMother != 1 }'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsComprehensiveAssessementForMotherConducted',
                bind: {
                    disabled: '{item12bApplicabilityNoMotherParticipant}',
                    value: '{isComprehensiveAssessementForMotherConducted}'
                }, fieldLabel: QuickStart.util.Resources.questions.wellbeing.question12B1()
            }, {
                xtype: 'yesnonarrativefield',
                bind: {
                    value: '{caseReview.ComprehensiveAssessementForMotherExplained}',
                    disabled: '{caseReview.IsComprehensiveAssessementForMotherConducted != 2}'
                }
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsComprehensiveAssessementForMotherConducted==""}',
                    html: '{error.IsComprehensiveAssessementForMotherConducted}'
                }
            }]
        },
        {
            title: 'Question 12B3',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question12b3(),
            defaults: { margin: 10 },
            layout: 'anchor',
            bind: { hidden: '{caseReview.IsNeedsServicesApplicableForMother != 1 }' },
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsAppropriateServicesForMotherProvided',
                bind: {
                    disabled: '{item12bApplicabilityNoMotherParticipant}',
                    value: '{isAppropriateServicesForMotherProvided}'
                }, fieldLabel: QuickStart.util.Resources.questions.wellbeing.question12B3()
            }, {
                xtype: 'yesnonarrativefield',
                bind: {
                    value: '{caseReview.AppropriateServicesForMotherExplained}',
                    disabled: '{caseReview.IsAppropriateServicesForMotherProvided != 2}'
                }
            }]
        },
        {
            title: 'Question 12B2',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question12b2(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.IsNeedsServicesApplicableForFather != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsComprehensiveAssessementForFatherConducted',
                bind: {
                    disabled: '{item12bApplicabilityNoFatherParticipant}',
                    value: '{isComprehensiveAssessementForFatherConducted}'
                }, fieldLabel: QuickStart.util.Resources.questions.wellbeing.question12B2()
            }, {
                xtype: 'yesnonarrativefield',
                bind: {
                    value: '{caseReview.ComprehensiveAssessementforFatherConductedExplained}',
                    disabled: '{caseReview.IsComprehensiveAssessementForFatherConducted != 2}'
                }
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsComprehensiveAssessementForFatherConducted==""}',
                    html: '{error.IsComprehensiveAssessementForFatherConducted}'
                }
            }]
        },
       
        {
            title: 'Question 12B4',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question12b4(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.IsNeedsServicesApplicableForFather!= 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsAppropriateServicesForFatherProvided',
                bind: {
                    disabled: '{item12bApplicabilityNoFatherParticipant}',
                    value: '{isAppropriateServicesForFatherProvided}'
                }, fieldLabel: QuickStart.util.Resources.questions.wellbeing.question12B4()
            }, {
                xtype: 'yesnonarrativefield',
                bind: {
                    value: '{caseReview.AppropriateServicesForFatherExplained}',
                    disabled: '{caseReview.IsAppropriateServicesForFatherProvided != 2}'
                }
            }]
        },
        {
            title: 'Sub Item 12B Rating Criteria',
            xtype: 'rating',
            itemId: 'rating12b',
            bind: {
                rating: '{caseReview.Item12b}',
				disabled: '{disabledItem}'
				//disabled: '{disabledItem|| (caseReview.IsNeedsServicesApplicableForMother != 1 && caseReview.IsNeedsServicesApplicableForFather != 1)}',
            },
            text: QuickStart.util.Resources.instructions.wellbeing.rating.item12b()
        },
        {
            title: 'Sub Item 12B - QA Notes',
            xtype: 'notepanel',
            itemId: 'item12bNotePanel',
            noteType: 1,
            itemCode: 15,
            outcomeCode: 5,
            storeName: 'item12bNoteStore',
            margin: '0 20 20 0',
            bind: {
                disabled: '{disabledNotes}'
            }
        },
        {
            title: 'Sub Item 12B - Interview Notes',
            bind: {
                hidden: '{!allowedInterviewNote}',
                disabled: '{disabledNotes}'
            },
            xtype: 'notepanel',
            noteType: 2,
            itemCode: 15,
            outcomeCode: 5,
            storeName: 'item12bInterviewNoteStore',
            margin: '0 20 20 0'
        }

    ],
    listeners: {
        afterrender: 'onAfterRenderItem12b'
    }
});