/**
 * Created by kkora on 2/25/2018.
 */
Ext.define('QuickStart.view.casereview.irr.container.Compare', {
    extend: 'Ext.panel.Panel',
    xtype: 'casecomparecontainer',
    title: 'Case Compare View',
    margin: 20,
   // scrollable: 'y',
    scrollable: true,

    data: {
        Case1HeaderTitle:'',
        Case2HeaderTitle:'',
        Title: '',
        TitleDesc: '',
        CaseReview: {},
        FaceSheet: {},
        Item1: {},
        Item2: {},
        Item3: {},
        Item4: {},
        Item5: {},
        Item6: {},
        Item7: {},
        Item8: {},
        Item9: {},
        Item10: {},
        Item11: {},
        Item12: {},
        Item12A: {},
        Item12B: {},
        Item12C: {},
        Item13: {},
        Item14: {},
        Item15: {},
        Item16: {},
        Item17: {},
        Item18: {},
        Outcomes: {},
        CustomProperties:{},
        Irr:{
            CaseReview: {},
            FaceSheet: {},
            Item1: {
                SafetyReports: []
            },
            Item2: {},
            Item3: {},
            Item4: {},
            Item5: {},
            Item6: {},
            Item7: {},
            Item8: {},
            Item9: {},
            Item10: {},
            Item11: {},
            Item12: {},
            Item12A: {},
            Item12B: {},
            Item12C: {},
            Item13: {},
            Item14: {},
            Item15: {},
            Item16: {},
            Item17: {},
            Item18: {},
            Outcomes: {},
            CustomProperties:{}
        }
    },
    tpl: new Ext.XTemplate(
        '<div class="casepreview">',
        '<tpl if="this.hasValue(Title)">',
        '<div class="title"> {Title} </div>',
        '</tpl>',
        '<tpl if="this.hasValue(TitleDesc)">',
        '<div class="desc"> {TitleDesc} </div>',
        '</tpl>',
        '<table cellpadding="0"cellspacing="0" class="table">',
        '<tr><th></th> <th></th> <th></th> <th></th></tr>',
        '<tr><td class="w5 head"></td><td class="head"></td><td class="head">{Case1HeaderTitle:this.title1}</td><td class="head">{Case2HeaderTitle:this.title2}</td></tr>',

        '<tr><td colspan="4" class="section">Face Sheet</td></tr>',

        '<tr>',
        '<td class="w5"><label>A.</label> </td><td class="w45"><label>Name of state and county (or local area):</label> </td><td class="w25">{CustomProperties.SiteName}</td><td class="w25">{Irr.CustomProperties.SiteName}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B.</label> </td><td class="w45"><label>Case name:</label></td><td class="w25">{CaseReview.CaseName}</td><td class="w25">{Irr.CaseReview.CaseName}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>C.</label> </td><td class="w45"> <label>Period under review begins on:</label></td><td class="w25">{CaseReview.ReviewStartDate:this.getDate}</td><td class="w25">{CaseReview.ReviewStartDate:this.getDate}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>D.</label> </td><td class="w75" colspan="4"><label>Case Participants</label></td>',
        '</tr>',

        '<tr>',
        '<td></td>',
        '<td class="w45"><label> Reviewer(s)</label></td>',
        '<td class="w25">{CustomProperties.ReviewerNames}</td>',
        '<td class="w25">{Irr.CustomProperties.ReviewerNames}</td>',
        '</tr>',

        '<tr>',
        '<td></td>',
        '<td class="w45"><label> Initial QA Staff</label></td>',
        '<td class="w25">{CustomProperties.InitialQAUserName}</td>',
        '<td class="w25">{Irr.CustomProperties.InitialQAUserName}</td>',
        '</tr>',

        '<tr>',
        '<td></td>',
        '<td class="w45"><label> Second Level QA Staff</label></td>',
        '<td class="w25">{CustomProperties.SecondQAUserName}</td>',
        '<td class="w25">{Irr.CustomProperties.SecondQAUserName}</td>',
        '</tr>',

        '<tr>',
        '<td></td>',
        '<td class="w45"><label> Secondary Oversight Staff</label></td>',
        '<td class="w25">{CustomProperties.SecondaryOversightUserName}</td>',
        '<td class="w25">{Irr.CustomProperties.SecondaryOversightUserName}</td>',
        '</tr>',

        '<tr>',
        '<td></td>',
        '<td class="w45"><label>CT Secondary Oversight Staff</label></td>',
        '<td class="w25">{CustomProperties.CtSecondaryOversightUserName}</td>',
        '<td class="w25">{Irr.CustomProperties.CtSecondaryOversightUserName}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>E.</label></td><td class="w45"><label>Date case review was completed:</label></td><td class="w25">{CaseReview.ReviewCompleted:this.getDate}</td><td class="w25">{Irr.CaseReview.ReviewCompleted:this.getDate}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>F.</label> </td><td class="w45"><label>What is the type of case reviewed:</label></td><td class="w25">{CustomProperties.ReviewSubType}</td><td class="w25">{Irr.CustomProperties.ReviewSubType}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>G1.</label> </td><td class="w75"colspan="4"><label>Child Table</label></td>',
        '</tr>',

        '<tr>',
        '<td colspan="2">',
            '<table cellpadding="0"cellspacing="0" class="child-table">',
            '<tr><th>Target Child</th><th>Child Name</th><th>Race</th><th>Ethnicity</th><th>DOB</th><th>Age</th><th>Gender</th><th>Interviewed</th></tr>',
            '<tpl for="FaceSheet.ChildDemographics">',
            '<tr><td class="center-bold">{IsTargetChild:this.yesNo}</td><td>{Name}</td><td>{Races:this.races}</td><td>{EthnicityCode:this.ethnicity}</td><td>{DateOfBirth:this.getDate}</td><td>{Age}</td><td class="center-bold">{GenderCode:this.gender}</td><td class="center-bold">{IsInterviewed:this.yesNo}</td></tr>',
            '</tpl>',
            '</table>',
        '</td>',

        '<td colspan="2">',
            '<table cellpadding="0"cellspacing="0"class="child-table" >',
            '<tr><th>Target Child</th><th>Child Name</th><th>Race</th><th>Ethnicity</th><th>DOB</th><th>Age</th><th>Gender</th><th>Interviewed</th></tr>',
            '<tpl for="Irr.FaceSheet.ChildDemographics">',
            '<tr><td class="center-bold">{IsTargetChild:this.yesNo}</td><td>{Name}</td><td>{Races:this.races}</td><td>{EthnicityCode:this.ethnicity}</td><td>{DateOfBirth:this.getDate}</td><td>{Age}</td><td class="center-bold">{GenderCode:this.gender}</td><td class="center-bold">{IsInterviewed:this.yesNo}</td></tr>',
            '</tpl>',
            '</table>',
        '</td>',
        '</tr>',

        '<tr><td class="w5"><label>G2.</label></td><td colspan="3"><label>Participant Table</label></td></tr>',
        '<tr>',
        '<td colspan="2">',
            '<table cellpadding="0"cellspacing="0"class="child-table">',
            '<tr><th>Participant Name</th><th>Participant Role</th><th>Relationship To Child</th><th>Interviewed</th></tr>',
            '<tpl for="FaceSheet.CaseParticipants">',
            '<tr><td>{Name}</td><td>{RoleCode:this.participantRole}</td><td>{RelationshipToChild}</td><td class="center-bold">{IsInterviewed:this.yesNo}</td></tr>',
            '</tpl>',
            '</table>',
        '</td>',
        '<td colspan="2">',
            '<table cellpadding="0"cellspacing="0"class="child-table">',
            '<tr><th>Participant Name</th><th>Participant Role</th><th>Relationship To Child</th><th>Interviewed</th></tr>',
            '<tpl for="Irr.FaceSheet.CaseParticipants">',
            '<tr><td>{Name}</td><td>{RoleCode:this.participantRole}</td><td>{RelationshipToChild}</td><td class="center-bold">{IsInterviewed:this.yesNo}</td></tr>',
            '</tpl>',
            '</table>',
        '</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>H.</label></td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.facesheet.questionH(true) + '</label></td>',
        '<td class="w25">{FaceSheet.IsCaseOpenReasonOtherAbuseNeglect:this.yesNo}</td>',
        '<td class="w25">{Irr.FaceSheet.IsCaseOpenReasonOtherAbuseNeglect:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>I.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.facesheet.questionI(true) + '</label></td>',
        '<td class="w25">{FaceSheet.FirstCaseOpeningDate:this.getDate}</td>',
        '<td class="w25">{Irr.FaceSheet.FirstCaseOpeningDate:this.getDate}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>J.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.facesheet.questionJ(true) + '</label></td>',
        '<td class="w25">{QuestionJ}</td>',
        '<td class="w25">{Irr.QuestionJ}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>K.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.facesheet.questionK(true) + '</label></td>',
        '<td class="w25">{QuestionK}</td>',
        '<td class="w25">{Irr.QuestionK}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>L.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.facesheet.questionL(true) + '</label></td>',
        '<td class="w25">{QuestionL}</td>',
        '<td class="w25">{Irr.QuestionL}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>M.</label> </td>',
        '<td class="w45"><label>M. Why was/were the case(s) opened for services?</label></td>',
        '<td class="w25">{FaceSheet.CaseReasons:this.caseReasons}</td>',
        '<td class="w25">{Irr.FaceSheet.CaseReasons:this.caseReasons}</td>',
        '</tr>',
        '</table>',
        '<br/>',

        // /************************************************ Section I: Safety **************************************************************************/
        //
        // /************************************************ ITEM 1 **************************************************************************/
        '<table cellpadding="0"cellspacing="0" class="table">',
        '<tr><th></th> <th></th> <th></th> <th></th></tr>',

        '<tr><td colspan="4"class="section">Section I: Safety</td></tr>',
        '<tr><td colspan="4"class="outcome">Safety Outcome 1: Children are, first and foremost, protected from abuse and neglect.</td></tr>',
        '<tr><td colspan="4"class="item">Item 1: Timeliness of Initiating Investigations of Reports of Child Maltreatment</td></tr>',

        '<tr><td colspan="2"><label>Is this case applicable?</label></td><td class="w25">{Item1.IsApplicable:this.yesNo}</td><td class="w25">{Irr.Item1.IsApplicable:this.yesNo}</td></tr>',
        '<tr><td colspan="2"><label>Optional Comments: </label></td><td class="w25">{Item1.Comments}</td><td class="w25">{Irr.Item1.Comments}</td> </tr>',


       '<tr><td class="w5"><label>A1.</label></td><td colspan="3"><label>Reports Table</label></td></tr>',

        '<tr>',
        '<td colspan="2">',
        '<tpl if="this.isApplicable(Item1.IsApplicable)">',
        '<table cellpadding="0"cellspacing="0"class="child-table">',
        '<tr><th>Report Date</th><th>Child Name</th><th>Allegation</th><th>Priority Level (if applicable)</th><th>Assessment or Investigation</th><th>Date Assigned for an Investigation or Assessment</th><th>Date Investigation or Assessment Initiated</th><th>Date of Face-to-Face Contact With Child</th><th>Relationship of Alleged Perpetrator to Child</th><th>Disposition</th></tr>',
        '<tpl for="Item1.SafetyReports">',
        '<tr><td>{ReportDate:this.getDate}</td><td>{ChildName}</td><td>{Allegations:this.caseReasons}{AllegationOther:this.other}</td><td>{PriorityLevel:this.priority}</td><td>{AssessmentCode:this.assessmentType}</td><td>{DateAssessmentAssignedText}</td>',
        '<td>{DateAssessmentInitiatedText}</td><td>{DateFaceToFaceContactText}</td><td>{PerpetratorChildRelationshipCode:this.perpetratorChildRelationship}{PerpetratorChildRelationshipOther:this.other}</td><td>{DispositionCode:this.disposition}</td></tr>',
        '</tpl>',
        '</table>',
        '</tpl>',
        '</td>',

        '<td colspan="2">',
        '<tpl if="this.isApplicable(Irr.Item1.IsApplicable)">',
        '<table cellpadding="0"cellspacing="0"class="child-table">',
        '<tr><th>Report Date</th><th>Child Name</th><th>Allegation</th><th>Priority Level (if applicable)</th><th>Assessment or Investigation</th><th>Date Assigned for an Investigation or Assessment</th><th>Date Investigation or Assessment Initiated</th><th>Date of Face-to-Face Contact With Child</th><th>Relationship of Alleged Perpetrator to Child</th><th>Disposition</th></tr>',
        '<tpl for="Irr.Item1.SafetyReports">',
        '<tr><td>{ReportDate:this.getDate}</td><td>{ChildName}</td><td>{Allegations:this.caseReasons}{AllegationOther:this.other}</td><td>{PriorityLevel:this.priority}</td><td>{AssessmentCode:this.assessmentType}</td><td>{DateAssessmentAssignedText}</td>',
        '<td>{DateAssessmentInitiatedText}</td><td>{DateFaceToFaceContactText}</td><td>{PerpetratorChildRelationshipCode:this.perpetratorChildRelationship}{PerpetratorChildRelationshipOther:this.other}</td><td>{DispositionCode:this.disposition}</td></tr>',
        '</tpl>',
        '</table>',
        '</tpl>',
        '</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>A.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.safety.question1A(true) + '</label></td>',
        '<td class="w25">{Item1.ReportsNotInAccordance}</td>',
        '<td class="w25">{Irr.Item1.ReportsNotInAccordance}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.safety.question1B(true) + '</label></td>',
        '<td class="w25">{Item1.FaceToFaceReportsNotInAccordance}</td>',
        '<td class="w25">{Irr.Item1.FaceToFaceReportsNotInAccordance}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Explain the reason for any delays related to reports identified in A and B in the narrative field below.</label></td>',
        '<td class="w25">{Item1.DelayReason}</td>',
        '<td class="w25">{Irr.Item1.DelayReason}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>C.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.safety.question1C(true) + '</label></td>',
        '<td class="w25">{Item1.IsDelayBeyondAgencyControl:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item1.IsDelayBeyondAgencyControl:this.yesNoNa}</td>',
        '</tr>',


        '<tr class="item-rating"><td colspan="2">Item 1 Rating: </td><td><span> {Item1.ItemRatingCode:this.getRatingDesc}</span> </td><td><span> {Irr.Item1.ItemRatingCode:this.getRatingDesc}</span> </td></tr>',
        '<tr><td colspan="2"><label>Additional Comments: </label></td><td>{Item1.RatingComments}</td><td>{Irr.Item1.RatingComments}</td></tr>',
        '<tr class="outcome-rating"><td colspan="2" >Safety Outcome 1 Rating: </td><td >{Outcome1RatingCode:this.getOutcomeRatingDesc}</td><td >{Irr.Outcome1RatingCode:this.getOutcomeRatingDesc}</td></tr>',
        '<tr><td colspan="4"></td></tr>',

        // /************************************************ Section II: Safety **************************************************************************/
        //
        // /************************************************ ITEM 2 **************************************************************************/

        '<tr><td colspan="4"class="outcome">Safety Outcome 2: Children are safely maintained in their homes whenever possible and appropriate.</td></tr>',
        '<tr><td colspan="4"class="item">Item 2: Services to Family to Protect Child(ren) in the Home and Prevent Removal or Re-Entry Into Foster Care</td></tr>',
        '<tr><td colspan="4"><label>Item 2 Applicable Cases:</label></td></tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td ><label>It is an in-home services case and the reviewer determines that there are concerns regarding the safety of at least one child in the family during the period under review.</label></td>',
        '<td>{Item2.Applicability51:this.yesNo}</td>',
        '<td>{Irr.Item2.Applicability51:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td><label>It is an in-home services case and services were provided for children at risk of foster care placement to remain safely in their homes.</label></td>',
        '<td>{Item2.Applicability52:this.yesNo}</td>',
        '<td>{Irr.Item2.Applicability52:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td><label>It is a foster care case and the child entered foster care during the period under review due to safety concerns.</label></td>',
        '<td>{Item2.Applicability53:this.yesNo}</td>',
        '<td>{Irr.Item2.Applicability53:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td><label>It is a foster care case and the child was reunified during the period under review or was returned home on a trial basis, and the reviewer determines that there are concerns regarding the safety of that child in the home.</label></td>',
        '<td>{Item2.Applicability54:this.yesNo}</td>',
        '<td>{Irr.Item2.Applicability54:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td><label>It is a foster care case, and although the target child entered foster care before the period under review and remained in care for the entire period under review, there are other children in the home and the reviewer determines that there are concerns regarding the safety of those children during the period under review.</label></td>',
        '<td>{Item2.Applicability55:this.yesNo}</td>',
        '<td>{Irr.Item2.Applicability55:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td><label>Only a safety plan was needed to ensure the child(ren)’s safety and no safety-related services were necessary based on the circumstances of the case. (In this situation, item 2 would be Not Applicable and the safety plan would be assessed in item 3.)</label></td>',
        '<td>{Item2.Applicability56:this.yesNo}</td>',
        '<td>{Irr.Item2.Applicability56:this.yesNo}</td>',
        '</tr>',

        '<tr><td colspan="2"><label>Is this case applicable?</label></td><td class="w25">{Item2.IsApplicable:this.yesNo}</td><td class="w25">{Irr.Item2.IsApplicable:this.yesNo}</td></tr>',
        '<tr><td colspan="2"><label>Optional Comments: </label></td><td>{Item2.Comments}</td><td>{Irr.Item2.Comments}</td></tr>',

        '<tr>',
        '<td class="w5"><label>A.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.safety.question2A(true) + '</label></td>',
        '<td class="w25"> <tpl if="this.isApplicable(Item2.IsApplicable)"> {Item2.IsEffortToPreventReEntry:this.yesNoNa}</tpl></td>',
        '<td class="w25"> <tpl if="this.isApplicable(Irr.Item2.IsApplicable)"> {Irr.Item2.IsEffortToPreventReEntry:this.yesNoNa}</tpl></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25"> <tpl if="this.isApplicable(Item2.IsApplicable)"> {Item2.EffortToPreventReEntryExplained:this.yesNoNa}</tpl></td>',
        '<td class="w25"> <tpl if="this.isApplicable(Irr.Item2.IsApplicable)"> {Irr.Item2.EffortToPreventReEntryExplained:this.yesNoNa}</tpl></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.safety.question2B(true) + '</label></td>',
       '<td class="w25"> <tpl if="this.isApplicable(Item2.IsApplicable)"> {Item2.IsChildRemovedToEnsureSafety:this.yesNoNa}</tpl></td>',
        '<td class="w25"> <tpl if="this.isApplicable(Irr.Item2.IsApplicable)"> {Irr.Item2.IsChildRemovedToEnsureSafety:this.yesNoNa}</tpl></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25"> <tpl if="this.isApplicable(Item2.IsApplicable)"> {Item2.ChildRemovedToEnsureSafetyExplained:this.yesNoNa}</tpl></td>',
        '<td class="w25"> <tpl if="this.isApplicable(Irr.Item2.IsApplicable)"> {Irr.Item2.ChildRemovedToEnsureSafetyExplained:this.yesNoNa}</tpl></td>',
        '</tr>',

        '<tr class="item-rating"><td colspan="2">Item 2 Rating: </td><td><span>{Item2.ItemRatingCode:this.getRatingDesc}</span></td><td><span>{Irr.Item2.ItemRatingCode:this.getRatingDesc}</span></td></tr>',
        '<tr><td colspan="2"><label>Additional Comments: </label></td><td>{Item2.RatingComments}</td><td>{Irr.Item2.RatingComments}</td></tr>',

        // /************************************************ ITEM 3 **************************************************************************/

        '<tr><td colspan="4"class="item">Item 3: Risk and Safety Assessment and Management</td></tr>',
        '<tr><td colspan="4"><label>All cases are applicable for an assessment of this item.</label></td></tr>',

        '<tr>',
        '<td class="w5"><label>A1.</label> </td>',
        '<td colspan="3"><label>Did any of the following concerns exist during the period under review?</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>There were maltreatment allegations about the family but they were never formally reported or formally investigated/assessed.</label></td>',
        '<td class="w25">{Item3.IsFamilyMaltreatmentAllegations:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item3.IsFamilyMaltreatmentAllegations:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>There were maltreatment allegations that were not substantiated despite evidence that would support substantiation.</label></td>',
        '<td class="w25">{Item3.IsMaltreatmentNotSubstantiated:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item3.IsMaltreatmentNotSubstantiated:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>A.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.safety.question3A(true) + '</label></td>',
        '<td class="w25">{Item3.IsInitialAssesmentForAllChildrenInHome:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item3.IsInitialAssesmentForAllChildrenInHome:this.yesNoNa}</td>',
        '</tr>',

        '<tr><td class="w5"></td><td><label>If No, explain any concerns in the narrative field below.</label></td><td>{Item3.InitialAssesmentForAllChildrenInHomeExplained}</td><td>{Irr.Item3.InitialAssesmentForAllChildrenInHomeExplained}</td></tr>',

        '<tr>',
        '<td class="w5"><label>B.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.safety.question3B(true) + '</label></td>',
        '<td class="w25">{Item3.IsOngoingAssesementForAllChildrenInHome:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item3.IsOngoingAssesementForAllChildrenInHome:this.yesNoNa}</td>',
        '</tr>',

        '<tr><td class="w5"></td><td><label>If No, explain any concerns in the narrative field below.</label></td><td>{Item3.OngoingAssessmentForAllChildrenInHomeExplained}</td><td>{Irr.Item3.OngoingAssessmentForAllChildrenInHomeExplained}</td></tr>',

        '<tr>',
        '<td class="w5"><label>C.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.safety.question3C(true) + '</label></td>',
        '<td class="w25">{Item3.IsSafetyPlanDevelopedAndMonitored:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item3.IsSafetyPlanDevelopedAndMonitored:this.yesNoNa}</td>',
        '</tr>',

        '<tr><td class="w5"></td><td><label>If No, explain any concerns in the narrative field below.</label></td><td>{Item3.SafetyPlanDevelopedAndMonitoredExplained}</td><td>{Irr.Item3.SafetyPlanDevelopedAndMonitoredExplained}</td></tr>',


        '<tr>',
        '<td class="w5"><label>D1.</label> </td>',
        '<td colspan="3"><label>' + QuickStart.util.Resources.questions.safety.question3D1(true) + '</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td><td class="w45"><label>NA (no safety issues were present during the period under review).</label></td><td class="w25"><label>{SafetyRelatedIncident86}</label></td><td class="w25"><label>{Irr.SafetyRelatedIncident86}</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>No safety-related incidents occurred that were not adequately addressed by the agency.</label></td>',
        '<td class="w25"><label>{SafetyRelatedIncident87}</label></td>',
        '<td class="w25"><label>{Irr.SafetyRelatedIncident87}</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Recurring maltreatment: There was at least one substantiated or indicated maltreatment report on any child in the family during the period under review AND there was another substantiated report within a 6-month period before or after that report that involved the same or similar circumstances. In determining the similarity of the circumstances, consider the perpetrator of the maltreatment and other individuals involved in the incident.</label></td>',
        '<td class="w25"><label>{SafetyRelatedIncident88}</label></td>',
        '<td class="w25"><label>{Irr.SafetyRelatedIncident88}</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Recurring safety concerns: There was at least one maltreatment report involving any child in the family during the period under review that was handled by an alternative response and resulted in opening the case for services to address safety concerns (this decision may have been made by the agency or by a private provider under contract with the agency) AND there was at least one additional maltreatment report within a 6-month period before or after that report that was handled by an alternative response and resulted in a decision to open the case for services to address the same or similar safety concerns (the case may have been opened for services by the agency or by a private provider under contract with the agency). In determining the similarity of the concerns, consider the perpetrator of the maltreatment, other individuals involved in the incident, and the type of safety issues that existed.</label></td>',
        '<td class="w25"><label>{SafetyRelatedIncident89}</label></td>',
        '<td class="w25"><label>{Irr.SafetyRelatedIncident89}</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>The case was closed while significant safety concerns that were not adequately addressed still existed in the home.</label></td>',
        '<td class="w25"><label>{SafetyRelatedIncident90}</label></td>',
        '<td class="w25"><label>{Irr.SafetyRelatedIncident90}</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Other (describe any other safety-related incidents that were not adequately addressed by the agency):</label></td>',
        '<td class="w25"><label>{SafetyRelatedIncident91}</label></td>',
        '<td class="w25"><label>{Irr.SafetyRelatedIncident91}</label></td>',
        '</tr>',

        '<tr><td class="w5"></td><td class="w45"></td><td>{Item3.OtherSafetyConcernExplained}</td><td>{Irr.Item3.OtherSafetyConcernExplained}</td></tr>',

        '<tr>',
        '<td class="w5"><label>D.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.safety.question3D(true) + '</label></td>',
        '<td class="w25">{Item3.IsSafetyConcernForOtherChildren:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item3.IsSafetyConcernForOtherChildren:this.yesNoNa}</td>',
        '</tr>',


        '<tr>',
        '<td class="w5"><label>E1.</label> </td>',
        '<td colspan="3"><label>' + QuickStart.util.Resources.questions.safety.question3E1(true) + '</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>NA (this is an in-home services case, or the target child did not have any visitation).</label></td>',
        '<td class="w25"><label>{FosterSafety92}</label></td>',
        '<td class="w25"><label>{Irr.FosterSafety92}</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>No unmitigated safety concerns related to visitation were present.</label></td>',
        '<td class="w25"><label>{FosterSafety93}</label></td>',
        '<td class="w25"><label>{Irr.FosterSafety93}</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Sufficient monitoring of visitation by parents/caretakers or other family members was not ensured.</label></td>',
        '<td class="w25"><label>{FosterSafety94}</label></td>',
        '<td class="w25"><label>{Irr.FosterSafety94}</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Unsupervised visitation was allowed when it was not appropriate.</label></td>',
        '<td class="w25"><label>{FosterSafety95}</label></td>',
        '<td class="w25"><label>{Irr.FosterSafety95}</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Visitation was court-ordered despite safety concerns that could not be controlled with supervision.</label></td>',
        '<td class="w25"><label>{FosterSafety96}</label></td>',
        '<td class="w25"><label>{Irr.FosterSafety96}</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Other (describe the safety concerns that existed with visitation):</label></td>',
        '<td class="w25"><label>{FosterSafety97}</label></td>',
        '<td class="w25"><label>{Irr.FosterSafety97}</label></td>',
        '</tr>',

        '<tr><td class="w5"></td><td class="w45"></td><td>{Item3.FosterSafetyOtherExplained}</td><td>{Irr.Item3.FosterSafetyOtherExplained}</td></tr>',

        '<tr>',
        '<td class="w5"><label>E.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.safety.question3E(true) + '</label></td>',
        '<td class="w25">{Item3.IsFosterSafetyConcernDuringVisitation:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item3.IsFosterSafetyConcernDuringVisitation:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>F1.</label> </td>',
        '<td colspan="3"><label>' + QuickStart.util.Resources.questions.safety.question3F1(true) + '</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>NA (this is an in-home services case).</label></td>',
        '<td class="w25"><label>{FosterPlacementConcern98}</label></td>',
        '<td class="w25"><label>{Irr.FosterPlacementConcern98}</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>No safety concerns existed for the target child while in foster care placement that were not adequately addressed.</label></td>',
        '<td class="w25"><label>{FosterPlacementConcern99}</label></td>',
        '<td class="w25"><label>{Irr.FosterPlacementConcern99}</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>There was a substantiated allegation of maltreatment of the child by a foster parent (including a relative foster parent) or facility staff member that could have been prevented if the agency had taken appropriate actions.</label></td>',
        '<td class="w25"><label>{FosterPlacementConcern100}</label></td>',
        '<td class="w25"><label>{Irr.FosterPlacementConcern100}</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>There was a critical incident report or other major issue relevant to noncompliance by foster parents or facility staff that could potentially make the child unsafe, and the agency could have prevented it or did not provide an adequate response after it occurred.</label></td>',
        '<td class="w25"><label>{FosterPlacementConcern101}</label></td>',
        '<td class="w25"><label>{Irr.FosterPlacementConcern101}</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>The child’s placement during the period under review presented other risks to the child that are not being addressed, even though no allegation was made and no critical incident reports were filed.</label></td>',
        '<td class="w25"><label>{FosterPlacementConcern102}</label></td>',
        '<td class="w25"><label>{Irr.FosterPlacementConcern102}</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>You discover that there are safety concerns related to the child in the foster home of which the agency is unaware because of inadequate monitoring.</label></td>',
        '<td class="w25"><label>{FosterPlacementConcern103}</label></td>',
        '<td class="w25"><label>{Irr.FosterPlacementConcern103}</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Other (describe any other safety concerns that existed with the child’s foster placement):</label></td>',
        '<td class="w25"><label>{FosterPlacementConcern104}</label></td>',
        '<td class="w25"><label>{Irr.FosterPlacementConcern104}</label></td>',
        '</tr>',

        '<tr><td class="w5"></td><td class="w45"></td><td>{Item3.FosterPlacementConcerOtherExplained}</td><td>{Irr.Item3.FosterPlacementConcerOtherExplained}</td></tr>',

        '<tr>',
        '<td class="w5"><label>F.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.safety.question3F(true) + '</label></td>',
        '<td class="w25">{Item3.IsFosterSafetyConcernNotAddressed:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item3.IsFosterSafetyConcernNotAddressed:this.yesNoNa}</td>',
        '</tr>',

        '<tr class="item-rating"><td colspan="2">Item 3 Rating: </td><td><span> {Item3.ItemRatingCode:this.getRatingDesc}</span></td><td><span> {Irr.Item3.ItemRatingCode:this.getRatingDesc}</span></td></tr>',
        '<tr><td colspan="2"><label>Additional Comments: </label></td><td>{Item3.RatingComments}</td><td>{Irr.Item3.RatingComments}</td></tr>',
        '<tr class="outcome-rating"><td colspan="2">Safety Outcome 2 Rating: </td><td>{Outcome2RatingCode:this.getOutcomeRatingDesc}</td><td >{Irr.Outcome2RatingCode:this.getOutcomeRatingDesc}</td></tr>',

         '</table>',
         '<br/>',


         '<tpl if="this.isFosterCase(CaseReview.ReviewSubTypeID)">',
        // // /************************************************ Section II: Permanency **********************************************************/
        // //
        // // /************************************************ ITEM 4 **************************************************************************/

        '<table cellpadding="0"cellspacing="0" class="table">',
        '<tr><th></th> <th></th> <th></th> <th></th></tr>',

        '<tr><td colspan="4"class="section">Section II: Permanency</td></tr>',
        '<tr><td colspan="4"class="outcome">Permanency Outcome 1: Children have permanency and stability in their living situations.</td></tr>',
        '<tr><td colspan="4"class="item">Item 4: Stability of Foster Care Placement</td></tr>',


        '<tr><td class="w5"><label>A1.</label> </td><td colspan="3"><label>Placement Table</label></td></tr>',

        '<tr>',
        '<td colspan="2">',
            '<table cellpadding="0"cellspacing="0"class="child-table">',
            '<tr><th>Placement Date</th><th>Placement Type</th><th>Reason for Change in Placement Setting</th></tr>',
            '<tpl for="Item4.Placements">',
            '<tr><td>{Date:this.getDate}</td><td>{TypeCode:this.placementType}{TypeOther:this.other}</td><td>{ChangeReasonCode:this.changeReason}{ChangeReasonOther:this.other}</td></tr>',
            '</tpl>',
            '</table>',
        '</td>',

        '<td colspan="2">',
            '<table cellpadding="0"cellspacing="0"class="child-table">',
            '<tr><th>Placement Date</th><th>Placement Type</th><th>Reason for Change in Placement Setting</th></tr>',
            '<tpl for="Irr.Item4.Placements">',
            '<tr><td>{Date:this.getDate}</td><td>{TypeCode:this.placementType}{TypeOther:this.other}</td><td>{ChangeReasonCode:this.changeReason}{ChangeReasonOther:this.other}</td></tr>',
            '</tpl>',
            '</table>',
        '</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>A.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question4A(true) + '</label></td>',
        '<td class="w25">{Item4.NumberOfPlacementSettings}</td>',
        '<td class="w25">{Irr.Item4.NumberOfPlacementSettings}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question4B(true) + '</label></td>',
        '<td class="w25">{Item4.WereAllPlacementChangesPlanned:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item4.WereAllPlacementChangesPlanned:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>C1.</label> </td>',
        '<td colspan="3"><label>' + QuickStart.util.Resources.questions.permanency.question4C1(true) + '</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>None apply, placement is stable.</label></td>',
        '<td class="w25"><label>{PlacementApplicableCircumstance121}</label></td>',
        '<td class="w25"><label>{Irr.PlacementApplicableCircumstance121}</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>The child’s current placement is in a temporary shelter or other temporary setting.</label></td>',
        '<td class="w25"><label>{PlacementApplicableCircumstance122}</td>',
        '<td class="w25"><label>{Irr.PlacementApplicableCircumstance122}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>There is information indicating that the child’s current substitute care provider may not be able to continue to care for the child.</label></td>',
        '<td class="w25"><label>{PlacementApplicableCircumstance123}</td>',
        '<td class="w25"><label>{Irr.PlacementApplicableCircumstance123}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>There are problems in the current placement threatening its stability that the agency is not addressing.</label></td>',
        '<td class="w25"><label>{PlacementApplicableCircumstance124}</td>',
        '<td class="w25"><label>{Irr.PlacementApplicableCircumstance124}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>The child has run away from this placement more than once in the past, or is in runaway status at the time of the review.</label></td>',
        '<td class="w25"><label>{PlacementApplicableCircumstance125}</td>',
        '<td class="w25"><label>{Irr.PlacementApplicableCircumstance125}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Other (describe reasons why the current placement is not stable):</label></td>',
        '<td class="w25"><label>{PlacementApplicableCircumstance126}</td>',
        '<td class="w25"><label>{Irr.PlacementApplicableCircumstance126}</td>',
        '</tr>',

        '<tr>',
        '<td colspan="2"></td>',
        '<td class="w25">{Item4.PlacementApplicableCircumstancesOther}</td>',
        '<td class="w25">{Irr.Item4.PlacementApplicableCircumstancesOther}</td>',
        '</tr>',


        '<tr>',
        '<td class="w5"><label>C.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question4C(true) + '</label></td>',
        '<td class="w25">{Item4.IsCurrentPlacementSettingStable:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item4.IsCurrentPlacementSettingStable:this.yesNoNa}</td>',
        '</tr>',

        '<tr class="item-rating"><td colspan="2">Item 4 Rating: </td><td><span> {Item4.ItemRatingCode:this.getRatingDesc}</span> </td><td><span> {Irr.Item4.ItemRatingCode:this.getRatingDesc}</span> </td></tr>',
        '<tr><td colspan="2"><label>Additional Comments: </label></td> <td>{Item4.RatingComments}</td><td>{Irr.Item4.RatingComments}</td></tr>',

        // // /************************************************ ITEM 5 **************************************************************************/

        '<tr><td colspan="4"class="item">Item 5: Permanency Goal for Child</td></tr>',

        '<tr><td colspan="2"><label>Is this case applicable?</label></td><td class="w25">{Item5.IsApplicable:this.yesNo}</td><td class="w25">{Irr.Item5.IsApplicable:this.yesNo}</td></tr>',
        '<tr><td colspan="2"><label>Optional Comments: </label></td><td class="w25">{Item5.Comments}</td><td class="w25">{Irr.Item5.Comments}</td></tr>',

        '<tpl if="this.isApplicable(Item5.IsApplicable) && this.isApplicable(Irr.Item5.IsApplicable)">',
            '<tr><td class="w5"><label>A1.</label> </td><td colspan="3"><label>Permanency Goal Table</label></td></tr>',

            '<tr>',
                '<td colspan="2">',
                '<table cellpadding="0"cellspacing="0"class="child-table">',
                '<tr><th>Permanency Goal</th><th>Date Established</th><th>Time in Foster Care <br>Before Goal Established</th><th>Date Goal Changed</th><th>Reason for Goal Change</th></tr>',
                '<tpl for="Item5.Goals">',
                '<tr><td>{GoalCode:this.permanencyGoal1}</td><td>{DateEstablished:this.getDate}</td><td>{TimeInFosterCare} {TimeUnitCode:this.timeUnit}</td><td>{DateGoalChanged:this.getDate}</td><td>{ReasonForGoalChange}</td></tr>',
                '</tpl>',
                '</table>',
                '</td>',
                '<td colspan="2">',
                '<table cellpadding="0"cellspacing="0"class="child-table">',
                '<tr><th>Permanency Goal</th><th>Date Established</th><th>Time in Foster Care <br>Before Goal Established</th><th>Date Goal Changed</th><th>Reason for Goal Change</th></tr>',
                '<tpl for="Irr.Item5.Goals">',
                '<tr><td>{GoalCode:this.permanencyGoal1}</td><td>{DateEstablished:this.getDate}</td><td>{TimeInFosterCare} {TimeUnitCode:this.timeUnit}</td><td>{DateGoalChanged:this.getDate}</td><td>{ReasonForGoalChange}</td></tr>',
                '</tpl>',
                '</table>',
                '</td>',
            '</tr>',

            '<tr>',
            '<td class="w5"><label>A2.</label> </td>',
            '<td colspan="3"><label>' + QuickStart.util.Resources.questions.permanency.question5A2(true) + '</label></td>',
            '</tr>',


            '<tr><td class="w5"></td><td class="w45"><label>Permanency Goal1:</label></td><td class="w25">{Item5.Goal1Code:this.permanencyGoal1}</td><td class="w25">{Irr.Item5.Goal1Code:this.permanencyGoal1}</td></tr>',
            '<tr><td class="w5"></td><td class="w45"><label>Permanency Goal2:</label></td><td class="w25">{Item5.Goal2Code:this.permanencyGoal1}</td><td class="w25">{Irr.Item5.Goal2Code:this.permanencyGoal1}</td></tr>',

            '<tr>',
            '<td class="w5"><label>A3.</label> </td>',
            '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question5A3(true) + '</label></td>',
            '<td class="w25">{Item5.IsGoalSpecified:this.yesNoNa}</td>',
            '<td class="w25">{Irr.Item5.IsGoalSpecified:this.yesNoNa}</td>',
            '</tr>',

            '<tr>',
            '<td class="w5"><label>B.</label> </td>',
            '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question5B(true) + '</label></td>',
        '<td class="w25">{Item5.WereAllGoalsInTimelyManner:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item5.WereAllGoalsInTimelyManner:this.yesNoNa}</td>',
        '</tr>',

            '<tr>',
            '<td class="w5"></td>',
            '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25">{Item5.AllGoalsInTimelyMannerExplained}</td>',
        '<td class="w25">{Irr.Item5.AllGoalsInTimelyMannerExplained}</td>',

        '</tr>',

            '<tr>',
            '<td class="w5"><label>C.</label> </td>',
            '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question5C(true) + '</label></td>',
        '<td class="w25">{Item5.WereAllGoalsAppropriate:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item5.WereAllGoalsAppropriate:this.yesNoNa}</td>',
        '</tr>',

            '<tr>',
            '<td class="w5"></td>',
            '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25">{Item5.AllGoalsAppropriateExplained}</td>',
        '<td class="w25">{Irr.Item5.AllGoalsAppropriateExplained}</td>',
        '</tr>',


            '<tr>',
            '<td class="w5"><label>D.</label> </td>',
            '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question5D(true) + '</label></td>',
        '<td class="w25">{Item5.IsInFoster15OutOf22:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item5.IsInFoster15OutOf22:this.yesNoNa}</td>',
        '</tr>',

            '<tr>',
            '<td class="w5"><label>E.</label> </td>',
            '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question5E(true) + '</label></td>',
        '<td class="w25">{Item5.MeetsTerminationOfParentalRights:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item5.MeetsTerminationOfParentalRights:this.yesNoNa}</td>',
        '</tr>',

            '<tr>',
            '<td class="w5"><label>F.</label> </td>',
            '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question5F(true) + '</label></td>',
        '<td class="w25">{Item5.IsAgencyJointTerminationOfParentalRights:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item5.IsAgencyJointTerminationOfParentalRights:this.yesNoNa}</td>',
        '</tr>',


            '<tr>',
            '<td class="w5"><label>G1.</label> </td>',
            '<td colspan="3"><label>' + QuickStart.util.Resources.questions.permanency.question5G1(true) + '</label></td>',
            '</tr>',

            '<tr><td class="w5"></td><td class="w45"><label>NA</label></td><td class="w25">{TerminationException138}</td><td class="w25">{Irr.TerminationException138}</td></tr>',
            '<tr><td class="w5"></td><td class="w45"><label>No exceptions apply.</label></td><td class="w25">{TerminationException139}</td><td class="w25">{Irr.TerminationException139}</td></tr>',

            '<tr>',
            '<td class="w5"></td>',
            '<td class="w45"><label>(1) At the option of the state, the child is being cared for by a relative at the 15/22-month time frame.</label></td>',
        '<td class="w25">{TerminationException140}</td>',
        '<td class="w25">{Irr.TerminationException140}</td>',
        '</tr>',

            '<tr>',
            '<td class="w5"></td>',
            '<td class="w45"><label>(2) The agency documented in the case plan a compelling reason for determining that termination of parental rights would not be in the best interests of the child.</label></td>',
        '<td class="w25">{TerminationException141}</td>',
        '<td class="w25">{Irr.TerminationException141}</td>',
        '</tr>',

            '<tr>',
            '<td class="w5"></td>',
            '<td class="w45"><label>(3) The state has not provided to the family the services that the state deemed necessary for the safe return of the child to the child\'s home.</label></td>',
        '<td class="w25">{TerminationException142}</td>',
        '<td class="w25">{Irr.TerminationException142}</td>',
        '</tr>',

            '<tr>',
            '<td class="w5"><label>G.</label> </td>',
            '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question5G(true) + '</label></td>',
        '<td class="w25">{Irr.Item5.IsExceptionForTermination:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item5.IsExceptionForTermination:this.yesNoNa}</td>',
        '</tr>',
        '</tpl>',


        '<tr class="item-rating"><td colspan="2">Item 5 Rating: </td><td><span> {Item5.ItemRatingCode:this.getRatingDesc}</span> </td><td><span> {Irr.Item5.ItemRatingCode:this.getRatingDesc}</span> </td></tr>',
        '<tr><td colspan="2"><label>Additional Comments: </label></td><td>{Item5.RatingComments}</td><td>{Irr.Item5.RatingComments}</td></tr>',


        // // /************************************************ ITEM 6 **************************************************************************/

        '<tr><td colspan="4"class="item">Item 6: Achieving Reunification, Guardianship, Adoption, or Other Planned Permanent Living Arrangement</td></tr>',

        '<tr><td colspan="4"><label>Item 6 Applicable Cases:</label></tr>',
        '<tr><td colspan="4"><label>All foster care cases are applicable for an assessment of this item.</label></td></tr>',

        '<tr>',
        '<td class="w5"><label>A1.</label></td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question6A1(true) + '</label></td>',
        '<td class="w25">{Item6.ChildMostRecentFosterEntryDate:this.getDate}</td>',
        '<td class="w25">{Irr.Item6.ChildMostRecentFosterEntryDate:this.getDate}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>A2.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question6A2(true) + '</label></td>',
        '<td class="w25">{Item6.TimeInCare}</td>',
        '<td class="w25">{Irr.Item6.TimeInCare}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>A3.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question6A3(true) + '</label></td>',
        '<td class="w25">{Item6.TimeInCare}</td>',
        '<td class="w25">{Irr.Item6.TimeInCare}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>A4.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question6A4(true) + '</label></td>',
        '<td class="w25">{Item6.PermanencyGoal1:this.permanencyGoal1}</td>',
        '<td class="w25">{Irr.Item6.PermanencyGoal1:this.permanencyGoal1}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question6B(true) + '</label></td>',
        '<td class="w25">{Item6.IsAgencyConcertedEfforts:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item6.IsAgencyConcertedEfforts:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25">{Item6.AgencyConcertedEffortsExplained}</td>',
        '<td class="w25">{Irr.Item6.AgencyConcertedEffortsExplained}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>C1.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question6C1(true) + '</label></td>',
        '<td class="w25">{Item6.LivingArrangementCode:this.livingArrangement}</td>',
        '<td class="w25">{Irr.Item6.LivingArrangementCode:this.livingArrangement}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>If Other is selected, describe the child\'s permanent living arrangement.</label></td>',
        '<td class="w25">{Item6.LivingArrangementExplained}</td>',
        '<td class="w25">{Irr.Item6.LivingArrangementExplained}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>C2.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question6C2(true) + '</label></td>',
        '<td class="w25">{Question6C2}</td>',
        '<td class="w25">{Irr.Question6C2}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>C.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question6C(true) + '</label></td>',
        '<td class="w25">{Item6.IsOtherPlannedConcertedEffort:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item6.IsOtherPlannedConcertedEffort:this.yesNoNa}</td>',
        '</tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25">{Item6.OtherPlannedConcertedEffortExplained}</td>',
        '<td class="w25">{Irr.Item6.OtherPlannedConcertedEffortExplained}</td>',
        '</tr>',


        '<tr class="item-rating">',
         '<td colspan="2">Item 6 Rating: </td>',
        '<td class="w25"><span> {Item6.ItemRatingCode:this.getRatingDesc}</span> </td>',
        '<td class="w25"><span> {Irr.Item6.ItemRatingCode:this.getRatingDesc}</span> </td>',
        '</tr>',
        '<tr>',
        '<td colspan="2"><label>Additional Comments: </label></td>',
        '<td class="w25">{Item6.RatingComments}</td>',
        '<td class="w25">{Irr.Item6.RatingComments}</td>',
        '</tr>',
        '<tr class="outcome-rating">',
        '<td colspan="2">Permanency Outcome 1 Rating: </td>',
        '<td class="w25">{Outcome3RatingCode:this.getOutcomeRatingDesc}</td>',
        '<td class="w25">{Irr.Outcome3RatingCode:this.getOutcomeRatingDesc}</td>',
        '</tr>',
        '<tr><td colspan="4"></td></tr>',

        // // // /************************************************ ITEM 7 **************************************************************************/
        //
        '<tr><td colspan="4"class="outcome">Permanency Outcome 2: The continuity of family relationships and connections is preserved for children.</td></tr>',
        '<tr><td colspan="4"class="item">Item 7: Placement With Siblings</td></tr>',

        '<tr><td colspan="2"><label>Is this case applicable?</label></td><td class="w25">{Item7.IsApplicable:this.yesNo}</td><td class="w25">{Irr.Item7.IsApplicable:this.yesNo}</td></tr>',
        '<tr><td colspan="2"><label>Optional Comments: </label></td><td class="w25">{Item7.Comments}</td><td class="w25">{Irr.Item7.Comments}</td></tr>',


        '<tpl if="this.isApplicable(Item7.IsApplicable) || this.isApplicable(Irr.Item7.IsApplicable)">',
        '<tr>',
        '<td class="w5"><label>A.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question7A(true) + '</label></td>',
        '<td class="w25">{Item7.IsPlacedWithAllSiblings:this.yesNo}</td>',
        '<td class="w25">{Irr.Item7.IsPlacedWithAllSiblings:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question7B(true) + '</label></td>',
        '<td class="w25">{Item7.IsValidReasonForSeparation:this.yesNo}</td>',
        '<td class="w25">{Irr.Item7.IsValidReasonForSeparation:this.yesNo}</td>',
        '</tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25">{Item7.ValidReasonForSeparationExplained}</td>',
        '<td class="w25">{Irr.Item7.ValidReasonForSeparationExplained}</td>',
        '</tr>',
        '</tpl>',

        '<tr class="item-rating"><td colspan="2">Item 7 Rating: </td><td><span> {Item7.ItemRatingCode:this.getRatingDesc}</span> </td><td><span> {Irr.Item7.ItemRatingCode:this.getRatingDesc}</span> </td></tr>',
        '<tr><td colspan="2"><label>Additional Comments: </label></td><td>{Item7.RatingComments}</td><td>{Irr.Item7.RatingComments}</td></tr>',

        // // /************************************************ITEM 8**************************************************************************/

        '<tr><td colspan="4"class="item">Item 8: Visiting With Parents and Siblings in Foster Care</td></tr>',
        '<tr><td colspan="4"><label>Item 8 Applicable Cases:</label></td></tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>The child has at least one sibling in foster care who is in a different placement setting.</label></td>',
        '<td class="w25">{Item8.Applicability57:this.yesNo}</td>',
        '<td class="w25">{Irr.Item8.Applicability57:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>There is documentation in the case file indicating that contact between the child and both of his or her parents is not in the child\'s best interests.</label></td>',
        '<td class="w25">{Item8.Applicability58:this.yesNo}</td>',
        '<td class="w25">{Irr.Item8.Applicability58:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>The whereabouts of both parents are unknown despite documented concerted agency efforts to locate the parents.</label></td>',
        '<td class="w25">{Item8.Applicability59:this.yesNo}</td>',
        '<td class="w25">{Irr.Item8.Applicability59:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Both Parents were deceased during the entire period under review.</label></td>',
        '<td class="w25">{Item8.Applicability60:this.yesNo}</td>',
        '<td class="w25">{Irr.Item8.Applicability60:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>The Parental rights of both parents remained terminated during the entire period under review.</label></td>',
        '<td class="w25">{Item8.Applicability60:this.yesNo}</td>',
        '<td class="w25">{Irr.Item8.Applicability60:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>The only parent(s) being assessed in this item does not meet the definition of Mother/Father for this item.</label></td>',
        '<td class="w25">{Item8.Applicability62:this.yesNo}</td>',
        '<td class="w25">{Irr.Item8.Applicability62:this.yesNo}</td>',
        '</tr>',

        '<tr><td colspan="2"><label>Is this case applicable?</label></td><td class="w25">{Item8.IsApplicable:this.yesNo}</td><td class="w25">{Irr.Item8.IsApplicable:this.yesNo}</td></tr>',
        '<tr><td colspan="2"><label>Optional Comments: </label></td><td>{Item8.Comments}</td><td>{Irr.Item8.Comments}</td></tr>',

        '<tpl if="this.isApplicable(Item8.IsApplicable) || this.isApplicable(Irr.Item8.IsApplicable)">',
        '<tr><td colspan="4"><label>Case participants who are included in this item as Mother and Father:</label></td></tr>',

        '<tr><td class="w5"></td><td class="w45"><label>Case Participant Mother</label></td><td class="w25"><label>{Item8ParticipantMother}</label></td><td class="w25"><label>{Irr.Item8ParticipantMother}</label></td></tr>',
        '<tr><td class="w5"></td><td class="w45"><label>Case Participant Father</label></td><td class="w25"><label>{Item8ParticipantFather}</label></td><td class="w25"><label>{Irr.Item8ParticipantFather}</label></td></tr>',


        '<tr>',
        '<td class="w5"><label>A1.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question8A1(true) + '</label></td>',
        '<td class="w25">{Item8.MotherVisitationFrequencyCode:this.visitationFrequency}</td>',
        '<td class="w25">{Irr.Item8.MotherVisitationFrequencyCode:this.visitationFrequency}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>A.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question8A(true) + '</label></td>',
        '<td class="w25">{Item8.IsSufficientFrequencyForMotherVisitation:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item8.IsSufficientFrequencyForMotherVisitation:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B1.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question8B1(true) + '</label></td>',
        '<td class="w25">{Item8.FatherVisitationFrequencyCode:this.visitationFrequency}</td>',
        '<td class="w25">{Irr.Item8.FatherVisitationFrequencyCode:this.visitationFrequency}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question8B(true) + '</label></td>',
        '<td class="w25">{Item8.IsSufficientFrequencyForFatherVisitation:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item8.IsSufficientFrequencyForFatherVisitation:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>C.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question8C(true) + '</label></td>',
        '<td class="w25">{Item8.IsSufficientQualityForMotherVisitation:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item8.IsSufficientQualityForMotherVisitation:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>D.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question8D(true) + '</label></td>',
        '<td class="w25">{Item8.IsSufficentQualityForFatherVisitation:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item8.IsSufficentQualityForFatherVisitation:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>E1.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question8E1(true) + '</label></td>',
        '<td class="w25">{Item8.SiblingVisitationFrequencyCode:this.visitationFrequency}</td>',
        '<td class="w25">{Irr.Item8.SiblingVisitationFrequencyCode:this.visitationFrequency}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>E.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question8E(true) + '</label></td>',
        '<td class="w25">{Item8.IsSufficientFrequencyForSiblingVisitation:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item8.IsSufficientFrequencyForSiblingVisitation:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>F.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question8F(true) + '</label></td>',
        '<td class="w25">{Item8.IsSufficentQualityForSiblingVisitation:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item8.IsSufficentQualityForSiblingVisitation:this.yesNoNa}</td>',
        '</tr>',
        '</tpl>',


        '<tr class="item-rating"><td colspan="2">Item 8 Rating: </td><td><span> {Item8.ItemRatingCode:this.getRatingDesc}</span></td><td><span> {Irr.Item8.ItemRatingCode:this.getRatingDesc}</span></td></tr>',
        '<tr><td colspan="2"><label>Additional Comments: </label></td><td>{Item8.RatingComments}</td><td>{Irr.Item8.RatingComments}</td></tr>',

        // // /************************************************ITEM 9**************************************************************************/

        '<tr><td colspan="4"class="item">Item 9: Preserving Connections</td></tr>',
        '<tr><td colspan="2"><label>Is this case applicable?</label></td><td class="w25">{Item9.IsApplicable:this.yesNo}</td><td class="w25">{Irr.Item9.IsApplicable:this.yesNo}</td></tr>',
        '<tr><td colspan="2"><label>Optional Comments: </label></td><td>{Item9.Comments}</td><td>{Irr.Item9.Comments}</tr>',


        '<tpl if="this.isApplicable(Item9.IsApplicable) || this.isApplicable(Item9.IsApplicable)">',
        '<tr>',
        '<td class="w5"><label>A.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question9A(true) + '</label></td>',
        '<td class="w25">{Item9.IsConcertedEffortsForImportantConnections:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item9.IsConcertedEffortsForImportantConnections:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question9B(true) + '</label></td>',
        '<td class="w25">{Item9.IsSufficientInquiryForIndianTribe:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item9.IsSufficientInquiryForIndianTribe:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>C.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question9C(true) + '</label></td>',
        '<td class="w25">{Item9.IsTribeProvidedTimelyNotification:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item9.IsTribeProvidedTimelyNotification:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>D.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question9D(true) + '</label></td>',
        '<td class="w25">{Item9.IsAccordanceWithIndianChildWelfareAct:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item9.IsAccordanceWithIndianChildWelfareAct:this.yesNoNa}</td>',
        '</tr>',
        '</tpl>',

        '<tr class="item-rating"><td colspan="2" >Item 9 Rating: </td><td><span> {Item9.ItemRatingCode:this.getRatingDesc}</span> </td><td><span> {Irr.Item9.ItemRatingCode:this.getRatingDesc}</span> </td></tr>',
        '<tr><td colspan="2"><label>Additional Comments: </label></td><td>{Item9.RatingComments}</td><td>{Irr.Item9.RatingComments}</td></tr>',


        // // /************************************************ITEM 10**************************************************************************/

        '<tr><td colspan="4"class="item">Item 10: Relative Placement</td></tr>',
        '<tr><td colspan="2"><label>Is this case applicable?</label></td><td class="w25">{Item10.IsApplicable:this.yesNo}</td><td class="w25">{Irr.Item10.IsApplicable:this.yesNo}</td></tr>',
        '<tr><td colspan="2"><label>Optional Comments: </label></td><td>{Item10.Comments}</td><td>{Irr.Item10.Comments}</td></tr>',


        '<tpl if="this.isApplicable(Item10.IsApplicable) || this.isApplicable(Irr.Item10.IsApplicable)">',
        '<tr>',
        '<td class="w5"><label>A1.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question10A1(true) + '</label></td>',
        '<td class="w25">{Item10.IsRecentPlacementWithRelative:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item10.IsRecentPlacementWithRelative:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>A2.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question10A2(true) + '</label></td>',
        '<td class="w25">{Item10.IsPlacementWithRelativeStable:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item10.IsPlacementWithRelativeStable:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question10B(true) + '</label></td>',
        '<td class="w25">{Item10.IsConcertedEffortToLocateMaternalRelatives:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item10.IsConcertedEffortToLocateMaternalRelatives:this.yesNoNa}</td>',
        '</tr>',

        '<tpl if="Item10.IsConcertedEffortToLocateMaternalRelatives==2 || Irr.Item10.IsConcertedEffortToLocateMaternalRelatives==2">',
        '<tr><td colspan="4"><label>No, specify the area in which concerns existed:</label> </td></tr>',
        '<tr><td class="w5"></td><td class="w45"><label>Identify</label></td><td class="w25">{PlacementEffortConcernsMother156}</td><td class="w25">{Irr.PlacementEffortConcernsMother156}</td></tr>',
        '<tr><td class="w5"></td><td class="w45"><label>Locate</label></td><td class="w25">{PlacementEffortConcernsMother157}</td><td class="w25">{Irr.PlacementEffortConcernsMother157}</td></tr>',
        '<tr><td class="w5"></td><td class="w45"><label>Inform</label></td><td class="w25">{PlacementEffortConcernsMother158}</td><td class="w25">{Irr.PlacementEffortConcernsMother158}</td></tr>',
        '<tr><td class="w5"></td><td class="w45"><label>Evaluate</label></td><td class="w25">{PlacementEffortConcernsMother159}</td><td class="w25">{Irr.PlacementEffortConcernsMother159}</td></tr>',
         '</tpl>',


        '<tr>',
        '<td class="w5"><label>C.</label></td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question10C(true) + '</label></td>',
        '<td class="w25">{Item10.IsConcertedEffortToLocatePaternalRelatives:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item10.IsConcertedEffortToLocatePaternalRelatives:this.yesNoNa}</td>',
        '</tr>',

        '<tpl if="Item10.IsConcertedEffortToLocatePaternalRelatives==2 || Irr.Item10.IsConcertedEffortToLocatePaternalRelatives==2">',
            '<tr><td colspan="4"><label>No, specify the area in which concerns existed:</label> </td></tr>',
            '<tr><td class="w5"></td><td class="w45"><label>Identify</label></td><td class="w25">{PlacementEffortConcernsFather160}</td><td class="w25">{Irr.PlacementEffortConcernsFather160}</td></tr>',
            '<tr><td class="w5"></td><td class="w45"><label>Locate</label></td><td class="w25">{PlacementEffortConcernsFather161}</td><td class="w25">{Irr.PlacementEffortConcernsFather161}</td></tr>',
            '<tr><td class="w5"></td><td class="w45"><label>Inform</label></td><td class="w25">{PlacementEffortConcernsFather162}</td><td class="w25">{Irr.PlacementEffortConcernsFather162}</td></tr>',
            '<tr><td class="w5"></td><td class="w45"><label>Evaluate</label></td><td class="w25">{PlacementEffortConcernsFather163}</td><td class="w25">{Irr.PlacementEffortConcernsFather163}</td></tr>',
        '</tpl>',

        '</tpl>',

        '<tr class="item-rating"><td colspan="2">Item 10 Rating: </td><td><span> {Item10.ItemRatingCode:this.getRatingDesc}</span> </td><td><span> {Irr.Item10.ItemRatingCode:this.getRatingDesc}</span> </td></tr>',
        '<tr><td colspan="2"><label>Additional Comments: </label></td><td>{Item10.RatingComments}</td><td>{Irr.Item10.RatingComments}</td></tr>',


        // /************************************************ ITEM 11 **************************************************************************/

        '<tr><td colspan="4"class="item">Item 11: Relationship of Child in Care With Parents</td></tr>',
        '<tr><td colspan="4"><label>Item 11 Applicable Cases:</label></td></tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>The parental rights for both parents remained terminated during the entire period under review.</label></td>',
        '<td class="w25">{Item11.Applicability63:this.yesNo}</td>',
        '<td class="w25">{Irr.Item11.Applicability63:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>The child was abandoned and neither parent could be located.</label></td>',
        '<td class="w25">{Item11.Applicability64:this.yesNo}</td>',
        '<td class="w25">{Irr.Item11.Applicability64:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>The whereabouts of both parents were not known during the entire period under review despite documented concerted agency efforts to locate both parents.</label></td>',
        '<td class="w25">{Item11.Applicability65:this.yesNo}</td>',
        '<td class="w25">{Irr.Item11.Applicability65:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Contact with both parents was considered to be not in the child’s best interests and this is documented in the case record.</label></td>',
        '<td class="w25">{Item11.Applicability66:this.yesNo}</td>',
        '<td class="w25">{Irr.Item11.Applicability66:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>During the entire period under review, both parents were deceased.</label></td>',
        '<td class="w25">{Item11.Applicability67:this.yesNo}</td>',
        '<td class="w25">{Irr.Item11.Applicability67:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>The only parent(s) being assessed in this item does not meet the definition of Mother/Father for this item.</label></td>',
        '<td class="w25">{Item11.Applicability261:this.yesNo}</td>',
        '<td class="w25">{Irr.Item11.Applicability261:this.yesNo}</td>',
        '</tr>',

        '<tr><td colspan="2"><label>Is this case applicable?</label></td><td class="w25">{Item11.IsApplicable:this.yesNo}</td><td class="w25">{Irr.Item11.IsApplicable:this.yesNo}</td></tr>',
        '<tr><td colspan="2"><label>Optional Comments: </label></td><td>{Item11.Comments}</td><td>{Irr.Item11.Comments}</td></tr>',

        '<tpl if="this.isApplicable(Item11.IsApplicable) || this.isApplicable(Irr.Item11.IsApplicable)">',
        '<tr><td colspan="4"><label>Case participants who are included in this item as Mother and Father:</label></td></tr>',
        '<tr><td class="w5"></td><td class="w45"><label>Case Participant Mother</label></td><td class="w25"><label>{Item11ParticipantMother}</label></td><td class="w25"><label>{Irr.Item11ParticipantMother}</label></td></tr>',
        '<tr><td class="w5"></td><td class="w45"><label>Case Participant Father</label></td><td class="w25"><label>{Item11ParticipantFather}</label></td><td class="w25"><label>{Irr.Item11ParticipantFather}</label></td></tr>',

        '<tr>',
        '<td class="w5"><label>A.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question11A(true) + '</label></td>',
        '<td class="w25">{Item11.IsConcertedEffortMotherFosterRelationship:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item11.IsConcertedEffortMotherFosterRelationship:this.yesNoNa}</td>',
        '</tr>',


        '<tr>',
        '<td class="w5"><label>A1.</label> </td>',
        '<td colspan="3"><label>' + QuickStart.util.Resources.questions.permanency.question11A1(true) + '</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>NA</label></td>',
        '<td class="w25">{EffortsToSupportMotherFosterRelationship164}</td>',
        '<td class="w25">{Irr.EffortsToSupportMotherFosterRelationship164}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Encouraged the mother’s participation in school activities and case conferences, attendance at doctors’ appointments with the child, or engagement in the child’s after-school or sports activities?</label></td>',
        '<td class="w25">{EffortsToSupportMotherFosterRelationship165}</td>',
        '<td class="w25">{Irr.EffortsToSupportMotherFosterRelationship165}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Provided or arranged for transportation or provided funds for transportation so that the mother could attend the child’s special activities and doctors’ appointments?</label></td>',
        '<td class="w25">{EffortsToSupportMotherFosterRelationship166}</td>',
        '<td class="w25">{Irr.EffortsToSupportMotherFosterRelationship166}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Provided opportunities for therapeutic situations to help the mother and child strengthen their relationship?</label></td>',
        '<td class="w25">{EffortsToSupportMotherFosterRelationship167}</td>',
        '<td class="w25">{Irr.EffortsToSupportMotherFosterRelationship167}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Encouraged the foster parents to provide mentoring or serve as role models to the mother to assist her in appropriate parenting?</label></td>',
        '<td class="w25">{EffortsToSupportMotherFosterRelationship168}</td>',
        '<td class="w25">{Irr.EffortsToSupportMotherFosterRelationship168}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Encouraged and facilitated contact with a mother not living in close proximity to the child?</label></td>',
        '<td class="w25">{EffortsToSupportMotherFosterRelationship169}</td>',
        '<td class="w25">{Irr.EffortsToSupportMotherFosterRelationship169}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Other (describe other concerted efforts made)</label></td>',
        '<td class="w25">{EffortsToSupportMotherFosterRelationship170}</td>',
        '<td class="w25">{Irr.EffortsToSupportMotherFosterRelationship170}</td>',
        '</tr>',
        '<tr><td colspan="2"></td><td >{Item11.EffortsMotherFosterOther}</td><td >{Irr.Item11.EffortsMotherFosterOther}</td></tr>',

        '<tr>',
        '<td class="w5"><label>B.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.permanency.question11B(true) + '</label></td>',
        '<td class="w25">{Item11.IsConcertedEffortFatherFosterRelationship:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item11.IsConcertedEffortFatherFosterRelationship:this.yesNoNa}</td>',
        '</tr>',


        '<tr>',
        '<td class="w5"><label>B1.</label> </td>',
        '<td class="w45"colspan="3"><label>' + QuickStart.util.Resources.questions.permanency.question11B1(true) + '</label></td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>NA</label></td>',
        '<td class="w25">{EffortsToSupportFatherFosterRelationship171}</td>',
        '<td class="w25">{Irr.EffortsToSupportFatherFosterRelationship171}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Encouraged the mother’s participation in school activities and case conferences, attendance at doctors’ appointments with the child, or engagement in the child’s after-school or sports activities?</label></td>',
        '<td class="w25">{EffortsToSupportFatherFosterRelationship172}</td>',
        '<td class="w25">{Irr.EffortsToSupportFatherFosterRelationship172}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Provided or arranged for transportation or provided funds for transportation so that the mother could attend the child’s special activities and doctors’ appointments?</label></td>',
        '<td class="w25">{EffortsToSupportFatherFosterRelationship173}</td>',
        '<td class="w25">{Irr.EffortsToSupportFatherFosterRelationship173}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Provided opportunities for therapeutic situations to help the mother and child strengthen their relationship?</label></td>',
        '<td class="w25">{EffortsToSupportFatherFosterRelationship174}</td>',
        '<td class="w25">{Irr.EffortsToSupportFatherFosterRelationship174}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Encouraged the foster parents to provide mentoring or serve as role models to the mother to assist her in appropriate parenting?</label></td>',
        '<td class="w25">{EffortsToSupportFatherFosterRelationship175}</td>',
        '<td class="w25">{Irr.EffortsToSupportFatherFosterRelationship175}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Encouraged and facilitated contact with a mother not living in close proximity to the child?</label></td>',
        '<td class="w25">{EffortsToSupportFatherFosterRelationship176}</td>',
        '<td class="w25">{Irr.EffortsToSupportFatherFosterRelationship176}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>Other (describe other concerted efforts made)</label></td>',
        '<td class="w25">{EffortsToSupportFatherFosterRelationship177}</td>',
        '<td class="w25">{Irr.EffortsToSupportFatherFosterRelationship177}</td>',
        '</tr>',
        '<tr><td colspan="2"></td><td >{Item11.EffortFatherFosterRelationshipOther}</td><td >{Irr.Item11.EffortFatherFosterRelationshipOther}</td></tr>',
        '</tpl>',


        '<tr class="item-rating"><td colspan="2">Item 11 Rating: </td><td><span> {Item11.ItemRatingCode:this.getRatingDesc}</span> </td><td><span> {Irr.Item11.ItemRatingCode:this.getRatingDesc}</span> </td></tr>',
        '<tr><td colspan="2"><label>Additional Comments: </label></td><td>{Item11.RatingComments}</td><td>{Irr.Item11.RatingComments}</td></tr>',
        '<tr class="outcome-rating"><td colspan="2" >Permanency Outcome 2 Rating: </td><td>{Outcome4RatingCode:this.getOutcomeRatingDesc}</td><td>{Irr.Outcome4RatingCode:this.getOutcomeRatingDesc}</td></tr>',
        '</table>',
        '<br/>',
        '</tpl>',

        //permanency end
        //foster items hidden for home service



        // /************************************************ Section III: Child and Family Well-Being *****************************************/
        '<table cellpadding="0"cellspacing="0" class="table">',
        '<tr><th></th> <th></th> <th></th> <th></th></tr>',

        '<tr><td colspan="4"class="section">Section III: Child and Family Well-Being</td></tr>',
        '<tr><td colspan="4"class="outcome">Well-Being Outcome 1: Families have enhanced capacity to provide for their children\'s needs.</td></tr>',
        '<tr><td colspan="4"class="item">Item 12: Needs and Services of Child, Parents, and Foster Parents</td></tr>',


        // // /************************************************ ITEM 12 **************************************************************************/

        '<tr>',
        '<td colspan="4"><label>Most cases are applicable for an assessment of this item because Sub-Item 12A is typically applicable to all cases. Sub-Items 12B and 12C may not be applicable to all cases, and instructions for applicability are provided before each sub-item.</label></td>',
        '</tr>',

        // /************************************************ ITEM 12 A **************************************************************************/

        '<tr><td colspan="4"class="item">Sub-Item 12A: Needs Assessment and Services to Children</td></tr>',
        '<tr><td colspan="4"><label>Item 12 Applicable Cases:</label></td></tr>',
        '<tr><td colspan="4"><label>All cases are applicable for an assessment of this sub-item</label></td></tr>',
        '<tr><td colspan="2"><label>Optional Comments: </label><td>{Item12A.Comments}</td><td>{Irr.Item12A.Comments}</td></tr>',


        '<tr>',
        '<td class="w5"><label>A1.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question12A1(true) + '</label></td>',
        '<td class="w25">{Item12A.IsComprehensiveAssessementConducted:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item12A.IsComprehensiveAssessementConducted:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25">{Item12A.ComprehensiveAssessmentExplained}</td>',
        '<td class="w25">{Irr.Item12A.ComprehensiveAssessmentExplained}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>A2.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question12A2(true) + '</label></td>',
        '<td class="w25">{Item12A.IsAppropriateServicesProvided:this.yesNoNa}</td>',
        '<td class="w25">{Item12A.IsAppropriateServicesProvided:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25">{Item12A.AppropriateServicesProvidedExplained}</td>',
        '<td class="w25">{Irr.Item12A.AppropriateServicesProvidedExplained}</td>',
        '</tr>',

        '<tr class="item-rating"><td colspan="2">Sub-Item 12A Rating:  </td><td><span> {Item12A.ItemRatingCode:this.getRatingDesc}</span></td><td><span> {Irr.Item12A.ItemRatingCode:this.getRatingDesc}</span></td></tr>',
        '<tr><td colspan="2"><label>Additional Comments: </label></td><td>{Item12A.RatingComments}</td><td>{Irr.Item12A.RatingComments}</td></tr>',

        /************************************************ ITEM 12 B **************************************************************************/

        '<tr><td colspan="4"class="item">Sub-Item 12B: Needs Assessment and Services to Parents</td></tr>',
        '<tr><td colspan="4"><label>Sub-Item 12B Applicable Cases:</label></td></tr>',

        '<tr>',
        '<td colspan="2"><label>Parental rights remained terminated during the entire period under review</label></td>',
        '<td class="w25">{Item12B.Applicability68:this.yesNo}</td>',
        '<td class="w25">{Irr.Item12B.Applicability68:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td colspan="2"><label>Parent’s whereabouts were not known during the entire period under review despite agency efforts to locate the parent</label></td>',
        '<td class="w25">{Item12B.Applicability69:this.yesNo}</td>',
        '<td class="w25">{Irr.Item12B.Applicability69:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td colspan="2"><label>Parent was deceased during the entire period under review</label></td>',
        '<td class="w25">{Item12B.Applicability70:this.yesNo}</td>',
        '<td class="w25">{Irr.Item12B.Applicability70:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td colspan="2"><label>During the entire period under review it was documented in the case file that it was not in the child’s best interests to involve the parent in case planning</label></td>',
        '<td class="w25">{Item12B.Applicability71:this.yesNo}</td>',
        '<td class="w25">{Irr.Item12B.Applicability71:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td colspan="2"><label>During the entire period under review the parent has indicated he/she does not want to be involved in the child’s life and this was documented in the case file</label></td>',
        '<td class="w25">{Item12B.Applicability72:this.yesNo}</td>',
        '<td class="w25">{Irr.Item12B.Applicability72:this.yesNo}</td>',
        '</tr>',


        '<tr>',
        '<td colspan="2"><label>Is sub-item 12B applicable for Mother?</label></td>',
        '<td class="w25">{Item12B.IsNeedsServicesApplicableForMother:this.yesNo}</td>',
        '<td class="w25">{Irr.Item12B.IsNeedsServicesApplicableForMother:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td colspan="2"><label>Is sub-item 12B applicable for Father?</label></td>',
        '<td class="w25">{Item12B.IsNeedsServicesApplicableForFather:this.yesNo}</td>',
        '<td class="w25">{Irr.Item12B.IsNeedsServicesApplicableForFather:this.yesNo}</td>',
        '</tr>',

        '<tr><td colspan="2"><label>Case participants who are included in this item as Mother and Father:</label></td></tr>',
        '<tr><td class="w5"></td><td class="w45"><label>Case Participant Mother</label></td><td class="w25"><label>{Item12bParticipantMother}</label></td><td class="w25"><label>{Irr.Item12bParticipantMother}</label></td></tr>',
        '<tr><td class="w5"></td><td class="w45"><label>Case Participant Father</label></td><td class="w25"><label>{Item12bParticipantFather}</label></td><td class="w25"><label>{Irr.Item12bParticipantFather}</label></td></tr>',

        '<tr><td colspan="2"><label>Optional Comments:</label></td><td >{Item12B.Comments}</td><td >{Irr.Item12B.Comments}</td></tr>',


        '<tr>',
        '<td class="w5"><label>B1.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question12B1(true) + '</label></td>',
        '<td class="w25">{Item12B.IsComprehensiveAssessementForMotherConducted:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25">{Item12B.ComprehensiveAssessementForMotherExplained}</td>',
        '<td class="w25">{Irr.Item12B.ComprehensiveAssessementForMotherExplained}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B2.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question12B2(true) + '</label></td>',
        '<td class="w25">{Item12B.IsComprehensiveAssessementForFatherConducted:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item12B.IsComprehensiveAssessementForFatherConducted:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25">{Item12B.ComprehensiveAssessementforFatherConductedExplained}</td>',
        '<td class="w25">{Irr.Item12B.ComprehensiveAssessementforFatherConductedExplained}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B3.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question12B3(true) + '</label></td>',
        '<td class="w25">{Item12B.IsAppropriateServicesForMotherProvided:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item12B.IsAppropriateServicesForMotherProvided:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25">{Item12B.AppropriateServicesForMotherExplained}</td>',
        '<td class="w25">{Irr.Item12B.AppropriateServicesForMotherExplained}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B4.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question12B4(true) + '</label></td>',
        '<td class="w25">{Item12B.IsAppropriateServicesForFatherProvided:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item12B.IsAppropriateServicesForFatherProvided:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25">{Item12B.AppropriateServicesForFatherExplained}</td>',
        '<td class="w25">{Irr.Item12B.AppropriateServicesForFatherExplained}</td>',
        '</tr>',

        '<tr class="item-rating"><td colspan="2">Sub-Item 12B Rating: </td><td><span> {Item12B.ItemRatingCode:this.getRatingDesc}</span></td><td><span> {Irr.Item12B.ItemRatingCode:this.getRatingDesc}</span></td></tr>',
        '<tr><td colspan="2"><label>Additional Comments: </label></td><td>{Item12B.RatingComments}</td><td>{Irr.Item12B.RatingComments}</td></tr>',

        // /************************************************ ITEM 12 C **************************************************************************/

        '<tr><td colspan="4"class="item">Sub-Item 12C: Needs Assessment and Services to Foster Parents</td></tr>',
        '<tr><td colspan="2"><label>Is this case applicable?</label></td><td class="w25">{Item12C.IsApplicable:this.yesNo}</td><td class="w25">{Irr.Item12C.IsApplicable:this.yesNo}</td></tr>',
        '<tr><td colspan="2"><label>Optional Comments: </label></td><td>{Item12C.Comments}</td><td>{Irr.Item12C.Comments}</td></tr>',


        '<tpl if="this.isApplicable(Item12C.IsApplicable) || this.isApplicable(Irr.Item12C.IsApplicable)">',
        '<tr>',
        '<td class="w5"><label>C1.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question12C1(true) + '</label></td>',
        '<td class="w25">{Item12C.IsNeedsOfFosterParentsAdequatelyAssessed:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item12C.IsNeedsOfFosterParentsAdequatelyAssessed:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25">{Item12C.NeedsOfFosterParentsAdequatelyAssessedExplained}</td>',
        '<td class="w25">{Irr.Item12C.NeedsOfFosterParentsAdequatelyAssessedExplained}</td>',
        '</tr>',


        '<tr>',
        '<td class="w5"><label>C2.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question12C2(true) + '</label></td>',
        '<td class="w25">{Item12C.IsFosterParentsProvidedAppropriateServices:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item12C.IsFosterParentsProvidedAppropriateServices:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25">{Item12C.FosterParentsProvidedAppropriateServicesExplained}</td>',
        '<td class="w25">{Irr.Item12C.FosterParentsProvidedAppropriateServicesExplained}</td>',
        '</tr>',
        '</tpl>',

        '<tr class="item-rating"><td colspan="2">Sub-Item 12C Rating:  </td><td><span> {Item12C.ItemRatingCode:this.getRatingDesc}</span></td><td><span> {Irr.Item12C.ItemRatingCode:this.getRatingDesc}</span></td></tr>',
        '<tr><td colspan="2"><label>Additional Comments: </label></td><td>{Item12C.RatingComments}</td><td>{Irr.Item12C.RatingComments}</td></tr>',
        '<tr class="item-rating"><td colspan="2">Item 12 Rating: </td><td> <span> {Item12.ItemRatingCode:this.getRatingDesc}</span></td><td> <span> {Irr.Item12.ItemRatingCode:this.getRatingDesc}</span></td></tr>',
        '<tr><td colspan="2"><label>Additional Comments: </label></td><td>{Item12.RatingComments}</td><td>{Irr.Item12.RatingComments}</td></tr>',

        // /************************************************ ITEM 13 **************************************************************************/

        '<tr><td colspan="4"class="item">Item 13: Child and Family Involvement in Case Planning</td></tr>',
        '<tr><td colspan="4"><label>Item 13 Applicable Cases:</label></td></tr>',

        '<tr>',
        '<td colspan="2"><label>Cases involving children for whom participating in planning is not developmentally appropriate.</label></td>',
        '<td class="w25">{Item13.Applicability73:this.yesNo}</td>',
        '<td class="w25">{Irr.Item13.Applicability73:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td colspan="2"><label>Parental rights remained terminated during the entire period under review</label></td>',
        '<td class="w25">{Item13.Applicability74:this.yesNo}</td>',
        '<td class="w25">{Irr.Item13.Applicability74:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td colspan="2"><label>Parent’s whereabouts were not known during the entire period under review despite agency efforts to locate the parent</label></td>',
        '<td class="w25">{Item13.Applicability75:this.yesNo}</td>',
        '<td class="w25">{Irr.Item13.Applicability75:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td colspan="2"><label>The Reviewer has determined that Item 12B is rated as an Area Needing Improvement due to lack of concerted efforts to find applicable parents</label></td>',
        '<td class="w25">{Item13.Applicability76:this.yesNo}</td>',
        '<td class="w25">{Irr.Item13.Applicability76:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td colspan="2"><label>Parent was deceased during the entire period under review</label></td>',
        '<td class="w25">{Item13.Applicability77:this.yesNo}</td>',
        '<td class="w25">{Irr.Item13.Applicability77:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td colspan="2"><label>During the entire period under review it was documented in the case file that it was not in the child’s best interests to involve the parent in case planning</label></td>',
        '<td class="w25">{Item13.Applicability78:this.yesNo}</td>',
        '<td class="w25">{Irr.Item13.Applicability78:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td colspan="2"><label>During the entire period under review the parent has indicated he/she does not want to be involved in the child’s life and this was documented in the case file</label></td>',
        '<td class="w25">{Item13.Applicability292:this.yesNo}</td>',
        '<td class="w25">{Irr.Item13.Applicability292:this.yesNo}</td>',
        '</tr>',

        '<tr><td colspan="2"><label>Is this case applicable?</label></td><td class="w25">{Item13.IsApplicable:this.yesNo}</td><td class="w25">{Irr.Item13.IsApplicable:this.yesNo}</td></tr>',
        '<tr><td colspan="2"><label>Optional Comments: </label></td><td>{Item13.Comments}</td><td>{Irr.Item13.Comments}</td></tr>',


        '<tpl if="this.isApplicable(Item13.IsApplicable) || this.isApplicable(Item13.IsApplicable)">',
        '<tr>',
        '<td class="w5"><label>A.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question13A(true) + '</label></td>',
        '<td class="w25">{Item13.IsAgencyConcertedEffortsToInvolveTheChild:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item13.IsAgencyConcertedEffortsToInvolveTheChild:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25">{Item13.AgencyConcertedEffortsToInvolveTheChildExplained}</td>',
        '<td class="w25">{Irr.Item13.AgencyConcertedEffortsToInvolveTheChildExplained}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question13B(true) + '</label></td>',
        '<td class="w25">{Item13.IsAgencyConcertedEffortsToInvolveTheMother:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item13.IsAgencyConcertedEffortsToInvolveTheMother:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25">{Item13.AgencyConcertedEffortsToInvolveTheMotherExplained}</td>',
        '<td class="w25">{Irr.Item13.AgencyConcertedEffortsToInvolveTheMotherExplained}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>C.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question13C(true) + '</label></td>',
        '<td class="w25">{Item13.IsAgencyConcertedEffortsToInvolveTheFather:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item13.IsAgencyConcertedEffortsToInvolveTheFather:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25">{Item13.AgencyConcertedEffortsToInvolveTheFatherExplained}</td>',
        '<td class="w25">{Irr.Item13.AgencyConcertedEffortsToInvolveTheFatherExplained}</td>',
        '</tr>',
        '</tpl>',

        '<tr class="item-rating"><td colspan="2">Item 13 Rating: </td><td><span> {Item13.ItemRatingCode:this.getRatingDesc}</span> </td><td><span> {Irr.Item13.ItemRatingCode:this.getRatingDesc}</span> </td></tr>',
        '<tr><td colspan="2"><label>Additional Comments: </label></td><td>{Item13.RatingComments}</td><td>{Irr.Item13.RatingComments}</td></tr>',

        /************************************************ ITEM 14 **************************************************************************/

        '<tr><td colspan="4"class="item">Item 14: Caseworker Visits With Child</td></tr>',
        '<tr><td colspan="4"><label>Item 14 Applicable Cases:</label></td></tr>',

        '<tr>',
        '<td class="w5"><label>A1.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question14A1(true) + '</label></td>',
        '<td class="w25">{Item14.ResponsiblePartyVisitationFrequencyCode:this.visitationFrequency}</td>',
        '<td class="w25">{Irr.Item14.ResponsiblePartyVisitationFrequencyCode:this.visitationFrequency}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>A.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question14A(true) + '</label></td>',
        '<td class="w25">{Item14.IsResponsiblePartyVisitationFrequencySufficient:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item14.IsResponsiblePartyVisitationFrequencySufficient:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question14B(true) + '</label></td>',
        '<td class="w25">{Item14.IsResponsiblePartyVisitationQualitySufficient:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item14.IsResponsiblePartyVisitationQualitySufficient:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25">{Item14.ResponsiblePartyVisitationQualityExplained}</td>',
        '<td class="w25">{Irr.Item14.ResponsiblePartyVisitationQualityExplained}</td>',
        '</tr>',

        '<tr class="item-rating"><td colspan="2">Item 14 Rating: </td><td><span> {Item14.ItemRatingCode:this.getRatingDesc}</span> </td><td><span> {Irr.Item14.ItemRatingCode:this.getRatingDesc}</span> </td></tr>',
        '<tr><td colspan="2"><label>Additional Comments: </label></td><td>{Item14.RatingComments}</td><td>{Irr.Item14.RatingComments}</td></tr>',

        /************************************************ ITEM 15 **************************************************************************/

        '<tr><td colspan="4"class="item">Item 15: Caseworker Visits With Parents</td></tr>',
        '<tr><td colspan="4"><label>Item 15 Applicable Cases:</label></td></tr>',

        '<tr>',
        '<td colspan="2"><label>Parental rights remained terminated during the entire period under review</label></td>',
        '<td class="w25">{Item15.Applicability79:this.yesNo}</td>',
        '<td class="w25">{Irr.Item15.Applicability79:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td colspan="2"><label>Parent’s whereabouts were not known during the entire period under review despite agency efforts to locate the parent</label></td>',
        '<td class="w25">{Item15.Applicability80:this.yesNo}</td>',
        '<td class="w25">{Irr.Item15.Applicability80:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td colspan="2"><label>The Reviewer has determined that Item 12B is rated as an Area Needing Improvement due to lack of concerted efforts to find applicable parents</label></td>',
        '<td class="w25">{Item15.Applicability81:this.yesNo}</td>',
        '<td class="w25">{Irr.Item15.Applicability81:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td colspan="2"><label>Parent was deceased during the entire period under review</label></td>',
        '<td class="w25">{Item15.Applicability82:this.yesNo}</td>',
        '<td class="w25">{Irr.Item15.Applicability82:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td colspan="2"><label>During the entire period under review it was documented in the case file that it was not in the child’s best interests to involve the parent in case planning</label></td>',
        '<td class="w25">{Item15.Applicability83:this.yesNo}</td>',
        '<td class="w25">{Irr.Item15.Applicability83:this.yesNo}</td>',
        '</tr>',

        '<tr>',
        '<td colspan="2"><label>During the entire period under review the parent has indicated he/she does not want to be involved in the child’s life and this was documented in the case file</label></td>',
        '<td class="w25">{Item15.Applicability293:this.yesNo}</td>',
        '<td class="w25">{Irr.Item15.Applicability293:this.yesNo}</td>',
        '</tr>',

        '<tr><td colspan="2"><label>Is this case applicable?</label></td><td class="w25">{Item15.IsApplicable:this.yesNo}</td><td class="w25">{Irr.Item15.IsApplicable:this.yesNo}</td></tr>',
        '<tr><td colspan="2"><label>Optional Comments: </label></td><td>{Item15.Comments}</td><td>{Irr.Item15.Comments}</td></tr>',

        '<tpl if="this.isApplicable(Item15.IsApplicable) || this.isApplicable(Item15.IsApplicable)">',
        '<tr>',
        '<td class="w5"><label>A1.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question15A1(true) + '</label></td>',
        '<td class="w25">{Item15.ResponsiblePartyVisitationFrequencyWithMotherCode:this.visitationFrequency}</td>',
        '<td class="w25">{Irr.Item15.ResponsiblePartyVisitationFrequencyWithMotherCode:this.visitationFrequency}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>A2.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question15A2(true) + '</label></td>',
        '<td class="w25">{Item15.IsResponsiblePartyVisitationFrequencyWithMotherSufficient:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item15.IsResponsiblePartyVisitationFrequencyWithMotherSufficient:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B1.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question15B1(true) + '</label></td>',
        '<td class="w25">{Item15.ResponsiblePartyVisitationFrequencyWithFatherCode:this.visitationFrequency}</td>',
        '<td class="w25">{Irr.Item15.ResponsiblePartyVisitationFrequencyWithFatherCode:this.visitationFrequency}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B2.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question15B2(true) + '</label></td>',
        '<td class="w25">{Item15.IsResponsiblePartyVisitationFrequencyWithFatherSufficient:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item15.IsResponsiblePartyVisitationFrequencyWithFatherSufficient:this.yesNoNa}</td>',
        '</tr>',


        '<tr>',
        '<td class="w5"><label>C.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question15C(true) + '</label></td>',
        '<td class="w25">{Item15.IsResponsiblePartyVisitationQualityWithMotherSufficient:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item15.IsResponsiblePartyVisitationQualityWithMotherSufficient:this.yesNoNa}</td>',
        '</tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25">{Item15.ResponsiblePartyVisitationQualityWithMotherExplained}</td>',
        '<td class="w25">{Irr.Item15.ResponsiblePartyVisitationQualityWithMotherExplained}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>D.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question15D(true) + '</label></td>',
        '<td class="w25">{Item15.IsResponsiblePartyVisitationQualityWithFatherSufficient:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item15.IsResponsiblePartyVisitationQualityWithFatherSufficient:this.yesNoNa}</td>',
        '</tr>',
        '<td class="w5"></td>',
        '<td class="w45"><label>If No, explain circumstances in the narrative field below.</label></td>',
        '<td class="w25">{Item15.ResponsiblePartyVisitationQualityWithFatherExplained}</td>',
        '<td class="w25">{Irr.Item15.ResponsiblePartyVisitationQualityWithFatherExplained}</td>',
        '</tr>',
        '</tpl>',

        '<tr class="item-rating" ><td colspan="2">Item 15 Rating: </td><td><span> {Item15.ItemRatingCode:this.getRatingDesc}</span> </td><td><span> {Irr.Item15.ItemRatingCode:this.getRatingDesc}</span> </td></tr>',
        '<tr><td colspan="2"><label>Additional Comments: </label></td><td>{Item15.RatingComments}</td><td>{Irr.Item15.RatingComments}</td></tr>',
        '<tr class="outcome-rating"><td colspan="2">Well-Being Outcome 1 Rating:</td><td> {Outcome5RatingCode:this.getOutcomeRatingDesc}</td><td> {Irr.Outcome5RatingCode:this.getOutcomeRatingDesc}</td></tr>',
        '<tr><td colspan="4"></td></tr>',

        /************************************************ ITEM 16 **************************************************************************/

        '<tr><td colspan="4"class="outcome">Well-Being Outcome 2: Children receive appropriate services to meet their educational needs.</td></tr>',
        '<tr><td colspan="4"class="item">Item 16: Educational Needs of the Child</td></tr>',

        '<tr><td colspan="2"><label>Is this case applicable?</label></td><td class="w25">{Item16.IsApplicable:this.yesNo}</td><td class="w25">{Irr.Item16.IsApplicable:this.yesNo}</td></tr>',
        '<tr><td colspan="2"><label>Optional Comments: </label></td><td>{Item16.Comments}</td><td>{Irr.Item16.Comments}</td></tr>',


        '<tpl if="this.isApplicable(Item16.IsApplicable) || this.isApplicable(Irr.Item16.IsApplicable)">',
        '<tr>',
        '<td class="w5"><label>A.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question16A(true) + '</label></td>',
        '<td class="w25">{Item16.IsAgencyAssessEducationNeeds:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item16.IsAgencyAssessEducationNeeds:this.yesNoNa}</td>',
        '</tr>',


        '<tr><td class="w5"><label>A1.</label> </td><td colspan="3"><label>Education Table</label></td></tr>',

        '<tr>',
        '<td colspan="2">',
        '<table cellpadding="0"cellspacing="0"class="child-table">',
        '<tr><th>Educational Needs</th><th>Services Provided</th><th>Services Needed But Not Provided</th></tr>',
        '<tpl for="Item16.Educations">',
        '<tr><td>{Needs}</td><td>{ServicesProvided}</td><td>{ServicesNeededNotProvided}</td></tr>',
        '</tpl>',
        '</table>',
        '</td>',
        '<td colspan="2">',
        '<table cellpadding="0"cellspacing="0"class="child-table">',
        '<tr><th>Educational Needs</th><th>Services Provided</th><th>Services Needed But Not Provided</th></tr>',
        '<tpl for="Irr.Item16.Educations">',
        '<tr><td>{Needs}</td><td>{ServicesProvided}</td><td>{ServicesNeededNotProvided}</td></tr>',
        '</tpl>',
        '</table>',
        '</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question16B(true) + '</label></td>',
        '<td class="w25">{Item16.IsAgencyAddressEducationNeeds:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item16.IsAgencyAddressEducationNeeds:this.yesNoNa}</td>',
        '</tr>',
        '</tpl>',


        '<tr class="item-rating"><td colspan="2">Item 16 Rating:</td><td><span> {Item16.ItemRatingCode:this.getRatingDesc}</span></td><td><span> {Irr.Item16.ItemRatingCode:this.getRatingDesc}</span></td></tr>',
        '<tr><td colspan="2"><label>Additional Comments: </label></td><td>{Item16.RatingComments}</td><td>{Irr.Item16.RatingComments}</td></tr>',
        '<tr class="outcome-rating"><td colspan="2">Well-Being Outcome 2 Rating: </td><td>{Outcome6RatingCode:this.getOutcomeRatingDesc}</td><td>{Irr.Outcome6RatingCode:this.getOutcomeRatingDesc}</td></tr>',
        '<tr><td colspan="4"></td></tr>',

        // /************************************************ ITEM 17 **************************************************************************/

        '<tr><td colspan="4"class="outcome">Children receive adequate services to meet their physical and mental health needs..</td></tr>',
        '<tr><td colspan="4"class="item">Item 17: Physical Health of the Child</td></tr>',
        '<tr><td colspan="2"><label>Is this case applicable?</label></td><td class="w25">{Item17.IsApplicable:this.yesNo}</td><td class="w25">{Irr.Item17.IsApplicable:this.yesNo}</td></tr>',
        '<tr><td colspan="2"><label>Optional Comments: </label></td><td>{Item17.Comments}</td><td>{Irr.Item17.Comments}</td></tr>',

        '<tpl if="this.isApplicable(Item17.IsApplicable) || this.isApplicable(Irr.Item17.IsApplicable)">',
        '<tr>',
        '<td class="w5"><label>A1.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question17A1(true) + '</label></td>',
        '<td class="w25">{Item17.IsAgencyAssessPhysicalHealthNeeds:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item17.IsAgencyAssessPhysicalHealthNeeds:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>A2.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question17A2(true) + '</label></td>',
        '<td class="w25">{Item17.IsAgencyAssessDentalHealthNeeds:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item17.IsAgencyAssessDentalHealthNeeds:this.yesNoNa}</td>',
        '</tr>',


        '<tr>',
        '<td class="w5"><label>A3.</label> </td>',
        '<td colspan="3"><label>Physical and Dental Health Table</label></td>',
        '</tr>',

        '<tr>',
        '<td colspan="2">',
        '<table cellpadding="0"cellspacing="0"class="child-table">',
        '<tr><th>Identified Physical or Dental Health Needs</th><th>Services Provided</th><th>Services Needed But Not Provided</th></tr>',
        '<tpl for="Item17.PhysicalDentalHealthHealths">',
        '<tr><td>{HealthNeeds}</td><td>{ServicesProvided}</td><td>{ServicesNeededNotProvided}</td></tr>',
        '</tpl>',
        '</table>',
        '</td>',
        '<td colspan="2">',
        '<table cellpadding="0"cellspacing="0"class="child-table">',
        '<tr><th>Identified Physical or Dental Health Needs</th><th>Services Provided</th><th>Services Needed But Not Provided</th></tr>',
        '<tpl for="Irr.Item17.PhysicalDentalHealthHealths">',
        '<tr><td>{HealthNeeds}</td><td>{ServicesProvided}</td><td>{ServicesNeededNotProvided}</td></tr>',
        '</tpl>',
        '</table>',
        '</td>',
        '</tr>',


        '<tr>',
        '<td class="w5"><label>A4.</label> </td>',
        '<td colspan="3"><label>' + QuickStart.util.Resources.questions.wellbeing.question17A4(true) + '</label></td>',
        '</tr>',

        '<tr><td class="w5"></td><td class="w45"><label>NA (this is an in-home services case)</label></td><td class="w25">{FosterFederalCaseManagamentCriteria178}</td><td class="w25">{Irr.FosterFederalCaseManagamentCriteria178}</td></tr>',
        '<tr><td class="w5"></td><td class="w45"><label>No evidence found</label></td><td class="w25">{FosterFederalCaseManagamentCriteria178}</td><td class="w25">{Irr.FosterFederalCaseManagamentCriteria178}</td></tr>',
        '<tr><td class="w5"></td><td class="w45"><label>To the extent available and accessible, the child’s health records are up to date and included in the case file [Social Security Act § 475(1)(C)]</label></td><td class="w25">{FosterFederalCaseManagamentCriteria179}</td><td class="w25">{Irr.FosterFederalCaseManagamentCriteria179}</td></tr>',
        '<tr><td class="w5"></td><td class="w45"><label>The case plan addresses the issue of health and dental care needs [Social Security Act § 475(1)(C)]</label></td><td class="w25">{FosterFederalCaseManagamentCriteria180}</td><td class="w25">{Irr.FosterFederalCaseManagamentCriteria180}</td></tr>',
        '<tr><td class="w5"></td><td class="w45"><label>The case plan addresses the issue of health and dental care needs [Social Security Act § 475(1)(C)]</label></td><td class="w25">{FosterFederalCaseManagamentCriteria181}</td><td class="w25">{Irr.FosterFederalCaseManagamentCriteria181}</td></tr>',
        '<tr><td class="w5"></td><td class="w45"><label>To the extent available and accessible, foster parents or foster care providers are provided with the child’s health records [Social Security Act § 475(5)(D)]</label></td><td class="w25">{FosterFederalCaseManagamentCriteria182}</td><td class="w25">{Irr.FosterFederalCaseManagamentCriteria182}</td></tr>',

        '<tr>',
        '<td class="w5"><label>B1.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question17B1(true) + '</label></td>',
        '<td class="w25">{Item17.IsFosterOversightMedicationForPhysicalHealtyAppropriate:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item17.IsFosterOversightMedicationForPhysicalHealtyAppropriate:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B2.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question17B2(true) + '</label></td>',
        '<td class="w25">{Item17.IsAppropriateSerivcesForAllPhysicalHealthNeeds:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item17.IsAppropriateSerivcesForAllPhysicalHealthNeeds:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B3.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question17B3(true) + '</label></td>',
        '<td class="w25">{Item17.IsAppropriateServicesForAllDentalNeeds:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item17.IsAppropriateServicesForAllDentalNeeds:this.yesNoNa}</td>',
        '</tr>',
        '</tpl>',

        '<tr class="item-rating"><td colspan="2">Item 17 Rating: </td><td><span> {Item17.ItemRatingCode:this.getRatingDesc}</span> </td><td><span> {Irr.Item17.ItemRatingCode:this.getRatingDesc}</span> </td></tr>',
        '<tr><td colspan="2"><label>Additional Comments: </label></td><td>{Item17.RatingComments}</td><td>{Irr.Item17.RatingComments}</td></tr>',

        // /************************************************ ITEM 18 **************************************************************************/

        '<tr><td colspan="4"class="item">Item 18: Mental/Behavioral Health of the Child</td></tr>',
        '<tr><td colspan="2"><label>Is this case applicable?</label></td><td class="w25">{Item18.IsApplicable:this.yesNo}</td><td class="w25">{Irr.Item18.IsApplicable:this.yesNo}</td></tr>',
        '<tr><td colspan="2"><label>Optional Comments: </label></td><td>{Item18.Comments}</td><td>{Irr.Item18.Comments}</td></tr>',

        '<tpl if="this.isApplicable(Item18.IsApplicable) || this.isApplicable(Irr.Item18.IsApplicable)">',
        '<tr>',
        '<td class="w5"><label>A.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question18A(true) + '</label></td>',
        '<td class="w25">{Item18.IsAgencyAssessMentalHealthNeeds:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item18.IsAgencyAssessMentalHealthNeeds:this.yesNoNa}</td>',
        '</tr>',

        '<tr><td class="w5"><label>A1.</label></td><td colspan="3"><label>Mental/Behavioral Health Table</label></td></tr>',

        '<tr>',
        '<td colspan="2">',
        '<table cellpadding="0"cellspacing="0"class="child-table">',
        '<tr><th>Identified Mental/Behavioral Health Needs</th><th>Services Provided</th><th>Services Needed But Not Provided</th></tr>',
        '<tpl for="Item18.MentalBehavirolHealths">',
        '<tr><td>{HealthNeeds}</td><td>{ServicesProvided}</td><td>{ServicesNeededNotProvided}</td></tr>',
        '</tpl>',
        '</table>',
        '</td>',
        '<td colspan="2">',
        '<table cellpadding="0"cellspacing="0"class="child-table">',
        '<tr><th>Identified Mental/Behavioral Health Needs</th><th>Services Provided</th><th>Services Needed But Not Provided</th></tr>',
        '<tpl for="Irr.Item18.MentalBehavirolHealths">',
        '<tr><td>{HealthNeeds}</td><td>{ServicesProvided}</td><td>{ServicesNeededNotProvided}</td></tr>',
        '</tpl>',
        '</table>',
        '</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>B.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question18B(true) + '</label></td>',
        '<td class="w25">{Item18.IsFosterOversightMedicationForMentalHealtyAppropriate:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item18.IsFosterOversightMedicationForMentalHealtyAppropriate:this.yesNoNa}</td>',
        '</tr>',

        '<tr>',
        '<td class="w5"><label>C.</label> </td>',
        '<td class="w45"><label>' + QuickStart.util.Resources.questions.wellbeing.question18C(true) + '</label></td>',
        '<td class="w25">{Item18.IsAppropriateSerivcesForMentalHealthNeeds:this.yesNoNa}</td>',
        '<td class="w25">{Irr.Item18.IsAppropriateSerivcesForMentalHealthNeeds:this.yesNoNa}</td>',
        '</tr>',
        '</tpl>',

        '<tr class="item-rating"><td colspan="2">Item 18 Rating:  </td><td><span> {Item18.ItemRatingCode:this.getRatingDesc}</span></td><td><span> {Irr.Item18.ItemRatingCode:this.getRatingDesc}</span></td></tr>',
        '<tr><td colspan="2"><label>Additional Comments: </label></td><td>{Item18.RatingComments}</td><td>{Irr.Item18.RatingComments}</td></tr>',
        '<tr class="outcome-rating"><td colspan="2">Well-Being Outcome 3 Rating: </td><td>{Outcome7RatingCode:this.getOutcomeRatingDesc}</td><td>{Irr.Outcome7RatingCode:this.getOutcomeRatingDesc}</tr>',

        '</table>',

        '</div>',
        {
            title1:function(val){
               return Ext.isEmpty(val) ?'Base Case' : val;
            },
           title2:function(val){
               return Ext.isEmpty(val) ?'IRR Case' : val;
            },
            hasValue: function (val) {
                return !Ext.isEmpty(val)
            },
            isApplicable: function (val) {
                return val == 1;
            },
            isFosterCase: function (val) {
                return val == 20;
            },
            isHomeCase: function (val) {
                return val == 19 || val==21;
            },
            getDate: function (val) {
                if (Ext.isEmpty(val))
                    return '';
                return Ext.Date.format(new Date(val), 'm/d/Y');
            },
            visitationFrequency:function (val) {
                return this.getLookupDataValue('SiblingVisitationFrequency', val, 'medium') || val;
            },
            caseStatusText: function (val) {
                return this.getLookupDataValue('CaseStatus', val, 'large') || val;
            },
            reviewSubType: function (val) {
                return this.getLookupDataValue('CrReviewSubType', val) || val;
            },
            siteCodeText: function (val) {
                return this.getLookupDataValue('Site', val, 'large') || val;
            },
            getUser: function (val) {
                return this.getLookupDataValue('CrSecurityUser', val) || val;
            },
            reviewersText: function (val) {
                if (Ext.isEmpty(val)) return '';
                var names = [];
                Ext.each(val, function (v) {
                    var data = this.getLookupData('CrSecurityUser', v);
                    if (data && !Ext.isEmpty(data.name)) names.push(data.name);
                }, this);
                return names.join(', ');
            },
            permanencyGoal1: function (val) {
                if (Ext.isEmpty(val)) return '';
                var names = [];
                Ext.each(val, function (v) {
                    var data = this.getLookupDataValue('PermanencyGoal1', null, 'large', v);
                    if (data && !Ext.isEmpty(data)) names.push(data);
                }, this);
                return names.join(', ');
            },

            yesNoNa: function (val) {
                return val == 1 ? 'Yes' : val == 2 ? 'No' : val == 3 ? 'NA' : '';
            },
            yesNo: function (val) {
                return val == 1 ? 'Yes' : val == 2 ? 'No' : '';
            },
            getRatingDesc: function (code) {
                return code == 1 ? 'Strength' :
                    code == 2 ? 'Area Needing Improvement' :
                        code == 3 ? 'NA' :
                            code == 4 ? 'Unable to Rate' :
                                code == 5 ? 'Not Applicable' : 'Not Yet Rated';
            },
            getOutcomeRatingDesc: function (code) {
                return code == 1 ? 'Substantially Achieved' :
                    code == 2 ? 'Partially Achieved' :
                        code == 3 ? 'Not Achieved' :
                            code == 4 ? 'NA' :
                                code == 5 ? 'Not Applicable' : 'Not Yet Rated';
            },
            other: function (val) {
                if (!Ext.isEmpty(val))
                    return ' - ' + val;
                return '';
            },

            timeUnit: function (val) {
                return this.getLookupDataValue('TimeUnit', val, 'large') || val;
            },
            livingArrangement: function (val) {
                return this.getLookupDataValue('LivingArrangement', val, 'large') || val;
            },
            placementType: function (val) {
                return this.getLookupDataValue('PlacementType', val, 'large') || val;
            },
            changeReason: function (val) {
                return this.getLookupDataValue('PlacementChangeReason', val, 'large') || val;
            },

            gender: function (val) {
                // return this.getLookupDataValue('Gender', val,'large') || val;
                return val == 1 ? '<span title="Male"class="x-fa fa-male male"></span>' : val == 2 ? '<span title="Female"class="x-fa fa-female female"></span>' : 'Other';
            },
            ethnicity: function (val) {
                return this.getLookupDataValue('Ethnicity', val, 'large') || val;
            },
            disposition: function (val) {
                return this.getLookupDataValue('Disposition', val, 'large') || val;
            },
            priority: function (val) {
                return this.getLookupDataValue('PriorityLevel', parseInt(val), 'large') || val;
            },
            perpetratorChildRelationship: function (val) {
                return this.getLookupDataValue('PerpetratorChildRelationship', val, 'large') || val;
            },

            assessmentType: function (val) {
                return this.getLookupDataValue('AssessmentType', val, 'large') || val;
            },
            race: function (val) {
                return this.getLookupDataValue('Race', val, 'large') || val;
            },
            races: function (val) {
                if (Ext.isEmpty(val)) return '';
                var names = [];
                Ext.each(val, function (v) {
                    var data = this.race(v);
                    if (!Ext.isEmpty(data)) names.push(data);
                }, this);
                return names.join(', ');
            },

            participantRole: function (val) {
                return this.getLookupDataValue('ParticipantRole', val, 'large') || val;
            },
            caseReasons: function (val) {
                if (Ext.isEmpty(val)) return '';
                var names = [];
                Ext.each(val, function (v) {
                    var data = this.getLookupDataValue('CaseReason', v, 'large');
                    if (!Ext.isEmpty(data)) names.push(data);
                }, this);
                return names.join(', ');
            },


            getLookupData: function (group, groupId, code) {
                var store = Ext.getStore('Lookups');
                if (store) {
                    var record = store.queryRecordsBy(function (r) {
                        if (!Ext.isEmpty(code))
                            return r.get('group') === group && r.get('codeId') === code;
                        return r.get('group') === group && r.get('groupId') === groupId;
                    });
                    if (record && record.length > 0) {
                        return record[0].getData();
                    }
                }
                return null;
            },
            getLookupDataValue: function (group, groupId, returnValue, code) {

                if (group == 'ItemRating' && groupId == 4) {
                    return 'Unable to Rate';
                }
                var data = this.getLookupData(group, groupId, code);
                if (data) {
                    return data[returnValue || 'name'] || '';
                }
                return '';
            }
        }
    )

});