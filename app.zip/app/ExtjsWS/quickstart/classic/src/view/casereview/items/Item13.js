/**
 * Created by kkora on 10/12/2017.
 */

Ext.define('QuickStart.view.casereview.items.Item13', {
    extend: 'QuickStart.view.common.BaseItem',
    xtype: 'item13container',

    requires: [
		'Ext.form.*',
		'Ext.layout.container.*'
	],

    routeId: 'item13',
    items: [
        {
            title: 'Item 13: Child and Family Involvement in Case Planning',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.item13(),
            defaults: {
                margin: 10,
                disabledCls: 'disable-item',
                xtype: 'radiogroup',
                labelAlign: 'top',
                layout: 'hbox',
                items: [{
                    boxLabel: 'Yes',
                    inputValue: 1
                }, {
                    boxLabel: 'No',
                    inputValue: 2
                }]
            },
            layout: 'anchor',
            items: [
                {
                    xtype: 'component',
                    html: '<strong> Item 13 Applicable Cases:</strong><br/>'
                },
                {
                    xtype: 'component',
                    html: '<ul><li>Because multiple case participants can be assessed in these questions, consider applicability for all appropriate case participants before determining that the rating should be Not Applicable. ' +
                    'All cases are applicable for an assessment of this item except as determined below (check Yes for criteria that apply and No for those that do not).</li>' +
                    '</ul>'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability73'},
                    bind: {
                        disabled: '{!isFosterCareCase}',
                        value: '{item13Applicability73}'
                    },
                    fieldLabel: 'Cases involving children for whom participating in planning is not developmentally appropriate.'
                },
                {
                    xtype: 'component',
                    html: '<strong> AND:</strong><br/><ul><li>Cases in which all parents being assessed as Mother or Father meet any of these criteria:</li></ul>'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability74'},
                    bind: {
                        disabled: '{!isFosterCareCase}',
                        value: '{item13Applicability74}'
                    }, fieldLabel: 'Parental rights remained terminated during the entire period under review'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability75'},
                    bind: {
                        disabled: '{!isFosterCareCase}',
                        value: '{item13Applicability75}'
                    },
                    fieldLabel: 'Parent’s whereabouts were not known during the entire period under review despite agency efforts to locate the parent'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability292'},
                    bind: {
                        disabled: '{!isFosterCareCase}',
                        value: '{item13Applicability292}'
                    },
                    fieldLabel: 'The Reviewer has determined that Item 12B is rated as an Area Needing Improvement due to lack of concerted efforts to find applicable parents'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability76'},
                    bind: {
                        disabled: '{!isFosterCareCase}',
                        value: '{item13Applicability76}'
                    }, fieldLabel: 'Parent was deceased during the entire period under review'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability77'},
                    bind: {
                        disabled: '{!isFosterCareCase}',
                        value: '{item13Applicability77}'
                    },
                    fieldLabel: 'During the entire period under review it was documented in the case file that it was not in the child’s best interests to involve the parent in case planning'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability78'},
                    bind: {
                        disabled: '{!isFosterCareCase}',
                        value: '{item13Applicability78}'
                    },
                    fieldLabel: 'During the entire period under review the parent has indicated he/she does not want to be involved in the child’s life and this was documented in the case file'
                },
                {
                    xtype: 'component',
                    html: '<ul><li>In-home services cases are applicable even in states that do not require a formal case plan to be developed for in-home services cases. Therefore, the case is applicable even if there is no state requirement for a case plan and there is no case plan in the file.</li></ul>'
                },

                {
                    xtype: 'component',
                    html: '<strong> Select the appropriate response.</strong> If the response is No, the case will be rated as Not Applicable in the ratings section for this sub item.'

                }, {
                    xtype: 'yesnoradiogroup',
                    labelAlign: 'left',
                    name: 'Item13IsApplicable',
                    bind: '{item13IsApplicable}',
                    labelWidth: 200,
                    fieldLabel: 'Is this case applicable?'
                },
                {
                    xtype: 'fieldcontainer',
                    labelAlign: 'top',
                    fieldLabel: 'For in home services cases, indicate the name(s) of the child(ren) who were included in the assessment',
                    layout: 'hbox',
                    defaults: {
                        xtype: 'checkboxgroup', disabledCls: 'disable-item',
                        flex: 1,
                        columns: 1,
                        labelWidth: 75,
                        vertical: true,
                        items: [{}],
                        listeners: {
                            change: 'onItemParticipantChanged'
                        }
                    },
                    bind: {hidden: '{caseReview.Item13IsApplicable != 1  || isFosterCareCase}'},
                    items: [{
                        defaults: {name: 'Item13ParticipantChild', disabledCls: 'disable-item'},
                        name: 'Item13ParticipantChild',
                        itemId: 'item13ParticipantChild'
                    }]
                },
                {
                    xtype: 'component',
                    bind: {hidden: '{caseReview.Item13IsApplicable != 1}'},
                    html: 'Indicate the case participants who are included in this item as Mother and Father'
                },

                {
                    xtype: 'fieldcontainer',
                    labelAlign: 'top',
                    labelSeparator: '',
                    layout: 'hbox',
                    defaults: {
                        xtype: 'checkboxgroup', disabledCls: 'disable-item',
                        flex: 1,
                        columns: 1,
                        labelWidth: 75,
                        vertical: true,
                        items: [{}],
                        listeners: {
                            change: 'onItemParticipantChanged'
                        }
                    },
                    bind: {hidden: '{caseReview.Item13IsApplicable != 1}'},
                    items: [{
                        defaults: {name: 'Item13ParticipantMother'},
                        fieldLabel: 'Mother',
                        name: 'Item13ParticipantMother',
                        itemId: 'item13ParticipantMother',
						bind: { hidden: '{!hasMotherAndOtherParticipant}' }

					}, {
						fieldLabel: 'Mother',
						xtype: 'displayfield',
						value: 'There are no case participants in Face Sheet table G2 that can be assessed as Mother',
						bind: { hidden: '{hasMotherAndOtherParticipant}' }
					}, {
						defaults: { name: 'Item13ParticipantFather' },
						fieldLabel: 'Father',
						name: 'Item13ParticipantFather',
						itemId: 'item13ParticipantFather',
						bind: { hidden: '{!hasFatherAndOtherParticipant}' }
					}, {
						fieldLabel: 'Father',
						xtype: 'displayfield',
						value: 'There are no case participants in Face Sheet table G2 that can be assessed as Father',
						bind: { hidden: '{hasFatherAndOtherParticipant}' }
					}]
                },
                {
                    xtype: 'narrativefield',
                    bind: '{caseReview.Item13Comments}'
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.Item13IsApplicable==""}',
                        html: '{error.Item13IsApplicable}'
                    }
                }]
        },
        {
            title: 'Question 13A',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question13a(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item13IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsAgencyConcertedEffortsToInvolveTheChild',
                bind: {
                    disabled: '{item13ApplicabilityNoChildParticipant}',
                    value: '{isAgencyConcertedEffortsToInvolveTheChild}'
                },
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question13A()
            }, {
                xtype: 'yesnonarrativefield',
                bind: {
                    value: '{caseReview.AgencyConcertedEffortsToInvolveTheChildExplained}',
                    disabled: '{caseReview.IsAgencyConcertedEffortsToInvolveTheChild != 2 }'
                }
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsAgencyConcertedEffortsToInvolveTheChild==""}',
                    html: '{error.IsAgencyConcertedEffortsToInvolveTheChild}'
                }
            }]
        },
        {
            title: 'Question 13B',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question13b(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item13IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsAgencyConcertedEffortsToInvolveTheMother',
                bind: {
                    disabled: '{item13ApplicabilityNoMotherParticipant}',
                    value: '{isAgencyConcertedEffortsToInvolveTheMother}'
                },
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question13B()
            }, {
                xtype: 'yesnonarrativefield',
                bind: {
                    value: '{caseReview.AgencyConcertedEffortsToInvolveTheMotherExplained}',
                    disabled: '{caseReview.IsAgencyConcertedEffortsToInvolveTheMother != 2 }'
                }
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsAgencyConcertedEffortsToInvolveTheMother==""}',
                    html: '{error.IsAgencyConcertedEffortsToInvolveTheMother}'
                }
            }]
        },
        {
            title: 'Question 13C',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question13c(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item13IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsAgencyConcertedEffortsToInvolveTheFather',
                bind: {
                    disabled: '{item13ApplicabilityNoFatherParticipant}',
                    value: '{isAgencyConcertedEffortsToInvolveTheFather}'
                },
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question13C()
            }, {
                xtype: 'yesnonarrativefield',
                bind: {
                    value: '{caseReview.AgencyConcertedEffortsToInvolveTheFatherExplained}',
                    disabled: '{caseReview.IsAgencyConcertedEffortsToInvolveTheFather != 2 }'
                }
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsAgencyConcertedEffortsToInvolveTheFather==""}',
                    html: '{error.IsAgencyConcertedEffortsToInvolveTheFather}'
                }
            }]
        },
        {
            title: 'Item 13 Rating Criteria',
            xtype: 'rating',
            itemId: 'rating13',
            bind: {
				disabled: '{disabledItem}',
				//disabled: '{disabledItem||caseReview.Item13IsApplicable != 1}',
                overrideRatingPermission: '{overrideRatingPermission}',
                rating: '{caseReview.Item13}'
            },
            text: QuickStart.util.Resources.instructions.wellbeing.rating.item13()
        },
        {
            title: 'Item 13 - QA Notes',
            xtype: 'notepanel',
            itemId: 'item13NotePanel',
            noteType: 1,
            itemCode: 17,
            outcomeCode: 5,
            storeName: 'item13NoteStore',
            margin: '0 20 20 0',
            bind: {
                disabled: '{disabledNotes}'
            }
        },
        {
            bind: {
                hidden: '{!allowedInterviewNote}',
                disabled: '{disabledNotes}'
            },
            title: 'Item 13 - Interview Notes',
            xtype: 'notepanel',
            noteType: 2,
            itemCode: 17,
            outcomeCode: 5,
            storeName: 'item13InterviewNoteStore',
            margin: '0 20 20 0'
        }
    ],
    listeners: {
        afterrender: 'onAfterRenderItem13'
    }
});