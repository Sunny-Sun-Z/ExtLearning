/**
 * Created by kkora on 10/19/2017.
 */
Ext.define('QuickStart.view.casereview.wellbeing.Outcome2', {
    extend: 'QuickStart.view.common.InstructionPanel',
    xtype: 'wellbeingoutcome2container',
    routeId: 'wellbeingoutcome2',
    margin: '0 20 20 0',
    title: 'Outcome 2: Children receive appropriate services to meet their educational needs',
    text: QuickStart.util.Resources.instructions.wellbeing.outcome2(),
    defaults: {margin: 10},
    items: [{
        xtype: 'component',
        html: 'What is the level of outcome achievement that best describes the extent to which this outcome is being or has been achieved, based on the rating for item 16?'

    }, {
        xtype: 'displayfield',
        labelWidth: '100%',
        fieldLabel: 'Level of Outcome Achievement',
        bind: '{caseReview.Outcome6.RatingDesc}'
    }, {
        xtype: 'displayfield',
        labelWidth: '100%',
        fieldLabel: 'Outcome Rating Override',
        bind: {
            value: '{caseReview.Outcome6.RatingDesc}',
            hidden: '{caseReview.Outcome6.OverrideRatingDesc==""}'
        }
    }]
});