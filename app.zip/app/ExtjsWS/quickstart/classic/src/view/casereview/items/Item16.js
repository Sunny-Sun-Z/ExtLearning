/**
 * Created by kkora on 10/12/2017.
 */

Ext.define('QuickStart.view.casereview.items.Item16', {
    extend: 'QuickStart.view.common.BaseItem',
    xtype: 'item16container',

    requires: [
        'Ext.form.CheckboxGroup',
        'Ext.layout.container.HBox'
    ],

    routeId: 'item16',
    items: [
        {
            title: 'Item 16: Educational Needs of the Child',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.item16(),
            defaults: {
                margin: 10, disabledCls: 'disable-item'
            },
            layout: 'anchor',
            items: [
                {
                    xtype: 'component',
                    html: '<strong> Item 16 Applicable Cases:</strong><br/>'
                },
                {
                    xtype: 'component',
                    html: '<div class="question-instruction"><ul>' +
                    '<li>All foster care cases involving a school-aged child, including those in pre-school, are applicable for an assessment of this item. If a child is 2 years old or younger and has been identified as having developmental delays, the case may be applicable if the developmental delays need to be addressed through an educational approach rather than through physical therapy or some form of physical health approach. In these latter cases, the issue of developmental delays would be addressed under item 17.</li>' +
                    '<li>Foster care cases are Not Applicable if the child is age 2 or younger and there are no apparent developmental delays.</li>' +
                    '<li>In-home services cases are applicable for an assessment of this item if (1) educational issues are relevant to the reason for the agency’s involvement with the family, and/or (2) it is reasonable to expect that the agency would address educational issues given the circumstances of the case. For example, it is reasonable to expect that the agency would address educational issues in a case in which the child is the subject of a substantiated maltreatment report and, during the period under review, the maltreatment appeared to be affecting the child’s school performance.</li>' +
                    '<li>In-home services cases are Not Applicable for an assessment of this item if the reviewer determines that, during the period under review, there is no reason to expect that the agency would address educational issues for any children in the family, given the reason for agency involvement or the circumstances of the case. This "non-applicability" applies even if there is evidence in the case file that the agency has learned that the parent/caregiver has obtained educational services for the children.</li>' +
                    '</ul></div>'
                },
                {
                    xtype: 'component',
                    html: '<strong> Select the appropriate response.</strong> If the response is No, the case will be rated as Not Applicable in the ratings section for this sub item.'

                },
                {
                    xtype: 'yesnoradiogroup',
                    labelAlign: 'left',
                    name: 'Item16IsApplicable',
                    bind: '{item16IsApplicable}',
                    labelWidth: 200,
                    fieldLabel: 'Is this case applicable?'
                },
                {
                    xtype: 'fieldcontainer',
                    labelAlign: 'top',
                    fieldLabel: 'For in home services cases, indicate the name(s) of the child(ren) who were included in the assessment',
                    layout: 'hbox',
                    defaults: {
                        xtype: 'checkboxgroup', disabledCls: 'disable-item',
                        flex: 1,
                        columns: 1,
                        labelWidth: 75,
                        vertical: true,
                        items: [{}],
                        listeners: {
                            change: 'onItemParticipantChanged'
                        }
                    },
                    bind: {hidden: '{isFosterCareCase || caseReview.Item16IsApplicable != 1}'},
                    items: [{
                        defaults: {name: 'Item16ParticipantChild'},
                        name: 'Item16ParticipantChild',
                        itemId: 'item16ParticipantChild'
                    }]
                },
                {
                    xtype: 'narrativefield',
                    bind: '{caseReview.Item16Comments}'
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.Item16IsApplicable==""}',
                        html: '{error.Item16IsApplicable}'
                    }
                }]
        },
        {
            title: 'Question 16A',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question16a(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item16IsApplicable != 1}'},
            items: [{
                xtype: 'yesnoradiogroup',
                name: 'IsAgencyAssessEducationNeeds',
                bind: '{isAgencyAssessEducationNeeds}',
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question16A()
            }]
        },
        {
            title: 'A1. Education Table',
            xtype: 'educationgrid',
            itemId: 'educationGrid',
            bind: {
                store: '{educationStore}',
                hidden: '{caseReview.Item16IsApplicable != 1}'
            },
            listeners: {
                addrecord: 'onAddEducation',
                editrecord: 'onEditEducation',
                deleterecord: 'onDeleteEducation'
            }

        },
        {
            title: 'Question 16B',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question16b(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item16IsApplicable != 1}'},
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsAgencyAddressEducationNeeds',
                bind: '{isAgencyAddressEducationNeeds}',
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question16B()
            }]
        },
        {
            title: 'Item 16 Rating Criteria',
            xtype: 'rating',
            itemId: 'rating16',
            bind: {
              //  disabled: '{disabledItem|| caseReview.Item16IsApplicable != 1}',
				disabled: '{disabledItem}',
				overrideRatingPermission: '{overrideRatingPermission}',
                rating: '{caseReview.Item16}'
            },
            text: QuickStart.util.Resources.instructions.wellbeing.rating.item16()
        },
        {
            title: 'Item 16 - QA Notes',
            xtype: 'notepanel',
            itemId: 'item16NotePanel',
            noteType: 1,
            itemCode: 20,
            outcomeCode: 6,
            storeName: 'item16NoteStore',
            margin: '0 20 20 0',
            bind: {
                disabled: '{disabledNotes}'
            }
        },
        {
            bind: {
                hidden: '{!allowedInterviewNote}',
                disabled: '{disabledNotes}'
            },
            title: 'Item 16 - Interview Notes',
            xtype: 'notepanel',
            noteType: 2,
            itemCode: 20,
            outcomeCode: 6,
            storeName: 'item16InterviewNoteStore',
            margin: '0 20 20 0'
        }
    ],
    listeners: {
        afterrender: 'onAfterRenderItem16'
    }
});