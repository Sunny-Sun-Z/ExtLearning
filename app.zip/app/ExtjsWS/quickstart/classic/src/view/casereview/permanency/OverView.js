/**
 * Created by kkora on 10/23/2017.
 */
Ext.define('QuickStart.view.casereview.permanency.OverView', {
    extend: 'QuickStart.view.casereview.overview.Panel',

    xtype: 'permanencyoverviewcontainer',
    routeId: 'permanencyoverview',
    title: 'Section II: Permanency',
    margin: '0 20 20 0',
    bind: {data: '{permanencySectionOverview}'}
});