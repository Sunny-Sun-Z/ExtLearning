/**
 * Created by kkora on 9/7/2017.
 */

Ext.define('QuickStart.view.casereview.wellbeing.education.Window', {
    extend: 'QuickStart.view.common.BaseWindow',
    alias: 'widget.educationwindow',
    width: 750,
    layout: 'fit',
     defaults: {
        defaultFocus: 'textfield:not([value]):focusable:not([disabled])',
        defaultButton: 'educationSaveButton'
    },
    bind: {
        title: '{current.educationAction} Education'
    },
    scrollable: 'y',
    items: [
        {
            bodyPadding: '10 10 0 10',
            xtype: 'form',
            scrollable: 'y',
            cls: 'casereview-container',
            defaultType: 'textarea',
            defaults: {
                submitEmptyText: false,
                anchor: '100%',
                labelAlign: 'top',
                maxLength: 500,
                fieldLabel: ' ',
                enforceMaxLength: true,
                allowBlank: false,
                msgTarget: 'side'
            },
            items: [
                {
                    fieldLabel: 'Educational Needs',
                    name: 'Needs',
                    blankText: 'You have not entered any educational needs. Please enter educational needs or enter None.',
                    bind: '{current.education.Needs}'
                },
                {
                    fieldLabel: 'Services Provided',
                    name: 'ServicesProvided',
                    blankText: 'You have not entered any services provided. Please enter services provided or enter None.',
                    bind: '{current.education.ServicesProvided}'
                },
                {
                    fieldLabel: 'Services Needed but Not Provided',
                    name: 'ServicesNeededNotProvided',
                    blankText: 'You have not entered any services needed but not provided. Please enter services needed but not provided or enter None',
                    bind: '{current.education.ServicesNeededNotProvided}'
                }
            ],
            dockedItems: [
                {
                    xtype: 'toolbar',
                    dock: 'bottom',
                    ui: 'footer',
                    items: ['->', {
						text: 'Update & Add More',
						ui: 'soft-green',
						iconCls: 'x-fa fa-save',
						type:'addnew',
						formBind: true,
						handler: 'onSaveEducation'
					}, {
						text: 'Add/Update',
                        ui: 'soft-green',
                        iconCls: 'x-fa fa-save',
                        reference: 'educationSaveButton',
                        formBind: true,
                        handler: 'onSaveEducation'

                    }, {
                        text: 'Cancel',
                        ui: 'gray',
                        iconCls: 'x-fa fa-close',
                        handler: 'onCancelEducation'
                    }]
                }]
        }
    ]

});