/**
 * Created by kkora on 9/12/2017.
 */

Ext.define('QuickStart.view.casereview.newcase.NewCaseController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.newcase',
    errors: [],
    /**
     * Called when the view is created
     */
    init: function () {

    },
    initViewModel: function (vm) {

    },
    isValid: function () {
        var me = this,
            vm = me.getViewModel(),
            record = vm.get('caseReview'),
            data = record.getData(),
            reviewers = data.Reviewers || []
        ;
        me.errors = [];

        if (!Ext.isArray(reviewers) && !Ext.isEmpty(reviewers)) {
            reviewers = [];
            reviewers.push(reviewers);
        }
        var result = reviewers.filter(function (item) {
            return item === data.InitialQAUserID;
        });

        if (result > 0)
            me.errors.push('Same person cannot be selected as Reviewer and Initial QA.');

        result = reviewers.filter(function (item) {
            return item === data.SecondQAUserID;
        });
        if (result > 0)
            me.errors.push('Same person cannot be selected as Reviewer and Second Level QA.');
        else if (data.InitialQAUserID === data.SecondQAUserID)
            me.errors.push('Same person cannot be selected as Initial QA and Second Level QA.');

        result = reviewers.filter(function (item) {
            return item === data.SecondaryOversightUserID;
        });

        if (result > 0)
            me.errors.push('Same person cannot be selected as Reviewer and Secondary Oversight.');
        else if (data.InitialQAUserID === data.SecondaryOversightUserID)
            me.errors.push('Same person cannot be selected as Initial QA and Secondary Oversight.');
        else if (data.SecondQAUserID === data.SecondaryOversightUserID)
            me.errors.push('Same person cannot be selected as Second Level QA and Secondary Oversight.');

        result = reviewers.filter(function (item) {
            return item === data.CtSecondaryOversightUserID;
        });
        if (result > 0)
            me.errors.push('Same person cannot be selected as Reviewer and CT Secondary Oversight.');
        else if (data.InitialQAUserID === data.CtSecondaryOversightUserID)
            me.errors.push('Same person cannot be selected as Initial QA and CT Secondary Oversight.');
        else if (data.SecondQAUserID === data.CtSecondaryOversightUserID)
            me.errors.push('Same person cannot be selected as Second Level QA and CT Secondary Oversight.');
        else if (data.SecondaryOversightUserID === data.CtSecondaryOversightUserID && data.SecondaryOversightUserID != null)
            me.errors.push('Same person cannot be selected as Secondary Oversight and CT Secondary Oversight.');

        return me.errors.length === 0;
    },
    onLoadSampleCase: function (view, sampleReviewId) {
        // console.log('onLoadSampleCase', arguments)
        if (sampleReviewId && sampleReviewId > 0) {
            var me = this,
                vm = me.getViewModel(),
                locationStore = vm.getStore('siteStore'),
                myMask = new Ext.LoadMask({ msg: 'Please wait...', target: view }),
                url = QuickStart.util.Global.getApi() + 'sampling/' + sampleReviewId;

            myMask.show();

            Ext.Ajax.request({
                url: url,
                method: 'GET',
                success: function (response) {
                    myMask.hide();
                    var result = Ext.decode(response.responseText);
                    if (result !== null) {
                        if (result.success) {
                            var officeRecord = locationStore.findRecord('medium', result.data.Office_Name);
                            var siteCode = 0;
                            if (officeRecord && officeRecord.getData())
                                siteCode = officeRecord.getData().code;

                            var sampleCase = Ext.create('QuickStart.model.sampling.SampleCase', result.data).getData();
                            vm.set('caseReview', Ext.create('QuickStart.model.NewCaseReview', { SampleReviewId: sampleCase.ID, CaseID: sampleCase.Case_ID, CaseName: sampleCase.Case_Name, SiteCode: siteCode, ReviewStartDate: sampleCase.PeriodUnderReview, ReviewSubTypeID: sampleCase.Case_Type === 'IH' ? 19 : 20 }));
                            //vm.set('caseReview', Ext.create('QuickStart.model.NewCaseReview', { SampleReviewId: sampleCase.ID, CaseID: sampleCase.Case_ID, CaseName: sampleCase.Case_Name, SiteCode: siteCode, ReviewStartDate: sampleCase.PeriodUnderReview }));
                        }
                        else {
                            Ext.Msg.alert('Status', result.message);
                        }
                    }
                },
                failure: function (response) {
                    myMask.hide();
                    Ext.Msg.alert('Status', "failure");
                    console.log('server-side failure with status code ' + response.status);
                },
                scope: this
            });
        }
    },
    onSaveCase: function (btn) {

        var me = this,
            vm = me.getViewModel(),
            view = me.getView(),
            form = view.down('form').getForm(),
            values = form.getValues(),
            record = vm.get('caseReview'),
            reviewers = record.get('Reviewers')
        ;
        if (!me.isValid()) {
            Ext.Msg.show({
                title: 'Validation',
                message: me.errors.join('<br><br>'),
                buttons: Ext.Msg.OK,
                icon: Ext.Msg.ERROR
            });

            return false;
        }
        if (!Ext.isArray(reviewers)) {
            reviewers = [];
            reviewers.push(record.get('Reviewers'));
        }


        if (!Ext.isEmpty(reviewers)) {

            var revCols = [];
            Ext.each(reviewers, function (rev) {
                revCols.push({
                    CaseReviewID: record.get('CaseReviewID'),
                    UserID: parseInt(rev),
                    DataState: 0
                });
            });
            record.set('CR_Reviewer_Collection', revCols);
        }
        record.set('ReviewSubTypeID', values.ReviewSubTypeID);
        record.set('IsPIPMonitored', values.IsPIPMonitored);
        Ext.Msg.show({
            title: 'Save Case?',
            message: 'You are about to save a case. Be aware that the fields - ' +
            '<strong>Case ID, Office Name, Period Under Review, Type of Case and PIP Monitored </strong> ' +
            '- cannot be modified after saving. <br><br>' +
            'Would you still like to save your changes?',
            buttons: Ext.Msg.YESNO,
            icon: Ext.Msg.QUESTION,
            fn: function (btn) {
                if (btn === 'yes') {
                    me.saveData(record, view);
                }
            }
        });


    },
    onCancelCase: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            record = vm.get('caseReview');
        record.reject();
        window.history.back();
    },
    saveData: function (record, view) {
        var me = this,
            vm = me.getViewModel(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: view || me.getView()}),
            userID = QuickStart.util.Global.getUser().id,
            data = record.getData(),
            url = QuickStart.util.Global.getApi() + 'case/CreateCase';

        delete data.id;
        delete data.Reviewers;
        delete data.FaceSheet;
        delete data.FirstCaseOpeningDate;
        delete data.FosterEntryDate;
        delete data.EpisodeDischargeDate;
        delete data.IsFosterEntryDateNA;
        delete data.IsEpisodeDischargeDateNA;
        delete data.IsEpisodeNotYetDischarged;
        delete data.CaseClosureDate;
        delete data.IsCaseClosureNotClosed;
        delete data.IsCaseOpenReasonOtherAbuseNeglect;
        delete data.CaseReasons;

        myMask.show();

        Ext.Ajax.request({
            url: url,
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            params: {
                userID: QuickStart.util.Global.getUser().id,
                editedItems:'casereview'
            },
            jsonData: data,
            success: function (response, opts) {
                myMask.hide();
                //  debugger
                var result = Ext.decode(response.responseText);

                if (result !== null) {

                    if (result.success  && Ext.isEmpty(result.rule) && !Ext.isEmpty(result.data)) {
                        this.redirectTo('#case/' + result.data.CaseReviewRootID + '/' + result.data.CaseReviewID);
                    }
                    else if (result.success && !Ext.isEmpty(result.rule)) {
                        if(!result.rule.required && !Ext.isEmpty(result.data)){
                            this.redirectTo('#case/' + result.data.CaseReviewRootID + '/' + result.data.CaseReviewID);
                        }
                        QuickStart.util.Global.showRuleErrors(result.rule);
                    }
                    else if(!result.success ){
                        QuickStart.util.Global.showErrors(result.message);
                    }
                }
            },
            failure: function (response, opts) {

                myMask.hide();
                //  debugger
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });
    }
});