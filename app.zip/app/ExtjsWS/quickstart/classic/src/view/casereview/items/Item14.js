/**
 * Created by kkora on 10/12/2017.
 */

Ext.define('QuickStart.view.casereview.items.Item14', {
    extend: 'QuickStart.view.common.BaseItem',
    xtype: 'item14container',
    routeId: 'item14',
    items: [
        {
            title: 'Item 14: Caseworker Visits With Child',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.item14(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [{
                xtype: 'component',
                html: '<strong> Item 14 Applicable Cases:</strong><br/><ul><li>All cases are applicable for an assessment of this item.</li></ul>'
            }]
        },
        {
            title: 'Question 14A1',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question14a1(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [{
                xtype: 'visitationfrequencydiogroup',
                defaults: {name: 'ResponsiblePartyVisitationFrequencyCode', disabledCls: 'disable-item'},
                bind: '{responsiblePartyVisitationFrequencyCode}',
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question14A1()
            }]
        },
        {
            title: 'Question 14A',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question14a(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [{
                xtype: 'yesnoradiogroup',
                name: 'IsResponsiblePartyVisitationFrequencySufficient',
                bind: '{isResponsiblePartyVisitationFrequencySufficient}',
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question14A()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsResponsiblePartyVisitationFrequencySufficient==""}',
                    html: '{error.IsResponsiblePartyVisitationFrequencySufficient}'
                }
            }]
        },
        {
            title: 'Question 14B',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question14b(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsResponsiblePartyVisitationQualitySufficient',
                bind: '{isResponsiblePartyVisitationQualitySufficient}',
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question14B()
            }, {
                xtype: 'yesnonarrativefield',
                bind: {
                    value: '{caseReview.ResponsiblePartyVisitationQualityExplained}',
                    disabled: '{caseReview.IsResponsiblePartyVisitationQualitySufficient != 2 }'
                }
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsResponsiblePartyVisitationQualitySufficient==""}',
                    html: '{error.IsResponsiblePartyVisitationQualitySufficient}'
                }
            }]
        },

        {
            title: 'Item 14 Rating Criteria',
            xtype: 'rating',
            itemId: 'rating14',
            bind: {
				disabled: '{disabledItem}',
				rating: '{caseReview.Item14}'
            },
            text: QuickStart.util.Resources.instructions.wellbeing.rating.item14()
        },
        {
            title: 'Item 14 - QA Notes',
            xtype: 'notepanel',
            itemId: 'item14NotePanel',
            noteType: 1,
            itemCode: 18,
            outcomeCode: 5,
            storeName: 'item14NoteStore',
            margin: '0 20 20 0',
            bind: {
                disabled: '{disabledNotes}'
            }
        },
        {
            bind: {
                hidden: '{!allowedInterviewNote}',
                disabled: '{disabledNotes}'
            },
            title: 'Item 14 - Interview Notes',
            xtype: 'notepanel',
            noteType: 2,
            itemCode: 18,
            outcomeCode: 5,
            storeName: 'item14InterviewNoteStore',
            margin: '0 20 20 0'
        }
    ]
});