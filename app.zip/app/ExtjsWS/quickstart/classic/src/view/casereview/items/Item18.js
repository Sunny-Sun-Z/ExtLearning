/**
 * Created by kkora on 10/12/2018.
 */

Ext.define('QuickStart.view.casereview.items.Item18', {
    extend: 'QuickStart.view.common.BaseItem',
    xtype: 'item18container',

    requires: [
        'Ext.form.CheckboxGroup',
        'Ext.panel.Panel'
    ],

    routeId: 'item18',
    items: [
        {
            title: 'Item 18: Mental/Behavioral Health of the Child',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.item18(),
            defaults: {
                margin: 10
            },
            layout: 'anchor',
            items: [
                {
                    xtype: 'component',
                    html: '<strong> Item 18 Applicable Cases:</strong><br/>'
                },
                {
                    xtype: 'component',
                    html: '<ul>' +
                    '<li>Foster care cases are applicable for an assessment of this item if the reviewer determines that, during the period under review, the child had existing mental/behavioral health needs, including substance abuse issues. If the child had mental/behavioral health issues before the period under review that were adequately addressed and there are no remaining needs during the period under review, the case should be rated as Not Applicable.</li>' +
                    '<li>In-home services cases are applicable for an assessment of this item if (1) mental/behavioral health issues related to any of the children in the family were relevant to the reason for the agency’s involvement with the family, and/or (2) it is reasonable to expect that the agency would address mental/behavioral health issues given the circumstances of the case. For example, it is reasonable to expect that the agency would address mental health issues in a case in which a child is the subject of a substantiated maltreatment report and there is reason to suspect that, during the period under review, the maltreatment may have affected the child’s mental health.</li>' +
                    '<li>In-home services cases are Not Applicable for an assessment of this item if the reviewer determines that there is no reason to expect that, during the period under review, the agency would address mental/behavioral health issues for any children in the family, given the reason for agency involvement or the circumstances of the case. This "non-applicability" applies even if there is evidence in the case file that the agency has learned that the parent is effective in taking care of the children’s mental/behavioral health needs.</li>' +
                    '</ul>'
                },

                {
                    xtype: 'component',
                    html: '<strong> Select the appropriate response.</strong> If the response is No, the case will be rated as Not Applicable in the ratings section for this sub item.'

                }, {
                    xtype: 'yesnoradiogroup',
                    labelAlign: 'left',
                    name: 'Item18IsApplicable',
                    bind: '{item18IsApplicable}',
                    labelWidth: 200,
                    fieldLabel: 'Is this case applicable?'
                },
                {
                    xtype: 'fieldcontainer',
                    labelAlign: 'top',
                    fieldLabel: 'For in home services cases, indicate the name(s) of the child(ren) who were included in the assessment',
                    layout: 'hbox',
                    defaults: {
                        xtype: 'checkboxgroup', disabledCls: 'disable-item',
                        flex: 1,
                        columns: 1,
                        labelWidth: 75,
                        vertical: true,
                        items: [{}],
                        listeners: {
                            change: 'onItemParticipantChanged'
                        }
                    },
                    bind: {hidden: '{isFosterCareCase || caseReview.Item18IsApplicable != 1}'},
                    items: [{
                        defaults: {name: 'Item18ParticipantChild'},
                        name: 'Item18ParticipantChild',
                        itemId: 'item18ParticipantChild'
                    }]
                },
                {
                    xtype: 'narrativefield',
                    bind: '{caseReview.Item18Comments}'
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{caseReview.Item18IsApplicable != 1 || error.Item18IsApplicable==""}',
                        html: '{error.Item18IsApplicable}'
                    }
                }]
        },
        {
            title: 'Question 18A',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question18a(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item18IsApplicable != 1}'},
            items: [{
                xtype: 'yesnoradiogroup',
                name: 'IsAgencyAssessMentalHealthNeeds',
                bind: '{isAgencyAssessMentalHealthNeeds}',
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question18A()
            }]
        },
        {
            xtype: 'panel',
            bind: {hidden: '{caseReview.Item18IsApplicable != 1}'},
            items: [{
                title: 'A1. Mental/Behavioral Health Table',
                xtype: 'mentalhealthgrid',
                itemId: 'mentalHealthGrid',
                bind: {store: '{mentalHealthStore}'},
                listeners: {
                    addrecord: 'onAddMentalHealth',
                    editrecord: 'onEditMentalHealth',
                    deleterecord: 'onDeleteMentalHealth'
                }
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.MentalBehavirolHealths==""}',
                    html: '{error.MentalBehavirolHealths}'
                }
            }]
        },

        {
            title: 'Question 18B',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question18b(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {
                hidden: '{caseReview.Item18IsApplicable != 1}',
                disabled: '{!hasMentalHealthRows}'
            },
            items: [{
                xtype: 'yesnonaradiogroup',
                bind: {
                    disabled: '{!isFosterCareCase}',
                    value: '{isFosterOversightMedicationForMentalHealtyAppropriate}'
                },
                name: 'IsFosterOversightMedicationForMentalHealtyAppropriate',
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question18B()
            }]
        },
        {
            title: 'Question 18C',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.wellbeing.question18c(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {
                hidden: '{caseReview.Item18IsApplicable != 1}',
                disabled: '{!hasMentalHealthRows}'
            },
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsAppropriateSerivcesForMentalHealthNeeds',
                bind: '{isAppropriateSerivcesForMentalHealthNeeds}',
                fieldLabel: QuickStart.util.Resources.questions.wellbeing.question18C()
            }]
        },
        {
            title: 'Item 18 Rating Criteria',
            xtype: 'rating',
            itemId: 'rating18',
            bind: {
                overrideRatingPermission: '{overrideRatingPermission}',
				disabled: '{disabledItem}',
				rating: '{caseReview.Item18}'
               // disabled: '{disabledItem|| !hasMentalHealthRows || caseReview.Item18IsApplicable != 1}'
            },
            text: QuickStart.util.Resources.instructions.wellbeing.rating.item18()
        },
        {
            title: 'Item 18 - QA Notes',
            xtype: 'notepanel',
            itemId: 'item18NotePanel',
            noteType: 1,
            itemCode: 22,
            outcomeCode: 7,
            storeName: 'item18NoteStore',
            margin: '0 20 20 0',
            bind: {
                disabled: '{disabledNotes}'
            }
        },
        {
            bind: {
                hidden: '{!allowedInterviewNote}',
                disabled: '{disabledNotes}'
            },
            title: 'Item 18 - Interview Notes',
            xtype: 'notepanel',
            noteType: 2,
            itemCode: 22,
            outcomeCode: 7,
            storeName: 'item18InterviewNoteStore',
            margin: '0 20 20 0'
        }
    ],
    listeners: {
        afterrender: 'onAfterRenderItem18'
    }
});;