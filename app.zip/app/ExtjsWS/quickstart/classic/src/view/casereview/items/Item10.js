/**
 * Created by kkora on 10/12/2017.
 */


Ext.define('QuickStart.view.casereview.items.Item10', {
    extend: 'QuickStart.view.common.BaseItem',
    xtype: 'item10container',
    routeId: 'item10',
    items: [
        {
            title: 'Item 10: Relative Placement',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.item10(),
            defaults: {margin: 10},
            layout: 'anchor',
            items: [{
                xtype: 'component',
                html: '<strong> Item 10 Applicable Cases:</strong><br/>' +
                '<ul><li>All foster care cases are applicable for assessment of this item except those in which (1) the agency determined upon the child’s initial entry into care that his or her needs required a specialized placement (such as residential treatment services) and that they will continue to require such specialized treatment the entire time the child is in care and a relative placement would be inappropriate, or (2) situations such as abandonment in which the identity of both parents and all relatives remains unknown despite documented concerted efforts to identify them</li></ul>'
            }, {
                xtype: 'component',
                html: '<strong> Select the appropriate response.</strong> If the response is No, the case will be rated as Not Applicable in the ratings section for this item.'

            }, {
                xtype: 'yesnoradiogroup',
                labelAlign: 'left',
                labelWidth: 200,
                name: 'Item10IsApplicable',
                bind: '{item10IsApplicable}',
                fieldLabel: 'Is this case applicable?'
            }, {
                xtype: 'narrativefield',
                bind: '{caseReview.Item10Comments}'
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.Item10IsApplicable==""}',
                    html: '{error.Item10IsApplicable}'
                }
            }]
        },
        {
            title: 'Question 10A1',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question10a1(),
            //  titleAlign: 'center',
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {
                hidden: '{caseReview.Item10IsApplicable != 1}',
                disabled: '{!hasPlacementRows}'
            },
            items: [{
                xtype: 'yesnoradiogroup',
                name: 'IsRecentPlacementWithRelative',
                bind: '{isRecentPlacementWithRelative}',
                fieldLabel: QuickStart.util.Resources.questions.permanency.question10A1()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsRecentPlacementWithRelative==""}',
                    html: '{error.IsRecentPlacementWithRelative}'
                }
            }]
        },
        {
            title: 'Question 10A2',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question10a2(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {
                hidden: '{caseReview.Item10IsApplicable != 1}',
                disabled: '{!hasPlacementRows}'
            },
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsPlacementWithRelativeStable',
                bind: '{isPlacementWithRelativeStable}',
                fieldLabel: QuickStart.util.Resources.questions.permanency.question10A2()
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsPlacementWithRelativeStable==""}',
                    html: '{error.IsPlacementWithRelativeStable}'
                }
            }]
        },
        {
            title: 'Question 10B',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question10b(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {
                hidden: '{caseReview.Item10IsApplicable != 1}',
                disabled: '{!hasPlacementRows}'
            },
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsConcertedEffortToLocateMaternalRelatives',
                bind: '{isConcertedEffortToLocateMaternalRelatives}',
                fieldLabel: QuickStart.util.Resources.questions.permanency.question10B()
            }, {
                xtype: 'checkboxgroup',
                itemId: 'motherEfforts',
                disabledCls: 'disable-item',
                defaults: {margin: '0 10 0 0', name: 'PlacementEffortConcernsMother'},
                labelAlign: 'top',
                layout: 'hbox',
                bind: {
                    value: '{placementEffortConcernsMother}',
                    disabled: '{isConcertedEffortToLocateMaternalRelatives.IsConcertedEffortToLocateMaternalRelatives != 2}'
                },
                items: [
                    {boxLabel: 'Identify', inputValue: 156},
                    {boxLabel: 'Locate', inputValue: 157},
                    {boxLabel: 'Inform', inputValue: 158},
                    {boxLabel: 'Evaluate', inputValue: 159}
                ],
                fieldLabel: 'If No, specify the area in which concerns existed'
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsConcertedEffortToLocateMaternalRelatives==""}',
                    html: '{error.IsConcertedEffortToLocateMaternalRelatives}'
                }
            }]
        },
        {
            title: 'Question 10C',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.permanency.question10c(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {
                hidden: '{caseReview.Item10IsApplicable != 1}',
                disabled: '{!hasPlacementRows}'
            },
            items: [{
                xtype: 'yesnonaradiogroup',
                name: 'IsConcertedEffortToLocatePaternalRelatives',
                bind: '{isConcertedEffortToLocatePaternalRelatives}',
                fieldLabel: QuickStart.util.Resources.questions.permanency.question10C()
            }, {
                xtype: 'checkboxgroup',
                itemId: 'fatherEfforts', //Was motherEfforts. Cannot have non-unique itemIds. Changed by hlawrence 2/1/2018.
                defaults: {margin: '0 10 0 0', name: 'PlacementEffortConcernsFather'},
                labelAlign: 'top',
                disabledCls: 'disable-item',
                layout: 'hbox',
                bind: {
                    value: '{placementEffortConcernsFather}',
                    disabled: '{isConcertedEffortToLocatePaternalRelatives.IsConcertedEffortToLocatePaternalRelatives != 2}'
                },
                items: [
                    {boxLabel: 'Identify', inputValue: 160},
                    {boxLabel: 'Locate', inputValue: 161},
                    {boxLabel: 'Inform', inputValue: 162},
                    {boxLabel: 'Evaluate', inputValue: 163}
                ],
                fieldLabel: 'If No, specify the area in which concerns existed'
            }, {
                xtype: 'component',
                cls: 'error-msg',
                bind: {
                    hidden: '{error.IsConcertedEffortToLocatePaternalRelatives==""}',
                    html: '{error.IsConcertedEffortToLocatePaternalRelatives}'
                }
            }]
        },
        {
            title: 'Item 10 Rating Criteria',
            xtype: 'rating',
            itemId: 'rating10',
            bind: {
              //  disabled: '{disabledItem ||!hasPlacementRows || caseReview.Item10IsApplicable != 1}',
				disabled: '{disabledItem}',
				overrideRatingPermission: '{overrideRatingPermission}',
                rating: '{caseReview.Item10}'
            },
            text: QuickStart.util.Resources.instructions.permanency.rating.item10()
        },
        {
            title: 'Item 10 - QA Notes',
            xtype: 'notepanel',
            itemId: 'item10NotePanel',
            noteType: 1,
            itemCode: 11,
            outcomeCode: 4,
            storeName: 'item10NoteStore',
            margin: '0 20 20 0',
            bind: {
                disabled: '{disabledNotes}'
            }
        },
        {
            bind: {
                hidden: '{!allowedInterviewNote}',
                disabled: '{disabledNotes}'
            },
            title: 'Item 10 - Interview Notes',
            xtype: 'notepanel',
            itemCode: 11,
            noteType: 2,
            outcomeCode: 4,
            storeName: 'item10InterviewNoteStore',
            margin: '0 20 20 0'
        }
    ]
});