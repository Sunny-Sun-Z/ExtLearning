/**
 * Created by kkora on 10/16/2017.
 */

Ext.define('QuickStart.view.casereview.items.Item2', {
    extend: 'QuickStart.view.common.BaseItem',
    xtype: 'item2container',
    routeId: 'item2',


    items: [
        {
            title: 'Item 2:Services to Family to Protect Child(ren) in the Home and Prevent Removal or Re-Entry Into Foster Care',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.safety.outcome2Item2(),
            defaults: {
                margin: 10,
                xtype: 'radiogroup',
                disabledCls: 'disable-item',
                labelAlign: 'top',
                layout: 'hbox',
                defaults:{ disabledCls: 'disable-item'},
                items: [
                    {boxLabel: 'Yes', inputValue: 1},
                    {boxLabel: 'No', inputValue: 2}
                ]
            },
            layout: 'anchor',
            items: [
                {
                    xtype: 'component',
                    html: '<strong> Item 2 Applicable Cases:</strong><br/><ul><li>In the list of criteria below, check Yes for any that apply and No for any that do not apply. A case is applicable for an assessment of this item if it meets at least one of the following criteria:</li></ul>'
                },
                {
                    margin: '0 0 0 50',
                    bind: {
                        disabled: '{isFosterCareCase}',
                        value: '{item2Applicability51}'
                    },
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability51'},
                    fieldLabel: 'It is an in-home services case and the reviewer determines that there are concerns regarding the safety of at least one child in the family during the period under review'
                },
                {
                    margin: '0 0 0 50',
                    bind: {
                        disabled: '{isFosterCareCase}',
                        value: '{item2Applicability52}'
                    },
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability52'},
                    fieldLabel: 'It is an in-home services case and services were provided for children at risk of foster care placement to remain safely in their homes'
                },
                {
                    margin: '0 0 0 50',
                    bind: {
                        disabled: '{isHomeServiceCase|| isFosterCareCase && caseReview.FosterEntryDate < caseReview.ReviewStartDate}',
                        value: '{item2Applicability53}'
                    },
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability53'},
                    fieldLabel: 'It is a foster care case and the child entered foster care during the period under review due to safety concerns'
                },
                {
                    margin: '0 0 0 50',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability54'},
                    bind: {
                        disabled: '{isHomeServiceCase}',
                        value: '{item2Applicability54}'
                    },
                    fieldLabel: 'It is a foster care case and the child was reunified during the period under review or was returned home on a trial basis, and the reviewer determines that there are concerns regarding the safety of that child in the home'
                },
                {
                    margin: '0 0 0 50',
                    bind: {
                      //  disabled: '{ (isHomeServiceCase && caseReview.ItemApplicability55 != null)|| isFosterCareCase && caseReview.ItemApplicability55 != null && (caseReview.EpisodeDischargeDate != null || (caseReview.FosterEntryDate > caseReview.ReviewStartDate && caseReview.FosterEntryDate < caseReview.ReviewCompleted))}',
                        disabled:'{item2Applicability55Disabled}',
                        value: '{item2Applicability55}'
                    },
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability55'},
                    fieldLabel: 'It is a foster care case, and although the target child entered foster care before the period under review and remained in care for the entire period under review, there are other children in the home and the reviewer determines that there are concerns regarding the safety of those children during the period under review'
                },
                {
                    xtype: 'component',
                    html: '<ul><li>However, a case is not applicable for an assessment of this item if it meets the following criterion, even if the case is applicable based on the criteria above:</li></ul>'
                },
                {
                    margin: '0 0 0 50',
                    bind: '{item2Applicability56}',
                    defaults: {margin: '0 10 0 0', name: 'ItemApplicability56'},
                    fieldLabel: 'Only a safety plan was needed to ensure the child(ren)\'s safety and no safety-related services were necessary based on the circumstances of the case. (In this situation, item 2 would be Not Applicable and the safety plan would be assessed in item 3.)'
                },
                {
                    xtype: 'component',
                    html: '<strong> Select the appropriate response.</strong> If the response is No, the case will be rated as Not Applicable in the ratings section for this item.'

                }, {
                    xtype: 'yesnoradiogroup',
                    name: 'Item2IsApplicable',
                    bind: '{item2IsApplicable}',
                    labelWidth: 200,
                    labelAlign: 'left',
                    fieldLabel: 'Is this case applicable?'
                }, {
                    xtype: 'narrativefield',
                    bind: '{caseReview.Item2Comments}'
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.Item2IsApplicable==""}',
                        html: '{error.Item2IsApplicable}'
                    }
                }
            ]
        },
        {
            title: 'Question 2A',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.safety.question2a(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item2IsApplicable != 1}'},
            items: [
                {
                    xtype: 'yesnoradiogroup',
                    name: 'IsEffortToPreventReEntry',
                    bind: '{isEffortToPreventReEntry}',
                    fieldLabel: QuickStart.util.Resources.questions.safety.question2A()
                }, {
                    xtype: 'yesnonarrativefield',
                      bind: {
                         value: '{caseReview.EffortToPreventReEntryExplained}',
                         disabled: '{caseReview.IsEffortToPreventReEntry != 2 }'
                    }
                }]
        },
        {
            title: 'Question 2B',
            xtype: 'instructionpanel',
            text: QuickStart.util.Resources.instructions.safety.question2b(),
            defaults: {margin: 10},
            layout: 'anchor',
            bind: {hidden: '{caseReview.Item2IsApplicable != 1}'},
            items: [
                {
                    xtype: 'yesnonaradiogroup',
                    name: 'IsChildRemovedToEnsureSafety',
                    bind: {
                        value: '{isChildRemovedToEnsureSafety}',
                        disabled: '{!isFosterCareCase}'
                    },
                    fieldLabel: QuickStart.util.Resources.questions.safety.question2B()
                }, {
                    xtype: 'yesnonarrativefield',
                    bind: {
                        value: '{caseReview.ChildRemovedToEnsureSafetyExplained}',
                        disabled: '{caseReview.IsChildRemovedToEnsureSafety != 2}'
                    }
                }, {
                    xtype: 'component',
                    cls: 'error-msg',
                    bind: {
                        hidden: '{error.IsChildRemovedToEnsureSafety==""}',
                        html: '{error.IsChildRemovedToEnsureSafety}'
                    }
                }]
        },
        {
            title: 'Item 2 Rating Criteria',
            xtype: 'rating',
            itemId: 'rating2',
            bind: {
               // disabled: '{caseReview.Item2IsApplicable != 1}',
				disabled: '{disabledItem}',
				rating: '{caseReview.Item2}'//, overrideRatingPermission: '{overrideRatingPermission}'
            },
            text: QuickStart.util.Resources.instructions.safety.item2Rating()
        },
        {
            title: 'Safety - Item 2 - QA Notes',
            xtype: 'notepanel',
            itemId: 'item2NotePanel',
            noteType: 1,
            itemCode: 3,
            outcomeCode: 2,
            storeName: 'item2NoteStore',
            margin: '0 20 20 0',
            bind: {
                disabled: '{disabledNotes}'
            }
        },
        {
            bind: {
                hidden: '{!allowedInterviewNote}',
                disabled: '{disabledNotes}'
            },
            title: 'Safety - Item 2 - Interview Notes',
            xtype: 'notepanel',
            noteType: 2,
            itemCode: 3,
            outcomeCode: 2,
            storeName: 'item2InterviewNoteStore',
            margin: '0 20 20 0'
        }
    ]
});