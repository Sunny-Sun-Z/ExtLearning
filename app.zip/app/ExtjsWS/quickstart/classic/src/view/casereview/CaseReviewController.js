/**
 * Created by kkora on 9/6/2017.
 */

Ext.define('QuickStart.view.casereview.CaseReviewController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.casereview',
    mixins: [
        'QuickStart.mixins.Global',
        'QuickStart.view.mixins.Note',
        'QuickStart.view.mixins.FaceSheet',
        'QuickStart.view.mixins.Safety',
        'QuickStart.view.mixins.Permanency',
        'QuickStart.view.mixins.WellBeing',
        'QuickStart.view.mixins.ItemStatus',
        'QuickStart.view.mixins.ExportImport'
    ],
    requires: [
        'Ext.form.field.Checkbox',
        'QuickStart.model.CaseReview'
        // ,'Ext.exporter.text.CSV',
        // 'Ext.exporter.text.TSV',
        // 'Ext.exporter.text.Html',
        // 'Ext.exporter.excel.Xml',
        // 'Ext.exporter.excel.Xlsx'
    ],
    errors: [],

    exportTo: function (btn) {

        var cfg = Ext.merge({
            title: 'Grid export demo',
            fileName: 'GridExport' + '.' + (btn.cfg.ext || btn.cfg.type)
        }, btn.cfg);

        // this.getView().saveDocumentAs(cfg);
        btn.up('grid').saveDocumentAs(cfg);
    },

    onBeforeDocumentSave: function (view) {
        this.timeStarted = Date.now();
        view.mask('Document is prepared for export. Please wait ...');
        Ext.log('export started');
    },

    onDocumentSave: function (view) {
        view.unmask();
        Ext.log('export finished; time passed = ' + (Date.now() - this.timeStarted));
    },

    onDataReady: function () {
        Ext.log('data ready; time passed = ' + (Date.now() - this.timeStarted));
    },

	/**
	 * Called when the view is created
	 */
    init: function () {
    },

    onTreeItemSelectionChange: function (tree, record, opt) {

        var panelContainer = tree.up('container').down('#panelContainer'),
            h = 0;
        if (!panelContainer)
            return;
        var panel = panelContainer.down('#' + record.get('refId'));

        for (var i = 0; panelContainer.items.length; i++) {
            var p = panelContainer.items.items[i];
            if (p.getItemId() === panel.getItemId()) {
                break;
            }
            h += p.getHeight();
        }
        panelContainer.scrollTo('top', 0);
        panelContainer.scrollBy(0, h, true);


    },

    onSwitchCaseReviewLayout: function (btn) {
        var caseContainer = this.lookupReference('caseContainer');
        caseContainer.setLayout(btn.type);
        caseContainer.suspendLayout = false;
        caseContainer.updateLayout();
        caseContainer.suspendLayout = true;
    },

    onAfterRenderCaseReview: function (tab) {

        var vm = this.getViewModel();
        // vm.set('current.review',record);
        var store = vm.getStore('noteStore');
        if (store)
            console.log(store.getRange())
        //  var record = Ext.create('QuickStart.model.CaseReview', {id: 1000});

        // record.load({
        //     success: function (rec) {
        //         console.log(rec.getId()); //logs 123
        //     }
        // });
        // var cf=tab.down('#questionM');
        // cf.setValue({questionM:[1,2,3]})
    },

    onCaseItemClick: function (btn) {
        //   console.log(btn.text)

        var me = this,
            vm = me.getViewModel(),
            editedItems = vm.get('editedItems') || [],
            refs = me.getReferences(),
            caseContainer = refs.caseContainer,
            caseLayout = caseContainer.getLayout(),
            lastView = me.lastView,
            category = btn.getCategory(),
            existingItem = caseContainer.child('component[routeId=' + category + ']'),
            view = category + 'container',
            newView;

        // Kill any previously routed window
        // if (lastView && lastView.isWindow) {
        //     lastView.destroy();
        // }
        lastView = caseLayout.getActiveItem();
        vm.set('isCaseNote', view === 'caseqanotescontainer');
        if (!existingItem) {
            newView = Ext.create({
                xtype: view,
                routeId: btn.getCategory(),  // for existingItem search later
                hideMode: 'offsets'
            });
        }
        if (!newView || !newView.isWindow) {
            // !newView means we have an existing view, but if the newView isWindow
            // we don't add it to the card layout.
            if (existingItem) {
                // We don't have a newView, so activate the existing view.
                if (existingItem !== lastView) {
                    caseLayout.setActiveItem(existingItem);
                }
                newView = existingItem;
            }
            else {
                // newView is set (did not exist already), so add it and make it the
                // activeItem.
                Ext.suspendLayouts();
                caseLayout.setActiveItem(caseContainer.add(newView));
                Ext.resumeLayouts(true);
            }
        }

        if (newView.isFocusable(true)) {
            newView.focus();
        }
        //debugger;
        if (newView.setRecord) {
            newView.setRecord(vm.get('caseReview'));
        }
        me.lastView = newView;

        btn.setPressed(true);
        caseContainer.scrollTo('top', 0);
        caseContainer.scrollBy(0, 0, true);
        editedItems.push(category);
        vm.set('editedItems', editedItems);

        me.highlightedUnresolvedTab();

    },
    clearCaseItemsContainer: function (currentRootId, lastRootId) {
        var me = this,
            vm = me.getViewModel(),
            refs = me.getReferences(),
            caseContainer = refs.caseContainer,
            caseLayout = caseContainer.getLayout(),
            lastView = caseLayout.getActiveItem(),
            existingItem = caseContainer.child("component[routeId='facesheet']")
            ;

        if (caseContainer.items.length > 0) {
            Ext.suspendLayouts();
            if (existingItem)
                caseLayout.setActiveItem(existingItem);

            for (var index = 0; index < caseContainer.items.length; index++) {
                var item = caseContainer.items.items[index];
                //  if (item && item.xtype !== "facesheetcontainer" && lastView && item.xtype !== lastView.xtype) {
                //if (item && item.xtype !== "facesheetcontainer") {
                if (item) {
                    caseContainer.remove(item);
                    index--;
                }
            }
            if (currentRootId === lastRootId && existingItem !== lastView) {
                caseLayout.setActiveItem(caseContainer.add(Ext.create({
                    xtype: lastView.xtype,
                    routeId: lastView.routeId,  // for existingItem search later
                    hideMode: 'offsets'
                })));
            }
            else {
                //console.log('caseContainer.items.length', caseContainer.items.length)
                caseLayout.setActiveItem(caseContainer.add(Ext.create({
                    xtype: "facesheetcontainer",
                    routeId: "facesheet",
                    hideMode: 'offsets'
                })));
            }
            Ext.resumeLayouts(true);
        }
    },
    onCaseSetup: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            editedItems = vm.get('editedItems') || [],
            win = me.getView().down('#casereviewSetupWindow'),
            form = win.down('form').getForm()
            ;
        win.show(btn);
        editedItems.push('casereview');
        vm.set('editedItems', editedItems);

    },

    onCaseEliminate: function (btn) {

        var me = this,
            vm = me.getViewModel(),
            win = me.getView().down('#eliminateWindow'),
            form = win.down('form').getForm()
            ;
        //    form.reset();
        win.show(btn);

        vm.set('current.elimination', Ext.create('QuickStart.model.casereview.Elimination'));
    },

    onApproveCaseEliminate: function (btn) {

        var me = this,
            vm = me.getViewModel(),
            win = me.getView().down('#eliminateWindow'),
            form = win.down('form').getForm(),
            values = form.getValues(),
            record = vm.get('caseReview')

            ;

        if (record) {
            record.set('CaseStatusCode', 6);
            record.set('EliminationReasonCode', values.EliminationReasonCode);
            record.set('EliminationReasonExplained', values.EliminationReasonExplained);

            me.saveData(record, win);
        }

    },


    onLoadCase: function (view, caseReviewRootId, caseReviewId) {
        // console.log('onLoadCase', arguments)

        var me = this,
            vm = me.getViewModel(),
            isCaseImported = vm.get('isCaseImported'),
            readOnlyPanel = me.getView().down('#readOnlyPanel'),
            myMask = new Ext.LoadMask({ msg: 'Please wait...', target: view }),
            url = QuickStart.util.Global.getApi() + 'case/GetData';

        //var btn = me.getView().down('#facesheet');
        var btn = me.getView().down('component[category=facesheet]');
        if (btn) {
            btn.setPressed(true);
        }

        myMask.show();

        Ext.Ajax.request({
            url: url,
            method: 'GET',
            //headers: {'Content-Type': 'application/json'},
            params: {
                caseReviewRootId: caseReviewRootId,
                caseReviewId: caseReviewId,
                userID: QuickStart.util.Global.getUser().id
            },
            success: function (response, opts) {
                myMask.hide();
                var result = Ext.decode(response.responseText);

                if (result !== null) {
                    if (!Ext.isEmpty(result.data)) {
                        var noteStore = vm.getStore('noteStore');
                        if (noteStore) {
                            noteStore.removeAll();
                        }

                        var userId = QuickStart.util.Global.getUser().id;
                        var record = Ext.create('QuickStart.model.CaseReview', result.data);
                        record.commit();
                        vm.set('caseReview', record);

                        me.activeCaseStatusItem(record.get('CaseStatusCode'));
                        me.updateNumberStore(record);
                        vm.set('editedItems', ['facesheet']);

                        var flag = (record && (record.get('CaseStatusCode') === 6 || record.get('CaseStatusCode') === 7 || record.get('CaseStatusCode') === 8))

                        if (!flag) {
                            flag = !(
                                (QuickStart.util.Global.permissions.allowEditIRRCase() && vm.hasUserInCaseReview(userId)) ||
                                (QuickStart.util.Global.permissions.allowEditCaseData() && vm.hasUserInCaseReview(userId)) ||
                                (QuickStart.util.Global.permissions.allowAddEditQANote() && vm.hasUserInCaseReview(userId))
                            );
                        }
                        vm.set('caseReview.DisabledCase', flag);
                        vm.set('caseReview.DisabledNotes', flag);

                        readOnlyPanel.setHidden(!flag);
                        //	console.log('isCaseImported',isCaseImported)
                        //	readOnlyPanel.setTitle(isCaseImported ? "READ ONLY CASE - (CASE IMPORTED)" : "READ ONLY CASE")

                        //default container facesheet should be loaded here whenever new record comes
                        //remove other items from container
                        me.clearCaseItemsContainer(vm.get('caseReview.CaseReviewRootID'), vm.get('lastCaseReviewRootID'));
                        vm.set('lastCaseReviewRootID', record.get('CaseReviewRootID'));

                        vm.set('caseReview.TS_CR', new Date());
                        record.commit();
                        vm.set('caseReviewOriginalState', Ext.clone(record.getData()));
                        vm.set('ratingItems', null);
                        // console.log(record.getData())

                        Ext.defer(function () {
                            me.highlightedUnresolvedTab();
                        }, 500, this);

                    }
                }
            },
            failure: function (response, opts) {

                myMask.hide();
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });

    },

    isValid: function () {
        var me = this,
            vm = me.getViewModel(),
            record = vm.get('caseReview'),
            data = record.getData(),
            reviewers = data.Reviewers || []
            ;
        me.errors = [];

        if (!Ext.isArray(reviewers) && !Ext.isEmpty(reviewers)) {
            reviewers = [];
            reviewers.push(reviewers);
        }
        var result = reviewers.filter(function (item) {
            return item === data.InitialQAUserID;
        });

        if (result > 0)
            me.errors.push('Same person cannot be selected as Reviewer and Initial QA');

        result = reviewers.filter(function (item) {
            return item === data.SecondQAUserID;
        });
        if (result > 0)
            me.errors.push('Same person cannot be selected as Reviewer and Second Level QA');
        else if (data.InitialQAUserID === data.SecondQAUserID)
            me.errors.push('Same person cannot be selected as Initial QA and Second Level QA');

        result = reviewers.filter(function (item) {
            return item === data.SecondaryOversightUserID;
        });

        if (result > 0)
            me.errors.push('Same person cannot be selected as Reviewer and Secondary Oversight');
        else if (data.InitialQAUserID === data.SecondaryOversightUserID)
            me.errors.push('Same person cannot be selected as Initial QA and Secondary Oversight');
        else if (data.SecondQAUserID === data.SecondaryOversightUserID)
            me.errors.push('Same person cannot be selected as Second Level QA and Secondary Oversight');

        result = reviewers.filter(function (item) {
            return item === data.CtSecondaryOversightUserID;
        });
        if (result > 0)
            me.errors.push('Same person cannot be selected as Reviewer and CT Secondary Oversight');
        else if (data.InitialQAUserID === data.CtSecondaryOversightUserID)
            me.errors.push('Same person cannot be selected as Initial QA and CT Secondary Oversight');
        else if (data.SecondQAUserID === data.CtSecondaryOversightUserID)
            me.errors.push('Same person cannot be selected as Second Level QA and CT Secondary Oversight');
        else if (data.SecondaryOversightUserID === data.CtSecondaryOversightUserID && data.SecondaryOversightUserID != null)
            me.errors.push('Same person cannot be selected as Secondary Oversight and CT Secondary Oversight');

        return me.errors.length === 0;


    },

    onSaveCase: function (btn) {
        console.log('onSaveCase');
        var me = this,
            vm = me.getViewModel(),
            view = me.getView(),
            win = btn.up('window'),
            record = vm.get('caseReview'),
            reviewers = record.get('Reviewers')
            ;
        if (!me.isValid()) {
            Ext.Msg.show({
                title: 'Validation',
                message: me.errors.join('<br><br>'),
                buttons: Ext.Msg.YES,
                icon: Ext.Msg.ERROR
            });

            return false;
        }
        if (!Ext.isArray(reviewers)) {
            reviewers = [];
            reviewers.push(record.get('Reviewers'));
        }


        if (!Ext.isEmpty(reviewers)) {

            var revCols = [];
            Ext.each(reviewers, function (rev) {
                revCols.push({
                    CaseReviewID: record.get('CaseReviewID'),
                    UserID: parseInt(rev),
                    DataState: 0
                });
            });
            record.set('CR_Reviewer_Collection', revCols);
        }
        if (win)
            view = win;
        me.saveData(record, view);

    },

    onCaseUpdate: function (btn) {
        //  console.log('onCaseUpdate')
        var me = this,
            vm = me.getViewModel(),
            view = me.getView(),
            record = vm.get('caseReview');

        me.saveData(record, view, btn === true);
    },

    onCancelCase: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            record = vm.get('caseReview')
            ;
        record.reject();
        btn.up('window').close();
    },

    saveData: function (record, view, autoSave) {

        var me = this,
            vm = me.getViewModel(),
            noteStore = vm.getStore('noteStore'),
            notes = Ext.Array.pluck(noteStore.getRange(), 'data'),
            myMask = new Ext.LoadMask({ msg: 'Saving...', target: view || me.getView() }),
            userID = QuickStart.util.Global.getUser().id,
            data = record.getData(),
            fsData, sData, pData, wbData,
            url = QuickStart.util.Global.getApi() + 'case/saveData';



        view = view || me.getView();

        fsData = me.getFacesheetData();
        sData = me.getSafetyData();
        pData = me.getPermanencyData();
        wbData = me.getWellBeingData();

        me.buildData(data, fsData, sData, pData, wbData, notes);
        me.cleanData(data);

        data = me.updateCaseforErrors(data);

        //  console.log('data', data);
        myMask.show();
        Ext.Ajax.request({
            url: url,
            method: 'POST',
            //headers: {'Content-Type': 'application/json'},
            params: {
                userID: QuickStart.util.Global.getUser().id,
                editedItems: (vm.get('editedItems') || []).join(',')
            },
            jsonData: data,
            success: function (response, opts) {
                myMask.hide();
                var result = Ext.decode(response.responseText);
                if (result !== null) {
                    if (!autoSave) {
                        if (result.success && Ext.isEmpty(result.rule) && !Ext.isEmpty(result.data)) {
                            this.redirectTo('#case/' + result.data.CaseReviewRootID + '/' + result.data.CaseReviewID);
                        }
                        else if (result.success && !Ext.isEmpty(result.rule)) {
                            if (!result.rule.required && !Ext.isEmpty(result.data)) {
                                this.redirectTo('#case/' + result.data.CaseReviewRootID + '/' + result.data.CaseReviewID);
                            }
                            QuickStart.util.Global.showRuleErrors(result.rule);
                        }

                        if (view && view.isWindow) {
                            view.close();
                        }
                    }
                    else {
                        QuickStart.util.Global.showMessage('Auto saved successfully!');
                    }
                }
            },
            failure: function (response, opts) {
                myMask.hide();
                if (!autoSave) {
                    Ext.Msg.alert('Status', "failure");
                }
                console.log('server-side failure with status code ' + response.status);

            },
            scope: this
        });
    },

    buildData: function (data, fsData, sData, pData, wbData, notes) {

        if (fsData) {
            data.CR_FaceSheet_Collection[0] = fsData;
        }
        data.CR_CaseNote_Collection = [];

        if (notes) {
            data.CR_CaseNote_Collection = this.getNotesByItemCode(notes, null);
        }

        data.CR_Outcome_Collection = this.getOutcomes();
        data.CR_MultiAnswer_Collection = this.getMultiAnswers();
        data.CaseStatusCode = this.getDataEntryCaseStatus(data);
        // console.log(data)
        return data;
    },
    //
    // buildOutComes: function (outcomes, notes) {
    //     for (var i = 0; i < outcomes.length; i++) {
    //         var outcome = outcomes[i];
    //         switch (outcome.OutcomeCode) {
    //             case 1:
    //                 outcome = this.setItemNote(outcome, notes, 2);
    //                 break;
    //             case 2:
    //                 outcome = this.setItemNote(outcome, notes, 3);
    //                 outcome = this.setItemNote(outcome, notes, 4);
    //                 break;
    //             case 3:
    //                 outcome = this.setItemNote(outcome, notes, 5);
    //                 outcome = this.setItemNote(outcome, notes, 6);
    //                 outcome = this.setItemNote(outcome, notes, 7);
    //                 break;
    //             case 4:
    //                 outcome = this.setItemNote(outcome, notes, 8);
    //                 outcome = this.setItemNote(outcome, notes, 9);
    //                 outcome = this.setItemNote(outcome, notes, 10);
    //                 outcome = this.setItemNote(outcome, notes, 11);
    //                 outcome = this.setItemNote(outcome, notes, 12);
    //                 break;
    //             case 21:
    //                 outcome = this.setItemNote(outcome, notes, 23);
    //                 break;
    //         }
    //         outcomes[i] = outcome;
    //     }
    //     ;
    //     return outcomes;
    // },

    setItemNote: function (outcome, notes, itemCode) {
        for (var i = 0; i < outcome.CR_Item_Collection.length; i++) {
            if (outcome.CR_Item_Collection[i].ItemCode === itemCode || outcome.CR_Item_Collection[i].ItemCode === null) {
                outcome.CR_Item_Collection[i].CR_Note_Collection = this.getNotesByItemCode(notes, itemCode);
                break;
            }
        }
        return outcome;
    },

    cleanData: function (data) {
        delete data.id;
        delete data.Reviewers;
        delete data.FaceSheet;
        delete data.FirstCaseOpeningDate;
        delete data.FosterEntryDate;
        delete data.EpisodeDischargeDate;
        delete data.IsFosterEntryDateNA;
        delete data.IsEpisodeDischargeDateNA;
        delete data.IsEpisodeNotYetDischarged;
        delete data.CaseClosureDate;
        delete data.IsCaseClosureNotClosed;
        delete data.IsCaseOpenReasonOtherAbuseNeglect;
        delete data.CaseReasons;
        return data;
    },

    activeCaseStatusItem: function (status) {
        var progress = this.lookupReference('caseProgress'),
            progressItems = progress.items.items,
            item, i, activeItem, activeIndex;

        for (i = 0; i < progressItems.length; i++) {
            item = progressItems[i];
            if (item.statusCode === 6)
                item.setHidden(status !== 6);//Case Eliminated

            if (status === item.statusCode) {
                item.setUI('wizard-case-status-' + status);
                item.setPressed(true);
            }
            else {
                item.setUI('wizard-soft-purple');
                item.setPressed(false);
            }

            // IE8 has an odd bug with handling font icons in pseudo elements;
            // it will render the icon once and not update it when something
            // like text color is changed via style addition or removal.
            // We have to force icon repaint by adding a style with forced empty
            // pseudo element content, (x-sync-repaint) and removing it back to work
            // around this issue.
            // See this: https://github.com/FortAwesome/Font-Awesome/issues/954
            // and this: https://github.com/twbs/bootstrap/issues/13863
            if (Ext.isIE8) {
                item.btnIconEl.syncRepaint();
            }
        }
    },

    updateNumberStore: function (record) {

        var me = this,
            vm = me.getViewModel(),
            numberTableStore = vm.getStore('numberTableStore'),
            numberTablePlacementStore = vm.getStore('numberTablePlacementStore'),
            safetyReportLen = record.get('Safety').CR_SafetyReport_Collection.length,
            placementLen = record.get('Permanency').CR_Placement_Collection.length

            ;

        numberTableStore.removeAll();
        for (var i = 0; i <= safetyReportLen; i++) {
            numberTableStore.insert(i, { id: i });
        }
        numberTablePlacementStore.removeAll();
        for (var i = 0; i <= placementLen; i++) {
            numberTablePlacementStore.insert(i, { id: i });
        }

    },

    onAfterRenderItem8: function (container) {

        this.processItemParticipant(container, 'Item8');
    },
    onAfterRenderItem11: function (container) {

        this.processItemParticipant(container, 'Item11');
    },
    onAfterRenderItem12a: function (container) {
        this.processItemChild(container, 'Item12a');
    },
    onAfterRenderItem12b: function (container) {
        this.processItemParticipant(container, 'Item12b');
    },
    onAfterRenderItem13: function (container) {
        this.processItemParticipant(container, 'Item13');
        this.processItemChild(container, 'Item13');
    },
    onAfterRenderItem15: function (container) {
        this.processItemParticipant(container, 'Item15');
    },
    onAfterRenderItem16: function (container) {
        this.processItemChild(container, 'Item16');
    },
    onAfterRenderItem17: function (container) {
        this.processItemChild(container, 'Item17');
    },
    onAfterRenderItem18: function (container) {
        this.processItemChild(container, 'Item18');
    },
    processItemParticipant: function (container, itemName) {
        var mother = container.down('#' + itemName.toLowerCase() + 'ParticipantMother'),
            father = container.down('#' + itemName.toLowerCase() + 'ParticipantFather'),
            vm = this.getViewModel(),
            participantMotherPropName = itemName + 'ParticipantMother',
            participantFatherPropName = itemName + 'ParticipantFather',
            participantMother = vm.get('caseReview.' + participantMotherPropName),
            participantFather = vm.get('caseReview.' + participantFatherPropName),
            item = vm.get('caseReview.' + itemName),
            participants = !Ext.isEmpty(item) ? item.CR_ItemParticipant_Collection : [],
            caseParticipantStore = vm.getStore('caseParticipantStore'),
            participantRecords = Ext.Array.pluck(caseParticipantStore.getRange(), 'data'),
            arrMother = [], arrFather = []
            ;

        // store load after render so i used collection. Because of this, we need to save case participants table first
        participantRecords = vm.get('caseReview.FaceSheet.CR_CaseParticipant_Collection');
        Ext.suspendLayouts();
        mother.removeAll();
        father.removeAll();
        //console.log('participantRecords', participantRecords);
        Ext.each(participantRecords, function (rec) {
            var name = rec.Name, pId = rec.CaseParticipantID, role = rec.RoleCode;
            //mother
            if (role === 1) {
                var result = participants.filter(function (item) {
                    return item.CodeDescriptionID === 269 && item.ParticipantID === pId;
                });

                mother.add({
                    xtype: 'checkbox',
                    inputValue: pId,
                    boxLabel: name,
                    checked: result && result.length > 0
                });
                if (result && result.length > 0)
                    arrMother.push(pId);
            }
            //father
            else if (role === 2) {

                var result = participants.filter(function (item) {
                    return item.CodeDescriptionID === 270 && item.ParticipantID === pId;
                });

                father.add({
                    xtype: 'checkbox',
                    inputValue: pId,
                    boxLabel: name,
                    checked: result && result.length > 0
                });
                if (result && result.length > 0)
                    arrFather.push(pId);
            }

            //other
            else if (role === 6) {
                var result = participants.filter(function (item) {
                    return item.CodeDescriptionID === 269 && item.ParticipantID === pId;
                });

                mother.add({
                    xtype: 'checkbox',
                    inputValue: pId,
                    boxLabel: name,
                    checked: result && result.length > 0
                });
                if (result && result.length > 0)
                    arrMother.push(pId);
                var result = participants.filter(function (item) {
                    return item.CodeDescriptionID === 270 && item.ParticipantID === pId;
                });

                father.add({
                    xtype: 'checkbox',
                    inputValue: pId,
                    boxLabel: name,
                    checked: result && result.length > 0
                });
                if (result && result.length > 0)
                    arrFather.push(pId);
            }
        });

        Ext.resumeLayouts(true);
        var m = {}, f = {};
        m[participantMotherPropName] = arrMother;
        f[participantFatherPropName] = arrFather;
        mother.setValue(m);
        father.setValue(f);
        //	mother.fireEvent('change', mother,m);
        //	father.fireEvent('change', mother,f);

    },
    processItemChild: function (container, itemName) {
        var child = container.down('#' + itemName.toLowerCase() + 'ParticipantChild'),
            vm = this.getViewModel(),
            item = vm.get('caseReview.' + itemName),
            participants = !Ext.isEmpty(item) ? item.CR_ItemParticipant_Collection : [],
            childDemographicStore = vm.getStore('childDemographicStore'),
            childRecords = Ext.Array.pluck(childDemographicStore.getRange(), 'data')
            ;
        // store load after render so i used collection. Because of this, we need to save case child Demographic table first

        childRecords = vm.get('caseReview.FaceSheet.CR_ChildDemographic_Collection');
        Ext.suspendLayouts();
        child.removeAll();

        Ext.each(childRecords, function (rec) {
            //console.log(itemName, rec.getData())
            //child
            var result = participants.filter(function (item) {
                return item.CodeDescriptionID === 271 && item.ParticipantID === rec.ChildDemographicID
            });

            child.add({
                xtype: 'checkbox',
                inputValue: rec.ChildDemographicID,
                boxLabel: rec.Name + ' ' + rec.Age,
                checked: result && result.length > 0
            });

        });

        Ext.resumeLayouts(true);
    },
    onItemParticipantChanged: function (field, values) {
        //   console.log(arguments)
        //	console.log('onItemParticipantChanged', values)
        var me = this,
            vm = me.getViewModel(),
            val = [],
            name = field.getName(),
            propName = 'caseReview.' + name
            ;
        if (!Ext.isArray(values[name])) {
            if (values[name] !== null)
                val.push(values[name]);
        } else {
            val = values[name];
        }
        vm.set(propName, val);

    },
    getFacesheetData: function () {
        var me = this,
            vm = me.getViewModel(),
            childDemographicPanel = me.getView().down('#childDemographicPanel'),
            caseParticipantPanel = me.getView().down('#caseParticipantPanel'),
            childDemographicValues = [], caseParticipantValues = [],
            grid, fs, data, caseReasons = [],
            record = vm.get('caseReview')
            ;

        if (childDemographicPanel) {
            grid = childDemographicPanel.down('grid');
            childDemographicValues = grid.getValue();
        }

        if (caseParticipantPanel) {
            grid = caseParticipantPanel.down('grid');
            caseParticipantValues = grid.getValue();
        }

        if (record) {
            data = record.getData();
            fs = data.FaceSheet;
            Ext.each(data.CaseReasons, function (item) {
                caseReasons.push({
                    GroupName: 'CaseReason',
                    DataState: 0,
                    AnswerCode: 1,
                    CodeDescriptionID: item
                })
            });
            if (childDemographicValues === null || childDemographicValues.length === 0)
                childDemographicValues = fs.CR_ChildDemographic_Collection;
            if (caseParticipantValues === null || caseParticipantValues.length === 0)
                caseParticipantValues = fs.CR_CaseParticipant_Collection;

            Ext.apply(fs, {
                DataState: 0,
                CR_CaseParticipant_Collection: caseParticipantValues,
                CR_ChildDemographic_Collection: childDemographicValues,
                EpisodeDischargeDate: data.EpisodeDischargeDate,
                FirstCaseOpeningDate: data.FirstCaseOpeningDate,
                CaseClosureDate: data.CaseClosureDate,
                FosterEntryDate: data.FosterEntryDate,
                IsCaseClosureNotClosed: data.IsCaseClosureNotClosed,
                IsCaseOpenReasonOtherAbuseNeglect: data.IsCaseOpenReasonOtherAbuseNeglect,
                IsEpisodeDischargeDateNA: data.IsEpisodeDischargeDateNA,
                IsEpisodeNotYetDischarged: data.IsEpisodeNotYetDischarged,
                IsFosterEntryDateNA: data.IsFosterEntryDateNA,
                OtherCaseReason: data.OtherCaseReason,
                // IsEpisodeNotYetDischarged: data.IsEpisodeNotYetDischarged,
                CaseReasons: caseReasons
            });
        }
        return fs;
    },

    getSafetyData: function () {
        var me = this,
            vm = me.getViewModel(),
            safetyReportGrid = me.getView().down('#safetyReportGrid'),
            safetyReportValues = [],
            grid, data, safety,
            record = vm.get('caseReview'),
            isItem1, isItem2
            ;

        if (safetyReportGrid) {
            safetyReportValues = safetyReportGrid.getValue();
        }

        if (record) {
            data = record.getData(),
                isItem1 = data.Item1IsApplicable === 1,
                isItem2 = data.Item2IsApplicable === 1

            safety = data.Safety;

            if (safetyReportValues === null || safetyReportValues.length === 0)
                safetyReportValues = safety.CR_SafetyReport_Collection;
            Ext.apply(safety, {
                DataState: 0,
                CR_SafetyReport_Collection: isItem1 ? safetyReportValues : [],
                ReportsNotInAccordance: isItem1 ? data.ReportsNotInAccordance : null,
                FaceToFaceReportsNotInAccordance: isItem1 ? data.FaceToFaceReportsNotInAccordance : null,
                DelayReason: isItem1 ? data.DelayReason : null,
                IsDelayBeyondAgencyControl: isItem1 ? data.IsDelayBeyondAgencyControl : null,
                //
                // Item 2
                //
                EffortToPreventReEntryExplained: isItem2 ? (data.IsEffortToPreventReEntry === 2 ? data.EffortToPreventReEntryExplained : "") : null,
                IsEffortToPreventReEntry: isItem2 ? data.IsEffortToPreventReEntry : null,
                IsChildRemovedToEnsureSafety: isItem2 ? data.IsChildRemovedToEnsureSafety : null,
                ChildRemovedToEnsureSafetyExplained: isItem2 ? data.ChildRemovedToEnsureSafetyExplained : null,

                //
                // Item 3
                //
                IsFamilyMaltreatmentAllegations: data.IsFamilyMaltreatmentAllegations,
                IsMaltreatmentNotSubstantiated: data.IsMaltreatmentNotSubstantiated,
                IsInitialAssesmentForAllChildrenInHome: data.IsInitialAssesmentForAllChildrenInHome,
                InitialAssesmentForAllChildrenInHomeExplained: data.IsInitialAssesmentForAllChildrenInHome === 2 ? data.InitialAssesmentForAllChildrenInHomeExplained : "",
                IsOngoingAssesementForAllChildrenInHome: data.IsOngoingAssesementForAllChildrenInHome,
                OngoingAssessmentForAllChildrenInHomeExplained: data.IsOngoingAssesementForAllChildrenInHome === 2 ? data.OngoingAssessmentForAllChildrenInHomeExplained : "",
                IsSafetyPlanDevelopedAndMonitored: data.IsSafetyPlanDevelopedAndMonitored,
                SafetyPlanDevelopedAndMonitoredExplained: data.IsSafetyPlanDevelopedAndMonitored === 2 ? data.SafetyPlanDevelopedAndMonitoredExplained : "",
                OtherSafetyConcernExplained: data.OtherSafetyConcernExplained,
                IsSafetyConcernForOtherChildren: data.IsSafetyConcernForOtherChildren,
                FosterSafetyOtherExplained: data.FosterSafetyOtherExplained,
                IsFosterSafetyConcernDuringVisitation: data.IsFosterSafetyConcernDuringVisitation,
                FosterPlacementConcerOtherExplained: data.FosterPlacementConcerOtherExplained,
                IsFosterSafetyConcernNotAddressed: data.IsFosterSafetyConcernNotAddressed
            });
            //  debugger;
        }
        // console.log(safety)
        return safety;
    },

    getPermanencyData: function () {
        var me = this,
            vm = me.getViewModel(),
            refs = me.getReferences(),
            placementGrid = me.getView().down('#placementGrid'),
            goalGrid = me.getView().down('#goalGrid'),
            placementValues = [],
            goalValues = [],
            grid, data, permanency,
            record = vm.get('caseReview'),
            isItem5, isItem7, isItem8, isItem9, isItem10, isItem11

            ;
        if (placementGrid) {
            placementValues = placementGrid.getValue();
        }
        if (goalGrid) {
            goalValues = goalGrid.getValue();
        }

        if (record) {

            data = record.getData();
            permanency = data.Permanency;
            isItem5 = data.Item5IsApplicable === 1;
            isItem7 = data.Item7IsApplicable === 1;
            isItem8 = data.Item8IsApplicable === 1;
            isItem9 = data.Item9IsApplicable === 1;
            isItem10 = data.Item10IsApplicable === 1;
            isItem11 = data.Item11IsApplicable === 1;


            var hasEffortsToSupportMotherFosterRelationship = data.EffortsToSupportMotherFosterRelationship.filter(function (item) {
                return item.CodeDescriptionID === 170 || item === 170;//other=170
            })[0],
                hasEffortFatherFosterRelationshipOther = data.EffortsToSupportFatherFosterRelationship.filter(function (item) {
                    return item.CodeDescriptionID === 177 || item === 177;//other=177
                })[0];
            if (placementValues === null || placementValues.length === 0)
                placementValues = permanency.CR_Placement_Collection;
            if (goalValues === null || goalValues.length === 0)
                goalValues = permanency.CR_Goal_Collection;

            Ext.apply(permanency, {
                DataState: 0,
                //item4
                CR_Placement_Collection: placementValues,
                NumberOfPlacementSettings: data.NumberOfPlacementSettings,
                WereAllPlacementChangesPlanned: data.WereAllPlacementChangesPlanned,
                IsCurrentPlacementSettingStable: data.IsCurrentPlacementSettingStable,
                PlacementApplicableCircumstances: data.PlacementApplicableCircumstances,
                PlacementApplicableCircumstancesOther: data.PlacementApplicableCircumstancesOther,
                //item5
                CR_Goal_Collection: isItem5 ? goalValues : [],
                Goal1Code: isItem5 ? data.Goal1Code : null,
                Goal2Code: isItem5 ? data.Goal2Code : null,
                IsGoalSpecified: isItem5 ? data.IsGoalSpecified : null,
                WereAllGoalsInTimelyManner: isItem5 ? data.WereAllGoalsInTimelyManner : null,
                AllGoalsInTimelyMannerExplained: isItem5 ? data.AllGoalsInTimelyMannerExplained : null,
                WereAllGoalsAppropriate: isItem5 ? data.WereAllGoalsAppropriate : null,
                AllGoalsAppropriateExplained: isItem5 ? data.AllGoalsAppropriateExplained : null,
                IsInFoster15OutOf22: isItem5 ? data.IsInFoster15OutOf22 : null,
                MeetsTerminationOfParentalRights: isItem5 ? data.MeetsTerminationOfParentalRights : null,
                IsAgencyJointTerminationOfParentalRights: isItem5 ? data.IsAgencyJointTerminationOfParentalRights : null,
                IsExceptionForTermination: isItem5 ? data.IsExceptionForTermination : null,

                //item6
                ChildMostRecentFosterEntryDate: data.ChildMostRecentFosterEntryDate,
                TimeInCare: data.TimeInCare,
                DischargeDate: data.DischargeDate,
                IsDischargeDateNA: data.IsDischargeDateNA,
                IsAgencyConcertedEfforts: data.IsAgencyConcertedEfforts,
                AgencyConcertedEffortsExplained: data.IsAgencyConcertedEfforts === 2 ? data.AgencyConcertedEffortsExplained : "",
                LivingArrangementCode: data.LivingArrangementCode,
                LivingArrangementExplained: data.LivingArrangementCode === 6 ? data.LivingArrangementExplained : "",
                OtherPlannedArrangementDocumentationDate: data.OtherPlannedArrangementDocumentationDate,
                IsOtherPlannedArrangement: data.IsOtherPlannedArrangement,
                IsOtherPlannedArrangementNA: data.IsOtherPlannedArrangementNA,
                IsOtherPlannedArrangementNoDate: data.IsOtherPlannedArrangementNoDate,
                IsOtherPlannedConcertedEffort: data.IsOtherPlannedConcertedEffort,
                OtherPlannedConcertedEffortExplained: data.IsOtherPlannedConcertedEffort === 2 ? data.OtherPlannedConcertedEffortExplained : "",

                //item7
                IsPlacedWithAllSiblings: isItem7 ? data.IsPlacedWithAllSiblings : null,
                IsValidReasonForSeparation: isItem7 ? data.IsValidReasonForSeparation : null,
                ValidReasonForSeparationExplained: isItem7 ? (data.IsValidReasonForSeparation === 2 ? data.ValidReasonForSeparationExplained : "") : null,

                //item8
                MotherVisitationFrequencyCode: isItem8 ? data.MotherVisitationFrequencyCode : null,
                IsSufficientFrequencyForMotherVisitation: isItem8 ? data.IsSufficientFrequencyForMotherVisitation : null,
                FatherVisitationFrequencyCode: isItem8 ? data.FatherVisitationFrequencyCode : null,
                IsSufficientFrequencyForFatherVisitation: isItem8 ? data.IsSufficientFrequencyForFatherVisitation : null,
                IsSufficientQualityForMotherVisitation: isItem8 ? data.IsSufficientQualityForMotherVisitation : null,
                IsSufficentQualityForFatherVisitation: isItem8 ? data.IsSufficentQualityForFatherVisitation : null,
                SiblingVisitationFrequencyCode: isItem8 ? data.SiblingVisitationFrequencyCode : null,
                IsSufficientFrequencyForSiblingVisitation: isItem8 ? data.IsSufficientFrequencyForSiblingVisitation : null,
                IsSufficentQualityForSiblingVisitation: isItem8 ? data.IsSufficentQualityForSiblingVisitation : null,

                //item9
                IsConcertedEffortsForImportantConnections: isItem9 ? data.IsConcertedEffortsForImportantConnections : null,
                IsSufficientInquiryForIndianTribe: isItem9 ? data.IsSufficientInquiryForIndianTribe : null,
                IsTribeProvidedTimelyNotification: isItem9 ? data.IsTribeProvidedTimelyNotification : null,
                IsAccordanceWithIndianChildWelfareAct: isItem9 ? data.IsAccordanceWithIndianChildWelfareAct : null,

                //item10
                IsRecentPlacementWithRelative: isItem10 ? data.IsRecentPlacementWithRelative : null,
                IsPlacementWithRelativeStable: isItem10 ? data.IsPlacementWithRelativeStable : null,
                IsConcertedEffortToLocateMaternalRelatives: isItem10 ? data.IsConcertedEffortToLocateMaternalRelatives : null,
                IsConcertedEffortToLocatePaternalRelatives: isItem10 ? data.IsConcertedEffortToLocatePaternalRelatives : null,

                //item11
                IsConcertedEffortMotherFosterRelationship: isItem11 ? data.IsConcertedEffortMotherFosterRelationship : null,
                EffortsMotherFosterOther: isItem11 ? (hasEffortsToSupportMotherFosterRelationship ? data.EffortsMotherFosterOther : "") : null,
                IsConcertedEffortFatherFosterRelationship: isItem11 ? data.IsConcertedEffortFatherFosterRelationship : null,
                EffortFatherFosterRelationshipOther: isItem11 ? (hasEffortFatherFosterRelationshipOther ? data.EffortFatherFosterRelationshipOther : "") : null


            });
        }
        // console.log(permanency)
        return permanency;
    },

    getWellBeingData: function () {

        var me = this,
            vm = me.getViewModel(),
            educationGrid = me.getView().down('#educationGrid'),
            phsicalHealthGrid = me.getView().down('#physicalDentalHealthGrid'),
            mentalHealthGrid = me.getView().down('#mentalHealthGrid'),
            educationValues = [],
            physicalHealthValues = [],
            mentalHealthValues = [],
            healthValues = [],
            grid, data, wb,
            record = vm.get('caseReview'),
            isMother, isMother, isItem12c, isItem13, isItem15, isItem16, isItem17, isItem18
            ;
        if (educationGrid) {
            educationValues = educationGrid.getValue();
        }

        if (phsicalHealthGrid) {
            physicalHealthValues = phsicalHealthGrid.getValue();
        }

        if (mentalHealthGrid) {
            mentalHealthValues = mentalHealthGrid.getValue();
        }

        if (record) {
            data = record.getData();
            wb = data.WellBeing;
            isMother = data.IsNeedsServicesApplicableForMother === 1;
            isFather = data.IsNeedsServicesApplicableForFather === 1;
            isItem12c = data.Item12cIsApplicable === 1;
            isItem13 = data.Item13IsApplicable === 1;
            isItem15 = data.Item15IsApplicable === 1;
            isItem16 = data.Item16IsApplicable === 1;
            isItem17 = data.Item17IsApplicable === 1;
            isItem18 = data.Item18IsApplicable === 1;

            if (educationValues === null || educationValues.length === 0)
                educationValues = wb.CR_Education_Collection;
            if (physicalHealthValues === null || physicalHealthValues.length === 0)
                physicalHealthValues = wb.CR_Health_Collection.filter(function (item) {
                    return item.HealthNeedCode === 1;
                });
            if (mentalHealthValues === null || mentalHealthValues.length === 0)
                mentalHealthValues = wb.CR_Health_Collection.filter(function (item) {
                    return item.HealthNeedCode === 2;
                });

            if (!isItem17) {
                physicalHealthValues = [];
            }
            if (!isItem18) {
                mentalHealthValues = [];
            }

            //console.log(physicalHealthValues, mentalHealthValues)
            healthValues = Ext.Array.union(physicalHealthValues, mentalHealthValues);

            Ext.apply(wb, {
                DataState: 0,
                //
                // Item 12A
                //
                IsComprehensiveAssessementConducted: data.IsComprehensiveAssessementConducted,
                IsAppropriateServicesProvided: data.IsAppropriateServicesProvided,
                IsSufficientInquiryForIndianTribe: data.IsSufficientInquiryForIndianTribe,
                ComprehensiveAssessmentExplained: data.IsComprehensiveAssessementConducted === 2 ? data.ComprehensiveAssessmentExplained : "",
                AppropriateServicesProvidedExplained: data.IsAppropriateServicesProvided === 2 ? data.AppropriateServicesProvidedExplained : "",

                //
                // Item 12B
                //

                IsNeedsServicesApplicableForMother: data.IsNeedsServicesApplicableForMother,
                IsNeedsServicesApplicableForFather: data.IsNeedsServicesApplicableForFather,

                IsComprehensiveAssessementForMotherConducted: isMother ? data.IsComprehensiveAssessementForMotherConducted : (isMother || isFather) ? 3 : null,
                ComprehensiveAssessementForMotherExplained: isMother ? (data.IsComprehensiveAssessementForMotherConducted === 2 ? data.ComprehensiveAssessementForMotherExplained : "") : null,

                IsComprehensiveAssessementForFatherConducted: isFather ? data.IsComprehensiveAssessementForFatherConducted : (isMother || isFather) ? 3 : null,
                ComprehensiveAssessementforFatherConductedExplained: isFather ? (data.IsComprehensiveAssessementForFatherConducted === 2 ? data.ComprehensiveAssessementforFatherConductedExplained : "") : null,

                IsAppropriateServicesForMotherProvided: isMother ? data.IsAppropriateServicesForMotherProvided : (isMother || isFather) ? 3 : null,
                AppropriateServicesForMotherExplained: isMother ? (data.IsAppropriateServicesForMotherProvided === 2 ? data.AppropriateServicesForMotherExplained : "") : null,

                IsAppropriateServicesForFatherProvided: isFather ? data.IsAppropriateServicesForFatherProvided : (isMother || isFather) ? 3 : null,
                AppropriateServicesForFatherExplained: isFather ? (data.IsAppropriateServicesForFatherProvided === 2 ? data.AppropriateServicesForFatherExplained : "") : null,

                //
                // Item 12C
                //
                IsNeedsOfFosterParentsAdequatelyAssessed: isItem12c ? data.IsNeedsOfFosterParentsAdequatelyAssessed : null,
                IsFosterParentsProvidedAppropriateServices: isItem12c ? data.IsFosterParentsProvidedAppropriateServices : null,
                NeedsOfFosterParentsAdequatelyAssessedExplained: isItem12c ? (data.IsNeedsOfFosterParentsAdequatelyAssessed === 2 ? data.NeedsOfFosterParentsAdequatelyAssessedExplained : "") : null,
                FosterParentsProvidedAppropriateServicesExplained: isItem12c ? (data.IsFosterParentsProvidedAppropriateServices === 2 ? data.FosterParentsProvidedAppropriateServicesExplained : "") : null,

                //
                // Item 13
                //
                IsAgencyConcertedEffortsToInvolveTheChild: isItem13 ? data.IsAgencyConcertedEffortsToInvolveTheChild : null,
                IsAgencyConcertedEffortsToInvolveTheMother: isItem13 ? data.IsAgencyConcertedEffortsToInvolveTheMother : null,
                IsAgencyConcertedEffortsToInvolveTheFather: isItem13 ? data.IsAgencyConcertedEffortsToInvolveTheFather : null,
                AgencyConcertedEffortsToInvolveTheChildExplained: isItem13 ? (data.IsAgencyConcertedEffortsToInvolveTheChild === 2 ? data.AgencyConcertedEffortsToInvolveTheChildExplained : "") : null,
                AgencyConcertedEffortsToInvolveTheMotherExplained: isItem13 ? (data.IsAgencyConcertedEffortsToInvolveTheMother === 2 ? data.AgencyConcertedEffortsToInvolveTheMotherExplained : "") : null,
                AgencyConcertedEffortsToInvolveTheFatherExplained: isItem13 ? (data.IsAgencyConcertedEffortsToInvolveTheFather === 2 ? data.AgencyConcertedEffortsToInvolveTheFatherExplained : "") : null,

                //
                // Item 14
                //
                ResponsiblePartyVisitationFrequencyCode: data.ResponsiblePartyVisitationFrequencyCode,
                IsResponsiblePartyVisitationFrequencySufficient: data.IsResponsiblePartyVisitationFrequencySufficient,
                IsResponsiblePartyVisitationQualitySufficient: data.IsResponsiblePartyVisitationQualitySufficient,
                ResponsiblePartyVisitationQualityExplained: (data.IsResponsiblePartyVisitationQualitySufficient === 2 ? data.ResponsiblePartyVisitationQualityExplained : ""),

                //
                // Item 15
                //
                ResponsiblePartyVisitationFrequencyWithMotherCode: isItem15 ? data.ResponsiblePartyVisitationFrequencyWithMotherCode : null,
                IsResponsiblePartyVisitationFrequencyWithMotherSufficient: isItem15 ? data.IsResponsiblePartyVisitationFrequencyWithMotherSufficient : null,
                ResponsiblePartyVisitationFrequencyWithFatherCode: isItem15 ? data.ResponsiblePartyVisitationFrequencyWithFatherCode : null,
                IsResponsiblePartyVisitationFrequencyWithFatherSufficient: isItem15 ? data.IsResponsiblePartyVisitationFrequencyWithFatherSufficient : null,
                IsResponsiblePartyVisitationQualityWithMotherSufficient: isItem15 ? data.IsResponsiblePartyVisitationQualityWithMotherSufficient : null,
                IsResponsiblePartyVisitationQualityWithFatherSufficient: isItem15 ? data.IsResponsiblePartyVisitationQualityWithFatherSufficient : null,
                ResponsiblePartyVisitationQualityWithMotherExplained: isItem15 ? (data.IsResponsiblePartyVisitationQualityWithMotherSufficient === 2 ? data.ResponsiblePartyVisitationQualityWithMotherExplained : "") : null,
                ResponsiblePartyVisitationQualityWithFatherExplained: isItem15 ? (data.IsResponsiblePartyVisitationQualityWithFatherSufficient === 2 ? data.ResponsiblePartyVisitationQualityWithFatherExplained : "") : null,

                //
                // Item 16
                //
                CR_Education_Collection: isItem16 ? educationValues : [],
                IsAgencyAssessEducationNeeds: isItem16 ? data.IsAgencyAssessEducationNeeds : null,
                IsAgencyAddressEducationNeeds: isItem16 ? data.IsAgencyAddressEducationNeeds : null,

                //
                // Item 17
                //
                CR_Health_Collection: healthValues,
                IsAgencyAssessPhysicalHealthNeeds: isItem17 ? data.IsAgencyAssessPhysicalHealthNeeds : null,
                IsAgencyAssessDentalHealthNeeds: isItem17 ? data.IsAgencyAssessDentalHealthNeeds : null,
                IsFosterOversightMedicationForPhysicalHealtyAppropriate: isItem17 ? data.IsFosterOversightMedicationForPhysicalHealtyAppropriate : null,
                IsAppropriateSerivcesForAllPhysicalHealthNeeds: isItem17 ? data.IsAppropriateSerivcesForAllPhysicalHealthNeeds : null,
                IsAppropriateServicesForAllDentalNeeds: isItem17 ? data.IsAppropriateServicesForAllDentalNeeds : null,
                FosterFederalCaseManagamentCriteria: isItem17 ? data.FosterFederalCaseManagamentCriteria : null,

                //
                // Item 18
                //
                IsAgencyAssessMentalHealthNeeds: isItem18 ? data.IsAgencyAssessMentalHealthNeeds : null,
                IsAppropriateSerivcesForMentalHealthNeeds: isItem18 ? data.IsAppropriateSerivcesForMentalHealthNeeds : null,
                IsFosterOversightMedicationForMentalHealtyAppropriate: isItem18 ? data.IsFosterOversightMedicationForMentalHealtyAppropriate : null
            });
        }
        //  console.log(wb);

        return wb;
    },

    getOutcomes: function () {
        var me = this,
            vm = me.getViewModel(),
            noteStore = vm.getStore('noteStore'),
            notes = Ext.Array.pluck(noteStore.getRange(), 'data'),
            data,
            outcomes = [],
            ratingVm,
            record = vm.get('caseReview'),
            outcome,
            oIdx = 0,
            statusCodes = [],
            complete = [],
            inProgress = [],
            notStarted = [],
            oItems = [
                { item: { itemNo: 1, itemCode: 2, outcomeCode: 1 } },
                { item: { itemNo: 2, itemCode: 3, outcomeCode: 2 } },
                { item: { itemNo: 3, itemCode: 4, outcomeCode: 2 } },
                { item: { itemNo: 4, itemCode: 5, outcomeCode: 3 } },
                { item: { itemNo: 5, itemCode: 6, outcomeCode: 3 } },
                { item: { itemNo: 6, itemCode: 7, outcomeCode: 3 } },
                { item: { itemNo: 7, itemCode: 8, outcomeCode: 4 } },
                { item: { itemNo: 8, itemCode: 9, outcomeCode: 4 } },
                { item: { itemNo: 9, itemCode: 10, outcomeCode: 4 } },
                { item: { itemNo: 10, itemCode: 11, outcomeCode: 4 } },
                { item: { itemNo: 11, itemCode: 12, outcomeCode: 4 } },
                { item: { itemNo: 12, itemCode: 13, outcomeCode: 5 } },
                { item: { itemNo: '12a', itemCode: 14, outcomeCode: 5 } },
                { item: { itemNo: '12b', itemCode: 15, outcomeCode: 5 } },
                { item: { itemNo: '12c', itemCode: 16, outcomeCode: 5 } },
                { item: { itemNo: 13, itemCode: 17, outcomeCode: 5 } },
                { item: { itemNo: 14, itemCode: 18, outcomeCode: 5 } },
                { item: { itemNo: 15, itemCode: 19, outcomeCode: 5 } },
                { item: { itemNo: 16, itemCode: 20, outcomeCode: 6 } },
                { item: { itemNo: 17, itemCode: 21, outcomeCode: 7 } },
                { item: { itemNo: 18, itemCode: 22, outcomeCode: 7 } }
            ],
            updItem
            ;

        if (record) {
            data = record.getData();
            outcomes = data.CR_Outcome_Collection;

            if (outcomes === null || outcomes.length === 1)
                outcomes = me.getNewOutcomes();
            if (outcomes && outcomes.length > 1) {
                // var outcomes = ma.filter(function (item) { return item.OutcomeCode === 1;});
                //outcomes[0] is for facesheet
                outcomes[0].CR_Item_Collection[0].CR_Note_Collection = me.getNotesByItemCode(notes, 23);
                outcomes[0].CR_Item_Collection[0].StatusCode = me.getItemStatus(23);

                Ext.each(oItems, function (oRec) {
                    oIdx = me.getOutcomeIndex(outcomes, oRec.item.outcomeCode);

                    if (oIdx > -1) {
                        updItem = outcomes[oIdx].CR_Item_Collection.filter(function (item) {
                            return item.ItemCode === oRec.item.itemCode;
                        })[0];
                        updItem = me.getUpdatedItem(updItem, data, oRec.item.itemNo);

                        //if (updItem.IsApplicable === 0) {
                        //    debugger;
                        //}

                        if (oRec.item.itemCode > 13 && oRec.item.itemCode < 17) {
                            statusCodes.push(updItem.StatusCode);
                        }

                        updItem.CR_Note_Collection = me.getNotesByItemCode(notes, updItem.ItemCode);

                        if (updItem.ItemCode === 9 || updItem.ItemCode === 12 || updItem.ItemCode === 14 || updItem.ItemCode === 15 || updItem.ItemCode === 17 || updItem.ItemCode === 19 || updItem.ItemCode === 20 || updItem.ItemCode === 21 || updItem.ItemCode === 22) {
                            updItem.CR_ItemParticipant_Collection = me.getItemParticipantByItemName(updItem, oRec.item.itemNo);
                        }
                        // if (updItem.ItemCode === 14 || updItem.ItemCode === 17 || updItem.ItemCode === 21 || updItem.ItemCode === 22 ) {
                        //     updItem.CR_ItemParticipant_Collection = me.getItemParticipantByItemName(updItem, oRec.item.itemNo);
                        // }
                        outcomes[oIdx].OutcomeRatingCode = Ext.isEmpty(updItem.OutcomeRatingCode) ? outcomes[oIdx].OutcomeRatingCode : updItem.OutcomeRatingCode;
                        outcomes[oIdx].OverriddenOutcomeRatingCode = Ext.isEmpty(updItem.OverriddenOutcomeRatingCode) ? outcomes[oIdx].OverriddenOutcomeRatingCode : updItem.OverriddenOutcomeRatingCode;


                        outcomes[oIdx].DataState = 0;
                    }
                });
                //
                // Update Item 12 status. Need to be calculated after 12a,12b and 12c.
                //
                oIdx = me.getOutcomeIndex(outcomes, 5);
                updItem = outcomes[oIdx].CR_Item_Collection.filter(function (item) {
                    return item.ItemCode === 13;
                })[0];

                complete = statusCodes.filter(function (code) {
                    return code === 1;
                });
                inProgress = statusCodes.filter(function (code) {
                    return code === 2;
                });
                notStarted = statusCodes.filter(function (code) {
                    return code === 3 || code === 0;
                });

                if (complete.length > 0 && complete.length === statusCodes.length) {
                    updItem.StatusCode = 1;
                } else if (inProgress.length > 0) {
                    updItem.StatusCode = 2;
                } else if (notStarted.length > 0 && inProgress.length === 0) {
                    updItem.StatusCode = 3;
                }
                //var item1 = outcomes[1].CR_Item_Collection[0],
                //    item2 = outcomes[2].CR_Item_Collection.filter(function (item) {
                //        return item.ItemCode === 3;
                //    })[0],
                //    item3 = outcomes[2].CR_Item_Collection.filter(function (item) {
                //        return item.ItemCode === 4;
                //    })[0],

                //    item4 = outcomes[3].CR_Item_Collection.filter(function (item) {
                //        return item.ItemCode === 5;
                //    })[0],
                //    item5 = outcomes[3].CR_Item_Collection.filter(function (item) {
                //        return item.ItemCode === 6;
                //    })[0],
                //    item6 = outcomes[3].CR_Item_Collection.filter(function (item) {
                //        return item.ItemCode === 7;
                //    })[0],

                //    item7 = outcomes[4].CR_Item_Collection.filter(function (item) {
                //        return item.ItemCode === 8;
                //    })[0],
                //    item8 = outcomes[4].CR_Item_Collection.filter(function (item) {
                //        return item.ItemCode === 9;
                //    })[0],
                //    item9 = outcomes[4].CR_Item_Collection.filter(function (item) {
                //        return item.ItemCode === 10;
                //    })[0],
                //    item10 = outcomes[4].CR_Item_Collection.filter(function (item) {
                //        return item.ItemCode === 11;
                //    })[0],
                //    item11 = outcomes[4].CR_Item_Collection.filter(function (item) {
                //        return item.ItemCode === 12;
                //    })[0],
                //    item12 = outcomes[5].CR_Item_Collection.filter(function (item) {
                //        return item.ItemCode === 13;
                //    })[0],
                //    item12a = outcomes[5].CR_Item_Collection.filter(function (item) {
                //        return item.ItemCode === 14;
                //    })[0],
                //    item12b = outcomes[5].CR_Item_Collection.filter(function (item) {
                //        return item.ItemCode === 15;
                //    })[0],
                //    item12c = outcomes[5].CR_Item_Collection.filter(function (item) {
                //        return item.ItemCode === 16;
                //    })[0],
                //    item13 = outcomes[5].CR_Item_Collection.filter(function (item) {
                //        return item.ItemCode === 17;
                //    })[0],
                //    item14 = outcomes[5].CR_Item_Collection.filter(function (item) {
                //        return item.ItemCode === 18;
                //    })[0],
                //    item15 = outcomes[5].CR_Item_Collection.filter(function (item) {
                //        return item.ItemCode === 19;
                //    })[0],
                //    item16 = outcomes[6].CR_Item_Collection.filter(function (item) {
                //        return item.ItemCode === 20;
                //    })[0],
                //    item17 = outcomes[7].CR_Item_Collection.filter(function (item) {
                //        return item.ItemCode === 21;
                //    })[0],
                //    item18 = outcomes[7].CR_Item_Collection.filter(function (item) {
                //        return item.ItemCode === 22;
                //    })[0]
                //;

                //item1 = me.getUpdatedItem(item1, data, 1);
                //outcomes[1].OutcomeRatingCode = Ext.isEmpty(item1.OutcomeRatingCode) ? outcomes[1].OutcomeRatingCode: item1.OutcomeRatingCode;
                //item2 = me.getUpdatedItem(item2, data, 2);
                //outcomes[2].OutcomeRatingCode = Ext.isEmpty(item2.OutcomeRatingCode) ? outcomes[2].OutcomeRatingCode : item2.OutcomeRatingCode;
                //item3 = me.getUpdatedItem(item3, data, 3);
                //outcomes[2].OutcomeRatingCode = Ext.isEmpty(item3.OutcomeRatingCode) ? outcomes[2].OutcomeRatingCode : item3.OutcomeRatingCode;

                //item4 = me.getUpdatedItem(item4, data, 4);
                //outcomes[3].OutcomeRatingCode = Ext.isEmpty(item4.OutcomeRatingCode) ? outcomes[3].OutcomeRatingCode : item4.OutcomeRatingCode;
                //item5 = me.getUpdatedItem(item5, data, 5);
                //outcomes[3].OutcomeRatingCode = Ext.isEmpty(item5.OutcomeRatingCode) ? outcomes[3].OutcomeRatingCode : item5.OutcomeRatingCode;
                //item6 = me.getUpdatedItem(item6, data, 6);
                //outcomes[3].OutcomeRatingCode = Ext.isEmpty(item6.OutcomeRatingCode) ? outcomes[3].OutcomeRatingCode : item6.OutcomeRatingCode;
                //item7 = me.getUpdatedItem(item7, data, 7);
                //outcomes[4].OutcomeRatingCode = Ext.isEmpty(item7.OutcomeRatingCode) ? outcomes[4].OutcomeRatingCode : item7.OutcomeRatingCode;
                //item8 = me.getUpdatedItem(item8, data, 8);
                //outcomes[4].OutcomeRatingCode = Ext.isEmpty(item8.OutcomeRatingCode) ? outcomes[4].OutcomeRatingCode : item8.OutcomeRatingCode;
                //item9 = me.getUpdatedItem(item9, data, 9);
                //outcomes[4].OutcomeRatingCode = Ext.isEmpty(item9.OutcomeRatingCode) ? outcomes[4].OutcomeRatingCode : item9.OutcomeRatingCode;
                //item10 = me.getUpdatedItem(item10, data, 10);
                //outcomes[4].OutcomeRatingCode = Ext.isEmpty(item10.OutcomeRatingCode) ? outcomes[4].OutcomeRatingCode: item10.OutcomeRatingCode;
                //item11 = me.getUpdatedItem(item11, data, 11);
                //outcomes[4].OutcomeRatingCode = Ext.isEmpty(item11.OutcomeRatingCode) ? outcomes[4].OutcomeRatingCode: item11.OutcomeRatingCode;

                //item12a = me.getUpdatedItem(item12a, data, '12a');
                //outcomes[5].OutcomeRatingCode = Ext.isEmpty(item12a.OutcomeRatingCode) ? outcomes[5].OutcomeRatingCode : item12a.OutcomeRatingCode;
                //item12b = me.getUpdatedItem(item12b, data, '12b');
                //outcomes[5].OutcomeRatingCode = Ext.isEmpty(item12b.OutcomeRatingCode) ? outcomes[5].OutcomeRatingCode : item12b.OutcomeRatingCode;
                //item12c = me.getUpdatedItem(item12c, data, '12c');
                //outcomes[5].OutcomeRatingCode = Ext.isEmpty(item12c.OutcomeRatingCode) ? outcomes[5].OutcomeRatingCode: item12c.OutcomeRatingCode;

                //item12 = me.getUpdatedItem(item12, data, 12);
                //outcomes[5].OutcomeRatingCode = Ext.isEmpty(item12.OutcomeRatingCode) ? outcomes[5].OutcomeRatingCode : item12.OutcomeRatingCode;
                //item13 = me.getUpdatedItem(item13, data, 13);
                //outcomes[5].OutcomeRatingCode = Ext.isEmpty(item13.OutcomeRatingCode) ? outcomes[5].OutcomeRatingCode : item13.OutcomeRatingCode;
                //item14 = me.getUpdatedItem(item14, data, 14);
                //outcomes[5].OutcomeRatingCode = Ext.isEmpty(item14.OutcomeRatingCode) ? outcomes[5].OutcomeRatingCode : item14.OutcomeRatingCode;
                //item15 = me.getUpdatedItem(item15, data, 15);
                //outcomes[5].OutcomeRatingCode = Ext.isEmpty(item15.OutcomeRatingCode) ? outcomes[5].OutcomeRatingCode: item15.OutcomeRatingCode;
                //item16 = me.getUpdatedItem(item16, data, 16);
                //outcomes[6].OutcomeRatingCode = Ext.isEmpty(item16.OutcomeRatingCode) ? outcomes[6].OutcomeRatingCode: item16.OutcomeRatingCode;
                //item17 = me.getUpdatedItem(item17, data, 17);
                //outcomes[7].OutcomeRatingCode = Ext.isEmpty(item17.OutcomeRatingCode) ? outcomes[7].OutcomeRatingCode: item17.OutcomeRatingCode;
                //item18 = me.getUpdatedItem(item18, data, 18);
                //outcomes[7].OutcomeRatingCode = Ext.isEmpty(item18.OutcomeRatingCode) ? outcomes[7].OutcomeRatingCode : item18.OutcomeRatingCode;
            }
        }
        //Ext.each(outcomes, function (item) {
        //    item.DataState = 0;
        //});
        return outcomes;
    },
    getOutcomeIndex: function (outcomes, oCode) {
        var coll = outcomes.filter(function (outcome) {
            return outcome.OutcomeCode === oCode;
        });

        return outcomes.indexOf(coll[0]);
    },
    getMultiAnswers: function () {
        var me = this,
            vm = me.getViewModel(),
            data,
            answers,
            ratingVm,
            value,
            record = vm.get('caseReview'),
            arr = []
            ;

        if (record) {
            data = record.getData();
            answers = data.CR_MultiAnswer_Collection;
            for (var index = 0; index <= 300; index++) {

                var ans = me.getApplicability(answers, index);
                if (index >= 51 && index <= 83 || index === 261 ||
                    index >= 292 && index <= 293) // item2(51-56) item8(57-62) item11(63-67,261) item12b(68-72) item13(73-78,292) item15(79-83,293)
                {
                    if (!Ext.isEmpty(ans)) {
                        ans.AnswerCode = data['ItemApplicability' + index];
                        arr.push(ans);
                    }
                    else {
                        if (!Ext.isEmpty(data['ItemApplicability' + index])) {
                            arr.push({
                                DataState: 0,
                                AnswerID: null,
                                GroupName: 'Applicability',
                                AnswerCode: data['ItemApplicability' + index],
                                CodeDescriptionID: index
                            });
                        }
                    }
                }
                else if (index >= 86 && index <= 91) // item3 SafetyRelatedIncidents
                {
                }
                else if (index >= 92 && index <= 97) // item3 FosterSafety
                {
                }
                else if (index >= 98 && index <= 104) // item3 FosterPlacementConcern
                {
                }
                else if (index >= 121 && index <= 126) // item4 PlacementApplicableCircumstances
                {
                }
                else if (index >= 127 && index <= 130) // item6 PermanencyGoal1
                {
                }
                else if (index >= 138 && index <= 142) // item5 TerminationExceptions
                {
                }
                else if (index >= 156 && index <= 159) // item10 PlacementEffortConcernsMother
                {
                }
                else if (index >= 160 && index <= 163) // item10 PlacementEffortConcernsFather
                {
                }
                else if (index >= 164 && index <= 170) // item11 EffortsToSupportMotherFosterRelationship
                {
                }
                else if (index >= 171 && index <= 177) // item11 EffortsToSupportFatherFosterRelationship
                {
                }
                else if (index >= 178 && index <= 182) // item 17 FosterFederalCaseManagamentCriteria
                {
                }
                else if (index >= 1 && index <= 14) // facesheet CaseReasons
                {
                }
                else {
                    if (!Ext.isEmpty(ans)) {
                        //  ans.AnswerCode = data['ItemApplicability' + index];
                        arr.push(ans);
                    }
                }
            }
        }

        var colls = data.FosterPlacementConcern;
        Ext.each(colls, function (item) {
            arr.push(me.getNewMultiAnswerObject('FosterPlacementConcern', item));
        });

        colls = data.SafetyRelatedIncidents;
        Ext.each(colls, function (item) {
            arr.push(me.getNewMultiAnswerObject('SafetyRelatedIncidents', item));
        });
        colls = data.FosterSafety;
        Ext.each(colls, function (item) {
            arr.push(me.getNewMultiAnswerObject('FosterSafety', item));
        });
        colls = data.PlacementApplicableCircumstances;
        Ext.each(colls, function (item) {
            arr.push(me.getNewMultiAnswerObject('PlacementApplicableCircumstances', item));
        });
        colls = data.TerminationExceptions;
        Ext.each(colls, function (item) {
            arr.push(me.getNewMultiAnswerObject('TerminationExceptions', item));
        });

        colls = data.PermanencyGoal1;
        Ext.each(colls, function (item) {
            arr.push(me.getNewMultiAnswerObject('PermanencyGoal1', item, 1));
        });
        colls = data.PlacementEffortConcernsMother;
        Ext.each(colls, function (item) {
            arr.push(me.getNewMultiAnswerObject('PlacementEffortConcernsMother', item, 1));
        });

        colls = data.PlacementEffortConcernsFather;
        Ext.each(colls, function (item) {
            arr.push(me.getNewMultiAnswerObject('PlacementEffortConcernsFather', item, 1));
        });

        colls = data.EffortsToSupportMotherFosterRelationship;
        Ext.each(colls, function (item) {
            arr.push(me.getNewMultiAnswerObject('EffortsToSupportMotherFosterRelationship', item, 1));
        });

        colls = data.EffortsToSupportFatherFosterRelationship;
        Ext.each(colls, function (item) {
            arr.push(me.getNewMultiAnswerObject('EffortsToSupportFatherFosterRelationship', item, 1));
        });

        colls = data.CaseReasons;
        Ext.each(colls, function (item) {
            arr.push(me.getNewMultiAnswerObject('CaseReason', item, 1));
        });

        colls = data.FosterFederalCaseManagamentCriteria;
        Ext.each(colls, function (item) {
            arr.push(me.getNewMultiAnswerObject('FosterFederalCaseManagamentCriteria', item, 1));
        });

        return arr;
    },

    getUpdatedItem: function (item, data, itemNo) {
        item.IsApplicable = data['Item' + itemNo + 'IsApplicable'];
        item.DataState = 0,
            me = this;

        if ((data.ReviewSubTypeID === 19 || data.ReviewSubTypeID === 21) && item.ItemCode > 4 && item.ItemCode < 13) {
            item.ItemRatingCode = 4; //4==Not Applicable
            item.StatusCode = 4;
            item.OutcomeRatingCode = 5;

            return item;
        }

        item.Comments = data['Item' + itemNo + 'Comments'];
        var rating = me.getView().down('#rating' + itemNo);

        if (rating) {
            rating.calculate(data);
            var ratingData = rating.getViewModel().get('ratingData');
            // console.log(itemNo, ratingData)
            if (ratingData) {
                //console.log(ratingData)
                item.isRatingOverride = ratingData.isRatingOverride;
                item.ItemRatingCode = ratingData.ItemRatingCode;
                item.OverriddenRatingCode = ratingData.OverriddenRatingCode;
                item.OverriddenOutcomeRatingCode = ratingData.OverriddenOutcomeRatingCode;
                item.RatingComments = ratingData.RatingComments;
                item.OutcomeRatingCode = ratingData.OutcomeRatingCode;
            }
        }

        if (item.ItemRatingCode === 3) {
            item.StatusCode = 1;
        } else {
            item.StatusCode = me.getItemStatus(item.ItemCode);
            if (item.StatusCode === 1 && me.hasItemContainErrors(item.ItemCode)) {
                item.StatusCode = 2;
            }
        }

        return item;
    },
    getNewOutcomes: function () {
        var outcomes = [],
            outcome21 = this.getNewOutcomeObject(21),
            outcome1 = this.getNewOutcomeObject(1),
            outcome2 = this.getNewOutcomeObject(2),
            outcome3 = this.getNewOutcomeObject(3),
            outcome4 = this.getNewOutcomeObject(4),
            outcome5 = this.getNewOutcomeObject(5),
            outcome6 = this.getNewOutcomeObject(6),
            outcome7 = this.getNewOutcomeObject(7)
            ;
        outcome21.CR_Item_Collection.push(this.getNewItemObject(23));

        outcome1.CR_Item_Collection.push(this.getNewItemObject(2));

        outcome2.CR_Item_Collection.push(this.getNewItemObject(3));
        outcome2.CR_Item_Collection.push(this.getNewItemObject(4));

        outcome3.CR_Item_Collection.push(this.getNewItemObject(5));
        outcome3.CR_Item_Collection.push(this.getNewItemObject(6));
        outcome3.CR_Item_Collection.push(this.getNewItemObject(7));

        outcome4.CR_Item_Collection.push(this.getNewItemObject(8));
        outcome4.CR_Item_Collection.push(this.getNewItemObject(9));
        outcome4.CR_Item_Collection.push(this.getNewItemObject(10));
        outcome4.CR_Item_Collection.push(this.getNewItemObject(11));
        outcome4.CR_Item_Collection.push(this.getNewItemObject(12));

        outcome5.CR_Item_Collection.push(this.getNewItemObject(13));
        outcome5.CR_Item_Collection.push(this.getNewItemObject(14));
        outcome5.CR_Item_Collection.push(this.getNewItemObject(15));
        outcome5.CR_Item_Collection.push(this.getNewItemObject(16));
        outcome5.CR_Item_Collection.push(this.getNewItemObject(17));
        outcome5.CR_Item_Collection.push(this.getNewItemObject(18));
        outcome5.CR_Item_Collection.push(this.getNewItemObject(19));

        outcome6.CR_Item_Collection.push(this.getNewItemObject(20));

        outcome7.CR_Item_Collection.push(this.getNewItemObject(21));
        outcome7.CR_Item_Collection.push(this.getNewItemObject(22));

        outcomes.push(outcome21);
        outcomes.push(outcome1);
        outcomes.push(outcome2);
        outcomes.push(outcome3);
        outcomes.push(outcome4);
        outcomes.push(outcome5);
        outcomes.push(outcome6);
        outcomes.push(outcome7);
        return outcomes;
    },

    getNewOutcomeObject: function (outcomeCode) {
        return {
            OutcomeCode: outcomeCode,
            OutcomeRatingCode: null,
            OverriddenOutcomeRatingCode: null,
            DataState: 0,
            CR_Item_Collection: []
        };
    },

    getNewItemObject: function (itemCode) {
        return {
            Comments: null,
            CR_ItemParticipant_Collection: [],
            CR_Note_Collection: [],
            DataState: 0,
            IsApplicable: null,
            isRatingOverride: null,
            ItemCode: itemCode,
            ItemRatingCode: null,
            OverriddenRatingCode: null,
            OverrideReason: null,
            StatusCode: null,
            RatingComments: null
        };
    },

    getNewMultiAnswerObject: function (groupName, codeId, answerCode) {
        return {
            DataState: 0,
            AnswerID: null,
            GroupName: groupName,
            AnswerCode: answerCode,
            CodeDescriptionID: codeId
        };
    },
    getItemParticipantByItemName_OLD: function (item, itemName) {

        var partcipants = [],
            container = this.getView(),
            motherField = container.down('#item' + itemName + 'ParticipantMother'),
            fatherField = container.down('#item' + itemName + 'ParticipantFather'),
            childField = container.down('#item' + itemName + 'ParticipantChild'),
            children = [],
            mothers = [],
            fathers = []
            ;

        if (motherField) {
            var mother = motherField.getValue()["Item" + itemName + 'ParticipantMother'];
            if (!Ext.isArray(mother)) {
                mothers.push(mother);
            }
            else {
                mothers = mother;
            }
            Ext.each(mothers, function (m) {
                partcipants.push({
                    CodeDescriptionID: 269,
                    DataState: 0,
                    ItemID: item.ItemID,
                    ParticipantID: m
                });
            });

        }

        if (fatherField) {
            var father = fatherField.getValue()["Item" + itemName + 'ParticipantFather'];
            if (!Ext.isArray(father)) {
                fathers.push(father);
            }
            else {
                fathers = father;
            }
            Ext.each(fathers, function (f) {
                partcipants.push({
                    CodeDescriptionID: 270,
                    DataState: 0,
                    ItemID: item.ItemID,
                    ParticipantID: f
                });
            });
        }
        if (childField) {
            var child = childField.getValue()["Item" + itemName + 'ParticipantChild'];
            if (!Ext.isArray(child)) {
                children.push(child);
            }
            else {
                children = child;
            }
            Ext.each(children, function (m) {
                partcipants.push({
                    CodeDescriptionID: 271,
                    DataState: 0,
                    ItemID: item.ItemID,
                    ParticipantID: m
                });
            });
        }

        return partcipants;
    },
    getItemParticipantByItemName: function (item, itemName) {

        var participants = [],
            vm = this.getViewModel(),
            mothers = vm.get('caseReview.Item' + itemName + 'ParticipantMother'),
            fathers = vm.get('caseReview.Item' + itemName + 'ParticipantFather'),
            children = vm.get('caseReview.Item' + itemName + 'ParticipantChild'),
            isApplicable = vm.get('caseReview.Item' + itemName + 'IsApplicable') === 1,
            isMotherApplicable = isApplicable,
            isFatherApplicable = isApplicable,
            isChildrenApplicable = isApplicable

            ;

        if (itemName === '12b') {
            isMotherApplicable = vm.get('caseReview.IsNeedsServicesApplicableForMother') === 1;
            isFatherApplicable = vm.get('caseReview.IsNeedsServicesApplicableForFather') === 1;

        }
        if (isMotherApplicable)
            Ext.each(mothers, function (m) {
                participants.push({
                    CodeDescriptionID: 269,
                    DataState: 0,
                    ItemID: item.ItemID,
                    ParticipantID: m
                });
            });

        if (isFatherApplicable)
            Ext.each(fathers, function (f) {
                participants.push({
                    CodeDescriptionID: 270,
                    DataState: 0,
                    ItemID: item.ItemID,
                    ParticipantID: f
                });
            });


        if (isChildrenApplicable)
            Ext.each(children, function (c) {
                participants.push({
                    CodeDescriptionID: 271,
                    DataState: 0,
                    ItemID: item.ItemID,
                    ParticipantID: c
                });
            });

        return participants;
    },
    onItem12bMotherApplicabilityChanged: function (field, value) {
        //console.log(arguments,field.getValue())
        if (value.IsNeedsServicesApplicableForMother === 2) {
            var item12bParticipantMother = field.up('panel').down('#item12bParticipantMother');
            if (item12bParticipantMother)
                item12bParticipantMother.setValue([]);
        }
    },
    onItem12bFatherApplicabilityChanged: function (field, value) {
        //console.log(arguments)
        if (value.IsNeedsServicesApplicableForFather === 2) {
            var item12bParticipantFather = field.up('panel').down('#item12bParticipantFather');
            if (item12bParticipantFather)
                item12bParticipantFather.setValue([]);
        }
    },
    getApplicability: function (arr, codeDescId) {
        var data = arr.filter(function (item) {
            return item.CodeDescriptionID === codeDescId;
        });
        if (!Ext.isEmpty(data) && Ext.isArray(data) && data.length > 0) {
            return data[0];
        }
        return null;
    },
    onCaseStatusUpdate: function (btn) {
        //   console.log('onCaseStatusUpdate')

        var me = this,
            vm = me.getViewModel(),
            record = vm.get('caseReview'),
            status = 0,
            hasNote = vm.get('hasCaseOrCaseInterviewNote'),
            hasParticipantInterviewed = vm.get('hasParticipantInterviewed'),
            hasDemographicChildInterviewed = vm.get('hasDemographicChildInterviewed'),
            errorMsg;

        Ext.MessageBox.confirm('Confirm?', 'Are you sure you want to ' + btn.text + '?', function (action) {
            if (action === 'yes') {
                //  console.log(record.get('CaseStatusCode'))
                if (record) {
                    switch (record.get('CaseStatusCode')) {
                        case 1:
                            status = 4;
                            break;
                        case 4:
                            status = btn.direction === 'next' ? 5 : 1;
                            break;
                        case 5:
                            status = 7;
                            break;
                        case 7:
                            status = 4;
                            break;
                    }

                    if (record.get('CaseStatusCode') === 1) {
                        if (!hasNote && hasDemographicChildInterviewed) {
                            errorMsg = 'For table G1, you entered Interviewed for child. Please enter at least one Case Interview Notes.';
                        }
                        else if (!hasNote && hasParticipantInterviewed) {
                            errorMsg = 'For table G2, you entered Interviewed for participant. Please enter at least one Case Interview Notes.';
                        }
                    }

                    if (!Ext.isEmpty(errorMsg)) {
                        Ext.Msg.show({
                            title: 'Interview Notes Missing',
                            msg: errorMsg,
                            buttons: Ext.MessageBox.OK,
                            icon: Ext.MessageBox.ERROR
                        });
                    }
                    else {
                        record.set('CaseStatusCode', status);
                        me.saveData(record, null);
                    }
                }
            }
        });
    },
    onCaseExport: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            rec = vm.get('caseReview'),
            caseId = rec.get('CaseID'),
            rootId = rec.get('CaseReviewRootID'),
            reviewId = rec.get('CaseReviewID'),
            url = QuickStart.util.Global.getCaseExportUrl();

        if (Ext.isEmpty(url)) {
            QuickStart.util.Global.showMessage("Download url does not exist");
            return;
        }
        url = url.replace('{CASEID}', caseId).replace('{CASEREVIEWID}', reviewId).replace('{FORMAT}', btn.format);

        me.downloadFile(url);
    },

    onCaseEliminateGenerateFederalRequestClick: function (btn) {

        var me = this,
            vm = me.getViewModel(),
            win = me.getView().down('#eliminateRequestWindow'),
            form = win.down('form').getForm(),
            record,
            reviewers = [],
            targetChild = vm.get('totalDemographicTargetChildRows'),
            targetChildName,
            myMask = new Ext.LoadMask({ msg: 'Please wait...', target: win }),
            action = 'case/GetEliminationRequestForm',
            preData = {};

        Ext.each(vm.get('caseReview.CR_Reviewer_Collection'), function (rev) {
            reviewers.push(vm.getLookupDataValue('CrSecurityUser', rev.UserID));
        });

        if (targetChild && targetChild.length > 0) {
            targetChildName = targetChild[0].Name;
        }
        preData = {
            QaTeam: QuickStart.util.Global.getUser().name,
            CaseId: vm.get('caseReview.CaseID'),
            CaseName: vm.get('caseReview.CaseName'),
            CaseReviewId: vm.get('caseReview.CaseReviewID'),
            CaseReviewRootId: vm.get('caseReview.CaseReviewRootID'),
            CaseType: vm.getLookupDataValue('CrReviewSubType', vm.get('caseReview.ReviewSubTypeID')),
            ScheduledReviewMonth: Ext.Date.format(new Date(vm.get('caseReview.ReviewStartDate')), 'm/d/Y') + ' - ' + Ext.Date.format(new Date(vm.get('caseReview.ReviewStartDate')), 'm/d/Y'),
            Reviewers: reviewers.join(', '),
            TargetChildName: targetChildName

        };
        record = Ext.create('QuickStart.model.casereview.EliminationRequest');
        //  form.reset();
        win.show(btn);
        vm.set('current.eliminationRequest', record);

        myMask.show();
        Ext.Ajax.request({
            url: QuickStart.util.Global.getApi() + action,
            method: 'GET',
            params: { id: vm.get('caseReview.CaseReviewID') },
            success: function (response, opts) {
                myMask.hide();
                var result = Ext.decode(response.responseText);
                if (result !== null && result.success && result.data) {
                    Ext.apply(result.data, preData);
                    record.set(result.data);
                }
                else {
                    record.set(preData);
                }
            },
            failure: function (response, opts) {
                myMask.hide();
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });

    },
    onCaseEliminateGenerateFederalRequestSubmit: function (btn) {
        var me = this,
            win = btn.up('window'),
            form = win.down('form').getForm(),
            vm = me.getViewModel(),
            record = vm.get('current.eliminationRequest'),
            data = record.getData(),
            myMask = new Ext.LoadMask({ msg: 'Please wait...', target: win }),
            action = 'case/SendEliminationRequestForm';

        data.RequestedDate = new Date();
        data.Created = new Date();
        data.CreatedBy = QuickStart.util.Global.getUser().id;

        myMask.show();
        Ext.Ajax.request({
            url: QuickStart.util.Global.getApi() + action,
            method: 'POST',
            params: { userID: QuickStart.util.Global.getUser().id },
            jsonData: data,
            success: function (response, opts) {
                myMask.hide();
                var result = Ext.decode(response.responseText);
                if (result !== null && result.success) {
                    QuickStart.util.Global.showMessage(result.message);
                    win.close();
                }
                else {
                    QuickStart.util.Global.showMessage(result.message);
                }
            },
            failure: function (response, opts) {
                myMask.hide();
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });
    },
    onCasePreview: function (btn) {
        var me = this,
            win = me.getView().down('#previewWindow'),
            vm = me.getViewModel(),
            record = vm.get('caseReview'),
            params = {
                caseReviewRootId: record.get('CaseReviewRootID'),
                caseReviewId: record.get('CaseReviewID'),
                userID: QuickStart.util.Global.getUser().id
            },
            myMask = new Ext.LoadMask({ msg: 'Please wait...', target: win }),
            url = QuickStart.util.Global.getApi() + 'case/GetPreview';

        win.show(btn);

        myMask.show();
        Ext.Ajax.request({
            url: url,
            method: 'GET',
            params: params,
            success: function (response, opts) {
                myMask.hide();
                var result = Ext.decode(response.responseText);
                if (result !== null) {
                    if (!Ext.isEmpty(result.data)) {
                        console.log(result.data);
                        var record = Ext.create('QuickStart.model.casereview.Preview', result.data);
                        var data = record.getData();
                        // console.log('Outcome', data.Outcomes)

                        win.down('casepreviewcontainer').setData(result.data);
                    }
                }
            },
            failure: function (response, opts) {

                myMask.hide();
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });
    },

    onCaseComparePreview: function (btn) {
        var me = this,
            win = me.getView().down('#compareWindow'),
            vm = me.getViewModel(),
            record = vm.get('caseReview'),
            params = {
                caseReviewRootId: record.get('CaseReviewRootID'),
                caseReviewId: record.get('CaseReviewID'),
                caseId: record.get('CaseID'),
                userID: QuickStart.util.Global.getUser().id
            },
            myMask = new Ext.LoadMask({ msg: 'Please wait...', target: win }),
            url = QuickStart.util.Global.getApi() + 'case/GetComparePreview';

        win.show(btn);

        myMask.show();
        Ext.Ajax.request({
            url: url,
            method: 'GET',
            params: params,
            success: function (response, opts) {
                myMask.hide();
                var result = Ext.decode(response.responseText);
                if (result !== null) {
                    if (!Ext.isEmpty(result.data)) {

                        var record = Ext.create('QuickStart.model.casereview.Preview', result.data.Case);
                        var irrRecord = Ext.create('QuickStart.model.casereview.Preview', result.data.Irr);
                        var data = record.getData();
                        var rec = Ext.apply({}, data);
                        rec = Ext.apply(rec, { Irr: irrRecord.getData() });
                        win.down('casecomparecontainer').setData(rec);
                        console.log(rec);

                    }
                }
            },
            failure: function (response, opts) {

                myMask.hide();
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });
    },
    highlightedUnresolvedTab: function () {
        //if you want to disable this feature then uncommented below line
        //return;

        var me = this,
            vm = me.getViewModel();

        if (!vm.get('disabledItem')) {
            //var tabs = Ext.Array.unique(vm.getFieldTabMap().getValues()),
            var tabs = vm.getFieldTabMapList(),
                unresolvedTab = vm.get('unresolvedTab'),
                ui, tooltip, tab, errorList, btn, tooltips = [];

            //Ext.each(tabs, function (tab) {
            for (tab in tabs) {
                btn = me.getView().down('component[category=' + tab + ']');
                if (!btn)
                    continue;

                ui = tab === 'facesheet' ? 'case-item' : 'case-sub-item1';
                tooltip = QuickStart.util.Resources.tips.itemMenu.toolTip(tab);

                if (!btn.disabled) {
                    item = vm.get('caseReview.' + Ext.String.capitalize(tab));
                    if (tab === 'facesheet' || (item && item.StatusCode && item.StatusCode !== 3)) {
                        if (unresolvedTab.containsKey(tab)) {
                            ui = tab === 'facesheet' ? 'case-item-unresolved' : 'case-sub-item-unresolved';
                            errorList = unresolvedTab.get(tab);
                            tooltips.push('<ul>');
                            //errorlist contains key and value pair collection
                            Ext.each(errorList, function (error) {
                                tooltips.push('<li>' + error.value + '</li>');
                            });
                            tooltips.push('</ul>');
                            tooltip = tooltips.join('');
                        }
                    }
                }
                if (btn.ui !== ui && btn.ui !== ui + '-small') {
                    btn.setUI(ui);
                }

                btn.setTooltip(tooltip);
                if (unresolvedTab.containsKey('facesheet'))
                    break;
            }
        }
    },
    hasItemContainErrors: function (inputItem) {
        var me = this,
            vm = me.getViewModel(),
            tabs = vm.getFieldTabMapList(),
            unresolvedTab = vm.get('unresolvedTab');

        for (tab in tabs) {
            if (tabs[tab].itemCode !== inputItem)
                continue;

            return unresolvedTab.containsKey(tab);
        }
        return false;
    },
    updateCaseforErrors: function (data) {
        var me = this,
            vm = me.getViewModel(),
            unresolvedTab = vm.get('unresolvedTab');

        if ((data.CaseStatusCode === 1 || data.CaseStatusCode === 4) && unresolvedTab.getCount() > 0) {
            data.CaseStatusCode = 2;
        }
        return data;
    }
});