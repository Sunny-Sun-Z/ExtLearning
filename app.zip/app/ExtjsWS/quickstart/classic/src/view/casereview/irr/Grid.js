/**
 * Created by kkora on 9/13/2017.
 */
Ext.define('QuickStart.view.casereview.irr.Grid', {
    extend: 'Ext.grid.Panel',

    requires: [

    ],

    alias: 'widget.irrgrid',

    reference: 'irrGrid',
    title: 'IRR Cases',
    bind: '{irrStore}',

    headerBorders: false,
    columns: [
        {
            text: 'View',
            menuDisabled: true,
            renderer: function (val, meta, record) {

                //  var url = window.location.host + window.location.pathname + '#casereview/' + record.get('CaseReviewRootID');
                var url = window.location.origin + window.location.pathname + '#case/' + record.get('CaseReviewRootID') + '/' + record.get('CaseReviewID');
                return '<a href="' + url + '">View</a>';
            }
        },
        {
            menuDisabled: true,
            text: 'Case ID',
            dataIndex: 'CaseID'
        },
        {
            menuDisabled: true,
            hidden: true,
            text: 'Type',
            flex: 1,
            dataIndex: 'ReviewTypeID',
            renderer: 'rendererReviewType'
        },
        {
            menuDisabled: true,
            text: 'Sub Type',
            flex: 1,
            dataIndex: 'ReviewSubTypeID',
            renderer: 'rendererReviewSubType'
        },
        {
            text: 'Case Name',
            menuDisabled: true,
            flex: 2,
            dataIndex: 'CaseName'

        },
        {
            menuDisabled: true,
            text: 'Status',
            flex: 1,
            dataIndex: 'CaseStatusCode',
            renderer: 'rendererCaseStatus'
          },
        {
            menuDisabled: true,
            text: 'Review Start',
            //flex: 1,
            dataIndex: 'ReviewStartDate',
            formatter: 'date("m/d/Y")'
            // ,renderer: 'dateRenderer'


        },
        {
            text: 'Review End',
            menuDisabled: true,
           // flex: 1,
            dataIndex: 'ReviewCompleted',
            formatter: 'date("m/d/Y")'
            //, renderer: 'dateRenderer'
        },
        {
            menuDisabled: true,
            text: 'Site Name',
            flex: 1,
            dataIndex: 'SiteCode',
            renderer: 'rendererSite'
        },
        {
            flex: 1,
            hidden: true,
            sortable: false,
            menuDisabled: true,
            text: 'Reviewer(s)',
            //cellWrap:true,
            dataIndex: 'Reviewers',
            renderer: 'renderReviewers'
        },
        {
            menuDisabled: true,
            text: 'IRR Reviewer',
            flex: 1,
            dataIndex: 'IRRReviewerID',
            renderer: 'rendererUser'

        }
    ],
    viewConfig: {
        emptyText: '<div style="text-align:center;font-weight:bold"> No Record Found</div>',
        forceFit: true
    },
    dockedItems: [
        {// ui:'footer',
            xtype: 'toolbar',

            items: [{
                bind: {
                    hidden: '{!allowedCreateIRRCase}'
                },
                text: 'Add',
                ui: 'dcf',
                iconCls: 'x-fa fa-plus light',
                tooltip: 'Add New Case',
                handler: 'onAddIrrCaseClick'
            }, '->',
                {
                    xtype: 'textfield',
                    itemId: 'searchText',
                    emptyText: 'Search...',
                    flex: 1,
                    triggers: {
                        clear: {
                            weight: -1,
                            cls: 'x-form-clear-trigger',
                            handler: function () {
                                this.setValue('');
                            }
                        }
                    },
                    listeners: {
                        change: 'onSearch',
                        delay:300
                    }

                }
            ]
        },

        {
            xtype: 'pagingtoolbar',
            dock: 'bottom',
            itemId: 'paginationToolbar',
            displayInfo: true,
            bind: '{irrStore}'

        }
    ]
});