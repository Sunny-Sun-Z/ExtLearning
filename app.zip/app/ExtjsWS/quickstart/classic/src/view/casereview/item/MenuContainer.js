/**
 * Created by kkora on 9/22/2017.
 */
Ext.define('QuickStart.view.casereview.item.MenuContainer', {
    extend: 'Ext.Container',

    xtype: 'itemmenucontainer',

    requires: [
        'QuickStart.view.common.ItemButton'
    ],
    region: 'west',
    // width: 360,
    width: 260,
    //flex: 1,
    split: {width: 2},
    defaults: {
        xtype: 'panel',
        //scrollable: 'y',
        width: '100%',
        margin: '0 0 0 20'
    },
    scrollable: 'y',
    title: 'left',
    layout: {
        //type: 'vbox',
        //  align: 'stretch'
    },
    items: [
        {
            category: 'notetab',
            textAlign: 'left',
            ui: 'case-item',
            margin: '0 0 0 20',
            text: 'Case QA/Interview Notes',
            xtype: 'itembutton'
        },
        {
            textAlign: 'left',
            ui: 'case-item',
            // margin: '0 0 0 5',
            margin: '0 0 0 20',
            text: 'Case Overview',
          //  pressed: true,
            category: 'overview',
            xtype: 'itembutton'

        },
        {
            textAlign: 'left',
            ui: 'case-item',
            //  margin: '0 0 0 5',
            margin: '0 0 0 20',
            text: 'Face Sheet',
            pressed:true,
            category: 'facesheet',
            xtype: 'itembutton',
            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('facesheet'),
            itemCode:23
        },
        {
            textAlign: 'left',
            ui: 'case-item',
            //  margin: '0 0 0 5',
            margin: '0 0 0 20',
            text: 'Section I: Safety',
            category: 'safetyoverview',
            xtype: 'itembutton'
        },
        // {
        //     textAlign: 'left',
        //     ui: 'case-item',
        //     //  margin: '0 0 0 5',
        //     margin: '0 0 0 20',
        //     text: 'Safety',
        //     category: 'safety',
        //     xtype: 'itembutton'
        // },
        {
            // title: 'Section I: Safety',
            defaults: {
                xtype: 'itembutton',
                ui: 'case-sub-item'
            },
            category: 'safety',
            items: [
                {
                    text: 'Outcome 1',
                    category: 'safetyoutcome1',
                    tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('safetyoutcome1'),
                    outComeCode: 1
                }, {
                    xtype: 'fieldcontainer',
                    padding: '0 0 0 20px',
                    items: [
                        {
                            xtype: 'itembutton',
                            text: 'Item 1',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item1'),
                            category: 'item1',
                            itemCode: 2
                        }
                    ]
                },
                {
                    text: 'Outcome 2',
                    category: 'safetyoutcome2',
                    tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('safetyoutcome2'),
                    outComeCode: 2
                },
                {
                    xtype: 'fieldcontainer',
                    padding: '0 0 0 20px',
                    defaults: {
                        xtype: 'itembutton'
                    },
                    items: [
                        {
                            text: 'Item 2',
                            category: 'item2',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item2'),
                            itemCode: 3
                        },
                        {
                            text: 'Item 3',
                            category: 'item3',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item3'),
                            itemCode: 4
                        }
                    ]
                }

            ]
        },
        {
            textAlign: 'left',
            ui: 'case-item',
            //  margin: '0 0 0 5',
            margin: '0 0 0 20',
            text: 'Section II: Permanency',
            category: 'permanencyoverview',
            xtype: 'itembutton',
            bind: {
                disabled: '{!isFosterCareCase}'
            }
        },
        // {
        //     textAlign: 'left',
        //     ui: 'case-item',
        //     //  margin: '0 0 0 5',
        //     margin: '0 0 0 20',
        //     text: 'Permanency',
        //     category: 'permanency',
        //     xtype: 'itembutton'
        // },
        {
            category: 'permanency',
            bind: {
                disabled: '{!isFosterCareCase}'
            },
            defaults: {
                xtype: 'itembutton',
                ui: 'case-sub-item'
            },
            items: [
                {
                    text: 'Outcome 1',
                    category: 'permanencyoutcome1',
                    tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('permanencyoutcome1'),
                    outComeCode: 3
                },
                {
                    xtype: 'fieldcontainer',
                    padding: '0 0 0 10px',
                    defaults: {
                        xtype: 'itembutton'
                    },
                    items: [
                        {
                            text: 'Item 4',
                            category: 'item4',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item4'),
                            itemCode: 5
                        },
                        {
                            text: 'Item 5',
                            category: 'item5',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item5'),
                            itemCode: 6
                        },
                        {
                            text: 'Item 6',
                            category: 'item6',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item6'),
                            itemCode: 7
                        }
                    ]
                },
                {
                    text: 'Outcome 2',
                    category: 'permanencyoutcome2',
                    tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('permanencyoutcome2'),
                    outComeCode: 4
                },
                {
                    xtype: 'fieldcontainer',
                    padding: '0 0 0 10px',
                    defaults: {
                        xtype: 'itembutton'
                    },
                    items: [
                        {
                            text: 'Item 7',
                            category: 'item7',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item7'),
                            itemCode: 8
                        },
                        {
                            text: 'Item 8',
                            category: 'item8',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item8'),
                            itemCode: 9
                        },
                        {
                            text: 'Item 9',
                            category: 'item9',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item9'),
                            itemCode: 10
                        },
                        {
                            text: 'Item 10',
                            category: 'item10',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item10'),
                            itemCode: 11
                        },
                        {
                            text: 'Item 11',
                            category: 'item11',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item11'),
                            itemCode: 12
                        }
                    ]
                }
            ]
        },
        {
            textAlign: 'left',
            ui: 'case-item',
            //  margin: '0 0 0 5',
            margin: '0 0 0 20',
            text: 'Section III: Child & Family<br/> Well-Being',
            category: 'wellbeingoverview',
            xtype: 'itembutton'
        },
        // {
        //     textAlign: 'left',
        //     ui: 'case-item',
        //     //  margin: '0 0 0 5',
        //     margin: '0 0 0 20',
        //     text:  'Well-Being',
        //     category: 'wellbeing',
        //     xtype: 'itembutton'
        // },
        {
            //  title: 'Section III: Child & Family<br/> Well-Being',
            tooltip: 'Section III: Child & Family Well-Being',
            category: 'wellbeing',
            //  flex: 3,
            defaults: {
                xtype: 'itembutton',
                ui: 'case-sub-item'
            },
            items: [
                {
                    text: 'Outcome 1',
                    category: 'wellbeingoutcome1',
                    tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('wellbeingoutcome1'),
                    outComeCode: 5
                },
                {
                    xtype: 'fieldcontainer',
                    padding: '0 0 0 10px',
                    defaults: {
                        xtype: 'itembutton'
                    },
                    items: [
                        {
                            text: 'Item 12',
                            category: 'item12',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item12'),
                            itemCode: 13
                        },
                         {
                            text: 'Item 12A',
                            category: 'item12a',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item12a'),
                            itemCode: 14
                        },
                        {
                            text: 'Item 12B',
                            category: 'item12b',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item12b'),
                            itemCode: 15
                        },
                        {
                            text: 'Item 12C',
                            category: 'item12c',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item12c'),
                            itemCode: 16
                        },
                          {
                            text: 'Item 13',
                            category: 'item13',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item13'),
                            itemCode: 17
                        },
                        {
                            text: 'Item 14',
                            category: 'item14',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item14'),
                            itemCode: 18
                        },
                        {
                            text: 'Item 15',
                            category: 'item15',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item15'),
                            itemCode: 19
                        }
                    ]
                },
                {
                    text: 'Outcome 2',
                    category: 'wellbeingoutcome2',
                    tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('wellbeingoutcome2'),
                    outComeCode: 6
                },
                {
                    xtype: 'fieldcontainer',
                    padding: '0 0 0 10px',
                    layout: 'hbox',
                    items: [
                        {
                            xtype: 'itembutton',
                            text: 'Item 16',
                            category: 'item16',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item16'),
                            itemCode: 20
                        }
                    ]
                },
                {
                    text: 'Outcome 3',
                    category: 'wellbeingoutcome3',
                    tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('wellbeingoutcome3'),
                    outComeCode: 7
                },
                {
                    xtype: 'fieldcontainer',
                    padding: '0 0 0 10px',
                    defaults: {
                        xtype: 'itembutton'
                    },
                    items: [
                        {
                            text: 'Item 17',
                            category: 'item17',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item17'),
                            itemCode: 21
                        },
                        {
                            text: 'Item 18',
                            category: 'item18',
                            tooltip: QuickStart.util.Resources.tips.itemMenu.toolTip('item18'),
                            itemCode: 22
                        }
                    ]
                }
            ]
        }
        // {flex: 1, xtype: 'tbfill'},

    ]
});