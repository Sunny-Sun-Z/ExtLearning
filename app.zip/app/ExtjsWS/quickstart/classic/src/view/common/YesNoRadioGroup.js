/**
 * Created by kkora on 9/7/2017.
 */
Ext.define('QuickStart.view.common.YesNoRadioGroup', {
    extend: 'Ext.form.RadioGroup',
    config: {
        yes: 1,
        no: 0
    },
    xtype: 'yesnoradiogroup',
    publishes: 'value',
    //labelWidth: '100%',
    labelAlign: 'top',
    items: [],
    layout: 'hbox',
    disabledCls: 'disable-item',
   // defaults: { disabledCls: 'disable-item'},
    msgTarget: 'under',
    // cls:'x-form-cb-label-bold',
    initComponent: function () {

        var me = this,
            name = me.name||me.getId(),
            yesValue = 1,
            noValue = 2,
            yesChecked = false,
            noChecked = false,
            yesField = {boxLabel: 'Yes'},
            noField = {boxLabel: 'No', margin:'0 0 0 20'}

        ;

        if (me.yes) {
            yesValue = me.yes;
            if (Ext.isObject(me.yes)) {
                yesValue = me.yes.value||1;
                yesChecked = me.yes.checked;
            }
        }
        if (me.no) {
            noValue = me.no;
            if (Ext.isObject(me.no)) {
                noValue = me.no.value||2;
                noChecked = me.no.checked;
            }
        }
        yesField.name = noField.name = name;
        yesField.inputValue = yesValue;
        noField.inputValue = noValue;
        if (yesChecked) {
            yesField.checked = yesChecked;
        }
        if (noChecked) {
            noField.checked = noChecked;
        }
        me.items=[];
        me.items.push(yesField);
        me.items.push(noField);

        if(me.fieldLabel.lastIndexOf('?')>=0){
            me.labelSeparator='';
        }
        me.callParent();
    }

});