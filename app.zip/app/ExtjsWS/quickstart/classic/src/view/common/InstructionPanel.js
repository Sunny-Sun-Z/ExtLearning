/**
 * Created by kkora on 9/6/2017.
 */

Ext.define('QuickStart.view.common.InstructionPanel', {
    extend: 'Ext.panel.Panel',

    xtype: 'instructionpanel',
    viewModel: {
        data: {
            showInstruction: false
        }
    },
    header:{
      padding:'7 10'
    },
    tools: [{
        xtype: 'button',
      //  iconCls:'x-fa fa-question',
      //  iconAlign:'right',
        bind: {
            hidden: '{disabledItem}',
            text: '{!showInstruction?"Show Instructions" :"Hide Instructions"}'
        },
        handler: function (btn) {
            var vm = btn.up('panel').getViewModel();
            vm.set('showInstruction', !vm.get('showInstruction'));
        }
    }],
    bind: {
        disabled: '{disabledItem}'
    },
    title: '',
    cls:'shadow',
    shadow: true,
    disabledCls: 'disable-item',
    defaults: { disabledCls: 'disable-item'},

    initComponent: function () {
        var me = this,
            instruction = {
                xtype: 'component',
                bind: {
                    hidden: '{!showInstruction}'
                },
                margin: 10,
                html: me.text
            },
            items = []
        ;

        if (me.items) {
            if (me.instructionAlign == 'bottom') {
                Ext.each(me.items, function (item) {
                    items.push(item);
                });
                items.push(instruction);
            } else {
                items.push(instruction);
                Ext.each(me.items, function (item) {
                    items.push(item);
                });
            }
        }
        else {
            items.push(instruction);
        }
        me.items = items;
        me.callParent();
    }

});