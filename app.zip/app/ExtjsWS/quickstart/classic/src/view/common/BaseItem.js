/**
 * Created by kkora on 10/5/2017.
 */
Ext.define('QuickStart.view.common.BaseItem', {
    extend: 'Ext.Container',
    xtype: 'baseitem',
    requires: [

    ],

    defaults: {margin: '0 20 20 0'},
    bind: {
        disabled: '{disabledItem}'
    },
    disabledCls: 'disable-item',
    maskOnDisable: false
});