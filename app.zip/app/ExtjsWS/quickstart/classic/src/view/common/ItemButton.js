/**
 * Created by kkora on 9/20/2017.
 */

Ext.define('QuickStart.view.common.ItemButton', {
    extend: 'Ext.button.Button',
    xtype: 'itembutton',
    config: {
        outComeCode: null,
        itemCode: null,
        category: null,
        panelRefId: null
    },
    ui: 'case-sub-item1',
    handler: 'onCaseItemClick',
    enableToggle :true,
    toggleGroup : 'menu',
    applyOutComeCode: function (val) {
        if (Ext.isEmpty(this.getCategory())) {

            switch (val) {
                case 1:
                case 2:
                    this.setCategory('safety');
                    break;
                case 3:
                case 4:
                    this.setCategory('permanency');
                    break;
                case 5:
                case 6:
                case 7:
                    this.setCategory('wellbeing');
                    break;
                case 21:
                    this.setCategory('facesheet');
                    break;

            }
        }
    },
    applyItemCode: function (val) {
     //   console.log('item', val)
        if (Ext.isEmpty(this.getCategory())) {
            switch (val) {
                case 2:
                    this.setCategory('safety');
                    this.setOutComeCode(1);
                    break;
                case 3:
                case 4:
                    this.setCategory('safety');
                    this.setOutComeCode(2);
                    break;
                case 5:
                case 6:
                case 7:
                    this.setCategory('permanency');
                    this.setOutComeCode(3);
                    break;
                case 8:
                case 9:
                case 10:
                case 11:
                case 12:
                    this.setCategory('permanency');
                    this.setOutComeCode(4);
                    break;
                case 13:
                case 14:
                case 15:
                case 16:
                case 17:
                case 18:
                case 19:
                    this.setCategory('wellbeing');
                    this.setOutComeCode(5);
                    break;
                case 20:
                    this.setCategory('wellbeing');
                    this.setOutComeCode(6);
                    break;
                case 21:
                case 22:
                    this.setCategory('wellbeing');
                    this.setOutComeCode(7);
                    break;
                case 23:
                    this.setCategory('facesheet');
                    break;


            }
        }
    }

});