/**
 * Created by kkora on 10/25/2017.
 */
Ext.define('QuickStart.view.common.YesNoNarrativeField', {
    extend: 'Ext.form.field.TextArea',
    xtype: 'yesnonarrativefield',
    flex: 1,
    anchor: '100%',
    labelAlign: 'top',
    disabled: true,
    disabledCls: 'disable-item',
    allowBlank:true,
    msgTarget: 'side',
    fieldLabel: 'If No, explain any concerns in the narrative field below',
    listeners:{
        disable:function(field){
            field.allowBlank = field.disabled;
            //console.log('disable',field.disabled)
        },
        enable:function(field){
            field.allowBlank = field.disabled;
            field.isValid();
          //  console.log('enable',field.disabled)
        }

    }
});