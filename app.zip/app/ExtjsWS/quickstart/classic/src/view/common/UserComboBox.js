/**
 * Created by kkora on 9/7/2017.
 */
Ext.define('QuickStart.view.common.UserComboBox', {
    extend: 'Ext.form.ComboBox',
    xtype: 'usercombo',
    fieldLabel: 'User',
    name: 'UserId',
    displayField: 'Name',
    valueField: 'Id',
    forceSelection: true,
    queryMode: 'remote',
    minChars: 1,
    triggerAction: 'all',
    tpl: new Ext.create('Ext.XTemplate',
       '<tpl for=".">',
        '<div class="x-boundlist-item">',
            "<div class='user-item'>",
                '<tpl if="Avatar==true">',
                    "<img src='user/GetProfilePicture?id={Id}' alt='Smiley face' class='profile-icon'>",
                '<tpl else>',
                     "<img src='{Avatar:this.defaultProfile}' alt='default' class='profile-icon'>",
                '</tpl>',
                "<div class='content-wrap'>",
                    "<div>",
                        "<h4 class='username'>{Name}</h4>",
                        "<span class='active-status'><span class='{[values.IsActive ? 'x-fa fa-check-circle':'x-fa fa-ban']}'></span></span>",
                    "</div>",
                    "<h4 class='reviewer'>{Role}</h4>",
                    "<h4 class='email'>{Email}</h4>",
                    "<div class='content'></div>",
                "</div>",
            "</div>",
        '</div>',
      '</tpl>', {
          defaultProfile: function (val) {
              return QuickStart.util.Global.getResources() + '/images/user-profile/default.png';;
          }
      })  

});