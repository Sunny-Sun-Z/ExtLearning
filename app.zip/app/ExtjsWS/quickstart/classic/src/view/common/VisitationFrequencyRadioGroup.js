/**
 * Created by kkora on 9/7/2017.
 */
Ext.define('QuickStart.view.common.VisitationFrequencyRadioGroup', {
    extend: 'Ext.form.RadioGroup',

    xtype: 'visitationfrequencydiogroup',
    labelAlign: 'top',
    publishes: 'value',

    layout: 'vbox',
    disabledCls: 'disable-item',
    defaults: {margin: '0 10 0 0',  disabledCls: 'disable-item'},
    items: [
        {
            boxLabel: 'NA',
            inputValue: 1
        },
        {
            boxLabel: 'More than once a week',
            inputValue: 2
        },
        {
            boxLabel: 'Once a week',
            inputValue: 3
        },
        {
            boxLabel: 'Less than once a week, but at least twice a month',
            inputValue: 4
        },
        {
            boxLabel: 'Less than twice a month, but at least once a month',
            inputValue: 5
        },
        {
            boxLabel: 'Less than once a month',
            inputValue: 6
        },
        {
            boxLabel: 'Never',
            inputValue: 7
        }
    ],
    initComponent: function () {

        var me = this,
            name = me.name||me.getId()
        ;

        if(me.fieldLabel.lastIndexOf('?')>=0){
            me.labelSeparator='';
        }
        me.callParent();
    }

});