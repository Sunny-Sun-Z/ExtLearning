/**
 * Created by kkora on 9/7/2017.
 */
Ext.define('QuickStart.view.common.DateContainer', {
    extend: 'Ext.form.FieldContainer',
    config: {
        dateValue:null,
        naValue:null,
        allowNa: false
    },
    xtype: 'datecontainer',
    labelWidth: '100%',
    labelAlign: 'top',
    items: [],
    layout: 'hbox',
    defaults: {
        margin: '0 20 0 0'
    },
    //cls:'x-form-cb-label-bold',
    initComponent: function () {

        var me = this,
            name = me.name || me.getId()
        ;

        me.items = [{
            bind:{
                value:'{dateValue}'
            },
            xtype: 'datefield'
        }];

        if (me.fieldLabel.lastIndexOf('?') >= 0) {
            me.labelSeparator = '';
        }
        if (me.allowNa === true) {
            me.items.push({
                xtype: 'checkbox',
                inputValue: 1,
                uncheckedValue: 2,
                boxLabel: 'NA'
            });
        }
        if (me.additionalItems && Ext.isArray(me.additionalItems) && me.additionalItems.length > 0) {
            Ext.each(me.additionalItems, function (item) {
                me.items.push(item);
            });
        }

        me.callParent();
    },
    updateDateValue:function (value) {
        var date= this.items.items[0];
        date.setValue(value);

    },
    updateNaValue:function (value) {
        var check= this.items.items[1];
        check.setValue(value);
    }

});