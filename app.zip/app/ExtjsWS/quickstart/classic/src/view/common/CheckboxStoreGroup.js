/**
 * Created by kkora on 9/11/2017.
 */
Ext.define('QuickStart.view.common.CheckboxStoreGroup', {
    extend: 'Ext.form.CheckboxGroup',
    alias: 'widget.checkboxstoregroup',
    config: {
        store: null,
        labelField: 'label',
        valueField: 'id',
        checkedField: 'checked',
        columns: 1,
        fieldName: 'mycheckbox'

    },
    applyStore: function (store) {
        if (Ext.isString(store)) {
            return Ext.getStore(store);
        } else {
            return store;
        }
    },
    updateStore: function (newStore, oldStore) {
        if (oldStore) {
            oldStore.removeEventListener('datachanged', this.onStoreChange, this);
        }
        newStore.on('datachanged', this.onStoreChange, this);
    },
    onStoreChange: function (s) {

        Ext.suspendLayouts();
        this.removeAll();


        var vField = this.getValueField();
        var lField = this.getLabelField();
        var cField = this.getCheckedField();
        var fName = this.getFieldName();
        var rec = null;
        var otherRef = '';
        for (var i = 0; i < s.getCount(); i++) {
            rec = s.getAt(i);
            var checkbox = {
                xtype: 'checkbox',
                inputValue: rec.get(vField),
                boxLabel: rec.get(lField),
                checked: rec.get(cField),
                name: fName
            };
            if (checkbox.boxLabel === 'Other (specify)') {
                otherRef = fName + 'Other' + checkbox.inputValue;
                checkbox.reference = otherRef;
            }
            this.add(checkbox);
        }
        if (this.allowOther) {
            this.add({
                xtype: 'textarea',
                bind: {
                    disabled: '{!' + otherRef + '.checked}'
                },
                name: 'txt-other'
            });
        }
        //console.log(this.value)
        //console.log(this.getValue1())
        //  this.setValue({questionM:[1,2,3]});
        Ext.resumeLayouts(true);

    },
    initComponent: function () {
        this.callParent(arguments);
        this.on('afterrender', this.onAfterRender);
    },
    onAfterRender: function () {
        if (this.getStore().totalCount) {
            this.onStoreChange(this.getStore);
        }
    }
});