/**
 * Created by kkora on 9/7/2017.
 */
Ext.define('QuickStart.view.common.YesNoNaRadioGroup', {
    extend: 'Ext.form.RadioGroup',
    config: {
        yes: 1,
        no: 2,
        na:3
    },
    xtype: 'yesnonaradiogroup',
    labelAlign: 'top',
    publishes: 'value',
    disabledCls: 'disable-item',
    layout: 'hbox',
    defaults: {margin: '0 10 0 0'},
    msgTarget: 'under',
    items: [{
        boxLabel: 'Yes',
        inputValue: 1
    }, {
        boxLabel: 'No',
        inputValue: 2
    }, {
        boxLabel: 'NA',
        inputValue: 3
    }],
    initComponent: function () {

        var me = this,
            name = me.name||me.getId()
        ;

        if(me.fieldLabel.lastIndexOf('?')>=0){
            me.labelSeparator='';
        }
        me.callParent();
    }

});