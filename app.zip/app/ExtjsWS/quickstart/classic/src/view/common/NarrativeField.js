/**
 * Created by kkora on 10/25/2017.
 */
Ext.define('QuickStart.view.common.NarrativeField', {
    extend: 'Ext.form.field.TextArea',

    xtype: 'narrativefield',
    flex: 1,
    maxLength: 4100,
    anchor: '100%',
    labelAlign: 'top',
    disabledCls: 'disable-item',
    fieldLabel: 'Provide comments in the narrative field below <strong>(Optional)</strong>'

});