/**
 * Created by kkora on 9/7/2017.
 */

Ext.define('QuickStart.view.common.CrudGrid', {
    extend: 'Ext.grid.Panel',
    // cls: 'user-grid',
    xtype: 'crudgrid',

    requires: [
        'Ext.form.field.Display',
        'Ext.toolbar.Fill'
    ],

    config: {
        //value: null
    },
    viewConfig: {
        stripeRows: true,
        enableTextSelection: false
    },
    dataState: {
        Added: 0,
        Deleted: 1,
        Detached: 2,
        Modified: 3,
        Unchanged: 4
    },
    columnLines: false,
    headerBorders: true,
    enableColumnMove: false,
    enableColumnResize: true,
    reference: 'crudgrid',
    cls: 'dcf-grid',
    dockedItems: [
        {
            bind: {
                hidden: '{disabledItem || !allowedEditCaseData}'
            },
            xtype: 'toolbar',
            //  ui: 'footer',
            items: [  {
                xtype: 'displayfield',
                itemId: 'error',
                msgTarget: 'under',
                value: null
            },
                '->', {
                text: 'Add',
                iconCls: 'x-fa fa-plus',
                handler: function (btn) {
                    var grid = btn.up('grid');
                    grid.fireEvent('addrecord', grid, btn);
                }

            }, {
                text: 'Edit',
                iconCls: 'x-fa fa-pencil',
                bind: {
                    disabled: '{!crudgrid.selection}'
                },
                handler: function (btn) {
                    var grid = btn.up('grid'),
                        record = grid.selection;
                    grid.fireEvent('editrecord', grid, btn, record);
                }
            }, {
                text: 'Delete',
                iconCls: 'x-fa fa-close',
                bind: {
                    disabled: '{!crudgrid.selection}'
                },
                handler: function (btn) {
                    var grid = btn.up('grid'),
                        record = grid.selection;
                    grid.fireEvent('deleterecord', grid, btn, record);
                }
            }]
        }],
    columns: [],
    listeners: {
        scope: this,
        itemdblclick: function (view, record, item, index, e, eOpts) {
            var grid = view.up('grid');
            grid.fireEvent('editrecord', grid, item, record);
        }
    },
    getValue: function () {

        var store = this.getStore(),
            modifiedRecords = store.getModifiedRecords(),
            records = [];
        Ext.each(modifiedRecords, function (rec) {
            var data = rec.getData();
            if (rec.isDirty()) {
                data.DataState = this.dataState.Modified;
            }
            records.push(data);
        }, this);

        return records;
    }
});