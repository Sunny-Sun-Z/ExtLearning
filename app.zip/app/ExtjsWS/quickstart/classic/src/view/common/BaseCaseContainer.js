/**
 * Created by kkora on 10/5/2017.
 */
Ext.define('QuickStart.view.common.BaseCaseContainer', {
    extend: 'Ext.Container',
    xtype: 'basecasecontainer',

    config: {
        record: null
    },
    defaults: {
        xtype: 'panel',
        margin: '0 0 20 0'
        // margin: '0 20 20 0'

    },

    layout: 'auto',
    cls: 'casereview-container'
});