/**
 * Created by kkora on 10/10/2017.
 */

Ext.define('QuickStart.view.common.Rating', {
	extend: 'QuickStart.view.common.InstructionPanel',
	xtype: 'rating',

	requires: [
		'Ext.form.RadioGroup',
		'Ext.form.field.*',
		'Ext.layout.container.*'
	],

	text: '',
	title: '',
	layout: {
		type: 'anchor'
	},
	defaults: {
		disabledCls: 'disable-item',
		margin: '0 10 10 10',
		anchor: '100%'
	},
	config: {
		rating: null,
		overrideRatingPermission: false
	},
	itemRating: {
		NotYetRated: 0,
		Strength: 1,
		AreaNeedingImprovement: 2,
		NA: 3,
		UnableToRate: 4,
		NotApplicable: 5
	},
	outcomeRating: {
		NotYetRated: 0,
		SubstantiallyAchieved: 1,
		PartiallyAchieved: 2,
		NotAchieved: 3,
		NA: 4,
		NotApplicable: 5
	},
	reviewSubType: {
		InHomeServices: 19,
		FosterCare: 20
	},
	questionAns: {
		Yes: 1,
		No: 2,
		NA: 3
	},
	viewModel: {
		data: {
			ratingData: null,
			overrideEnabled: false
		},
		formulas: {
			isOverride: {
				bind: {
					bindTo: '{ratingData.isRatingOverride}'
				},
				get: function (data) {
					return data == 1;
				},
				set: function (data) {
					this.set('ratingData.isRatingOverride', data ? 1 : 2);
				}
			},
			ratingDesc: {
				bind: {
					bindTo: '{ratingData.ItemRatingCode}'
				},
				get: function (data) {
					return this.getRatingDesc(data);
				}
			},
			overriddenRating: {
				bind: {bindTo: '{ratingData}', deep: true},
				get: function (data) {
					if(Ext.isEmpty(data))
						return;
						var ratingData= this.get('ratingData'),
						parentVm=this.getParent(),
						items=parentVm.get('ratingItems')||{},
						code=ratingData.ItemCode-1,
						item=items[code]||{},
							overriddenRatingCode=item['OverriddenRatingCode']
					;

					//console.log('ratingItems.get',items);
					return {OverriddenRatingCode: overriddenRatingCode};
				}
				,
				set: function (data) {
					var ratingData= this.get('ratingData'),
					parentVm=this.getParent(),
					items=parentVm.get('ratingItems')||{},
					code=ratingData.ItemCode-1,
					item=items[code]||{}
						;
					item['OverriddenRatingCode']=data.OverriddenRatingCode;
					items[code]=item;
					parentVm.set('ratingItems',items);
					//console.log('ratingItems.set',items);
					//this.set('ratingData.OverriddenRatingCode', data.OverriddenRatingCode);
					// this.set('ratingData.ItemRatingCode', data.OverriddenRatingCode);
					//this.set('ratingData.RatingDesc', this.getRatingDesc(data.OverriddenRatingCode));
				}
			},
			overriddenOutcomeRating: {
				bind: {
					bindTo: '{ratingData.OverriddenOutcomeRatingCode}'
				},
				get: function (data) {
					return {OverriddenOutcomeRatingCode: data};
				},
				set: function (data) {
					console.log('overriddenOutcomeRating.set', data)
					this.set('ratingData.OverriddenOutcomeRatingCode', data.OverriddenOutcomeRatingCode);
				}
			},
			allowedOverrideRating: {
				bind: {bindTo: '{ratingData}', deep: true},
				get: function (data) {
					return !QuickStart.util.Global.permissions.allowOverrideRating();
				}
			},
			isItemDisabled:{
				bind: {bindTo: '{caseReview}', deep: true},
				get: function (data) {
					if(data==null)
						return;

					var itemRating=this.getParent().get('itemRating') ||{},
						ratingData=this.get('ratingData');
					if(ratingData==null)
						return;

					return itemRating[ratingData.ItemCode];
				}
			}
		},
		getRatingDesc: function (code) {
			return code == 1 ? 'Strength' :
				code == 2 ? 'Area Needing Improvement' :
					code == 3 ? 'NA' :
						code == 4 ? 'Unable to Rate' :
							code == 5 ? 'Not Applicable' : 'Not Yet Rated';
		},
		getOutcomeRatingDesc: function (code) {
			return code == 1 ? 'Substantially Achieved' :
				code == 2 ? 'Partially Achieved' :
					code == 3 ? 'Not Achieved' :
						code == 4 ? 'NA' :
							code == 5 ? 'Not Applicable' : 'Not Yet Rated';
		}
	},
	items: [
		{
			xtype: 'displayfield',
			fieldLabel: 'Item Rating',
			// bind: '{ratingData.RatingDesc}',
			bind: '{ratingDesc}',
			padding: 0
		},
		{
			xtype: 'textarea',
			flex: 1,
			maxLength: 10000,
			bind: '{ratingData.RatingComments}',
			disabledCls: 'disable-item',
			labelAlign: 'top',
			fieldLabel: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below'
		},
		{
			xtype: 'checkbox',
			reference: 'isRatingOverride',
			inputValue: 1,
			uncheckedValue: 2,
		//	disabledCls: 'disable-item',
			bind: {
				hidden: '{allowedOverrideRating}',
				disabled: '{isItemDisabled}',
				value: '{isOverride}'
			},
			boxLabel: '<b>Override this rating?</b>'
		},
		// {
		// 	xtype: 'radiogroup',
		// 	labelWidth: 190,
		// 	fieldLabel: 'Overridden rating',
		// 	defaults: {margin: '0 10 0 0', name: 'OverriddenRatingCode', disabledCls: 'disable-item'},
		// 	layout: 'hbox',
		// 	bind: {
		// 		hidden: '{!isRatingOverride.checked}',
		// 		disabled: '{isItemDisabled}',
		// 		allowBlank: '{!isRatingOverride.checked}',
		// 		value: '{overriddenRating}'
		// 	},
		// 	items: [
		// 		{boxLabel: 'Strength', inputValue: 1},
		// 		{boxLabel: 'Area Needing Improvement', inputValue: 2},
		// 		{boxLabel: 'NA', inputValue: 3},
		// 		{boxLabel: 'Unable to Rate', inputValue: 4}
		// 	],
		// 	emptyText: 'Please select an Overridden item rating.',
		// 	msgTarget: 'side',
		// 	setAllowBlank: function (value) {
		// 		this.allowBlank = value;
		// 		this.isValid();
		// 	}
		// },
		{
			xtype: 'combobox',
			labelWidth: 150,
			fieldLabel: 'Overridden rating',
			disabledCls: 'disable-item',
			bind: {
				hidden: '{!isRatingOverride.checked}',
				disabled: '{isItemDisabled}',
				allowBlank: '{!isRatingOverride.checked}',
				value: '{ratingData.OverriddenRatingCode}'
			},
			store: [
				{name: 'Strength', id: 1},
				{name: 'Area Needing Improvement', id: 2},
				{name: 'NA', id: 3},
				{name: 'Unable to Rate', id: 4}
			],
			emptyText: 'Please select an Overridden item rating.',
			msgTarget: 'side',
			valueField:'id',
			displayField:'name',
			editable:false,
			setAllowBlank: function (value) {
				this.allowBlank = value;
				this.isValid();
			}
		},
		{
			bind: {
				hidden: '{!isRatingOverride.checked}',
				disabled: '{isItemDisabled}',
				allowBlank: '{!isRatingOverride.checked}',
				value: '{ratingData.OverrideReason}'
			},
			msgTarget: 'side',
			setAllowBlank: function (value) {
				this.allowBlank = value;
				this.isValid();
			},
			//disabledCls: 'disable-item',
			xtype: 'textarea',
			flex: 1,
			maxLength: 10000,
			labelAlign: 'top',
			margin: '0 10 10 10',
			fieldLabel: 'Override reason'
		}
	],
	updateOverrideRatingPermission: function (value) {
		// this.getViewModel().set('overrideEnabled', value);
	},
	updateRating: function (value) {
		var vm=this.getViewModel(),
			parentVm=vm.getParent(),
			items=parentVm.get('ratingItems')||{};
		vm.set('ratingData', value || {});
		if(!Ext.isEmpty(value)){
			var code=value.ItemCode-1;
			var item=	items[code]||{};
			item['OverriddenRatingCode']=value.OverriddenRatingCode;

			items[code]=item;
			parentVm.set('ratingItems',items);
			//console.log(items);
		}
	},
	calculateRatingCode: function (answers, data) {
		var allAnswersYes = true,
			atLeast1AnswerNo = false,
			allQuestionsAnswered = true,
			code = null,
			me = this;

		if (data.IsApplicable == 2) {
			code = me.itemRating.NA;
		} else if (!me.isItemStarted(answers)) {
			code = me.itemRating.NotYetRated;
		} else {
			Ext.each(answers, function (answer) {

				if (answer == me.questionAns.No) {
					atLeast1AnswerNo = true;
					allAnswersYes = false;
				}

				if (answer == me.questionAns.NA || Ext.isEmpty(answer)) {
					allAnswersYes = false;
					if (Ext.isEmpty(answer)) {
						allQuestionsAnswered = false;
					}
				}
			});

			if ((allAnswersYes) || (allQuestionsAnswered && !(atLeast1AnswerNo))) {
				code = me.itemRating.Strength;
			} else if (atLeast1AnswerNo) {
				code = me.itemRating.AreaNeedingImprovement;
			} else {
				code = me.itemRating.UnableToRate;
			}
		}
		return code;
	},
	isItemStarted: function (answers) {
		var responses = [];

		Ext.each(answers, function (answer) {
			if (!Ext.isEmpty(answer)) {
				responses.push(answer);
			}
		});

		return responses.length == 0 ? false : true;
	},
	calculateItem12Rating: function (data) {
		var me = this,
			vm = me.getViewModel(),
			outcome5 = data.CR_Outcome_Collection.filter(function (outcome) {
				return outcome.OutcomeCode == 5;
			}),
			item12 = outcome5.length > 0 ? outcome5[0].CR_Item_Collection.filter(function (item) {
				return item.ItemCode == 13;
			}) : null,
			rating12A = vm.get('caseReview.Item12a').ItemRatingCode,
			rating12B = vm.get('caseReview.Item12b').ItemRatingCode,
			rating12C = vm.get('caseReview.Item12c').ItemRatingCode;

		if ((rating12A == me.itemRating.Strength && rating12B == me.itemRating.Strength && rating12C == me.itemRating.Strength) ||
			((rating12A == me.itemRating.Strength || rating12B == me.itemRating.Strength || rating12C == me.itemRating.Strength) &&
				(!(rating12A == me.itemRating.AreaNeedingImprovement || rating12B == me.itemRating.AreaNeedingImprovement ||
					rating12C == me.itemRating.AreaNeedingImprovement) && (!Ext.isEmpty(rating12A) && !Ext.isEmpty(rating12B) && !Ext.isEmpty(rating12C))))) {
			code = me.itemRating.Strength;
		} else if (rating12A == me.itemRating.AreaNeedingImprovement || rating12B == me.itemRating.AreaNeedingImprovement ||
			(rating12C == me.itemRating.AreaNeedingImprovement || rating12C == me.itemRating.NA)) {
			code = me.itemRating.AreaNeedingImprovement;
		} else {
			code = me.itemRating.UnableToRate;
		}

		if (item12.length > 0) {
			item12[0].ItemRatingCode = code;
			item12[0].RatingDesc = me.viewModel.getRatingDesc(code);
		}

		return data;
	},
	calculateOutcomeRating: function (data, code) {
		//
		// code === itemCode
		//
		var me = this,
			outcomeRating = null,
			overriddenRating = null,
			result = {outcomeCode: null, outcomeRatingCode: null, overriddenOutcomeRatingCode: null};

		if (code == 2) {
			//
			// Safety Outcome 1 rating
			//
			var rating1 = data.Item1.ItemRatingCode;
			if (rating1 == me.itemRating.Strength) {
				outcomeRating = me.outcomeRating.SubstantiallyAchieved;
			} else if (rating1 == me.itemRating.AreaNeedingImprovement) {
				outcomeRating = me.outcomeRating.NotAchieved;
			} else if (rating1 == me.itemRating.NA) {
				outcomeRating = me.outcomeRating.NA;
			}

			rating1 = data.Item1.OverriddenRatingCode;
			if (rating1 == me.itemRating.Strength) {
				overriddenRating = me.outcomeRating.SubstantiallyAchieved;
			} else if (rating1 == me.itemRating.AreaNeedingImprovement) {
				overriddenRating = me.outcomeRating.NotAchieved;
			} else if (rating1 == me.itemRating.NA) {
				overriddenRating = me.outcomeRating.NA;
			}

			result.outcomeCode = 1;
		}
		else if (code == 3 || code == 4) {
			//
			// Safety Outcome 2 rating
			//
			var rating2 = data.Item2.ItemRatingCode,
				rating3 = data.Item3.ItemRatingCode;

			if ((rating2 == me.itemRating.Strength && rating3 == me.itemRating.Strength) ||
				(rating2 == me.itemRating.NA && rating3 == me.itemRating.Strength)) {
				outcomeRating = me.outcomeRating.SubstantiallyAchieved;
			} else if ((rating2 == me.itemRating.Strength || rating3 == me.itemRating.Strength) &&
				(rating2 == me.itemRating.AreaNeedingImprovement || rating3 == me.itemRating.AreaNeedingImprovement)) {
				outcomeRating = me.outcomeRating.PartiallyAchieved;
			} else if ((rating2 == me.itemRating.AreaNeedingImprovement && rating3 == me.itemRating.AreaNeedingImprovement) ||
				(rating2 == me.itemRating.NA && rating3 == me.itemRating.AreaNeedingImprovement)) {
				outcomeRating = me.outcomeRating.NotAchieved;
			}

			rating2 = data.Item2.OverriddenRatingCode;
			rating3 = data.Item3.OverriddenRatingCode;

			if ((rating2 == me.itemRating.Strength && rating3 == me.itemRating.Strength) ||
				(rating2 == me.itemRating.NA && rating3 == me.itemRating.Strength)) {
				overriddenRating = me.outcomeRating.SubstantiallyAchieved;
			} else if ((rating2 == me.itemRating.Strength || rating3 == me.itemRating.Strength) &&
				(rating2 == me.itemRating.AreaNeedingImprovement || rating3 == me.itemRating.AreaNeedingImprovement)) {
				overriddenRating = me.outcomeRating.PartiallyAchieved;
			} else if ((rating2 == me.itemRating.AreaNeedingImprovement && rating3 == me.itemRating.AreaNeedingImprovement) ||
				(rating2 == me.itemRating.NA && rating3 == me.itemRating.AreaNeedingImprovement)) {
				overriddenRating = me.outcomeRating.NotAchieved;
			}
			result.outcomeCode = 2;
		}
		else if (code == 5 || code == 6 || code == 7) {
			//
			// Permanency Outcome 1 rating
			//
			var item4 = data.Item4,
				item5 = data.Item5,
				item6 = data.Item6,
				rating4 = item4.ItemRatingCode,
				rating5 = item5.ItemRatingCode,
				rating6 = item6.ItemRatingCode;

			if ((rating4 == me.itemRating.Strength && rating5 == me.itemRating.Strength && rating6 == me.itemRating.Strength) ||
				(rating4 == me.itemRating.Strength && rating6 == me.itemRating.Strength && rating5 == me.itemRating.NA)) {
				outcomeRating = me.outcomeRating.SubstantiallyAchieved;
			} else if (rating4 == me.itemRating.Strength || rating5 == me.itemRating.Strength || rating6 == me.itemRating.Strength) {
				outcomeRating = me.outcomeRating.PartiallyAchieved;
			} else if ((rating4 == me.itemRating.AreaNeedingImprovement && rating5 == me.itemRating.AreaNeedingImprovement &&
				rating6 == me.itemRating.AreaNeedingImprovement) ||
				(rating4 == me.itemRating.AreaNeedingImprovement && rating6 == me.itemRating.AreaNeedingImprovement &&
					rating5 == me.itemRating.NA)) {
				outcomeRating = me.outcomeRating.NotAchieved;
			}


			rating4 = item4.OverriddenRatingCode;
			rating5 = item5.OverriddenRatingCode;
			rating6 = item6.OverriddenRatingCode;

			if ((rating4 == me.itemRating.Strength && rating5 == me.itemRating.Strength && rating6 == me.itemRating.Strength) ||
				(rating4 == me.itemRating.Strength && rating6 == me.itemRating.Strength && rating5 == me.itemRating.NA)) {
				overriddenRating = me.outcomeRating.SubstantiallyAchieved;
			} else if (rating4 == me.itemRating.Strength || rating5 == me.itemRating.Strength || rating6 == me.itemRating.Strength) {
				overriddenRating = me.outcomeRating.PartiallyAchieved;
			} else if ((rating4 == me.itemRating.AreaNeedingImprovement && rating5 == me.itemRating.AreaNeedingImprovement &&
				rating6 == me.itemRating.AreaNeedingImprovement) ||
				(rating4 == me.itemRating.AreaNeedingImprovement && rating6 == me.itemRating.AreaNeedingImprovement &&
					rating5 == me.itemRating.NA)) {
				overriddenRating = me.outcomeRating.NotAchieved;
			}

			result.outcomeCode = 3;
		}
		else if (code == 8 || code == 9 || code == 10 || code == 11 || code == 12) {
			//
			// Permanency Outcome 2 rating
			//
			var item7 = data.Item7,
				item8 = data.Item8,
				item9 = data.Item9,
				item10 = data.Item10,
				item11 = data.Item11,
				ratings = [],
				aniRatings = [],
				strengthRatings = [],
				naRatings = [];

			ratings.push(item7.ItemRatingCode);
			ratings.push(item8.ItemRatingCode);
			ratings.push(item9.ItemRatingCode);
			ratings.push(item10.ItemRatingCode);
			ratings.push(item11.ItemRatingCode);

			aniRatings = ratings.filter(function (rating) {
				return rating == me.itemRating.AreaNeedingImprovement;
			});
			strengthRatings = ratings.filter(function (rating) {
				return rating == me.itemRating.Strength;
			});
			naRatings = ratings.filter(function (rating) {
				return rating == me.itemRating.NA;
			});

			if (strengthRatings.length > 0 && aniRatings.length < 2) {
				outcomeRating = me.outcomeRating.SubstantiallyAchieved;
			} else if (strengthRatings.length > 0 && aniRatings.length > 1 && aniRatings.length < 5) {
				outcomeRating = me.outcomeRating.PartiallyAchieved;
			} else if (strengthRatings.length == 0 && aniRatings.length > 0) {
				outcomeRating = me.outcomeRating.NotAchieved;
			} else if (aniRatings.length == 5) {
				outcomeRating = me.outcomeRating.NA;
			}


			ratings = [];
			aniRatings = [];
			strengthRatings = [];
			naRatings = [];

			ratings.push(item7.OverriddenRatingCode);
			ratings.push(item8.OverriddenRatingCode);
			ratings.push(item9.OverriddenRatingCode);
			ratings.push(item10.OverriddenRatingCode);
			ratings.push(item11.OverriddenRatingCode);

			aniRatings = ratings.filter(function (rating) {
				return rating == me.itemRating.AreaNeedingImprovement;
			});
			strengthRatings = ratings.filter(function (rating) {
				return rating == me.itemRating.Strength;
			});
			naRatings = ratings.filter(function (rating) {
				return rating == me.itemRating.NA;
			});

			if (strengthRatings.length > 0 && aniRatings.length < 2) {
				overriddenRating = me.outcomeRating.SubstantiallyAchieved;
			} else if (strengthRatings.length > 0 && aniRatings.length > 1 && aniRatings.length < 5) {
				overriddenRating = me.outcomeRating.PartiallyAchieved;
			} else if (strengthRatings.length == 0 && aniRatings.length > 0) {
				overriddenRating = me.outcomeRating.NotAchieved;
			} else if (aniRatings.length == 5) {
				overriddenRating = me.outcomeRating.NA;
			}

			result.outcomeCode = 4;
		}
		else if (code > 12 && code < 20) {
			//
			// Wellbeing Outcome 1 rating
			//
			var item12 = data.Item12,
				item13 = data.Item13,
				item14 = data.Item14,
				item15 = data.Item15,
				rating12 = item12.ItemRatingCode,
				otherStrengths = [],
				otherNotRated = [],
				otherANI = [],
				otherNA = [],
				otherRatings = [item13.ItemRatingCode, item14.ItemRatingCode, item15.ItemRatingCode];

			otherStrengths = otherRatings.filter(function (rating) {
				return rating == me.itemRating.Strength;
			});
			otherANI = otherRatings.filter(function (rating) {
				return rating == me.itemRating.AreaNeedingImprovement;
			});
			otherNA = otherRatings.filter(function (rating) {
				return rating == me.itemRating.NA;
			});
			otherNotRated = otherRatings.filter(function (rating) {
				return rating == me.itemRating.UnableToRate || rating == me.itemRating.NotYetRated || Ext.isEmpty(rating);
			});

			if (rating12 == me.itemRating.Strength && otherANI.length <= 1 && (otherStrengths.length > 0 && otherStrengths.length <= 3) && otherNA.length <= 2) {
				outcomeRating = me.outcomeRating.SubstantiallyAchieved;
			} else if ((rating12 == me.itemRating.AreaNeedingImprovement && otherStrengths.length > 0) ||(rating12 == me.itemRating.Strength && otherANI.length >= 2)) {
				outcomeRating = me.outcomeRating.PartiallyAchieved;
			} else if (rating12 == me.itemRating.AreaNeedingImprovement && otherANI.length == 2) {
				outcomeRating = me.outcomeRating.NotAchieved;
			}

			rating12 = item12.OverriddenRatingCode;
			otherStrengths = [];
			otherNotRated = [];
			otherANI = [];
			otherNA = [];
			otherRatings = [item13.OverriddenRatingCode, item14.OverriddenRatingCode, item15.OverriddenRatingCode];

			otherStrengths = otherRatings.filter(function (rating) {
				return rating == me.itemRating.Strength;
			});
			otherANI = otherRatings.filter(function (rating) {
				return rating == me.itemRating.AreaNeedingImprovement;
			});
			otherNA = otherRatings.filter(function (rating) {
				return rating == me.itemRating.NA;
			});
			otherNotRated = otherRatings.filter(function (rating) {
				return rating == me.itemRating.UnableToRate || rating == me.itemRating.NotYetRated || Ext.isEmpty(rating);
			});

			if (rating12 == me.itemRating.Strength && otherANI.length <= 1 &&
				(otherStrengths.length > 0 && otherStrengths.length <= 3) && otherNA.length <= 2) {
				overriddenRating = me.outcomeRating.SubstantiallyAchieved;
			} else if ((rating12 == me.itemRating.AreaNeedingImprovement && otherStrengths.length > 0) ||
				(rating12 == me.itemRating.Strength && otherANI.length >= 2)) {
				overriddenRating = me.outcomeRating.PartiallyAchieved;
			} else if (rating12 == me.itemRating.AreaNeedingImprovement && otherANI.length == 2) {
				overriddenRating = me.outcomeRating.NotAchieved;
			}

			result.outcomeCode = 5;
			
		}
		else if (code == 20) {
			//
			// Wellbeing Outcome 2 rating
			//
			var item16 = data.Item16,
				quest16a = data.WellBeing.IsAgencyAssessEducationNeeds,
				quest16b = data.WellBeing.IsAgencyAddressEducationNeeds,
				rating16 = item16.ItemRatingCode;

			if (rating16 == me.itemRating.Strength) {
				outcomeRating = me.outcomeRating.SubstantiallyAchieved;
			} else if (rating16 == me.itemRating.AreaNeedingImprovement &&
				(quest16a == me.questionAns.Yes || quest16b == me.questionAns.Yes)) {
				outcomeRating = me.outcomeRating.PartiallyAchieved;
			} else if (rating16 == me.itemRating.AreaNeedingImprovement &&
				(quest16a == me.questionAns.No && quest16b == me.questionAns.No)) {
				outcomeRating = me.outcomeRating.NotAchieved;
			} else if (rating16 == me.itemRating.NA) {
				outcomeRating = me.outcomeRating.NA;
			}

			rating16 = item16.OverriddenRatingCode;

			if (rating16 == me.itemRating.Strength) {
				overriddenRating = me.outcomeRating.SubstantiallyAchieved;
			} else if (rating16 == me.itemRating.AreaNeedingImprovement &&
				(quest16a == me.questionAns.Yes || quest16b == me.questionAns.Yes)) {
				overriddenRating = me.outcomeRating.PartiallyAchieved;
			} else if (rating16 == me.itemRating.AreaNeedingImprovement &&
				(quest16a == me.questionAns.No && quest16b == me.questionAns.No)) {
				overriddenRating = me.outcomeRating.NotAchieved;
			} else if (rating16 == me.itemRating.NA) {
				overriddenRating = me.outcomeRating.NA;
			}


			result.outcomeCode = 6;
		}
		else if (code == 21 || code == 22) {
			//
			// Wellbeing Outcome 3 rating
			//
			var rating17 = data.Item17.ItemRatingCode,
				rating18 = data.Item18.ItemRatingCode;

			if ((rating17 == me.itemRating.Strength && rating18 == me.itemRating.Strength) ||
				((rating17 == me.itemRating.Strength || rating18 == me.itemRating.Strength) &&
					(rating17 == me.itemRating.NA || rating18 == me.itemRating.NA))) {
				outcomeRating = me.outcomeRating.SubstantiallyAchieved;
			} else if ((rating17 == me.itemRating.Strength || rating18 == me.itemRating.Strength) &&
				(rating17 == me.itemRating.AreaNeedingImprovement || rating18 == me.itemRating.AreaNeedingImprovement)) {
				outcomeRating = me.outcomeRating.PartiallyAchieved;
			} else if ((rating17 == me.itemRating.AreaNeedingImprovement && rating18 == me.itemRating.AreaNeedingImprovement) ||
				((rating17 == me.itemRating.AreaNeedingImprovement || rating18 == me.itemRating.AreaNeedingImprovement) &&
					(rating17 == me.itemRating.NA || rating18 == me.itemRating.NA))) {
				outcomeRating = me.outcomeRating.NotAchieved;
			} else if (rating17 == me.itemRating.NA || rating18 == me.itemRating.NA) {
				outcomeRating = me.outcomeRating.NA;
			}

			rating17 = data.Item17.OverriddenRatingCode;
			rating18 = data.Item18.OverriddenRatingCode;

			if ((rating17 == me.itemRating.Strength && rating18 == me.itemRating.Strength) ||
				((rating17 == me.itemRating.Strength || rating18 == me.itemRating.Strength) &&
					(rating17 == me.itemRating.NA || rating18 == me.itemRating.NA))) {
				overriddenRating = me.outcomeRating.SubstantiallyAchieved;
			} else if ((rating17 == me.itemRating.Strength || rating18 == me.itemRating.Strength) &&
				(rating17 == me.itemRating.AreaNeedingImprovement || rating18 == me.itemRating.AreaNeedingImprovement)) {
				overriddenRating = me.outcomeRating.PartiallyAchieved;
			} else if ((rating17 == me.itemRating.AreaNeedingImprovement && rating18 == me.itemRating.AreaNeedingImprovement) ||
				((rating17 == me.itemRating.AreaNeedingImprovement || rating18 == me.itemRating.AreaNeedingImprovement) &&
					(rating17 == me.itemRating.NA || rating18 == me.itemRating.NA))) {
				overriddenRating = me.outcomeRating.NotAchieved;
			} else if (rating17 == me.itemRating.NA || rating18 == me.itemRating.NA) {
				overriddenRating = me.outcomeRating.NA;
			}
			result.outcomeCode = 7;
		}

		result.outcomeRatingCode = outcomeRating;
		result.overriddenOutcomeRatingCode = overriddenRating;

		if ((data.ReviewSubTypeID == 19 || data.ReviewSubTypeID == 21) && code > 4 && code < 13) {
			result.outcomeRatingCode = me.outcomeRating.NotApplicable;
			result.overriddenOutcomeRatingCode = me.outcomeRating.NotApplicable;
		}

		return result;
	},
	calculate: function (data) {
		// Item rating calculations

		var me = this,
			vm = me.getViewModel(),
			ratingData = vm.get('ratingData'),
			code = null,
			answers = [],
			parms = {data: data, itemCode: ratingData.ItemCode},
			questA, questA1, questA2, questA3, questB, questB1, questB2, questB3, quesAB, questC, questC1, questC2,
			questD, questE, questF, questG, result
		;
		if (ratingData && ratingData.OverriddenRatingCode > 0 && ratingData.isRatingOverride == 1) {
			//return;
		}
		else {
			switch (ratingData.ItemCode) {
				// Facesheet
				case 23:

					break;
				// Item 1
				case 2:
					quesAB = data.Safety.FaceToFaceReportsNotInAccordance + data.Safety.ReportsNotInAccordance;
					questC = data.Safety.IsDelayBeyondAgencyControl;

					if (ratingData.IsApplicable == me.questionAns.No) {
						code = me.itemRating.NA;
					} else if (!(data.Safety.CR_SafetyReport_Collection)) {
						code = me.itemRating.NotYetRated;
					} else if (data.Safety.CR_SafetyReport_Collection && data.Safety.CR_SafetyReport_Collection.length > 0) {
						if (quesAB == 0 || (quesAB > 0 && (questC == me.questionAns.Yes || questC == me.questionAns.NA))) {
							code = me.itemRating.Strength;
						} else if (quesAB > 0 && (questC == me.questionAns.No)) {
							code = me.itemRating.AreaNeedingImprovement;
						} else {
							code = me.itemRating.UnableToRate;
						}
					} else {
						code = me.itemRating.UnableToRate;
					}
					break;
				// Item 2
				case 3:
					questA = data.Safety.IsEffortToPreventReEntry;
					questB = data.Safety.IsChildRemovedToEnsureSafety;

					if (ratingData.IsApplicable == me.questionAns.No) {
						code = me.itemRating.NA;
					} else if ((questA == me.questionAns.Yes && questB == me.questionAns.Yes) || (questA == me.questionAns.Yes && questB == me.questionAns.NA) || (questA == me.questionAns.No && questB == me.questionAns.Yes)) {
						code = me.itemRating.Strength;
					} else if ((questA == me.questionAns.No && questB == me.questionAns.No) || (questA == me.questionAns.No && questB == me.questionAns.NA)) {
						code = me.itemRating.AreaNeedingImprovement;
					} else {
						code = me.itemRating.UnableToRate;
					}
					break;
				// Item 3
				case 4:
					questA = data.Safety.IsInitialAssesmentForAllChildrenInHome;
					questB = data.Safety.IsOngoingAssesementForAllChildrenInHome;
					questC = data.Safety.IsSafetyPlanDevelopedAndMonitored;
					questD = data.Safety.IsSafetyConcernForOtherChildren;
					questE = data.Safety.IsFosterSafetyConcernDuringVisitation;
					questF = data.Safety.IsFosterSafetyConcernNotAddressed;

					if (ratingData.IsApplicable == me.questionAns.No) {
						code = me.itemRating.NA;
					} else if (questA == me.questionAns.No || questB == me.questionAns.No || questC == me.questionAns.No || questD == me.questionAns.Yes || questE == me.questionAns.Yes || questF == me.questionAns.Yes) {
						code = me.itemRating.AreaNeedingImprovement;
					} else if ((questA == me.questionAns.Yes && questB == me.questionAns.Yes) ||
						(((questA == me.questionAns.Yes && questB == me.questionAns.NA) || (questA == me.questionAns.NA && questB == me.questionAns.Yes)) &&
							(questC == me.questionAns.Yes || questC == me.questionAns.NA) &&
							(questD == me.questionAns.No || questD == me.questionAns.NA) &&
							(questE == me.questionAns.No || questE == me.questionAns.NA) &&
							(questF == me.questionAns.No || questF == me.questionAns.NA))) {
						code = me.itemRating.Strength;
					} else {
						code = me.itemRating.UnableToRate;
					}
					break;
				// Item 4
				case 5:
					questA = data.Permanency.NumberOfPlacementSettings;
					questB = data.Permanency.WereAllPlacementChangesPlanned;
					questC = data.Permanency.IsCurrentPlacementSettingStable;
					questC1 = data.Permanency.PlacementApplicableCircumstances;
					//console.log('PlacementApplicableCircumstances',questC1)
					if ((questA == 0 && questC == me.questionAns.No) || (questA >= 1 && (questB == me.questionAns.No || questC == me.questionAns.No))&& questC1.length>0) {

						code = me.itemRating.AreaNeedingImprovement;
					}
					else if (((questA == 0 ||questA == 1 ) && questB == me.questionAns.NA && questC == me.questionAns.Yes) ||
						(questA >= 1 && questB == me.questionAns.Yes && questC == me.questionAns.Yes) && questC1.length>0) {

						code = me.itemRating.Strength;
					}
					else  {
						code = me.itemRating.UnableToRate;
					}
					break;
				// Item 5
				case 6:
					questA3 = data.Permanency.IsGoalSpecified;
					questB = data.Permanency.WereAllGoalsInTimelyManner;
					questC = data.Permanency.WereAllGoalsAppropriate;
					questD = data.Permanency.IsInFoster15OutOf22;
					questE = data.Permanency.MeetsTerminationOfParentalRights;
					questF = data.Permanency.IsAgencyJointTerminationOfParentalRights;
					questG = data.Permanency.IsExceptionForTermination;

					if (ratingData.IsApplicable == me.questionAns.No) {
						code = me.itemRating.NA;
					}
					else if ((!(questA3 == me.questionAns.No || questB == me.questionAns.No || questC == me.questionAns.No) &&
						(questD == me.questionAns.No && questE == me.questionAns.No)) ||
						(!(questA3 == me.questionAns.No || questB == me.questionAns.No || questC == me.questionAns.No) &&
							(questD == me.questionAns.Yes && questF == me.questionAns.Yes)) ||
						(!(questA3 == me.questionAns.No || questB == me.questionAns.No || questC == me.questionAns.No) &&
							(questD == me.questionAns.No && (questE == me.questionAns.Yes && questF == me.questionAns.Yes))) ||
						(!(questA3 == me.questionAns.No || questB == me.questionAns.No || questC == me.questionAns.No) &&
							(questD == me.questionAns.Yes || questE == me.questionAns.Yes) && (questF == me.questionAns.No && questG == me.questionAns.Yes))) {

						code = me.itemRating.Strength;
					} else if ((questA3 == me.questionAns.No || questB == me.questionAns.No || questC == me.questionAns.No) ||
						(!(questA3 == me.questionAns.No || questB == me.questionAns.No || questC == me.questionAns.No) &&
							(questD == me.questionAns.Yes || questE == me.questionAns.Yes) &&
							(questF == me.questionAns.No && questG == me.questionAns.No))) {
						code = me.itemRating.AreaNeedingImprovement;
					}
					else {
						code = me.itemRating.UnableToRate;
					}
					break;
				// Item 6
				case 7:
					questB = data.Permanency.IsAgencyConcertedEfforts;
					questC = data.Permanency.IsOtherPlannedConcertedEffort;

					if (questB == me.questionAns.Yes || questC == me.questionAns.Yes) {

						code = me.itemRating.Strength;
					} else if (!(questB == me.questionAns.Yes && questC == me.questionAns.Yes)) {
						code = me.itemRating.AreaNeedingImprovement;
					} else {
						code = me.itemRating.UnableToRate;
					}
					break;
				// Item 7
				case 8:
					questA = data.Permanency.IsPlacedWithAllSiblings;
					questB = data.Permanency.IsValidReasonForSeparation;

					if (ratingData.IsApplicable == me.questionAns.No) {
						code = me.itemRating.NA;
					} else if (Ext.isEmpty(questA) && Ext.isEmpty(questB)) {
						code = me.itemRating.NotYetRated;
					} else if (questA == me.questionAns.Yes || (questA == me.questionAns.No && questB == me.questionAns.Yes)) {
						code = me.itemRating.Strength;
					} else if (questA == me.questionAns.No && questB == me.questionAns.No) {
						code = me.itemRating.AreaNeedingImprovement;
					} else {
						code = me.itemRating.UnableToRate;
					}
					break;
				// Item 8
				case 9:
					answers.push(data.Permanency.IsSufficientFrequencyForMotherVisitation);
					answers.push(data.Permanency.IsSufficientFrequencyForFatherVisitation);
					answers.push(data.Permanency.IsSufficientQualityForMotherVisitation);
					answers.push(data.Permanency.IsSufficentQualityForFatherVisitation);
					answers.push(data.Permanency.IsSufficientFrequencyForSiblingVisitation);
					answers.push(data.Permanency.IsSufficentQualityForSiblingVisitation);

					code = me.calculateRatingCode(answers, ratingData);
					break;
				// Item 9
				case 10:
					questA = data.Permanency.IsConcertedEffortsForImportantConnections;
					questB = data.Permanency.IsSufficientInquiryForIndianTribe;
					questC = data.Permanency.IsTribeProvidedTimelyNotification;
					questD = data.Permanency.IsAccordanceWithIndianChildWelfareAct;

					if (ratingData.IsApplicable == me.questionAns.No) {
						code = me.itemRating.NA;
					} else if (Ext.isEmpty(questA) && Ext.isEmpty(questB) &&
						Ext.isEmpty(questC) && Ext.isEmpty(questD)) {
						code = me.itemRating.NotYetRated;
					} else if (questA == me.questionAns.Yes && !(questC == me.questionAns.No || questD == me.questionAns.No)) {
						code = me.itemRating.Strength;
					} else if ((questA == me.questionAns.Yes && (questC == me.questionAns.No || questD == me.questionAns.No)) || questA == me.questionAns.No) {
						code = me.itemRating.AreaNeedingImprovement;
					} else {
						code = me.itemRating.UnableToRate;
					}
					break;
				// Item 10
				case 11:
					questA1 = data.Permanency.IsRecentPlacementWithRelative;
					questA2 = data.Permanency.IsPlacementWithRelativeStable;
					questB = data.Permanency.IsConcertedEffortToLocateMaternalRelatives;
					questC = data.Permanency.IsConcertedEffortToLocatePaternalRelatives;

					if (ratingData.IsApplicable == me.questionAns.No) {
						code = me.itemRating.NA;
					} else if (Ext.isEmpty(questA1) && Ext.isEmpty(questA2) &&
						Ext.isEmpty(questB) && Ext.isEmpty(questC)) {
						code = me.itemRating.NotYetRated;
					} else if ((questA1 == me.questionAns.Yes && questA2 == me.questionAns.Yes) ||
						((questA1 == me.questionAns.No || questA2 == me.questionAns.No) &&
							!(questB == me.questionAns.No || questC == me.questionAns.No))) {
						code = me.itemRating.Strength;
					} else if ((questA1 == me.questionAns.No || questA2 == me.questionAns.No) ||
						(questB == me.questionAns.No || questC == me.questionAns.No)) {
						code = me.itemRating.AreaNeedingImprovement;
					} else {
						code = me.itemRating.UnableToRate;
					}
					break;
				// Item 11
				case 12:
					answers.push(data.Permanency.IsConcertedEffortMotherFosterRelationship);
					answers.push(data.Permanency.IsConcertedEffortFatherFosterRelationship);

					code = me.calculateRatingCode(answers, ratingData);
					break;
				// Item 12
				case 13:
					var rating12A = vm.get('caseReview.Item12a').ItemRatingCode,
						rating12B = vm.get('caseReview.Item12b').ItemRatingCode,
						rating12C = vm.get('caseReview.Item12c').ItemRatingCode;

					if (rating12A == me.itemRating.AreaNeedingImprovement || rating12B == me.itemRating.AreaNeedingImprovement ||
						(rating12C == me.itemRating.AreaNeedingImprovement || rating12C == me.itemRating.NA)) {
						code = me.itemRating.AreaNeedingImprovement;
					} else if ((rating12A == me.itemRating.Strength && rating12B == me.itemRating.Strength && rating12C == me.itemRating.Strength) ||
						((rating12A == me.itemRating.Strength || rating12B == me.itemRating.Strength || rating12C == me.itemRating.Strength) &&
							(!(rating12A == me.itemRating.AreaNeedingImprovement || rating12B == me.itemRating.AreaNeedingImprovement ||
								rating12C == me.itemRating.AreaNeedingImprovement)))) {
						code = me.itemRating.Strength;
					} else {
						code = me.itemRating.UnableToRate;
					}
					break;
				// Item 12A
				case 14:
					questA1 = data.WellBeing.IsComprehensiveAssessementConducted;
					questA2 = data.WellBeing.IsAppropriateServicesProvided;

					if (ratingData.IsApplicable == me.questionAns.No) {
						code = me.itemRating.NA;
					} else if (Ext.isEmpty(questA1) && Ext.isEmpty(questA2)) {
						code = me.itemRating.NotYetRated;
					} else if ((questA1 == me.questionAns.Yes && questA2 == me.questionAns.Yes) || (questA1 == me.questionAns.Yes && questA2 == me.questionAns.NA)) {
						code = me.itemRating.Strength;
					} else if (questA1 == me.questionAns.No || questA2 == me.questionAns.No) {
						code = me.itemRating.AreaNeedingImprovement;
					} else {
						code = me.itemRating.UnableToRate;
					}
					break;
				// Item 12B
				case 15:
					answers.push(data.WellBeing.IsComprehensiveAssessementForMotherConducted);
					answers.push(data.WellBeing.IsComprehensiveAssessementForFatherConducted);
					answers.push(data.WellBeing.IsAppropriateServicesForMotherProvided);
					answers.push(data.WellBeing.IsAppropriateServicesForFatherProvided);

					if (data.WellBeing.IsNeedsServicesApplicableForMother == 2 && data.WellBeing.IsNeedsServicesApplicableForFather == 2) {
						code = me.itemRating.NA;
					} else {
						ratingData.IsApplicable = 0;
						code = me.calculateRatingCode(answers, ratingData);
					}
					break;
				// Item 12C
				case 16:
					questC1 = data.WellBeing.IsNeedsOfFosterParentsAdequatelyAssessed;
					questC2 = data.WellBeing.IsFosterParentsProvidedAppropriateServices;

					if (ratingData.IsApplicable == me.questionAns.No) {
						code = me.itemRating.NA;
					} else if (Ext.isEmpty(questC1) && Ext.isEmpty(questC2)) {
						code = me.itemRating.NotYetRated;
					} else if ((questC1 == me.questionAns.Yes && questC2 == me.questionAns.Yes) || (questC1 == me.questionAns.Yes && questC2 == me.questionAns.NA)) {
						code = me.itemRating.Strength;
					} else if (questC1 == me.questionAns.No || questC2 == me.questionAns.No) {
						code = me.itemRating.AreaNeedingImprovement;
					} else {
						code = me.itemRating.UnableToRate;
					}
					break;
				// Item 13
				case 17:
					answers.push(data.WellBeing.IsAgencyConcertedEffortsToInvolveTheChild);
					answers.push(data.WellBeing.IsAgencyConcertedEffortsToInvolveTheMother);
					answers.push(data.WellBeing.IsAgencyConcertedEffortsToInvolveTheFather);

					code = me.calculateRatingCode(answers, ratingData);
					break;
				// Item 14
				case 18:
					questA = data.WellBeing.IsResponsiblePartyVisitationFrequencySufficient;
					questB = data.WellBeing.IsResponsiblePartyVisitationQualitySufficient;

					if (ratingData.IsApplicable == me.questionAns.No) {
						code = me.itemRating.NA;
					} else if (Ext.isEmpty(questA) && Ext.isEmpty(questB)) {
						code = me.itemRating.NotYetRated;
					} else if (questA == me.questionAns.Yes && questB == me.questionAns.Yes) {
						code = me.itemRating.Strength;
					} else if (questA == me.questionAns.No || questB == me.questionAns.No) {
						code = me.itemRating.AreaNeedingImprovement;
					} else {
						code = me.itemRating.UnableToRate;
					}
					break;
				// Item 15
				case 19:
					answers.push(data.WellBeing.IsResponsiblePartyVisitationFrequencyWithMotherSufficient);
					answers.push(data.WellBeing.IsResponsiblePartyVisitationFrequencyWithFatherSufficient);
					answers.push(data.WellBeing.IsResponsiblePartyVisitationQualityWithMotherSufficient);
					answers.push(data.WellBeing.IsResponsiblePartyVisitationQualityWithFatherSufficient);

					code = me.calculateRatingCode(answers, ratingData);
					break;
				// Item 16
				case 20:
					questA = data.WellBeing.IsAgencyAssessEducationNeeds;
					questB = data.WellBeing.IsAgencyAddressEducationNeeds;

					if (ratingData.IsApplicable == me.questionAns.No) {
						code = me.itemRating.NA;
					} else if (Ext.isEmpty(questA) && Ext.isEmpty(questB)) {
						code = me.itemRating.NotYetRated;
					} else if ((questA == me.questionAns.Yes && questB == me.questionAns.Yes) || (questA == me.questionAns.Yes && questB == me.questionAns.NA)) {
						code = me.itemRating.Strength;
					} else if (questA == me.questionAns.No || questB == me.questionAns.No) {
						code = me.itemRating.AreaNeedingImprovement;
					} else {
						code = me.itemRating.UnableToRate;
					}
					break;
				// Item 17
				case 21:
					answers.push(data.WellBeing.IsAgencyAssessPhysicalHealthNeeds);
					answers.push(data.WellBeing.IsAgencyAssessDentalHealthNeeds);
					answers.push(data.WellBeing.IsFosterOversightMedicationForPhysicalHealtyAppropriate);
					answers.push(data.WellBeing.IsAppropriateSerivcesForAllPhysicalHealthNeeds);
					answers.push(data.WellBeing.IsAppropriateServicesForAllDentalNeeds);

					if (ratingData.IsApplicable == me.questionAns.No) {
						code = me.itemRating.NA;
					} else if (!me.isItemStarted(answers)) {
						code = me.itemRating.NotYetRated;
					} else {
						var yesAnswers = answers.filter(function (answer) {
								return answer == me.questionAns.Yes;
							}),
							noAnswers = answers.filter(function (answer) {
								return answer == me.questionAns.No;
							}),
							naAnswers = answers.filter(function (answer) {
								return answer == me.questionAns.NA;
							}),
							isStrength = yesAnswers.length > 0 ? ((yesAnswers.length + naAnswers.length) == answers.length ? true : false) : false;

						if (isStrength) {
							code = me.itemRating.Strength;
						} else if (noAnswers.length > 0) {
							code = me.itemRating.AreaNeedingImprovement;
						} else {
							code = me.itemRating.UnableToRate;
						}
					}
					break;
				// Item 18
				case 22:
					answers.push(data.WellBeing.IsAgencyAssessMentalHealthNeeds);
					answers.push(data.WellBeing.IsFosterOversightMedicationForMentalHealtyAppropriate);
					answers.push(data.WellBeing.IsAppropriateSerivcesForMentalHealthNeeds);

					if (ratingData.IsApplicable == me.questionAns.No) {
						code = me.itemRating.NA;
					} else if (!me.isItemStarted(answers)) {
						code = me.itemRating.NotYetRated;
					} else {
						var yesAnswers = answers.filter(function (answer) {
								return answer == me.questionAns.Yes;
							}),
							noAnswers = answers.filter(function (answer) {
								return answer == me.questionAns.No;
							}),
							naAnswers = answers.filter(function (answer) {
								return answer == me.questionAns.NA;
							}),
							isStrength = yesAnswers.length > 0 ? ((yesAnswers.length + naAnswers.length) == answers.length ? true : false) : false;

						if (isStrength) {
							code = me.itemRating.Strength;
						} else if (noAnswers.length > 0) {
							code = me.itemRating.AreaNeedingImprovement;
						} else {
							code = me.itemRating.UnableToRate;
						}
					}
					break;
			}
			vm.set('ratingData.ItemRatingCode', code);

			if (ratingData.ItemCode > 13 && ratingData.ItemCode < 17) {
				data = me.calculateItem12Rating(data);
			}
		}

		//need to calculate OverriddenOutcomeRatingCode based on overridden item orverridden rate
		result = me.calculateOutcomeRating(data, ratingData.ItemCode);
		vm.set('ratingData.OutcomeRatingCode', result.outcomeRatingCode);
		vm.set('ratingData.OverriddenOutcomeRatingCode', result.overriddenOutcomeRatingCode);
		//console.log('ratingData',vm.get('ratingData'))
	//	console.log('overriddenRating',vm.get('overriddenRating'))

	}

});