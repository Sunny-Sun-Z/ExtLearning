/**
 * Created by kkora on 9/7/2017.
 */
Ext.define('QuickStart.view.common.UserTagField', {
    extend: 'Ext.form.field.Tag',
    xtype: 'usertagfield',
    fieldLabel: 'User',
    displayField: 'Name',
    valueField: 'Id',
    forceSelection: true,
    queryMode: 'remote',
    minChars: 1,
    filterPickList: true,
    
    labelTpl: new Ext.create('Ext.XTemplate',
         "<div class='user-item'>",
                '<tpl if="Avatar==true">',
                    "<img src='user/GetProfilePicture?id={Id}' alt='Smiley face' class='profile-icon'>",
                '<tpl else>',
                     "<img src='{Avatar:this.defaultProfile}' alt='default' class='profile-icon'>",
                '</tpl>',
                "<div class='content-wrap'>",
                    "<div>",
                        "<h4 class='username'>{Name}</h4>",                        
                    "</div>",
                    "<h4 class='reviewer'>{Role}</h4>",
                   // "<div class='content'></div>",
                "</div>",
            "</div>",
        {
            defaultProfile: function (val) {
                return QuickStart.util.Global.getResources() + '/images/user-profile/default.png';;
            }
        }),
    tipTpl: new Ext.create('Ext.XTemplate',
            "<div class='user-item'>",
                   '<tpl if="Avatar==true">',
                       "<img src='user/GetProfilePicture?id={Id}' alt='Smiley face' class='profile-icon'>",
                   '<tpl else>',
                        "<img src='{Avatar:this.defaultProfile}' alt='default' class='profile-icon'>",
                   '</tpl>',
                   "<div class='content-wrap'>",
                       "<div>",
                           "<h4 class='username'>{Name}</h4>",
                           "<span class='active-status'><span class='{[values.IsActive ? 'x-fa fa-check-circle':'x-fa fa-ban']}'></span></span>",
                       "</div>",
                       "<h4 class='reviewer'>{Role}</h4>",
                       "<div class='content'></div>",
                   "</div>",
               "</div>",
           {
               defaultProfile: function (val) {
                   return QuickStart.util.Global.getResources() + '/images/user-profile/default.png';;
               }
           }),

    tpl: new Ext.create('Ext.XTemplate',
       '<tpl for=".">',
        '<div class="x-boundlist-item">',
            "<div class='user-item'>",
                '<tpl if="Avatar==true">',
                    "<img src='user/GetProfilePicture?id={Id}' alt='Smiley face' class='profile-icon'>",
                '<tpl else>',
                     "<img src='{Avatar:this.defaultProfile}' alt='default' class='profile-icon'>",
                '</tpl>',
                "<div class='content-wrap'>",
                    "<div>",
                        "<h4 class='username'>{Name}</h4>",
                        "<span class='active-status'><span class='{[values.IsActive ? 'x-fa fa-check-circle':'x-fa fa-ban']}'></span></span>",
                    "</div>",
                    "<h4 class='reviewer'>{Role}</h4>",
                    "<h4 class='email'>{Email}</h4>",
                    "<div class='content'></div>",
                "</div>",
            "</div>",
        '</div>',
      '</tpl>', {
          defaultProfile: function (val) {
              return  QuickStart.util.Global.getResources() + '/images/user-profile/default.png';;
          }
      }),
    getItemLabel: function(values) {
        // return Ext.String.htmlEncode(me.labelTpl.apply(values));
        //remove htmlencoding of label
        return me.labelTpl.apply(values)
    },
    listeners: {
        select: function (combo, record, index, eOpts) {
            if(combo.multiSelect==false)
                combo.collapse();
        }
    }
});