/**
 * Created by kkora on 9/7/2017.
 */
Ext.define('QuickStart.view.common.BaseWindow', {
    extend: 'Ext.window.Window',

    xtype: 'basewindow',
    closeAction: 'close',
    resizable: false,
    modal: true,
    maximized:true,
    constrain : true,
    closable :false
});