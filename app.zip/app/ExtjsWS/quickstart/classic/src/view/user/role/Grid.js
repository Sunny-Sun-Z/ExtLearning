/**
 * Created by kkora on 9/19/2017.
 */
Ext.define('QuickStart.view.user.role.Grid', {
    extend: 'Ext.grid.Panel',
    cls: 'user-grid dcf-grid',
    xtype: 'rolegrid',
    requires: [
        'Ext.form.field.Text',
        'Ext.grid.column.Action'
    ],
    title: 'Roles',
    scrollable: true,
    headerBorders: false,
    enableColumnResize: false,
    enableColumnMove: false,
    collapsible: true,
    collapseDirection: 'right',
    bind: '{roleStore}',
    selModel: {        selType: 'checkboxmodel'    },
    columns: [
        {
            cls: 'content-column boldFont',
            dataIndex: 'Name',
            text: 'Role',
            menuDisabled: true,
            flex: 1
        },
        {
            xtype: 'actioncolumn',
            items: [
                {
                    xtype: 'button',
                    iconCls: 'x-fa fa-pencil',
                    tooltip: 'View all permissions for this role',
                    handler: 'onViewRolePermissions'
                }
            ],
            menuDisabled: true,
            sortable: false,
            cls: 'content-column',
            width: 30,
            dataIndex: 'bool',
            tooltip: 'view '
        }
    ],
    dockedItems: [
        {
            xtype: 'toolbar',
            items: [{
                xtype: 'textfield',
                itemId: 'searchText',
                emptyText: 'Search...',
                flex: 1,
                triggers: {
                    clear: {
                        weight: -1,
                        cls: 'x-form-clear-trigger',
                        handler: function () {
                            this.setValue('');
                        }
                    }
                },
                listeners: {
                    change: 'onSearchRole'
                }
            }
            ]
        },
        {
            xtype: 'toolbar',
            dock: 'bottom',
            items: ['->', {
                text: 'Save',
                ui: 'soft-green',
                bind: {
                    disabled: '{!userGrid.selection}'

                },
                iconCls: 'x-fa fa-save',
                handler: 'onSaveRole'
            }]
        }
    ]
});