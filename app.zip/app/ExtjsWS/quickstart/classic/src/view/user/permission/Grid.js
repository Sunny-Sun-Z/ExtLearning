/**
 * Created by kkora on 9/19/2017.
 */
Ext.define('QuickStart.view.user.permission.Grid', {
    extend: 'Ext.grid.Panel',

    xtype: 'permissiongrid',
    title: 'Permissions',
    scrollable: true,
    headerBorders: false,
    enableColumnResize: false,
    enableColumnMove: false,
    collapsible: true,
    collapseDirection: 'right',
    bind: '{permissionStore}',
    selModel: {
        selType: 'checkboxmodel'
    },
    columns: [
        {
            xtype: 'gridcolumn',
            cls: 'content-column boldFont',
            dataIndex: 'Name',
            text: 'Permission',
            menuDisabled: true,
            flex: 1
        }
    ],
    dockedItems: [
        {
            xtype: 'toolbar',
            items: [{
                xtype: 'textfield',
                itemId:'searchText',
                emptyText: 'Search...',
                flex: 1,
                triggers:{
                    clear: {
                        weight:-1,
                        cls: 'x-form-clear-trigger',
                        handler: function () {
                            this.setValue('');
                        }
                    }
                },
                listeners:{
                    change:'onSearchPermission'
                }
            }
            ]
        },
        {
            xtype: 'toolbar',
            dock: 'bottom',
            items: ['->', {
                text: 'Save',
                bind:{
                    disabled:'{!userGrid.selection}'
                },
                ui: 'soft-green',
                iconCls: 'x-fa fa-save',
                handler: 'onSavePermission'
            }]
        }
    ]
});