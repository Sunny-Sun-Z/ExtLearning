/**
 * Created by kkora on 9/19/2017.
 */

Ext.define('QuickStart.view.user.role.Permissions', {
    extend: 'QuickStart.view.common.BaseWindow',
    xtype: 'rolepermissionswindow',
    width: 600,
    height: 500,
    layout: 'fit',
    bind: {
        title: "View Role '{current.role.Name}' Permissions"
    },
    maximized:false,
    constrain : false,

    items: [
        {
            xtype: 'grid',
            itemId: 'Permissions',
            scrollable: true,
            headerBorders: false,
            enableColumnResize: false,
            enableColumnMove: false,
            selModel: {
                selType: 'checkboxmodel'
            },
            columns: [
                {
                    xtype: 'gridcolumn',
                    cls: 'content-column boldFont',
                    dataIndex: 'Name',
                    text: 'Permission',
                    menuDisabled: true,
                    flex: 1
                }
            ],
            bind: '{permissionsStore}'
        }
    ],
    dockedItems: [
        {
            xtype: 'toolbar',
            dock: 'bottom',
            ui: 'footer',
            items: ['->', {
                text: 'Save',
                ui: 'soft-green',
                iconCls: 'x-fa fa-save',
                reference: 'rolePermissionSavebutton',
                formBind: true,
                handler: 'onSaveRolePermissions'

            }, {
                text: 'Cancel',
                ui: 'gray',
                iconCls: 'x-fa fa-close',
                handler: 'onRolePermissionRecordCancel'
            }]
        }
    ],
    listeners: {
        close: 'onRolePermissionRecordCancel'
    }
})
;