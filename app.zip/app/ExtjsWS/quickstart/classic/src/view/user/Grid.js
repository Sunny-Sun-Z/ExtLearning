/**
 * Created by kkora on 9/19/2017.
 */

Ext.define('QuickStart.view.user.Grid', {
    extend: 'Ext.grid.Panel',

    xtype: 'usergrid',
    cls: 'user-grid dcf-grid',
    title: 'Users',
    scrollable: true,
    headerBorders: false,
    enableColumnResize: false,
    enableColumnMove: false,
    bind: '{userStore}',
    selModel: {selType: 'rowmodel'},
    columns: [
        {
            hidden: true,
            menuDisabled: true,
            width: 40,
            dataIndex: 'UserId',
            text: '#'
        },
        {
            menuDisabled: true,
            sortable: false,
            renderer: function (value, meta, rec) {
                if (value) {
                     var path = 'user/GetPicture?id=' + rec.get('LoginID') + '.png';
                    //console.log(path)
                    return "<img src='" + path + "' alt='Profile Pic' height='30px' width='30px'>";
                }
                return Ext.String.format("<div class='avatar-circle-grid'> <span class='initials'>{0}</span></div>", QuickStart.util.Global.string.initial(rec.data.Name));
            },
            width: 40,
            dataIndex: 'Avatar'
        },
        {
            cls: 'content-column boldFont',
            dataIndex: 'Name',
            menuDisabled: true,
            text: 'Name',
            flex: 1
        },
        {
            cls: 'content-column boldFont',
            dataIndex: 'LoginID',
            menuDisabled: true,
            text: 'Login ID',
            flex: 1
        },
        {
            cls: 'content-column boldFont',
            dataIndex: 'Email',
            menuDisabled: true,
            text: 'Email',
            flex: 1
        },
        {
            cls: 'content-column boldFont',
            dataIndex: 'IsActive',
            menuDisabled: true,
            sortable: false,
            text: 'Active',
            align: 'center',
            renderer: function (val) {
                return val ? 'Yes' : 'No';
            }
        },
        {
            xtype: 'actioncolumn',
            items: [
                {
                    iconCls: 'x-fa fa-pencil',
                    handler: 'onEditUser',
                    tooltip: 'Edit User'
                },
                {
                    handler: 'onActiveDeactiveUser',
                    getClass: function (v, meta, record) {

                        if (record.get('IsActive')) {
                            this.items[1].tooltip = 'Deactivate User';
                            return 'x-fa fa-ban';
                        }
                        else {
                            this.items[1].tooltip = 'Activate User';
                            return 'x-fa fa-check-circle';
                        }
                    }
                }
            ],
            menuDisabled: true,
            width: 70,
            sortable: false,
            dataIndex: 'bool',
            tooltip: 'Actions '
        }
    ],
    dockedItems: [
        {// ui:'footer',
            xtype: 'toolbar',
            items: [{
                text: 'Add',
                ui: 'dcf',
                iconCls: 'x-fa fa-plus light',
                tooltip: 'Add New User',
                handler: 'onAddUser'
            }, //'->',
                {
                    xtype: 'checkbox',
                    hidden: true,
                    itemId: 'showInActiveCheck',
                    boxLabel: 'Show In-Active',
                    inputValue: 1,
                    uncheckedValue: 2,
                    listeners: {
                        change: 'onSearchUser'
                    }
                },
                {
                    xtype: 'combobox',
                    itemId: 'show',
                    fieldLabel: 'Show',
                    queryMode: 'local',
                    valueField: 'Id',
                    displayField: 'Name',
                    forceSelection: true,
                    labelWidth: 50,
                    labelAlign: 'right',
                    store: {
                        fields: ['Id', 'Name'],
                        data: [{Id: 1, Name: 'Active'}, {Id: 2, Name: 'De-Active'}]
                    },
                    triggers: {
                        clear: {
                            weight: -1,
                            cls: 'x-form-clear-trigger',
                            handler: function () {
                                this.setValue('');
                            }
                        }
                    },
                    listeners: {
                        change: 'onSearchUser',
                        select: 'onSearchUser'
                    }
                },

                {
                    xtype: 'textfield',
                    itemId: 'searchText',
                    emptyText: 'Search...',
                    flex: 1,
                    triggers: {
                        clear: {
                            weight: -1,
                            cls: 'x-form-clear-trigger',
                            handler: function () {
                                this.setValue('');
                            }
                        }
                    },
                    listeners: {
                        change: 'onSearchUser'
                    }

                }
            ]
        },
        {
            xtype: 'pagingtoolbar',
            // ui:'footer',
            dock: 'bottom',
            itemId: 'userPaginationToolbar',
            displayInfo: true,
            bind: '{userStore}'
        }
    ],
    listeners: {
        selectionchange: 'onUserSelection'
    }
});