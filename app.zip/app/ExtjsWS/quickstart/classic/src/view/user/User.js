Ext.define('QuickStart.view.user.User', {
    extend: 'Ext.Container',
    xtype: 'user',

    requires: [
        'Ext.grid.Panel',
        'Ext.grid.column.Date',
        'Ext.toolbar.Paging',
        'QuickStart.view.user.Grid',
        'QuickStart.view.user.UserController',
        'QuickStart.view.user.UserModel',
        'QuickStart.view.user.Window',
        'QuickStart.view.user.permission.Grid',
        'QuickStart.view.user.role.Grid',
        'QuickStart.view.user.role.Permissions'
    ],

    uses: [
        'QuickStart.view.user.permission.Grid'
    ],

    controller: 'user',
    viewModel: {
        type: 'user'
    },
    config: {
        highlightTitle: 'Security Management'
    },

    margin: 20,
    cls: 'casereview-container',
    layout: 'hbox',
    defaults: {

    },

    items: [
        {
            flex: 2,
            margin: '0 10 0 0',
            height: '100%',
            itemId: 'userGrid',
            reference: 'userGrid',
            routeId: 'user',
            xtype: 'usergrid'


        },
        {
            flex: 1,
            margin: '0 10 0 0',
            height: '100%',
            itemId: 'roleGrid',
            xtype: 'rolegrid'
        },
        {
            flex: 1,
            height: '100%',
            itemId: 'permissionGrid',
            xtype: 'permissiongrid'

        },
        {
            xtype: 'userwindow',
            itemId: 'userWindow'
        },
        {
            xtype: 'rolepermissionswindow',
            itemId: 'rolePermissionsWindow'
        }
    ],
    listeners:{
        afterrender:'onUserPanelRender'
    }

})
;
