Ext.define('QuickStart.view.user.UserController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.user',

    requires: [
        'QuickStart.model.User',
        'Ext.window.*'
    ],
    onSearchUser: function (field) {
        var me = this,
            toolbar = field.up(),
            showInActiveCheck = toolbar.down('#showInActiveCheck'),
            showCombo = toolbar.down('#show'),
            searchTextField = toolbar.down('#searchText'),
            searchText = searchTextField.getValue(),

            vm = me.getViewModel(),
            store = vm.getStore('userStore'),
            filters = [];
        store.clearFilter();

        //filters.push({property: 'IsActive', value: showInActiveCheck.getValue()});
        filters.push({property: 'IsActive', value: showCombo.getValue()});
        filters.push({property: 'Name', value: searchTextField.getValue()});
        store.setFilters(filters);
    },
    onSearchRole: function (field) {
        var me = this,
            vm = me.getViewModel(),
            store = vm.getStore('roleStore'),
            filters = [];
        store.clearFilter();

        filters.push({property: 'group', value: 'CrSecurityRoles'});
        filters.push({property: 'name', value: field.getValue()});
        store.setFilters(filters);
    },
    onSearchPermission: function (field) {
        var me = this,
            vm = me.getViewModel(),
            store = vm.getStore('permissionStore'),
            filters = [];
        store.clearFilter();

        filters.push({property: 'group', value: 'CrSecurityPermission'});
        filters.push({property: 'name', value: field.getValue()});
        store.setFilters(filters);
    },

    onAddUser: function (grid, btn) {

        var me = this,
            win = me.getView().down('#userWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = Ext.create('QuickStart.model.User');

        win.show(btn);
        form.reset();
        form.isValid();
        vm.set('current.user', record);
        vm.set('current.userAction', 'Add');
        vm.getStore('userStore').insert(0, record);
    },
    onSaveUser: function (btn) {
        var me = this,
            win = btn.up('window'),
            form = win.down('form').getForm(),
            values = form.getValues(),
            vm = me.getViewModel(),
            record = vm.get('current.user'),
            data = record.getData(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: win}),
            action = data.UserID > 0 ? 'user/updateuser' : 'user/createuser',
            isNew = vm.get('current.userAction') === 'Add'

        ;

        myMask.show();
        Ext.Ajax.request({
            url: QuickStart.util.Global.getApi() + action,
            method: 'POST',
            params: {userID: QuickStart.util.Global.getUser().id},
            jsonData: data,
            success: function (response, opts) {
                myMask.hide();
                var result = Ext.decode(response.responseText);
                if (result != null) {
                    if (!Ext.isEmpty(result.data)) {
                        QuickStart.util.Global.showMessage(result.message);
                        if (isNew) {
                            record.set('UserID', result.data.UserID);
                            me.lookupReference('userGrid').getSelectionModel().select(0);
                        }
                        record.commit();
                        win.close();
                    }
                }
            },
            failure: function (response, opts) {
                myMask.hide();
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });

    },
    onEditUser: function (grid, rowIndex, colIndex, cell, e, rec, row) {
        //  console.log(arguments)
        var me = this,
            win = me.getView().down('#userWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = rec;

        // form.reset();
        win.show(cell);
        form.isValid();
        vm.set('current.user', record);
        vm.set('current.userAction', 'Edit');
    },
    onDeleteUser: function (grid, rowIndex, colIndex, cell, e, rec, row) {
        // grid.getStore().remove(rec);

    },
    onActiveDeactiveUser: function (grid, rowIndex, colIndex, cell, e, record, row) {
        var me = this,
            data = record.getData(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: me.getView()}),
            action = 'user/ActiveDeactiveUser'
        ;
        // console.log(data)
        Ext.Msg.show({
            title: data.IsActive ? 'Deactivate User?' : 'Activate User?',
            message: "Are you sure do you want to " + (data.IsActive ? 'deactivate' : 'activate') + " user '<b>" + record.get('Name') + "</b>' ?",
            buttons: Ext.Msg.YESNO,
            icon: Ext.Msg.QUESTION,
            fn: function (btn) {
                if (btn === 'yes') {
                    myMask.show();
                    data.IsActive = !data.IsActive;
                    Ext.Ajax.request({
                        url: QuickStart.util.Global.getApi() + action,
                        method: 'POST',
                        params: {
                            userID: QuickStart.util.Global.getUser().id
                        },
                        jsonData: data,
                        success: function (response, opts) {
                            myMask.hide();
                            var result = Ext.decode(response.responseText);
                            if (result != null) {
                                if (!Ext.isEmpty(result.data)) {
                                    QuickStart.util.Global.showMessage(result.message);
                                    record.set('IsActive', result.data.IsActive);
                                    record.commit();

                                    //grid.getStore().remove(rec);
                                }
                            }
                        },
                        failure: function (response, opts) {
                            myMask.hide();
                            Ext.Msg.alert('Status', "failure");
                            console.log('server-side failure with status code ' + response.status);
                        },
                        scope: this
                    });
                }
            }
        }, this);


    },
    onUserStoreLoad: function (store) {

        if (store.getCount() > 0) {
            this.lookupReference('userGrid').getSelectionModel().select(0);
        }
    },
    onUserSelection: function (sm, selected) {
        ///  console.log(arguments)

        var me = this,
            vm = me.getViewModel(),
            record = selected[0],
            data = record ? record.getData() : {},
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: me.getView()}),
            action = 'user/GetUserRolesAndPermissions'
        ;
        if (record) {
            vm.set('current.user', record);
            if (data.Roles == null || data.Permissions == null || ( data.Roles.length == 0 && data.Permissions.length == 0)) {
                // myMask.show();
                Ext.Ajax.request({
                    url: QuickStart.util.Global.getApi() + action,
                    method: 'GET',
                    params: {userID: data.UserID},
                    success: function (response, opts) {
                        //myMask.hide();
                        var result = Ext.decode(response.responseText);
                        if (result != null) {
                            if (!Ext.isEmpty(result.data)) {
                                record.set('Roles', result.data.Roles);
                                record.set('Permissions', result.data.Permissions);
                                //console.log(result)
                                this.setRolesAndPermissions(result.data.Roles, result.data.Permissions);
                            }
                        }
                    },
                    failure: function (response, opts) {
                        //   myMask.hide();
                        Ext.Msg.alert('Status', "failure");
                        console.log('server-side failure with status code ' + response.status);
                    },
                    scope: this
                });
            }
            else {
                this.setRolesAndPermissions(data.Roles, data.Permissions);
            }
        }
    },

    onViewRolePermissions: function (grid, rowIndex, colIndex, cell, e, rec, row) {
        //  console.log(arguments)
        var me = this,
            win = me.getView().down('#rolePermissionsWindow'),
            vm = me.getViewModel(),
            record = rec,
            data = record.getData(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: win}),
            action = 'user/GetRolePermissions';

        win.show(cell);
        vm.set('current.role', record);
        myMask.show();
        Ext.Ajax.request({
            url: QuickStart.util.Global.getApi() + action,
            method: 'GET',
            params: {
                roleId: data.Id
            },
            success: function (response, opts) {
                myMask.hide();
                var result = Ext.decode(response.responseText);
                if (result != null) {
                    if (!Ext.isEmpty(result.data)) {
                        console.log(result)
                        // win.down('#Permissions').setValue(result.data.Permissions)
                        me.setGridValues('Permissions',result.data.Permissions);
                    }
                }
            },
            failure: function (response, opts) {
                myMask.hide();
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });
    },
    onSaveRolePermissions: function (btn) {
        var me = this,
            win = btn.up('window'),
            grid = win.down('grid'),
            selections = grid.getSelection(),
            vm = me.getViewModel(),
            record = vm.get('current.role'),
            data = record.getData(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: win}),
            values=[],
            action = 'user/UpdateRolePermissions'
        ;
        if (selections.length > 0) {
            values = Ext.Array.pluck(Ext.Array.pluck(selections, 'data'), 'Id');
        }

        record.set('Permissions', values);
        data = record.getData();
        data.RoleId=data.Id;
        myMask.show();
        Ext.Ajax.request({
            url: QuickStart.util.Global.getApi() + action,
            method: 'POST',
            params: {userID: QuickStart.util.Global.getUser().id},
            jsonData:data,
            success: function (response, opts) {
                myMask.hide();
                var result = Ext.decode(response.responseText);
                if (result != null) {
                    if (!Ext.isEmpty(result.data)) {
                        QuickStart.util.Global.showMessage(result.message);
                        record.commit();
                        win.close();
                    }
                }
            },
            failure: function (response, opts) {
                myMask.hide();
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });


    },
    onSaveRole: function (btn) {

        var me = this,
            grid = btn.up('grid'),
            selections = grid.getSelection(),
            values,
            vm = me.getViewModel(),
            record = vm.get('current.user'),
            data = record.getData(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: grid}),
            action = 'user/UpdateUserRoles'
        ;

        if (selections.length > 0) {
            values = Ext.Array.pluck(Ext.Array.pluck(selections, 'data'), 'Id');
        }

        data = {
            UserID: data.UserID,
            Roles: values || []
        };
        myMask.show();
        Ext.Ajax.request({
            url: QuickStart.util.Global.getApi() + action,
            method: 'POST',
            params: {userID: QuickStart.util.Global.getUser().id},
            jsonData: data,
            success: function (response, opts) {
                myMask.hide();
                var result = Ext.decode(response.responseText);
                if (result != null) {
                    if (!Ext.isEmpty(result.data)) {
                        QuickStart.util.Global.showMessage(result.message);
                        record.set('Roles', data.Roles);
                        record.commit();
                    }
                }
            },
            failure: function (response, opts) {
                myMask.hide();
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });

    },
    onSavePermission: function (btn) {

        var me = this,
            grid = btn.up('grid'),
            selections = grid.getSelection(),
            values,
            vm = me.getViewModel(),
            record = vm.get('current.user'),
            data = record.getData(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: grid}),
            action = 'user/UpdateUserPermissions'
        ;
        if (selections.length > 0) {
            values = Ext.Array.pluck(Ext.Array.pluck(selections, 'data'), 'Id');
        }
        data = {
            UserID: data.UserID,
            Permissions: values || []
        };
        myMask.show();
        Ext.Ajax.request({
            url: QuickStart.util.Global.getApi() + action,
            method: 'POST',
            params: {userID: QuickStart.util.Global.getUser().id},
            jsonData: data,
            success: function (response, opts) {
                myMask.hide();
                var result = Ext.decode(response.responseText);
                if (result != null) {
                    if (!Ext.isEmpty(result.data)) {
                        QuickStart.util.Global.showMessage(result.message);
                        record.set('Permissions', data.Permissions);
                        record.commit();
                    }
                }
            },
            failure: function (response, opts) {
                myMask.hide();
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });
    },
    onUserRecordCancel: function (owner) {
        var me = this,
            vm = me.getViewModel(),
            store = vm.getStore('userStore');
        if (store && store.rejectChanges)
            store.rejectChanges();
        if (owner.isWindow)
            owner.hide();
        else
            owner.up('window').close();

    },
    onRolePermissionRecordCancel: function (owner) {
        var me = this,
            vm = me.getViewModel(),
            store = vm.getStore('roleStore');
        if (store && store.rejectChanges)
            store.rejectChanges();
        if (owner.isWindow)
            owner.hide();
        else
            owner.up('window').close();
    },
    onUserPanelRender: function () {

    },
    setRolesAndPermissions: function (roles, permissions) {
        // var view = this.getView(),
        //     roleGrid = view.down('#roleGrid'),
        //     smRole = roleGrid.getSelectionModel(),
        //     roleStore = roleGrid.getStore(),
        //     permissionGrid = view.down('#permissionGrid'),
        //     permissionStore = permissionGrid.getStore(),
        //     smPermission = permissionGrid.getSelectionModel(),
        //     records = [],
        //     index
        // ;
        // smRole.deselectAll();
        // smPermission.deselectAll();
        //
        // if (roles && roles.length > 0) {
        //     Ext.each(roles, function (role) {
        //         index = roleStore.find('Id', role);
        //         if (index > -1) {
        //             smRole.select(index, true);
        //         }
        //     });
        // }
        //
        //
        // if (permissions && permissions.length > 0) {
        //     Ext.each(permissions, function (permission) {
        //         index = permissionStore.find('Id', permission);
        //         if (index > -1) {
        //             smPermission.select(index, true);
        //         }
        //     });
        // }
        this.setGridValues('roleGrid',roles);
        this.setGridValues('permissionGrid',permissions);

    },
    setGridValues: function (gridItemId, values) {
        var view = this.getView(),
            grid = view.down('#' + gridItemId),
            sm = grid.getSelectionModel(),
            store = grid.getStore(),
            records = [],
            index;

        sm.deselectAll();

        if (values && values.length > 0) {
            Ext.each(values, function (v) {
                index =store.find('Id',v,0,false,true,true);//(prop,value, start, anymatch, caseSensitive, exactmatch)
                if (index > -1) {
                    sm.select(index, true);
                }
            });
        }
    }
})
;
