/**
 * Created by kkora on 9/19/2017.
 */
Ext.define('QuickStart.view.report.Report', {
    extend: 'Ext.Container',

    requires: [
        'QuickStart.view.pages.BlankPage',
        'QuickStart.view.report.ReportController',
        'QuickStart.view.report.ReportModel',
        'QuickStart.view.report.Test'
    ],

    xtype: 'report',


    viewModel: {
        type: 'report'
    },
    config: {
        highlightTitle: 'Report'
    },
    margin: 20,

    controller: 'report',
    layout: 'border',
    items: [
        // {
        //     title: 'Report',
        //     xtype: 'pageblank'
        //  //   xtype: 'test'
        // // },
        // // {
        // //     title: 'basereport',
        // //     xtype: 'basereport'
        // }

        {
           xtype:'reportgrid'
        },{
            xtype:'reporttabpanel',
            reference:'reportTab'

        }
    ]
});