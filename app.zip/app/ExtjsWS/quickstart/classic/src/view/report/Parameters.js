/**
 * Created by kkora on 1/29/2018.
 */
Ext.define('QuickStart.view.report.Parameters', {
    extend: 'Ext.grid.Panel',
    cls: 'user-grid dcf-grid',
    requires: [
        'Ext.form.field.*',
         'Ext.grid.column.RowNumberer',
        'Ext.grid.plugin.CellEditing'
    ],
    flex: 1,
    xtype: 'parametergrid',
    selModel: {
        type: 'cellmodel'
    },
    plugins: [{
        ptype: 'cellediting',
        clicksToEdit: 1
    }],
    columns: [
        {xtype: 'rownumberer'},
        {
            flex: 1,
            text: 'Parameter',
            dataIndex: 'Name'
        },
        {
            flex: 2,
            text: 'Label',
            dataIndex: 'Label',
            editor: {
                xtype: 'textfield',
                allowBlank: false
            }
        },
        {
            text: 'DataType',
            dataIndex: 'DataType',
            editor: {
                xtype: 'combobox',
                allowBlank: false,
                value:'String',
                store:['String','Int','Date','Boolean'],
                queryMode: 'local',
                editable: false,
                listConfig: {
                    width: 300
                }
            }
        },
        {
            flex: 1,
            text: 'Field Type',
            dataIndex: 'FieldType',
            editor: {
                xtype: 'combobox',
                allowBlank: false,
                value:'Text',
                store:['Text','Number','Date','Check','Lookup'],
                queryMode: 'local',
                editable: false,
                listConfig: {
                    width: 300
                }
            }
        },
          {
            flex: 1,
            text: 'Lookup',
            dataIndex: 'LookupId',
            editor: {
                xtype: 'combobox',
                displayField: 'Value',
                valueField: 'Key',
                bind: {
                    store: '{reportLookup}'
                },
                queryMode: 'local',
                editable: false,
                listConfig: {
                    width: 300
                }
            },
            renderer:'reportLookupRenderer'
        },
           {
            flex: 1,
            hidden:true,
            text: 'Value Field',
            dataIndex: 'LookupValueField',
             editor: {
                 xtype: 'textfield'
             }
        },
        {
            flex: 1,
            hidden:true,
            text: 'Display Field',
            dataIndex: 'LookupDisplayField',
            editor: {
                xtype: 'textfield'
            }
        },
        {
            flex: 1,
            text: 'DefaultValue',
            dataIndex: 'DefaultValue',
            editor: {
                xtype: 'textfield'
            }
        }
    ]
});