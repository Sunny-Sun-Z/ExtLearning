/**
 * Created by kkora on 1/23/2018.
 */
Ext.define('QuickStart.view.report.Grid', {
    extend: 'Ext.grid.Panel',
    cls: 'user-grid dcf-grid',
    requires: [
        'Ext.grid.column.RowNumberer'
    ],
    title:'Reports',
    region:'west',
    flex:1,
    xtype: 'reportgrid',
  //  hideHeaders:true,
    split:true,
    collapsible:true,
    bind:'{reports}',
    columns: [
        {xtype: 'rownumberer'},
        {
            flex: 1,
            menuDisabled: true,
            text: 'Report Name',
            dataIndex: 'Description'
        }
    ],
    dockedItems: [
        {
            xtype: 'pagingtoolbar',
            dock: 'bottom',
            itemId: 'paginationToolbar',
            displayInfo: false,
            bind: '{reports}'

        }
    ],
    listeners:{
        'selectionchange':'onReportSelectionChange'
    }
});