/**
 * Created by kkora on 1/26/2018.
 */
Ext.define('QuickStart.view.report.AddReportWindow', {
    extend: 'QuickStart.view.common.BaseWindow',
    requires: [
        'Ext.form.FieldSet',
        'Ext.form.Panel',
        'Ext.form.RadioGroup',
        'Ext.form.field.*',
        'Ext.layout.container.VBox'
    ],

    alias: 'widget.addreportwindow',
    width: 600,
    height: 500,
    layout: 'fit',
    resizable: true,
    maximized: true,
    constrain: true,
    defaults: {
        defaultFocus: 'textfield:not([value]):focusable:not([disabled])'
    },
    title: 'Add Report',
    items: [{
        bodyPadding: '10 10 0 10',
        xtype: 'form',
        scrollable: 'y',
        defaultType: 'textfield',
        defaults: {
            submitEmptyText: false,
            anchor: '100%',
            labelWidth: 150,
            fieldLabel: ' ',
            msgTarget: 'side'
        },
        layout: {
            type: 'vbox',
            align: 'stretch'
        },
        items: [
            {
                allowBlank: false,
                fieldLabel: 'Description',
                bind: '{current.Report.Description}',
                name: 'Description'
            },
            {
                bind: {value: '{reportType}'},
                xtype: 'radiogroup',
                fieldLabel: 'Type',
                name: 'Type',
                defaults: {name: 'Type'},
                items: [{
                    boxLabel: 'SSIS', inputValue: 'SSIS', checked: true,
                }, {
                    boxLabel: 'ADHOC', inputValue: 'ADHOC'
                }, {
                    boxLabel: 'LOOKUP', inputValue: 'LOOKUP'
                }],
                listeners: {change: 'onQueryChanged'}

            },
            {
                xtype: 'fieldset',
                title: 'SSIS',
                bind: {
                    hidden: '{!ssisReportType}'
                },
                items: [{
                    xtype: 'textfield',
                    fieldLabel: 'URL',
                    name: 'URL',
                    msgTarget: 'side',
                    anchor: '100%',
                    setAllowBlank: function (value) {
                        this.allowBlank = value;
                        this.isValid();
                    },
                    bind: {
                        value: '{current.Report.Url}',
                        allowBlank: '{!ssisReportType}'
                    }

                }, {
                    fieldLabel: 'File Name',
                    xtype: 'textfield',
                    name: 'FileName',
                    msgTarget: 'side',
                    anchor: '100%',
                    setAllowBlank: function (value) {
                        this.allowBlank = value;
                        this.isValid();
                    },
                    bind: {
                        value: '{current.Report.FileName}',
                        allowBlank: '{!ssisReportType}'
                    }
                }]
            },
            {
                xtype: 'fieldset',
                title: 'Adhoc SQL Query',
                bind: {hidden: '{ssisReportType}'},
                layout: {type: 'vbox', align: 'stretch'},
                flex: 1,
                items: [{
                    flex: 1,
                    xtype: 'textarea',
                    name: 'Query',
                    anchor: '100%',
                    msgTarget: 'side',
                    emptyText: 'Enter SQL Query',
                    setAllowBlank: function (value) {
                        this.allowBlank = value;
                        this.isValid();
                    },
                    bind: {
                        value: '{current.Report.Query}',
                        allowBlank: '{ssisReportType}'
                    },
                    listeners: {change: 'onQueryChanged'}
                }, {
                    hidden: true,
                    xtype: 'parametergrid',
                    itemId: 'parameterGrid',
                    bind: '{parameters}'
                }]
            }
        ],
        dockedItems: [
            {
                xtype: 'toolbar',
                dock: 'bottom',
                ui: 'footer',
                items: [{
                    bind: {
                        // hidden: '{ssisReportType}'
                    },
                    hidden: true,
                    text: 'Execute',
                    ui: 'dcf',
                    iconCls: 'x-fa fa-cogs',
                    formBind: true,
                    handler: 'onExecuteReport'

                }, '->', {
                    text: 'Save',
                    ui: 'soft-green',
                    iconCls: 'x-fa fa-save',
                    formBind: true,
                    handler: 'onSaveReport'

                }, {
                    text: 'Cancel',
                    ui: 'gray',
                    iconCls: 'x-fa fa-close',
                    handler: function (btn) {
                        btn.up('window').close();
                    }
                }]
            }]
    }]
});