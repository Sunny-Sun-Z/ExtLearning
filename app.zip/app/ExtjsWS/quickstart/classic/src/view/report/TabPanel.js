/**
 * Created by kkora on 1/23/2018.
 */
Ext.define('QuickStart.view.report.TabPanel', {
    extend: 'Ext.tab.Panel',

    xtype: 'reporttabpanel',
    region: 'center',
    flex: 3
});