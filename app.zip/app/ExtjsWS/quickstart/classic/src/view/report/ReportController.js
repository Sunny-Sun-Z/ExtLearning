/**
 * Created by kkora on 9/19/2017.
 */
Ext.define('QuickStart.view.report.ReportController', {
	extend: 'Ext.app.ViewController',
	alias: 'controller.report',

	requires: [
		'Ext.grid.property.Grid',
		'Ext.layout.container.Border',
		'Ext.layout.container.Fit',
		'Ext.panel.Panel',
		'Ext.toolbar.Fill',
		'Ext.toolbar.Toolbar'
	],

	/**
	 * Called when the view is created
	 */
	init: function () {

	},
    onReportSelectionChange: function (grid, selection, eOpts) {
       

		if (selection == null || selection.length == 0) {
			return;
		}

		var me = this,
			rec = selection[0],
			data = rec.getData(),
			reportTab = this.lookupReference('reportTab'),
			panel = reportTab.down('#report-' + data.Id)
		;
		if (!panel) {
			if (data.Type == 'SSIS') {
				panel = me.addSsisReport(data);
			}
			else if (data.Type == 'COMPONENT') {
				panel = me.addComponentReport(data);
			}
			else {
				panel = me.addAdhocReport(data);
			}
		}
		reportTab.setActiveItem(panel);

	},
	addSsisReport: function (data) {
		console.log(Ext.browser);

		var reportTab = this.lookupReference('reportTab'),
			browsers = QuickStart.util.Global.getReportInBrowsers(),
			currentBrowser = Ext.browser.name.toLowerCase(),
			panel = {
				xtype: 'panel',
				layout: 'fit',
				title: data.Description,
				itemId: 'report-' + data.Id,
				record: data,
				closable: true,
				border: false,
				style: 'border:0px solid #b7bcc4;',
				items: {
					scrollable: true,
					xtype: 'component',
					// style: 'border:0px solid #b7bcc4;',
					border: false,
					autoEl: {scrollable: 'y', scrolling: "yes", src: data.Url, tag: 'iframe'}
				}
			};

		if (browsers) {
			browsers = browsers.toLowerCase();
			if (browsers.indexOf(currentBrowser) > -1) {
				panel.dockedItems = [{
					xtype: 'toolbar',
					items: [
						"->", {
							text: 'Open in Browser',
							iconCls: 'x-fa fa-globe',
							url: data.Url,
							handler: function () {
								this.openWindow = window.open(data.Url, "_blank");
							}
						}]
				}				];
			}
		}
		return reportTab.add(panel);
	},
	addComponentReport: function (data) {
		var reportTab = this.lookupReference('reportTab');
		return reportTab.add({
			xtype: data.Component,
			// layout: 'fit',
			title: data.Description,
			itemId: 'report-' + data.Id,
			record: data,
			closable: true,
			border: false,
			style: 'border:0px solid #b7bcc4;',
			//items: {
			//    xtype: data.Component

			//}
		});
	},
	addAdhocReport: function (data) {
		var me = this,
			reportTab = this.lookupReference('reportTab'),
			myMask = new Ext.LoadMask({msg: 'Please wait...', target: reportTab}),
			url = QuickStart.util.Global.getApi() + 'report/GetAdhocColumns';

		myMask.show();
		console.log(data);
		Ext.Ajax.request({
			url: url,
			method: 'GET',
			headers: {'Content-Type': 'application/json'},
			params: {
				userID: QuickStart.util.Global.getUser().id,
				Id: data.Id
			},
			success: function (response, opts) {
				myMask.hide();

				var result = Ext.decode(response.responseText);
				if (result != null) {
					if (result.success) {

						Ext.suspendLayouts();
						var panel = reportTab.add(me.buildResult({columns: result.data, data: data}));
						reportTab.setActiveItem(panel);
						Ext.resumeLayouts(true);
						var resultGrid = panel.down('#result-' + data.Id);
						var parameterGrid = panel.down('#parameter-' + data.Id);

						if (parameterGrid) {
							parameterGrid.setSource(parameterGrid.source, parameterGrid.extra.config);
						}

						if (resultGrid && (data.Parameters == null || data.Parameters.length == 0))
							resultGrid.getStore().reload();
					}
				}

			},
			failure: function (response, opts) {
				myMask.hide();
				Ext.Msg.alert('Status', "failure");
				console.log('server-side failure with status code ' + response.status);
			},
			scope: this
		});
	},
	buildResult: function (config) {
		var me = this,
			columns = config.columns,
			data = config.data,
			items = [],
			grid = me.buildGrid(columns, data),
			parameter = me.buildParameters(data)
		;
		if (grid) items.push(grid);
		if (parameter) items.push(parameter);

		return {
			xtype: 'panel',
			title: data.Description,
			itemId: 'report-' + data.Id,
			layout: 'border',
			record: data,
			closable: true,
			items: items
		};
	},
	buildGrid: function (columns, data) {
		var fields = [], gridColumns = [];
		gridColumns.push({xtype: 'rownumberer'});

		Ext.each(columns, function (col) {
			fields.push({name: col.Key, type: col.Value});
			var gcol = {
				tooltip: col.Key,
				text: col.Key,
				width: col.Value == "string" ? 200 : 100,
				align: col.Value == "int" ? 'right' : 'left',
				formatter: col.Value == "date" ? 'date("m/d/Y")' : null,
				dataIndex: col.Key
			};

			gridColumns.push(gcol);
		});
		var store = new Ext.data.JsonStore({
			storeId: 'store' + data.Id,
			proxy: {
				type: 'ajax',
				url: QuickStart.util.Global.getApi() + 'report/GetAdhocResult?id=' + data.Id,
				reader: {
					type: 'json',
					rootProperty: 'data',
					totalProperty: 'total'
				}
			},
			fields: fields
		});

		var grid = Ext.create('Ext.grid.Panel', {
			//title: data.Description,
			// itemId: 'report-' + data.Id,
			itemId: 'result-' + data.Id,
			record: data,
			// closable: true,
			region: 'center',
			store: store,
			columns: gridColumns,
			flex: 1,
			viewConfig: {
				emptyText: '<span style="text-align: center;font-weight: bold" >No Record Found</span>'
			},
			dockedItems: [
				{
					xtype: 'pagingtoolbar',
					dock: 'bottom',
					itemId: 'paginationToolbar',
					displayInfo: true,
					store: store,
					displayMsg :'Total Record(s): {2}'
				}],
			listeners: {
				afterrender: function (grid) {
					for (var i = 0; i < 10; i++)
						grid.down('#paginationToolbar').items.items[i].hide();
				}
			}
		});

		return grid;
	},
	buildParameters: function (data) {
		var me = this,
			parameters = data.Parameters,
			source = {},
			config = {}

		;

		if (Ext.isEmpty(parameters) || parameters.length == 0)
			return null;

		Ext.each(parameters, function (p) {

			source[p.Name] = p.DefaultValue;

			config[p.Name] = {
				displayName: p.Label,
				type: me.getParameterDataType(p),
				editor: me.getParameterComponent(p)
			}
		});

		var grid = {
			xtype: 'propertygrid',
			itemId: 'parameter-' + data.Id,
			region: 'east',
			title: 'Parameters',
			width: 250,
			split: true,
			collapsible: true,
			source: source,
			extra: {
				config: config
			},
			dockedItems: [
				{
					xtype: 'toolbar',
					dock: 'bottom',
					//   ui: 'footer',
					items: ['->', {
						text: 'Execute',
						ui: 'dcf',
						data: data,
						iconCls: 'x-fa fa-bolt',
						formBind: true,
						handler: me.onExecuteReport
					}]
				}]

		};

		return grid;
	},
	onExecuteReport: function (btn) {
		var propertygrid = btn.up('propertygrid'),
			source = propertygrid.getSource(),
			panel = propertygrid.up('panel'),
			store = panel.down('grid').getStore(),
			filters = [];

		for (var s in source) {
			if (!Ext.isEmpty(source[s])) {
				filters.push({property: s, value: source[s]})
			}
		}

		if (store)
			store.reload({params: {filter: Ext.encode(filters)}});

	},
	getParameterDataType: function (data) {
		switch (data.DataType) {
			case 'Int':
				return 'number';
			case 'Date':
				return 'date';
			case 'Float':
				return 'float';
			case 'Boolean':
				return 'boolean';
			default:
				return 'string';
		}
	},
	getParameterComponent: function (data) {
		var isRequired = data.Required == true;
		switch (data.FieldType) {
			case 'Lookup':
				return {
					xtype: 'combobox',
					store: new Ext.data.JsonStore({
						// autoLoad: true,
						remoteFilter: true,
						//   filters: [{property: 'Key', value: ''}],
						proxy: {
							type: 'ajax',
							url: QuickStart.util.Global.getApi() + 'report/GetReportLookupResult?id=' + data.LookupId,
							reader: {
								type: 'json',
								rootProperty: 'data',
								totalProperty: 'total'
							}
						}
					}),

					minChars: 1,
					typeAhead: 'all',
					displayField: 'Value',
					valueField: 'Key',
					forceSelection: true,
					allowBlank: !isRequired
				};
			case 'Combo':
				return {
					xtype: 'combobox',
					store: [],
					forceSelection: true,
					allowBlank: !isRequired
				};
			case 'Date':
				return {
					xtype: 'datefield',
					allowBlank: !isRequired
				};
			case 'Number':
				return {
					xtype: 'numberfield',
					allowBlank: !isRequired
				};
			case 'Check':
				return null;
			// return {
			//     xtype: 'checkbox',
			//     allowBlank: !isRequired
			// };
			case 'Text':
				return {
					xtype: 'textfield',
					vtype: data.FieldValidationType,
					allowBlank: !isRequired
				};
			default :
				return {}
		}
	},

});