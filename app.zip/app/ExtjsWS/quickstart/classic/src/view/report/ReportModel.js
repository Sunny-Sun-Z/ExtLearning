/**
 * Created by kkora on 9/19/2017.
 */
Ext.define('QuickStart.view.report.ReportModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.report',

    stores: {
      reports:{
          model: 'QuickStart.model.Report',
          autoLoad: true,
          pageSize: 20,
          remoteFilter: true,
          remoteSort:true,
          filters: [{property:'name',value:''}],
          proxy: {
              url: QuickStart.util.Global.getApi(),
              type: 'ajax',
              paramsAsJson: true,
              pageParam:null,
              api: {
                  read: 'report/GetReports'
              },
              //  actionMethods: {read: 'POST'},
              reader: {
                  type: 'json',
                  rootProperty: 'data',
                  totalProperty: 'total'
              }
          }
      }
    },

    data: {
        /* This object holds the arbitrary data that populates the ViewModel and is then available for binding. */
    }
});