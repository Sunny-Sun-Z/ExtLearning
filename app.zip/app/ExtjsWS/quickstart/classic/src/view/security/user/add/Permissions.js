/**
 * Created by kkora on 9/19/2017.
 */

Ext.define('QuickStart.view.security.user.add.Permissions', {
    extend: 'QuickStart.view.common.BaseWindow',
    xtype: 'adduserpermissionswindow',

    requires: [
        'Ext.form.field.Tag',
        'Ext.layout.container.Fit',
        'Ext.toolbar.Fill'
    ],

    width: 600,
    layout: 'fit',
    bind: {
        title: "Add Permissions for User '{current.user.Name}'"
    },
    maximized: false,
    constrain: false,
    items: [
        {
            padding: 10,
            xtype: 'tagfield',
            fieldLabel: 'Permissions',
            bind: {
                store: '{userNonePermissionsStore}'
            },
            displayField: 'Name',
            valueField: 'Id',
            forceSelection: true,
            filterPickList: true,
            growMax: 300,
            name: 'Name',
            itemId: 'Name',
            reference: 'userPermissionsTag',
            queryMode: 'local',
            allowBlank: false
        }
    ],
    dockedItems: [
        {
            xtype: 'toolbar',
            dock: 'top',
            ui: 'footer',
            items: ['->', {
                text: 'Save',
                ui: 'soft-green',
                iconCls: 'x-fa fa-save',
                bind: {
                    disabled: '{!userPermissionsTag.selection}'
                },
                handler: 'onSaveUserPermissions'

            }, {
                text: 'Cancel',
                ui: 'gray',
                iconCls: 'x-fa fa-close',
                handler: function (btn) {
                    btn.up('window').close();
                }
            }]
        }
    ]
})
;