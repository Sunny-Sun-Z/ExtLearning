/**
 * Created by kkora on 9/19/2017.
 */
Ext.define('QuickStart.view.security.user.Roles', {
    extend: 'Ext.grid.Panel',
    cls: 'user-grid dcf-grid',
    xtype: 'userroles',
    requires: [
        'Ext.grid.column.Action'
    ],
    scrollable: true,
    hideHeaders:true,
    headerBorders: false,
    enableColumnResize: false,
    enableColumnMove: false,
    bind: '{userRolesStore}',
    viewConfig: {
        emptyText: '<span style="text-align: center;font-weight: bold" >No Record Found</span>'
    },
    title:'Roles',
    columns: [
        {
            cls: 'content-column boldFont',
            dataIndex: 'Name',
            text: 'User Roles',
            menuDisabled: true,
            flex: 1
        },
        {
            xtype: 'actioncolumn',
            items: [
                {
                    iconCls: 'x-fa fa-close',
                    tooltip: 'Remove user role',
                    handler: 'onDeleteUserRole'
                }
            ],
            menuDisabled: true,
            width:40,
            sortable: false,
            align: 'center',
            dataIndex: 'bool',
            tooltip: 'Delete'
        }
    ]
});