Ext.define('QuickStart.view.security.user.Panel', {
    extend: 'Ext.panel.Panel',
    xtype: 'userpanel',

    requires: [
        'Ext.form.field.Checkbox',
        'Ext.form.field.ComboBox',
        'Ext.grid.Panel',
        'Ext.grid.column.Date',
        'Ext.toolbar.Paging',
        'QuickStart.view.user.UserController',
        'QuickStart.view.user.UserModel',
        'QuickStart.view.user.Window',
        'QuickStart.view.user.permission.Grid',
        'QuickStart.view.user.role.Grid',
        'QuickStart.view.user.role.Permissions'
    ],

    cls: 'casereview-container',
    layout: 'hbox',
    defaults: {
        border: true
    },
    dockedItems: [
        {// ui:'footer',
            xtype: 'toolbar',
            items: [{
                text: 'Add New User',
                xtype: 'splitbutton',
                ui: 'dcf',
                iconCls: 'x-fa fa-plus light',
                tooltip: 'Add New User',
                handler: 'onAddUser',
                menu: {
                    items: [
                        {
                            text: 'Add User Role',
                            bind: {
                                disabled: '{!userList.selection}'
                            },
                            handler: 'onAddUserRoles'
                        },
                        {
                            text: 'Add User Permission',
                            bind: {
                                disabled: '{!userList.selection}'
                            },
                            handler: 'onAddUserPermissions'
                        }
                    ]
                }
            },
                {
                    text: 'Edit User',
                    bind: {
                        disabled: '{!userList.selection}'
                    },
                    iconCls: 'x-fa fa-pencil',
                    handler: 'onEditUser'

                },
                {
                    text: 'Activate',
                    ui: 'soft-green',
                    itemId:'activate',
                    disabled:true,
                    // bind: {
                    //     disabled: '{!userList.selection || (userList.selection && userList.selection.IsActive) }'
                    // },
                    iconCls: 'x-fa fa-check-circle',
                    handler: 'onActivateUser'

                },
                {
                    text: 'Deactivate',
                    ui: 'soft-red',
                    // bind: {
                    //     disabled: '{!userList.selection || (userList.selection && !userList.selection.IsActive )}'
                    // },
                    itemId:'deactivate',
                    disabled:true,
                    iconCls: 'x-fa fa-ban',
                    handler: 'onActivateUser'

                },
                {
                    xtype: 'checkbox',
                    hidden: true,
                    itemId: 'showInActiveCheck',
                    boxLabel: 'Show In-Active',
                    inputValue: 1,
                    uncheckedValue: 2,
                    listeners: {
                        change: 'onSearchUser'
                    }
                },
                {
                    xtype: 'combobox',
                    itemId: 'show',
                    fieldLabel: 'Show',
                    queryMode: 'local',
                    valueField: 'Id',
                    displayField: 'Name',
                    forceSelection: true,
                    labelWidth: 50,
                    labelAlign: 'right',
                    value: '',
                    store: {
                        fields: ['Id', 'Name'],
                        data: [{Id: '', Name: 'All'}, {Id: 1, Name: 'Active User'}, {Id: 2, Name: 'Inactive User'}]
                    },
                    // triggers: {
                    //     clear: {
                    //         weight: -1,
                    //         cls: 'x-form-clear-trigger',
                    //         handler: function () {
                    //             this.setValue('');
                    //         }
                    //     }
                    // },
                    listeners: {
                        change: 'onSearchUser',
                        select: 'onSearchUser'
                    }
                },'->',
                {
                    xtype: 'textfield',
                    itemId: 'searchText',
                    emptyText: 'Search user...',
                    flex: 1,
                    triggers: {
                        clear: {
                            weight: -1,
                            cls: 'x-form-clear-trigger',
                            handler: function () {
                                this.setValue('');
                            }
                        }
                    },
                    listeners: {
                        change: 'onSearchUser'
                    }

                }
            ]
        },
        {
            xtype: 'pagingtoolbar',
            // ui:'footer',
            dock: 'bottom',
            itemId: 'userPaginationToolbar',
            displayInfo: true,
            bind: '{userStore}'
        }
    ],

    items: [
        {
            flex: 5,
            margin: '0 10 0 0',
            height: '100%',
            reference: 'userList',
            itemId: 'userList',
            xtype: 'userlist'


        },
        {
            flex: 2,
            margin: '0 10 0 0',
            height: '100%',
            itemId: 'userRoles',
            xtype: 'userroles',
            tools: [{
                type: 'plus',
                tooltip: 'Add Roles',
                bind: {disabled: '{!userList.selection}'},
                handler: 'onAddUserRoles'
            }]
        },
        {
            flex: 3,
            height: '100%',
            itemId: 'userPermissions',
            xtype: 'userpermissions',
            tools: [{
                type: 'plus',
                tooltip: 'Add Permissions',
                bind: {disabled: '{!userList.selection}'},
                handler: 'onAddUserPermissions'
            }],

        },
        {
            xtype: 'adduserwindow',
            itemId: 'userWindow'
        },
        {
            xtype: 'adduserpermissionswindow',
            itemId: 'addUserPermissionsWindow'
        },
        {
            xtype: 'adduserroleswindow',
            itemId: 'addUserRolesWindow'
        }
    ]

})
;
