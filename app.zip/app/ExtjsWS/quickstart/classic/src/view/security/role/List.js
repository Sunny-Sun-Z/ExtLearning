/**
 * Created by kkora on 9/19/2017.
 */
Ext.define('QuickStart.view.security.role.List', {
    extend: 'Ext.grid.Panel',
    cls: 'user-grid dcf-grid',
    xtype: 'rolelist',
    requires: [
        'Ext.grid.column.Action',
        'Ext.grid.column.RowNumberer'
    ],
    scrollable: true,
    headerBorders: true,
   // hideHeaders :true,
    enableColumnResize: false,
    enableColumnMove: false,
    bind: '{roleStore}',
    selModel: {selType: 'rowmodel'},
    columns: [{xtype: 'rownumberer'},
        {
            cls: 'content-column boldFont',
            dataIndex: 'Name',
            text: 'Role',
            menuDisabled: true,
            flex: 1
        }
    ],
     listeners: {
        selectionchange: 'onRoleSelection'
    }

});