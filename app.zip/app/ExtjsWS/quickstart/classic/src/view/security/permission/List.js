/**
 * Created by kkora on 9/19/2017.
 */
Ext.define('QuickStart.view.security.permission.List', {
    extend: 'Ext.grid.Panel',

    xtype: 'permissionlist',

    requires: [
         'Ext.grid.column.RowNumberer'
    ],

    title: 'Permissions',
    scrollable: true,
    headerBorders: true,
    hideHeaders :true,
    enableColumnResize: false,
    enableColumnMove: false,
    columns: [{xtype: 'rownumberer'},
        {
            cls: 'content-column boldFont',
            dataIndex: 'Name',
           // text: 'Permission',
            menuDisabled: true,
            flex: 1
        }
    ]
});