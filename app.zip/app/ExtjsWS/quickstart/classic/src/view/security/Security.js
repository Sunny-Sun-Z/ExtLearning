/**
 * Created by kkora on 3/13/2018.
 */
Ext.define('QuickStart.view.security.Security', {
    extend: 'Ext.tab.Panel',

    requires: [
        'QuickStart.view.security.SecurityModel',
		'QuickStart.view.security.SecurityController'
    ],

    xtype: 'security',

    viewModel: {
        type: 'security'
    },

    controller: 'security',

    margin: 20,
    cls: 'casereview-container',

    items: [
        {
            xtype: 'userpanel',
            title:'Users'
        },
        {
            itemId: 'roleGrid',
            xtype: 'rolepanel'
        },
        {
             xtype: 'permissionlist',
             bind: '{permissionStore}'
        }
    ]
});