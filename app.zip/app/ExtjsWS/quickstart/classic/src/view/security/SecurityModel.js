/**
 * Created by kkora on 3/13/2018.
 */
Ext.define('QuickStart.view.security.SecurityModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.security',
    requires: [
        'QuickStart.store.GroupLookups',
        'QuickStart.store.Users'
    ],
    data: {
        current: {
            user: null,
            userAction: 'Edit',
            rolePermissions: null
        }
    },
    formulas: {

        emailMessagePreference: {
            bind: '{current.user.MessagePreference}',
            get: function (data) {
                return data && (data == 1 || data == 3);
            },
            set: function (data) {
                var phone = this.get('phoneMessagePreference')
                var val = phone && data ? 3 : data ? 1 : phone ? 2 : null;
                console.log('emailMessagePreference',val)
                this.set('current.user.MessagePreference', val);
            }
        },
        phoneMessagePreference: {
            bind: '{current.user.MessagePreference}',
            get: function (data) {
                return data && (data == 2 || data == 3);
            },
            set: function (data) {
                var email = this.get('emailMessagePreference');
                var val = email && data ? 3 : data ? 2 : email ? 1 : null;
                console.log('phoneMessagePreference',val)
                this.set('current.user.MessagePreference', val);
            }
        },

    },
    stores: {
        userStore: {
            model: 'QuickStart.model.User',
            autoLoad: true,
            pageSize: 15,
            remoteFilter: true,
            remoteSort: true,
            filters: [{ property: 'Name', value: '' }, { property: 'IsActive', value: 1 }],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'user/GetUsers',
                    create: 'user/CreateUser',
                    update: 'user/UpdateUser',
                    destroy: 'user/DeactivateUser'
                },
                writer: {
                    type: 'json',
                    writeAllFields: true,
                    // allowSingle: true,
                    // rootProperty: 'data'
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            },
            listeners: {
                load: 'onUserStoreLoad'
            }
        },
        userRolesStore: {

            model: 'QuickStart.model.BaseLookup',
            autoLoad: true,
            pageSize: 100,
            remoteFilter: true,
           // remoteSort: true,
            filters: [{property: 'Name', value: ''}],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'user/GetUserRoles'
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },
        userPermissionsStore: {
            model: 'QuickStart.model.BaseLookup',
            autoLoad: true,
            pageSize: 100,
            remoteFilter: true,
          //  remoteSort: true,
            filters: [{property: 'Name', value: ''}],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'user/GetUserPermissions'
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },
        userNoneRolesStore: {
            model: 'QuickStart.model.BaseLookup',
            autoLoad: false,
            pageSize: 100,
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'user/GetUserNoneRoles'
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },
        userNonePermissionsStore: {
            model: 'QuickStart.model.BaseLookup',
            autoLoad: false,
            pageSize: 100,
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'user/GetUserNonePermissions'
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },

        roleStore: {

            model: 'QuickStart.model.BaseLookup',
            autoLoad: true,
            pageSize: 100,
            remoteFilter: true,
            remoteSort: true,
            filters: [{property: 'Name', value: ''}],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'user/GetRoles'
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            },
            listeners: {
                load: 'onRoleStoreLoad'
            }
        },
        rolePermissionsStore: {
            model: 'QuickStart.model.BaseLookup',
            autoLoad: true,
            pageSize: 100,
            remoteFilter: true,
            //  remoteSort: true,
            filters: [{property: 'Name', value: ''}],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'user/GetRolePermissionsEx'
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },

        permissionStore: {
            model: 'QuickStart.model.BaseLookup',
            autoLoad: true,
            pageSize: 100,
            remoteFilter: true,
            remoteSort: true,
            filters: [{property: 'Name', value: ''}],
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'user/GetPermissions'
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },
        permissionsStore: {
            type: 'chained',
            source: '{permissionStore}'
        },
        rolesStore: {
            type: 'chained',
            source: '{roleStore}'
        },
        phoneServiceProvidersStore: {
            model: 'QuickStart.model.BaseLookup',
            autoLoad: true,
            pageSize: 100,
            proxy: {
                url: QuickStart.util.Global.getApi(),
                type: 'ajax',
                paramsAsJson: true,
                pageParam: null,
                api: {
                    read: 'lookup/MobileCarrierGateway'
                },
                reader: {
                    type: 'json',
                    rootProperty: 'data',
                    totalProperty: 'total'
                }
            }
        },

    }
});