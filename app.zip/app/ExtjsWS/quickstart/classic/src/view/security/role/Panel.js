/**
 * Created by kkora on 3/13/2018.
 */
Ext.define('QuickStart.view.security.role.Panel', {
    extend: 'Ext.panel.Panel',

    xtype: 'rolepanel',
    cls: 'casereview-container',
    layout: 'hbox',
    defaults: {
        border:true
    },
    title:'Roles',
    dockedItems: [
        {
            xtype: 'toolbar',
            items: ['->',{
                bind: {
                    disabled: '{!roleList.selection}'
                },
                text: 'Save',
                ui: 'soft-green',
                iconCls: 'x-fa fa-save light',
                handler: 'onSaveRolePermissions'
            }
            ]
        }
    ],
    items: [
        {
            flex: 1,
            margin: '0 10 0 0',
            height: '100%',
            itemId: 'roleList',
            reference: 'roleList',
            xtype: 'rolelist'
        },
        {

            flex: 1,
            height: '100%',
            itemId: 'rolePermissions',
            xtype: 'rolepermissions'
        }
    ]
});