/**
 * Created by kkora on 3/13/2018.
 */
Ext.define('QuickStart.view.security.SecurityController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.security',

    requires: [
        'QuickStart.model.User',
        'Ext.window.*'
    ],
    onSearchUser: function (field) {
        var me = this,
            toolbar = field.up(),
            showInActiveCheck = toolbar.down('#showInActiveCheck'),
            showCombo = toolbar.down('#show'),
            searchTextField = toolbar.down('#searchText'),
            searchText = searchTextField.getValue(),

            vm = me.getViewModel(),
            store = vm.getStore('userStore'),
            filters = [];
        store.clearFilter();

        //filters.push({property: 'IsActive', value: showInActiveCheck.getValue()});
        filters.push({property: 'IsActive', value: showCombo.getValue()});
        filters.push({property: 'Name', value: searchTextField.getValue()});
        store.setFilters(filters);
    },
    onAddUser: function (grid, btn) {

        var me = this,
            win = me.getView().down('#userWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = Ext.create('QuickStart.model.User');

        win.show(btn);
        form.reset();
        form.isValid();
        vm.set('current.user', record);
        vm.set('current.userAction', 'Add');
        vm.getStore('userStore').insert(0, record);
    },
    onSaveUser: function (btn) {
        var me = this,
            win = btn.up('window'),
            form = win.down('form').getForm(),
            values = form.getValues(),
            vm = me.getViewModel(),
            record = vm.get('current.user'),
            data = record.getData(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: win}),
            action = data.UserID > 0 ? 'user/updateUser' : 'user/createUser',
            isNew = vm.get('current.userAction') === 'Add'

        ;

        myMask.show();
        Ext.Ajax.request({
            url: QuickStart.util.Global.getApi() + action,
            method: 'POST',
            params: {userID: QuickStart.util.Global.getUser().id},
            jsonData: data,
            success: function (response, opts) {
                myMask.hide();
                var result = Ext.decode(response.responseText);
                if (result !== null) {
                    if (!Ext.isEmpty(result.data)) {
                        if (result.success) {
                            QuickStart.util.Global.showMessage(result.message);

                            if (isNew) {
                                record.set('UserID', result.data.UserID);
                                me.lookupReference('userList').getSelectionModel().select(0);
                            }
                            record.commit();
                            win.close();
                        }
                        else {
                            QuickStart.util.Global.showErrors(result.message);

                        }
                    }
                }
            },
            failure: function (response, opts) {
                myMask.hide();
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });

    },
    onEditUser: function (btn) {
        //  console.log(arguments)
        var me = this,
            win = me.getView().down('#userWindow'),
            vm = me.getViewModel(),
            form = win.down('form').getForm(),
            record = vm.get('current.user');

        // form.reset();
        win.show(btn);
        form.isValid();

        vm.set('current.userAction', 'Edit');
    },
    onDeleteUser: function (grid, rowIndex, colIndex, cell, e, rec, row) {
        // grid.getStore().remove(rec);

    },
    onActivateUser: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            record = vm.get('current.user'),
            data = record.getData(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: me.getView()}),
            action = 'user/ActiveDeactiveUser'
        ;
        // console.log(data)
        Ext.Msg.show({
            title: data.IsActive ? 'Deactivate User?' : 'Activate User?',
            message: "Are you sure do you want to " + (data.IsActive ? 'deactivate' : 'activate') + " user '<b>" + record.get('Name') + "</b>' ?",
            buttons: Ext.Msg.YESNO,
            icon: Ext.Msg.QUESTION,
            fn: function (btn) {
                if (btn === 'yes') {
                    myMask.show();
                    data.IsActive = !data.IsActive;
                    Ext.Ajax.request({
                        url: QuickStart.util.Global.getApi() + action,
                        method: 'POST',
                        params: {
                            userID: QuickStart.util.Global.getUser().id
                        },
                        jsonData: data,
                        success: function (response, opts) {
                            myMask.hide();
                            var result = Ext.decode(response.responseText);
                            if (result != null) {
                                if (!Ext.isEmpty(result.data)) {
                                    QuickStart.util.Global.showMessage(result.message);
                                    record.set('IsActive', result.data.IsActive);
                                    record.commit();

                                    //grid.getStore().remove(rec);
                                }
                            }
                        },
                        failure: function (response, opts) {
                            myMask.hide();
                            Ext.Msg.alert('Status', "failure");
                            console.log('server-side failure with status code ' + response.status);
                        },
                        scope: this
                    });
                }
            }
        }, this);
    },

    onUserStoreLoad: function (store) {

        if (store.getCount() > 0) {
            this.lookupReference('userList').getSelectionModel().select(0);
        }
    },
    onUserSelection: function (sm, selected) {
        ///  console.log(arguments)

        var me = this,
            view = me.getView(),
            userRolesGrid = view.down('#userRoles'),
            btnActivate=view.down('#activate'),
            btnDeactivate=view.down('#deactivate'),
            userPermissionsGrid = view.down('#userPermissions'),
            vm = me.getViewModel(),
            record = selected[0],
            data = record ? record.getData() : {}

        ;
        btnActivate.setDisabled(record && record.get('IsActive'));
        btnDeactivate.setDisabled(record && !record.get('IsActive'));
        if (record) {
            vm.set('current.user', record);
            me.rolesFilterByUser(data.UserID);
            me.permissionsFilterByUser(data.UserID);

            userRolesGrid.setTitle(data.FirstName + '\'s Roles');
            userPermissionsGrid.setTitle(data.FirstName + '\'s Permissions');

        }
    },
    rolesFilterByUser: function (userId) {
        var me = this,
            vm = me.getViewModel(),
            store = vm.getStore('userRolesStore'),
            filters = [];
        ;
        store.clearFilter();
        filters.push({property: 'Id', value: userId});
        store.setFilters(filters);

    },
    permissionsFilterByUser: function (userId) {
        var me = this,
            vm = me.getViewModel(),
            store = vm.getStore('userPermissionsStore')
        ;
        store.clearFilter();
        store.setFilters([{property: 'Id', value: userId}]);

    },
    onAddUserRoles: function (btn) {
        var me = this,
            window = me.getView().down('#addUserRolesWindow'),
            nameCombo = window.down('#Name'),
            vm = me.getViewModel(),
            store = vm.getStore('userNoneRolesStore'),
            record = vm.get('current.user'),
            data = record.getData() || {}
        ;
        store.reload({params: {userId: data.UserID}});
        nameCombo.clearValue();
        window.show(btn);

    },
    onSaveUserRoles: function (btn) {

        var me = this,
            window = btn.up('window'),
            values = window.down('#Name').getValue(),
            vm = me.getViewModel(),
            record = vm.get('current.user'),
            data = record.getData(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: window}),
            action = 'user/UpdateUserRolesEx'
        ;

        data = {
            UserID: data.UserID,
            Roles: values || []
        };
        myMask.show();
        Ext.Ajax.request({
            url: QuickStart.util.Global.getApi() + action,
            method: 'POST',
            params: {userID: QuickStart.util.Global.getUser().id},
            jsonData: data,
            success: function (response, opts) {
                myMask.hide();
                var result = Ext.decode(response.responseText);
                if (result != null) {
                    if (!Ext.isEmpty(result.data)) {
                        QuickStart.util.Global.showMessage(result.message);
                        me.rolesFilterByUser(data.UserID);
                        me.permissionsFilterByUser(data.UserID);
                        window.close();
                    }
                }
            },
            failure: function (response, opts) {
                myMask.hide();
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });

    },

    onAddUserPermissions: function (btn) {
        var me = this,
            window = me.getView().down('#addUserPermissionsWindow'),
            nameCombo = window.down('#Name'),
            vm = me.getViewModel(),
            store = vm.getStore('userNonePermissionsStore'),
            record = vm.get('current.user'),
            data = record.getData() || {}
        ;
        store.reload({params: {userId: data.UserID}});
        nameCombo.clearValue();
        window.show(btn);

    },
    onSaveUserPermissions: function (btn) {

        var me = this,
            window = btn.up('window'),
            values = window.down('#Name').getValue(),
            vm = me.getViewModel(),
            record = vm.get('current.user'),
            data = record.getData(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: window}),
            action = 'user/UpdateUserPermissionsEx'
        ;

        data = {
            UserID: data.UserID,
            Permissions: values || []
        };
        myMask.show();
        console.log(data)
        Ext.Ajax.request({
            url: QuickStart.util.Global.getApi() + action,
            method: 'POST',
            params: {userID: QuickStart.util.Global.getUser().id},
            jsonData: data,
            success: function (response, opts) {
                myMask.hide();
                var result = Ext.decode(response.responseText);
                if (result != null) {
                    if (!Ext.isEmpty(result.data)) {
                        QuickStart.util.Global.showMessage(result.message);
                        me.permissionsFilterByUser(data.UserID);
                        window.close();
                    }
                }
            },
            failure: function (response, opts) {
                myMask.hide();
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });
    },
    onDeleteUserPermission: function (grid, rowIndex, colIndex, cell, e, rec, row) {
        var me = this,
            vm = me.getViewModel(),
            record = vm.get('current.user'),
            data = record.getData(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: grid}),
            action = 'user/DeleteUserPermissions';

        data = {
            UserID: data.UserID,
            Permissions: [rec.get('Id')]
        };
        console.log(data)
        Ext.Msg.show({
            title: 'Delete?',
            message: "Are you sure do you want to delete?",
            buttons: Ext.Msg.YESNO,
            icon: Ext.Msg.QUESTION,
            fn: function (btn) {
                if (btn === 'yes') {
                    myMask.show();
                    Ext.Ajax.request({
                        url: QuickStart.util.Global.getApi() + action,
                        method: 'POST',
                        jsonData: data,
                        success: function (response, opts) {
                            myMask.hide();
                            var result = Ext.decode(response.responseText);
                            if (result != null) {
                                if (!Ext.isEmpty(result.data)) {
                                    QuickStart.util.Global.showMessage(result.message);
                                    me.permissionsFilterByUser(data.UserID);
                                }
                            }
                        },
                        failure: function (response, opts) {
                            myMask.hide();
                            Ext.Msg.alert('Status', "failure");
                            console.log('server-side failure with status code ' + response.status);
                        },
                        scope: this
                    });
                }
            }
        });
    },
    onDeleteUserRole: function (grid, rowIndex, colIndex, cell, e, rec, row) {
        var me = this,
            vm = me.getViewModel(),
            record = vm.get('current.user'),
            data = record.getData(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: grid}),
            action = 'user/DeleteUserRoles';
        data = {
            UserID: data.UserID,
            Roles: [rec.get('Id')]
        };
        console.log(data)

        Ext.Msg.show({
            title: 'Delete?',
            message: "Are you sure do you want to delete?",
            buttons: Ext.Msg.YESNO,
            icon: Ext.Msg.QUESTION,
            fn: function (btn) {
                if (btn === 'yes') {
                    myMask.show();
                    Ext.Ajax.request({
                        url: QuickStart.util.Global.getApi() + action,
                        method: 'POST',
                        jsonData: data,
                        success: function (response, opts) {
                            myMask.hide();
                            var result = Ext.decode(response.responseText);
                            if (result != null) {
                                if (!Ext.isEmpty(result.data)) {
                                    QuickStart.util.Global.showMessage(result.message);
                                    me.rolesFilterByUser(data.UserID);
                                    me.permissionsFilterByUser(data.UserID);
                                }
                            }
                        },
                        failure: function (response, opts) {
                            myMask.hide();
                            Ext.Msg.alert('Status', "failure");
                            console.log('server-side failure with status code ' + response.status);
                        },
                        scope: this
                    });
                }
            }
        });
    },

    onRoleStoreLoad: function (store) {

        if (store.getCount() > 0) {
            this.lookupReference('roleList').getSelectionModel().select(0);
        }
    },
    onRoleSelection: function (sm, selected) {
        ///  console.log(arguments)

        var me = this,
            vm = me.getViewModel(),
            view = me.getView(),
            rolePermissionsGrid = view.down('#rolePermissions'),
            rolePermissionsStore = vm.getStore('rolePermissionsStore'),
            filters = [],
            record = selected[0],
            data = record ? record.getData() : {}
        ;
        rolePermissionsGrid.setTitle('Permissions');

        if (record) {
            vm.set('current.role', record);
            filters.push({property: 'Id', value: data.Id});
            rolePermissionsStore.clearFilter();
            rolePermissionsStore.setFilters(filters);
            rolePermissionsGrid.setTitle(data.Name + '\'s Permissions');

        }
    },
    onSaveRolePermissions: function (btn) {
        var me = this,
            view = me.getView(),
            vm = me.getViewModel(),
            record = vm.get('current.role'),
            store = vm.getStore('rolePermissionsStore'),
            modifiedRecords = store.getModifiedRecords(),
            data = record.getData(),
            myMask = new Ext.LoadMask({msg: 'Please wait...', target: me.getView()}),
            values = [],
            action = 'user/UpdateRolePermissionsEx'
        ;
        if (modifiedRecords.length > 0) {
            values = Ext.Array.pluck(modifiedRecords, 'data');
        }

        record.set('Permissions', values);
        data = record.getData();
        data.RoleId = data.Id;
        myMask.show();
        Ext.Ajax.request({
            url: QuickStart.util.Global.getApi() + action,
            method: 'POST',
            params: {userID: QuickStart.util.Global.getUser().id},
            jsonData: data,
            success: function (response, opts) {
                myMask.hide();
                var result = Ext.decode(response.responseText);
                if (result != null) {
                    if (!Ext.isEmpty(result.data)) {
                        QuickStart.util.Global.showMessage(result.message);
                        store.clearFilter();
                        store.setFilters([{property: 'Id', value: data.RoleId}]);

                    }
                }
            },
            failure: function (response, opts) {
                myMask.hide();
                Ext.Msg.alert('Status', "failure");
                console.log('server-side failure with status code ' + response.status);
            },
            scope: this
        });


    },
    onUserRecordCancel: function (owner) {
        var me = this,
            vm = me.getViewModel(),
            store = vm.getStore('userStore');
        if (store && store.rejectChanges)
            store.rejectChanges();
        if (owner.isWindow)
            owner.hide();
        else
            owner.up('window').close();

    },
    onRolePermissionRecordCancel: function (owner) {
        var me = this,
            vm = me.getViewModel(),
            store = vm.getStore('roleStore');
        if (store && store.rejectChanges)
            store.rejectChanges();
        if (owner.isWindow)
            owner.hide();
        else
            owner.up('window').close();
    }

});