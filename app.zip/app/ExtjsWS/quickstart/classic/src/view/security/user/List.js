/**
 * Created by kkora on 9/19/2017.
 */

Ext.define('QuickStart.view.security.user.List', {
    extend: 'Ext.grid.Panel',

    xtype: 'userlist',

    requires: [
        'Ext.button.Button',
        'Ext.grid.column.Action',
        'Ext.grid.column.Widget'
    ],

    cls: 'user-grid dcf-grid',
    scrollable: true,
    headerBorders: false,
    enableColumnResize: false,
    enableColumnMove: false,
    bind: '{userStore}',
    selModel: {selType: 'rowmodel'},
    columns: [
        {
            hidden: true,
            menuDisabled: true,
            width: 40,
            dataIndex: 'UserId',
            text: '#'
        },
        {
            menuDisabled: true,
            sortable: false,
            renderer: function (value, meta, rec) {
                if (value) {
                     var path = 'user/GetPicture?id=' + rec.get('LoginID') + '.png';
                    //console.log(path)
                    return "<img src='" + path + "' alt='Profile Pic' height='30px' width='30px'>";
                }
                return Ext.String.format("<div class='avatar-circle-grid'> <span class='initials'>{0}</span></div>", QuickStart.util.Global.string.initial(rec.data.Name));
            },
            width: 40,
            dataIndex: 'Avatar'
        },
        {
            cls: 'content-column boldFont',
            dataIndex: 'Name',
            menuDisabled: true,
            text: 'Name',
            flex: 1
        },
        {
            cls: 'content-column boldFont',
            dataIndex: 'LoginID',
            menuDisabled: true,
            text: 'Login ID',
            flex: 1
        },
        {
            cls: 'content-column boldFont',
            dataIndex: 'Email',
            menuDisabled: true,
            text: 'Email',
            flex: 1
        },
        {
            xtype: 'actioncolumn',
            dataIndex: 'IsActive',
            items: [
                {
                    getClass: function (v, meta, record) {

                        if (!record.get('IsActive')) {
                           // this.items[0].tooltip = 'Inactive User';
                            return 'x-fa fa-ban';
                        }
                        else {
                           // this.items[0].tooltip = 'Active User';
                            return 'x-fa fa-check-circle';
                        }
                    },
                    isActionDisabled:function () {
                        return false;
                    }
                }
            ],
            menuDisabled: true,
            width: 70,
            sortable: true,
            align:'center',
            cls: 'content-column boldFont',
            text: 'Status'
        }
    ],
    listeners: {
        selectionchange: 'onUserSelection'
    }
});