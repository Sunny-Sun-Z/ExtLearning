/**
 * Created by kkora on 9/19/2017.
 */
Ext.define('QuickStart.view.security.user.Permissions', {
    extend: 'Ext.grid.Panel',
    cls: 'user-grid dcf-grid',

    xtype: 'userpermissions',

    requires: [
        'Ext.grid.column.Action',
        'Ext.grid.column.RowNumberer'
    ],
    title:'Permissions',

    scrollable: true,
    hideHeaders:true,
    headerBorders: false,
    enableColumnResize: false,
    enableColumnMove: false,
    bind: '{userPermissionsStore}',
    viewConfig: {
        emptyText: '<span style="text-align: center;font-weight: bold" >No Record Found</span>'
    },
    columns: [
        {
            cls: 'content-column boldFont',
            dataIndex: 'Name',
            text: 'User Permissions',
            menuDisabled: true,
            flex: 1,
            renderer: function (v, meta, record) {

                return !record.get('InRole') ? '<strong>' + v + '</strong>' : v;
            }
        },
        {
            xtype: 'actioncolumn',
            items: [
                {
                    iconCls: 'x-fa fa-close',
                    tooltip: 'Remove user permissions',
                    handler: 'onDeleteUserPermission',
                    getClass: function (v, meta, record) {

                        if (!record.get('InRole')) {
                            return 'x-fa fa-close';
                        }
                        else {
                            return 'x-fa ';
                        }
                    },
                    isActionDisabled: function (action, rowIndex, colIndex, e, rec) {
                        return rec.get('InRole');
                    }
                }
            ],
            width: 40,
            menuDisabled: true,
            sortable: false,
            align: 'center',
            dataIndex: 'bool',
            tooltip: 'Delete'
        }
    ]
});