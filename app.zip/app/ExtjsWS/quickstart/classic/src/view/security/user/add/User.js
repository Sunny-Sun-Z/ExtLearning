/**
 * Created by kkora on 9/19/2017.
 */

Ext.define('QuickStart.view.security.user.add.User', {
    extend: 'QuickStart.view.common.BaseWindow',

    xtype: 'adduserwindow',

    requires: [
        'Ext.form.field.Checkbox'
    ],

    width: 500,
    layout: 'fit',
    defaults: {
        defaultFocus: 'textfield:not([value]):focusable:not([disabled])',
        defaultButton: 'userSaveButton'
    },
    bind: {
        title: '{current.userAction} User: {current.user.FirstName} {current.user.LastName}'
    },
    maximized: false,
    constrain: false,
    items: [
        {
            bodyPadding: '10 10 0 10',
            xtype: 'form',
            defaultType: 'textfield',
            defaults: {
                submitEmptyText: false,
                anchor: '100%',
               // labelWidth: 75,
                fieldLabel: ' ',
                msgTarget: 'side',
                allowBlank: false

            },
            items: [
                {
                    blankText: 'Please specify the First Name',
                    fieldLabel: 'First Name',
                    maxLength: 100,
                    enforceMaxLength: true,
                    bind: '{current.user.FirstName}',
                    name: 'FirstName'
                },
                {
                    blankText: 'Please specify the Last Name',
                    fieldLabel: 'Last Name',
                    bind: '{current.user.LastName}',
                    name: 'LastName'
                },
                {
                    blankText: 'Please specify the Login ID',
                    fieldLabel: 'Login ID',
                    bind: '{current.user.LoginID}',
                    name: 'LoginID'
                },
                {
                    blankText: 'Please specify the Email',
                    fieldLabel: 'Email',
                    vtype: 'email',
                    bind: '{current.user.Email}',
                    name: 'Email'
                },
                {
                    labelSeparator: '',
                    bind: {value: '{current.user.IsActive}'},
                    xtype: 'checkbox',
                    boxLabel: 'Active',
                    name: 'IsActive',
                    inputValue: 1,
                    uncheckedValue: 2
                },
                {
                    xtype: 'tagfield',
                    fieldLabel: 'Roles',
                    bind: {
                        hidden: '{current.userAction=="Edit"}',
                        value: '{current.user.Roles}',
                        store: '{rolesStore}'
                    },
                    displayField: 'Name',
                    valueField: 'Id',
                    forceSelection: true,
                    filterPickList: true,
                    growMax: 300,
                    name: 'Roles',
                    queryMode: 'local',
                    allowBlank: true
                },
                {
                    xtype: 'tagfield',
                    fieldLabel: 'Permissions',
                    bind: {
                        hidden: '{current.userAction=="Edit"}',
                        value: '{current.user.Permissions}',
                        store: '{permissionsStore}'
                    },
                    displayField: 'Name',
                    valueField: 'Id',
                    forceSelection: true,
                    filterPickList: true,
                    growMax: 300,
                    name: 'Permissions',
                    queryMode: 'local',
                    allowBlank: true
                },
                {
                    xtype: 'combobox',
                    fieldLabel: 'Mobile Service Provider',
                    bind: {
                        value: '{current.user.PhoneServiceProvider}',
                        store: '{phoneServiceProvidersStore}'
                    },
                    displayField: 'Name',
                    valueField: 'Id',
                    forceSelection: true,
                    name: 'PhoneServiceProvider',
                    queryMode: 'local',
                    allowBlank: true
                },
                {
                    fieldLabel: 'Mobile',
                    bind: '{current.user.Phone}',
                    name: 'Phone',
                    allowBlank: true
                },
                {
                    xtype:'fieldcontainer',
                    layout:'hbox',
                    fieldLabel: 'Notify Option',
                    items:[{
                        labelSeparator: '',
                        bind: {value: '{emailMessagePreference}'},
                        xtype: 'checkbox',
                        boxLabel: 'Email',
                        inputValue: 1,
                        margin:'0 20 0 0',
                        uncheckedValue: 2
                    },{
                        labelSeparator: '',
                        bind: {value: '{phoneMessagePreference}'},
                        xtype: 'checkbox',
                        boxLabel: 'Phone',
                        inputValue: 1,
                        uncheckedValue: 2
                    }]
                }
            ],
            dockedItems: [
                {
                    xtype: 'toolbar',
                    dock: 'bottom',
                    ui: 'footer',
                    items: ['->', {
                        text: 'Save',
                        ui: 'soft-green',
                        iconCls: 'x-fa fa-save',
                        reference: 'userSaveButton',
                        formBind: true,
                        handler: 'onSaveUser'

                    }, {
                        text: 'Cancel',
                        ui: 'gray',
                        iconCls: 'x-fa fa-close',
                        handler: 'onUserRecordCancel'
                    }]
                }]

        }
    ],
    listeners: {
        close: 'onUserRecordCancel'
    }
});