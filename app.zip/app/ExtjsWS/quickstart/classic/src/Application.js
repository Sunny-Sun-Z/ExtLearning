/**
 * Created by kkora on 9/8/2017.
 */

Ext.define('QuickStart.Application', {
    extend: 'Ext.app.Application',
    requires: [
        'QuickStart.*'
    ],
    name: 'QuickStart',

    stores: [
        'NavigationTree', 'AdminNavigationTree', 'Lookups', 'CaseReasonLookups', 'CaseReviewReviewerLookups', 'Sites'
    ],

    defaultToken: 'dashboard',

    // The name of the initial view to create. This class will gain a "viewport" plugin
    // if it does not extend Ext.Viewport.
    //

    mainView: 'QuickStart.view.main.Main',
    launch: function () {
        Ext.state.Manager.setProvider(new Ext.state.CookieProvider());

        //   Ext.Ajax.useDefaultXhrHeader = false;
        //   Ext.Ajax.cors = true;
        Ext.ariaWarn = Ext.emptyFn;
        // Ext.Ajax.setDefaultHeaders({
        //     'Content-Type': 'application/json'
        // });
        // console.log(window.location);
        var app = QuickStart.app,
            //url = QuickStart.util.Global.getApi() + 'session/getSession';
            url = 'session/getSession';
        QuickStart.util.Global.setApi(window.location.origin + '/');
        QuickStart.util.Global.setResources('app/ExtJsWs/build/testing/QuickStart/resources');

        if (window.location.href.toLowerCase().indexOf('orionagent') > 0) {
            app.test = true;
            QuickStart.util.Global.setTest(true);
            url = '~api/testdata/session';
        }

        Ext.Ajax.request({
            url: url,
            scope: this,
            failure: function () {
                console.log('failure');
                this.onUser();
            },
            success: function (response) {
                console.log('success');

                var result = Ext.decode(response.responseText);
                if (result && result.success) {
                    var session = result.session;
                    QuickStart.util.Global.setUser(session.user);
                    QuickStart.util.Global.setDebug(session.debug);
                    QuickStart.util.Global.setAssemblyVersion(session.assemblyVersion);
                    QuickStart.util.Global.setSessionInfo(session.sessionInfo);
                    QuickStart.util.Global.setDelayed(session.delayed);
                    QuickStart.util.Global.setImportPath(session.importPath);
                    QuickStart.util.Global.setExportPath(session.exportPath);
                    QuickStart.util.Global.setCaseExportUrl(session.caseExportUrl);
                    QuickStart.util.Global.setReportInBrowsers(session.reportInBrowsers);
                    QuickStart.util.Global.setAutoSave(session.autoSave);
                    if (Ext.isEmpty(session.delayed)) {
                        QuickStart.util.Global.setDelayed(10000);
                    }

                    if (!Ext.isEmpty(session.resources)) {
                        QuickStart.util.Global.setResources(session.resources);
                    }
                    app.user = session.user;
                    console.log(result);
                    if (this.hasInitialQaRole(session.user))
                        QuickStart.util.ServiceProvider.eliminationNotify.execute(session.user.id);
                }

                this.onUser(app.user);
            }
        });


        //   QuickStart.util.Global.setUser({id: 153, name: 'Kanchan Kora'});
        Ext.getStore('Lookups').reload();

    },
    onUser: function (user) {
        this.appready = true;
        this.fireEvent('appready', this, user);
    },
    onAppUpdate: function () {
        Ext.Msg.confirm('Application Update', 'This application has an update, reload?',
            function (choice) {
                if (choice === 'yes') {
                    window.location.reload();
                }
            }
        );
    },
    hasInitialQaRole: function (user) {
        var val = false;

        if (user && user.roles && user.roles.length > 0) {
            return user.roles.filter(function (value) {
                return value == 15;
            }).length > 0;
        }

        return val;
    }
});
