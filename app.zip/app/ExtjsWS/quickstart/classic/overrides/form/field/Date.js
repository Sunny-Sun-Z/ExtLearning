/**
 * Created by Kanchan on 6/9/2018.
 */
Ext.define('QuickStart.overrides.form.field.Date', {
    override:'Ext.form.field.Date',
	format:'m/d/Y',
	formatText:"Expected date format 'MM/DD/YYYY'",
	invalidText :"{0} is not a valid date - it must be in the format 'MM/DD/YYYY'",
	formatter: 'date("m/d/Y")'

});