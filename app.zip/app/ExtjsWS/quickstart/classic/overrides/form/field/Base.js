/**
 * Created by Kanchan on 8/9/2016.
 */
Ext.define('QuickStart.overrides.form.field.Base', {
    override:'Ext.form.field.Base',
    publishValue:function(){
        var me=this;
        if(me.rendered /*me.getErrors().length*/){
            me.publishState('value',me.getValue());
        }
    }
});