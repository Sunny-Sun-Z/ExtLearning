
/*
 * This file is responsible for launching the application. Application logic should be
 * placed in the QuickStart.Application class.
 */
Ext.application({
    extend: 'QuickStart.Application',

    name: 'QuickStart',

    requires: [
        // This will automatically load all classes in the QuickStart namespace
        // so that application classes do not need to require each other.
        'QuickStart.*'
    ]
});

