/**
 * Created by kkora on 12/21/2017.
 */
Ext.define('QuickStart.model.Smtp', {
    extend: 'Ext.data.Model',
    idProperty: 'Id',
    fields: [

        {name: 'Id', type: 'int'},
        {name: 'Server', type: 'string'},
        {name: 'UserName', type: 'string'},
        {name: 'Password', type: 'string'},
        {name: 'Port', type: 'int', allowNull: true},
        {name: 'EnableSsl', type: 'boolean'},
        {name: 'SenderName', type: 'string'},
        {name: 'SenderEmail', type: 'string'}
    ]
});