/**
 * Created by kkora on 9/19/2017.
 */
Ext.define('QuickStart.model.User', {
    extend: 'QuickStart.model.Base',
    idProperty: 'UserID',
    entityName: 'User',
    fields: [
        {
            type: 'int',
            name: 'UserID'
        },
        {
            type: 'string',
            name: 'FirstName'
        },
        {
            type: 'string',
            name: 'LastName'
        },
        {
            type: 'string',
            name: 'Name',
            calculate: function (data) {
                return data.FirstName + ' ' + data.LastName;
            }
        },
        {
            type: 'string',
            name: 'Email'
        },
        {
            type: 'string',
            name: 'LoginID'
        },
        {
            type: 'boolean',
            name: 'IsActive',
            defaultValue: true
        },
        {
            type: 'boolean',
            name: 'Avatar',
            defaultValue: false
        },
        {
            type: 'int', allowNull: true, name: 'MessagePreference'
        },
        {
            type: 'int', allowNull: true, name: 'PhoneServiceProvider'
        },
        {
            type: 'string', name: 'Phone'
        },

        'Roles', 'Permissions'
    ]
});