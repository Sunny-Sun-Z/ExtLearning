Ext.define('QuickStart.model.Base', {
    extend: 'Ext.data.Model',

    schema: {
        namespace: 'QuickStart.model'
    }
});
