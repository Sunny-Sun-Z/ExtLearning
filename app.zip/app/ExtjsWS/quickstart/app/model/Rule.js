/**
 * Created by kkora on 12/21/2017.
 */
Ext.define('QuickStart.model.Rule', {
    extend: 'Ext.data.Model',
    idProperty: 'Id',
    fields: [

        {name: 'Id', type: 'int'},
        {name: 'Enabled', type: 'boolean', defaultValue: true},
        {name: 'Created', type: 'date'},
        {name: 'CreatedBy', type: 'int'},
        {name: 'Priority', type: 'int', allowNull: true},
        {name: 'IsRuleSet', type: 'boolean'},
        {name: 'OpenBracket', type: 'boolean'},
        {name: 'CloseBracket', type: 'boolean'},
        {name: 'Predicate', type: 'string'},
        {name: 'Operator', type: 'string'},
        {name: 'TargetValue', type: 'string'},
        {name: 'DataType', type: 'string'},
        {name: 'ErrorMessage', type: 'string'},
        {name: 'RuleSetName', type: 'string'},
        {name: 'PropertyName', type: 'string'},
        {name: 'Category', type: 'string'},
        {name: 'SubCategory', type: 'string'},
        {name: 'Required', type: 'boolean'},
        {name: 'Mode', type: 'string', defaultValue: 'Server'},
        {name: 'StartDate', type: 'date'},
        {name: 'EndDate', type: 'date'},
        {name: 'LogicOperator', type: 'int'}

    ]
});