/**
 * Created by kkora on 10/24/2017.
 */
Ext.define('QuickStart.model.casereview.Goal', {
    extend: 'QuickStart.model.Base',
    fields: [

        { name: 'GoalID',      type: 'int' },
        { name: 'PermanencyID',      type: 'int' },
        { name: 'DateEstablished',     type: 'date' },
        { name: 'GoalCode',      type: 'int' },
        { name: 'DateGoalChanged',    type: 'date' },
        { name: 'TimeInFosterCare',    type: 'string' },
        { name: 'TimeUnitCode',      type: 'int' },
        { name: 'IsCurrentGoal',      type: 'int' , allowNull: true},
        { name: 'ReasonForGoalChange',    type: 'string' },
        {
            name: 'IsCurrentGoalCheck', type: 'boolean',
            calculate: function (data) {
                return data.IsCurrentGoal === 1;
            }
        }



    ]
});