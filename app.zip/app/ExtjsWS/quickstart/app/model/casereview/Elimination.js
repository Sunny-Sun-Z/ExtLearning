/**
 * Created by kkora on 9/8/2017.
 */
Ext.define('QuickStart.model.casereview.Elimination', {
    extend: 'QuickStart.model.Base',

    fields: [
        {name: 'EliminationReasonCode', type: 'int', allowNull: true},
        {name: 'EliminationReasonExplained', type: 'string'},
        {name: 'QaSignOff', type: 'boolean',defaultValue: false}
    ]

});