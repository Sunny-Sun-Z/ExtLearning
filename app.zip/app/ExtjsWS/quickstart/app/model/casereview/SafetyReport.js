/**
 * Created by kkora on 10/11/2017.
 */
Ext.define('QuickStart.model.casereview.SafetyReport', {
    extend: 'QuickStart.model.Base',

    fields: [
        {name: 'ChildDemographicID', type: 'int'},
        {name: 'SafetyReportID', type: 'int'},
        {name: 'SafetyID', type: 'int'},
        {name: 'PriorityLevel', type: 'int'},
        {name: 'PerpetratorChildRelationshipCode', type: 'int'},
        {name: 'IsInitiated', type: 'int'},
        {name: 'IsFaceToFaceContact', type: 'int'},
        {name: 'IsAssigned', type: 'int'},
        {name: 'DispositionCode', type: 'int'},
        {name: 'AssessmentCode', type: 'int'},
        {name: 'DateAssessmentAssigned', type: 'date'},
        {name: 'DateAssessmentInitiated', type: 'date'},
        {name: 'DateFaceToFaceContact', type: 'date'},
        {name: 'ReportDate', type: 'date'},
        {name: 'AllegationOther', type: 'string'},
        {name: 'PerpetratorChildRelationshipOther', type: 'string'},
        {name: 'CR_SafetyReport_Allegation_Collection',defaultValue: []},
       // {name: 'SafetyReportAllegationCode'},
        {
            name: 'SafetyReportAllegationCode',
            calculate: function (data) {
                var arr = data.CR_SafetyReport_Allegation_Collection || [],
                    codes = Ext.Array.pluck(arr, 'SafetyReportAllegationCode');
                return codes;
            }
        },

        {
            name: 'AllegationCodes',
            convert: function (val,rec) {
                var arr = rec.get('CR_SafetyReport_Allegation_Collection')||[],
                    codes = Ext.Array.pluck(arr, 'SafetyReportAllegationCode');
              //  rec.set('SafetyReportAllegationCode',codes);

                return codes;
            }
        },
        {
            name: 'IsAssignedCheck', type: 'boolean',
            calculate: function (data) {
                return data.IsAssigned === 1;
            }
        },
        {
            name: 'IsInitiatedCheck', type: 'boolean',
            calculate: function (data) {
                return data.IsInitiated === 1;
            }
        },
        {
            name: 'IsFaceToFaceContactCheck', type: 'boolean',
            calculate: function (data) {
                return data.IsFaceToFaceContact === 1;
            }
        }

    ]

});