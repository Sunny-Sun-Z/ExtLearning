/**
 * Created by kkora on 9/8/2017.
 */
Ext.define('QuickStart.model.casereview.Note', {
    extend: 'QuickStart.model.Base',

    fields: [
        {name: 'TempID', type: 'int', allowNull: true},
        {name: 'CaseReviewID', type: 'int'},
        {name: 'NoteID', type: 'int', allowNull: true},
        {name: 'ResponseID', type: 'int', allowNull: true},
        {name: 'ItemID', type: 'int', allowNull: true},
        {name: 'ItemCode', type: 'int', allowNull: true},
        {name: 'OutcomeCode', type: 'int', allowNull: true},
        {name: 'Subject', type: 'string', allowNull: true},
        {name: 'Description', type: 'string'},
        {name: 'LastModifiedDate', type: 'date'},
        {name: 'IsResolved', type: 'int', defaultValue: 2},
        {name: 'IsResponse', type: 'boolean', defaultValue: false},
        {name: 'LastModifiedUserID', type: 'int'},
        {name: 'ReviewerType', type: 'string'},
        {name: 'Name', type: 'string'},
        {name: 'Time', type: 'string'},
        {name: 'NoteType', type: 'int', allowNull: true, defaultValue: 1},
        {
            name: 'Type', type: 'string',
            convert: function (val, rec) {
                return !(Ext.isEmpty(rec.get('OutcomeCode')) && Ext.isEmpty(rec.get('ItemCode'))) ? 'ITEM' : 'CASE';
            }
        },
        {
            name: 'ItemName',
            calculate: function (data) {
                if (!(Ext.isEmpty(data.OutcomeCode) && Ext.isEmpty(data.ItemCode))) {
                    switch (data.ItemCode) {
                        case 1 :  return 'Case Note';
                        case 2 :  return 'Item 1';
                        case 3 :  return 'Item 2';
                        case 4 :  return 'Item 3';
                        case 5 :  return 'Item 4';
                        case 6 :  return 'Item 5';
                        case 7 :  return 'Item 6';
                        case 8 :  return 'Item 7';
                        case 9 :  return 'Item 8';
                        case 10 :  return 'Item 9';
                        case 11 :  return 'Item 10';
                        case 12 :  return 'Item 11';
                        case 13 :  return 'Item 12';
                        case 14 :  return 'Item 12A';
                        case 15 :  return 'Item 12B';
                        case 16 :  return 'Item 12C';
                        case 17 :  return 'Item 13';
                        case 18 :  return 'Item 14';
                        case 19 :  return 'Item 15';
                        case 20 :  return 'Item 16';
                        case 21 :  return 'Item 17';
                        case 22 :  return 'Item 18';
                        case 23 :  return 'Facesheet';
                    }
                }
                else {
                    return 'Case Note';
                }

                return null;
            }
        }

    ]
});