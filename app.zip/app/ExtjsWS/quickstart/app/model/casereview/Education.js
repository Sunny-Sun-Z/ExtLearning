/**
 * Created by kkora on 10/24/2017.
 */
Ext.define('QuickStart.model.casereview.Education', {
    extend: 'QuickStart.model.Base',
    fields: [

        {name: 'EducationID', type: 'int'},
        {name: 'WellBeingID', type: 'int'},
        {name: 'Needs', type: 'string'},
        {name: 'ServicesProvided', type: 'string'},
        {name: 'ServicesNeededNotProvided', type: 'string'}

    ]


});