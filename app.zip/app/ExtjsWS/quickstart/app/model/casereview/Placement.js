/**
 * Created by kkora on 10/24/2017.
 */
Ext.define('QuickStart.model.casereview.Placement', {
    extend: 'QuickStart.model.Base',
    fields: [

        { name: 'PlacementID',      type: 'int' },
        { name: 'PermanencyID',      type: 'int' },
        { name: 'Date',     type: 'date' },
        { name: 'TypeCode',      type: 'int' },
        { name: 'ChangeReasonCode',    type: 'int' },
        { name: 'TypeOther',    type: 'string' },
        { name: 'ChangeReasonOther',    type: 'string' }

    ]


});