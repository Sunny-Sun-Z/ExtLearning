/**
 * Created by kkora on 3/15/2018.
 */
Ext.define('QuickStart.model.casereview.Preview', {
    extend: 'QuickStart.model.Base',

    fields: [
        {
            name: 'temp',
            convert: function (val, rec) {

                var fs = rec.get('FaceSheet'),
                    item1 = rec.get('Item1'),
                    item3 = rec.get('Item3'),
                    item4 = rec.get('Item4'),
                    item5 = rec.get('Item5'),
                    item6 = rec.get('Item6'),
                    item8 = rec.get('Item8'),
                    item10 = rec.get('Item10'),
                    item11 = rec.get('Item11'),
                    item12b = rec.get('Item12B'),
                    item17 = rec.get('Item17'),
                    outcomes = rec.get('Outcomes'),
                    str = '',
                    participants=[],
                    quesJ = '', quesK = '', quesL = ''

                ;
                //console.log()
                if (!Ext.isEmpty(fs)) {

                    if (!Ext.isEmpty(fs.FosterEntryDate))
                        quesJ = this.getDate(fs.FosterEntryDate);
                    else if (!Ext.isEmpty(fs.IsFosterEntryDateNA))
                        quesJ = this.isNA(fs.IsFosterEntryDateNA);
                    rec.set('QuestionJ', quesJ);

                    if (!Ext.isEmpty(fs.EpisodeDischargeDate))
                        quesK = this.getDate(fs.EpisodeDischargeDate);
                    else if (fs.IsEpisodeDischargeDateNA == 1)
                        quesK = this.isNA(fs.IsEpisodeDischargeDateNA);
                    else if (fs.IsEpisodeNotYetDischarged == 1)
                        quesK = 'Not Yet Discharged';
                    rec.set('QuestionK', quesK);

                    if (!Ext.isEmpty(fs.CaseClosureDate))
                        quesL = this.getDate(fs.CaseClosureDate);
                    else if (fs.IsCaseClosureNotClosed == 1)
                        quesL = 'Case not closed by time of review';
                    rec.set('QuestionL', quesL);


                }

                if (!Ext.isEmpty(outcomes)) {
                    rec.set('Outcome1RatingCode', this.getOutcomeCode(outcomes, 1));
                    rec.set('Outcome2RatingCode', this.getOutcomeCode(outcomes, 2));
                    rec.set('Outcome3RatingCode', this.getOutcomeCode(outcomes, 3));
                    rec.set('Outcome4RatingCode', this.getOutcomeCode(outcomes, 4));
                    rec.set('Outcome5RatingCode', this.getOutcomeCode(outcomes, 5));
                    rec.set('Outcome6RatingCode', this.getOutcomeCode(outcomes, 6));
                    rec.set('Outcome7RatingCode', this.getOutcomeCode(outcomes, 7));

                }

                if (!Ext.isEmpty(item3)) {
                    rec.set('SafetyRelatedIncident86', this.markX(item3.SafetyRelatedIncidents, 86));
                    rec.set('SafetyRelatedIncident87', this.markX(item3.SafetyRelatedIncidents, 87));
                    rec.set('SafetyRelatedIncident88', this.markX(item3.SafetyRelatedIncidents, 88));
                    rec.set('SafetyRelatedIncident89', this.markX(item3.SafetyRelatedIncidents, 89));
                    rec.set('SafetyRelatedIncident90', this.markX(item3.SafetyRelatedIncidents, 90));
                    rec.set('SafetyRelatedIncident91', this.markX(item3.SafetyRelatedIncidents, 91));

                    rec.set('FosterSafety92', this.markX(item3.FosterSafety, 92));
                    rec.set('FosterSafety93', this.markX(item3.FosterSafety, 93));
                    rec.set('FosterSafety94', this.markX(item3.FosterSafety, 94));
                    rec.set('FosterSafety95', this.markX(item3.FosterSafety, 95));
                    rec.set('FosterSafety96', this.markX(item3.FosterSafety, 96));
                    rec.set('FosterSafety97', this.markX(item3.FosterSafety, 97));

                    rec.set('FosterPlacementConcern98', this.markX(item3.FosterPlacementConcern, 98));
                    rec.set('FosterPlacementConcern99', this.markX(item3.FosterPlacementConcern, 99));
                    rec.set('FosterPlacementConcern100', this.markX(item3.FosterPlacementConcern, 100));
                    rec.set('FosterPlacementConcern101', this.markX(item3.FosterPlacementConcern, 101));
                    rec.set('FosterPlacementConcern102', this.markX(item3.FosterPlacementConcern, 102));
                    rec.set('FosterPlacementConcern103', this.markX(item3.FosterPlacementConcern, 103));
                    rec.set('FosterPlacementConcern104', this.markX(item3.FosterPlacementConcern, 104));


                }

                if (!Ext.isEmpty(item4)) {
                    rec.set('PlacementApplicableCircumstance121', this.markX(item4.PlacementApplicableCircumstances, 121));
                    rec.set('PlacementApplicableCircumstance122', this.markX(item4.PlacementApplicableCircumstances, 122));
                    rec.set('PlacementApplicableCircumstance123', this.markX(item4.PlacementApplicableCircumstances, 123));
                    rec.set('PlacementApplicableCircumstance124', this.markX(item4.PlacementApplicableCircumstances, 124));
                    rec.set('PlacementApplicableCircumstance125', this.markX(item4.PlacementApplicableCircumstances, 125));
                    rec.set('PlacementApplicableCircumstance126', this.markX(item4.PlacementApplicableCircumstances, 126));
                }

                if (!Ext.isEmpty(item5)) {
                    rec.set('TerminationException138', this.markX(item5.TerminationExceptions, 138));
                    rec.set('TerminationException139', this.markX(item5.TerminationExceptions, 139));
                    rec.set('TerminationException140', this.markX(item5.TerminationExceptions, 140));
                    rec.set('TerminationException141', this.markX(item5.TerminationExceptions, 141));
                    rec.set('TerminationException142', this.markX(item5.TerminationExceptions, 142));
                }

                if (!Ext.isEmpty(item6)) {
                    str = '';
                    if (!Ext.isEmpty(item6.DischargeDate))
                        str = this.getDate(item6.DischargeDate);
                    else if (item6.IsDischargeDateNACheck == 1)
                        str = 'NA';
                    rec.set('Question6A3', str);

                    str = '';
                    if (!Ext.isEmpty(item6.OtherPlannedArrangementDocumentationDate))
                        str = this.getDate(item6.OtherPlannedArrangementDocumentationDate);
                    else if (item6.IsOtherPlannedArrangement == 1)
                        str = 'NA';
                    else if (item6.IsOtherPlannedArrangement == 4)
                        str = 'No Date';
                    rec.set('Question6C2', str);
                }

                if (!Ext.isEmpty(item8)) {
                    participants=[];
                    Ext.each(item8.ParticipantMother, function (p) {
                            str=this.findValueInArray(fs.CaseParticipants,p,'CaseParticipantID','Name');
                            if(!Ext.isEmpty(str))
                                participants.push(str);
                    },this);
                    rec.set('Item8ParticipantMother', participants.join('<br/>'));
                    participants=[];
                    Ext.each(item8.ParticipantFather, function (p) {
                        str=this.findValueInArray(fs.CaseParticipants,p,'CaseParticipantID','Name');
                        if(!Ext.isEmpty(str))
                            participants.push(str);
                    },this);
                    rec.set('Item8ParticipantFather', participants.join('<br/>'));

                }

                if (!Ext.isEmpty(item10)) {
                    rec.set('PlacementEffortConcernsMother156', this.markX(item10.PlacementEffortConcernsMother, 156));
                    rec.set('PlacementEffortConcernsMother157', this.markX(item10.PlacementEffortConcernsMother, 157));
                    rec.set('PlacementEffortConcernsMother158', this.markX(item10.PlacementEffortConcernsMother, 158));
                    rec.set('PlacementEffortConcernsMother159', this.markX(item10.PlacementEffortConcernsMother, 159));

                    rec.set('PlacementEffortConcernsFather160', this.markX(item10.PlacementEffortConcernsFather, 160));
                    rec.set('PlacementEffortConcernsFather161', this.markX(item10.PlacementEffortConcernsFather, 161));
                    rec.set('PlacementEffortConcernsFather162', this.markX(item10.PlacementEffortConcernsFather, 162));
                    rec.set('PlacementEffortConcernsFather163', this.markX(item10.PlacementEffortConcernsFather, 163));

                }
                if (!Ext.isEmpty(item11)) {
                    rec.set('EffortsToSupportMotherFosterRelationship164', this.markX(item11.EffortsToSupportMotherFosterRelationship, 164));
                    rec.set('EffortsToSupportMotherFosterRelationship165', this.markX(item11.EffortsToSupportMotherFosterRelationship, 165));
                    rec.set('EffortsToSupportMotherFosterRelationship166', this.markX(item11.EffortsToSupportMotherFosterRelationship, 166));
                    rec.set('EffortsToSupportMotherFosterRelationship167', this.markX(item11.EffortsToSupportMotherFosterRelationship, 167));
                    rec.set('EffortsToSupportMotherFosterRelationship168', this.markX(item11.EffortsToSupportMotherFosterRelationship, 168));
                    rec.set('EffortsToSupportMotherFosterRelationship169', this.markX(item11.EffortsToSupportMotherFosterRelationship, 169));
                    rec.set('EffortsToSupportMotherFosterRelationship170', this.markX(item11.EffortsToSupportMotherFosterRelationship, 170));

                    rec.set('EffortsToSupportFatherFosterRelationship171', this.markX(item11.EffortsToSupportFatherFosterRelationship, 171));
                    rec.set('EffortsToSupportFatherFosterRelationship172', this.markX(item11.EffortsToSupportFatherFosterRelationship, 172));
                    rec.set('EffortsToSupportFatherFosterRelationship173', this.markX(item11.EffortsToSupportFatherFosterRelationship, 173));
                    rec.set('EffortsToSupportFatherFosterRelationship174', this.markX(item11.EffortsToSupportFatherFosterRelationship, 174));
                    rec.set('EffortsToSupportFatherFosterRelationship175', this.markX(item11.EffortsToSupportFatherFosterRelationship, 175));
                    rec.set('EffortsToSupportFatherFosterRelationship176', this.markX(item11.EffortsToSupportFatherFosterRelationship, 176));
                    rec.set('EffortsToSupportFatherFosterRelationship177', this.markX(item11.EffortsToSupportFatherFosterRelationship, 177));

                    participants = [];
                    Ext.each(item11.ParticipantMother, function (p) {
                        str = this.findValueInArray(fs.CaseParticipants, p, 'CaseParticipantID', 'Name');
                        if (!Ext.isEmpty(str))
                            participants.push(str);
                    }, this);
                    rec.set('item11ParticipantMother', participants.join('<br/>'));
                    participants = [];
                    Ext.each(item11.ParticipantFather, function (p) {
                        str = this.findValueInArray(fs.CaseParticipants, p, 'CaseParticipantID', 'Name');
                        if (!Ext.isEmpty(str))
                            participants.push(str);
                    }, this);
                    rec.set('Item11ParticipantFather', participants.join('<br/>'));

                }
                if (!Ext.isEmpty(item12b)) {
                    participants=[];
                    Ext.each(item12b.ParticipantMother, function (p) {
                        str=this.findValueInArray(fs.CaseParticipants,p,'CaseParticipantID','Name');
                        if(!Ext.isEmpty(str))
                            participants.push(str);
                    },this);
                    rec.set('Item12bParticipantMother', participants.join('<br/>'));
                    participants=[];
                    Ext.each(item12b.ParticipantFather, function (p) {
                        str=this.findValueInArray(fs.CaseParticipants,p,'CaseParticipantID','Name');
                        if(!Ext.isEmpty(str))
                            participants.push(str);
                    },this);
                    rec.set('Item12bParticipantFather', participants.join('<br/>'));

                }
                if (!Ext.isEmpty(item17)) {
                    rec.set('FosterFederalCaseManagamentCriteria178', this.markX(item17.FosterFederalCaseManagamentCriteria, 178));
                    rec.set('FosterFederalCaseManagamentCriteria179', this.markX(item17.FosterFederalCaseManagamentCriteria, 179));
                    rec.set('FosterFederalCaseManagamentCriteria180', this.markX(item17.FosterFederalCaseManagamentCriteria, 180));
                    rec.set('FosterFederalCaseManagamentCriteria181', this.markX(item17.FosterFederalCaseManagamentCriteria, 181));
                    rec.set('FosterFederalCaseManagamentCriteria182', this.markX(item17.FosterFederalCaseManagamentCriteria, 182));


                }
            },
            getYesNoNaText: function (val) {
                return val == 1 ? 'Yes' : val == 2 ? 'No' : val == 3 ? 'NA' : '';
            },
            isNA: function (val) {
                return val == 1 ? 'NA' : '';
            },
            getDate: function (date) {
                return Ext.Date.format(new Date(date), 'm/d/Y');
            },
            getOutcomeCode: function (arr, code) {
                if (arr == null || !Ext.isArray(arr))
                    return null;
                var item = arr.filter(function (item) {
                    return item.OutcomeCode == code;
                });
                if (item.length > 0)
                    return item[0].OutcomeRatingCode;
                return null;
            },
            findValueInArray: function (arr, value, prop, returnValue) {
                if (arr == null)
                    return false;
                if (!Ext.isArray(arr))
                    arr = arr[arr];

                var v = arr.filter(function (item) {
                    if (prop)
                        return item[prop] == value;
                    return item == value;
                });
                return v.length > 0 ? v[0][returnValue]: null ;
            },
            hasValueInArray: function (arr, value, prop) {
                if (arr == null)
                    return false;
                if (!Ext.isArray(arr))
                    arr = arr[arr];

                return arr.filter(function (item) {
                    if (prop)
                        return item[prop] == value;
                    return item == value;
                }).length > 0;
            },
            markX: function (arr, value, prop) {

                return this.hasValueInArray(arr, value, prop) ? 'X' : '';
            }
        },

        {name: 'Outcome1RatingCode', type: 'int', allowNull: true},
        {name: 'Outcome2RatingCode', type: 'int', allowNull: true},
        {name: 'Outcome3RatingCode', type: 'int', allowNull: true},
        {name: 'Outcome4RatingCode', type: 'int', allowNull: true},
        {name: 'Outcome5RatingCode', type: 'int', allowNull: true},
        {name: 'Outcome6RatingCode', type: 'int', allowNull: true},
        {name: 'Outcome7RatingCode', type: 'int', allowNull: true},
        {name: 'Outcome8RatingCode', type: 'int', allowNull: true},

        {name: 'QuestionJ', type: 'string'},
        {name: 'QuestionK', type: 'string'},
        {name: 'QuestionL', type: 'string'},
        {name: 'Question6A3', type: 'string'},
        {name: 'Question6A3', type: 'string'}

    ]


});