/**
 * Created by kkora on 9/8/2017.
 */
Ext.define('QuickStart.model.casereview.ChildDemographic', {
    extend: 'QuickStart.model.Base',

    fields: [
        {name: 'ChildDemographicID', type: 'int'},
        {name: 'FaceSheetID', type: 'int'},
        {name: 'IsTargetChild', type: 'int'},
        {
            name: 'IsTargetChildCheck', type: 'boolean',
            calculate: function (data) {
                return data.IsTargetChild=== 1 ;
            }

        },
        {name: 'Name', type: 'string'},
        {name: 'EthnicityCode', type: 'int'},
        {name: 'DateOfBirth', type: 'date'},
        {name: 'GenderCode', type: 'int'},
        {name: 'IsInterviewed', type: 'int'},
        {
            name: 'IsInterviewedCheck', type: 'boolean',
            calculate: function (data) {
                return data.IsInterviewed=== 1 ;
            }
        },
        //{name: 'Race', mapping: 'CR_ChildRace_Collection'},
        {name: 'CR_ChildRace_Collection'},
        {
            name: 'RaceCodes',
            calculate: function (data) {
                var arr = data.CR_ChildRace_Collection || [],
                    codes = Ext.Array.pluck(arr, 'RaceCode');
                return codes;
            }
        },
        {name: 'ChildDemographicPreviousID', type: 'int'},
        {
            name: 'Age', type: 'string'

        },
        {
            name: 'AgeObj'

        }

    ]

    /*
    Uncomment to add validation rules
    validators: {
        age: 'presence',
        name: { type: 'length', min: 2 },
        gender: { type: 'inclusion', list: ['Male', 'Female'] },
        username: [
            { type: 'exclusion', list: ['Admin', 'Operator'] },
            { type: 'format', matcher: /([a-z]+)[0-9]{2,3}/i }
        ]
    }
    */

});