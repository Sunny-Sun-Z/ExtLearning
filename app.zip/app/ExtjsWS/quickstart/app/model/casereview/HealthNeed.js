/**
 * Created by kkora on 10/24/2017.
 */
Ext.define('QuickStart.model.casereview.HealthNeed', {
    extend: 'QuickStart.model.Base',
    fields: [

        {name: 'HealthID', type: 'int'},
        {name: 'WellBeingID', type: 'int'},
        {name: 'HealthNeeds', type: 'string'},
        {name: 'ServicesProvided', type: 'string'},
        {name: 'ServicesNeededNotProvided', type: 'string'},
        {name: 'HealthNeedCode', type: 'int'}

    ]


});