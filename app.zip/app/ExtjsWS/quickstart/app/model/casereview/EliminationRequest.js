/**
 * Created by kkora on 9/8/2017.
 */
Ext.define('QuickStart.model.casereview.EliminationRequest', {
    extend: 'QuickStart.model.Base',

    fields: [
        {name: 'Id', type: 'int'},
        {name: 'CaseReviewId', type: 'int'},
        {name: 'CaseReviewRootId', type: 'int'},
        {name: 'CaseId', type: 'int'},
        {name: 'CaseName', type: 'string'},
        {name: 'TargetChildName', type: 'string'},
        {name: 'CaseType', type: 'string'},
        {name: 'Reviewers', type: 'string'},
        {name: 'QaTeam', type: 'string'},
        {name: 'ScheduledReviewMonth', type: 'string'},
        {name: 'IsCaseMeetEliminationCriteria', type: 'boolean', allowNull: true, defaultValue: true},
        {name: 'CaseMeetEliminationCriteriaReason', type: 'string'},

        {name: 'IsQaTeamForEliminationRequest', type: 'boolean'},
        {name: 'QaTeamForEliminationRequestExplain', type: 'string'},

        {name: 'IsChildAdoptionOrGuardianshipFinalize', type: 'boolean'},
        {name: 'ChildAdoptionOrGuardianshipFinalizeExplain', type: 'string'},
        {name: 'ChildAdoptionOrGuardianshipDateFinalize', type: 'date', dateFormat: 'c'},

        {name: 'IsTargetChildPlacementOfAnotherState', type: 'boolean'},
        {name: 'TargetChildPlacementOfAnotherStateExplain', type: 'string'},

        {name: 'IsTargetChildTurned18', type: 'boolean'},
        {name: 'TargetChildTurned18Date', type: 'date', dateFormat: 'c'},

        {name: 'IsFosterCareCaseClosed', type: 'boolean'},
        {name: 'FosterCareCaseClosedDate', type: 'date', dateFormat: 'c'},

        {name: 'IsChildEntryInFosterCare', type: 'boolean'},
        {name: 'ChildEntryInFosterCareDate', type: 'date', dateFormat: 'c'},

        {name: 'IsHomeServiceCaseOpenDuringPUR', type: 'boolean'},
        {name: 'HomeServiceCaseOpenedDuringPUR', type: 'date', dateFormat: 'c'},
        {name: 'HomeServiceCaseClosedDuringPUR', type: 'date', dateFormat: 'c'},

        {name: 'IsCaseAppearedMultipleTimes', type: 'boolean'},
        {name: 'CaseAppearedMultipleTimesExplain', type: 'string'},

        {name: 'IsIdentifyCpsStaff', type: 'boolean'},
        {name: 'IdentifyCpsStaffExplain', type: 'string'},

        {name: 'IsIdentifyKeyIndividual', type: 'boolean'},
        {name: 'IdentifyKeyIndividualExplain', type: 'string'},

        {name: 'IsIdentifyPhoneCall', type: 'boolean'},
        {name: 'IdentifyCpsStaffExplain', type: 'string'},

        {name: 'IsIdentifyCpsStaff', type: 'boolean'},
        {name: 'IdentifyPhoneCallExplain', type: 'string'},

        {name: 'IsIdentifyLetter', type: 'boolean'},
        {name: 'IdentifyLetterExplain', type: 'string'},
        {name: 'IsCaseOpenForSubsidizedAdoptionOrGuardianship', type: 'boolean'},

        {name: 'RequestedDate', type: 'date', dateFormat: 'c'},
        {name: 'EliminatedDate', type: 'date', dateFormat: 'c'},
        {name: 'ApprovedDate', type: 'date', dateFormat: 'c'},
        {name: 'Created', type: 'date', dateFormat: 'c'},
        {name: 'ApproverName', type: 'string'},
        {name: 'ApproverEmail', type: 'string'},

        {name: 'CreatedBy', type: 'int', allowNull: true}

    ]

});