/**
 * Created by kkora on 9/8/2017.
 */
Ext.define('QuickStart.model.casereview.CaseParticipant', {
    extend: 'QuickStart.model.Base',

    fields: [
        {name: 'CaseParticipantID', type: 'int'},
        {name: 'FaceSheetID', type: 'int'},
        {name: 'Name', type: 'string'},
        {name: 'RoleCode', type: 'int'},
        {name: 'OtherRole', type: 'string'},
        {name: 'RelationshipToChild', type: 'string'},
        {name: 'IsInterviewed', type: 'int'},
        {
            name: 'IsInterviewedCheck', type: 'boolean',
            convert: function (val, rec) {
                return rec.get('IsInterviewed') === 1 ;
            }
        },
        {name: 'CasePreviousPreviousID', type: 'int'}
    ]

    /*
    Uncomment to add validation rules
    validators: {
        age: 'presence',
        name: { type: 'length', min: 2 },
        gender: { type: 'inclusion', list: ['Male', 'Female'] },
        username: [
            { type: 'exclusion', list: ['Admin', 'Operator'] },
            { type: 'format', matcher: /([a-z]+)[0-9]{2,3}/i }
        ]
    }
    */

});