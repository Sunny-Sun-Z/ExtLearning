/**
 * Created by kkora on 9/8/2017.
 */
Ext.define('QuickStart.model.casereview.Lookup', {
    extend: 'QuickStart.model.Base',

    fields: [
        {name: 'group', type: 'string'},
        {name: 'groupId', type: 'int'},
        {name: 'parentCode', type: 'int'},
        {name: 'code', type: 'string'},
        {name: 'codeId', type: 'int'},
        {name: 'name', type: 'string'},
        {name: 'small', type: 'string'},
        {name: 'medium', type: 'string'},
        {name: 'large', type: 'string'},
        {name:'originalValue'}
    ]

});