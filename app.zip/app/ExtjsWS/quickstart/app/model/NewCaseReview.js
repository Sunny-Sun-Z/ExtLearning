/**
 * Created by kkora on 9/14/2017.
 */


Ext.define('QuickStart.model.NewCaseReview', {
    extend: 'QuickStart.model.Base',
    // idProperty:'CaseReviewRootID',
    requires: [
        'Ext.data.validator.*'
    ],

    fields: [
        { name: 'CaseReviewRootID', type: 'int', allowNull: true },
        { name: 'CaseReviewID', type: 'int', allowNull: true },
        //  {name: 'CaseID', type: 'int'},
        //  {name: 'MeetingID', type: 'int'},
        { name: 'CaseID', type: 'string' },
        { name: 'MeetingID', type: 'string', allowNull: true },
        { name: 'ReviewTypeID', type: 'int' },
        { name: 'ReviewSubTypeID', type: 'int' },
        { name: 'IRRReviewerID', type: 'int', allowNull: true },
        { name: 'CaseName', type: 'string' },
        { name: 'CaseStatusCode', type: 'int', defaultValue: 3 },
        { name: 'ReviewStartDate', type: 'date', dateFormat: 'c' },
        { name: 'ReviewCompleted', type: 'date', dateFormat: 'c', defaultValue: new Date() },
        { name: 'SiteCode', type: 'int' },
        {
            name: 'Reviewers', defaultValue: [],
            validate: function (value, separator, errors, record) {

                if (Ext.isEmpty(value))
                    return 'Must be present';
                //console.log('validate', value)
                var len = Ext.isArray(value) ? value.length : value.split(',').length;
                if (len > 3) {
                    return 'A maximum of 3 reviwers can be selected per case.';
                }
                return true;
            }
        },
        {
            name: 'InitialQAUserID', type: 'int'
            //     , validate: function (value, separator, errors, record) {
            //     record.clearState();
            //
            //     var reviewers = record.get('Reviewers') || [];
            //     if (!Ext.isArray(reviewers) && !Ext.isEmpty(reviewers)) {
            //         reviewers = [];
            //         reviewers.push(reviewers);
            //     }
            //     var result = reviewers.filter(function (item) {
            //         return item === record.get('InitialQAUserID');
            //     });
            //     if (Ext.isEmpty(value))
            //         return 'Must be present';
            //     else if (result > 0)
            //         return 'Same person cannot be selected as Reviewer and Initial QA';
            //     return true;
            // }
        },
        {
            name: 'SecondQAUserID', type: 'int'
            //     , validate: function (value, separator, errors, record) {
            //     console.log('SecondQAUserID', record.getData())
            //     record.clearState();
            //     var reviewers = record.get('Reviewers') || [];
            //     if (!Ext.isArray(reviewers) && !Ext.isEmpty(reviewers)) {
            //         reviewers = [];
            //         reviewers.push(reviewers);
            //     }
            //     var result = reviewers.filter(function (item) {
            //         return item === record.get('SecondQAUserID');
            //     });
            //     if (Ext.isEmpty(value))
            //         return 'Must be present';
            //     else if (result > 0)
            //         return 'Same person cannot be selected as Reviewer and Second Level QA';
            //     else if (record.get('InitialQAUserID') === record.get('SecondQAUserID'))
            //         return 'Same person cannot be selected as Initial QA and Second Level QA';
            //     return true;
            // }
        },
        {
            name: 'SecondaryOversightUserID', type: 'int', allowNull: true
            //     , validate: function (value, separator, errors, record) {
            //     console.log('SecondaryOversightUserID', record.getData())
            //     var reviewers = record.get('Reviewers') || [];
            //     if (!Ext.isArray(reviewers) && !Ext.isEmpty(reviewers)) {
            //         reviewers = [];
            //         reviewers.push(reviewers);
            //     }
            //     var result = reviewers.filter(function (item) {
            //         return item === record.get('SecondaryOversightUserID');
            //     });
            //     if (Ext.isEmpty(value))
            //         return 'Must be present';
            //     else if (result > 0)
            //         return 'Same person cannot be selected as Reviewer and Secondary Oversight';
            //     else if (record.get('InitialQAUserID') === record.get('SecondaryOversightUserID'))
            //         return 'Same person cannot be selected as Initial QA and Secondary Oversight';
            //     else if (record.get('SecondQAUserID') === record.get('SecondaryOversightUserID'))
            //         return 'Same person cannot be selected as Second Level QA and Secondary Oversight';
            //     return true;
            // }
        },
        {
            name: 'CtSecondaryOversightUserID', type: 'int', allowNull: true
            //     , validate: function (value, separator, errors, record) {
            //     console.log('CtSecondaryOversightUserID', record.getData())
            //     var reviewers = record.get('Reviewers') || [];
            //     if (!Ext.isArray(reviewers) && !Ext.isEmpty(reviewers)) {
            //         reviewers = [];
            //         reviewers.push(reviewers);
            //     }
            //     var result = reviewers.filter(function (item) {
            //         return item === record.get('CtSecondaryOversightUserID');
            //     });
            //     if (Ext.isEmpty(value))
            //         return 'Must be present';
            //     else if (result > 0)
            //         return 'Same person cannot be selected as Reviewer and CT Secondary Oversight';
            //     else if (record.get('InitialQAUserID') === record.get('CtSecondaryOversightUserID'))
            //         return 'Same person cannot be selected as Initial QA and CT Secondary Oversight';
            //     else if (record.get('SecondQAUserID') === record.get('CtSecondaryOversightUserID'))
            //         return 'Same person cannot be selected as Second Level QA and CT Secondary Oversight';
            //     else if (record.get('SecondaryOversightUserID') === record.get('CtSecondaryOversightUserID'))
            //         return 'Same person cannot be selected as Secondary Oversight and CT Secondary Oversight';
            //     return true;
            // }
        },
        { name: 'Active', type: 'int', allowNull: true },
        { name: 'EliminationReasonCode', type: 'int', allowNull: true },
        { name: 'EliminationReasonExplained', type: 'string', allowNull: true },
        { name: 'IsPIPMonitored', type: 'int', allowNull: true },
        { name: 'CR_Reviewer_Collection', defaultValue: [] },
        { name: 'SampleReviewId', type: 'int', allowNull: true }
    ],


    convertDateIfString: function (data) {
        if (!Ext.isEmpty(data))
            return null;
        return Ext.isDate(data) ? data : new Date(data);
    },
    validators: {

        // CaseID: {type: 'presence'},
        // CaseName: {type: 'presence'},
        // SiteCode: {type: 'presence'},
        // ReviewStartDate:{type: 'presence'},
        // ReviewCompleted: 'presence',
        // Reviewers: ['presence'],
        // InitialQAUserID: ['presence'],
        // SecondQAUserID:  'presence',
        // SecondaryOversightUserID: ['presence'],
        // CtSecondaryOversightUserID: ['presence']
        // gender: { type: 'inclusion', list: ['Male', 'Female'] },
        // username: [
        //     { type: 'exclusion', list: ['Admin', 'Operator'] },
        //     { type: 'format', matcher: /([a-z]+)[0-9]{2,3}/i }
        // ]
    }
});