﻿/**
 * Created by rkumar on 11/06/2018.
 */
Ext.define('QuickStart.model.sampling.ReviewPeriod', {
    extend: 'QuickStart.model.Base',
    idProperty: 'FFY',
    fields: [
        { name: 'Id', type: 'int' },
        { name: 'Period', type: 'string' },
        { name: 'StartDate', type: 'date' },
        {
            name: 'EndDate', type: 'date',
            calculate: function (data) {
                if (Ext.isEmpty(data.StartDate))
                    return;

                //var startDate = Ext.Date.format(data.StartDate, "m/d/Y");
                var dt = Ext.Date.add(data.StartDate, Ext.Date.MONTH, 5);
                return dt;
            }
        },
        {
            name: 'message', type: 'string',
            calculate: function (data) {
                if (Ext.isEmpty(data.StartDate) || Ext.isEmpty(data.EndDate))
                    return;

                var period = Ext.Date.format(data.StartDate, 'M-Y') + ' to ' + Ext.Date.format(data.EndDate, 'M-Y');
                return period;
            }
        }
    ]
});