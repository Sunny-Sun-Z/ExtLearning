﻿/**
 * Created by rkumar on 1/18/2019.
 */
Ext.define('QuickStart.model.sampling.SampleCase', {
    extend: 'QuickStart.model.Base',
    entityName: 'SampleCase',
    fields: [
        { name: 'ID', type: 'int', allowNull: true },
        { name: 'FFY', type: 'string', allowNull: true },
        { name: 'ReviewPeriodId', type: 'int', allowNull: true },
        { name: 'Office_Id', type: 'int', allowNull: true },
        { name: 'Office_Name', type: 'string', allowNull: true },
        { name: 'Region_Id', type: 'int', allowNull: true },
        { name: 'Region_Name', type: 'string', allowNull: true },
        { name: 'Case_Type', type: 'string', allowNull: true },
        { name: 'Case_ID', type: 'int', allowNull: true },
        { name: 'Case_Name', type: 'string', allowNull: true },
        { name: 'Case_Status', type: 'string', allowNull: true },
        { name: 'Primary_Language', type: 'string', allowNull: true },
        { name: 'Home_Town', type: 'string', allowNull: true },
        {
            type: 'string',
            name: 'HomeTown',
            calculate: function (data) {
                if (Ext.isEmpty(data.Home_Town))
                    return '';

                if (data.Home_Town.indexOf(',') <= 0)
                    return data.Home_Town;

                var arr = data.Home_Town.split(',');
                if (Ext.isEmpty(arr[1]))
                    return arr[0];

                return arr[0] + ', ' + arr[1];
            }
        },
        { name: 'Legal_Status', type: 'string', allowNull: true },
        { name: 'SOLNIT_N', type: 'boolean', allowNull: true },
        { name: 'SOLNIT_S', type: 'boolean', allowNull: true },
        { name: 'CJTS', type: 'boolean', allowNull: true },
        { name: 'ChildName', type: 'string', allowNull: true },
        { name: 'TypeChild', type: 'string', allowNull: true },
        { name: 'SampleType', type: 'string', allowNull: true },
        { name: 'ReviewMonth', type: 'date', allowNull: true, dateFormat: 'c' },
        { name: 'STATE', type: 'string', allowNull: true },
        { name: 'REPDATE', type: 'string', allowNull: true },
        { name: 'REPORT_DATE', type: 'date', allowNull: true },
        { name: 'FIPSCODE', type: 'string', allowNull: true },
        { name: 'RECNMBR', type: 'int', allowNull: true },
        { name: 'RCNT_ACR', type: 'string', allowNull: true },
        { name: 'DT_CHLD_BRTH', type: 'string', allowNull: true },
        { name: 'Child_DOB', type: 'date', allowNull: true, dateFormat: 'c' },
        { name: 'AGE_RPT_DT', type: 'int', allowNull: true },
        { name: 'SEX', type: 'string', allowNull: true },
        { name: 'RACE_AMERICANINDIAN', type: 'string', allowNull: true },
        { name: 'RACE_ASIAN', type: 'string', allowNull: true },
        { name: 'RACE_AFERICANAMERICAN', type: 'string', allowNull: true },
        { name: 'RACE_OTHER', type: 'string', allowNull: true },
        { name: 'RACE_WHITE', type: 'string', allowNull: true },
        { name: 'RACE_UNKNOWN', type: 'string', allowNull: true },
        {
            type: 'string',
            name: 'ChildRace',
            calculate: function (data) {
                var _multiRacial = 0, _race = '';
                if (data.RACE_AMERICANINDIAN === 'Applies') {
                    _race = "American Indian";
                    _multiRacial++;
                }
                if (data.RACE_ASIAN === 'Applies') {
                    _race = "Asian";
                    _multiRacial++;
                }
                if (data.RACE_AFERICANAMERICAN === 'Applies') {
                    _race = "African American";
                    _multiRacial++;
                }
                if (data.RACE_WHITE === 'Applies') {
                    _race = "White";
                    _multiRacial++;
                }
                if (data.RACE_OTHER === 'Applies') {
                    _race = "Other";
                    _multiRacial++;
                }
                if (data.RACE_UNKNOWN === 'Applies') {
                    _race = "Unknown";
                    _multiRacial++;
                }

                if (_multiRacial > 1)
                    return "Multi-Racial";
                else
                    return _race;
            }
        },
        { name: 'HISPNC', type: 'string', allowNull: true },
        { name: 'CLIN_DIAGN_DSBLTY', type: 'string', allowNull: true },
        { name: 'MNTL_RTRDTN', type: 'string', allowNull: true },
        { name: 'VSL_HRNG_IMPRD', type: 'string', allowNull: true },
        { name: 'PHYS_DSBLD', type: 'string', allowNull: true },
        { name: 'EMOT_DSTRBD', type: 'string', allowNull: true },
        { name: 'OTHR_MDCL_CNDTN', type: 'string', allowNull: true },
        {
            type: 'string',
            name: 'DisableReasons',
            calculate: function (data) {
                var _disableReasons = [];

                if (data.CLIN_DIAGN_DSBLTY === 'Yes') {
                    if (data.MNTL_RTRDTN === 'Applies')
                        _disableReasons.push(1);
                    if (data.VSL_HRNG_IMPRD === 'Applies')
                        _disableReasons.push(2);
                    if (data.PHYS_DSBLD === 'Applies')
                        _disableReasons.push(3);
                    if (data.EMOT_DSTRBD === 'Applies')
                        _disableReasons.push(4);
                    if (data.OTHR_MDCL_CNDTN === 'Applies')
                        _disableReasons.push(5);
                }
                return { 'DisableReasons': _disableReasons };
            }
        },
        { name: 'EVER_ADOPTED', type: 'string', allowNull: true },
        { name: 'ADPTN_AGE', type: 'string', allowNull: true },
        { name: 'FRST_RMVL_DATE', type: 'string', allowNull: true },
        { name: 'TTL_RMVLS', type: 'int', allowNull: true },
        { name: 'LST_DSCHRG_DATE', type: 'string', allowNull: true },
        { name: 'RCNT_RMVL_DATE', type: 'string', allowNull: true },
        { name: 'RCNT_RMVL_TRNS_DT', type: 'string', allowNull: true },
        { name: 'CRRNT_PLCMNT_STRT_DT', type: 'string', allowNull: true },
        { name: 'PREV_PLCMNTS_IN_EPSD', type: 'int', allowNull: true },
        { name: 'RMVL_MANNER', type: 'string', allowNull: true },
        { name: 'RMVL_PHYS_AB', type: 'string', allowNull: true },
        { name: 'RMVL_SEX_AB', type: 'string', allowNull: true },
        { name: 'RMVL_NEGLECT', type: 'string', allowNull: true },
        { name: 'RMVL_PRNT_ALC_AB', type: 'string', allowNull: true },
        { name: 'RMVL_PRNT_DRUG_AB', type: 'string', allowNull: true },
        { name: 'RMVL_CHLD_ALC_AB', type: 'string', allowNull: true },
        { name: 'RMVL_CHLD_DRUG_AB', type: 'string', allowNull: true },
        { name: 'RMVL_CHLD_DSBLTY', type: 'string', allowNull: true },
        { name: 'RMVL_CHLD_BEH_PROB', type: 'string', allowNull: true },
        { name: 'RMVL_PRNT_DEATH', type: 'string', allowNull: true },
        { name: 'RMVL_PRNT_INCRCRTN', type: 'string', allowNull: true },
        { name: 'RMVL_CRTKR_COPING', type: 'string', allowNull: true },
        { name: 'RMVL_ABNDNMNT', type: 'string', allowNull: true },
        { name: 'RMVL_RLNQSHMNT', type: 'string', allowNull: true },
        { name: 'RMVL_INADQT_HOUSING', type: 'string', allowNull: true },
        {
            type: 'string',
            name: 'CaseReasons',
            calculate: function (data) {
                var _caseReasons = [];

                if (data.RMVL_PHYS_AB === 'Applies')
                    _caseReasons.push(1);
                if (data.RMVL_SEX_AB === 'Applies')
                    _caseReasons.push(2);
                if (data.RMVL_NEGLECT === 'Applies')
                    _caseReasons.push(3);
                if (data.RMVL_CHLD_ALC_AB === 'Applies')
                    _caseReasons.push(4);
                if (data.RMVL_CHLD_DRUG_AB === 'Applies')
                    _caseReasons.push(5);
                if (data.RMVL_PRNT_ALC_AB === 'Applies')
                    _caseReasons.push(6);
                if (data.RMVL_PRNT_DRUG_AB === 'Applies')
                    _caseReasons.push(7);
                if (data.RMVL_INADQT_HOUSING === 'Applies')
                    _caseReasons.push(8);
                if (data.RMVL_CHLD_BEH_PROB === 'Applies')
                    _caseReasons.push(9);
                if (data.RMVL_CHLD_DSBLTY === 'Applies')
                    _caseReasons.push(10);
                if (data.RMVL_PRNT_INCRCRTN === 'Applies')
                    _caseReasons.push(11);
                if (data.RMVL_PRNT_DEATH === 'Applies')
                    _caseReasons.push(12);
                if (data.RMVL_CRTKR_COPING === 'Applies')
                    _caseReasons.push(13);
                if (data.RMVL_ABNDNMNT === 'Applies')
                    _caseReasons.push(14);
                if (data.RMVL_RLNQSHMNT === 'Applies')
                    _caseReasons.push(15);

                return { 'CaseReasons': _caseReasons };
            }
        },
        { name: 'PLCMNT_SETTING', type: 'string', allowNull: true },
        { name: 'PLCMNT_OUTOFSTATE', type: 'string', allowNull: true },
        { name: 'RCNT_PERM_GOAL', type: 'string', allowNull: true },
        { name: 'CRTKR_FMLY_STRCTR', type: 'string', allowNull: true },
        { name: 'CRTKR1_BRTH_YR', type: 'int', allowNull: true },
        {
            type: 'string',
            name: 'CRTKR1_BRTH_YR_TEXT',
            calculate: function (data) {
                if (data.CRTKR1_BRTH_YR > 0)
                    return data.CRTKR1_BRTH_YR;
                else
                    return '';
            }
        },
        { name: 'CRTKR2_BRTH_YR', type: 'int', allowNull: true },
        {
            type: 'string',
            name: 'CRTKR2_BRTH_YR_TEXT',
            calculate: function (data) {
                if (data.CRTKR2_BRTH_YR > 0)
                    return data.CRTKR2_BRTH_YR;
                else
                    return '';
            }
        },
        { name: 'MOTHER_TPR_DT', type: 'string', allowNull: true },
        { name: 'FATHER_TPR_DT', type: 'string', allowNull: true },
        { name: 'FO_FMLY_STRCTR', type: 'string', allowNull: true },
        { name: 'FO_CRTRKR1_BIRTH_YR', type: 'int', allowNull: true },
        {
            type: 'string',
            name: 'FO_CRTRKR1_BIRTH_YR_TEXT',
            calculate: function (data) {
                if (data.FO_CRTRKR1_BIRTH_YR > 0)
                    return data.FO_CRTRKR1_BIRTH_YR;
                else
                    return '';
            }
        },
        { name: 'FO_CRTRKR2_BIRTH_YR', type: 'int', allowNull: true },
        {
            type: 'string',
            name: 'FO_CRTRKR2_BIRTH_YR_TEXT',
            calculate: function (data) {
                if (data.FO_CRTRKR2_BIRTH_YR > 0)
                    return data.FO_CRTRKR2_BIRTH_YR;
                else
                    return '';
            }
        },
        { name: 'FO_CRTRKR1_RACE_AMERICANINDIAN', type: 'string', allowNull: true },
        { name: 'FO_CRTRKR1_RACE_ASIAN', type: 'string', allowNull: true },
        { name: 'FO_CRTRKR1_RACE_AFERICANAMERICAN', type: 'string', allowNull: true },
        { name: 'FO_CRTRKR1_RACE_OTHER', type: 'string', allowNull: true },
        { name: 'FO_CRTRKR1_RACE_WHITE', type: 'string', allowNull: true },
        { name: 'FO_CRTRKR1_RACE_UNKNOWN', type: 'string', allowNull: true },
        {
            type: 'string',
            name: 'FO_CRTRKR1_RACE',
            calculate: function (data) {
                var _multiRacial = 0, _race = '';
                if (data.FO_CRTRKR1_RACE_AMERICANINDIAN === 'Applies') {
                    _race = "American Indian";
                    _multiRacial++;
                }
                if (data.FO_CRTRKR1_RACE_ASIAN === 'Applies') {
                    _race = "Asian";
                    _multiRacial++;
                }
                if (data.FO_CRTRKR1_RACE_AFERICANAMERICAN === 'Applies') {
                    _race = "African American";
                    _multiRacial++;
                }
                if (data.FO_CRTRKR1_RACE_WHITE === 'Applies') {
                    _race = "White";
                    _multiRacial++;
                }
                if (data.FO_CRTRKR1_RACE_OTHER === 'Applies') {
                    _race = "Other";
                    _multiRacial++;
                }
                if (data.FO_CRTRKR1_RACE_UNKNOWN === 'Applies') {
                    _race = "Unknown";
                    _multiRacial++;
                }

                if (_multiRacial > 1)
                    return "Multi-Racial";
                else
                    return _race;
            }
        },
        { name: 'FO_CRTRKR1_HISP', type: 'string', allowNull: true },
        { name: 'FO_CRTRKR2_RACE_AMERICANINDIAN', type: 'string', allowNull: true },
        { name: 'FO_CRTRKR2_RACE_ASIAN', type: 'string', allowNull: true },
        { name: 'FO_CRTRKR2_RACE_AFERICANAMERICAN', type: 'string', allowNull: true },
        { name: 'FO_CRTRKR2_RACE_OTHER', type: 'string', allowNull: true },
        { name: 'FO_CRTRKR2_RACE_WHITE', type: 'string', allowNull: true },
        { name: 'FO_CRTRKR2_RACE_UNKNOWN', type: 'string', allowNull: true },
        {
            type: 'string',
            name: 'FO_CRTRKR1_RACE',
            calculate: function (data) {
                var _multiRacial = 0, _race = '';
                if (data.FO_CRTRKR2_RACE_AMERICANINDIAN === 'Applies') {
                    _race = "American Indian";
                    _multiRacial++;
                }
                if (data.FO_CRTRKR2_RACE_ASIAN === 'Applies') {
                    _race = "Asian";
                    _multiRacial++;
                }
                if (data.FO_CRTRKR2_RACE_AFERICANAMERICAN === 'Applies') {
                    _race = "African American";
                    _multiRacial++;
                }
                if (data.FO_CRTRKR2_RACE_WHITE === 'Applies') {
                    _race = "White";
                    _multiRacial++;
                }
                if (data.FO_CRTRKR2_RACE_OTHER === 'Applies') {
                    _race = "Other";
                    _multiRacial++;
                }
                if (data.FO_CRTRKR2_RACE_UNKNOWN === 'Applies') {
                    _race = "Unknown";
                    _multiRacial++;
                }

                if (_multiRacial > 1)
                    return "Multi-Racial";
                else
                    return _race;
            }
        },
        { name: 'FO_CRTRKR2_HISP', type: 'string', allowNull: true },
        { name: 'DISCHARGE_DT', type: 'string', allowNull: true },
        { name: 'DISCHARGE_TRNS_DT', type: 'string', allowNull: true },
        { name: 'DISCHARGE_REASON', type: 'string', allowNull: true },
        //{ name: 'FEDSUPPRT_IVEFC', type: 'string', allowNull: true },
        //{ name: 'FEDSUPPRT_IVEAA', type: 'string', allowNull: true },
        //{ name: 'FEDSUPPRT_IVA', type: 'string', allowNull: true },
        //{ name: 'FEDSUPPRT_IVD', type: 'string', allowNull: true },
        //{ name: 'FEDSUPPRT_XIX', type: 'string', allowNull: true },
        //{ name: 'FEDSUPPRT_SOCSEC', type: 'string', allowNull: true },
        //{ name: 'FEDSUPPRT_NONE', type: 'string', allowNull: true },
        { name: 'MNTHLY_FOCARE_AMNT', type: 'int', allowNull: true },
        { name: 'DAYS_OPEN_SMPL_PRD', type: 'int', allowNull: true },
        { name: 'DT_CASE_OPN', type: 'date', allowNull: true },
        { name: 'RCNT_ASSIGN_START', type: 'date', allowNull: true },
        { name: 'RCNT_ASSIGN_TYPE', type: 'string', allowNull: true },
        { name: 'RCNT_ROLE', type: 'string', allowNull: true },
        { name: 'RCNT_RSPNSBLTY', type: 'string', allowNull: true },
        { name: 'RCNT_ASSIGN_END', type: 'date', allowNull: true },
        { name: 'DT_CASE_CLS', type: 'date', allowNull: true },
        { name: 'IsPrimary', type: 'boolean', allowNull: true },
        { name: 'IsEliminated', type: 'boolean', allowNull: true },
        {
            type: 'string',
            name: 'IsEliminated_Desc',
            calculate: function (data) {
                return data.IsEliminated ? 'Yes' : 'No';
            }
        },
        { name: 'TS_Eliminated', type: 'date', allowNull: true , dateFormat: 'c'},
        //{ name: 'ID_UP', type: 'int', allowNull: true },
        //{ name: 'TS_UP', type: 'date', allowNull: true },
        { name: 'Reviewer_Name', type: 'string', allowNull: true },
        {
            type: 'string',
            name: 'SampleType_Desc',
            calculate: function (data) {
                if (data.SampleType)
                    return data.SampleType === 'P' ? 'Primary' : 'Secondary';

                return '';
            }
        },
        {
            type: 'string',
            name: 'Case_Type_Desc',
            calculate: function (data) {
                return data.Case_Type === 'IH' ? 'In Home' : 'Foster Care';
            }
        },
        { name: 'WorkerInfo', allowNull: true },
        { name: 'PeriodUnderReview', type: 'date', allowNull: true, dateFormat: 'c' }
    ]
});
