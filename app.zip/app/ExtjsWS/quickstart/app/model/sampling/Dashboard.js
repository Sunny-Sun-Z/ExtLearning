﻿/**
 * Created by kkora on 11/07/2018.
 */
Ext.define('QuickStart.model.sampling.Dashboard', {
    extend: 'QuickStart.model.Base',
    fields: [
        { name: 'ID', type: 'int' },
        { name: 'FFY', type: 'string' },
        { name: 'OfficeName', type: 'string' },
        { name: 'SampleType', type: 'string' },
        { name: 'Region_Name', type: 'string', allowNull: true },
        { name: 'ReviewMonth', type: 'date', allowNull: true },
        { name: 'Case_ID', type: 'int' },
        { name: 'Case_Type', type: 'string' },
        { name: 'Case_Name', type: 'string' },
        { name: 'Case_Status', type: 'string' },
        { name: 'Primary_Language', type: 'string' },
        { name: 'Home_Town', type: 'string' },
        {
            type: 'string',
            name: 'HomeTown',
            calculate: function (data) {
                if (Ext.isEmpty(data.Home_Town))
                    return '';

                if (data.Home_Town.indexOf(',') <= 0)
                    return data.Home_Town;

                var arr = data.Home_Town.split(',');
                if (Ext.isEmpty(arr[1]))
                    return arr[0];

                return arr[0] + ', ' + arr[1];
            }
        },
        { name: 'ChildName', type: 'string' },
        { name: 'Child_DOB', type: 'date', dateFormat: 'c' },
        { name: 'AGE_RPT_DT', type: 'int' },
        {
            type: 'string',
            name: 'Child_Age_Calc',
            calculate: function (data) {
                if (!data.IsPrimary)
                    return '';

                if (Ext.isEmpty(data.Case_Type) || data.Case_Type === 'IH' || Ext.isEmpty(data.ReviewMonth) || !Ext.isDate(data.Child_DOB))
                    return '';

                var diff = Ext.Date.diff(data.Child_DOB, data.ReviewMonth, Ext.Date.MONTH);
                var years = parseInt(diff / 12, 10);
                var months = diff % 12;
                var ageDesc;
                if (years > 0 && months > 0)
                    ageDesc = years + ' Year(s) and ' + months + ' Month(s)';
                else if (years > 0)
                    ageDesc = years + ' Year(s)';
                else if (months > 0)
                    ageDesc = months + ' Month(s)';
                else 
                    ageDesc = '-';

                return ageDesc;
                //return data.AGE_RPT_DT;
            }
        },
        
        { name: 'Legal_Status', type: 'string' },
        { name: 'Reviewers', type: 'string' },
        { name: 'IsPrimary', type: 'boolean' },
        { name: 'IsEliminated', type: 'boolean' },
        { name: 'TS_Eliminated', type: 'date', allowNull: true, dateFormat: 'c' },
        { name: 'CaseReviewRootID', type: 'int', allowNull: true },
        { name: 'IsIntake', type: 'boolean'},

        {
            type: 'boolean',
            name: 'IsReplacement',
            calculate: function (data) {

                return data.IsPrimary == true && data.SampleType == 'S';
               
            }
        },
    ]
});
