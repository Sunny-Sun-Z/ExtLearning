/**
 * Created by kkora on 12/21/2017.
 */
Ext.define('QuickStart.model.Report', {
    extend: 'Ext.data.Model',
    idProperty: 'Id',
    fields: [

        {name: 'Id', type: 'int'},
        {name: 'Name', type: 'string'},
        {name: 'Description', type: 'string'},
        {name: 'FileName', type: 'string'},
        {name: 'Query', type: 'string'},
        {name: 'Enabled', type: 'boolean'},
        {name: 'Url', type: 'string'},
        {name: 'Type', type: 'string'},
        {name: 'Created', type: 'date'},
        {name: 'CreatedBy', type: 'int'},
        {name: 'Component', type: 'string'},
        'Parameters'
    ]
});