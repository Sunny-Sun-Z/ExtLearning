/**
 * Created by kkora on 10/16/2017.
 */
Ext.define('QuickStart.model.Log', {
    extend: 'QuickStart.model.Base',
    fields: [
        {name: 'Id', type: 'int'},
        {name: 'Message', type: 'string'},
        {name: 'Source', type: 'string'},
        {name: 'Type', type: 'string'},
        {name: 'StackTrace', type: 'string'},
        {name: 'UserId', type: 'int'},
        {name: 'Created', type: 'date', dateFormat: 'c'}
    ]

});