/**
 * Created by kkora on 10/6/2017.
 */
Ext.define('QuickStart.model.BaseLookup', {
    extend: 'Ext.data.Model',
    idProperty:'Id',
    fields: [
        {name: 'Name', type: 'string'},
        {name: 'Id', type: 'int'}
    ]

});