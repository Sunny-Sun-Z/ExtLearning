/**
 * Created by kkora on 9/19/2017.
 */
Ext.define('QuickStart.model.ReviewerProfile', {
    extend: 'QuickStart.model.Base',
    idProperty: 'UserID',
    entityName: 'ReviewerProfile',
    fields: [
        {
            type: 'int',
            name: 'UserID'
        },
        {
            type: 'string',
            name: 'FirstName'
        },
        {
            type: 'string',
            name: 'LastName'
        },
        {
            type: 'string',
            name: 'Name',
            calculate: function (data) {
                return data.FirstName + ' ' + data.LastName;
            }
        },
       
        //{
        //    type: 'boolean',
        //    name: 'IsActive',
        //    defaultValue: true
        //},
       
        {
            type: 'string', name: 'SpecialConsideration'
        },
        {
            type: 'string', name: 'CurrentOffice'
        },
        {
            type: 'int', name: 'CurrentOfficeID'
        },
        {
            type: 'string', name: 'PreviousOffice'
        },  

        {
            type: 'int', name: 'PreviousOfficeID'
        },
        {
            type: 'string', name: 'Hometown' 
        },
        {
            type: 'int', name: 'HometownID'
        },
        {
            type: 'boolean',
            name: 'IsProfileActive',
            defaultValue: false
        },
        {
            type: 'string', name: 'OtherHometown'   
        }
       

       // 'Roles', 'Permissions'
    ]
});