/**
 * Created by kkora on 12/21/2017.
 */
Ext.define('QuickStart.model.PipReviewSample', {
    extend: 'Ext.data.Model',
    idProperty: 'Id',
    fields: [

        {name: 'Id', type: 'int'},
        {name: 'CaseId', type: 'int'},
        {name: 'RegionId', type: 'int'},
        {name: 'Date', type: 'date'},
        {name: 'Office', type: 'string'},
        {name: 'SampleGroup', type: 'string'},//In-Home/Foster Care
        {name: 'SampleType', type: 'string'},//PRIMARY/SECONDARY/UNIVERSE
        {name: 'IsAdditionalHS', type: 'boolean', allowNull: true},
        {name: 'Month', type: 'int', allowNull: true},
        {name: 'Month1', type: 'int', allowNull: true},
        {name: 'Month2', type: 'int', allowNull: true},
        {name: 'Month3', type: 'int', allowNull: true},
        {name: 'Month4', type: 'int', allowNull: true},
        {name: 'Month5', type: 'int', allowNull: true},
        {name: 'Month6', type: 'int', allowNull: true},
        {
            name: 'Total', type: 'int',
            calculate: function (data) {
                var t = (data.Month1 || 0) + (data.Month2 || 0) + (data.Month3 || 0) + (data.Month4 || 0) + (data.Month5 || 0) + (data.Month6 || 0);
                return t == 0 ? '' : t;
            }
        }

    ]
});