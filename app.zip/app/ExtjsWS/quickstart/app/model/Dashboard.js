/**
 * Created by kkora on 9/14/2017.
 */
Ext.define('QuickStart.model.Dashboard', {
    extend: 'QuickStart.model.Base',
    fields: [
        {name: 'CaseReviewRootID', type: 'int', allowNull: true},
        {name: 'CaseReviewID', type: 'int', allowNull: true},
        //  {name: 'CaseID', type: 'int'},
        //  {name: 'MeetingID', type: 'int'},
        {name: 'CaseID', type: 'string'},
        {name: 'MeetingID', type: 'string', allowNull: true},
        {name: 'ReviewTypeID', type: 'int'},
        {name: 'ReviewSubTypeID', type: 'int'},
        {name: 'CaseName', type: 'string'},
        {name: 'CaseStatusCode', type: 'int', defaultValue: 3},
        {name: 'ReviewStartDate', type: 'date', dateFormat: 'c'},
        {name: 'ReviewCompleted', type: 'date', dateFormat: 'c'},
        {name: 'SiteCode', type: 'int'},
        {name: 'Reviewers', type: 'string'},//used in dashboard
        {name: 'BatchProcessedID', type: 'string'},
        {name: 'FederalProcessedDate', type: 'date', dateFormat: 'c'},
        {name: 'Active', type: 'boolean'},
        {name: 'HasFile', type: 'boolean'}

    ]
});