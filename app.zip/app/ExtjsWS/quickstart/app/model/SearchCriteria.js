/**
 * Created by kkora on 9/14/2017.
 */
Ext.define('QuickStart.model.SearchCriteria', {
    extend: 'QuickStart.model.Base',
    fields: [
        {name: 'Id', type: 'int'},
        {name: 'UserId', type: 'int'},
        {name: 'Name', type: 'string'},
        {name: 'Type', type: 'int', defaultValue: 1},
        {name: 'Created', type: 'date', dateFormat: 'c'},
        {name: 'Enabled', type: 'boolean'},
        {name: 'Data', type: 'string'}
    ]
});