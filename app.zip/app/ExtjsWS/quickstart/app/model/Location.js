﻿/**
 * Created by rkumar on 11/06/2018.
 */
Ext.define('QuickStart.model.Location', {
    extend: 'QuickStart.model.BaseLookup',
    idProperty: 'Id',
    fields: [
        { name: 'RegionId', type: 'int' }
    ]
});