/**
 * Created by rkumar on 11/06/2018.
 */
Ext.define('QuickStart.model.Hometown111', {
    extend: 'QuickStart.model.BaseLookup',
    idProperty: 'Id',
    fields: [
        { name: 'HometownName111', type: 'string' },
        { name: 'Id', type: 'int' }
    ]
});
