/**
 * Created by kkora on 9/14/2017.
 */


Ext.define('QuickStart.model.irr.CaseReview', {
    extend: 'QuickStart.model.Base',
    // idProperty:'CaseReviewRootID',
    requires: [
        'Ext.data.validator.*'
    ],

    fields: [
        {name: 'CaseReviewRootID', type: 'int', allowNull: true},
        {name: 'CaseReviewID', type: 'int', allowNull: true},
        {name: 'CaseID', type: 'int'},
        {name: 'MeetingID', type: 'int'},
        {name: 'CaseID', type: 'string'},
        {name: 'MeetingID', type: 'string', allowNull: true},
        {name: 'ReviewTypeID', type: 'int'},
        {name: 'ReviewSubTypeID', type: 'int'},
        {name: 'CaseName', type: 'string'},
        {name: 'CaseStatusCode', type: 'int', defaultValue: 3},
        {name: 'ReviewStartDate', type: 'date', dateFormat: 'c'},
        {name: 'ReviewCompleted', type: 'date', dateFormat: 'c'},
        {name: 'SiteCode', type: 'int'},
        {
            name: 'Reviewers', defaultValue: []
        },
        {name: 'InitialQAUserID', type: 'int'},
        {name: 'SecondQAUserID', type: 'int'},
        {name: 'SecondaryOversightUserID', type: 'int'},
        {name: 'CtSecondaryOversightUserID', type: 'int'},
        {name: 'Active', type: 'int', allowNull: true},
        {name: 'EliminationReasonCode', type: 'int', allowNull: true},
        {name: 'EliminationReasonExplained', type: 'string', allowNull: true},
        {name: 'IsPIPMonitored', type: 'int', allowNull: true},

        {name: 'CR_FaceSheet_Collection', defaultValue: []},
        {name: 'CR_MultiAnswer_Collection', defaultValue: []},
        {name: 'CR_Permanency_Collection', defaultValue: []},
        {name: 'CR_Reviewer_Collection', defaultValue: []},
        {name: 'CR_Safety_Collection', defaultValue: []},
        {name: 'CR_WellBeing_Collection', defaultValue: []},
        {name: 'CR_CaseNote_Collection', defaultValue: []},
        {name: 'CR_Outcome_Collection', defaultValue: []},

        {name: 'TS_UP', type: 'date', allowNull: true},
        {name: 'TS_CR', type: 'date', allowNull: true},
        {name: 'ID_UP', type: 'int', allowNull: true},
        {name: 'ID_CR', type: 'int', allowNull: true},
        {
            name: 'temp',
            convert: function (val, rec) {
                var reviewers = Ext.Array.pluck(rec.get('CR_Reviewer_Collection'), 'UserID');
                var reviewSubTypeID = rec.get('ReviewSubTypeID');

                rec.set('Reviewers', reviewers);

                var fs = rec.get('CR_FaceSheet_Collection')[0];
                if (!Ext.isEmpty(fs)) {
                    if (!Ext.isEmpty(fs.FirstCaseOpeningDate)) {
                        rec.set('FirstCaseOpeningDate', Ext.isDate(fs.FirstCaseOpeningDate) ? fs.FirstCaseOpeningDate : new Date(fs.FirstCaseOpeningDate));
                    }
                    if (!Ext.isEmpty(fs.FosterEntryDate)) {
                        rec.set('FosterEntryDate', Ext.isDate(fs.FosterEntryDate) ? fs.FosterEntryDate : new Date(fs.FosterEntryDate));
                    }
                    if (!Ext.isEmpty(fs.EpisodeDischargeDate)) {
                        rec.set('EpisodeDischargeDate', Ext.isDate(fs.EpisodeDischargeDate) ? fs.EpisodeDischargeDate : new Date(fs.EpisodeDischargeDate));
                    }
                    if (!Ext.isEmpty(fs.CaseClosureDate)) {
                        rec.set('CaseClosureDate', Ext.isDate(fs.CaseClosureDate) ? fs.CaseClosureDate : new Date(fs.CaseClosureDate));
                    }
                    rec.set('OtherCaseReason', fs.OtherCaseReason);
                    rec.set('IsCaseOpenReasonOtherAbuseNeglect', fs.IsCaseOpenReasonOtherAbuseNeglect);
                    rec.set('IsFosterEntryDateNA', fs.IsFosterEntryDateNA);
                    rec.set('IsEpisodeDischargeDateNA', fs.IsEpisodeDischargeDateNA);
                    rec.set('IsCaseClosureNotClosed', fs.IsCaseClosureNotClosed);
                    rec.set('IsEpisodeNotYetDischarged', fs.IsEpisodeNotYetDischarged);

                }
                var ma = rec.get('CR_MultiAnswer_Collection');
                if (ma) {
                    var caseReasons = ma.filter(function (item) {
                        return item.GroupName == 'CaseReason';
                    });
                    caseReasons = Ext.Array.pluck(caseReasons, 'CodeDescriptionID');
                    rec.set('CaseReasons', caseReasons);

                    var safetyRelatedIncidents = ma.filter(function (item) {
                        return item.GroupName === 'SafetyRelatedIncidents';
                    });
                    safetyRelatedIncidents = Ext.Array.pluck(safetyRelatedIncidents, 'CodeDescriptionID');
                    rec.set('SafetyRelatedIncidents', safetyRelatedIncidents);

                    var fosterSafety = ma.filter(function (item) {
                        return item.GroupName === 'FosterSafety';
                    });
                    fosterSafety = Ext.Array.pluck(fosterSafety, 'CodeDescriptionID');

                    var fosterPlacementConcern = ma.filter(function (item) {
                        return item.GroupName === 'FosterPlacementConcern';
                    });
                    fosterPlacementConcern = Ext.Array.pluck(fosterPlacementConcern, 'CodeDescriptionID');

                    if (reviewSubTypeID === 19 || reviewSubTypeID === 21) //home service or In-Home Services DR/AR
                    {
                        fosterSafety = [];
                        fosterSafety.push(92);
                        fosterPlacementConcern = [];
                        fosterPlacementConcern.push(98);

                    }
                    rec.set('FosterSafety', fosterSafety);
                    rec.set('FosterPlacementConcern', fosterPlacementConcern);


                    var placementApplicableCircumstances = ma.filter(function (item) {
                        return item.GroupName === 'PlacementApplicableCircumstances';
                    });
                    placementApplicableCircumstances = Ext.Array.pluck(placementApplicableCircumstances, 'CodeDescriptionID');
                    rec.set('PlacementApplicableCircumstances', placementApplicableCircumstances);

                    var terminationExceptions = ma.filter(function (item) {
                        return item.GroupName === 'TerminationExceptions';
                    });
                    terminationExceptions = Ext.Array.pluck(terminationExceptions, 'CodeDescriptionID');
                    rec.set('TerminationExceptions', terminationExceptions);

                    var permanencyGoal1 = ma.filter(function (item) {
                        return item.GroupName === 'PermanencyGoal1';
                    });
                    permanencyGoal1 = Ext.Array.pluck(permanencyGoal1, 'CodeDescriptionID');
                    rec.set('PermanencyGoal1', permanencyGoal1);

                    var placementEffortConcernsFather = ma.filter(function (item) {
                        return item.GroupName === 'PlacementEffortConcernsFather';
                    });
                    placementEffortConcernsFather = Ext.Array.pluck(placementEffortConcernsFather, 'CodeDescriptionID');
                    rec.set('PlacementEffortConcernsFather', placementEffortConcernsFather);

                    var placementEffortConcernsMother = ma.filter(function (item) {
                        return item.GroupName === 'PlacementEffortConcernsMother';
                    });
                    placementEffortConcernsMother = Ext.Array.pluck(placementEffortConcernsMother, 'CodeDescriptionID');
                    rec.set('PlacementEffortConcernsMother', placementEffortConcernsMother);

                    var effortsToSupportMotherFosterRelationship = ma.filter(function (item) {
                        return item.GroupName === 'EffortsToSupportMotherFosterRelationship';
                    });
                    effortsToSupportMotherFosterRelationship = Ext.Array.pluck(effortsToSupportMotherFosterRelationship, 'CodeDescriptionID');
                    rec.set('EffortsToSupportMotherFosterRelationship', effortsToSupportMotherFosterRelationship);

                    var effortsToSupportFatherFosterRelationship = ma.filter(function (item) {
                        return item.GroupName === 'EffortsToSupportFatherFosterRelationship';
                    });
                    effortsToSupportFatherFosterRelationship = Ext.Array.pluck(effortsToSupportFatherFosterRelationship, 'CodeDescriptionID');
                    rec.set('EffortsToSupportFatherFosterRelationship', effortsToSupportFatherFosterRelationship);

                    var fosterFederalCaseManagamentCriteria = ma.filter(function (item) {
                        return item.GroupName === 'FosterFederalCaseManagamentCriteria';
                    });
                    fosterFederalCaseManagamentCriteria = Ext.Array.pluck(fosterFederalCaseManagamentCriteria, 'CodeDescriptionID');
                    rec.set('FosterFederalCaseManagamentCriteria', fosterFederalCaseManagamentCriteria);
                    //
                    // Safety
                    //
                    rec.set('ItemApplicability51', this.getMultiAnswerValue(ma, 'Applicability', 51));
                    rec.set('ItemApplicability52', this.getMultiAnswerValue(ma, 'Applicability', 52));
                    rec.set('ItemApplicability53', this.getMultiAnswerValue(ma, 'Applicability', 53));
                    rec.set('ItemApplicability54', this.getMultiAnswerValue(ma, 'Applicability', 54));
                    rec.set('ItemApplicability55', this.getMultiAnswerValue(ma, 'Applicability', 55));
                    rec.set('ItemApplicability56', this.getMultiAnswerValue(ma, 'Applicability', 56));
                    //
                    // Permanency
                    //
                    rec.set('ItemApplicability57', this.getMultiAnswerValue(ma, 'Applicability', 57));
                    rec.set('ItemApplicability58', this.getMultiAnswerValue(ma, 'Applicability', 58));
                    rec.set('ItemApplicability59', this.getMultiAnswerValue(ma, 'Applicability', 59));
                    rec.set('ItemApplicability60', this.getMultiAnswerValue(ma, 'Applicability', 60));
                    rec.set('ItemApplicability61', this.getMultiAnswerValue(ma, 'Applicability', 61));
                    rec.set('ItemApplicability62', this.getMultiAnswerValue(ma, 'Applicability', 62));
                    rec.set('ItemApplicability63', this.getMultiAnswerValue(ma, 'Applicability', 63));
                    rec.set('ItemApplicability64', this.getMultiAnswerValue(ma, 'Applicability', 64));
                    rec.set('ItemApplicability65', this.getMultiAnswerValue(ma, 'Applicability', 65));
                    rec.set('ItemApplicability66', this.getMultiAnswerValue(ma, 'Applicability', 66));
                    rec.set('ItemApplicability67', this.getMultiAnswerValue(ma, 'Applicability', 67));
                    rec.set('ItemApplicability261', this.getMultiAnswerValue(ma, 'Applicability', 261));
                    //
                    // Wellbeing
                    //
                    rec.set('ItemApplicability68', this.getMultiAnswerValue(ma, 'Applicability', 68));
                    rec.set('ItemApplicability69', this.getMultiAnswerValue(ma, 'Applicability', 69));
                    rec.set('ItemApplicability70', this.getMultiAnswerValue(ma, 'Applicability', 70));
                    rec.set('ItemApplicability71', this.getMultiAnswerValue(ma, 'Applicability', 71));
                    rec.set('ItemApplicability72', this.getMultiAnswerValue(ma, 'Applicability', 72));
                    rec.set('ItemApplicability73', this.getMultiAnswerValue(ma, 'Applicability', 73));
                    rec.set('ItemApplicability74', this.getMultiAnswerValue(ma, 'Applicability', 74));
                    rec.set('ItemApplicability75', this.getMultiAnswerValue(ma, 'Applicability', 75));
                    rec.set('ItemApplicability76', this.getMultiAnswerValue(ma, 'Applicability', 76));
                    rec.set('ItemApplicability77', this.getMultiAnswerValue(ma, 'Applicability', 77));
                    rec.set('ItemApplicability78', this.getMultiAnswerValue(ma, 'Applicability', 78));
                    rec.set('ItemApplicability79', this.getMultiAnswerValue(ma, 'Applicability', 79));
                    rec.set('ItemApplicability80', this.getMultiAnswerValue(ma, 'Applicability', 80));
                    rec.set('ItemApplicability81', this.getMultiAnswerValue(ma, 'Applicability', 81));
                    rec.set('ItemApplicability82', this.getMultiAnswerValue(ma, 'Applicability', 82));
                    rec.set('ItemApplicability83', this.getMultiAnswerValue(ma, 'Applicability', 83));
                    rec.set('ItemApplicability292', this.getMultiAnswerValue(ma, 'Applicability', 292));
                    rec.set('ItemApplicability293', this.getMultiAnswerValue(ma, 'Applicability', 293));
                }
                var safety = rec.get('CR_Safety_Collection')[0];
                if (!Ext.isEmpty(safety)) {
                    rec.set('Safety', safety);

                    rec.set('ReportsNotInAccordance', safety.ReportsNotInAccordance);
                    rec.set('FaceToFaceReportsNotInAccordance', safety.FaceToFaceReportsNotInAccordance);
                    rec.set('DelayReason', safety.DelayReason);
                    rec.set('IsEffortToPreventReEntry', safety.IsEffortToPreventReEntry);
                    rec.set('EffortToPreventReEntryExplained', safety.EffortToPreventReEntryExplained);
                    rec.set('IsChildRemovedToEnsureSafety', safety.IsChildRemovedToEnsureSafety);
                    rec.set('ChildRemovedToEnsureSafetyExplained', safety.ChildRemovedToEnsureSafetyExplained);
                    rec.set('IsDelayBeyondAgencyControl', safety.IsDelayBeyondAgencyControl);

                    rec.set('IsFamilyMaltreatmentAllegations', safety.IsFamilyMaltreatmentAllegations);
                    rec.set('IsMaltreatmentNotSubstantiated', safety.IsMaltreatmentNotSubstantiated);
                    rec.set('IsInitialAssesmentForAllChildrenInHome', safety.IsInitialAssesmentForAllChildrenInHome);
                    rec.set('IsOngoingAssesementForAllChildrenInHome', safety.IsOngoingAssesementForAllChildrenInHome);
                    rec.set('IsSafetyPlanDevelopedAndMonitored', safety.IsSafetyPlanDevelopedAndMonitored);
                    rec.set('IsSafetyConcernForOtherChildren', safety.IsSafetyConcernForOtherChildren);
                    rec.set('IsFosterSafetyConcernDuringVisitation', safety.IsFosterSafetyConcernDuringVisitation);
                    rec.set('IsFosterSafetyConcernNotAddressed', safety.IsFosterSafetyConcernNotAddressed);

                    rec.set('InitialAssesmentForAllChildrenInHomeExplained', safety.InitialAssesmentForAllChildrenInHomeExplained);
                    rec.set('OngoingAssessmentForAllChildrenInHomeExplained', safety.OngoingAssessmentForAllChildrenInHomeExplained);
                    rec.set('SafetyPlanDevelopedAndMonitoredExplained', safety.SafetyPlanDevelopedAndMonitoredExplained);
                    rec.set('OtherSafetyConcernExplained', safety.OtherSafetyConcernExplained);
                    rec.set('FosterSafetyOtherExplained', safety.FosterSafetyOtherExplained);
                    rec.set('FosterPlacementConcerOtherExplained', safety.FosterPlacementConcerOtherExplained);


                }
                var outcomes = rec.get('CR_Outcome_Collection'),
                    outcome0 = this.getOutcome(outcomes, 21),
                    outcome1 = this.getOutcome(outcomes, 1),
                    outcome2 = this.getOutcome(outcomes, 2),
                    outcome3 = this.getOutcome(outcomes, 3),
                    outcome4 = this.getOutcome(outcomes, 4),
                    outcome5 = this.getOutcome(outcomes, 5),
                    outcome6 = this.getOutcome(outcomes, 6),
                    outcome7 = this.getOutcome(outcomes, 7),
                    item1, item2, item3, item4, item5, item6,
                    item7, item8, item9, item10, item11, item12, item12a,
                    item12b, item12c, item13, item14, item15, item16, item17, item18;


                if (outcomes && outcomes.length > 1) {
                    // var outcomes = ma.filter(function (item) { return item.OutcomeCode == 1;});
                    //outcomes[0] is for facesheet


                    if (outcome0) {
                        outcome0.RatingDesc = this.getOutcomeRatingDesc(outcome0.OutcomeRatingCode);
                    }
                    if (outcome1) {
                        item1 = this.getItem(outcome1.CR_Item_Collection, 2);
                        outcome1.RatingDesc = this.getOutcomeRatingDesc(outcome1.OutcomeRatingCode);
                    }
                    if (outcome2) {
                        item2 = this.getItem(outcome2.CR_Item_Collection, 3);
                        item3 = this.getItem(outcome2.CR_Item_Collection, 4);
                        outcome2.RatingDesc = this.getOutcomeRatingDesc(outcome2.OutcomeRatingCode);
                    }
                    if (outcome3) {
                        item4 = this.getItem(outcome3.CR_Item_Collection, 5);
                        item5 = this.getItem(outcome3.CR_Item_Collection, 6);
                        item6 = this.getItem(outcome3.CR_Item_Collection, 7);
                        outcome3.RatingDesc = this.getOutcomeRatingDesc(outcome3.OutcomeRatingCode);

                    }
                    if (outcome4) {
                        item7 = this.getItem(outcome4.CR_Item_Collection, 8);
                        item8 = this.getItem(outcome4.CR_Item_Collection, 9);
                        item9 = this.getItem(outcome4.CR_Item_Collection, 10);
                        item10 = this.getItem(outcome4.CR_Item_Collection, 11);
                        item11 = this.getItem(outcome4.CR_Item_Collection, 12);
                        outcome4.RatingDesc = this.getOutcomeRatingDesc(outcome4.OutcomeRatingCode);

                    }
                    if (outcome5) {
                        item12 = this.getItem(outcome5.CR_Item_Collection, 13);
                        item12a = this.getItem(outcome5.CR_Item_Collection, 14);
                        item12b = this.getItem(outcome5.CR_Item_Collection, 15);
                        item12c = this.getItem(outcome5.CR_Item_Collection, 16);
                        item13 = this.getItem(outcome5.CR_Item_Collection, 17);
                        item14 = this.getItem(outcome5.CR_Item_Collection, 18);
                        item15 = this.getItem(outcome5.CR_Item_Collection, 19);
                        outcome5.RatingDesc = this.getOutcomeRatingDesc(outcome5.OutcomeRatingCode);

                    }
                    if (outcome6) {
                        item16 = this.getItem(outcome6.CR_Item_Collection, 20);
                        outcome6.RatingDesc = this.getOutcomeRatingDesc(outcome6.OutcomeRatingCode);

                    }
                    if (outcome7) {
                        item17 = this.getItem(outcome7.CR_Item_Collection, 21);
                        item18 = this.getItem(outcome7.CR_Item_Collection, 22);
                        outcome7.RatingDesc = this.getOutcomeRatingDesc(outcome7.OutcomeRatingCode);
                    }


                    rec.set('Outcome1', outcome1);
                    rec.set('Outcome2', outcome2);
                    rec.set('Outcome3', outcome3);
                    rec.set('Outcome4', outcome4);
                    rec.set('Outcome5', outcome5);
                    rec.set('Outcome6', outcome6);
                    rec.set('Outcome7', outcome7);

                    if (item1) {

                        item1.RatingDesc = this.getRatingDesc(item1.ItemRatingCode)
                        rec.set('Item1IsApplicable', item1.IsApplicable == 0 ? null : item1.IsApplicable);
                        rec.set('Item1Comments', item1.Comments);
                        rec.set('Item1', item1);
                    }
                    if (item2) {
                        item2.RatingDesc = this.getRatingDesc(item2.ItemRatingCode)
                        rec.set('Item2IsApplicable', item2.IsApplicable == 0 ? null : item2.IsApplicable);
                        rec.set('Item2Comments', item2.Comments);
                        rec.set('Item2', item2);
                    }
                    if (item3) {
                        item3.RatingDesc = this.getRatingDesc(item3.ItemRatingCode)
                        rec.set('Item3IsApplicable', item3.IsApplicable == 0 ? null : item3.IsApplicable);
                        rec.set('Item3Comments', item3.Comments);
                        rec.set('Item3', item3);
                    }
                    if (item4) {
                        item4.RatingDesc = this.getRatingDesc(item4.ItemRatingCode)
                        rec.set('Item4IsApplicable', item4.IsApplicable == 0 ? null : item4.IsApplicable);
                        rec.set('Item4Comments', item4.Comments);
                        rec.set('Item4', item4);
                    }
                    if (item5) {
                        item5.RatingDesc = this.getRatingDesc(item5.ItemRatingCode)
                        rec.set('Item5IsApplicable', item5.IsApplicable == 0 ? null : item5.IsApplicable);
                        rec.set('Item5Comments', item5.Comments);
                        rec.set('Item5', item5);
                    }
                    if (item6) {
                        item6.RatingDesc = this.getRatingDesc(item6.ItemRatingCode)
                        rec.set('Item6IsApplicable', item6.IsApplicable == 0 ? null : item6.IsApplicable);
                        rec.set('Item6Comments', item6.Comments);
                        rec.set('Item6', item6);
                    }
                    if (item7) {
                        item7.RatingDesc = this.getRatingDesc(item7.ItemRatingCode)
                        rec.set('Item7IsApplicable', item7.IsApplicable == 0 ? null : item7.IsApplicable);
                        rec.set('Item7Comments', item7.Comments);
                        rec.set('Item7', item7);
                    }
                    if (item8) {
                        item8.RatingDesc = this.getRatingDesc(item8.ItemRatingCode)
                        rec.set('Item8IsApplicable', item8.IsApplicable == 0 ? null : item8.IsApplicable);
                        rec.set('Item8Comments', item8.Comments);
                        rec.set('Item8', item8);
                        rec.set('Item8ParticipantMother', this.getItemParticipant(item8, 269));
                        rec.set('Item8ParticipantFather', this.getItemParticipant(item8, 270));
                    }
                    if (item9) {
                        item9.RatingDesc = this.getRatingDesc(item9.ItemRatingCode)
                        rec.set('Item9IsApplicable', item9.IsApplicable == 0 ? null : item9.IsApplicable);
                        rec.set('Item9Comments', item9.Comments);
                        rec.set('Item9', item9);
                    }
                    if (item10) {
                        item10.RatingDesc = this.getRatingDesc(item10.ItemRatingCode)
                        rec.set('Item10IsApplicable', item10.IsApplicable == 0 ? null : item10.IsApplicable);
                        rec.set('Item10Comments', item10.Comments);
                        rec.set('Item10', item10);
                    }
                    if (item11) {
                        item11.RatingDesc = this.getRatingDesc(item11.ItemRatingCode)
                        rec.set('Item11IsApplicable', item11.IsApplicable == 0 ? null : item11.IsApplicable);
                        rec.set('Item11Comments', item11.Comments);
                        rec.set('Item11', item11);
                        rec.set('Item11ParticipantMother', this.getItemParticipant(item11, 269));
                        rec.set('Item11ParticipantFather', this.getItemParticipant(item11, 270));
                    }

                    if (item12) {
                        item12.RatingDesc = this.getRatingDesc(item12.ItemRatingCode)
                        rec.set('Item12IsApplicable', item12.IsApplicable == 0 ? null : item12.IsApplicable);
                        rec.set('Item12Comments', item12.Comments);
                        rec.set('Item12', item12);
                    }
                    if (item12a) {
                        item12a.RatingDesc = this.getRatingDesc(item12a.ItemRatingCode)
                        rec.set('Item12aIsApplicable', item12a.IsApplicable == 0 ? null : item12a.IsApplicable);
                        rec.set('Item12aComments', item12a.Comments);
                        rec.set('Item12a', item12a);
                        rec.set('Item12aParticipantChild', this.getItemParticipant(item12a, 271));
                    }
                    if (item12b) {
                        item12b.RatingDesc = this.getRatingDesc(item12b.ItemRatingCode)
                        rec.set('Item12bIsApplicable', item12b.IsApplicable == 0 ? null : item12b.IsApplicable);
                        rec.set('Item12bComments', item12b.Comments);
                        rec.set('Item12b', item12b);
                        rec.set('Item12bParticipantMother', this.getItemParticipant(item12b, 269));
                        rec.set('Item12bParticipantFather', this.getItemParticipant(item12b, 270));

                    }
                    if (item12c) {
                        item12c.RatingDesc = this.getRatingDesc(item12c.ItemRatingCode)
                        rec.set('Item12cIsApplicable', item12c.IsApplicable == 0 ? null : item12c.IsApplicable);
                        rec.set('Item12cComments', item12c.Comments);
                        rec.set('Item12c', item12c);
                    }

                    if (item13) {
                        item13.RatingDesc = this.getRatingDesc(item13.ItemRatingCode)
                        rec.set('Item13IsApplicable', item13.IsApplicable == 0 ? null : item13.IsApplicable);
                        rec.set('Item13Comments', item13.Comments);
                        rec.set('Item13', item13);
                        rec.set('Item13ParticipantChild', this.getItemParticipant(item13, 271));
                        rec.set('Item13ParticipantMother', this.getItemParticipant(item13, 269));
                        rec.set('Item13ParticipantFather', this.getItemParticipant(item13, 270));
                    }
                    if (item14) {
                        item14.RatingDesc = this.getRatingDesc(item14.ItemRatingCode)
                        rec.set('Item14IsApplicable', item14.IsApplicable == 0 ? null : item14.IsApplicable);
                        rec.set('Item14Comments', item14.Comments);
                        rec.set('Item14', item14);
                    }
                    if (item15) {
                        item15.RatingDesc = this.getRatingDesc(item15.ItemRatingCode)
                        rec.set('Item15IsApplicable', item15.IsApplicable == 0 ? null : item15.IsApplicable);
                        rec.set('Item15Comments', item15.Comments);
                        rec.set('Item15', item15);
                        rec.set('Item15ParticipantMother', this.getItemParticipant(item15, 269));
                        rec.set('Item15ParticipantFather', this.getItemParticipant(item15, 270));


                    }
                    if (item16) {
                        item16.RatingDesc = this.getRatingDesc(item16.ItemRatingCode)
                        rec.set('Item16IsApplicable', item16.IsApplicable == 0 ? null : item16.IsApplicable);
                        rec.set('Item16Comments', item16.Comments);
                        rec.set('Item16', item16);
                        rec.set('Item16ParticipantChild', this.getItemParticipant(item16, 271));
                    }
                    if (item17) {
                        item17.RatingDesc = this.getRatingDesc(item17.ItemRatingCode)
                        rec.set('Item17IsApplicable', item17.IsApplicable == 0 ? null : item17.IsApplicable);
                        rec.set('Item17Comments', item17.Comments);
                        rec.set('Item17', item17);
                        rec.set('Item17ParticipantChild', this.getItemParticipant(item17, 271));
                    }
                    if (item18) {
                        item18.RatingDesc = this.getRatingDesc(item18.ItemRatingCode)
                        rec.set('Item18IsApplicable', item18.IsApplicable == 0 ? null : item18.IsApplicable);
                        rec.set('Item18Comments', item18.Comments);
                        rec.set('Item18', item18);
                        rec.set('Item18ParticipantChild', this.getItemParticipant(item18, 271));

                    }
                }

                var permanency = rec.get('CR_Permanency_Collection')[0];
                if (!Ext.isEmpty(permanency)) {
                    rec.set('Permanency', permanency);
                    rec.set('NumberOfPlacementSettings', permanency.NumberOfPlacementSettings);
                    rec.set('WereAllPlacementChangesPlanned', permanency.WereAllPlacementChangesPlanned);
                    rec.set('IsCurrentPlacementSettingStable', permanency.IsCurrentPlacementSettingStable);
                    rec.set('PlacementApplicableCircumstancesOther', permanency.PlacementApplicableCircumstancesOther);
                    rec.set('Goal1Code', permanency.Goal1Code);
                    rec.set('Goal2Code', permanency.Goal2Code);
                    rec.set('IsGoalSpecified', permanency.IsGoalSpecified);
                    rec.set('WereAllGoalsInTimelyManner', permanency.WereAllGoalsInTimelyManner);
                    rec.set('AllGoalsInTimelyMannerExplained', permanency.AllGoalsInTimelyMannerExplained);
                    rec.set('WereAllGoalsAppropriate', permanency.WereAllGoalsAppropriate);
                    rec.set('AllGoalsAppropriateExplained', permanency.AllGoalsAppropriateExplained);
                    rec.set('IsInFoster15OutOf22', permanency.IsInFoster15OutOf22);
                    rec.set('MeetsTerminationOfParentalRights', permanency.MeetsTerminationOfParentalRights);
                    rec.set('IsAgencyJointTerminationOfParentalRights', permanency.IsAgencyJointTerminationOfParentalRights);
                    rec.set('IsExceptionForTermination', permanency.IsExceptionForTermination);

                    rec.set('ChildMostRecentFosterEntryDate', permanency.ChildMostRecentFosterEntryDate);
                    rec.set('TimeInCare', permanency.TimeInCare);
                    rec.set('DischargeDate', permanency.DischargeDate);
                    rec.set('IsDischargeDateNA', permanency.IsDischargeDateNA);
                    rec.set('IsAgencyConcertedEfforts', permanency.IsAgencyConcertedEfforts);
                    rec.set('AgencyConcertedEffortsExplained', permanency.AgencyConcertedEffortsExplained);
                    rec.set('OtherPlannedArrangementDocumentationDate', permanency.OtherPlannedArrangementDocumentationDate);
                    rec.set('IsOtherPlannedArrangement', permanency.IsOtherPlannedArrangement);
                    rec.set('IsOtherPlannedArrangementNA', permanency.IsOtherPlannedArrangementNA);
                    rec.set('IsOtherPlannedArrangementNoDate', permanency.IsOtherPlannedArrangementNoDate);
                    rec.set('IsOtherPlannedConcertedEffort', permanency.IsOtherPlannedConcertedEffort);
                    rec.set('OtherPlannedConcertedEffortExplained', permanency.OtherPlannedConcertedEffortExplained);
                    rec.set('LivingArrangementCode', permanency.LivingArrangementCode);
                    rec.set('LivingArrangementExplained', permanency.LivingArrangementExplained);

                    rec.set('IsPlacedWithAllSiblings', permanency.IsPlacedWithAllSiblings);
                    rec.set('IsValidReasonForSeparation', permanency.IsValidReasonForSeparation);
                    rec.set('ValidReasonForSeparationExplained', permanency.ValidReasonForSeparationExplained);

                    rec.set('MotherVisitationFrequencyCode', permanency.MotherVisitationFrequencyCode);
                    rec.set('IsSufficientFrequencyForMotherVisitation', permanency.IsSufficientFrequencyForMotherVisitation);
                    rec.set('FatherVisitationFrequencyCode', permanency.FatherVisitationFrequencyCode);
                    rec.set('IsSufficientFrequencyForFatherVisitation', permanency.IsSufficientFrequencyForFatherVisitation);
                    rec.set('IsSufficientQualityForMotherVisitation', permanency.IsSufficientQualityForMotherVisitation);
                    rec.set('IsSufficentQualityForFatherVisitation', permanency.IsSufficentQualityForFatherVisitation);
                    rec.set('SiblingVisitationFrequencyCode', permanency.SiblingVisitationFrequencyCode);
                    rec.set('IsSufficientFrequencyForSiblingVisitation', permanency.IsSufficientFrequencyForSiblingVisitation);
                    rec.set('IsSufficentQualityForSiblingVisitation', permanency.IsSufficentQualityForSiblingVisitation);

                    rec.set('IsConcertedEffortsForImportantConnections', permanency.IsConcertedEffortsForImportantConnections);
                    rec.set('IsSufficientInquiryForIndianTribe', permanency.IsSufficientInquiryForIndianTribe);
                    rec.set('IsTribeProvidedTimelyNotification', permanency.IsTribeProvidedTimelyNotification);
                    rec.set('IsAccordanceWithIndianChildWelfareAct', permanency.IsAccordanceWithIndianChildWelfareAct);

                    rec.set('IsRecentPlacementWithRelative', permanency.IsRecentPlacementWithRelative);
                    rec.set('IsPlacementWithRelativeStable', permanency.IsPlacementWithRelativeStable);
                    rec.set('IsConcertedEffortToLocateMaternalRelatives', permanency.IsConcertedEffortToLocateMaternalRelatives);
                    rec.set('IsConcertedEffortToLocatePaternalRelatives', permanency.IsConcertedEffortToLocatePaternalRelatives);

                    rec.set('IsConcertedEffortMotherFosterRelationship', permanency.IsConcertedEffortMotherFosterRelationship);
                    rec.set('IsConcertedEffortFatherFosterRelationship', permanency.IsConcertedEffortFatherFosterRelationship);
                    rec.set('EffortsMotherFosterOther', permanency.EffortsMotherFosterOther);
                    rec.set('EffortFatherFosterRelationshipOther', permanency.EffortFatherFosterRelationshipOther);


                }

                var wb = rec.get('CR_WellBeing_Collection')[0];
                if (!Ext.isEmpty(wb)) {
                    rec.set('WellBeing', wb);
                    //item 12a
                    rec.set('IsComprehensiveAssessementConducted', wb.IsComprehensiveAssessementConducted);
                    rec.set('IsAppropriateServicesProvided', wb.IsAppropriateServicesProvided);
                    rec.set('ComprehensiveAssessmentExplained', wb.ComprehensiveAssessmentExplained);
                    rec.set('AppropriateServicesProvidedExplained', wb.AppropriateServicesProvidedExplained);
                    //item 12b
                    rec.set('IsComprehensiveAssessementForMotherConducted', wb.IsComprehensiveAssessementForMotherConducted);
                    rec.set('ComprehensiveAssessementForMotherExplained', wb.ComprehensiveAssessementForMotherExplained);
                    rec.set('IsComprehensiveAssessementForFatherConducted', wb.IsComprehensiveAssessementForFatherConducted);
                    rec.set('ComprehensiveAssessementforFatherConductedExplained', wb.ComprehensiveAssessementforFatherConductedExplained);
                    rec.set('IsAppropriateServicesForMotherProvided', wb.IsAppropriateServicesForMotherProvided);
                    rec.set('AppropriateServicesForMotherExplained', wb.AppropriateServicesForMotherExplained);
                    rec.set('IsAppropriateServicesForFatherProvided', wb.IsAppropriateServicesForFatherProvided);
                    rec.set('AppropriateServicesForFatherExplained', wb.AppropriateServicesForFatherExplained);
                    rec.set('IsNeedsServicesApplicableForMother', wb.IsNeedsServicesApplicableForMother);
                    rec.set('IsNeedsServicesApplicableForFather', wb.IsNeedsServicesApplicableForFather);
                    //item 12c
                    rec.set('IsNeedsOfFosterParentsAdequatelyAssessed', wb.IsNeedsOfFosterParentsAdequatelyAssessed);
                    rec.set('NeedsOfFosterParentsAdequatelyAssessedExplained', wb.NeedsOfFosterParentsAdequatelyAssessedExplained);
                    rec.set('IsFosterParentsProvidedAppropriateServices', wb.IsFosterParentsProvidedAppropriateServices);
                    rec.set('FosterParentsProvidedAppropriateServicesExplained', wb.FosterParentsProvidedAppropriateServicesExplained);
                    //item 13
                    rec.set('IsAgencyConcertedEffortsToInvolveTheChild', wb.IsAgencyConcertedEffortsToInvolveTheChild);
                    rec.set('AgencyConcertedEffortsToInvolveTheChildExplained', wb.AgencyConcertedEffortsToInvolveTheChildExplained);
                    rec.set('IsAgencyConcertedEffortsToInvolveTheMother', wb.IsAgencyConcertedEffortsToInvolveTheMother);
                    rec.set('AgencyConcertedEffortsToInvolveTheMotherExplained', wb.AgencyConcertedEffortsToInvolveTheMotherExplained);
                    rec.set('IsAgencyConcertedEffortsToInvolveTheFather', wb.IsAgencyConcertedEffortsToInvolveTheFather);
                    rec.set('AgencyConcertedEffortsToInvolveTheFatherExplained', wb.AgencyConcertedEffortsToInvolveTheFatherExplained);
                    //item 14
                    rec.set('ResponsiblePartyVisitationFrequencyCode', wb.ResponsiblePartyVisitationFrequencyCode);
                    rec.set('IsResponsiblePartyVisitationFrequencySufficient', wb.IsResponsiblePartyVisitationFrequencySufficient);
                    rec.set('IsResponsiblePartyVisitationQualitySufficient', wb.IsResponsiblePartyVisitationQualitySufficient);
                    rec.set('ResponsiblePartyVisitationQualityExplained', wb.ResponsiblePartyVisitationQualityExplained);
                    //item 15
                    rec.set('ResponsiblePartyVisitationFrequencyWithMotherCode', wb.ResponsiblePartyVisitationFrequencyWithMotherCode);
                    rec.set('IsResponsiblePartyVisitationFrequencyWithMotherSufficient', wb.IsResponsiblePartyVisitationFrequencyWithMotherSufficient);
                    rec.set('ResponsiblePartyVisitationFrequencyWithFatherCode', wb.ResponsiblePartyVisitationFrequencyWithFatherCode);
                    rec.set('IsResponsiblePartyVisitationFrequencyWithFatherSufficient', wb.IsResponsiblePartyVisitationFrequencyWithFatherSufficient);
                    rec.set('IsResponsiblePartyVisitationQualityWithMotherSufficient', wb.IsResponsiblePartyVisitationQualityWithMotherSufficient);
                    rec.set('IsResponsiblePartyVisitationQualityWithFatherSufficient', wb.IsResponsiblePartyVisitationQualityWithFatherSufficient);
                    rec.set('ResponsiblePartyVisitationQualityWithMotherExplained', wb.ResponsiblePartyVisitationQualityWithMotherExplained);
                    rec.set('ResponsiblePartyVisitationQualityWithFatherExplained', wb.ResponsiblePartyVisitationQualityWithFatherExplained);

                    rec.set('IsAgencyAssessEducationNeeds', wb.IsAgencyAssessEducationNeeds);
                    rec.set('IsAgencyAddressEducationNeeds', wb.IsAgencyAddressEducationNeeds);

                    rec.set('IsAgencyAssessPhysicalHealthNeeds', wb.IsAgencyAssessPhysicalHealthNeeds);
                    rec.set('IsAgencyAssessDentalHealthNeeds', wb.IsAgencyAssessDentalHealthNeeds);
                    rec.set('IsFosterOversightMedicationForPhysicalHealtyAppropriate', wb.IsFosterOversightMedicationForPhysicalHealtyAppropriate);
                    rec.set('IsAppropriateSerivcesForAllPhysicalHealthNeeds', wb.IsAppropriateSerivcesForAllPhysicalHealthNeeds);
                    rec.set('IsAppropriateServicesForAllDentalNeeds', wb.IsAppropriateServicesForAllDentalNeeds);

                    rec.set('IsAgencyAssessMentalHealthNeeds', wb.IsAgencyAssessMentalHealthNeeds);
                    rec.set('IsFosterOversightMedicationForMentalHealtyAppropriate', wb.IsFosterOversightMedicationForMentalHealtyAppropriate);
                    rec.set('IsAppropriateSerivcesForMentalHealthNeeds', wb.IsAppropriateSerivcesForMentalHealthNeeds);
                }

            },
            getRatingDesc: function (code) {
                return code == 1 ? 'Strength' :
                    code == 2 ? 'Area Needing Improvement' :
                        code == 3 ? 'NA' :
                            code == 4 ? 'Unable to Rate' : 'Not Yet Rated';
            },
            getOutcomeRatingDesc: function (code) {
                return code == 1 ? 'Substantially Achieved' :
                    code == 2 ? 'Partially Achieved' :
                        code == 3 ? 'Not Achieved' :
                            code == 4 ? 'NA' : 'Not Yet Rated';
            },

            getMultiAnswerValue: function (arr, group, codeDescId) {
                var val = undefined;
                if (arr) {

                    var data = arr.filter(function (item) {
                        return item.GroupName == group && item.CodeDescriptionID == codeDescId;
                    });
                    if (!Ext.isEmpty(data) && Ext.isArray(data) && data.length > 0) {
                        val = data[0].AnswerCode
                    }
                }
                return val;
            },
            getItemParticipant: function (item, roleCode) {

                var participants = item.CR_ItemParticipant_Collection;
                var mp = participants.filter(function (p) {
                    return p.CodeDescriptionID == roleCode && p.ParticipantID != null;
                });
                mp = Ext.Array.pluck(mp, 'ParticipantID');
                return mp;
            },
            toArray: function (value) {
                if (Ext.isEmpty(value))
                    return [];
                if (!Ext.isArray(value))
                    return [value];
                return value;
            },
            getOutcome: function (arr, outcomeCode) {
                if (arr == null || !Ext.isArray(arr))
                    return null;
                return arr.filter(function (item) {
                    return item.OutcomeCode == outcomeCode;
                })[0];
            },
            getItem: function (arr, itemCode) {
                if (arr == null || !Ext.isArray(arr))
                    return null;
                return arr.filter(function (item) {
                    return item.ItemCode == itemCode;
                })[0];
            }
        },

        {
            name: 'FaceSheet',
            calculate: function (data) {

                if (!Ext.isEmpty(data) && !Ext.isEmpty(data.CR_FaceSheet_Collection) && data.CR_FaceSheet_Collection.length > 0) {
                    var fs = data.CR_FaceSheet_Collection[0];
                    return fs;
                }
                return null;
            }
        },
        {name: 'FirstCaseOpeningDate', type: 'date'},
        {name: 'FosterEntryDate', type: 'date'},
        {name: 'EpisodeDischargeDate', type: 'date'},
        {name: 'CaseClosureDate', type: 'date'},
        {name: 'IsFosterEntryDateNA', type: 'int', allowNull: true},
        {name: 'IsEpisodeDischargeDateNA', type: 'int', allowNull: true},
        {name: 'IsEpisodeNotYetDischarged', type: 'int', allowNull: true},
        {name: 'IsCaseClosureNotClosed', type: 'int', allowNull: true},
        {name: 'IsCaseOpenReasonOtherAbuseNeglect', type: 'int', allowNull: true},
        // {name: 'CaseReasons', defaultValue: {CaseReasons: []}},
        {name: 'CaseReasons', defaultValue: []},
        {name: 'OtherCaseReason', type: 'string'},

        {name: 'Safety'},
        {name: 'Outcome1'},
        {name: 'Outcome2'},

        {name: 'Item1'},
        {name: 'Item1IsApplicable', type: 'int', allowNull: true},
        {name: 'Item1Comments', type: 'string'},
        {name: 'ReportsNotInAccordance', type: 'int'},
        {name: 'FaceToFaceReportsNotInAccordance', type: 'int'},
        {name: 'DelayReason', type: 'string'},

        {name: 'IsChildRemovedToEnsureSafety', type: 'int', allowNull: true},
        {name: 'IsDelayBeyondAgencyControl', type: 'int', allowNull: true},

        {name: 'Item2'},
        {name: 'Item2IsApplicable', type: 'int', allowNull: true},
        {name: 'Item2Comments', type: 'string'},
        {name: 'IsEffortToPreventReEntry', type: 'int', allowNull: true},
        {name: 'EffortToPreventReEntryExplained', type: 'string'},
        {name: 'IsChildRemovedToEnsureSafety', type: 'int', allowNull: true},
        {name: 'ChildRemovedToEnsureSafetyExplained', type: 'string'},


        {name: 'Item3'},
        {name: 'Item3IsApplicable', type: 'int', allowNull: true},
        {name: 'Item3Comments', type: 'string'},

        {name: 'IsFamilyMaltreatmentAllegations', type: 'int', allowNull: true},
        {name: 'IsMaltreatmentNotSubstantiated', type: 'int', allowNull: true},
        {name: 'IsInitialAssesmentForAllChildrenInHome', type: 'int', allowNull: true},
        {name: 'IsOngoingAssesementForAllChildrenInHome', type: 'int', allowNull: true},
        {name: 'IsSafetyPlanDevelopedAndMonitored', type: 'int', allowNull: true},
        {name: 'IsSafetyConcernForOtherChildren', type: 'int', allowNull: true},
        {name: 'IsFosterSafetyConcernDuringVisitation', type: 'int', allowNull: true},
        {name: 'IsFosterSafetyConcernNotAddressed', type: 'int', allowNull: true},

        {name: 'InitialAssesmentForAllChildrenInHomeExplained', type: 'string'},
        {name: 'OngoingAssessmentForAllChildrenInHomeExplained', type: 'string'},
        {name: 'SafetyPlanDevelopedAndMonitoredExplained', type: 'string'},
        {name: 'OtherSafetyConcernExplained', type: 'string'},
        {name: 'FosterSafetyOtherExplained', type: 'string'},
        {name: 'FosterPlacementConcerOtherExplained', type: 'string'},

        {name: 'SafetyRelatedIncidents', defaultValue: []},
        {name: 'FosterSafety', defaultValue: []},
        {name: 'FosterPlacementConcern', defaultValue: []},

        {name: 'Permanency'},
        {name: 'NumberOfPlacementSettings', type: 'int', allowNull: true},
        {name: 'PlacementApplicableCircumstances', defaultValue: []},
        {name: 'PlacementApplicableCircumstancesOther', type: 'string'},
        {name: 'IsCurrentPlacementSettingStable', type: 'int'},
        {name: 'WereAllPlacementChangesPlanned', type: 'int'},

        {name: 'Outcome3'},
        {name: 'Item4IsApplicable', type: 'int', allowNull: true},
        {name: 'Item4Comments', type: 'string'},
        {name: 'Item5IsApplicable', type: 'int'},
        {name: 'Item5Comments', type: 'string'},
        {name: 'Item6IsApplicable', type: 'int'},
        {name: 'Item6Comments', type: 'string'},
        {name: 'Goal1Code', type: 'int', allowNull: true},
        {name: 'Goal2Code', type: 'int', allowNull: true},
        {name: 'IsGoalSpecified', type: 'int', allowNull: true},
        {name: 'WereAllGoalsInTimelyManner', type: 'int', allowNull: true},
        {name: 'AllGoalsInTimelyMannerExplained', type: 'string'},
        {name: 'WereAllGoalsAppropriate', type: 'int', allowNull: true},
        {name: 'AllGoalsAppropriateExplained', type: 'string'},
        {name: 'IsInFoster15OutOf22', type: 'int', allowNull: true},
        {name: 'MeetsTerminationOfParentalRights', type: 'int', allowNull: true},
        {name: 'IsAgencyJointTerminationOfParentalRights', type: 'int', allowNull: true},
        {name: 'IsExceptionForTermination', type: 'int', allowNull: true},
        {name: 'TerminationExceptions', defaultValue: []},


        {name: 'Item4'},

        {name: 'Item5'},

        {name: 'Item6'},
        {name: 'PermanencyGoal1', defaultValue: []},
        {name: 'ChildMostRecentFosterEntryDate', type: 'date'},
        {name: 'TimeInCare', type: 'int', allowNull: true},
        {name: 'DischargeDate', type: 'date'},
        {name: 'IsDischargeDateNA', type: 'int', allowNull: true},

        {name: 'IsAgencyConcertedEfforts', type: 'int', allowNull: true},
        {name: 'AgencyConcertedEffortsExplained', type: 'string'},
        {name: 'LivingArrangementCode', type: 'int', allowNull: true},
        {name: 'LivingArrangementExplained', type: 'string'},
        {name: 'OtherPlannedArrangementDocumentationDate', type: 'date'},
        {name: 'isOtherPlannedArrangement', type: 'int', allowNull: true},
        {name: 'IsOtherPlannedArrangementNA', type: 'int', allowNull: true},
        {name: 'IsOtherPlannedArrangementNoDate', type: 'int', allowNull: true},
        {name: 'IsOtherPlannedConcertedEffort', type: 'int', allowNull: true},
        {name: 'OtherPlannedConcertedEffortExplained', type: 'string'},

        {name: 'Outcome4'},
        {name: 'Item7'},
        {name: 'Item7IsApplicable', type: 'int', allowNull: true},
        {name: 'Item7Comments', type: 'string'},
        {name: 'IsPlacedWithAllSiblings', type: 'int', allowNull: true},
        {name: 'IsValidReasonForSeparation', type: 'int', allowNull: true},
        {name: 'ValidReasonForSeparationExplained', type: 'string'},

        {name: 'Item8'},
        {name: 'Item8IsApplicable', type: 'int', allowNull: true},
        {name: 'Item8Comments', type: 'string'},
        {name: 'MotherVisitationFrequencyCode', type: 'int', allowNull: true},
        {name: 'IsSufficientFrequencyForMotherVisitation', type: 'int', allowNull: true},
        {name: 'FatherVisitationFrequencyCode', type: 'int', allowNull: true},
        {name: 'IsSufficientFrequencyForFatherVisitation', type: 'int', allowNull: true},
        {name: 'IsSufficientQualityForMotherVisitation', type: 'int', allowNull: true},
        {name: 'IsSufficentQualityForFatherVisitation', type: 'int', allowNull: true},
        {name: 'SiblingVisitationFrequencyCode', type: 'int', allowNull: true},
        {name: 'IsSufficientFrequencyForSiblingVisitation', type: 'int', allowNull: true},
        {name: 'IsSufficentQualityForSiblingVisitation', type: 'int', allowNull: true},
        {name: 'Item8ParticipantMother', defaultValue: []},
        {name: 'Item8ParticipantFather', defaultValue: []},

        {name: 'Item9'},
        {name: 'Item9IsApplicable', type: 'int', allowNull: true},
        {name: 'Item9Comments', type: 'string'},
        {name: 'IsConcertedEffortsForImportantConnections', type: 'int', allowNull: true},
        {name: 'IsSufficientInquiryForIndianTribe', type: 'int', allowNull: true},
        {name: 'IsTribeProvidedTimelyNotification', type: 'int', allowNull: true},
        {name: 'IsAccordanceWithIndianChildWelfareAct', type: 'int', allowNull: true},


        {name: 'Item10'},
        {name: 'Item10IsApplicable', type: 'int', allowNull: true},
        {name: 'Item10Comments', type: 'string'},
        {name: 'IsRecentPlacementWithRelative', type: 'int', allowNull: true},
        {name: 'IsPlacementWithRelativeStable', type: 'int', allowNull: true},
        {name: 'IsConcertedEffortToLocateMaternalRelatives', type: 'int', allowNull: true},
        {name: 'IsConcertedEffortToLocatePaternalRelatives', type: 'int', allowNull: true},
        {name: 'PlacementEffortConcernsMother', defaultValue: []},
        {name: 'PlacementEffortConcernsFather', defaultValue: []},

        {name: 'Item11'},
        {name: 'Item11IsApplicable', type: 'int', allowNull: true},
        {name: 'Item11Comments', type: 'string'},
        {name: 'IsConcertedEffortMotherFosterRelationship', type: 'int', allowNull: true},
        {name: 'IsConcertedEffortFatherFosterRelationship', type: 'int', allowNull: true},
        {name: 'EffortsToSupportMotherFosterRelationship', defaultValue: []},
        {name: 'EffortsToSupportFatherFosterRelationship', defaultValue: []},
        {name: 'EffortsMotherFosterOther', type: 'string'},
        {name: 'EffortFatherFosterRelationshipOther', type: 'string'},
        {name: 'Item11ParticipantMother', defaultValue: []},
        {name: 'Item11ParticipantFather', defaultValue: []},

        {name: 'WellBeing'},

        {name: 'Outcome5'},
        {name: 'Item12'},
        {name: 'Item12IsApplicable', type: 'int', allowNull: true},
        {name: 'Item12Comments', type: 'string'},

        {name: 'Item12a'},
        {name: 'Item12aIsApplicable', type: 'int'},
        {name: 'Item12aComments', type: 'string'},
        {name: 'IsComprehensiveAssessementConducted', type: 'int', allowNull: true},
        {name: 'ComprehensiveAssessmentExplained', type: 'string'},
        {name: 'IsAppropriateServicesProvided', type: 'int', allowNull: true},
        {name: 'AppropriateServicesProvidedExplained', type: 'string'},
        {name: 'Item12aParticipantChild', defaultValue: []},


        {name: 'Item12b'},
        {name: 'Item12bIsApplicable', type: 'int', allowNull: true},
        {name: 'Item12bComments', type: 'string'},
        {name: 'IsComprehensiveAssessementForMotherConducted', type: 'int', allowNull: true},
        {name: 'ComprehensiveAssessementForMotherExplained', type: 'string'},
        {name: 'IsComprehensiveAssessementForFatherConducted', type: 'int', allowNull: true},
        {name: 'ComprehensiveAssessementforFatherConductedExplained', type: 'string'},
        {name: 'IsAppropriateServicesForMotherProvided', type: 'int', allowNull: true},
        {name: 'AppropriateServicesForMotherExplained', type: 'string'},
        {name: 'IsAppropriateServicesForFatherProvided', type: 'int', allowNull: true},
        {name: 'AppropriateServicesForFatherExplained', type: 'string'},
        {name: 'IsNeedsServicesApplicableForMother', type: 'int', allowNull: true},
        {name: 'IsNeedsServicesApplicableForFather', type: 'int', allowNull: true},
        {name: 'Item12bParticipantMother', defaultValue: []},
        {name: 'Item12bParticipantFather', defaultValue: []},


        {name: 'Item12c'},
        {name: 'Item12cIsApplicable', type: 'int', allowNull: true},
        {name: 'Item12cComments', type: 'string'},
        {name: 'IsNeedsOfFosterParentsAdequatelyAssessed', type: 'int', allowNull: true},
        {name: 'NeedsOfFosterParentsAdequatelyAssessedExplained', type: 'string'},
        {name: 'IsFosterParentsProvidedAppropriateServices', type: 'int', allowNull: true},
        {name: 'FosterParentsProvidedAppropriateServicesExplained', type: 'string'},

        {name: 'Item13'},
        {name: 'Item13IsApplicable', type: 'int', allowNull: true},
        {name: 'Item13Comments', type: 'string'},

        {name: 'IsAgencyConcertedEffortsToInvolveTheChild', type: 'int', allowNull: true},
        {name: 'AgencyConcertedEffortsToInvolveTheChildExplained', type: 'string'},
        {name: 'IsAgencyConcertedEffortsToInvolveTheMother', type: 'int', allowNull: true},
        {name: 'AgencyConcertedEffortsToInvolveTheMotherExplained', type: 'string'},
        {name: 'IsAgencyConcertedEffortsToInvolveTheFather', type: 'int', allowNull: true},
        {name: 'AgencyConcertedEffortsToInvolveTheFatherExplained', type: 'string'},
        {name: 'Item13ParticipantMother', defaultValue: []},
        {name: 'Item13ParticipantFather', defaultValue: []},
        {name: 'Item13ParticipantChild', defaultValue: []},

        {name: 'Item14'},
        {name: 'Item14IsApplicable', type: 'int', allowNull: true},
        {name: 'Item14Comments', type: 'string'},
        {name: 'ResponsiblePartyVisitationFrequencyCode', type: 'int', allowNull: true},
        {name: 'IsResponsiblePartyVisitationFrequencySufficient', type: 'int', allowNull: true},
        {name: 'IsResponsiblePartyVisitationQualitySufficient', type: 'int', allowNull: true},
        {name: 'ResponsiblePartyVisitationQualityExplained', type: 'string'},

        {name: 'Item15'},
        {name: 'Item15IsApplicable', type: 'int', allowNull: true},
        {name: 'Item15Comments', type: 'string'},
        {name: 'ResponsiblePartyVisitationFrequencyWithMotherCode', type: 'int', allowNull: true},
        {name: 'IsResponsiblePartyVisitationFrequencyWithMotherSufficient', type: 'int', allowNull: true},
        {name: 'ResponsiblePartyVisitationFrequencyWithFatherCode', type: 'int', allowNull: true},
        {name: 'IsResponsiblePartyVisitationFrequencyWithFatherSufficient', type: 'int', allowNull: true},
        {name: 'IsResponsiblePartyVisitationQualityWithMotherSufficient', type: 'int', allowNull: true},
        {name: 'IsResponsiblePartyVisitationQualityWithFatherSufficient', type: 'int', allowNull: true},
        {name: 'ResponsiblePartyVisitationQualityWithMotherExplained', type: 'string'},
        {name: 'ResponsiblePartyVisitationQualityWithFatherExplained', type: 'string'},
        {name: 'Item15ParticipantMother', defaultValue: []},
        {name: 'Item15ParticipantFather', defaultValue: []},


        {name: 'Outcome6'},
        {name: 'Item16'},
        {name: 'Item16IsApplicable', type: 'int', allowNull: true},
        {name: 'Item16Comments', type: 'string'},
        {name: 'Item16ParticipantChild', defaultValue: []},

        {name: 'Outcome7'},
        {name: 'Item17'},
        {name: 'Item17IsApplicable', type: 'int', allowNull: true},
        {name: 'Item17Comments', type: 'string'},
        {name: 'IsAgencyAssessPhysicalHealthNeeds', type: 'int', allowNull: true},
        {name: 'IsAgencyAssessDentalHealthNeeds', type: 'int', allowNull: true},
        {name: 'FosterFederalCaseManagamentCriteria', defaultValue: []},
        {name: 'IsFosterOversightMedicationForPhysicalHealtyAppropriate', type: 'int', allowNull: true},
        {name: 'IsAppropriateSerivcesForAllPhysicalHealthNeeds', type: 'int', allowNull: true},
        {name: 'IsAppropriateServicesForAllDentalNeeds', type: 'int', allowNull: true},
        {name: 'Item17ParticipantChild', defaultValue: []},

        {name: 'Item18'},
        {name: 'Item18IsApplicable', type: 'int', allowNull: true},
        {name: 'Item18Comments', type: 'string'},
        {name: 'IsAgencyAssessMentalHealthNeeds', type: 'int', allowNull: true},
        {name: 'IsFosterOversightMedicationForMentalHealtyAppropriate', type: 'int', allowNull: true},
        {name: 'IsAppropriateSerivcesForMentalHealthNeeds', type: 'int', allowNull: true},
        {name: 'Item18ParticipantChild', defaultValue: []},


        {name: 'ItemApplicability51', type: 'int', allowNull: true},
        {name: 'ItemApplicability52', type: 'int', allowNull: true},
        {name: 'ItemApplicability53', type: 'int', allowNull: true},
        {name: 'ItemApplicability54', type: 'int', allowNull: true},
        {name: 'ItemApplicability55', type: 'int', allowNull: true},
        {name: 'ItemApplicability56', type: 'int', allowNull: true},
        {name: 'ItemApplicability57', type: 'int', allowNull: true},
        {name: 'ItemApplicability58', type: 'int', allowNull: true},
        {name: 'ItemApplicability59', type: 'int', allowNull: true},
        {name: 'ItemApplicability60', type: 'int', allowNull: true},
        {name: 'ItemApplicability61', type: 'int', allowNull: true},
        {name: 'ItemApplicability62', type: 'int', allowNull: true},
        {name: 'ItemApplicability63', type: 'int', allowNull: true},
        {name: 'ItemApplicability64', type: 'int', allowNull: true},
        {name: 'ItemApplicability65', type: 'int', allowNull: true},
        {name: 'ItemApplicability66', type: 'int', allowNull: true},
        {name: 'ItemApplicability67', type: 'int', allowNull: true},
        {name: 'ItemApplicability68', type: 'int', allowNull: true},
        {name: 'ItemApplicability69', type: 'int', allowNull: true},
        {name: 'ItemApplicability70', type: 'int', allowNull: true},
        {name: 'ItemApplicability71', type: 'int', allowNull: true},
        {name: 'ItemApplicability72', type: 'int', allowNull: true},
        {name: 'ItemApplicability73', type: 'int', allowNull: true},
        {name: 'ItemApplicability74', type: 'int', allowNull: true},
        {name: 'ItemApplicability75', type: 'int', allowNull: true},
        {name: 'ItemApplicability76', type: 'int', allowNull: true},
        {name: 'ItemApplicability77', type: 'int', allowNull: true},
        {name: 'ItemApplicability78', type: 'int', allowNull: true},
        {name: 'ItemApplicability79', type: 'int', allowNull: true},
        {name: 'ItemApplicability80', type: 'int', allowNull: true},
        {name: 'ItemApplicability81', type: 'int', allowNull: true},
        {name: 'ItemApplicability82', type: 'int', allowNull: true},
        {name: 'ItemApplicability83', type: 'int', allowNull: true},
        {name: 'ItemApplicability261', type: 'int', allowNull: true},
        {name: 'ItemApplicability292', type: 'int', allowNull: true},
        {name: 'ItemApplicability293', type: 'int', allowNull: true}
    ],

    // proxy: {
    //     type: 'api',
    //     url: '~api/casereview/casereviews'
    //
    // },

    getFaceSheet: function (data) {
        if (!Ext.isEmpty(data) && !Ext.isEmpty(data.CR_FaceSheet_Collection) && data.CR_FaceSheet_Collection.length > 0) {
            var fs = data.CR_FaceSheet_Collection[0];
            return fs;
        }
        return null;
    },
    convertDateIfString: function (data) {
        if (!Ext.isEmpty(data))
            return null;
        return Ext.isDate(data) ? data : new Date(data);
    },
    validators: {

        // CaseID: {type: 'presence'},
        // CaseName: 'presence',
        // ReviewStartDate: 'presence',
        // ReviewCompleted: 'presence',
        // Reviewers: ['presence'],
        // InitialQAUserID: ['presence'],
        // SecondQAUserID: ['presence'],
        // SecondaryOversightUserID: ['presence'],
        // CtSecondaryOversightUserID: ['presence'],
        // gender: { type: 'inclusion', list: ['Male', 'Female'] },
        // username: [
        //     { type: 'exclusion', list: ['Admin', 'Operator'] },
        //     { type: 'format', matcher: /([a-z]+)[0-9]{2,3}/i }
        // ]
    }

});