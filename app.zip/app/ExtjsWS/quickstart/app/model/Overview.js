/**
 * Created by kkora on 9/25/2017.
 */
Ext.define('QuickStart.model.Overview', {
    extend: 'QuickStart.model.Base',

    fields: [

        { name: 'Header',     type: 'string' },
        { name: 'SubHeader',      type: 'string' },
        { name: 'ItemName',    type: 'string' },
        { name: 'Description',   type: 'string' },
        { name: 'Status', type: 'int' },
        { name: 'Rating',    type: 'int'}

    ]

});