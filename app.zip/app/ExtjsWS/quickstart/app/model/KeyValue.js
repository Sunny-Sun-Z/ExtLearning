/**
 * Created by kkora on 12/21/2017.
 */
Ext.define('QuickStart.model.KeyValue', {
    extend: 'Ext.data.Model',
    idProperty: 'Id',
    fields: [

        {name: 'Id', type: 'int'},
        {name: 'Key', type: 'string'},
        {name: 'Value', type: 'string'},
        {name: 'DataType', type: 'string'},
        {name: 'Description', type: 'string'},
        {name: 'Created', type: 'date'},
        {name: 'CreatedBy', type: 'int'}

    ]
});