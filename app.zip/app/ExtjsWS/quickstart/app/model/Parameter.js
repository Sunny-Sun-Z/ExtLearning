/**
 * Created by kkora on 12/21/2017.
 */
Ext.define('QuickStart.model.Parameter', {
    extend: 'Ext.data.Model',
    idProperty: 'Id',
    fields: [

        {name: 'Id', type: 'int'},
        {name: 'Name', type: 'string'},
        {name: 'Label', type: 'string'},
        {name: 'DataType', type: 'string'},
        {name: 'DefaultValue', type: 'string'},
        {name: 'FieldType', type: 'string'},
        {name: 'LookupDisplayField', type: 'string'},
        {name: 'LookupValueField', type: 'string'},
        {name: 'LookupId', type: 'int', allowNull: true},
        {name: 'LookupId', Required: 'boolean', allowNull: true},
        {name: 'FieldValidationType', type: 'string'},

    ]
});