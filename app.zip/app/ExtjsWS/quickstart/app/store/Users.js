Ext.define('QuickStart.store.Users', {
    extend: 'Ext.data.Store',

    alias: 'store.users',

    requires: [
        'QuickStart.model.User',
        'QuickStart.util.Global'
    ],

    storeId: 'Users',

    model: 'QuickStart.model.User',
    //
    // proxy: {
    //     type: 'api',
    //     url: '~api/casereview/lookups',
    //     reader: {
    //         type: 'json',
    //         transform: {
    //             fn: function (result) {
    //                 // do some manipulation of the raw data object
    //                 var data = [], val = {}, obj = result.data[0];
    //                 for (var o in obj) {
    //
    //                     var recs = obj[o];
    //                     Ext.each(recs, function (rec) {
    //                         if (Ext.isEmpty(rec.GroupName)) {
    //                             val = null;
    //                             switch (o) {
    //                                 case 'CrSecurityUser':
    //                                     val = {
    //                                         UserID: rec.UserID,
    //                                         Email: rec.Email,
    //                                         LoginID: rec.LoginID,
    //                                         IsActive: rec.IsActive,
    //                                         FirstName: rec.FirstName,
    //                                         LastName: rec.LastName
    //                                     };
    //
    //                                     if(rec.LoginID.toLowerCase()==="kkora")
    //                                         val.Avatar=true;
    //                                     break;
    //
    //                             }
    //                             if (val)
    //                                 data.push(val);
    //                         }
    //                     });
    //                 }
    //
    //                 // console.log(data.length)
    //                 return data;
    //             },
    //             scope: this
    //         }
    //     }
    // },

    proxy: {
        url: QuickStart.util.Global.getApi(),
        type: 'ajax',
        paramsAsJson: true,
        pageParam: null,
        remoteFilter:true,
        remortSort:true,
        api: {
            read: 'user/GetAllUsers'
        },
        reader: {
            type: 'json',
            rootProperty: 'data',
            totalProperty: 'total'
        }
    },
    autoLoad: true
});
