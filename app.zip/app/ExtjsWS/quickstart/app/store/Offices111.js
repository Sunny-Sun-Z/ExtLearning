Ext.define('QuickStart.store.Offices111', {
    extend: 'Ext.data.ChainedStore',

    alias: 'store.offices111',
    storeId: 'Offices',

    source: 'Lookups',
    //autoLoad:true,
    sorters: [{property: 'medium', direction: 'ASC'}],
    filters: [{property: 'group', value: 'Office', operator: '='}]
});
