
Ext.define('QuickStart.store.Lookups', {
    extend: 'Ext.data.Store',
    alias: 'store.lookups',
    requires: [
        'QuickStart.model.casereview.Lookup',
        'QuickStart.util.Global'
    ],
    storeId: 'Lookups',
    model: 'QuickStart.model.casereview.Lookup',

    proxy: {
       // type: 'api' ,
      //  url: '~api/casereview/lookups',

        type: QuickStart.util.Global.getTest() ? 'api' : 'ajax',
        url: QuickStart.util.Global.getTest() ? '~api/casereview/lookups' : 'lookup/GetLookups',
        reader: {
            type: 'json',
            rootProperty: 'data',
            totalProperty: 'total'

        //     // transform: {
        //     //     fn: function (result) {
        //     //
        //     //         // do some manipulation of the raw data object
        //     //         var data = [], val = {}, obj = Ext.isArray(result.data[0]) ? result.data[0] : result.data;
        //     //         for (var o in obj) {
        //     //
        //     //             var recs = obj[o];
        //     //             Ext.each(recs, function (rec) {
        //     //                 if (Ext.isEmpty(rec.GroupName)) {
        //     //                     //  console.log('Collection Name :', o);
        //     //                     val = null;
        //     //                     switch (o) {
        //     //                         case 'CrReviewType':
        //     //                             val = {
        //     //                                 group: o,
        //     //                                 groupId: rec.ReviewTypeID,
        //     //                                 code: rec.ReviewTypeID,
        //     //                                 codeId: rec.ReviewTypeID,
        //     //                                 name: rec.Description
        //     //                             };
        //     //                             break;
        //     //                         case 'CrReviewSubType':
        //     //                             val = {
        //     //                                 group: o,
        //     //                                 groupId: rec.ReviewSubTypeID,
        //     //                                 code: rec.ReviewSubTypeID,
        //     //                                 codeId: rec.ReviewSubTypeID,
        //     //                                 name: rec.Description,
        //     //                                 parentCode: rec.ReviewTypeID
        //     //                             };
        //     //                             break;
        //     //                         case 'CrSecurityUser':
        //     //                         case 'CaseReviewReviewers':
        //     //                         case 'CaseReviewQA':
        //     //                         case 'CaseReviewSecondaryOversight':
        //     //
        //     //                             val = {
        //     //                                 group: o,
        //     //                                 groupId: rec.UserID,
        //     //                                 code: rec.UserID,
        //     //                                 codeId: rec.UserID,
        //     //                                 name: rec.FirstName + ' ' + rec.LastName
        //     //                             };
        //     //                             break;
        //     //                         case 'CrSecurityRoles':
        //     //                             val = {
        //     //                                 group: o,
        //     //                                 groupId: rec.RoleID,
        //     //                                 code: rec.RoleID,
        //     //                                 codeId: rec.RoleID,
        //     //                                 name: rec.Description
        //     //                             };
        //     //
        //     //                             break;
        //     //                         case 'CrSecurityPermission':
        //     //                             val = {
        //     //                                 group: o,
        //     //                                 groupId: rec.PermissionID,
        //     //                                 code: rec.PermissionID,
        //     //                                 codeId: rec.PermissionID,
        //     //                                 name: rec.Description
        //     //                             };
        //     //                             break;
        //     //                         case 'CrSecurityUserPermission':
        //     //                             val = {
        //     //                                 group: o,
        //     //                                 groupId: rec.UserID,
        //     //                                 code: rec.PermissionID,
        //     //                                 codeId: rec.UserPermissionID
        //     //                             };
        //     //                             break;
        //     //
        //     //                         case 'CrSecurityUserRole':
        //     //                             val = {
        //     //                                 group: o,
        //     //                                 groupId: rec.UserID,
        //     //                                 code: rec.RoleID,
        //     //                                 codeId: rec.UserRoleID
        //     //                             };
        //     //                             break;
        //     //                         case 'CrSecurityRolePermission':
        //     //                             val = {
        //     //                                 group: o,
        //     //                                 groupId: rec.RoleID,
        //     //                                 code: rec.PermissionID,
        //     //                                 codeId: rec.RolePermissionID
        //     //                             };
        //     //                             break;
        //     //
        //     //
        //     //                     }
        //     //                     if (val)
        //     //                         data.push(val);
        //     //                 }
        //     //                 else {
        //     //                     val = {
        //     //                         groupId: rec.GroupID,
        //     //                         group: rec.GroupName,
        //     //                         code: rec.GroupID,
        //     //                         codeId: rec.CodeDescriptionID,
        //     //                         name: rec.DescriptionSmall || rec.DescriptionMedium || rec.DescriptionLarge || rec.GroupName,
        //     //                         small: rec.DescriptionSmall,
        //     //                         medium: rec.DescriptionMedium,
        //     //                         large: rec.DescriptionLarge
        //     //
        //     //                     };
        //     //                     if (!Ext.isEmpty(rec.GroupName))
        //     //                         data.push(val);
        //     //                 }
        //     //             });
        //     //         }
        //     //
        //     //         // console.log(data.length)
        //     //         return data;
        //     //     },
        //     //     scope: this
        //     // }
         }
    },

    autoLoad: false
});
