Ext.define('QuickStart.store.AdminNavigationTree', {
    extend: 'Ext.data.TreeStore',

    storeId: 'AdminNavigationTree',

    fields: [{
        name: 'text'
    }],

    root: {
        expanded: true,
        children: [
            {
                text: 'Rule Engine',
                iconCls: 'x-fa fa-cogs',
                rowCls: 'nav-tree-badge nav-tree-badge-new',
                viewType: 'rule',
                // routeId: 'rule', // routeId defaults to viewType
                leaf: true
            },
            {
                text: 'Settings',
                iconCls: 'x-fa fa-cog',
                viewType: 'setting',
                // routeId: 'rule', // routeId defaults to viewType
                leaf: true
            },
          {
              text: 'Report Settings',
              iconCls: 'x-fa fa-rss',    
              viewType: 'settingreportpanel',
              // routeId: 'rule', // routeId defaults to viewType
              leaf: true
          },
            {
                text: 'Import Export',
                iconCls: 'x-fa fa-upload',
                viewType: 'exportimport',
                leaf: true
            },
            {
               // text: 'Review Time Machine',
                text: 'Track Case Changes',
                iconCls: 'x-fa fa-compass',
                viewType: 'previewtool',
                leaf: true
            },
            {
                text: 'Case Compare Tool',
                iconCls: 'x-fa fa-clone',
                viewType: 'comparetool',
                leaf: true
            },
            {
                text: 'Audit Logs',
                iconCls: 'x-fa fa-bolt',
                viewType: 'auditlog',
                leaf: true
            }
            //,
            //{
            //    text: 'Reviewer Profile',
            //    iconCls: 'x-fa fa-user',
            //    rowCls: 'nav-tree-badge nav-tree-badge-new',
            //    viewType: 'reviewerprofile',//'userpanel', 
            //    // routeId: 'rule', // routeId defaults to viewType
            //    leaf: true
            //},

            // , {
            //     text: 'Preview',
            //     iconCls: 'x-fa fa-anchor',
            //     viewType: 'casepreviewcontainer',
            //     leaf: true
            // }
        ]
    }
});
