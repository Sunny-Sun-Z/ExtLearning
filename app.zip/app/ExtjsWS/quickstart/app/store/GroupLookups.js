Ext.define('QuickStart.store.GroupLookups', {
    extend: 'Ext.data.ChainedStore',

    alias: 'store.grouplookups',
    storeId: 'GroupLookups',

    source: 'Lookups',
    //autoLoad:true,
    filters: [{property: 'group', value: 'CaseReason', operator: '='}]
});
