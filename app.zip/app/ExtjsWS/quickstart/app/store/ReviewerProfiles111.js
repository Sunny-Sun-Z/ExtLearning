Ext.define('QuickStart.store.ReviewerProfiles111', {
    extend: 'Ext.data.Store',

    alias: 'store.reviewerprofile111',

    requires: [
        'QuickStart.model.ReviewerProfile',
        'QuickStart.util.Global'
    ],

    storeId: 'ReviewerProfiles',

    model: 'QuickStart.model.ReviewerProfile',
    

    proxy: {
        url: QuickStart.util.Global.getApi(),
        type: 'ajax',
        paramsAsJson: true,
        pageParam: null,
        remoteFilter:true,
        remortSort:true,
        api: {
            read: 'user/GetAllReviewerProfiles'
        },
        reader: {
            type: 'json',
            rootProperty: 'data',
            totalProperty: 'total'
        }
    },
    autoLoad: true
});
