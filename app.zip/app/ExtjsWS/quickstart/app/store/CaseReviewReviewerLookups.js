Ext.define('QuickStart.store.CaseReviewReviewerLookups', {
    extend: 'Ext.data.ChainedStore',

    alias: 'store.casereviewreviewerlookups',
    storeId: 'CaseReviewReviewerLookups',

    source: 'Lookups',

    filters: [{property: 'group', value: 'CaseReviewReviewers', operator: '='}]
});
