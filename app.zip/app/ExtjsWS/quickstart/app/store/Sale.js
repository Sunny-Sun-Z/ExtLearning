/**
 * Created by kkora on 10/16/2017.
 */
Ext.define('QuickStart.store.Sale', {
    extend: 'Ext.data.Store',

    alias: 'store.sales',

    model: 'QuickStart.model.Sale',

    proxy: {
        // load using HTTP
        limitParam: null,
        type: 'api',
        url: '~api/sales',
        // the return will be JSON, so lets set up a reader
        reader: {
            rootProperty: 'data',
            type: 'json'
        }
    },
    autoLoad: true
});