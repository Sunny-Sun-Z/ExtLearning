﻿Ext.define('QuickStart.store.Months', {
    extend: 'Ext.data.Store',
    alias: 'store.months',
    storeId: 'Months',
    requires: [
        'QuickStart.model.BaseLookup'
    ],
    model: 'QuickStart.model.BaseLookup',
    data: [
        { Id: 10, Name: 'October', FederalPeriod: 'A' },
        { Id: 11, Name: 'November', FederalPeriod: 'A' },
        { Id: 12, Name: 'December', FederalPeriod: 'A' },
        { Id: 1, Name: 'January',FederalPeriod:'A' },
        { Id: 2, Name: 'February', FederalPeriod: 'A' },
        { Id: 3, Name: 'March', FederalPeriod: 'A' },
        { Id: 4, Name: 'April', FederalPeriod: 'B'},
        { Id: 5, Name: 'May', FederalPeriod: 'B'},
        { Id: 6, Name: 'June', FederalPeriod: 'B'},
        { Id: 7, Name: 'July', FederalPeriod: 'B'},
        { Id: 8, Name: 'August', FederalPeriod: 'B'},
        { Id: 9, Name: 'September', FederalPeriod: 'B'}
    ]
});
