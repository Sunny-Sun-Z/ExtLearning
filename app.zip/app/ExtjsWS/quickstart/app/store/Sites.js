Ext.define('QuickStart.store.Sites', {
    extend: 'Ext.data.ChainedStore',

    alias: 'store.sites',
    storeId: 'Sites',

    source: 'Lookups',
    //autoLoad:true,
    sorters: [{property: 'medium', direction: 'ASC'}],
    filters: [{property: 'group', value: 'Site', operator: '='}]
});
