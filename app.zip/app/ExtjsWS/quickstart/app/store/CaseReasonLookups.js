Ext.define('QuickStart.store.CaseReasonLookups', {
    extend: 'Ext.data.ChainedStore',

    alias: 'store.casereasonlookups',
    storeId: 'CaseReasonLookups',

    source: 'Lookups',

    filters: [{property: 'group', value: 'CaseReason', operator: '='}]
});
