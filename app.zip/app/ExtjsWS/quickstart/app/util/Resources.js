/**
 * Created by kkora on 9/7/2017.
 * Added questions on 12/4/2017 (hlawrence).
 */
Ext.define('QuickStart.util.Resources', {
    singleton: true,
    instructions: {
        facesheet: {

            g1ChildTable: function () {

                return "<div class='question-instruction'>" +
                    "<ul>" +
                    "<li>For both foster care cases and in-home services cases, enter the first and last names (first name first) " +
                    "of all children in the family as identified in the case file. If the case is a foster care case, " +
                    "check the box to indicate if the child is the target child. It is essential that the target child be " +
                    "clearly identified for all foster care cases." +
                    "</li>" +

                    "<li>Enter the race and ethnicity information as provided in the case file. " +
                    "If the child is of two or more races, list all that are provided in the case file " +
                    "(for example, White and Asian, or White and American Indian). If you learn during the course of the interviews " +
                    "that a child is of a different race or ethnicity than is noted in the file or is of two or " +
                    "more races and only one is noted in the file (for example, Non-Hispanic instead of Hispanic, or both White andAmerican Indian), " +
                    "please change the race or ethnicity identification information presented to reflect the accurate information." +
                    "</li>" +

                    "<li>Select from the following options for ethnicity: \"Hispanic\", \"Non-hispanic,\" or \"Unknown or Unable to Determine.\"</li>" +
                    "<li> Select from the following options for race:" +
                    "<ul>" +
                    "<li>American Indian or Alaskan Native</li>" +
                    "<li>Asian</li>" +
                    "<li>Black or African American</li>" +
                    "<li>Native Hawaiian or Other Pacific Islander</li>" +
                    "<li>White</li>" +
                    "<li>Unknown or Unable to Determine</li>" +
                    "</ul>" +
                    "</li>" +

                    "<li>Provide the date of birth for every child in the family, even if this is a foster care case.</li>" +
                    "<li>If the child is abandoned or the date of birth is otherwise unknown, enter an approximate date of birth. Use the 15th as the day of birth.</li>" +
                    "</ul>" +
                    "</div>";
            },

            g2CaseParticipantTable: function () {
                return "<div class='question-instruction'>" +
                    "<ul>" +
                    "<li>In the Name column, for both foster care and in-home services cases, enter the first and last names " +
                    "(first name first) of the key case participants whose participation in this case will be assessed in the instrument " +
                    "and other persons who were interviewed to provide relevant information." +
                    "</li>" +

                    "<li>In the Role column, list one of the following options for each participant listed: Mother, Father, " +
                    "Caregiver, Foster Parent, Caseworker, Caseworker's Supervisor, Other. The same role may be indicated for more than one person " +
                    "(for example, a biological father may have the role of Father, and a stepfather may have the role of Father)." +
                    "</li>" +

                    "<li>In the Relationship to Child column, indicate how the person is involved in the case and/or related to the child. " +
                    "Indicate whether the person is/was living with the child and/or in a caregiving role. For example: boyfriend of (child name)'s mother, " +
                    "lives in the home; biological mother of (children's names), not living in the home, not a caregiver; legal father of (child's name), " +
                    "not living in the home" +
                    "</li>" +

                    "<li>In the Interviewed column, note whether the person has been interviewed regarding the case." +
                    "</li>" +
                    "</ul>" +
                    "</div>";
            },
            questionH: function () {
                return "<div class='question-instruction'>" +
                    "<ul>" +
                    "<li>Examples of cases opened for reasons other than child abuse or neglect include: (1) cases opened because of the child's behavior, including juvenile delinquency, substance abuse, or \"child in need of supervision,\" and there were no maltreatment concerns in the family; or (2) cases opened because parents requested mental/behavioral health services for their child(ren)." +
                    "</li>" +
                    "</ul>" +
                    "</div>";
            },
            questionI: function () {
                return "<div class='question-instruction'>" +
                    "<ul>" +
                    "<li>Using the MM/DD/YYYY format, enter the date on which the case was actually opened within the agency. Consider all cases that were open for services during the period under review, if there were multiple case openings. If the first case that was open during the period under review was opened before the period under review began, include it as the first case opening date for the period.</li>" +
                    "<li>If a child was on a trial home visit and returned to a foster care placement, the return to foster care is not considered a \"case opening\" unless the trial home visit was longer than 6 months and there was no court order extending the trial home visit beyond 6 months.</li>" +
                    "<li>If the family received in-home services before the removal of a child and placement of the child in foster care, and the case was not closed before placement, enter the date on which the case was opened for in-home services. The date of the child’s removal from home will be captured in the next question.</li>" +
                    "</ul>" +
                    "</div>";
            },
            questionJ: function () {
                return "<div class='question-instruction'>" +
                    "<ul>" +
                    "<li>Using the MM/DD/YYYY format, enter the date of the child's most recent entry into foster care.</li>" +
                    "<li>If a child was on a trial home visit and returned to a foster care placement, the return is not considered an \"entry into foster care\" unless the trial home visit was longer than 6 months and there was no court order extending the trial home visit beyond 6 months.</li>" +
                    "<li>If the case is an in-home services case, J is Not Applicable</li>" +
                    "</ul>" +
                    "</div>";
            },
            questionK: function () {
                return "<div class='question-instruction'>" +
                    "<ul>" +
                    "<li>Using the MM/DD/YYYY format, enter the date of discharge from foster care for the most recent foster care episode.</li>" +
                    "<li>If a child returns home on a trial home visit and the agency retains responsibility or supervision of the child, the child should be considered discharged from foster care only if the trial home visit was longer than 6 months, and there was no court order extending the trial home visit beyond 6 months.</li>" +
                    "<li>If the child is in foster care but has not yet been discharged, select Not Yet Discharged.</li>" +
                    "<li>If the case is an in-home services case, K is Not Applicable:</li>" +
                    "</ul>" +
                    "</div>";
            },
            questionL: function () {
                return "<div class='question-instruction'>" +
                    "<ul>" +
                    "<li>Using the MM/DD/YYYY format, enter the date on which the agency officially closed the case. For foster care cases, this may or may not be the same as the discharge date.</li>" +
                    "<li>If there were multiple case openings and closures during the period under review, indicate the date of the last case closure that occurred during the period.</li>" +
                    "<li>If the case is still open at the time of review, select \"Case not closed by time of review.\"</li>" +
                    "</ul>" +
                    "</div>";
            },
            questionM: function () {
                return "<div class='question-instruction'>" +
                    "<ul>" +
                    "<li>Indicate the reason(s) for case opening(s) by selecting all that apply. Consider all cases open during the period under review.</li>" +
                    "</ul>" +
                    "</div>";
            }

        },
        newCase: {
            questionA: function () {
                return "<div class='question-instruction'>" +
                    "<ul><li>For the local area, use the name that is used by the state for the review. This may be a region rather than a county, or may be multiple counties.</li>" +
                    "<li>Enter the case name that is the official name on the case file.</li>" +
                    "<li>The period under review is the time frame used for making decisions about the case. It begins with the sampling period start date and ends with the date the case review was completed.</li>" +
                    "</ul></div>";
            },
            questionF: function () {
                return "<div class='question-instruction'>" +
                    "<ul><li>The case is a foster care case if the target child was in foster care at any time during the period under review. A child is considered to be in foster care if the state child welfare agency or another public agency with whom the agency has a title IV-E agreement (hereafter 'the agency') has placement and care responsibility for the child. This includes a child who is placed by the agency with relatives or in other kin-type placements, but the agency maintains placement and care responsibility. It does not include a child who is living with relatives (or caregivers other than parents) but who is not under the placement and care responsibility of the agency.</li>" +
                    "<li>The case is an in-home services case if no child in the family was in foster care at any time during the period under review, and the case was open for at least 45 days.</li>" +
                    "<li>The case is an in-home services differential/alternative response case if the state has some form of differential/alternative response program during the period under review and the in-home services case was served through that program.</li>" +
                    "</ul></div>";
            },
            pip: function () {
                return "<div class='question-instruction'>" +
                    "Cases can be marked as \"PIP Monitored\" at case creation by selecting the checkbox below. " +
                    "Only check this box for a case that has been identified in advance as a case being used for PIP monitoring purposes. " +
                    "Once the Case Setup page is saved and the case is created, the \"PIP Monitored\" checkbox cannot be changed by the state user " +
                    "and can only be changed by contacting the CWRP Help Desk. " +
                    "Marking a case as \"PIP Monitored\" allows the case to be filtered as such on the Cases page and in the reports.</div>";

            }
        },
        safety: {
            outcome1: function () {
                return "<div class='question-instruction'>Safety Outcome 1 should be rated as Substantially Achieved if the following applies: " +
                    "<ul><li> Item 1 is rated as a Strength</li></ul>" +
                    "Safety Outcome 1 should be rated as Not Achieved if the following applies: " +
                    "<ul><li> Item 1 is rated as an Area Needing Improvement.</li></ul>" +
                    "Safety Outcome 1 should be rated as Not Applicable if the following applies:  " +
                    "<ul><li> Item 1 is rated as Not Applicable.</li></ul></div>"
            },
            outcome1Item1: function () {
                return "<div class='question-instruction'> <h3>Purpose of Assessment:</h3>" +
                    "<ul><li> To determine whether responses to all accepted child maltreatment reports received during the period under review were initiated, and face-to-face contact with the child(ren) made, within the time frames established by agency policies or state statutes.</li></ul>" +
                    "<h3>Item 1 Applicable Cases:</h3>" +
                    "<ul><li> Cases are applicable for an assessment of this item if an accepted child maltreatment report on any child in the family was received during the period under review. 'Accepted' means that the report was assigned to the agency to conduct an assessment or investigation. This includes reports assigned for an 'alternative response' assessment. Reports that are screened out are not considered 'accepted.' 'Alternative response' refers to an agency's approach to addressing child maltreatment reports that meet agency criteria for acceptance but at the initial screening do not meet the agency's requirements for a mandated investigation. For example, the agency's policy may be that reports that appear to present low to moderate risk to the child may be referred for a family assessment, rather than an investigation. Under such a response, no determination of child maltreatment is made. The alternative response may include an assessment to determine the safety of the child(ren), the risk of maltreatment, and the family's strengths and needs. The assessment may lead the state agency to provide services to eliminate or lessen the safety concerns and maltreatment risks.</li>" +
                    "<li> Cases are Not Applicable for an assessment of this item if, during the period under review, there were no child maltreatment reports on any child in the family, or if a report was received on a child in the family but it was 'screened out'; that is, not referred for an assessment or investigation.</li></ul>" +
                    "</div>"
            },
            item1Rating: function () {
                return "<div class='question-instruction'>Item 1 should be rated as a Strength if either of the following applies: " +
                    "<ul><li> The answers to A and B are zero.</li>" +
                    "<li>The answers to A or B are greater than zero, but the answer to C is Yes.</li></ul>" +
                    "Item 1 should be rated as an Area Needing Improvement if the following applies: " +
                    "<ul><li> The answer to A or B is greater than zero, and the answer to C is No.</li></ul>" +
                    "Item 1 should be rated as Not Applicable if the response to the question of applicability is No." +
                    "</div>";
            },
            question1c: function () {
                return "<div class='question-instruction'><ul><li>If the answers to both questions A and B are zero, the answer to question C should be Not Applicable.</li></ul>" +
                    "<ul><li>Delays in services provided by organizations or agencies under contract with the agency would not be considered to be beyond the control of the agency. However, where services are provided by another public state or local agency, such as law enforcement, the actions of these agencies may be beyond the control of the child welfare agency.</li></ul>" +
                    "</li></ul></div>";
            },
            outcome2: function () {
                return "<div class='question-instruction'>Safety Outcome 2 should be rated as Substantially Achieved if either of the following applies: " +
                    "<ul><li> Items 2 and 3 are rated as Strengths. " +
                    "<li>Item 2 is rated as Not Applicable and Item 3 is rated as a Strength.</ul>" +
                    "Safety Outcome 2 should be rated as Partially Achieved if the following applies:" +
                    "<ul><li> One of the two items is rated as a Strength and the other as an Area Needing Improvement.</ul>" +
                    " Safety Outcome 2 should be rated as Not Achieved if either of the following applies: " +
                    "<ul><li>Items 2 and 3 are rated as Areas Needing Improvement." +
                    "<li>Item 2 is rated as Not Applicable and Item 3 is rated as an Area Needing Improvement.</ul></div>"
            },
            outcome2Item2: function () {
                return "<div class='question-instruction'> <h3>Purpose of Assessment:</h3>" +
                    "<ul><li>To determine whether, during the period under review, the agency made concerted efforts to provide services to the family to prevent children's entry into foster care or re-entry after a reunification.</li></ul>" +
                    "</div>"
            },
            question2a: function () {
                return "<div class='question-instruction'>" +
                    "<ul><li> In answering question A, focus only on whether the agency made concerted efforts to provide appropriate and relevant services to the family to address the safety issues in the family so that the child could remain safely in the home or would not re-enter foster care after reunification. Concerns about monitoring service participation and safety planning and assessment of progress made will be captured in item 3." +
                    "<li>If the agency removed the child from the home without making concerted efforts to provide services, the answer to question A should be No, even if the agency determined that it was necessary to remove the child for safety reasons. This issue will be addressed in question B.</li>" +
                    "</ul>" +
                    "<h3>Definitions:</h3>" +
                    "<ul><li> 'Appropriate services,' for the purposes of item 2, are those that are provided to, or arranged for, the family with the explicit goal of ensuring the child’s safety. Examples include: (1) if there are safety issues in the home due to environmental hazards, homemaking services could be an appropriate safety-related service; (2) if there are safety concerns related to the parent’s ability to manage specific child needs or child behaviors, intensive in-home services could be an appropriate safety-related service; (3) child care services could be a safety-related service in cases where the child was being cared for in an unsafe setting or by an inappropriate caregiver; and (4) if there are safety concerns related to parental substance abuse, substance abuse treatment could be an appropriate safety-related service. In most cases a child’s need for mental health services, education-related services, or services to address health issues, would not be considered relevant to the child’s safety if the child remained in the home. The agency’s efforts to meet those service needs are assessed in other items." +
                    "<li>'Concerted efforts,' for the purposes of item 2, refers to facilitating a family’s access to needed services and working to engage the family in those services.</li>" +
                    "</ul>" +
                    "</div>"
            },
            question2b: function () {
                return "<div class='question-instruction'>" +
                    "<ul><li>If the answer to question A is Yes, but, after making efforts to provide services, the child was removed from the home during the period under review due to unmanageable safety concerns, the answer to question B should be Not Applicable." +
                    "<li>If the child was not removed from the home during the period under review, the answer to question B should be Not Applicable.</li>" +
                    "<li>Focus on whether the circumstances of the case and of the removal suggest that services would not have been able to ensure the child’s safety if the child remained in the home. If the information indicates that it was necessary to remove the child immediately to ensure the child’s safety, the answer to question B should be Yes. If the information indicates that services could have been provided to prevent removal but the child was removed without providing those services, this question should be answered No.</li>" +
                    "<li>If services should have been offered to protect the child but were not, because those services were not available in the community, the answer to question B should be No.</li>" +
                    "</div>"
            },
            item2Rating: function () {
                return "<div class='question-instruction'>" +
                    "Item 2 should be rated as a Strength if either of the following applies: " +
                    "<ul><li> The answer to question A is Yes, and the answer to question B is Not Applicable.</li>" +
                    "<li>The answer to question A is No, and the answer to question B is Yes.</li></ul>" +
                    "Item 2 should be rated as an Area Needing Improvement if either of the following applies: " +
                    "<ul><li> The answer to question A is No, and the answer to question B is No.</li>" +
                    "<li>The answer to question A is No, and the answer to question B is Not Applicable.</li></ul>" +
                    "Item 2 should be rated as Not Applicable if the response to the question of applicability is No." +
                    "</div>"
            },
            item3Rating: function () {
                return "<div class='question-instruction'>" +
                    "Item 3 should be rated as a Strength if the following applies: " +
                    "<ul><li> Questions A and B are both answered Yes, or</li>" +
                    "<li>The answer to either A or B is Yes and the other is Not Applicable, and</li>" +
                    "<li>The answer to question C is either Yes or Not Applicable, and</li>" +
                    "<li>The answers to questions D, E, and F are either No or Not Applicable.</li></ul>" +
                    "Item 3 should be rated as an Area Needing Improvement if the following applies: " +
                    "<ul><li> The answer to any one of questions A, B, or C is No, and/or</li>" +
                    "<li>The answer to any one of questions D, E, or F is Yes.</li></ul>" +
                    "There are no circumstances under which item 3 could be rated as Not Applicable." +
                    "</div>"
            },
            outcome2Item3: function () {
                return "<div class='question-instruction'>" +
                    "<h3>Purpose of Assessment:</h3>" +
                    "<ul>" +
                    "<li> To determine whether, during the period under review, the agency made concerted efforts to assess and address the risk and safety concerns relating to the child(ren) in their own homes or while in foster care.</li>" +

                    "</ul>" +
                    "There are no circumstances under which item 3 could be rated as Not Applicable." +
                    "</div>"
            },
            question3a: function () {
                return "<div class='question-instruction'>" +
                    "<ul>" +
                    "<li>For foster care cases, questions A and B should be answered for the target child in foster care and any children remaining in the home.</li>" +
                    "<li>For in-home services cases, questions A and B should be answered for all children in the home.</li>" +
                    "<li>In responding to questions A and B, consider any concerns selected in 3A1.</li>" +
                    "<li>Question A should be answered Not Applicable if the case was opened before the period under review.</li>" +
                    "</ul>" +
                    "<h3>Definitions:</h3>" +
                    "<ul>" +
                    "<li>'Risk' is defined as the likelihood that a child will be maltreated in the future.</li>" +
                    "<li>An assessment of safety is made to determine whether a child is in a safe environment. A safe environment is one in which there are no threats that pose a danger or, if there are threats, there is a responsible adult in a caregiving role who demonstrates sufficient capacity to protect the child.</li>" +
                    "<li>'Target child' is defined as the child in a foster care case who is the subject of the case.</li>" +
                    "</ul>" +
                    "<h3>Tip:</h3>" +
                    "<ul>" +
                    "<li>For questions 3A and 3B, consider whether the frequency and quality of caseworker visits with parents and/or children was adequate to appropriately assess risk and safety concerns during the period under review.</li>" +
                    "</ul>" +
                    "</div>"
            },


            question3b: function () {
                return "<div class='question-instruction'>" +
                    "<ul>" +
                    "<li>In responding to question B, determine whether ongoing assessments (formal or informal) were conducted during the period under review. If the agency conducted an initial assessment of risk and safety at the onset of the case, but did not assess for risk and safety concerns on an ongoing basis and at critical times in the case (for example, when there were new allegations of abuse or neglect; changing family conditions; new people coming into the family home or having access to the children; changes to visitation, upon reunification, or at case closure) then the answer to question B should be No.</li>" +
                    "<li>Note that in some cases that were opened during the period under review, the issue of ongoing assessments may not be relevant because the case was opened for a very short period of time (for example, if the case was opened shortly before the end of the period under review and during the initial assessment the agency determined that there were no risk or safety concerns, then it may be reasonable to conclude that the agency would not have conducted a second risk and safety assessment during the period under review). If the case was opened during the period under review and you believe that ongoing assessments were not necessary given the time frame and circumstances of the case, question B may be answered Not Applicable.</li>" +
                    "<li>If a case was closed during the period under review, determine whether the agency conducted a risk and safety assessment before closing the case. If not, the answer to question B should be No.</li>" +
                    "</ul></div>"
            },
            question3c: function () {
                return "<div class='question-instruction'>" +
                    "<ul>" +
                    "<li>Questions C and D are applicable to all in-home services cases and to foster care cases in which there are other children remaining in the family home, and/or the target child in foster care returned home during the period under review.</li>" +
                    "<li>Questions C and D should be answered Not Applicable if the reviewer determines that during the period under review there were no apparent safety concerns for any child in the family home.</li>" +
                    "</ul>" +
                    "<h3>Definitions:</h3>" +
                    "<ul>" +
                    "<li>'Safety plan' refers to a plan that describes strategies developed by the agency and family to ensure that the child(ren) is (are) safe. Safety plans should address (1) safety threats and how those will be managed and addressed by the caregiver, (2) caregiver capacity to implement the plan and report safety issues to the agency, and (3) family involvement in implementation of the plan. Safety plans may be separate from or integrated into the case plan.</li>" +
                    "</ul>" +
                    "</div>"
            },
            question3d: function () {
                return "<div class='question-instruction'>" +
                    "<ul>" +
                    "<li>Answer Yes if any safety-related incidents in D1 are selected.</li>" +
                    "<li>Answer No if no safety-related incidents occurred that were not adequately addressed by the agency.</li>" +
                    "<li>Answer NA if no safety issues were present during the period under review.</li>" +
                    "</ul></div>"
            },
            question3e: function () {
                return "<div class='question-instruction'>" +
                    "<ul>" +
                    "<li>Select Not Applicable if this is not a foster care case.</li>" +
                    "<li>Answer Yes if any safety concerns in E1 are selected.</li>" +
                    "<li>If no safety concerns were identified in E1, answer No.</li>" +
                    "<li>If the child does not have visits with parents/caretakers or with other family members, select Not Applicable.</li>" +
                    "</ul></div>"
            },
            question3f1: function () {
                return "<div class='question-instruction'>" +
                    "<ul>" +
                    "<li>Foster parents are defined as related or non-related caregivers who have been given responsibility for care of the child by the agency while the child is under the placement and care responsibility and supervision of the agency. This includes pre-adoptive parents if the adoption has not been finalized.</li>" +
                    "</ul></div>"
            },

            question3f: function () {
                return "<div class='question-instruction'>" +
                    "<ul>" +
                    "<li>Answer Not Applicable if this is not a foster care case.</li>" +
                    "<li>Answer No if no unaddressed concerns were noted in F1.</li>" +
                    "<li>Answer Yes if you determine that, during the period under review, the child was in at least one foster care placement in which he or she was unsafe, and appropriate action was not taken (such as providing closer monitoring of the placement, placing fewer children in the home, providing services to address potential problems or existing problems, or finding a more appropriate placement). If any concerns are selected in F1, question F should be answered Yes.</li>" +
                    "</ul></div>"
            },


        },

        permanency: {
            outcome1: function () {
                return "<div class='question-instruction'>Permanency Outcome 1 should be rated as Substantially Achieved if either of the following applies: " +
                    "<ul><li> Items 4, 5, and 6 are rated as Strengths</li>" +
                    "<li> Items 4 and 6 are rated as Strengths and Item 5 is rated as Not Applicable</li></ul>" +
                    "Permanency Outcome 1 should be rated as Partially Achieved if the following applies: " +
                    "<ul><li> At least one of items 4, 5, or 6 is rated as a Strength.</li></ul>" +
                    "Permanency Outcome 1 should be rated as Not Achieved if either of the following applies:  " +
                    "<ul><li> All of items 4, 5, and 6 are rated as Areas Needing Improvement.</li>" +
                    "<li>Items 4 and 6 are rated as Areas Needing Improvement and Item 5 is rated as Not Applicable.</li></ul></div>";
            },
            question4a: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul>" +
                    "<li>If there were multiple episodes of foster care during the period under review, add up the placement settings within each episode. If there is a re-entry into foster care and the child is placed in a different placement setting at the time of re-entry, then it would count as a new placement setting. If the child returns to the placement setting he or she was in before the return home, then it would not count as a new placement setting.</li>" +
                    "</ul></div>" +
                    "<h3>Definitions</h3>" +
                    "<div class='question-instruction text-justify'><ul><li> " + "'Placement setting'" + " refers to a physical setting in which a child resides while in foster care under the placement and care responsibility of the agency. A new placement setting would result, for example, when a child moves from one foster family home to another or to a group home or institution. If, however, a foster family with whom a child is placed moves and the child moves with them, this does not constitute a change in placement.</li>" +
                    "<li>'Entry into foster care'" + " refers to a child's removal from his or her normal place of residence and placement in a substitute care setting under the placement and care responsibility of the state or local title IV-B/IV-E agency. Children are considered to have entered foster care if the child has been in substitute care for 24 hours or more.</li>" +
                    "<li>'Current episode of foster care'" + " refers to a child's current stay in foster care based on the most recent removal of the child from his or her normal place of residence, resulting in his or her placement in a foster care setting and ending upon the child's discharge from foster care.</li></ul></div>"

                    ;
            },
            question4b: function () {
                return "<div class='question-instruction text-justify'><ul><li>If the response to question A is one (1), then the response to question B should be Not Applicable. If the single placement is not stable, that information will be collected in question C.</li>" +
                    "<li>Placement changes that reflect agency efforts to achieve case goals include moves from a foster home to an adoptive home, moves from a more restrictive to a less restrictive placement, moves from non-relative foster care to relative foster care, and moves that bring the child closer to family or community.</li>" +
                    "<li>Placement changes that do not reflect agency efforts to achieve case goals include moves due to unexpected and undesired placement disruptions; moves due to placing the child in an inappropriate placement (that is, moves based on mere availability rather than on appropriateness); moves to more restrictive placements when this is not essential to achieving a child's permanency goal or meeting a child's needs; temporary placements while awaiting a more appropriate placement; and practices of routinely placing children in a particular placement type, such as shelter care, upon initial entry into foster care regardless of individual needs.</li>" +
                    "<li>If ALL placement changes during the period under review reflect planned agency efforts to achieve the child's case goals or meet the needs of the child, then the answer to question B should be Yes.</li>" +
                    "<li>If any single placement change that occurred during the period under review was for a reason other than agency efforts to achieve case goals or to meet the child's needs, the answer to question B should be No.</li>" +
                    "<li>Placement changes that occur as a result of unexpected circumstances that are out of the control of the agency (such as the death of a foster parent or foster parents moving to another state) can be considered similar to those that reflect agency efforts to achieve case goals for purposes of question B.</li></ul></div>"
                    ;
            },
            question4c: function () {
                return "<div class='question-instruction'><ul><li>If any of the circumstances in C1 apply to the child's current placement, the answer to question C should be No.</li></ul></div>"
                    ;
            },
            item5: function () {
                return "<div class='question-instruction'>" +
                    "<h3>Purpose of Assessment</h3>" +
                    "<ul><li> To determine whether appropriate permanency goals were established for the child in a timely manner.</li></li></ul></div>"
                    ;
            },
            question5a3: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li> If the child has been in foster care less than 60 days and the goal is not specified in the case file, A3 should be answered NA.</li>" +
                    "<li> If the permanency goal(s) is (are) not specified anywhere in the case file, such as in the case plan or in a court order, then the answer to question A3 should be No.</li></ul></div>"
                    ;
            },
            question5b: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li> If the child has been in foster care less than 60 days, question B should be answered NA.</li>" +
                    "<li> Answer this question based on your professional judgment regarding the timeliness of establishing the goal, particularly with regard to changing a goal. For children who recently entered care, expect the first permanency goal to have been established no later than 60 days from the date of the child's entry into foster care, consistent with the federal requirement. For children whose goal was changed from reunification to adoption, consider the guidelines established by the federal Adoption and Safe Families Act regarding seeking termination of parental rights, which might affect the timeliness of changing a goal from reunification to adoption.</li>" +
                    "<li> Answer this question for all permanency goals in effect during the period under review. If there are concurrent goals, the answer should apply to both goals. For example, if there are concurrent goals of reunification and adoption, and you believe that the reunification goal was established in a timely manner, but the adoption goal was not, the answer to question B should be No.</li></ul></div>"
                    ;
            },
            question5c: function () {
                return "<div class='question-instruction'>" +
                    "<ul><li> Answer this question based on your professional judgment regarding the appropriateness of the permanency goal.</li>" +
                    "<li> Consider the factors that the agency considered in deciding on the permanency goal and whether all of the relevant factors were evaluated.</li>" +
                    "<li> If one of the goals is other planned permanent living arrangement and the reviewer determines that the goal was established without a thorough consideration of other permanency goals, then the answer to question C should be No.</li></ul></div>"
                    ;
            },
            question5d: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li> In answering question D, begin the 'count' with the date of the judicial finding of child abuse and neglect (usually the adjudicatory hearing) or 60 days after the child's entry into foster care, whichever is earlier. If the child had multiple episodes in care over the past 22 months, the determination of whether the child had been in care for at least 15 months should be calculated cumulatively over the episodes in foster care during the past 22 months from the review date.</li></ul></div>"
                    ;
            },
            question5e: function () {
                return "<div class='question-instruction'>" +
                    "<ul><li> If the answer to question D is Yes, the answer to question E should be Not Applicable.</li>" +
                    "<li>Question E must be answered if the answer to question D is No.</li>" +
                    "<li>If any of the conditions noted above apply to the case under review, question E should be answered Yes.</li></ul>" +
                    "<h3>Definitions</h3>" +
                    "<ul><li> The Adoption and Safe Families Act requires an agency to seek termination of parental rights when the child has been in care for at least 15 of the most recent 22 months, or a court of competent jurisdiction has determined that:</li></ul>" +
                    "</div>"

                    ;
            },
            question5f: function () {
                return "<div class='question-instruction'>" +
                    "<ul><li> If the answers to both questions D and E are No, the answer to question F should be Not Applicable.</li>" +
                    "<li>Review the case file for evidence of petitioning for termination of parental rights. If there is no evidence of this in the file, then ask the caseworker for documentation regarding petitioning for termination of parental rights. If there is no evidence in the file or other documentation, then question F should be answered No.</li>" +
                    "</ul>" +
                    "<h3>Tip</h3>" +
                    "<ul><li> Answer 5F as NA if both parents were either deceased or relinquished parental rights prior to the 15/22-month time frame.</li>" +
                    "</ul>" +
                    "</div>";
            },
            question5g1: function () {
                return "<div class='question-instruction'>" +
                    "<ul><li> If the answer to question F is Yes or Not Applicable, then question G1 should be answered Not Applicable.</li>" +
                    "</ul></div>";
            },
            question5g: function () {
                return "<div class='question-instruction'>" +
                    "<ul><li> If the answer to question F is Yes or Not Applicable, then question G should be answered Not Applicable.</li>" +
                    "<li> If any answers to G1 are yes, question G should be answered Yes.</li>" +
                    "<li> If, during an interview, the caseworker provides a compelling reason for not seeking termination of parental rights, but cannot provide any documentation, then question G should be answered No.</li>" +
                    "</ul></div>";
            },
            item6: function () {
                return "<div class='question-instruction'>" +
                    "<h3>Purpose of Assessment</h3>" +
                    "<ul><li> To determine whether concerted efforts were made, or are being made, during the period under review to achieve reunification, guardianship, adoption, or other planned permanent living arrangement.</li></li></ul>" +
                    "</div>"
                    ;
            },
            question6a1: function () {
                return "<div class='question-instruction'><ul><li> Using the MM/DD/YYYY format, enter the date of the child’s most recent entry into foster care. This date should be the same as the date provided in section J on the Face Sheet.</li></li></ul>" +

                    "<h3>Definitions</h3>" +
                    "<ul><li> \"Entry into foster care\" refers to a child’s removal from his or her normal place of residence and placement in a substitute care setting under the placement and care responsibility of the state or local title IV-B/IV-E agency. Children are considered to have entered foster care if the child has been in substitute care for 24 hours or more.</li></li></ul></div>"
                    ;
            },
            question6a2: function () {
                return "<div class='question-instruction'><ul><li> Enter the number of months that the child was in foster care, from (1) the date of the most recent entry into foster care to the date the case is being reviewed, or (2) from the date of the most recent entry into foster care to the time of discharge.</li></li></ul></div>"
                    ;
            },
            question6a3: function () {
                return "<div class='question-instruction'>" +
                    "<ul><li> Using the MM/DD/YYYY format, enter the date the child discharged from foster care. This date should be the same as the date provided in section K on the Face Sheet. If the child was not discharged, select Not Applicable.</li></li></ul>"+
                "<h3>Definitions</h3>" +
                "<ul><li> \"Discharge from foster care\" is defined as the point when the child is no longer in foster care under the placement and care responsibility or supervision of the agency. If a child returns home on a trial home visit and the agency retains responsibility or supervision of the child, the child is not considered discharged from foster care unless the trial home visit is longer than 6 months and there was no court order extending the trial home visit beyond 6 months.</li></li></ul>" +
                "</div>";
            },
            question6a4: function () {
                return "<div class='question-instruction text-justify'><ul><li> If item 5 was completed, select the same goal or goals identified in question 5A2. If item 5 was not applicable, refer to the definitions and instructions provided for the table in item 5A1 in order to determine the child’s permanency goal(s). For cases in which the child has been in foster care less than 60 days and no goal is documented, inquire with the caseworker about what the goal is (in most cases it should be reunification).</li></li></ul></div>"
                    ;
            },
            question6b: function () {
                return "<div class='question-instruction text-justify'><ul><li> If concurrent goals are in place and one of the goals has been, or will likely be, achieved in a timely manner, answer question B OR C based on the goal that has been or will be achieved.</li>" +
                    "<li>If concurrent goals are in place (neither of which is other planned permanent living arrangement) but permanency will not be achieved in a timely manner, answer question B No and indicate in the documentation specific barriers to implementing concurrent planning.</li>" +
                    "<li>If concurrent goals are in place and one of the goals is other planned permanent living arrangement but permanency will not be achieved in a timely manner, answer questions B and C No and indicate in the documentation specific barriers to implementing concurrent planning.</li>" +
                    "<li>If the only goal for the child during the period under review was other planned permanent living arrangement, select Not Applicable.</li>" +
                    "<li>In determining a response to question B, consider the time the child has been in foster care as well as agency and court efforts. The following time frames for achievement should be considered for each goal:</li></ul></div>"
                    ;
            },
            question6c1: function () {
                return "<div class='question-instruction'><ul><li> If the child’s current (or most recent) permanency goal was not other planned permanent living arrangement, select Not Applicable.</li>" +
                    "<li>If the child’s current (or most recent) permanency plan is other planned permanent living arrangement, select the response that describes the permanent living arrangement for the child.</li>" +
                    "<li>If the child does not have a permanent living arrangement specified, indicate that in \"Other.\"</li>" +
                    "<li>If the child has an arrangement that does not fit any of the options noted in C1, describe it in \"Other.\"</li>" +
                    "<li>If the goal for the child is noted as \"emancipation/independent living\" without a permanent placement specified, indicate that in \"Other.\"</li></ul></div>"
                    ;
            },
            question6c2: function () {
                return "<div class='question-instruction'><ul><li> If the child’s permanency goal is not other planned permanent living arrangement, select Not Applicable.</li>" +
                    "<li>The date of documentation regarding \"permanency\" is the date on which there was a court order, signed agreement, or other method to formalize that the caretaker or a particular facility would provide care for this child until the child reaches adulthood.</li>" +
                    "<li>If there is no documentation regarding \"permanency\" of the child’s living arrangement, select \"No Date.\"</li>" +
                    "<li>Using the MM/DD/YYYY format, enter the date of documentation regarding \"permanency.\"</li></ul></div>"
                    ;
            },
            question6c: function () {
                return "<div class='question-instruction'><ul><li> If the child’s only goal during the period under review was reunification, guardianship, or adoption, select Not Applicable.</li>" +
                    "<li>Consider the child’s current living arrangement and whether formal steps were completed to make this arrangement permanent.</li>" +
                    "<li>This might include the agency asking foster parents or relatives to agree to and sign a long-term care commitment, or ensuring that a child who is in a long-term care facility to meet special needs will be transferred to an adult facility at the appropriate time.</li>" +
                    "<li>If the child is no longer in foster care, then the answer to question C should be based on the child’s last placement before leaving foster care.</li></ul></div>"
                    ;
            },
            outcome2: function () {
                return "<div class='question-instruction'>Permanency Outcome 2 should be rated as Substantially Achieved if both of the following apply: " +
                    "<ul><li> Not more than one of items 7 through 11 is rated as an Area Needing Improvement.</li>" +
                    "<li> At least one item is rated as a Strength.</li></ul>" +
                    "Permanency Outcome 2 should be rated as Partially Achieved if both of the following apply: " +
                    "<ul><li>At least two items, but fewer than all five items, are rated as an Area Needing Improvement. </li>" +
                    "<li> At least one item is rated as a Strength.</li></ul>" +
                    "Permanency Outcome 2 should be rated as Not Achieved if both of the following apply: " +
                    "<ul><li> No item is rated as a Strength.</li>" +
                    "<li>At least one item is rated as an Area Needing Improvement.</li></ul>" +
                    "Permanency Outcome 2 should be rated as Not Applicable if the following applies: " +
                    "<ul><li> All of items 7 through 11 items are rated as Not Applicable.</li></ul></div>"
                    ;
            },
            item7: function () {
                return "<div class='question-instruction'>" +
                    "<h3>Purpose of Assessment</h3>" +
                    "<ul><li> To determine whether, during the period under review, concerted efforts were made to ensure that siblings in foster care are placed together unless a separation was necessary to meet the needs of one of the siblings.</li>" +
                    "</ul></div>";
            },
            question7a: function () {
                return "<div class='question-instruction text-justify'><ul><li>In answering question A, consider only the location of each of the siblings, not the reason for their location. If the child was placed with siblings for a portion of the period under review, or if the child was placed with one but not all siblings during the period under review, answer question A No.</li>" +
                    "</ul>" +
                    "<h3>Definitions</h3>" +
                    "<ul><li>Siblings are children who have one or more parents in common either biologically, through adoption, or through the marriage of their parents, and with whom the child lived before his or her foster care placement, or with whom the child would be expected to live if the child were not in foster care.</li></ul>" +
                    "</div>";
            },
            question7b: function () {
                return "<div class='question-instruction text-justify'><ul><li>If question A was answered Yes, then question B is NA.</li>" +
                    "<li>Consider the circumstances of the placement of siblings, focusing on whether separation was necessary to meet the child’s needs. For example, were siblings separated temporarily because one sibling needed a specialized treatment or to be in a treatment foster home, or because one sibling was abusive to the other, or because siblings with different biological parents were placed with different relatives?</li>" +
                    "<li>If the separation of siblings is attributed by the agency to a lack of foster homes willing to take sibling groups, question B should be answered No.</li>" +
                    "<li>If siblings were separated for a valid reason, consider the entire period under review and determine whether that valid reason existed during the whole period of separation. For example, the siblings were separated because one sibling needed temporary treatment services. However, during the period under review, the sibling’s treatment services ended. In this situation, determine whether concerted efforts were made to reunite the siblings after the treatment service was completed. If the need for separation no longer existed and no efforts were made to reunite the siblings, then the answer to question B should be No.</li>" +
                    "</ul></div>";
            },
            item8: function () {
                return "<div class='question-instruction'>" +
                    "<h3>Purpose of Assessment</h3>" +
                    "<ul><li> To determine whether, during the period under review, concerted efforts were made to ensure that visitation between a child in foster care and his or her mother, father, and siblings is of sufficient frequency and quality to promote continuity in the child’s relationship with these close family members.</li>" +
                    "</ul>" +
                    "<h3>Definitions</h3>" +
                    "<ul><li> \"Mother\" and \"Father\" in items 8 and 11 are typically defined as the parents/caregivers from whom the child was removed and with whom the agency is working toward reunification.</li>" +
                    "<li>Because the focus of item 8 is to promote continuity in the child’s relationships, do not include in this item a parent who did not have a relationship with the child prior to the child’s entry in foster care, even if the goal is to reunify with that parent. Visitation for a parent in that circumstance may be assessed as a service need in item 12 (see item 12 instructions).</li></ul>" +
                    "</div>";
            },
            question8a1: function () {
                return "<div class='question-instruction'><ul>" +
                    "<li>Answer Not Applicable if (1) contact between the child and the mother or father was not in the child’s best interests, and this was documented in the case file or court order; (2) the whereabouts of the mother or father were not known during the entire period under review, despite documented concerted efforts to locate her or him; (3) the mother’s or father’s parental rights remained terminated during the entire period under review; or (4) the mother or father was deceased during the entire period under review.</li>" +
                    "</ul></div>";
            },
            question8a: function () {
                return "<div class='question-instruction'><ul>" +
                    "<li>If A1 is NA, question A is answered Not Applicable.</li>" +
                    "<li>Determine whether the frequency of visitation during the period under review was sufficient to maintain the continuity of the relationship between the child and the mother or father, depending on the circumstances of the case. For example, frequency may need to be greater for infants and young children who are still forming attachments. Frequency also may need to be greater if reunification is imminent. Visitation should be as frequent as possible, unless safety concerns cannot be appropriately managed with supervision. The opportunity for visitation should not be used as a consequence or reward for parents or for children.</li>" +
                    "<li>If, during the period under review, frequent visitation with the mother or father was not possible (for example, due to incarceration in a facility where visitation is not feasible, or if the parent lives in another state), determine whether there are documented concerted efforts to promote other forms of contact between the child and the mother or father, such as telephone calls or letters, in addition to facilitating visits when possible and appropriate.</li>" +
                    "<li>Address the question of appropriate frequency based on the circumstances of the child and the family, rather than on state policy.</li>" +
                    "</ul></div>";
            },
            question8c: function () {
                return "<div class='question-instruction'><ul>" +
                    "<li>If A1 is NA or Never, question C is answered NA.</li>" +
                    "<li>Determine whether concerted efforts were made to ensure that the quality of parent-child visitation was sufficient to maintain the continuity of the relationship. For example, did visits take place in a comfortable atmosphere and were they of an appropriate length? Did visitation allow for sufficient interaction between mother or father and child? If siblings were involved, did visits allow mother or father to interact with each child individually? If appropriate, were unsupervised visits and visits in the mother’s or father’s home in preparation for reunification allowed?</li>" +
                    "</ul></div>";
            },
            question8b1: function () {
                return "<div class='question-instruction'><ul>" +
                    "<li>Answer Not Applicable if (1) contact between the child and the mother or father was not in the child’s best interests, and this was documented in the case file or court order; (2) the whereabouts of the mother or father were not known during the entire period under review, despite documented concerted efforts to locate her or him; (3) the mother’s or father’s parental rights remained terminated during the entire period under review; or (4) the mother or father was deceased during the entire period under review.</li>" +
                    "</ul></div>";
            },
            question8b: function () {
                return "<div class='question-instruction'><ul>" +
                    "<li>If B1 is NA, question B is answered Not Applicable.</li>" +
                    "<li>Determine whether the frequency of visitation during the period under review was sufficient to maintain the continuity of the relationship between the child and the mother or father, depending on the circumstances of the case. For example, frequency may need to be greater for infants and young children who are still forming attachments. Frequency also may need to be greater if reunification is imminent. Visitation should be as frequent as possible, unless safety concerns cannot be appropriately managed with supervision. The opportunity for visitation should not be used as a consequence or reward for parents or for children.</li>" +
                    "<li>If, during the period under review, frequent visitation with the mother or father was not possible (for example, due to incarceration in a facility where visitation is not feasible, or if the parent lives in another state), determine whether there are documented concerted efforts to promote other forms of contact between the child and the mother or father, such as telephone calls or letters, in addition to facilitating visits when possible and appropriate.</li>" +
                    "<li>Address the question of appropriate frequency based on the circumstances of the child and the family, rather than on state policy.</li>" +
                    "</ul></div>";
            },
            question8d: function () {
                return "<div class='question-instruction'><ul>" +
                    "<li>If B1 is NA or Never, question D is answered NA.</li>" +
                    "<li>Determine whether concerted efforts were made to ensure that the quality of parent-child visitation was sufficient to maintain the continuity of the relationship. For example, did visits take place in a comfortable atmosphere and were they of an appropriate length? Did visitation allow for sufficient interaction between mother or father and child? If siblings were involved, did visits allow mother or father to interact with each child individually? If appropriate, were unsupervised visits and visits in the mother’s or father’s home in preparation for reunification allowed?</li>" +
                    "</ul></div>";
            },
            question8e1: function () {
                return "<div class='question-instruction'><ul>" +
                    "<li>Answer E1 Not Applicable if the child has no siblings in foster care or if contact with all siblings who are in foster care was not considered to be in the best interests of the child for the entire period under review (for example, one sibling is a physical threat to the other sibling or has a history of physical or sexual abuse of the other sibling, and this concern remained throughout the period under review).</li>" +
                    "</ul></div>";
            },
            question8e: function () {
                return "<div class='question-instruction'><ul>" +
                    "<li>If E1 is NA, E should be answered NA.</li>" +
                    "<li>If E1 is Never, E should be answered No.</li>" +
                    "<li>Consider whether the frequency of visits during the period under review was sufficient to maintain the continuity of the sibling relationships.</li>" +
                    "</ul></div>";
            },
            question8f: function () {
                return "<div class='question-instruction'><ul>" +
                    "<li>If E is NA or Never, question F should be answered NA.</li>" +
                    "<li>Determine whether concerted efforts were made to ensure that the quality of sibling visitation was sufficient to maintain the continuity of the relationship. For example, were visits long enough to permit quality interaction? Did sibling contacts only occur in the context of parent visitations? Did visits occur in a comfortable atmosphere?</li>" +
                    "</ul></div>";
            },
            item9: function () {
                return "<div class='question-instruction'>" +
                    "<h3>Purpose of Assessment</h3>" +
                    "<ul><li> To determine whether, during the period under review, concerted efforts were made to maintain the child’s connections to his or her neighborhood, community, faith, extended family, Tribe, school, and friends.</li>" +
                    "</ul></div>";
            },
            question9a: function () {
                return "<div class='question-instruction'><ul>" +
                    "<li>Determine what the important connections were for the child prior to their placement in foster care and then determine whether concerted efforts were made to maintain those connections during the period under review.</li>" +
                    "<li>For a child enrolled in school, consider whether efforts were made to maintain the child in the same school the child was in before placement in foster care, if remaining in the same school was in the child’s best interests.</li>" +
                    "<li>Do not rate this item based on connections to parents/caregivers from whom the child was removed and/or with whom the child will be reunified, or to siblings who are in foster care. Information about sustaining those connections is captured in other items. However, this item may be rated based on connections with siblings who are not in foster care and other extended family members, such as grandparents, uncles, aunts, or cousins.</li>" +
                    "<li>Connections to caregivers from whom the child was removed may also be included in this item if the goal is not to reunify the child with those caregivers, and it is in the child’s best interest to preserve those relationships.</li>" +
                    "<li>If, prior to placement in foster care, the child had a relationship with a biological parent who was not the caregiver the child was removed from or that they are being reunified with (the parent is not part of the case plan), that connection may be included in this item if it is in the child’s best interest to preserve that relationship.</li>" +
                    "</ul></div>";
            },
            question9b: function () {
                return "<div class='question-instruction'><ul>" +
                    "<li>This question is for data collection purposes only and does not affect the rating for this item.</li>" +
                    "<li>If there is no information in the case file that indicates the child is a member of, or eligible for membership in, an Indian Tribe, but you learn through interviews that the child has Native American heritage and no apparent efforts were made to determine this, then the answer to question B is No.</li>" +
                    "<li>If the child entered foster care during the period under review, determine whether timely and appropriate action was taken to determine whether the child is a member of, or eligible for membership in, an Indian Tribe. This may include exploring this with the parents and/or other persons with a relationship to the child, contacting Tribes, and contacting the Bureau of Indian Affairs.</li>" +
                    "<li>If the child entered foster care before the period under review, the answer to question B can be Yes if by the beginning of the period under review an informed determination was made about the child’s membership, or eligibility for membership, in an Indian Tribe and all appropriate steps were taken to determine whether the child is Native American.</li>" +
                    "</ul></div>";
            },
            question9c: function () {
                return "<div class='question-instruction'><ul>" +
                    "<li>If the child is not a member of, or eligible for membership in, an Indian Tribe, the answer to question C is Not Applicable.</li>" +
                    "<li>If the child entered care during the period under review or had a termination of parental rights hearing during the period under review, determine whether timely notice was provided to the Tribe. Timely notice is notice that was received no later than 10 days before the proceeding. If timely notice was not provided, the answer to question C is No.</li>" +
                    "<li>If the child entered care before the period under review and did not have a termination of parental rights hearing during the period under review, the answer to question C is Yes, if, by the beginning of the period under review, all appropriate steps were taken to notify the Tribe.</li>" +
                    "</ul></div>";
            },
            question9d: function () {
                return "<div class='question-instruction'><ul>" +
                    "<li>If the child is not Native American, then the answer to question D is Not Applicable.</li>" +
                    "<li>Determine whether, during the period under review, the child was placed (1) with a member of the child’s extended family; (2) in a foster home licensed, approved, or specified by the Native American child’s Tribe; (3) in another Native American foster home placement; or (4) in an institution approved by a Tribe or operated by a Native American organization. Placement preference is in this order unless another order is specified by Tribal resolution.</li>" +
                    "<li>If the child’s placement was not made in accordance with Indian Child Welfare Act placement preferences, determine whether, during the period under review, there were documented concerted efforts to meet the Act’s placement preferences.</li>" +
                    "</ul></div>";
            },
            item10: function () {
                return "<div class='question-instruction'>" +
                    "<h3>Purpose of Assessment</h3>" +
                    "<ul><li> To determine whether, during the period under review, concerted efforts were made to place the child with relatives when appropriate.</li>" +
                    "</ul></div>";
            },
            question10a1: function () {
                return "<div class='question-instruction text-justify'><ul><li>If the answer to question A1 is No, the answer to question A2 should be Not Applicable.</li>" +
                    "<li>If the answer to question A2 is Yes, you may rate the item as a Strength, and answer Not Applicable to the remaining questions for the item.</li>" +
                    "<li>If the answer to question A1 or A2 is No, answer the remaining questions for this item.</li></ul>" +
                    "<h3>Definitions</h3>" +
                    "<ul><li>\"Relative\" is defined as a person related to the child by blood, marriage, or adoption.</li></ul>"+
                "</div>";
            },

            question10a2: function () {
                return "<div class='question-instruction text-justify'><ul><li>If the answer to question A1 is No, the answer to question A2 should be Not Applicable.</li>" +
                    "<li>If the answer to question A2 is Yes, you may rate the item as a Strength, and answer Not Applicable to the remaining questions for the item.</li>" +
                    "<li>If the answer to question A1 or A2 is No, answer the remaining questions for this item.</li></ul>" +
                    "<h3>Definitions</h3>" +
                    "<ul><li>\"Relative\" is defined as a person related to the child by blood, marriage, or adoption.</li></ul>" +
                    "</div>"
                    ;
            },

            question10b: function () {
                return "<div class='question-instruction text-justify'><ul><li>The answers to questions B and C are NA if the answers to both questions A1 and A2 are Yes.</li>" +
                    "<li>If a child entered foster care during the period under review, determine whether the state followed the requirements of the title IV-E provision that requires states to consider giving preference to placing the child with relatives, and determine whether the state considered such a placement and how (for example, identifying, seeking out, and informing and evaluating the child’s relatives).</li>" +
                    "<li>If the parent’s whereabouts were not known during the entire period under review despite agency efforts to locate the parent, and as a result relatives could not be identified, the answer to question B and/or C should be NA.</li>" +
                    "<li>If a child entered foster care before the period under review and the answer to either question A1 or A2 is No, determine whether, during the period under review, the agency made concerted efforts to search for and assess relatives as placement resources, if appropriate. If all maternal and/or paternal relatives had already been appropriately considered and permanently ruled out before the period under review, the answer to question B and/or C can be Not Applicable. If, however, you determine that, during the period under review, the agency should have reconsidered relatives who had previously been ruled out and they did not, the answer to question B and/or C should be No.</li>" +
                    "</ul></div>";
            },

            question10c: function () {
                return "<div class='question-instruction text-justify'><ul><li>The answers to questions B and C are NA if the answers to both questions A1 and A2 are Yes.</li>" +
                    "<li>If a child entered foster care during the period under review, determine whether the state followed the requirements of the title IV-E provision that requires states to consider giving preference to placing the child with relatives, and determine whether the state considered such a placement and how (for example, identifying, seeking out, and informing and evaluating the child’s relatives).</li>" +
                    "<li>If the parent’s whereabouts were not known during the entire period under review despite agency efforts to locate the parent, and as a result relatives could not be identified, the answer to question B and/or C should be NA.</li>" +
                    "<li>If a child entered foster care before the period under review and the answer to either question A1 or A2 is No, determine whether, during the period under review, the agency made concerted efforts to search for and assess relatives as placement resources, if appropriate. If all maternal and/or paternal relatives had already been appropriately considered and permanently ruled out before the period under review, the answer to question B and/or C can be Not Applicable. If, however, you determine that, during the period under review, the agency should have reconsidered relatives who had previously been ruled out and they did not, the answer to question B and/or C should be No.</li>" +
                    "</ul></div>";
            },

            item11: function () {
                return "<div class='question-instruction'>" +
                    "<h3>Purpose of Assessment</h3>" +
                    "<ul><li> To determine whether, during the period under review, concerted efforts were made to promote, support, and/or maintain positive relationships between the child in foster care and his or her mother and father or other primary caregiver(s) from whom the child had been removed through activities other than just arranging for visitation.</li>" +
                    "</ul>" +
                    "<h3>Definitions</h3>" +
                    "<ul>" +
                    "<li> \"Mother\" and \"Father\" in items 8 and 11 are typically defined as the parents/caregivers from whom the child was removed and with whom the agency is working toward reunification.</li>" +
                    "<li> Because the focus of item 11 is to promote, support, and maintain the child’s relationships with the parents/caregivers from whom the child was removed, do not include in this item a parent who did not have a relationship with the child prior to the child’s entry into foster care, even if the goal is to reunify with that parent. Services to support a parent in developing a new relationship with a child may be assessed as a service need in item 12 (see item 12 instructions).</li>" +
                    "</ul>" +
                    "</div>";
            },

            question11a: function () {
                return "<div class='question-instruction text-justify'><ul><li>Question A should be answered Not Applicable if (1) contact between the child and the mother was not in the child’s best interests, and this was documented in the case file or court order, (2) the whereabouts of the mother were not known during the entire period under review, despite documented concerted efforts to locate her, (3) the mother’s parental rights remained terminated during the entire period under review, or (4) the mother was deceased during the entire period under review.</li>" +
                    "<li>Foster parents’ activities are considered for purposes of this question. For example, if the foster parent provided transportation so that the mother could attend the child’s school event or medical appointment, that would be considered as contributing toward concerted efforts.</li>" +
                    "<li>Do not answer this question based on efforts (or lack of efforts) to ensure the frequency or quality of visitation between the mother and the child. That information is captured under item 8. This question pertains to additional activities to help support, strengthen, or maintain the parent-child relationship.</li></ul></div>"
                    ;
            },

            question11a1: function () {
                return "<div class='question-instruction text-justify'><ul><li>Select NA if the answer to question A is NA.</li>" +
                    "<li>Select NA if the answer to question A is No.</li>" +
                    "</ul></div>";
            },

            question11b: function () {
                return "<div class='question-instruction text-justify'><ul><li>Question B should be answered Not Applicable if (1) contact between the child and the father was not in the child’s best interests, and this was documented in the case file or court order, (2) the whereabouts of the father were not known during the entire period under review, despite documented concerted efforts to locate him, (3) the father’s parental rights remained terminated during the entire period under review, or (4) the father was deceased during the entire period under review.</li>" +
                    "<li>Foster parents’ activities are considered for purposes of this question. For example, if the foster parent provided transportation so that the father could attend the child’s school event or medical appointment, that would be considered as contributing toward concerted efforts.</li>" +
                    "<li>Do not answer this question based on efforts (or lack of efforts) to ensure the frequency or quality of visitation between the father and the child. That information is captured under item 8. This question pertains to additional activities to help support, strengthen, or maintain the parent-child relationship.</li></ul></div>"
                    ;
            },

            question11b1: function () {
                return "<div class='question-instruction text-justify'><ul><li>Select NA if the answer to question B is NA.</li>" +
                    "<li>Select NA if the answer to question B is No.</li>" +
                    "</ul></div>";
            },

            rating: {
                item4: function () {
                    return "<div class='question-instruction'>Item 4 should be rated as a Strength if either of the following applies:" +
                        "<ul><li>The answer to question A is one (1), the answer to question B is Not Applicable, and the answer to question C is Yes.</li>" +
                        "<li>The answer to question A is greater than one (1), but the answers to questions B and C are Yes.</li></ul>" +
                        "Item 4 should be rated as an Area Needing Improvement if either of the following applies:" +
                        "<ul><li>The answer to question A is one (1), but the answer to question C is No.</li>" +
                        "<li>The answer to question A is greater than one (1), and the answer to question B and/or C is No.</li></ul>" +
                        "There are no circumstances under which item 4 could be rated as Not Applicable." +
                        "</div>"
                        ;
                },
                item5: function () {
                    return "<div class='question-instruction'>Item 5 should be rated as a Strength if any one of the following criteria apply:" +
                        "<ul><li>The answers to questions A3, B, and C are Yes or NA, and the answers to questions D and E are No.</li>" +
                        "<li>The answers to questions A3, B, and C are Yes or NA, and D and F are Yes.</li>" +
                        "<li>The answers to questions A3, B, and C are Yes or NA, the answer to question D is No, and the answers to questions E and F are Yes.</li>" +
                        "<li>The answers to questions A3, B, and C are Yes or NA, the answer to question D or E is Yes, the answer to question F is No, and the answer to question G is Yes.</li></ul>" +
                        "Item 5 should be rated as an Area Needing Improvement if any of the following apply:" +
                        "<ul><li>The answer to question A3, B, or C is No.</li>" +
                        "<li>The answers to questions A3, B, and C are Yes or NA, but the answer to question D or E is Yes, and the answers to questions F and G are No.</li></ul>" +
                        "Item 5 should be rated as Not Applicable if the response to the question of applicability is No." +
                        "</div>"
                        ;
                },
                item6: function () {
                    return "<div class='question-instruction'>Item 6 should be rated as a Strength if the answer to either question B or C is Yes.</p>" +
                        "Item 6 should be rated as an Area Needing Improvement if the answer to question B and/or C is No.</p>" +
                        "There are no circumstances under which item 6 could be rated as Not Applicable.</p>" +
                        "</div>"
                        ;
                },
                item7: function () {
                    return "<div class='question-instruction'>Item 7 should be rated as a Strength if either of the following applies:" +
                        "<ul><li>The answer to question A is Yes.</li>" +
                        "<li>The answer to question A is No, but the answer to question B is Yes.</li></ul>" +
                        "Item 7 should be rated as an Area Needing Improvement if the answers to questions A and B are No.</p>" +
                        "Item 7 should be rated as Not Applicable if the response to the question of applicability is No.</p>" +
                        "</div>"
                        ;
                },
                item8: function () {
                    return "<div class='question-instruction'>Item 8 should be rated as a Strength if at least one of the questions A through F is answered Yes and the other questions are answered Not Applicable.</p>" +
                        "Item 8 should be rated as an Area Needing Improvement if any one of the questions A through F is answered No.</p>" +
                        "Item 8 should be rated as Not Applicable if the response to the question of applicability is No.</p>" +
                        "</div>"
                        ;
                },

                item9: function () {
                    return "<div class='question-instruction'>Item 9 should be rated as a Strength if the answer to question A is Yes and the answers to questions C and D are either Yes or Not Applicable.</p>" +
                        "Item 9 should be rated as an Area Needing Improvement if either of the following applies:</p>" +
                        "<ul><li>The answer to question A is Yes, but the answer to question C and/or D is No.</li>" +
                        "<li>The answer to question A is No, regardless of the answers to questions C and D.</li></ul>" +
                        "Item 9 should be rated as Not Applicable if the response to the question of applicability is No.</p>" +
                        "The answer to question B is not considered in rating this item.</p>" +
                        "</div>";
                },
                item10: function () {
                    return "<div class='question-instruction'>Item 10 should be rated as a Strength if either of the following applies:" +
                        "<ul><li>The answers to both questions A1 and A2 are Yes.</li>" +
                        "<li>The answer to either question A1 or A2 is No, but the answers to questions B and/or C are Yes or Not Applicable.</li></ul>" +
                        "Item 10 should be rated as an Area Needing Improvement if both of the following apply:" +
                        "<ul><li>The answer to either question A1 or A2 is No.</li>" +
                        "<li>The answer to question B and/or C is No.</li></ul>" +
                        "Item 10 should be rated as Not Applicable if the response to the question of applicability is No." +
                        "</div>";
                },
                item11: function () {
                    return "<div class='question-instruction'>Item 11 should be rated as a Strength if either of the following applies:" +
                        "<ul><li>The answers to both questions A and B are Yes.</li>" +
                        "<li>The answer to either question A or B is Yes and the answer to the other question is Not Applicable.</li></ul>" +
                        "Item 11 should be rated as an Area Needing Improvement if the answer to question A and/or B is No.</p>" +
                        "Item 11 should be rated as Not Applicable if the response to the question of applicability is No.</p>" +
                        "</div>";
                }
            }

        },
        wellbeing: {
            outcome1: function () {
                return "<div class='question-instruction'>Well-Being Outcome 1 should be rated as Substantially Achieved if both of the following apply:" +
                    "<ul><li> Item 12 is rated as a Strength, and</li>" +
                    "<li> Only one of items 13, 14, and 15 is rated as an Area Needing Improvement.</li></ul>" +
                    "Well-Being Outcome 1 should be rated as Partially Achieved if either of the following applies:" +
                    "<ul><li> Item 12 is rated as an Area Needing Improvement, but at least one other item is rated as a Strength.</li>" +
                    "<li>Item 12 is rated as a Strength, but at least two of items 13, 14, and 15 are rated as Areas Needing Improvement.</li></ul>" +
                    "Well-Being Outcome 1 should be rated as Not Achieved if the following applies:" +
                    "<ul><li> All applicable items are rated as Areas Needing Improvement.</li>" +
                    "</ul></div>";
            },
            item12: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<h3>Purpose of Assessment</h3>" +
                    "<ul><li> To determine whether, during the period under review, the agency (1) made concerted efforts to assess the needs of children, parents, and foster parents (both initially, if the child entered foster care or the case was opened during the period under review, and on an ongoing basis) to identify the services necessary to achieve case goals and adequately address the issues relevant to the agency’s involvement with the family, and (2) provided the appropriate services.</li>" +
                    "</ul></div>";
            },
            item12a: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li> If the case is a foster care case, determine whether the agency assessed the needs of, and provided services for, the target child in the case, even if there are other children in the family in foster care or in the home.</li>" +
                    "<li>If the case is an in-home services case, determine whether the agency assessed the needs of, and provided services for, all children in the family, unless you determine that, based on case circumstances, only specific children in the home should be assessed and provided with services.</li>" +
                    "</ul></div>";
            },


            question12a1: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li> If the case was opened during the period under review, focus on whether the agency conducted an initial comprehensive assessment as a basis for developing a case plan, and whether ongoing assessment was conducted as appropriate.</li>" +
                    "<li>If the case was opened before the period under review, focus on whether the agency conducted periodic comprehensive needs assessments (as appropriate) during the period under review to update information relevant to ongoing case planning.</li>" +
                    "<li>Assessment of needs may take different forms. For example, needs may be assessed through a formal evaluation conducted by another agency or by a contracted provider or through a more informal case planning process involving intensive interviews with the child, family, and service providers. Answer question A1 based on a determination of whether the agency made concerted efforts to achieve an in-depth understanding of the needs of the child, regardless of whether the needs were assessed in a formal or informal manner. Consequently, the evaluation of the assessment should focus on its adequacy in accurately assessing the child’s needs in addition to whether one was conducted.</li>" +
                    "<li>Answer this question with regard to an assessment of needs other than those related to children’s education, physical health, and mental/behavioral health (including substance abuse). The assessment of the child’s needs related to these issues is addressed in later items. Needs that should be assessed in this item include those related to social/emotional development that are not connected to other physical health or mental health issues. These may include social competencies, attachment and caregiver relationships, social relationships and connections, social skills, self-esteem, and coping skills. If the case is a foster care case, and the child is an adolescent, determine whether the child’s needs for independent living services are being assessed on an ongoing basis as part of the child’s independent living plan. In making this determination, consider the following:</li>" +
                    "<li>Did the agency assess for independent living skills?</li>" +
                    "<li>Is there an independent living plan in the file? (This is required for all youth age 16 and older.)</li>" +
                    "</ul></div>";
            },
            question12a2: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li> If the answer to question A1 is Yes, but the result of the assessment was that no service needs were identified other than those related to education, physical health, and mental/behavioral health (including substance abuse), and therefore no services were provided other than services to address those needs, the answer to question A2 should be Not Applicable.</li>" +
                    "<li>Focus on the agency’s provision of services during the period under review. If services were provided before the period under review, and an assessment conducted during the period under review indicated no further service needs, then the answer to question A2 should be Not Applicable.</li>" +
                    "<li>Answer this question with regard to provision of services other than those related to education, physical health, or mental/behavioral health (including substance abuse). The assessment of service provision related to these issues is addressed in later items. If item 2 addresses all the safety-related services provided to the family, do not capture those services in this item.</li>" +
                    "<li>Determine whether the services provided matched identified needs. For example, were the services provided simply because those were the services available or were they provided because the assessment revealed a particular need for a particular type of service?</li>" +
                    "<li>If the case is a foster care case, independent living services should be provided to all youth age 16 and older and to children of any age with a goal of emancipation/independence or \"other planned permanent living arrangement\" who are expected to eventually exit foster care to independence. Consider whether concerted efforts were made to provide the child with services to adequately prepare the child for independent living when the child leaves foster care, such as post-high school planning, life skills classes, employment training, financial planning skills training, and transitional services.</li>" +
                    "<li>Examples of services that are assessed under this item include child care services that are not required for the child’s safety (those services would be covered under item 2), mentoring programs that are not related to the child’s education, recreational services, teen parenting education, preparation for adoption and other permanency goals, services that address family relationships that are not mental health in nature (for example, services to assist children in reestablishing or maintaining family ties), and services to assist the child that are recommended by a therapist or other provider but are not mental health-related (such as enrollment in an activity to assist with social skills or to boost self-esteem).</li>" +
                    "</ul></div>";
            },
            item12b: function () {
                return "<div class='question-instruction text-justify'>In-home services cases:" +
                    "<ul><li> \"Mother\" and \"Father\" in items 12, 13, and 15, are typically defined as the parents/caregivers with whom the children were living when the agency became involved with the family and with whom the children will remain (for example, biological parents, relatives, guardians, adoptive parents).</li>" +
                    "<li>If a biological parent does not fall into any of the categories above, determine whether that parent should be included in this item based on the circumstances of the case. Some things to consider in this determination are: the reason for the agency’s involvement and the identified perpetrators in the case, the status of the children’s relationship with the parent, the nature of the case (court supervised or voluntary) and the length of case opening. If a biological parent indicates a desire during the period under review to be involved with the child and it is in the child’s best interests to do so, they should be assessed in this item.</li></ul>" +
                    "Foster care cases:" +
                    "<ul><li>\"Mother\" and \"Father\" in items 12, 13, and 15 are typically defined as the parents/caregivers from whom the child was removed and with whom the agency is working toward reunification.</li>" +
                    "<li>\"Mother\" and \"Father\" in items 12, 13, and 15 include biological parents who were not the parents from whom the child was removed.</li>" +
                    "<li>\"Mother\" and \"Father\" include adoptive parents if the adoption has been finalized during the period under review.</li></ul>" +
                    "Tip" +
                    "<ul><li>If the whereabouts of a parent were unknown during the PUR and the agency did not make concerted efforts to locate them, the applicable item questions for that parent should be answered No, resulting in an Area Needing Improvement rating for sub-item 12B as well as item 12. This parent should not be assessed in items 13 and 15. Questions for that parent in those items should be answered NA. In Well-Being Outcome 1, concerns about efforts to locate a parent should only be reflected in item 12.</li></ul>"
                    ;
            },
            question12b1: function () {
                return "<div class='question-instruction text-justify'><ul><li>If the case was opened during the period under review, focus on whether the agency conducted an initial comprehensive assessment as a basis for developing a case plan, and whether ongoing assessment was conducted as appropriate.</li>" +
                    "<li>If the case was opened before the period under review, focus on whether the agency conducted periodic comprehensive needs assessments (as appropriate) during the period under review to update information relevant to ongoing case planning.</li>" +
                    "<li>Determine whether the agency has made concerted efforts to ensure that case planning is based on an in-depth understanding of the needs of the mother, regardless of whether the needs were assessed in a formal or informal manner. (Assessment of needs may take different forms. For example, needs may be assessed through a formal psychosocial evaluation conducted by another agency or by a contracted provider or through a more informal case planning process involving intensive interviews with the child, family, and service providers.)</li>" +
                    "<li>Assessment of mother’s needs refers to a determination of what the mother needs to provide appropriate care and supervision and to ensure the well-being of her children. This could include mental and physical health needs (as later items do not address these concerns for the parents), if those needs impact the parent’s capacity to care for the children. This could also include an assessment of needs related to supporting a biological parent’s relationship with the child if they did not have an established relationship prior to the child’s entry into foster care.</li>" +
                    "</ul></div>"
            },
            question12b3: function () {
                return "<div class='question-instruction text-justify'><ul><li>If an assessment was conducted but no service needs were identified, this question can be answered Not Applicable.</li>" +
                    "<li>Appropriate services are those that enhance the mother’s ability to provide care and supervision and support the well-being of her child(ren); for example, substance abuse treatment, parenting skills classes, or visitation and/or family counseling services for a biological parent who is establishing a new relationship with the child. Item 2 should address all the safety-related services provided to the family. Do not capture those services in this item. Visitation services would only be included for a biological parent in this item if the parent was not included in item 8.</li>" +
                    "</ul></div>";
            },
            question12b2: function () {
                return "<div class='question-instruction text-justify'><ul><li>If the case was opened during the period under review, focus on whether the agency conducted an initial comprehensive assessment as a basis for developing a case plan, and whether ongoing assessment was conducted as appropriate.</li>" +
                    "<li>If the case was opened before the period under review, focus on whether the agency conducted periodic comprehensive needs assessments (as appropriate) during the period under review to update information relevant to ongoing case planning.</li>" +
                    "<li>Determine whether the agency has made concerted efforts to ensure that case planning is based on an in-depth understanding of the needs of the father, regardless of whether the needs were assessed in a formal or informal manner. (Assessment of needs may take different forms. For example, needs may be assessed through a formal psychosocial evaluation conducted by another agency or by a contracted provider or through a more informal case planning process involving intensive interviews with the child, family, and service providers.)</li>" +
                    "<li>Assessment of father’s needs refers to a determination of what the father needs to provide appropriate care and supervision and to ensure the well-being of his children. This could include mental and physical health needs (as later items do not address these concerns for the parents), if those needs impact the parent’s capacity to care for the children. This could also include an assessment of needs related to supporting a biological parent’s relationship with the child if they did not have an established relationship prior to the child’s entry into foster care.</li>" +
                    "</ul></div>";
            },
            question12b4: function () {
                return "<div class='question-instruction text-justify'><ul><li>If an assessment was conducted but no service needs were identified, this question can be answered Not Applicable.</li>" +
                    "<li>Appropriate services are those that enhance the father’s ability to provide care and supervision and support the well-being of his child(ren); for example, substance abuse treatment, parenting skills classes, or visitation and/or family counseling services for a biological parent who is establishing a new relationship with the child. Item 2 should address all the safety-related services provided to the family. Do not capture those services in this item. Visitation services would only be included for a biological parent in this item if the parent was not included in item 8.</li>" +
                    "</ul></div>";
            },
            item12c: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<h3>Definitions</h3>" +
                    "<ul><li>Foster parents are defined as related or non-related caregivers who have been given responsibility for care of the child by the agency while the child is under the placement and care responsibility and supervision of the agency. This includes pre-adoptive parents if the adoption has not been finalized.</li></ul>"
                    ;
            },
            question12c1: function () {
                return "<div class='question-instruction text-justify'><ul><li>All foster parents who cared for the child during the period under review are included in this assessment.</li>" +
                    "<li>Determine whether an assessment was conducted to identify what the foster parents needed to enhance their capacity to provide appropriate care and supervision to the child in their home, such as respite care, assistance with transportation, or counseling to address the child’s behavior problems.</li>" +
                    "<li>Determine whether assessment of foster parent needs is done on an ongoing basis. If there is no evidence in the case file that the agency assessed the needs of the foster parents at any time during the period under review, and the foster parents (if available for interview) indicate that they have not been assessed, then the answer to question C1 should be No.</li>" +
                    "</ul>" +
                    "<h3>Tip</h3>" +
                    "For sub-item 12C, please consider any concerns identified in item 4 regarding the child's stability in foster care placement(s) when determining whether foster parents' needs were adequately assessed and whether appropriate services were provided to them.</p>" +
                    "</div>";
            },
            question12c2: function () {
                return "<div class='question-instruction text-justify'><ul><li>The answer to question C2 should be Not Applicable if needs were assessed but no service needs were identified.</li>" +
                    "<li>All foster parents who cared for the child during the period under review are included in this assessment.</li>" +
                    "</ul>" +
                    "<h3>Tip</h3>" +
                    "For sub-item 12C, please consider any concerns identified in item 4 regarding the child's stability in foster care placement(s) when determining whether foster parents' needs were adequately assessed and whether appropriate services were provided to them.</p>"+
                "</div>";
            },
            item13: function () {
                return "<div class='question-instruction'>" +
                    "<h3>Purpose of Assessment</h3>" +
                    "<ul><li>To determine whether, during the period under review, concerted efforts were made (or are being made) to involve parents and children (if developmentally appropriate) in the case planning process on an ongoing basis.</li>" +
                    "</ul>" +
                    "<h3>Definitions</h3>" +
                    "In-home services cases:" +
                    "<ul>" +
                    "<li>\"Mother\" and \"Father\" in items 12, 13, and 15, are typically defined as the parents/caregivers with whom the children were living when the agency became involved with the family and with whom the children will remain (for example, biological parents, relatives, guardians, adoptive parents).</li>" +
                    "<li>If a biological parent does not fall into any of the categories above, determine whether that parent should be included in this item based on the circumstances of the case. Some things to consider in this determination are: the reason for the agency’s involvement and the identified perpetrators in the case, the status of the children’s relationship with the parent, the nature of the case (court supervised or voluntary) and the length of case opening. If a biological parent indicates a desire during the period under review to be involved with the child and it is in the child’s best interests to do so, they should be assessed in this item.</li>" +
                    "</ul>" +
                    "Foster care cases:" +
                    "<ul>" +
                    "<li>\"Mother\" and \"Father\" in items 12, 13, and 15 are typically defined as the parents/caregivers from whom the child was removed and with whom the agency is working toward reunification.</li>" +
                    "<li>\"Mother\" and \"Father\" in items 12, 13, and 15 include biological parents who were not the parents from whom the child was removed.</li>" +
                    "<li>\"Mother\" and \"Father\" include adoptive parents if the adoption has been finalized during the period under review.</li>" +
                    "</ul>" +
                    "Tip" +
                    "<ul>" +
                    "<li>If the whereabouts of a parent were unknown during the PUR and the agency did not make concerted efforts to locate them, the applicable item questions for that parent should be answered No, resulting in an Area Needing Improvement rating for sub-item 12B as well as item 12. This parent should not be assessed in items 13 and 15. Questions for that parent in those items should be answered NA. In Well-Being Outcome 1, concerns about efforts to locate a parent should only be reflected in item 12.</li>" +
                    "</ul>"+
                "</div>";
            },
            question13a: function () {
                return "<div class='question-instruction text-justify'><ul><li>Select Not Applicable if the child is not old enough to participate in case planning or is incapacitated. Although the capacity to participate actively in case planning will need to be decided on a case-by-case basis, as a guideline, most children who are elementary school-aged or older may be expected to participate to some extent.</li>" +
                    "<li>If the case is a foster care case, item 13 applies to the target child only. If the case is an in-home services case, item 13 applies to all children in the family home unless you determine that based on case circumstances only specific children in the home should be engaged in case planning (for example, only children receiving services from the agency).</li>" +
                    "<li>If the case is a foster care case, answer No to this question if there is no case plan in the case file.</li>" +
                    "<li>If the case is an in-home services case, and there is no case plan in the file (some states require that an identifiable written case plan be included in the file for in-home services cases), identify the extent to which the children (if developmentally appropriate) were involved in determining: (1) their strengths and needs, (2) the type and level of services needed, and (3) their goals and progress toward meeting them. Determine whether this information was documented in the case file in any way.</li>" +
                    "<li>Do not assume that a child’s knowledge about his or her case plan is an indicator of active involvement.</li>" +
                    "<li>If the initial case plan was developed before the period under review, focus on the children’s involvement during the period under review in the ongoing case planning process, particularly with regard to evaluating progress and making changes in the type and level of services needed as well as understanding changes made to their permanency goal (in foster care cases).</li>" +
                    "</ul>" +
                    "<h3>Definitions</h3>" +
                    "<ul><li>\"Actively involved\" means that the agency consulted with the child (as developmentally appropriate) regarding the child’s goals and services, explained the plan and terms used in the plan in language that the child can understand, and included the child in periodic case planning meetings, particularly if any changes are being considered in the plan.</li></ul>"+
                "</div>";
            },
            question13b: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li>Select Not Applicable if all case participants being assessed as Mother meet the criteria for Not Applicable in the item 13 rating criteria above.</li>" +
                    "<li>If the initial case plan was developed before the period under review, focus on the mother’s involvement during the period under review in the ongoing case planning process, particularly with regard to evaluating progress and making changes in the plan.</li>" +
                    "<li>Select No if the agency did not make concerted efforts to locate a mother whose whereabouts were unknown.</li>" +
                    "</ul>" +
                    "<h3>Definitions</h3>" +
                    "<ul><li>\"Actively involved\" means that the agency involved the mother or father in (1) identifying strengths and needs, (2) identifying services and service providers, (3) establishing goals in case plans, (4) evaluating progress toward goals, and (5) discussing the case plan.</li></ul>"+
                "</div>";
            },
            question13c: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li>Select Not Applicable if all case participants being assessed as Father meet the criteria for Not Applicable in the item 13 rating criteria above.</li>" +
                    "<li>If the initial case plan was developed before the period under review, focus on the father’s involvement during the period under review in the ongoing case planning process, particularly with regard to evaluating progress and making changes in the plan.</li>" +
                    "<li>Select No if the agency did not make concerted efforts to locate a father whose whereabouts were unknown.</li>" +
                    "</ul>" +
                    "<h3>Definitions</h3>" +
                    "<ul><li>\"Actively involved\" means that the agency involved the mother or father in (1) identifying strengths and needs, (2) identifying services and service providers, (3) establishing goals in case plans, (4) evaluating progress toward goals, and (5) discussing the case plan.</li></ul>"+
                "</div>";
            },
            item14: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<h3>Purpose of Assessment</h3>" +
                    "<ul><li>To determine whether the frequency and quality of visits between caseworkers and the child(ren) in the case are sufficient to ensure the safety, permanency, and well-being of the child(ren) and promote achievement of case goals.</li>" +
                    "</ul></div>";
            },
            question14a1: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li> If the case is an in-home services case, question A1 should be answered for all children in the family home.</li>" +
                    "<li>If the case is a foster care case, question A1 should be answered only for the target child in the case.</li>" +
                    "<li>Consider only the pattern of visits during the period under review and not over the life of the case.</li>" +
                    "<li>Focus on the visitation frequency of the agency caseworker (or other responsible party) responsible for the case and not on other service providers who may be visiting the children.</li>" +
                    "<li>Determine the most typical pattern of visitation during the period under review, because the actual frequency may vary in specific time periods.</li>" +
                    "</ul>" +
                    "<h3>Definitions</h3>" +
                    "<ul><li> \"Other responsible party\" refers to contracted service providers who have full responsibility for case planning and case management (for example, fully or partially privatized child welfare systems where full case management responsibilities are delegated to contract agencies). It does not refer to contracted service providers that provide services while the agency maintains decision-making and case management responsibilities regarding the case or the child.</li>" +
                    "<li>A \"visit\" is defined as a face-to-face contact between the caseworker or other responsible party and the child.</li>" +
                    "</ul>" +
                    "</div>";
            },
            question14a: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li>If A1 is Never, question A is No.</li>" +
                    "<li>In responding to question A, consider the frequency of visits selected in question A1.</li>" +
                    "<li>Base your determination on the frequency necessary to ensure the child’s safety, permanency, and well-being and not on compliance with state policy requirements regarding caseworker contacts or visits with the child. For example, if state policy is that the caseworker should visit the child at least once a month and they complied with that, but you determine that given the circumstances of the case (for example, there are safety concerns), the caseworker should visit more frequently, then the answer to question A should be No.</li>" +
                    "<li>If the child is in a placement in another state, you should determine whether a caseworker from the jurisdiction in which the child is placed, or a caseworker from the jurisdiction from which the child was placed, visits with the child in the placement on a schedule that is consistent with the child’s needs.</li>" +
                    "<li>If the typical pattern of visits is less than once a month, the answer to question A should be No unless you determine that there is a substantial justification for a Yes answer.</li>" +
                    "<li>For an in-home services case, any children in the home who were assessed in item 12 should be visited at least monthly unless there is substantial justification for less than monthly visits. Frequency of visitation with other children in the family home should be determined based on the circumstances of the case, such as any risk and safety concerns present during the period under review, the age and vulnerability of the children, the reason for the agency’s involvement with the family, etc.</li>" +
                    "</ul>" +
                    "<h3>Definitions</h3>" +
                    "<ul><li> \"Other responsible party\" refers to contracted service providers who have full responsibility for case planning and case management (for example, fully or partially privatized child welfare systems where full case management responsibilities are delegated to contract agencies). It does not refer to contracted service providers that provide services while the agency maintains decision-making and case management responsibilities regarding the case or the child.</li>" +
                    "<li>A \"visit\" is defined as a face-to-face contact between the caseworker or other responsible party and the child.</li>" +
                    "</ul>" +
                    "</div>";
            },
            question14b: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li>If A1 is Never, question B is Not Applicable.</li>" +
                    "<li>Consider both the length of the visit (for example, was it of sufficient duration to address key issues with the child, or was it just a brief visit) and the location of the visit (for example, was it in a place conducive to open and honest conversation, such as a private home, or was it in a more formal or public environment, such as a court house or restaurant?).</li>" +
                    "<li>Consider whether the caseworker (or other responsible party) saw the child alone or whether the parent or foster parent was usually present during the caseworker’s visits with the child. If the child was older than an infant, and the caseworker did not see the child alone for at least part of each visit, then the answer to question B should be No.</li>" +
                    "<li>Also consider the topics that were discussed during the visits, if that information is available in the case file or through interviews. For the answer to question B to be Yes, there must be some evidence that the caseworker and the child addressed issues pertaining to the child’s needs, services, and case goals during the visits.</li>" +
                    "</ul></div>";
            },
            item15: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<h3>Purpose of Assessment</h3>" +
                    "<ul><li>To determine whether, during the period under review, the frequency and quality of visits between caseworkers and the mothers and fathers of the child(ren) are sufficient to ensure the safety, permanency, and well-being of the child(ren) and promote achievement of case goals.</li>" +
                    "</ul>" +
                    "<h3>Definitions</h3>" +
                    "In-home services cases:" +
                    "<ul><li>\"Mother\" and \"Father\" in items 12, 13, and 15, are typically defined as the parents/caregivers with whom the children were living when the agency became involved with the family and with whom the children will remain (for example, biological parents, relatives, guardians, adoptive parents).</li>" +
                    "<li>If a biological parent does not fall into any of the categories above, determine whether that parent should be included in this item based on the circumstances of the case. Some things to consider in this determination are: the reason for the agency’s involvement and the identified perpetrators in the case, the status of the children’s relationship with the parent, the nature of the case (court supervised or voluntary) and the length of case opening. If a biological parent indicates a desire during the period under review to be involved with the child and it is in the child’s best interests to do so, they should be assessed in this item.</li></ul>" +
                    "Foster care cases:" +
                    "<ul><li>\"Mother\" and \"Father\" in items 12, 13, and 15 are typically defined as the parents/caregivers from whom the child was removed and with whom the agency is working toward reunification.</li>" +
                    "<li>\"Mother\" and \"Father\" in items 12, 13, and 15 include biological parents who were not the parents from whom the child was removed.</li>" +
                    "<li>\"Mother\" and \"Father\" include adoptive parents if the adoption has been finalized during the period under review.</li></ul>" +
                    "Tip" +
                    "<ul><li>If the whereabouts of a parent were unknown during the PUR and the agency did not make concerted efforts to locate them, the applicable item questions for that parent should be answered No, resulting in an Area Needing Improvement rating for sub-item 12B as well as item 12. This parent should not be assessed in items 13 and 15. Questions for that parent in those items should be answered NA. In Well-Being Outcome 1, concerns about efforts to locate a parent should only be reflected in item 12.</li></ul>" +
                "</div>";
            },
            question15a1: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li>Select Not Applicable if all case participants being assessed as Mother meet the criteria for Not Applicable in the item 15 rating criteria above. Consider only the pattern of visits during the period under review and not over the life of the case.</li>" +
                    "<li>Determine the most typical pattern of visitation during the period under review, because the actual frequency may vary in specific time periods.</li>" +
                    "<li>Select Never for question A1 if the agency reported that the whereabouts of the mother were unknown, but there was no evidence that the agency made concerted efforts to locate the mother.</li>" +
                    "</ul>" +
                    "<h3>Definitions</h3>" +
                    "<ul><li>\"Other responsible party\" refers to contracted service providers who have full responsibility for case planning and case management (for example, fully or partially privatized child welfare systems where full case management responsibilities are delegated to contract agencies). It does not refer to contracted service providers who provide services while the agency maintains decision-making and case management responsibilities regarding the case or the child.</li>" +
                    "<li>A \"visit\" is defined as a face-to-face contact between the caseworker or other responsible party and the parent.</li>" +
                    "</ul>" +
                    "</div>";

            },
            question15a2: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li>If the answer to question A1 is Not Applicable, the answer to question A2 also should be Not Applicable.</li>" +
                    "<li>Consider the frequency of visits that is necessary to effectively address: (1) the child’s safety, permanency, and well-being, and (2) achievement of case goals. Do not answer the question based on the caseworker visit requirements that may be established by state policy.</li>" +
                    "<li>The answer to question A2 should be No if the typical pattern of contact is less than once a month, unless you have a substantial justification for answering Yes.</li>" +
                    "</ul>" +
                    "<h3>Definitions</h3>" +
                    "<ul><li>\"Other responsible party\" refers to contracted service providers who have full responsibility for case planning and case management (for example, fully or partially privatized child welfare systems where full case management responsibilities are delegated to contract agencies). It does not refer to contracted service providers who provide services while the agency maintains decision-making and case management responsibilities regarding the case or the child.</li>" +
                    "<li>A \"visit\" is defined as a face-to-face contact between the caseworker or other responsible party and the parent.</li>" +
                    "</ul>" +
                    "</div>";
            },
            question15b1: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li>Select Not Applicable if all case participants being assessed as Father meet the criteria for Not Applicable in the item 15 rating criteria above. Consider only the pattern of visits during the period under review and not over the life of the case.</li>" +
                    "<li>Determine the most typical pattern of visitation during the period under review, because the actual frequency may vary in specific time periods.</li>" +
                    "<li>Select Never for question B1 if the agency reported that the whereabouts of the father were unknown, but there was no evidence that the agency made concerted efforts to locate the father.</li>" +
                    "</ul>" +
                    "<h3>Definitions</h3>" +
                    "<ul><li>\"Other responsible party\" refers to contracted service providers who have full responsibility for case planning and case management (for example, fully or partially privatized child welfare systems where full case management responsibilities are delegated to contract agencies). It does not refer to contracted service providers who provide services while the agency maintains decision-making and case management responsibilities regarding the case or the child.</li>" +
                    "<li>A \"visit\" is defined as a face-to-face contact between the caseworker or other responsible party and the parent.</li>" +
                    "</ul></div>";
            },
            question15b2: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li>If the answer to question B1 is Not Applicable, the answer to question B2 also should be Not Applicable.</li>" +
                    "<li>Consider the frequency of visits that is necessary to effectively address: (1) the child’s safety, permanency, and well-being, and (2) achievement of case goals. Do not answer the question based on the caseworker visit requirements that may be established by state policy.</li>" +
                    "<li>The answer to question B2 should be No if the typical pattern of contact is less than once a month, unless you have a substantial justification for answering Yes.</li>" +
                    "</ul>" +
                    "<h3>Definitions</h3>" +
                    "<ul><li>\"Other responsible party\" refers to contracted service providers who have full responsibility for case planning and case management (for example, fully or partially privatized child welfare systems where full case management responsibilities are delegated to contract agencies). It does not refer to contracted service providers who provide services while the agency maintains decision-making and case management responsibilities regarding the case or the child.</li>" +
                    "<li>A \"visit\" is defined as a face-to-face contact between the caseworker or other responsible party and the parent.</li>" +
                    "</ul></div>";
            },
            question15c: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li>Consider both the length of the visit (for example, was it of sufficient duration to address key issues with the mother, or was it just a brief visit?) and the location of the visit (for example, was it in a place conducive to open and honest conversation, such as a private home, or was it in a formal or public environment that might be uncomfortable for the parent, such as a court house or restaurant?).</li>" +
                    "<li>Consider whether the visits between the caseworker or other responsible party and the mother focused on issues pertinent to case planning, service delivery, and goal achievement.</li>" +
                    "<li>If the answer to question A1 is Not Applicable or Never, the answer to question C should be Not Applicable.</li>" +
                    "</ul></div>";
            },
            question15d: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li>Consider both the length of the visit (for example, was it of sufficient duration to address key issues with the father, or was it just a brief visit?) and the location of the visit (for example, was it in a place conducive to open and honest conversation, such as a private home, or was it in a formal or public environment that might be uncomfortable for the parent, such as a court house or restaurant?).</li>" +
                    "<li>Consider whether the visits between the caseworker or other responsible party and the father focused on issues pertinent to case planning, service delivery, and goal achievement.</li>" +
                    "<li>If the answer to question B1 is Not Applicable or Never, the answer to question D should be Not Applicable.</li>" +
                    "</ul></div>";
            },
            outcome2: function () {
                return "<div class='question-instruction'>Well-Being Outcome 2 should be rated as Substantially Achieved if the following applies:" +
                    "<ul><li> Item 16 is rated as a Strength.</li></ul>" +
                    "Well-Being Outcome 2 should be rated as Partially Achieved if the following applies:" +
                    "<ul><li> Item 16 is rated as an Area Needing Improvement, but question A or B is answered Yes.</li></ul>" +
                    "Well-Being Outcome 2 should be rated as Not Achieved if the following applies:" +
                    "<ul><li> Item 16 is rated as an Area Needing Improvement and both questions A and B were answered No.</li></ul>" +
                    "Well-Being Outcome 2 should be rated as Not Applicable if the following applies:" +
                    "<ul><li> Item 16 is rated as Not Applicable.</li>" +
                    "</ul></div>";
            },

            item16: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<h3>Purpose of Assessment</h3>" +
                    "<ul><li>To assess whether, during the period under review, the agency made concerted efforts to assess children’s educational needs at the initial contact with the child (if the case was opened during the period under review) or on an ongoing basis (if the case was opened before the period under review), and whether identified needs were appropriately addressed in case planning and case management activities.</li>" +
                    "</ul></div>";
            },
            question16a: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li>If the case is a foster care case, question A should be answered only for the child in foster care, even if the child was reunified during the period under review and there are other children in the home.</li>" +
                    "<li>If the case is an in-home services case, question A should be answered for all children in the home who meet the case applicability requirements.</li>" +
                    "<li>Question A should be answered Yes if there was evidence of an educational assessment in the case file, such as:</li>" +
                    "<ul><li>An educational assessment included in the comprehensive needs assessment.</li>" +
                    "<li>A separate educational assessment conducted by the school (and made available to the agency) or by the agency.</li>" +
                    "<li>An informal (and documented) educational assessment conducted by the agency.</li></ul>" +
                    "<li>Question A should be answered Yes if the reviewer determines through interviews with key individuals that the agency assessed the children’s educational needs, even if the case file did not include the documentation identified above.</li>" +
                    "</ul></div>";
            },
            question16b: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li>Question B should be answered Not Applicable if an educational assessment was conducted (i.e., question A is answered Yes) but no needs were identified.</li>" +
                    "<li>Review any \"services needed but not provided\" noted in table A1 when responding to question B. Focus on agency efforts, even if these efforts were not fully successful due to factors beyond the agency’s control. For example, if the agency made concerted efforts to advocate for special education classes, but the local school continued to resist, you may answer Yes to question B, although the child did not receive the needed services. Also consider whether the service need was recently identified during the period under review and the agency has not had a reasonable amount of time to arrange for/request the service.</li>" +
                    "</ul></div>";
            },
            outcome3: function () {
                return "<div class='question-instruction text-justify'>Well-Being Outcome 3 should be rated as Substantially Achieved if either of the following applies:" +
                    "<ul><li> Items 17 and 18 are both rated as Strengths.</li>" +
                    "<li> One item is rated as a Strength and the other item is rated as Not Applicable.</li></ul>" +
                    "Well-Being Outcome 3 should be rated as Partially Achieved if the following applies:" +
                    "<ul><li> One of the two items (17 and 18) is rated as a Strength and the other is rated as an Area Needing Improvement.</li></ul>" +
                    "Well-Being Outcome 3 should be rated as Not Achieved if either of the following applies:" +
                    "<ul><li> Both items are rated as Areas Needing Improvement.</li>" +
                    "<li> One item is rated as an Area Needing Improvement and the other item is rated as Not Applicable.</li></ul>" +
                    "Well-Being Outcome 3 should be rated as Not Applicable if the following applies:" +
                    "<ul><li> Items 17 and 18 are both rated as Not Applicable.</li>" +
                    "</ul></div>";
            },
            item17: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<h3>Purpose of Assessment</h3>" +
                    "<ul><li>To determine whether, during the period under review, the agency addressed the physical health needs of the children, including dental health needs.</li>" +
                    "</ul></div>";
            },
            question17a1: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li> For in-home services cases, A1 and A2 should be answered for all children in the home who meet the case applicability requirements. A1 or A2 may be Not Applicable if only one of the issues (physical or dental health) was relevant for assessment in an in-home services case.</li>" +
                    "<li>Determine whether there is evidence that, during the period under review, the agency arranged for assessment of the child(ren)’s health care needs, including dental care needs, both initially (if the child entered foster care during the period under review or if an in-home services case was opened during the period under review), and on an ongoing basis through periodic health and dental screening services conducted during the period under review.</li>" +
                    "<li>The evidence to consider would include, but is not limited to:</li>" +
                    "<ul> <li>Conducting an initial health care screening, such as EPSDT (Early Periodic Screening, Diagnosis, and Treatment) or other comprehensive medical examination upon entry into foster care (if the child entered foster care during the period under review) or when the case first opened (for an in-home services case that opened during the period under review).</li>" +
                    "<li>Ensuring that, during the period under review, the children received ongoing periodic preventive physical and dental health screenings to identify and avoid potential problems. (Preventive health care refers to initial and periodic age-appropriate dental or physical health examinations.)</li>" +
                    "<li>Including an assessment of physical and dental health needs in the initial comprehensive needs assessment (if the child entered foster care during the period under review or if the in-home services case was opened during the period under review), or in ongoing needs assessments conducted to guide case planning.</li></ul>" +
                    "</ul></div>";
            },
            question17a2: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li> For in-home services cases, A1 and A2 should be answered for all children in the home who meet the case applicability requirements. A1 or A2 may be Not Applicable if only one of the issues (physical or dental health) was relevant for assessment in an in-home services case.</li>" +
                    "<li>Determine whether there is evidence that, during the period under review, the agency arranged for assessment of the child(ren)’s health care needs, including dental care needs, both initially (if the child entered foster care during the period under review or if an in-home services case was opened during the period under review), and on an ongoing basis through periodic health and dental screening services conducted during the period under review.</li>" +
                    "<li>The evidence to consider would include, but is not limited to:</li>" +
                    "<ul><li>Conducting an initial health care screening, such as EPSDT (Early Periodic Screening, Diagnosis, and Treatment) or other comprehensive medical examination upon entry into foster care (if the child entered foster care during the period under review) or when the case first opened (for an in-home services case that opened during the period under review).</li>" +
                    "<li>Ensuring that, during the period under review, the children received ongoing periodic preventive physical and dental health screenings to identify and avoid potential problems. (Preventive health care refers to initial and periodic age-appropriate dental or physical health examinations.)</li>" +
                    "<li>Including an assessment of physical and dental health needs in the initial comprehensive needs assessment (if the child entered foster care during the period under review or if the in-home services case was opened during the period under review), or in ongoing needs assessments conducted to guide case planning.</li></ul>" +
                    "<li>If the children are too young for a dental examination, then question A2 should be answered Not Applicable.</li>" +
                    "</ul></div>";
            },
            question17a4: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<h3>Definitions</h3>" +
                    "<ul><li>Health records include the names and addresses of the child’s health care providers, a record of the child’s immunizations, the child’s known medical problems, the child’s medications, and any other relevant health information.</li>" +
                    "</ul></div>";
            },
            question17b1: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li> Select NA if this is not a foster care case.</li>" +
                    "<li>If the child was not prescribed any medications for physical health issues during the period under review, select NA.</li>" +
                    "</ul>" +
                    "<h3>Definitions</h3>" +
                    "<ul><li>\"Appropriate oversight\" includes, but is not limited to, the following:</li>" +
                    "<ul><li>Ensuring that a child is seen regularly by a physician to monitor the effectiveness of the medication, assess any side effects and/or health implications, consider any changes needed to dosage or medication type, and determine whether medication is still necessary and/or if other treatment options would be more appropriate.</li>" +
                    "<li>Regularly following up with foster parents/caregivers about administering medications appropriately and about the child’s experience with the medication(s), including any side effects.</li>" +
                    "<li>Following any additional state protocols that may be in place related to the appropriate use and monitoring of medications.</li></ul>" +
                    "</ul></div>";
            },
            question17b2: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li> If the answers to question(s) A1 and/or A2 are Yes and no needs for services or treatment were identified, then the corresponding question(s) B2, and/or B3 should be answered Not Applicable. If question A2 is Not Applicable because of the child’s age, then question B3 also should be Not Applicable.</li>" +
                    "<li>If any \"services needed but not provided\" are noted in the A3 table, question B2 and/or B3 should be No, unless the service was recently identified during the period under review and the agency has not had a reasonable amount of time to arrange for the service. If services were not provided due to excessive waitlists, service providers not being available in the community, or delays by the agency, question B2 and/or B3 should be No.</li>" +
                    "<li>Answer No to question B2 or B3 if the case management criteria noted in question A4 were not met and you determine that had or has a negative impact on the agency’s ability to meet the child’s health and dental care needs. For example, foster parents were unable to effectively address health care needs because they had never seen the child’s health records, or the child’s health care needs were not being met because there were no health records in the case file and the worker was unaware of the child’s health care needs.</li>" +
                    "</ul>" +
                    "<h3>Tip</h3>" +
                    "For Item 17, although the instructions indicate that ongoing preventive physical health and dental health screenings are considered under the assessment question, these routine exams can include both evaluations and services (e.g. a teeth cleaning). Therefore, in cases where initial and/or ongoing assessments were conducted and the child received routine care but no follow-up services were needed, the answer to 17B2 or 17B3 should be Yes (not NA). Please note that if either routine care or any additional services were needed but not provided, the answer to 17B2 or 17B3 should be No.</p></div>"
                    ;
            },
            question17b3: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li> If the answers to question(s) A1 and/or A2 are Yes and no needs for services or treatment were identified, then the corresponding question(s) B2, and/or B3 should be answered Not Applicable. If question A2 is Not Applicable because of the child’s age, then question B3 also should be Not Applicable.</li>" +
                    "<li>If any \"services needed but not provided\" are noted in the A3 table, question B2 and/or B3 should be No, unless the service was recently identified during the period under review and the agency has not had a reasonable amount of time to arrange for the service. If services were not provided due to excessive waitlists, service providers not being available in the community, or delays by the agency, question B2 and/or B3 should be No.</li>" +
                    "<li>Answer No to question B2 or B3 if the case management criteria noted in question A4 were not met and you determine that had or has a negative impact on the agency’s ability to meet the child’s health and dental care needs. For example, foster parents were unable to effectively address health care needs because they had never seen the child’s health records, or the child’s health care needs were not being met because there were no health records in the case file and the worker was unaware of the child’s health care needs.</li>" +
                    "</ul></div>";
            },
            item18: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<h3>Purpose of Assessment</h3>" +
                    "<ul><li>To determine whether, during the period under review, the agency addressed the mental/behavioral health needs of the children.</li>" +
                    "</ul></div>";
            },
            question18a: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li>An assessment of mental health should include consideration of any trauma that the children may have experienced, including exposure to domestic violence.</li>" +
                    "<li>Determine whether, during the period under review, the agency conducted a formal or informal mental/behavioral health assessment on the children initially (if the in-home services case was opened during the period under review) or at entry into foster care (if the child entered foster care during the period under review), and on an ongoing basis.</li>" +
                    "<li>If the case is an in-home services case, question A should be answered for all children in the home who meet the case applicability requirements.</li>" +
                    "</ul>" +
                    "<h3>Definitions</h3>" +
                    "<ul><li>\"Behavioral health needs\" includes needs related to behavioral problems that are not always specified as mental health needs, including substance abuse.</li>" +
                    "</ul></div>";
            },
            question18b: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li>Select NA if this is not a foster care case.</li>" +
                    "<li>If the child was not prescribed any medications for mental/behavioral health issues during the period under review, select NA.</li>" +
                    "</ul>" +
                    "<h3>Definitions</h3>" +
                    "<ul><li>\"Appropriate oversight\" includes, but is not limited to, the following:</li>" +
                    "<ul><li>Ensuring that a child is seen regularly by a physician to monitor the effectiveness of the medication, assess any side effects and/or health implications, consider any changes needed to dosage or medication type, and determine whether medication is still necessary and/or whether other treatment options would be more appropriate.</li>" +
                    "<li>Regularly following up with foster parents/caregivers about administering medications appropriately and about the child’s experience with the medication(s), including any side effects.</li>" +
                    "<li>Following any additional state protocols that may be in place related to the appropriate use and monitoring of medications.</li></ul>" +
                    "</ul></div>";
            },
            question18c: function () {
                return "<div class='question-instruction text-justify'>" +
                    "<ul><li>If question A is answered Yes, but no mental/behavioral health service needs were identified, then the answer to question C should be Not Applicable.</li>" +
                    "<li>If you noted any \"services needed but not provided\" in the A1 table, question C should be No, unless the service was recently identified during the period under review and the agency has not had a reasonable amount of time to arrange for the service. If services were not provided due to excessive waitlists, service providers not being available in the community, or delays by the agency, question C should be answered No.</li>" +
                    "</ul></div>";
            },

            rating: {
                item12: function () {
                    return "<div class='question-instruction'>" +
                        "<ul><li>Item 12 should be rated as a Strength if sections A, B, and C are all rated Strength OR at least one of the sections is rated as a Strength and the others are Not Applicable.</li>" +
                        "<li>Item 12 should be rated as an Area Needing Improvement if any one of sections A, B, or C is rated as an Area Needing Improvement.</li>" +
                        "<li>There are no circumstances under which item 12 could be rated as Not Applicable.</li></ul>" +
                        "</div>";
                },
                item12a: function () {
                    return "<div class='question-instruction'>Sub-item 12A should be rated as a Strength if either of the following applies:" +
                        "<ul><li> The answers to both questions A1 and A2 are Yes.</li>" +
                        "<li>The answer to question A1 is Yes, and the answer to question A2 is Not Applicable.</li></ul>" +
                        "Sub-item 12A should be rated as an Area Needing Improvement if the answer to question A1 and/or A2 is No.</p>" +
                        "There are no circumstances under which sub-item 12A could be rated as Not Applicable.</p></div>";
                },
                item12b: function () {
                    return "<div class='question-instruction'>Sub-item 12B should be rated as a Strength if either of the following applies:" +
                        "<ul><li>The answers to B1, B2, B3, and B4 are Yes.</li>" +
                        "<li>The answer to at least one question is Yes, and the answer to the other questions is Not Applicable.</li></ul>" +
                        "Sub-item 12B should be rated as an Area Needing Improvement if the answer to any one of the questions is No.</p>" +
                        "Sub-item 12B should be rated as Not Applicable if the answer to the questions of applicability for both Mother and Father is No.</p></div>";
                },
                item12c: function () {
                    return "<div class='question-instruction'>Sub-item 12C should be rated as a Strength if either of the following applies:" +
                        "<ul><li>The answers to both questions C1 and C2 are Yes.</li>" +
                        "<li>The answer to question C1 is Yes, and the answer to question C2 is Not Applicable.</li></ul>" +
                        "Sub-item 12C should be rated as an Area Needing Improvement if the answer to question C1 and/or C2 is No.</p>" +
                        "Sub-item 12C should be rated as Not Applicable if the response to the question of applicability is No.</p></div>";
                },
                item13: function () {
                    return "<div class='question-instruction'>Item 13 should be rated as a Strength if either of the following applies:" +
                        "<ul><li>The answers to A, B, and C are Yes.</li>" +
                        "<li>The answer to at least one question is Yes, and the answer to the other questions is Not Applicable.</li></ul>" +
                        "Item 13 should be rated as an Area Needing Improvement if the answer to any one of questions A, B, or C is No.</p>" +
                        "Item 13 should be rated as Not Applicable if the response to the question of applicability is No.</p></div>";
                },
                item14: function () {
                    return "<div class='question-instruction text-justify'>" +
                        "<ul><li> Item 14 should be rated as a Strength if the answers to both questions A and B are Yes.</li>" +
                        "<li>Item 14 should be rated as an Area Needing Improvement if the answer to question A and/or B is No.</li>" +
                        "<li>There are no circumstances under which item 14 could be rated as Not Applicable.</li></ul></div>";
                },
                item15: function () {
                    return "<div class='question-instruction text-justify'>Item 15 should be rated as a Strength if any of the following apply:" +
                        "<ul><li>The answers to A2, B2, C, and D are Yes.</li>" +
                        "<li>The answer to A2 and C is Yes and the answer to B2 and D is NA.</li>" +
                        "<li>The answer to B2 and D is Yes and the answer to A2 and C is NA.</li></ul>" +
                        "Item 15 should be rated as an Area Needing Improvement if the answer to any one of questions A2, B2, C, or D is No.</p>" +
                        "Item 15 should be rated as Not Applicable if the response to the question of applicability is No.</p>" +
                        "</div>";
                },
                item16: function () {
                    return "<div class='question-instruction text-justify'>Item 16 should be rated as a Strength if either of the following applies:" +
                        "<ul><li>The answers to questions A and B are Yes.</li>" +
                        "<li>The answer to question A is Yes, and the answer to question B is Not Applicable.</li></ul>" +
                        "Item 16 should be rated as an Area Needing Improvement if the answer to question A and/or B is No.</p>" +
                        "Item 16 should be rated as Not Applicable if the response to the question of applicability is No.</p>" +
                        "</div>";
                },
                item17: function () {
                    return "<div class='question-instruction text-justify'>Item 17 should be rated as a Strength if either of the following applies:" +
                        "<ul><li> The answers to questions A1, A2, B1, B2, and B3 are Yes.</li>" +
                        "<li>The answer to at least one of questions A1, A2, B1, B2, or B3 is Yes, and the rest are Not Applicable.</li></ul>" +
                        "Item 17 should be rated as an Area Needing Improvement if the answer to any question is No.</p>" +
                        "Item 17 should be rated as Not Applicable if the response to the question of applicability is No.</p>" +
                        "For Foster Care cases only, there are no circumstances under which item 17 could be rated as Not Applicable.</p></div>";

                },
                item18: function () {
                    return "<div class='question-instruction text-justify'>Item 18 should be rated as a Strength if the answer to question A is Yes, the answer to question B is Yes or Not Applicable, and the answer to question C is Yes or Not Applicable.</p>" +
                        "Item 18 should be rated as an Area Needing Improvement if the answer to any question is No.</p>" +
                        "Item 18 should be rated as Not Applicable if the response to the question of applicability is No.</p></div>";
                }
            }
        }
    },
    definitions: {
        facesheet: {
            questionJ: function () {
                return "<div class='question-instruction'>" +
                    "<ul>" +
                    "<li>\"Entry into foster care\" refers to a child's removal from his or her normal place of residence and placement in a substitute care setting under the placement and care responsibility of the state or local title IV-B/IV-E agency. Children are considered to have entered foster care if the child has been in substitute care for 24 hours or more.</li>" +
                    "</ul>" +
                    "</div>";
            },
            questionK: function () {
                return "<div class='question-instruction'>" +
                    "<ul>" +
                    "<li> \"Discharge from foster care\" is defined as the point when the child is no longer in foster care under the placement and care responsibility or supervision of the agency.</li>" +
                    "</ul>" +
                    "</div>";
            },
            questionM: function () {
                return "<div class='question-instruction'>" +
                    "<ul>" +
                    "<li>If \"other\" was checked as a reason the case was opened for services, the circumstances and reason must be very clearly documented in the narrative. The reason should be compared with the reasons listed in question M to ensure that it does not fit in an existing category.</li>" +
                    "</ul>" +
                    "</div>";
            }
        }
    },
    tips: {
        newCase: {
            questionA: function () {
                return "<p class='instruction-required'>For question A, please verify that the site is accurate.</p>";
            },
            questionC: function () {
                return "<p class='instruction-required'>For question C, please verify that the PUR start date is accurate.</p>";
            },
            questionF: function () {
                return "<p class='instruction-required'>For question F, please verify that the case type is accurate.</p>";
            }
        },
        dashboard: {
            search: function () {
                return "<div class='dashboard-search-tips'>" +
                    "<h4>Search Tips</h4>" +
                    "<p>Wildcards <span>(*)</span>  can be used like this:</p>  " +
                    "<div>Starts with: 123<span>*</span>Rod<span>*</span></div>" +
                    "<div>Ends with: <span>*</span>234<span>*</span>guez</div>" +
                    "<div>Contains: <span>*</span>23<span>*</span>or<span>*</span>gue<span>*</span></div>" +
                    "</div>"
            }
        },
        itemMenu:
            {
                toolTip: function (itemId) {
                    if (Ext.isEmpty(itemId))
                        return '';
                    switch (itemId) {
                        case 'facesheet':
                            return 'Face Sheet';
                        case 'safetyoutcome1':
                            return 'Children are, first and foremost, protected from abuse and neglect.';
                        case 'safetyoutcome2':
                            return 'Children are safely maintained in their homes whenever possible and appropriate.';
                        case 'permanencyoutcome1':
                            return 'Children have permanency and stability in their living situations.';
                        case 'permanencyoutcome2':
                            return 'The continuity of family relationships and connections is preserved for children.';
                        case 'wellbeingoutcome1':
                            return 'Families have enhanced capacity to provide for their children\'s needs.';
                        case 'wellbeingoutcome2':
                            return 'Children receive appropriate services to meet their educational needs.';
                        case 'wellbeingoutcome3':
                            return 'Children receive adequate services to meet their physical and mental health needs.';
                        case 'item1':
                            return 'Timeliness of Initiating Investigations of Reports of Child Maltreatment';
                        case 'item2':
                            return 'Services to Family to Protect Child(ren) in the Home and Prevent Removal or Re-Entry Into Foster Care';
                        case 'item3':
                            return 'Risk and Safety Assessment and Management';
                        case 'item4':
                            return 'Stability of Foster Care Placement';
                        case 'item5':
                            return 'Permanency Goal for Child';
                        case 'item6':
                            return 'Achieving Reunification, Guardianship, Adoption, or Other Planned Permanent Living Arrangement';
                        case 'item7':
                            return 'Placement With Siblings';
                        case 'item8':
                            return 'Visiting With Parents and Siblings in Foster Care';
                        case 'item9':
                            return 'Preserving Connections';
                        case 'item10':
                            return 'Relative Placement';
                        case 'item11':
                            return 'Relationship of Child in Care With Parents';
                        case 'item12':
                            return 'Needs and Services of Child, Parents, and Foster Parents';
                        case 'item12a':
                            return 'Needs Assessment and Services to Children';
                        case 'item12b':
                            return 'Needs Assessment and Services to Parents';
                        case 'item12c':
                            return 'Needs Assessment and Services to Foster Parents';
                        case 'item13':
                            return 'Child and Family Involvement in Case Planning';
                        case 'item14':
                            return 'Caseworker Visits With Child';
                        case 'item15':
                            return 'Caseworker Visits With Parents';
                        case 'item16':
                            return 'Educational Needs of the Child';
                        case 'item17':
                            return 'Physical Health of the Child';
                        case 'item18':
                            return 'Mental/Behavioral Health of the Child';
                        default:
                            return 'Mental/Behavioral Health of the Child';
                    }
                }
            }
    },
    questions: {
        facesheet: {
            questionH:  function (noQuesChar) {
                return "Was this case opened for reasons other than child abuse and neglect?";
            },
            questionI:  function (noQuesChar) {
                return "What is the date of the first case opening, of the cases open for services during the period under review?";
            },
            questionJ:  function (noQuesChar) {
                return "What is the date of the child\'s most recent entry into foster care?";
            },
            questionK:  function (noQuesChar) {
                return "What is the date of discharge from foster care for the most recent foster care episode?";
            },
            questionL:  function (noQuesChar) {
                return "What is the date of the most recent case closure during the period under review?";
            },
            questionM:  function (noQuesChar) {
                return "Why was/were the case(s) opened for services?";
            }
        },
        safety: {
            question1A:  function (noQuesChar) {
                var str = "In how many of the reports listed in the table was the investigation or assessment NOT initiated in accordance with the state’s time frames and requirements for a report of that priority?";
                if (noQuesChar)
                    return str;
                return "A. " + str;
            },
            question1B:  function (noQuesChar) {
                var str = "In how many of the reports in the table was face-to-face contact with the child(ren) who is (are) the subject of the report NOT made in accordance with the state’s time frames and requirements for a report of that priority?";
                if (noQuesChar)
                    return str;
                return "B. " + str;
            },
            question1C:  function (noQuesChar) {
                var str = "For all reports identified in A and B, were the reasons for the delays due to circumstances beyond the control of the agency?";
                if (noQuesChar)
                    return str;
                return "C. " + str;
            },
            question2A:  function (noQuesChar) {
                var str = "For the period under review, did the agency make concerted efforts to provide or arrange for appropriate services for the family to protect the children and prevent their entry into foster care or re-entry into foster care after a reunification? (Be sure to assess the entire period under review.)";
                if (noQuesChar)
                    return str;
                return "A. " + str;
            },
            question2B:  function (noQuesChar) {
                var str = "If, during the period under review, any child was removed from the home without providing or arranging for services, was this action necessary to ensure the child’s safety?";
                if (noQuesChar)
                    return str;
                return "B. " + str;
            },
            question3A:  function (noQuesChar) {
                var str = "If the case was opened during the period under review, did the agency conduct an initial assessment that accurately assessed all risk and safety concerns for the target child in foster care and/or any child(ren) in the family remaining in the home?";
                if (noQuesChar)
                    return str;
                return "A. " + str;
            },
            question3B:  function (noQuesChar) {
                var str = "During the period under review, did the agency conduct ongoing assessments that accurately assessed all of the risk and safety concerns for the target child in foster care and/or any child(ren) in the family remaining in the home?";
                if (noQuesChar)
                    return str;
                return "B. " + str;
            },
            question3C:  function (noQuesChar) {
                var str = "During the period under review, if safety concerns were present, did the agency: (1) develop an appropriate safety plan with the family and (2) continually monitor and update the safety plan as needed, including monitoring family engagement in any safety-related services?";
                if (noQuesChar)
                    return str;
                return "C. " + str;
            },
            question3D:  function (noQuesChar) {
                var str = "During the period under review, were there safety concerns pertaining to the target child in foster care and/or any child(ren) in the family remaining in the home that were not adequately or appropriately addressed by the agency?";
                if (noQuesChar)
                    return str;
                return "D. " + str;
            },
            question3D1:  function (noQuesChar) {
                var str = "Indicate whether any safety-related incidents occurred during the period under review.";
                if (noQuesChar)
                    return str;
                return "D1. " + str;
            },
            question3E:  function (noQuesChar) {
                var str = "During the period under review, was there a safety concern related to the target child in foster care during visitation with parents/caretakers or other family members?";
                if (noQuesChar)
                    return str;
                return "E. " + str;
            },
            question3E1:  function (noQuesChar) {
                var str = "For foster care cases only, indicate whether any safety concerns related to visitation were present during the period under review. Select all that apply";
                if (noQuesChar)
                    return str;
                return "E1. " + str;
            },
            question3F:  function (noQuesChar) {
                var str = "For foster care cases only, during the period under review, was there a concern for the target child’s safety related to the foster parents, members of the foster parents’ family, other children in the foster home or facility, or facility staff members, that was not adequately or appropriately addressed by the agency?";
                if (noQuesChar)
                    return str;
                return "F. " + str;
            },
            question3F1:  function (noQuesChar) {
                var str = "For foster care cases only, indicate whether any concerns existed for the child in at least one foster care placement during the period under review. Select all that apply";
                if (noQuesChar)
                    return str;
                return "F1. " + str;
            }
        },
        permanency: {
            question4A: function (noQuesChar) {
                var str = "How many placement settings did the child experience during the period under review?";
                if (noQuesChar)
                    return str;
                return "A. " + str;
            },
            question4B:  function (noQuesChar) {
                var str = "Were all placement changes during the period under review planned by the agency in an effort to achieve the child\'s case goals or to meet the needs of the child?";
                if (noQuesChar)
                    return str;
                return "B. " + str;
            },
            question4C1:  function (noQuesChar) {
                var str = "Indicate whether any of the circumstances below apply to the child\'s current placement.";
                if (noQuesChar)
                    return str;
                return "C1. " + str;
            },
            question4C:  function (noQuesChar) {
                var str = "Is the child\'s current placement setting (or most recent placement if the child is no longer in foster care) stable?";
                if (noQuesChar)
                    return str;
                return "C. " + str;
            },
            question5A2:  function (noQuesChar) {
                var str = "What is (are) the child's current permanency goal(s)? (If concurrent permanency goals have been established in the case plan, identify both goals.) Or, if the case was closed during the period under review, what was the permanency goal before the case was closed?";
                if (noQuesChar)
                    return str;
                return "A2. " + str;
            },
            question5A3:  function (noQuesChar) {
                var str = "Is (are) the child\'s permanency goal(s) specified in the case file?";
                if (noQuesChar)
                    return str;
                return "A3. " + str;
            },
            question5B:  function (noQuesChar) {
                var str = "Were all the permanency goals that were in effect during the period under review established in a timely manner?";
                if (noQuesChar)
                    return str;
                return "B. " + str;
            },
            question5C:  function (noQuesChar) {
                var str = "Were all permanency goals in effect during the period under review appropriate to the child\'s needs for permanency and to the circumstances of the case?";
                if (noQuesChar)
                    return str;
                return "C. " + str;
            },
            question5D:  function (noQuesChar) {
                var str = "Has the child been in foster care for at least 15 of the most recent 22 months?";
                if (noQuesChar)
                    return str;
                return "D. " + str;
            },
            question5E:  function (noQuesChar) {
                var str = "Does the child meet other Adoption and Safe Families Act criteria for termination of parental rights?";
                if (noQuesChar)
                    return str;
                return "E. " + str;
            },
            question5F:  function (noQuesChar) {
                var str = "Did the agency file or join a termination of parental rights petition before the period under review or in a timely manner during the period under review?";
                if (noQuesChar)
                    return str;
                return "F. " + str;
            },
            question5G1:  function (noQuesChar) {
                var str = "Indicate whether any of the following exceptions to the termination of parental rights requirement apply";
                if (noQuesChar)
                    return str;
                return "G1. " + str;
            },
            question5G:  function (noQuesChar) {
                var str = "Did an exception to the requirement to file or join a termination of parental rights petition exist?";
                if (noQuesChar)
                    return str;
                return "G. " + str;
            },
            question6A1:  function (noQuesChar) {
                var str = "What is the date of the child’s most recent entry into foster care?";
                if (noQuesChar)
                    return str;
                return "A1. " + str;
            },
            question6A2:  function (noQuesChar) {
                var str = "What is the time in care (in months) at the time of the onsite review?";
                if (noQuesChar)
                    return str;
                return "A2. " + str;
            },
            question6A3:  function (noQuesChar) {
                var str = "What is the date the child discharged from foster care?";
                if (noQuesChar)
                    return str;
                return "A3. " + str;
            },
            question6A4:  function (noQuesChar) {
                var str = "What is (are) the child’s current permanency goal(s)? (If concurrent permanency goals have been established in the case plan, identify both goals.) Or, if the case was closed during the period under review, what was the permanency goal before the case was closed?";
                if (noQuesChar)
                    return str;
                return "A4. " + str;
            },
            question6B:  function (noQuesChar) {
                var str = "During the period under review, did the agency and court make concerted efforts to achieve permanency in a timely manner?";
                if (noQuesChar)
                    return str;
                return "B. " + str;
            },
            question6C1:  function (noQuesChar) {
                var str = "If the child’s current (or most recent) permanency goal is (was) other planned permanent living arrangement, what is (was) the child’s permanent living arrangement?";
                if (noQuesChar)
                    return str;
                return "C1. " + str;
            },
            question6C2:  function (noQuesChar) {
                var str = "For a child with a goal of other planned permanent living arrangement during the period under review, what is the date of documentation regarding \"permanency\" of the child’s living arrangements?";
                if (noQuesChar)
                    return str;
                return "C2. " + str;
            },
            question6C:  function (noQuesChar) {
                var str = "For a child with a goal of other planned permanent living arrangement during the period under review, did the agency and court make concerted efforts to place the child in a living arrangement that can be considered permanent until discharge from foster care?";
                if (noQuesChar)
                    return str;
                return "C. " + str;
            },
            question7A:  function (noQuesChar) {
                var str = "During the entire period under review, was the child placed with all siblings who also were in foster care?";
                if (noQuesChar)
                    return str;
                return "A. " + str;
            },
            question7B:  function (noQuesChar) {
                var str = "If the answer to question A is No, was there a valid reason for the child’s separation from the siblings?";
                if (noQuesChar)
                    return str;
                return "B. " + str;
            },
            question8A1:  function (noQuesChar) {
                var str = "What was the usual frequency of visits between the mother and the child during the period under review? Select the box next to the statement that best describes the typical frequency of visits during the period under review";
                if (noQuesChar)
                    return str;
                return "A1. " + str;
            },
            question8A:  function (noQuesChar) {
                var str = "During the period under review, were concerted efforts made to ensure that visitation (or other forms of contact if visitation was not possible) between the child and his or her mother was of sufficient frequency to maintain or promote the continuity of the relationship?";
                if (noQuesChar)
                    return str;
                return "A. " + str;
            },
            question8B1:  function (noQuesChar) {
                var str = "What was the usual frequency of visits between the father and the child during the period under review? Select the box next to the statement that best describes the typical frequency of visits during the period under review.";
                if (noQuesChar)
                    return str;
                return "B1. " + str;
            },
            question8B:  function (noQuesChar) {
                var str = "During the period under review, were concerted efforts made to ensure that visitation (or other forms of contact if visitation was not possible) between the child and his or her father was of sufficient frequency to maintain or promote the continuity of the relationship?";
                if (noQuesChar)
                    return str;
                return "B. " + str;
            },
            question8C:  function (noQuesChar) {
                var str = "During the period under review, were concerted efforts made to ensure that the quality of visitation between the child and the mother was sufficient to maintain or promote the continuity of the relationship?";
                if (noQuesChar)
                    return str;
                return "C. " + str;
            },
            question8D:  function (noQuesChar) {
                var str = "During the period under review, were concerted efforts made to ensure that the quality of visitation between the child and the father was sufficient to maintain or promote the continuity of the relationship?";
                if (noQuesChar)
                    return str;
                return "D. " + str;
            },
            question8E1:  function (noQuesChar) {
                var str = "What was the usual frequency of visits between the father and the child during the period under review? Select the box next to the statement that best describes the typical frequency of visits during the period under review.";
                if (noQuesChar)
                    return str;
                return "E1. " + str;
            },
            question8E:  function (noQuesChar) {
                var str = "During the period under review, were concerted efforts made to ensure that visitation between the child and his or her sibling(s) was of sufficient frequency to maintain or promote the continuity of the relationship?";
                if (noQuesChar)
                    return str;
                return "E. " + str;
            },
            question8F:  function (noQuesChar) {
                var str = "During the period under review, were concerted efforts made to ensure that the quality of visitation between the child and his or her sibling(s) was sufficient to promote the continuity of their relationships?";
                if (noQuesChar)
                    return str;
                return "F. " + str;
            },
            question9A:  function (noQuesChar) {
                var str = "During the period under review, were concerted efforts made to maintain the child’s important connections (for example, neighborhood, community, faith, language, extended family members including siblings who are not in foster care, Tribe, school, and/or friends)?";
                if (noQuesChar)
                    return str;
                return "A. " + str;
            },
            question9B:  function (noQuesChar) {
                var str = "Was a sufficient inquiry conducted with the parent, child, custodian, or other interested party to determine whether the child may be a member of, or eligible for membership in, a federally recognized Indian Tribe?";
                if (noQuesChar)
                    return str;
                return "B. " + str;
            },
            question9C:  function (noQuesChar) {
                var str = "If the child may be a member of, or eligible for membership in, a federally recognized Indian Tribe, during the period under review, was the Tribe provided timely notification of its right to intervene in any state court proceedings seeking an involuntary foster care placement or termination of parental rights?";
                if (noQuesChar)
                    return str;
                return "C. " + str;
            },
            question9D:  function (noQuesChar) {
                var str = "If the child is a member of, or eligible for membership in, a federally recognized Indian Tribe, was the child placed in foster care in accordance with Indian Child Welfare Act placement preferences or were concerted efforts made to place the child in accordance with the Act’s placement preferences?";
                if (noQuesChar)
                    return str;
                return "D. " + str;
            },
            question10A1:  function (noQuesChar) {
                var str = "During the period under review, was the child’s current or most recent placement with a relative?";
                if (noQuesChar)
                    return str;
                return "A1. " + str;
            },
            question10A2:  function (noQuesChar) {
                var str = "If the child’s current or most recent placement is with a relative, is (or was) this placement stable and appropriate to the child’s needs?";
                if (noQuesChar)
                    return str;
                return "A2. " + str;
            },
            question10B:  function (noQuesChar) {
                var str = "Did the agency, during the period under review, make concerted efforts to identify, locate, inform, and evaluate maternal relatives as potential placements for the child, with the result that maternal relatives were ruled out as placement resources (due to fit, relative’s unwillingness, or child\'s best interests) during the period under review?";
                if (noQuesChar)
                    return str;
                return "B. " + str;
            },
            question10C:  function (noQuesChar) {
                var str = "Did the agency, during the period under review, make concerted efforts to identify, locate, inform, and evaluate paternal relatives as potential placements for the child, with the result that paternal relatives were ruled out as placement resources (due to fit, relative’s unwillingness, or child\'s best interests) during the period under review?";
                if (noQuesChar)
                    return str;
                return "C. " + str;
            },
            question11A:  function (noQuesChar) {
                var str = "During the period under review, were concerted efforts made to promote, support, and otherwise maintain a positive and nurturing relationship between the child in foster care and his or her mother?";
                if (noQuesChar)
                    return str;
                return "A. " + str;
            },
            question11A1:  function (noQuesChar) {
                var str = "What concerted efforts were made to support or strengthen the mother-child relationship? Select all that apply, if question A is Yes.";
                if (noQuesChar)
                    return str;
                return "A1. " + str;
            },
            question11B:  function (noQuesChar) {
                var str = "During the period under review, were concerted efforts made to promote, support, and otherwise maintain a positive and nurturing relationship between the child in foster care and his or her father?";
                if (noQuesChar)
                    return str;
                return "B. " + str;
            },
            question11B1:  function (noQuesChar) {
                var str = "What concerted efforts were made to support or strengthen the father-child relationship? Select all that apply, if question B is Yes.";
                if (noQuesChar)
                    return str;
                return "B1. " + str;
            }
        },
        wellbeing: {
            question12A1:  function (noQuesChar) {
                var str = "During the period under review, did the agency conduct a formal or informal initial and/or ongoing comprehensive assessment that accurately assessed the children’s needs?";
                if (noQuesChar)
                    return str;
                return "A1. " + str;
                },
            question12A2:  function (noQuesChar) {
                var str = "During the period under review, were appropriate services provided to meet the children’s identified needs?";
                if (noQuesChar)
                    return str;
                return "A2. " + str;
            },
            question12B1:  function (noQuesChar) {
                var str = "During the period under review, did the agency conduct a formal or informal initial and/or ongoing comprehensive assessment that accurately assessed the mother’s needs?";
                if (noQuesChar)
                    return str;
                return "B1. " + str;
            },
            question12B2:  function (noQuesChar) {
                var str = "During the period under review, did the agency conduct a formal or informal initial and/or ongoing comprehensive assessment that accurately assessed the father’s needs?";
                if (noQuesChar)
                    return str;
                return "B2. " + str;
            },
            question12B3:  function (noQuesChar) {
                var str = "During the period under review, did the agency provide appropriate services to the mother to meet identified needs?";
                if (noQuesChar)
                    return str;
                return "B3. " + str;
            },
            question12B4:  function (noQuesChar) {
                var str = "During the period under review, did the agency provide appropriate services to the father to address identified needs?";
                if (noQuesChar)
                    return str;
                return "B4. " + str;
            },
            question12C1:  function (noQuesChar) {
                var str = "During the period under review, did the agency adequately assess the needs of the foster or pre-adoptive parents on an ongoing basis (with respect to services they need to in order to provide appropriate care and supervision to ensure the safety and well-being of the children in their care)?";
                if (noQuesChar)
                    return str;
                return "C1. " + str;
            },
            question12C2:  function (noQuesChar) {
                var str = "During the period under review, were the foster or pre-adoptive parents provided with appropriate services to address identified needs that pertained to their capacity to provide appropriate care and supervision of the children in their care?";
                if (noQuesChar)
                    return str;
                return "C2. " + str;
            },
            question13A:  function (noQuesChar) {
                var str = "During the period under review, did the agency make concerted efforts to actively involve the child in the case planning process?";
                if (noQuesChar)
                    return str;
                return "A. " + str;
            },
            question13B:  function (noQuesChar) {
                var str = "During the period under review, did the agency make concerted efforts to actively involve the mother in the case planning process?";
                if (noQuesChar)
                    return str;
                return "B. " + str;
            },
            question13C:  function (noQuesChar) {
                var str = "During the period under review, did the agency make concerted efforts to actively involve the father in the case planning process?";
                if (noQuesChar)
                    return str;
                return "C. " + str;
            },
            question14A1:  function (noQuesChar) {
                var str = "During the period under review, what was the most typical pattern of visitation between the caseworker or other responsible party and the child(ren) in the case? Select the box that describes the usual pattern of visitation.";
                if (noQuesChar)
                    return str;
                return "A1. " + str;
            },
            question14A:  function (noQuesChar) {
                var str = "During the period under review, was the frequency of the visits between the caseworker (or other responsible party) and the child(ren) sufficient to address issues pertaining to the safety, permanency, and well-being of the child and promote achievement of case goals?";
                if (noQuesChar)
                    return str;
                return "A. " + str;
            },
            question14B:  function (noQuesChar) {
                var str = "During the period under review, was the quality of the visits between the caseworker and the child(ren) sufficient to address issues pertaining to the safety, permanency, and well-being of the child(ren) and promote achievement of case goals (for example, did the visits between the caseworker or other responsible party and the child(ren) focus on issues pertinent to case planning, service delivery, and goal achievement)?";
                if (noQuesChar)
                    return str;
                return "B. " + str;
            },
            question15A1:  function (noQuesChar) {
                var str = "During the period under review, what was the most typical pattern of visitation between the caseworker (or other responsible party) and the mother of the child(ren)? Select the appropriate response";
                if (noQuesChar)
                    return str;
                return "A1. " + str;
            },
            question15A2:  function (noQuesChar) {
                var str = "During the period under review, was the frequency of the visits between the caseworker (or other responsible party) and the mother sufficient to (1) address issues pertaining to the safety, permanency, and well-being of the child and (2) promote achievement of case goals?";
                if (noQuesChar)
                    return str;
                return "A2. " + str;
            },
            question15B1:  function (noQuesChar) {
                var str = "During the period under review, what was the most typical pattern of visitation between the caseworker (or other responsible party) and the father of the child(ren)? Select the appropriate response";
                if (noQuesChar)
                    return str;
                return "B1. " + str;
            },
            question15B2:  function (noQuesChar) {
                var str = "During the period under review, was the frequency of the visits between the caseworker (or other responsible party) and the father sufficient to address issues pertaining to the safety, permanency, and well-being of the child and promote achievement of case goals?";
                if (noQuesChar)
                    return str;
                return "B2. " + str;
            },
            question15C:  function (noQuesChar) {
                var str = "During the period under review, was the quality of the visits between the caseworker (or other responsible party) and the mother sufficient to address issues pertaining to the safety, permanency, and well-being of the child and promote achievement of case goals?";
                if (noQuesChar)
                    return str;
                return "C. " + str;
            },
            question15D:  function (noQuesChar) {
                var str = "During the period under review, was the quality of the visits between the caseworker (or other responsible party) and the father sufficient to address issues pertaining to the safety, permanency, and well-being of the child and promote achievement of case goals?";
                if (noQuesChar)
                    return str;
                return "D. " + str;
            },
            question16A:  function (noQuesChar) {
                var str = "During the period under review, did the agency make concerted efforts to accurately assess the children’s educational needs?";
                if (noQuesChar)
                    return str;
                return "A. " + str;
            },
            question16B:  function (noQuesChar) {
                var str = "During the period under review, did the agency engage in concerted efforts to address the children’s educational needs through appropriate services?";
                if (noQuesChar)
                    return str;
                return "B. " + str;
            },
            question17A1:  function (noQuesChar) {
                var str = "During the period under review, did the agency accurately assess the children’s physical health care needs?";
                if (noQuesChar)
                    return str;
                return "A1. " + str;
            },
            question17A2:  function (noQuesChar) {
                var str = "During the period under review, did the agency accurately assess the children’s dental health care needs?";
                if (noQuesChar)
                    return str;
                return "A2. " + str;
            },
            question17A4:  function (noQuesChar) {
                var str = "For foster care cases only, determine whether, during the period under review, there was evidence that the following case-management criteria required by federal statute were met (select each one that was met).";
                if (noQuesChar)
                    return str;
                return "A4.  " + str;
            },
            question17B1:  function (noQuesChar) {
                var str = "For foster care cases only, during the period under review, did the agency provide appropriate oversight of prescription medications for physical health issues?";
                if (noQuesChar)
                    return str;
                return "B1. " + str;
            },
            question17B2:  function (noQuesChar) {
                var str = "During the period under review, did the agency ensure that appropriate services were provided to the children to address all identified physical health needs?";
                if (noQuesChar)
                    return str;
                return "B2. " + str;
            },
            question17B3:  function (noQuesChar) {
                var str = "During the period under review, did the agency ensure that appropriate services were provided to the children to address all identified dental health needs?";
                if (noQuesChar)
                    return str;
                return "B3. " + str;
            },
            question18A:  function (noQuesChar) {
                var str = "During the period under review, did the agency conduct an accurate assessment of the children’s mental/behavioral health needs either initially (if the child entered foster care during the period under review or if the in-home services case was opened during the period under review) and on an ongoing basis to inform case planning decisions?";
                if (noQuesChar)
                    return str;
                return "A. " + str;
            },
            question18B:  function (noQuesChar) {
                var str = "For foster care cases only, during the period under review, did the agency provide appropriate oversight of prescription medications for mental/behavioral health issues?";
                if (noQuesChar)
                    return str;
                return "B. " + str;
            },
            question18C:  function (noQuesChar) {
                var str = "During the period under review, did the agency provide appropriate services to address the children’s mental/behavioral health needs?";
                if (noQuesChar)
                    return str;
                return "C. " + str;
            }
        }
    },
    validations: {
        facesheet: {
            messages: {}
        },
        safety: {messages: {}},
        permanency: {messages: {}},
        wellbeing: {messages: {}}
    }
});