/**
 * Created by kkora on 9/8/2017.
 */

Ext.define('QuickStart.util.Global', {
    requires: [

        'Ext.window.*'
    ],
    singleton: true,  
    config: {
        //api1: window.location.origin + window.location.pathname,
        api1: window.location.origin + '/crs1/',
        api: window.location.origin + '/',
        resourcePath: window.location.origin + window.location.pathname,
        user: null,
        debug: false,
        resources: 'resources',
        test: false,
        assemblyVersion: null,
        sessionInfo: null,
        delayed: 10000,
        exportPath: null,
        importPath: null,
        caseExportUrl: null,
        reportInBrowsers: null,
        autoSave: false
    },
    showMessage: function (message, title, width, position, closable) {

        Ext.toast({
            html: message,
            title: title || 'Case Review System',
            width: width || 200,
            align: position || 't',
            closable: closable || false,
            closeAction: closable ? 'hide' : 'close',
            autoClose: !closable
        });
    },

    showRuleErrors: function (data) {
        var win = Ext.create('QuickStart.view.admin.rule.Message');
        win.down('#error').setHtml(data.message);
        win.down('grid').getStore().setData(data.data);
        win.show();
    },
    showErrors: function (message, title, width, position) {
        Ext.Msg.show({
            title: title || 'Error',
            message: message,
            buttons: Ext.Msg.YES,
            icon: Ext.Msg.ERROR
        });
    },
    string: {
        initial: function (name) {
            var initials = name.match(/\b\w/g) || [];
            initials = ((initials.shift() || '') + (initials.pop() || '')).toUpperCase().trim();
            return initials;
        }
    },

    permissions: {
        permEnums: {
            ViewCaseReadOnly: 1,
            CreateCaseReview: 2,
            EliminateCase: 3,
            ViewCaseLevelReports: 4,
            CompleteAdministration: 12,
            SecurityManagement: 13,
            AssignAsQARoleWithinCase: 14,
            AssignAsSecondaryOversigthWithinCase: 15,
            Enter_EditCaseData: 16,
            AccessHelpTab: 17,
            AccessReportsTab_DownloadReports: 18,
            AccessReviewLevelReports: 19,
            SubmitCaseToQA: 20,
            Add_EditQANotes: 21,
            OverrideRating: 22,
            ApproveEliminatedCases: 23,
            TransferBackToDataEntryMode: 24,
            FinalizeCase: 25,
            Access_EditCaseSetupPage: 26,
            AssignSelfAsReviewer: 27,
            ITAdministrator: 28,
            SubmitToFinalize: 29,
            SubmitBackToQA: 30,
            IRRTab: 31,
            CreateIRRCase: 32,
            EditIRRCase: 33,
            ShowAllIRRCases: 34,
            ShowInterviewNote: 35,
            FinalizeImportCases: 36,
            ExportCase: 37,
            ImportCase: 38,
            ExportImportTab: 39,
            AutomatedSampling: 40
        },

        allowIRRTab: function () {
            return this.hasPermission(this.permEnums.IRRTab);
        },
        allowCreateIRRCase: function () {
            return this.hasPermission(this.permEnums.CreateIRRCase);
        },
        allowEditIRRCase: function () {
            return this.hasPermission(this.permEnums.EditIRRCase);
        },
        allowShowAllIRRCases: function () {
            return this.hasPermission(this.permEnums.ShowAllIRRCases);
        },
        allowViewCaseReadOnly: function () {
            return this.hasPermission(this.permEnums.ViewCaseReadOnly);
        },
        allowCreateCaseReview: function () {
            return this.hasPermission(this.permEnums.CreateCaseReview);
        },
        allowEliminateCase: function () {
            return this.hasPermission(this.permEnums.EliminateCase);
        },
        allowViewCaseLevelReport: function () {
            return this.hasPermission(this.permEnums.ViewCaseLevelReports);
        },
        allowCompleteAdministration: function () {
            return this.hasPermission(this.permEnums.CompleteAdministration);
        },
        allowSecurityManagement: function () {
            return this.hasPermission(this.permEnums.SecurityManagement);
        },
        allowAssignAsQARoleWithinCase: function () {
            return this.hasPermission(this.permEnums.AssignAsQARoleWithinCase);
        },
        allowAssignAsSecondaryOversigthWithinCase: function () {
            return this.hasPermission(this.permEnums.AssignAsSecondaryOversigthWithinCase);
        },
        allowEditCaseData: function () {
            return this.hasPermission(this.permEnums.Enter_EditCaseData);
        },
        allowAccessHelpTab: function () {
            return this.hasPermission(this.permEnums.AccessHelpTab);
        },
        allowReports: function () {
            return this.hasPermission(this.permEnums.AccessReportsTab_DownloadReports) || this.allowAccessReviewLevelReport() || this.allowViewCaseLevelReport();
        },
        allowAccessReportTab: function () {
            return this.hasPermission(this.permEnums.AccessReportsTab_DownloadReports);
        },
        allowAccessReviewLevelReport: function () {
            return this.hasPermission(this.permEnums.AccessReviewLevelReports);
        },
        allowSubmitCaseToQA: function () {
            return this.hasPermission(this.permEnums.SubmitCaseToQA);
        },
        allowAddEditQANote: function () {
            return this.hasPermission(this.permEnums.Add_EditQANotes);
        },
        allowOverrideRating: function () {
            return this.hasPermission(this.permEnums.OverrideRating);
        },
        allowApproveEliminatedCase: function () {
            return this.hasPermission(this.permEnums.ApproveEliminatedCases);
        },
        allowTransferBackToDataEntryMode: function () {
            return this.hasPermission(this.permEnums.TransferBackToDataEntryMode);
        },
        allowFinalizeCase: function () {
            return this.hasPermission(this.permEnums.FinalizeCase);
        },
        allowEditCaseSetup: function () {
            return this.hasPermission(this.permEnums.Access_EditCaseSetupPage);
        },
        allowAssignSelfAsReviewer: function () {
            return this.hasPermission(this.permEnums.AssignSelfAsReviewer);
        },
        allowITAdministrator: function () {
            return this.hasPermission(this.permEnums.ITAdministrator);
        },
        allowSubmitToFinalize: function () {
            return this.hasPermission(this.permEnums.SubmitToFinalize);
        },
        allowSubmitBackToQA: function () {
            return this.hasPermission(this.permEnums.SubmitBackToQA);
        },
        isAdmin: function () {
            return this.allowITAdministrator() || this.allowCompleteAdministration();
        },
        allowInterviewNote: function () {
            return this.hasPermission(this.permEnums.ShowInterviewNote);
        },
        allowFinalizeImportCases: function () {
            return this.hasPermission(this.permEnums.FinalizeImportCases);
        },
        allowExportCase: function () {
            return this.hasPermission(this.permEnums.ExportCase);
        },
        allowImportCase: function () {
            return this.hasPermission(this.permEnums.ImportCase);
        },
        allowExportImportTab: function () {
            return this.hasPermission(this.permEnums.ExportImportTab);
        },
        allowedAutomatedSampling: function () {
            return this.hasPermission(this.permEnums.AutomatedSampling);
        },
        hasPermission: function (permission) {
            var user = QuickStart.util.Global.getUser(),
                perms = Ext.isEmpty(user) ? [] : user.allPermissions || []
            ;

            return perms.filter(function (perm) {
                return perm.id === permission;
            }).length > 0;

        }

    },
    objects: {

        /**
               * Compares two objects to determine if they are identical.
               * @param {Object} o1
               * @param {Object} o2
               * @return Boolean
               */
    
        equals: function (o1, o2) {
            //can't use json encoding in case objects contain functions - recursion will fail

            if (!o1 && !o2)
                return true;

            if (!o1 || !o2)
                return false;

            var me = this;
            if (Ext.isArray(o1) && Ext.isArray(o2)) {

                if (o1.length === 0 && o2.length === 0)
                    return true;

                if (o1.length !== o2.length)
                    return false;

                o1.sort();
                o2.sort();

                var result = true;

                //compare array element rather object because server side collection has different elements than client side stores.
                o1.forEach(function (element, index, arr) {
                    if (Ext.isObject(element)) {
                        for (var p in element) {
                            if (!Ext.isObject(element[p]) && !Ext.isArray(element[p]) && !me.equals(element[p], o2[index][p])) {
                                result = false;
                                return;
                            }
                        }
                    }
                    else {
                        result = Ext.isDate(element) || Ext.isDate(o2[index]) ? Ext.Date.isEqual(new Date(element), new Date(o2[index])) : o2[index] === element;
                        if (!result) {
                            result = false;
                            return;
                        }
                    }
                });

                return result;
            }
            else if (Ext.isObject(o1) && Ext.isObject(o2)) {
                return Ext.Object.equals(o1, o2);
            }
            else {
                return Ext.isDate(o1) || Ext.isDate(o2) ? Ext.Date.isEqual(new Date(o1), new Date(o2)) : o1 === o2;
            }
        }
    }
});