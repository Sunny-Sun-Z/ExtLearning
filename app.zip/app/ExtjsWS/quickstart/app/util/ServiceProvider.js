/**
 * Created by kkora on 2/20/2018.
 */
Ext.define('QuickStart.util.ServiceProvider', {
    requires: [
        'Ext.direct.Manager',
        'Ext.direct.PollingProvider'
    ],

    singleton: true,
    eliminationNotify: {
        execute: function (userId) {
            var poll = new Ext.direct.PollingProvider({
             //   baseParams: {userId: userId},
                timeout: 1000 * 60 * 5,//5 minutes
                interval : 1000*60 *10,//10 minutes
                type: 'polling',
                url: '/case/SendGeneratedEliminationList?userId='+ userId,
                listeners: {
                    data: function (provider, e, eOpts) {
                        console.log('data', e.data, e.data.data.length);
                        if (e.data.data.length > 0) {
                            QuickStart.util.Global.showMessage('System has generated all your eliminated cases and sent you email.', 'CRS Team', null, 'tr', true);
                        }
                        //add result in grid window from data.response
                    },
                    disconnect: function (provider, e, eOpts) {
                        console.log('disconnect');
                    },
                    connect: function (provider, eOpts) {
                        console.log('connect');
                    }
                }
            });
            Ext.direct.Manager.addProvider(poll);

        }
    }
});