/**
 * Created by kkora on 9/8/2017.
 */
Ext.define('QuickStart.mixins.Global', {
    extend: 'Ext.Mixin',
    dataState: {
        Added: 0,
        Deleted: 1,
        Detached: 2,
        Modified: 3,
        Unchanged: 4
    },
    dateRenderer: function (val, meta, rec) {

        if (Ext.isEmpty(val))
            return '';
        // return Ext.Date.format(val, "M d, Y g:i:s A");
        return Ext.Date.format(val, "m/d/Y");
    },
    datetimeRenderer: function (val, meta, rec) {

        if (Ext.isEmpty(val))
            return '';
       
        return Ext.Date.format(val, "m/d/Y h:i:s A");
    },
            rendererReportDate: function (val, meta, rec) {
        return !Ext.isEmpty(val) ? Ext.Date.format(val, "m/d/Y") : 'Did not occur';
    },
    rendererYesNoNa: function (val, meta, rec) {
        var v = this.getLookupValue('YesNoNa', val, 'large');
        if (v === undefined || v === 0)
            return "No";
        return v;
    },
    rendererYesNo: function (val, meta, rec) {
        if (val)
            return "Yes";
       return "No";
    },
    rendererSampleType: function (val, meta, rec) {
        if (val === 'P')
            return "Primary";
        if (val === 'S')
            return "Secondary";
        return '';
    },
    rendererGender: function (val, meta, rec) {

        return this.getLookupValue('Gender', val, 'large');
    },
    rendererSite: function (val, meta, rec) {
        return this.getLookupValue('Site', val, 'medium');
    },
    rendererPlacementType: function (val, meta, rec) {
        if (val === 7) {
            return this.getLookupValue('PlacementType', val, 'large') + ' - ' + rec.get('TypeOther');
        }
        return this.getLookupValue('PlacementType', val, 'large');
    },
    rendererPlacementChangeReason: function (val, meta, rec) {
        if (val === 8) {
            return this.getLookupValue('PlacementChangeReason', val, 'large') + ' - ' + rec.get('ChangeReasonOther');
        }
        return this.getLookupValue('PlacementChangeReason', val, 'large');
    },
    rendererCaseStatus: function (val, meta, rec) {
        switch (val) {
            case 1:
                meta.style = 'color:#ffc000';
                break;
            case 2:
                meta.style = 'color:#1a568a';
                break;
            case 3:
                meta.style = 'color:#ADB3B8';
                break;
            case 4:
                meta.style = 'color:#925e8b';
                break;
            case 5:
                meta.style = 'color:#9cc96b';
                break;
            case 6:
                meta.style = 'color:#e44959';
                break;
            case 7:
                meta.style = 'color:#16b603';
                break;
            case 8:
                meta.style = 'color:#ef5454';
                break;

        }
        return this.getLookupValue('CaseStatus', val, 'large');
    },


    rendererCaseIdWithStaus: function (val, meta, rec) {
        //console.log('rec', rec)
        var isCaseCreated = rec.get('CaseReviewRootID') != null;
        var caseStatusCode = rec.get('CaseStatusCode');
       // var isReplacement = rec.get('IsReplacement');

        switch (caseStatusCode) {
            case 1:
                meta.style = 'color:#ffc000;';
                break;
            case 2:
                meta.style = 'color:#1a568a;';
                break;
            case 3:
                meta.style = 'color:#ADB3B8;';
                break;
            case 4:
                meta.style = 'color:#925e8b;';
                break;
            case 5:
                meta.style = 'color:#9cc96b;';
                break;
            case 6:
                meta.style = 'color:#e44959;';
                break;
            case 7:
                meta.style = 'color:#16b603;';
                break;
            case 8:
                meta.style = 'color:#ef5454;';
                break;
          
        }

        //if (isReplacement) {
            
        //    meta.style = meta.style +'background-color: #746472;'
        //}

        if (isCaseCreated)
            meta.style = meta.style  +'font-weight:bold;';
        return val;
    },

    rendererReviewType: function (val, meta, rec) {

        return this.getLookupValue('CrReviewType', val, 'name');
    },
    rendererReviewSubType: function (val, meta, rec) {

        return this.getLookupValue('CrReviewSubType', val, 'name');
    },

    rendererEthnicity: function (val, meta, rec) {
        return this.getLookupValue('Ethnicity', val, 'large');
    },
    rendererRace: function (val, meta, rec) {
        return this.getLookupValue('Race', val, 'large');
    },
    rendererAgeOn: function (val, meta, rec) {
        if (!Ext.isEmpty(val))
            return val;

        return '';
    },
    rendererRaceNames: function (val, meta, rec) {
        return this.getLookupValue('Race', val, 'large', true);
    },
    rendererParticipantRole: function (val, meta, rec) {
        if (val === 6) {
            return this.getLookupValue('ParticipantRole', val, 'large') + ' - ' + rec.get('OtherRole');
        }
        return this.getLookupValue('ParticipantRole', val, 'large');
    },
    rendererDisposition: function (val, meta, rec) {
        return this.getLookupValue('Disposition', val, 'large');
    },
    rendererPerpetratorChildRelationship: function (val, meta, rec) {

        return this.getLookupValue('PerpetratorChildRelationship', val, 'large', false, 7, rec.get('PerpetratorChildRelationshipOther'));
    },
    rendererAssessmentType: function (val, meta, rec) {
        return this.getLookupValue('AssessmentType', val, 'large');
    },
    rendererPriorityLevel: function (val, meta, rec) {
        return this.getLookupValue('PriorityLevel', val, 'large');
    },
    rendererAllegations: function (val, meta, rec) {

        return this.getLookupValue('CaseReason', val, 'large', true, 14, rec.get('AllegationOther'));
    },
    rendererPermanencyGoal1: function (val, meta, rec) {
        return this.getLookupValue('PermanencyGoal1', val, 'large');
    },
    rendererTimeInFosterCare: function (val, meta, rec) {
        return val + " " + this.getLookupValue('TimeUnit', rec.get('TimeUnitCode'), 'large');
    },
    renderReviewers: function (val) {
         // console.log('reviewers', val)
        if (Ext.isEmpty(val))
            return '';
        var reviewerNames = [];

        if (val.indexOf(',')) {
            val = val.split(',');
        }
        if (Ext.isArray(val)) {
            Ext.each(val, function (rev) {
                reviewerNames.push(this.getLookupValue('CrSecurityUser',parseInt( rev)) || rev);
            }, this);
            return reviewerNames.join(', ');
        }
        console.log(val, reviewerNames.join(', '));

        return val;
    },
    rendererUser: function (val, meta, rec) {
        if (val === null) return '';

        return this.getLookupValue('CrSecurityUser',parseInt( val));
    },

    rendererOffice: function (val, meta, rec) {
        console.log('office', this.getLookupValue('Office', val, 'name'))

        return this.getLookupValue('Office', val, 'name');
    },

    summaryRendererBold: function(value, summaryData, dataIndex) {
        // return Ext.String.format('{0} Item{1}', value, value !== 1 ? 's' : '');
        if (value===0)
            return '';
        return '<strong>'+value+'</strong>';
    },
    
    getLookupValue: function (group, groupId, returnValue, isMultiValue, otherVal, otherDesc) {
        var store = Ext.getStore('Lookups');
        if (store) {

            if (isMultiValue && Ext.isArray(groupId)) {
                var names = [];
                Ext.each(groupId, function (id) {
                    var record = store.queryRecordsBy(function (r) {
                        return r.get('group') === group && r.get('groupId') === id;
                    });
                    if (record && record.length > 0) {
                        if (id === otherVal)
                            names.push('Other-' + otherDesc);
                        else
                            names.push(record[0].get(returnValue || 'name'));
                    }
                });
                return names.join(', ');
            }

            var record = store.queryRecordsBy(function (r) {
                return r.get('group') === group && r.get('groupId') === groupId;
            });
            if (record && record.length > 0) {
                return (groupId === otherVal) ? ('Other-' + otherDesc) : record[0].get(returnValue || 'name');
            }
        }
        if (groupId === 0)
            return '';
        return groupId;
    },
    getAgeInYmd: function (date1, date2) {

        if (date2 < date1) {
            return null;
        }

        var yearDiff = 0;
        var monthDiff = 0;
        var dayDiff = 0;

        var year1 = date1.getFullYear();
        var year2 = date2.getFullYear();

        if (year1 <= year2)
            yearDiff = year2 - year1;

        var month1 = date1.getMonth();
        var month2 = date2.getMonth();

        if (month1 <= month2)
            monthDiff = month2 - month1;
        else {
            yearDiff--;
            monthDiff = month2 + 12 - month1;
        }

        var day1 = date1.getDate();
        var day2 = date2.getDate();

        if (day1 <= day2)
            dayDiff = day2 - day1;
        else {
            monthDiff--;
            if (monthDiff < 0) {
                yearDiff--;
                monthDiff = monthDiff + 12;
            }
            var noOfDaysinMonth = (new Date(date1.getFullYear(), date1.getMonth() + 1, 1) - new Date(date1.getFullYear(), date1.getMonth(), 1)) / (1000 * 60 * 60 * 24);
            dayDiff = day2 + noOfDaysinMonth - day1;
            dayDiff = Math.round(dayDiff);
        }

        return { Year: yearDiff, Month: monthDiff, Day: dayDiff };

    },
    onCancelWindow: function (btn) {
        btn.up('window').close();
    }
});