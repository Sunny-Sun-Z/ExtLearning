Ext.define('QuickStart.proxy.API', {
    extend: 'Ext.data.proxy.Ajax',
    alias: 'proxy.api',

    reader: {
        type: 'json',
        rootProperty: 'data',
        totalProperty : 'total',
        successProperty : 'success'
    }
});