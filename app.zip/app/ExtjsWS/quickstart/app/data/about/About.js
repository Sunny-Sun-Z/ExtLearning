﻿/**
 * Created by Horace Lawrence on 12/27/2017.
 */
Ext.define('QuickStart.view.main.AboutPanel', {
    extend: 'Ext.panel.Panel',
    xtype: 'crsabout',
    margin: 10,
    bodyPadding: 5,
    scrollable: true,
    tpl: new Ext.Template(
        '<div><h2>Case Review System(CRS)</h2>',
        '<p>Welcome {loginId} - {userName} - {userId}</p>',
        '<p><b>Machine Address:</b> {ipAddr}|<b>Session ID:</b> {sessionId}|<b>Browser:</b> {browserName}</p>',
        '<p><b>Database Schema:</b> {database}|<b>Region:</b> {region}|<b>Version:</b> {version} | <b>Rendered:</b> {renderDate}</p>',
        '<p>Copyrighted {year} | Department of Children and Families, State of Connecticut | All rights reserved.</p>',
        '</div>'
    )
});