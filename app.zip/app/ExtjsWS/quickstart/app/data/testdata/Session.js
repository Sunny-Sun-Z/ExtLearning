/**
 * Created by kkora on 12/19/2017.
 */
Ext.define('QuickStart.data.testdata.Session', {
    extend: 'QuickStart.data.Simulated',
    data: {
        "success": true,
        "session": {
            "user": {

                "id": 153,
                "loginId": "kkora",
                "firstName": "kanchan",
                "lastName": "kora",
                "email": "kanchan.kora@ct.gov",
                "name": "kanchan kora",
                "isActive": 1,
                "avatar": true,
                "roles": [1, 7, 2, 15, 3, 16, 17],
                "permissions": [13, 28, 12, 1, 22],
                "allPermissions": [{"id": 2, "name": "Create Case Review"}, {
                    "id": 16,
                    "name": "Enter/Edit Case Data"
                }, {"id": 26, "name": "Access/Edit Case Setup Page"}, {
                    "id": 20,
                    "name": "Submit case to QA"
                }, {"id": 21, "name": "Add/Edit QA notes"}, {"id": 3, "name": "Eliminate Case"}, {
                    "id": 4,
                    "name": "View  Case Level Reports"
                }, {"id": 17, "name": "Access Help tab"}, {"id": 13, "name": "Security Management"}, {
                    "id": 1,
                    "name": "View Case Read Only"
                }, {"id": 14, "name": "Assign as QA role within case"}, {
                    "id": 15,
                    "name": "Assign as Secondary Oversigth within case"
                }, {"id": 18, "name": "Access Reports Tab / Download Reports"}, {
                    "id": 19,
                    "name": "Access Review Level Reports"
                }, {"id": 22, "name": "Override Rating"}, {"id": 23, "name": "Approve Eliminated Cases"}, {
                    "id": 24,
                    "name": "Transfer back to Data-entry mode"
                }, {"id": 25, "name": "Finalize Case"}, {"id": 29, "name": "Submit to Finalize "}, {
                    "id": 30,
                    "name": "Submit back to QA"
                }, {"id": 28, "name": "IT Administrator"}, {"id": 12, "name": "Complete Administration"}]
            }, test:true, "debug": false, "resources": "/app/ExtjsWS/build/testing/quickstart/resources/"
        }
    }
});