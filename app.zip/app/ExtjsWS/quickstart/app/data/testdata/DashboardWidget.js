/**
 * Created by kkora on 12/19/2017.
 */
Ext.define('QuickStart.data.testdata.DashboardWidget', {
    extend: 'QuickStart.data.Simulated',
    data: {
        "success": true,
        "data": {
            "dataEntryComplete": 47,
            "inProgress": 322,
            "notStarted": 369,
            "qaInProgress": 3,
            "finalized": 0,
            "eliminated": 13,
            "approved": 76,
            "eliminatedPendingApproval": 11
        }
    }
});