﻿Ext.define('QuickStart.profile.Tablet', {
    extend: 'Ext.app.Profile',

    requires: [
        'QuickStart.view.tablet.*'
    ],

    // Map tablet/desktop profile views to generic xtype aliases:
    //
    views: {
        email: 'QuickStart.view.tablet.email.Email',
        inbox: 'QuickStart.view.tablet.email.Inbox',
        compose: 'QuickStart.view.tablet.email.Compose',

        searchusers: 'QuickStart.view.tablet.search.Users'
    },

    isActive: function () {
        return !Ext.platformTags.phone;
    }
});
