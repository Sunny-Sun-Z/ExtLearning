/**
 * The main application class. An instance of this class is created by app.js when it
 * calls Ext.application(). This is the ideal place to handle application launch and
 * initialization details.
 */
Ext.define('QuickStart.Application', {
    extend: 'Ext.app.Application',
    
    name: 'QuickStart',

    defaultToken : 'dashboard',

    mainView: 'QuickStart.view.main.Main',

    profiles: [
        'Phone',
        'Tablet'
    ],

    stores: [
        'NavigationTree'
    ]
});
