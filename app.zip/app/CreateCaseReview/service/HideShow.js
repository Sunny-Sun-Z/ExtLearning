﻿/* globals App*/
Ext.define('App.service.HideShow',
{
    extend: Ext.Base.$className,
    constructor: function (viewModel) {
        //"use strict";
        var itemIds = App.Common.StringResources.ItemIds;
        var hideShow = function ()
        {
            hideShowTimeoutId = 0;
            Ext.suspendLayouts();
            if (viewModel.getValue('MAINDATA.HIDERADIOS') === 'Y') {
                viewModel.hide('Tab1_MAINDATA_YES_NO_Y'); // the itemId we want to hide
                viewModel.hide('Tab1_MAINDATA_YES_NO_N'); // the itemId we want to hide
            } else {
                viewModel.show('Tab1_MAINDATA_YES_NO_Y'); // the itemId we want to show
                viewModel.show('Tab1_MAINDATA_YES_NO_N'); // the itemId we want to show
            }
            if (viewModel.getValue('MAINDATA.HIDEFIRSTNAMEFIELD') === 'Y') {
                viewModel.hide(itemIds.MainDataFirstNameInputEl);
            } else {
                viewModel.show(itemIds.MainDataFirstNameInputEl);
            }
            Ext.resumeLayouts();
        };
        var hideShowTimeoutId = 0;
        viewModel.on('setValue', function (name /*, value*/)
        {
            // you probably want to filter by names that will have impact
            if (name !== 'MAINDATA.HIDERADIOS' && name !== 'MAINDATA.HIDEFIRSTNAMEFIELD')
            {
                return;
            }

            if (hideShowTimeoutId !== 0)
            {
                return;
            }
            hideShowTimeoutId = setTimeout(hideShow, 0);
        });
    }
});