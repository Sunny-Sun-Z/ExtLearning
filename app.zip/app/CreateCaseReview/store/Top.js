﻿/* globals App*/
Ext.define('App.CreateCaseReview.store.CaseReviewTop', {
    extend: Ext.data.Store.$className,
    //Fully Qualified Model required
    model: App.model.CaseReviewTop.$className,
    autoLoad: false,
    proxy: {
        type: 'direct',
        api: {
            read: window.Data.GetCreateCaseReviewData
        },
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    }
});