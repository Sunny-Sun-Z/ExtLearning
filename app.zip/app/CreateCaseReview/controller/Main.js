﻿/* globals App*/
var revStartDate;
var revCompleteDate;
var saveRequestResults = [];

var getMinCompletionDate = function () {

    var result;

    return Ext.isEmpty(revStartDate) ? Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30) : Ext.Date.add(revStartDate, Ext.Date.DAY, 1);
};

var changeDataState = function (store) {

    var dataState = {
        Added: 0,
        Deleted: 1,
        Detached: 2,
        Modified: 3,
        Unchanged: 4
    };

    var data = store.first();
    if (!data) {
        return;
    }

    // Check if the record was modified.

    for (var i = 0; i < store.count() ; i++) {
        if (store.getAt(i).dirty == true || !Ext.isEmpty(store.getAt(i).data["TS_CR"])) {
            store.getAt(i).data["DataState"] = dataState.Added;
        }
    }

    //// Check if the record was modified.
    //if (data.dirty || data.data["TS_CR"]!=null) {
    //    data.data["DataState"] = dataState.Added;
    //}


    // Loop through all the stores. If they have children and the children count is more than 0,
    // that means a child was added. This is for the situation where you add a child before a parent.
    // Eg add a child participant but dont make any changes for the facesheet screen.

    for (var iRecord = 0; iRecord < store.count() ; iRecord++) {
        data = store.getAt(iRecord);
        for (var property in data.data) {
            if (data.data.hasOwnProperty(property) && property !== 'store') {
                var propertyValue = data.data[property];
                if (typeof propertyValue !== 'undefined' && !!data[property] && propertyValue !== null && propertyValue.constructor === Array) {
                    var childStore = Ext.StoreManager.get(property + 'Store');
                    if (Ext.isEmpty(childStore)) {
                        childStore = Ext.StoreManager.get(data.data["ExtId"]);
                    }

                    if (!Ext.isEmpty(childStore) && childStore.count() > 0) {
                        if (data.data["DataState"] !== dataState.Added) {
                            for (var i = 0; i < childStore.count() ; i++) {
                                if (childStore.getAt(i).data["DataState"] == dataState.Added || !Ext.isEmpty(childStore.getAt(i).data["TS_CR"])) {
                                    data.data["DataState"] = dataState.Added;
                                }
                            }

                        }
                        changeDataState(childStore);
                    }
                }
            }
        }
    }
};

var changeReviewId = function (store) {

    for (var iCount = 0; iCount < store.count() ; iCount++) {

        var data = store.getAt(iCount);
        var lookupStore = Ext.StoreMgr.get('CrSecurityUserStore');
        var results = lookupStore.query('UserID', data.data['UserID'], false, false, true);
        if (results.length > 0) {
            data.data["FirstName"] = results.getAt(0).data.FirstName;
            data.data["LastName"] = results.getAt(0).data.LastName;
            data.data["FullName"] = results.getAt(0).data.FirstName + " " + results.getAt(0).data.LastName;
        }
    }
}

var checkforDuplicates = function () {

    var reviewers, initialQA, secondLevelQA, secondaryOversight, ctSecondaryOversight, reviewer, nameId, userId, displayName,
        viewModel = window.App.app.controllers.items[0].getAppForm().down('#createCaseReview').down('form').viewModel;

    var reviewerStore = Ext.StoreMgr.get('CR_Reviewer_CollectionStore');

    if (reviewerStore.count() > 0) {

        reviewers = [];

        for (var iCount = 0; iCount < reviewerStore.count() ; iCount++) {
            var data = reviewerStore.getAt(iCount);

            nameId = "Reviewer" + (iCount + 1);
            userId = data.data["UserID"];
            displayName = 'Reviewer';

            reviewer = { 'NameId':nameId, 'UserId': userId, 'DisplayName': displayName };
            reviewers.push(reviewer);
        }
    }

    var caseReviewStore = Ext.StoreMgr.get('CaseReviewStore');
    
    nameId = 'initialQA';
    userId = viewModel.data.caseReviewHeader.intialQAId;

    if (!Ext.isEmpty(userId) && userId != 0) {

        displayName = 'Initial QA';
        reviewer = { 'NameId': nameId, 'UserId': userId, 'DisplayName': displayName };
        reviewers.push(reviewer);
    }
    
    userId = viewModel.data.caseReviewHeader.secondLevelQAId;
    nameId = 'secondLevelQA';

    if (!Ext.isEmpty(userId) && userId != 0) {

        displayName = 'Second Level QA';
        reviewer = { 'NameId': nameId, 'UserId': userId, 'DisplayName': displayName };
        reviewers.push(reviewer);
    }

    userId = viewModel.data.caseReviewHeader.secondaryOversightId;
    nameId = 'secondaryOversight';

    if (!Ext.isEmpty(userId) && userId != 0) {

        displayName = 'Secondary Oversight';
        reviewer = { 'NameId': nameId, 'UserId': userId, 'DisplayName': displayName };
        reviewers.push(reviewer);
    }

    userId = viewModel.data.caseReviewHeader.ctSecondaryOversightId;
    nameId = 'ctSecondaryOversight';

    if (!Ext.isEmpty(userId) && userId != 0) {

        displayName = 'CT Secondary Oversight';
        reviewer = { 'NameId': nameId, 'UserId': userId, 'DisplayName': displayName };
        reviewers.push(reviewer);
    }
    //
    // Search for duplicates
    //
    var duplicates = [];
    
    Ext.each(reviewers, function (caseReviewer) {

        duplicates = reviewers.filter(function (rev) {

            return rev.UserId == caseReviewer.UserId;
        });

        if (duplicates.length > 1) {

            Ext.Msg.alert("Error", "Same person cannot be selected as " + duplicates[0].DisplayName + " and " + duplicates[1].DisplayName);

            return false;
        }
    });

    if (duplicates.length > 1) {

        duplicates = [];

        return false;
    }

    return true;
}
var checkforMandatoryFields = function () {

    var errorMessages = "";
    var caseReviewStore = Ext.StoreMgr.get('CaseReviewStore');
    var caseID = Ext.ComponentQuery.query('#caseID')[0];
    var reviewCompleted = Ext.ComponentQuery.query('#reviewCompleted')[0];
    var reviewStartDate = Ext.ComponentQuery.query('#reviewBeginDate')[0];
    var siteName = Ext.ComponentQuery.query('#state')[0];
    var caseName = Ext.ComponentQuery.query('#CaseName')[0];
    var reviewers = Ext.ComponentQuery.query('#reviewerCheckboxGroup')[0];
    var initialQA = Ext.ComponentQuery.query('#intitalQA')[0];
    var secondaryQA = Ext.ComponentQuery.query('#secondQA')[0];
    var secondaryOversight = Ext.ComponentQuery.query('#secondOversight')[0];
    var inHomeServicesReviewType = Ext.ComponentQuery.query('#reviewSubType1')[0];
    var fosterCareReviewType = Ext.ComponentQuery.query('#reviewSubType2')[0];
    var inHomeDRARReviewType = Ext.ComponentQuery.query('#reviewSubType3')[0];

    if (Ext.isEmpty(caseID.getValue())) {

        errorMessages = errorMessages + "- Please enter a case ID <br>";
    } else {

        if (caseID.getValue() < 0 || caseID.getValue() > 2147483647) 
            errorMessages = errorMessages + "- Please enter a case ID between 0 and 2147483647 <br>";
    }
    
    if (Ext.isEmpty(siteName.getValue())) {

        errorMessages = errorMessages + "- Please select a Site <br>";
    }

    if (Ext.isEmpty(caseName.getValue())) {

        errorMessages = errorMessages + "- Please enter Case Name <br>";
    }

    if (reviewers.store.data.length == 0) {

        errorMessages = errorMessages + "- Please select Review Participants <br>";
    }

    if (Ext.isEmpty(initialQA.getValue())) {

        errorMessages = errorMessages + "- Please enter the Initial QA <br>";
    }

    if (Ext.isEmpty(secondaryQA.getValue())) {

        errorMessages = errorMessages + "- Please enter the Secondary Level QA <br>";
    }

    if (Ext.isEmpty(secondaryOversight.getValue())) {

        errorMessages = errorMessages + "- Please enter the Secondary Oversight <br>";
    }

    if (Ext.isEmpty(reviewStartDate.getValue())) {

        errorMessages = errorMessages + "- Please enter Case Review Start Date <br>";
    }

    if (Ext.isEmpty(reviewCompleted.getValue())) {

        errorMessages = errorMessages + "- Please enter Case Review End Date <br>";
    }

    if (!inHomeServicesReviewType.checked && !fosterCareReviewType.checked && !inHomeDRARReviewType.checked) {

        errorMessages = errorMessages + "- Please select type of Case <br>";
    }

    if (!Ext.isEmpty(errorMessages)) {

        Ext.Msg.alert("Error", errorMessages);

        return false;
    }


    return true;
}

var saveCaseData = function (winObj) {

    var self = this;

    if (!checkforMandatoryFields()) {

        return;
    }

    if (checkforDuplicates()) {
        //
        // Alert message to indicate that certain fields cannot be changed after saving.
        //
        Ext.Msg.show({
            title: 'Save Case?',
            message: 'You are about to save a case. Be aware that the fields - <strong>Case ID, Name of state and county, Review Start Date, Type of Case and PIP Monitored </strong> - cannot be modified after saving! <br><br>Would you still like to save your changes?',
            buttons: Ext.Msg.YESNOCANCEL,
            icon: Ext.Msg.QUESTION,
            fn: function (btn) {

                if (btn === 'yes') {

                    winObj.saveData();
                }
            }
        });
        // End of alert
        //                
    }
}

var cancelCreateCase = function (winObj) {

    var self = this;

    Ext.destroy(winObj);

    window.history.back();
}
var getStorePropertyValue = function (parms) {

    var result;
    var filteredStore = Ext.data.StoreManager.get(parms.storeId);

    if (filteredStore.data.length > 0) {

        result = filteredStore.getAt(0).data[parms.propertyName]
    }

    return result;
}
var getSiteName = function (siteCode) {

    var result;

    var store = Ext.StoreManager.get('SiteStore');

    var filteredItem = store.data.items.filter(function (item) {

        return item.data.GroupID == siteCode;
    });

    if (filteredItem.length > 0) {

        result = filteredItem[0].data.DescriptionLarge;
    }

    return result;
}
var setStorePropertyValue = function (parms) {

    var filteredStore = Ext.data.StoreManager.get(parms.storeId);

    if (filteredStore.data.length == 0) {

        return false;
    }

    filteredStore.getAt(0).data[parms.propertyName] = parms.propertyValue;

    return true;
}

var getQAReviewerName = function (reviewerId) {

    var result;

    var store = Ext.StoreManager.get('CaseReviewQAStore');

    var filteredItem = store.data.items.filter(function (item) {

        return item.data.UserID == reviewerId;
    });

    if (filteredItem.length > 0) {

        result = filteredItem[0].data.FirstName + ' ' + filteredItem[0].data.LastName;
    }

    return result;
}
var getSecondaryOversightName = function (reviewerId) {

    var result;

    var store = Ext.StoreManager.get('CaseReviewSecondaryOversightStore');

    var filteredItem = store.data.items.filter(function (item) {

        return item.data.UserID == reviewerId;
    });

    if (filteredItem.length > 0) {

        result = filteredItem[0].data.FirstName + ' ' + filteredItem[0].data.LastName;
    }

    return result;
}

Ext.define('App.CreateCaseReview.controller.Main', {
    extend: framework.controller.ViewModelController.$className,
    id: 'CreateCaseReview',
    init: function () {
        //"use strict";
        var self = this;
        var sr = App.Common.StringResources;
        this.callParent([{
            // Class that represents the top level Model
            topStore: App.CreateCaseReview.store.CaseReviewTop.$className,
            params: {id: 0},
            // function that handles passing the data to save back to the server
            saveFunction: function ()

            {
                // Data corresponds to DataController on the server.
                // SaveData is the Action on the controller
                // mainData is the name of the parameter on SaveData in the controller
                // MAINDATAStore is our top level store that we are sending back
                // getAt(0) retrieves what should be the only record in our top level store.
                // getData(true) retrieves the JSON representation of the graph from MAINDATA on down.
                // self.saveCallback is in the parent class and handles any errors 
                // and reloads the data from the server once the save has completed

                changeDataState(Ext.StoreMgr.get('CaseReviewStore'));
                if (!checkforDuplicates()) {
                    return;
                }
                if (Ext.StoreMgr.get('CR_Reviewer_CollectionStore').count() > 0) {
                    changeReviewId(Ext.StoreMgr.get('CR_Reviewer_CollectionStore'));
                }

                if (!checkforMandatoryFields()) {
                    return;
                }

                var data = Ext.StoreMgr.get('CaseReviewStore').first();
                data.data["ReviewTypeID"] = 2;
                data.data["CaseStatusCode"] = 3;

                window.Data.SaveData(
                {
                    caseReviewTop:
                        Ext.StoreMgr.get('App.CreateCaseReview.store.CaseReviewTop')
                            .getAt(0)
                            .getData(true),
                    userID: userID
                }, self.afterSaveCallback);

                
            },

     
            // The view class this controller will create
            view: App.CreateCaseReview.view.Main.$className,
        }]);

        // The viewModel lives in parent class ViewModelController
        // between ViewModelControl and the viewModel object all changes
        // to the data in the view get reflected back into the viewModel
        // and any changes you need to make to the view should be made via
        // viewModel.  This enables the classes in the system to be
        // tested without needing a view in place.
        // You should put as little code as possible in the controller for
        // your app because the controller has a dependency on the view.
        // Instead you should create separate classes that have a dependancy
        // on the viewModel only and that dependancy should be passed in.
        // 
        // NONE OF _YOUR_ CODE SHOULD TALK TO THE VIEW DIRECTLY!
        //
        // To set a value/get a value
        //   self.viewModel.setValue('TableCollection.Field', 'NewValue');
        //     for example: 
        //         self.viewModel.setValue('MAINDATA.FIRSTNAME', 'Dave');
        //   self.viewModel.getValue('TableCollection.Field');
        //
        // To disable/enable an element
        //   self.viewModel.disable('itemIdGoesHere');
        //   self.viewModel.enable('itemIdGoesHere');
        //     If you enable an element, the children
        //     will automatically be enabled.
        //
        // To determine if an element is enabled/disabled
        //   self.viewModel.isEnabled('itemIdGoesHere');
        //   self.viewModel.isDisabled('itemIdGoesHere');
        //
        // To see if an element is valid
        //   self.viewModel.isValid('itemIdOfElementGoesHere');
        //
        // To find the errors registered by the view
        //   self.viewModel.getValidationErrors()
        //     returns an array of errors generated by the view.
        //
        // If you need to know if something has happened on the view,
        // it is probably reflected in the viewModel.  There are event
        // handlers that you can use to get notifications of changes
        // to the viewModel:
        //   To listen for changes to a value use
        //     viewModel.on('setValue', onSetValue);
        //       onSetValue is a function pointer that takes
        //         name: (MAINDATA.FIRSTNAME for example)
        //         value: the new value
        //   To listen changes when a store is cleared
        //     viewModel.on('clearStore', onClearStore);
        //       onClearStore(storeId)
        //         NOTE: it would probably be easier to
        //               add a listener to the store directly
        //               rather than use this listener
        //   To listen to changes when all of the elements
        //   on the screen are enabled
        //     viewModel.on('enableAll', onEnableAll);
        //       onEnableAll takes no parameters
        //   To listen for when an element is disabled
        //     viewModel.on('disabled', onDisabled);
        //       onDisabled(itemId)
        //   To listen for when an element is enabled
        //     viewModel.on('enabled', onEnabled);
        //       onEnabled(itemId);
        //   To listen for when an element is hidden
        //     viewModel.on('hide', onHide);
        //       onHide(itemId);
        //   To listen for when an element is made visible
        //     viewModel.on('show', onShow);
        //       onShow(itemId)

        self.viewModel.on('click', function (itemId) {

          if (itemId === 'createCaseReviewSaveButton') {

              saveRequestResults = [];

              //self.saveData();

              saveCaseData(self);
          }

          if (itemId === 'caseCancel') {
              
              cancelCreateCase(self);
          }
        });

        self.afterSaveCallback = function (caseReviewTop) {

            var caseReviewRootId = "";
            if (caseReviewTop.success) {
                caseReviewRootId = caseReviewTop.data.CaseReview[0].CaseReviewRootID;
                window.location = window.baseUrl + "CaseReview/Index/" + caseReviewRootId;
            }

        }

        self.control(
        {
            '#AppForm': {
                'afterrender': function() {


                    var items = Ext.ComponentQuery.query('#AppForm [itemId]');
                    var i, itemId, ref;
                    var itemsLength = items.length;
                    for (i = 0; i < itemsLength; i++) {
                        itemId = items[i].itemId;
                        ref = itemId.replace(/-/g, "_").replace(/\./g, "_");
                        self.addRef([{ ref: ref, selector: '#' + itemId }]);
                    }
                }
            },
            '#reviewBeginDate': {
                'select': function (cmp, newValue, oldValue) {

                    revStartDate = undefined;

                    if (!isNaN(Date.parse(newValue))) {

                        revStartDate = newValue;

                        var dateDiffToday = (new Date()).valueOf() - revStartDate.valueOf();

                        if (dateDiffToday < 0) {

                            Ext.Msg.show({
                                title: 'Invalid Review Start Date',
                                msg: 'Review Start Date cannot be in the future!!',
                                buttons: Ext.MessageBox.OK,
                                icon: Ext.MessageBox.ERROR
                            });

                            cmp.setValue('');

                            return;
                        }

                        if (!Ext.isEmpty(revCompleteDate)) {

                            var dateDiff = revCompleteDate.valueOf() - revStartDate.valueOf();

                            if (dateDiff < 0) {

                                Ext.Msg.show({
                                    title: 'Invalid Review Start Date',
                                    msg: 'Review Start Date cannot be after the Review Completed Date!!',
                                    buttons: Ext.MessageBox.OK,
                                    icon: Ext.MessageBox.ERROR
                                });

                                cmp.setValue('');
                            }
                        }                        
                    }
                },
                'blur': function (cmp, event, eOpts) {
                    
                    revStartDate = undefined;
                    var newValue = cmp.getValue();

                    if (!isNaN(Date.parse(newValue))) {

                        revStartDate = newValue;

                        var dateDiffToday = (new Date()).valueOf() - revStartDate.valueOf();

                        if (dateDiffToday < 0) {

                            Ext.Msg.show({
                                title: 'Invalid Review Start Date',
                                msg: 'Review Start Date cannot be in the future!!',
                                buttons: Ext.MessageBox.OK,
                                icon: Ext.MessageBox.ERROR
                            });

                            cmp.setValue('');

                            return;
                        }

                        if (!Ext.isEmpty(revCompleteDate)) {

                            var dateDiff = revCompleteDate.valueOf() - revStartDate.valueOf();

                            if (dateDiff < 0) {

                                Ext.Msg.show({
                                    title: 'Invalid Review Start Date',
                                    msg: 'Review Start Date cannot be after the Review Completed Date!!',
                                    buttons: Ext.MessageBox.OK,
                                    icon: Ext.MessageBox.ERROR
                                });

                                cmp.setValue('');
                            }
                        }
                    }
                }
            },
            '#reviewCompleted': {
                'select': function (cmp, newValue, eOpts) {

                    revCompleteDate = undefined;

                    if (!isNaN(Date.parse(newValue))) {

                        revCompleteDate = newValue;

                        var dateDiffToday = (new Date()).valueOf() - revCompleteDate.valueOf();

                        if (dateDiffToday < 0) {

                            Ext.Msg.show({
                                title: 'Invalid Review Completed Date',
                                msg: 'Review Completed Date cannot be in the future!!',
                                buttons: Ext.MessageBox.OK,
                                icon: Ext.MessageBox.ERROR
                            });

                            cmp.setValue('');

                            return;
                        }

                        if (!Ext.isEmpty(revStartDate)) {

                            var dateDiff = revCompleteDate.valueOf() - revStartDate.valueOf();

                            if (dateDiff <= 0) {

                                Ext.Msg.show({
                                    title: 'Invalid Review Completed Date',
                                    msg: 'Review Completed Date cannot be before the Review Start Date!!',
                                    buttons: Ext.MessageBox.OK,
                                    icon: Ext.MessageBox.ERROR
                                });

                                cmp.setValue('');
                            }
                        }
                    }
                },
                'blur': function (cmp, event, eOpts) {

                    revCompleteDate = undefined;
                    var newValue = cmp.getValue();

                    if (!isNaN(Date.parse(newValue))) {

                        revCompleteDate = newValue;

                        var dateDiffToday = (new Date()).valueOf() - revCompleteDate.valueOf();

                        if (dateDiffToday < 0) {

                            Ext.Msg.show({
                                title: 'Invalid Review Completed Date',
                                msg: 'Review Completed Date cannot be in the future!!',
                                buttons: Ext.MessageBox.OK,
                                icon: Ext.MessageBox.ERROR
                            });

                            cmp.setValue('');

                            return;
                        }

                        if (!Ext.isEmpty(revStartDate)) {

                            var dateDiff = revCompleteDate.valueOf() - revStartDate.valueOf();

                            if (dateDiff <= 0) {

                                Ext.Msg.show({
                                    title: 'Invalid Review Completed Date',
                                    msg: 'Review Completed Date cannot be before the Review Start Date!!',
                                    buttons: Ext.MessageBox.OK,
                                    icon: Ext.MessageBox.ERROR
                                });

                                cmp.setValue('');
                            }
                        }
                    }
                }
            },
            '#centerTabPanel':
             {
                 'tabchange': function (tabPanel, newCard, oldCard, eOpts) {
                     if (newCard.itemId == "createCaseReview") {
                         window.location = window.baseUrl + "CreateCaseReview";
                     }
                     else if (newCard.itemId == "dashboard") {
                         window.location = window.baseUrl;
                     }
                 },
                 'afterrender': function (cmp, eOpts) {

                     window.caseReviewViewModel = Ext.create('App.CaseReview.CaseReviewViewModel');
                 }
             },
            '#reviewerCheckboxGroup': {
                'afterrender' : function(checkboxgroup) {
                    Ext.Array.forEach(checkboxgroup.getBoxes(), function(checkbox) {

                        if (checkbox.inputValue == parseInt(window.userID)) {
                            checkbox.setValue(true);
                        }
                    });
                }
            }
        });
// ReSharper disable WrongExpressionStatement
        new App.service.EnableDisable(self.viewModel);
        new App.service.HideShow(self.viewModel);
        new App.service.Validations(self.viewModel);
// ReSharper restore WrongExpressionStatement
    }
});