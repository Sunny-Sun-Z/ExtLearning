﻿Ext.define('App.CreateCaseReview.view.Main',
{
    // Forms have to be children of tabs so our top level
    // control is derived from a Panel.
    //
    // This view is launched by the controller.
    extend: Ext.panel.Panel.$className,
    renderTo: 'ext',
    border: false,
    initComponent: function () {

        var startDate;

        var chainedStore = function(parentStore) {
            if (Ext.data.StoreManager.get(parentStore) == null) {
                return [];
            }
            return new Ext.data.ChainedStore({ source: parentStore });
        };

        var me = this;

        // these values keep us from having to type everything out
        // every time we want to put icons on the screen and makes it
        // easy to change their values in one place
        /* Commented the definitions below because they are not being used*/
        var windowBaseUrl = window.baseUrl;

        Ext.applyIf(me, {
            xtype: 'container',
            plugins: 'viewport',
            layout: 'fit',
            items: [
            {
                xtype: 'viewport',
                title: 'Border Layout',
                layout: 'border',
                bodyBorder: false,
                items: [
                {
                    region: 'south',
                    width: 100,
                    xtype: 'panel',
                    split: true,
                    layout: 'fit',
                    contentEl: 'divfootertext',
                    collapsible: true,
                    collapsed: true
                    //,header: false
                },
                {
                    region: 'center',
                    xtype: 'container',
                    layout: 'fit',
                    items: [
                    {
                        xtype: 'tabpanel',
                        layout: 'fit',
                        itemId: 'centerTabPanel',
                        activeTab:2,
                        items: [
                        {
                            title: 'CRS',
                            iconCls: 'brand',
                            disabled: true

                        },
                        {
                            title: 'Dashboard',
                            itemId : 'dashboard',
                            xtype: 'container',
                            layout: 'border'
                            },
                        {
                            title: 'Create New Case',
                            itemId: 'createCaseReview',
                            xtype: 'container',
                            layout: 'border',
                            defaults: {
                                collapsible: true,
                                split: true,
                                bodyStyle: 'padding:15px'
                            },

                            items: [
                            {
                                region: 'west',
                                xtype: 'panel',
                                collapsible: true,
                                header: false,
                                width: 300,
                                border: false,
                                bodyStyle: { "background-color": "#EEEEEE" },
                                layout: 'vbox'

                            },
                            {
                                region: 'center',
                                xtype: 'form',
                                header: false,
                                scrollable: true,
                                viewModel: {
                                    type: 'caseReviewViewModel'
                                },
                                dockedItems: [
                                    {
                                        //*****************************************************
                                        // Case Setup [Save and Cancel buttons]
                                        //*****************************************************
                                        xtype: 'toolbar',
                                        dock: 'bottom',
                                        border: false,
                                        ui: 'footer',
                                        items: ['->',
                                            {
                                                //CANCEL BUTTON                                
                                                text: 'Cancel',
                                                type: 'close',
                                                itemId: 'caseCancel',
                                                scale: 'medium'
                                            },
                                            {
                                                //SAVE BUTTON                                                
                                                text: 'Save',
                                                type: 'save',
                                                itemId: 'createCaseReviewSaveButton',
                                                margin: '0 50 0 10',
                                                scale: 'medium'
                                            }
                                        ]
                                    }
                                ],
                                items: [
                                {
                                    xtype: 'panel',
                                    margin: '0 20 20 20',
                                    bodyCls: 'panel-background-color',
                                    border: true,
                                    animCollapse: false,
                                    items:
                                    [
                                        {
                                            xtype: 'component',
                                            margin: '20 0 20 20',
                                            html: "<p style='font-size:20px;font-weight:bold; !important' >Create Case Review</style>"
                                        },
                                        {
                                            xtype: 'panel',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout: 'hbox',
                                            margin: '20 20 20 40',
                                            items: [
                                                {
                                                    xtype: 'numberfield',
                                                    itemId: 'caseID',
                                                    fieldLabel: 'Case ID ',
                                                    name: 'CaseReview.CaseID',
                                                    bind: '{caseReviewHeader.caseId}',
                                                    minValue : 0,
                                                    maxValue: 2147483647,
                                                    hideTrigger: true,
                                                    keyNavEnabled: false,
                                                    mouseWheelEnabled: false,
                                                    allowDecimals : false
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'panel',
                                            title: "<div class='html-content-header-margins'>Definition and Instructions for Questions A through F below: [SHOW]</div>",
                                            baseCls: 'x-panel panel-background-list',
                                            collapsible: 'true',
                                            collapsed: true,
                                            titleCollapse: true,
                                            width: 550,
                                            margin: '20 0 20 20',
                                            padding: '0 0 0 0',
                                            defaults: {
                                                bodyStyle: 'border-top: 1px solid #DDD !important'
                                            },
                                            items: [
                                                {
                                                    html: "<div class='html-content-item-margins text-justify'>" +
                                                        "<ul><li>For the local area, use the name that is used by the state for the review. This may be a region rather than a county, or may be multiple counties.</li>" +
                                                        "<li>Enter the case name that is the official name on the case file.</li>" +
                                                        "<li>The period under review is the time frame used for making decisions about the case. It begins with the sampling period start date and ends with the date the case review was completed.</li>" +
                                                        "</ul></div>"
                                                }
                                            ]

                                        },
                                        {
                                            xtype: 'component',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            margin: '15 0 0 20',
                                            html: "<p style='color:red;font-size:1.1em'>For question A, please verify that the site is accurate. You will not be able to change the site later.</p>"
                                        },
                                        //**********************************************************************
                                        // Question A
                                        //**********************************************************************
                                        {
                                            xtype: 'component',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            margin: '15 0 0 20',
                                            html: '<strong>A. Name of state and county (or local area):</strong>'
                                        },
                                        {
                                            xtype: 'container',
                                            border: false,
                                            margin: '20 0 0 40',
                                            bodyCls: 'panel-background-color',
                                            items: [
                                                {
                                                    xtype: 'combobox',
                                                    store: 'SiteStore',
                                                    displayField: 'DescriptionLarge',
                                                    valueField: 'GroupID',
                                                    width: 200,
                                                    editable: false,
                                                    itemId: 'state',
                                                    name: 'CaseReview.SiteCode',
                                                    bind: '{caseReviewHeader.siteCode}'
                                                }
                                            ]
                                        },
                                        //**********************************************************************
                                        // Question B
                                        //**********************************************************************
                                        {
                                            xtype: 'component',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            margin: '15 0 0 20',
                                            html: '<strong>B. Case Name:</strong>'
                                        },
                                        {
                                            xtype: 'panel',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout: 'hbox',
                                            margin: '20 20 20 40',
                                            items: [
                                                {
                                                    xtype: 'textfield',
                                                    length: 300,
                                                    itemId: 'CaseName',
                                                    name: 'CaseReview.CaseName',
                                                    bind: '{caseReviewHeader.caseName}'
                                                }
                                            ]
                                        },
                                        //**********************************************************************
                                        // Question C
                                        //**********************************************************************
                                        {
                                            xtype: 'component',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            margin: '15 0 0 20',
                                            html: "<p style='color:red;font-size:1.1em'>For question C, please verify that the PUR start date is accurate. You will not be able to change this date later.</p>"
                                        },
                                        {
                                            xtype: 'component',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            margin: '15 0 0 20',
                                            html: '<strong>C. Period under review begins on:</strong>'
                                        },
                                        {
                                            xtype: 'panel',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout: 'hbox',
                                            margin: '20 20 20 40',
                                            items: [
                                                {
                                                    xtype: 'datefield',
                                                    length: 300,
                                                    itemId: 'reviewBeginDate',
                                                    msgTarget: 'under',
                                                    name: 'CaseReview.ReviewStartDate',
                                                    bind: '{caseReviewHeader.reviewStartDate}',
                                                    maxValue: new Date(),
                                                    minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30)
                                                }
                                            ]
                                        },
                                        //**********************************************************************
                                        // Question D
                                        //**********************************************************************
                                        {
                                            xtype: 'component',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            margin: '15 0 0 20',
                                            html: '<strong>D. Review Participants:</strong></p>'
                                        },
                                        {
                                            xtype: 'component',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            margin: '15 0 0 40',
                                            html: 'Please select up to 3 reviewers.</strong>'
                                        },
                                        {
                                            xtype: 'panel',
                                            border: true,
                                            margin: '20 0 0 40',
                                            bodyCls: 'panel-background-color',
                                            height: 200,
                                            width: 600,
                                            scrollable: true,
                                            items: [
                                                {
                                                    xtype: 'boundcheckboxgroup',
                                                    columns: 4,
                                                    columnWidth : 200,
                                                    vertical: true,
                                                    store: 'CR_Reviewer_CollectionStore',
                                                    inputField: 'UserID',
                                                    itemId: 'reviewerCheckboxGroup',
                                                    listeners: {
                                                        'beforerender': function () {
                                                             var checkboxgroup = this;
                                                             var checkboxgroupStore = Ext.StoreManager.get('CaseReviewReviewersStore');
                                                            var checkbox = null;
                                                            for (var iCheckboxCount = 0; iCheckboxCount < checkboxgroupStore.count() ; iCheckboxCount++) {
                                                                checkbox = new Ext.form.Checkbox({
                                                                    itemId : 'checkbox' + iCheckboxCount,
                                                                    boxLabel: checkboxgroupStore.getAt(iCheckboxCount).data.FirstName + " " + checkboxgroupStore.getAt(iCheckboxCount).data.LastName,
                                                                    inputValue: checkboxgroupStore.getAt(iCheckboxCount).data.UserID,
                                                                    //checked: checkboxgroupStore.getAt(iCheckboxCount).data.UserID == window.userID ? true : false,
                                                                    listeners:  {
                                                                        'change': function () {
                                                                            var checkbox = this;
                                                                            var checkboxGroup = Ext.ComponentQuery.query('#reviewerCheckboxGroup')[0];
                                                                            if (checkboxGroup.getChecked().length > 3) {
                                                                                alert("A maximum of 3 reviwers can be selected per case.");
                                                                                checkbox.setValue(false);
                                                                                return false;
                                                                            }
                                                                            return true;
                                                                        }
                                                                    }
                                                                });
                                                                checkboxgroup.items.add(checkbox);
                                                            }

                                                        },
                                                    }

                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            margin: '15 0 0 40',
                                            html: '<strong>Initial QA completed by (name):</strong>'
                                        },
                                        {
                                            xtype: 'container',
                                            border: false,
                                            margin: '20 0 0 40',
                                            bodyCls: 'panel-background-color',
                                            items: [
                                                {
                                                    xtype: 'combo',
                                                    itemId: 'intitalQA',
                                                    flex: 1,
                                                    store: 'CaseReviewQAStore',
                                                    editable: false,
                                                    valueField: 'UserID',
                                                    displayField: 'LastName',
                                                    autoSelect: true,
                                                    forceSelection: true,
                                                    width: 200,
                                                    name: 'CaseReview.InitialQAUserID',
                                                    bind: '{caseReviewHeader.intialQAId}',
                                                    tpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '<div class="x-boundlist-item">{FirstName} {LastName}</div>', '</tpl>'),
                                                    displayTpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '{FirstName} {LastName}', '</tpl>')
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            margin: '15 0 0 40',
                                            html: '<strong>Second Level QA completed by (name):</strong>'
                                        },
                                        {
                                            xtype: 'container',
                                            border: false,
                                            margin: '20 0 0 40',
                                            bodyCls: 'panel-background-color',
                                            items: [
                                                {
                                                    xtype: 'combo',
                                                    itemId: 'secondQA',
                                                    flex: 1,
                                                    store: 'CaseReviewQAStore',
                                                    valueField: 'UserID',
                                                    displayField: 'LastName',
                                                    editable: false,
                                                    autoSelect: true,
                                                    forceSelection: true,
                                                    width: 200,
                                                    name: 'CaseReview.SecondQAUserID',
                                                    bind: '{caseReviewHeader.secondLevelQAId}',
                                                    tpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '<div class="x-boundlist-item">{FirstName} {LastName}</div>', '</tpl>'),
                                                    displayTpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '{FirstName} {LastName}', '</tpl>')
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            margin: '15 0 0 40',
                                            html: '<strong>Secondary Oversight completed by (name):</strong>'
                                        },
                                        {
                                            xtype: 'container',
                                            border: false,
                                            margin: '20 0 0 40',
                                            bodyCls: 'panel-background-color',
                                            items: [
                                                {
                                                    xtype: 'combo',
                                                    itemId: 'secondOversight',
                                                    flex: 1,
                                                    store: 'CaseReviewSecondaryOversightStore',
                                                    valueField: 'UserID',
                                                    displayField: 'LastName',
                                                    editable: false,
                                                    autoSelect: true,
                                                    forceSelection: true,
                                                    width: 200,
                                                    name: 'CaseReview.SecondaryOversightUserID',
                                                    bind: '{caseReviewHeader.secondaryOversightId}',
                                                    tpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '<div class="x-boundlist-item">{FirstName} {LastName}</div>', '</tpl>'),
                                                    displayTpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '{FirstName} {LastName}', '</tpl>')
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            margin: '15 0 0 40',
                                            html: '<strong>Secondary CT Oversight completed by (name):</strong>'
                                        },
                                    {
                                        xtype: 'container',
                                        itemId: 'secondCTQAOversight',
                                        border: false,
                                        margin: '20 0 0 40',
                                        bodyCls: 'panel-background-color',
                                        items: [
                                              {
                                                  xtype: 'combo',
                                                  itemId: 'secondCTOversight',
                                                  flex: 1,
                                                  store: 'CaseReviewSecondaryOversightStore',
                                                  valueField: 'UserID',
                                                  displayField: 'LastName',
                                                  autoSelect: false,
                                                  editable: true,
                                                  forceSelection: false,
                                                  width: 200,
                                                  name: 'CaseReview.CtSecondaryOversightUserID',
                                                  bind: '{caseReviewHeader.ctSecondaryOversightId}',
                                                  tpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '<div class="x-boundlist-item">{FirstName} {LastName}</div>', '</tpl>'),
                                                  displayTpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '{FirstName} {LastName}', '</tpl>')
                                              }
                                        ]
                                    },
                                        //**********************************************************************
                                        // Question E
                                        //**********************************************************************
                                        {
                                            xtype: 'component',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            margin: '15 0 0 20',
                                            html: '<strong>E. Date case review was completed:</strong>'
                                        },
                                        {
                                            xtype: 'panel',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout: 'hbox',
                                            margin: '20 20 20 40',
                                            items: [
                                                {
                                                    xtype: 'datefield',
                                                    itemId: 'reviewCompleted',
                                                    allowBlank : false,
                                                    length: 300,
                                                    name: 'CaseReview.ReviewCompleted',
                                                    msgTarget: 'under',
                                                    bind: '{caseReviewHeader.reviewCompletedDate}',
                                                    maxValue: new Date(),
                                                    //minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30)
                                                    minValue: getMinCompletionDate()
                                                }
                                            ]
                                        },
                                        //**********************************************************************
                                        // Question F Instructions
                                        //**********************************************************************
                                        {
                                            xtype: 'panel',
                                            title: "<div class='html-content-header-margins'>Question F Instructions: [SHOW]</div>",
                                            baseCls: 'x-panel panel-background-list',
                                            width: 550,
                                            collapsible: 'true',
                                            collapsed: true,
                                            titleCollapse: true,
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            defaults: {
                                                bodyStyle: 'border-top: 1px solid #DDD !important'
                                            },
                                            items: [
                                                {
                                                    html: "<div class='html-content-item-margins text-justify'>" +
                                                        "<ul><li>The case is a foster care case if the target child was in foster care at any time during the period under review. A child is considered to be in foster care if the state child welfare agency or another public agency with whom the agency has a title IV-E agreement (hereafter 'the agency') has placement and care responsibility for the child. This includes a child who is placed by the agency with relatives or in other kin-type placements, but the agency maintains placement and care responsibility. It does not include a child who is living with relatives (or caregivers other than parents) but who is not under the placement and care responsibility of the agency.</li>" +
                                                        "<li>The case is an in-home services case if no child in the family was in foster care at any time during the period under review, and the case was open for at least 45 days.</li>" +
                                                        "<li>The case is an in-home services differential/alternative response case if the state has some form of differential/alternative response program during the period under review and the in-home services case was served through that program.</li>" +
                                                        "</ul></div>"
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            margin: '15 0 0 20',
                                            html: "<p style='color:red;font-size:1.1em'>For question F, please verify that the case type is accurate. You will not be able to change the case type later.</p>"
                                        },
                                        {
                                            xtype: 'component',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            margin: '15 0 0 20',
                                            html: '<strong>F. What is the type of case reviewed:</strong>'
                                        },
                                        {
                                            xtype: 'container',
                                            layout: 'vbox',
                                            margin: '0 0 0 40',
                                            items: [
                                                {
                                                    xtype: 'radio',
                                                    boxLabel: 'In-Home Services',
                                                    name: 'CaseReview.ReviewSubTypeID',
                                                    bind: '{reviewSubTypeId}',
                                                    itemId: 'reviewSubType1',
                                                    inputValue: '19',

                                                },
                                                {
                                                    xtype: 'radio',
                                                    boxLabel: 'Foster Care',
                                                    name: 'CaseReview.ReviewSubTypeID',
                                                    bind: '{reviewSubTypeId}',
                                                    itemId: 'reviewSubType2',
                                                    inputValue: '20',
                                                },
                                                {
                                                    xtype: 'radio',
                                                    boxLabel: 'In-Home Services – DR/AR ',
                                                    name: 'CaseReview.ReviewSubTypeID',
                                                    bind: '{reviewSubTypeId}',
                                                    itemId: 'reviewSubType3',
                                                    inputValue: '21',
                                                }
                                            ]
                                        },
                                        //**********************************************************************
                                        // PIP Monitored Instructions
                                        //**********************************************************************
                                        {
                                            xtype: 'panel',
                                            title: "<div class='html-content-header-margins'>PIP Monitored Instructions: [SHOW]</div>",
                                            baseCls: 'x-panel panel-background-list',
                                            width: 550,
                                            collapsible: 'true',
                                            collapsed: true,
                                            titleCollapse: true,
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            defaults: {
                                                bodyStyle: 'border-top: 1px solid #DDD !important'
                                            },
                                            items: [
                                                {
                                                    html: "<div class='html-content-item-margins text-justify'>" +
                                                        "Cases can be marked as \"PIP Monitored\" at case creation by selecting the checkbox below. " +
                                                        "Only check this box for a case that has been identified in advance as a case being used for PIP monitoring purposes. " +
                                                        "Once the Case Setup page is saved and the case is created, the \"PIP Monitored\" checkbox cannot be changed by the state user " +
                                                        "and can only be changed by contacting the CWRP Help Desk. " +
                                                        "Marking a case as \"PIP Monitored\" allows the case to be filtered as such on the Cases page and in the reports.</div>"
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'radiogroup',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout: 'hbox',
                                            margin: '0 0 0 20',
                                            listeners: {
                                                render: function (comp, eOpts) {

                                                    var pipChecked = false;

                                                    Ext.each(comp.items.items, function (item) {

                                                        if (item.checked) {

                                                            pipChecked = true;

                                                            return false;
                                                        }
                                                    });

                                                    if (pipChecked) {

                                                        Ext.each(comp.items.items, function (item) {

                                                            if (item.isRadio) {

                                                                if (!item.checked) {

                                                                    item.setDisabled(true);
                                                                }
                                                            }
                                                        });
                                                    }
                                                }
                                            },
                                            items: [
                                                {
                                                    xtype: 'displayfield',
                                                    fieldLabel: '<b>PIP Monitored</b>'
                                                },
                                                {
                                                    boxLabel: '<b>Yes</b>',
                                                    itemId: 'pipMonitoredYes',
                                                    inputValue: 1,
                                                    name: 'CaseReview.IsPIPMonitored',
                                                    bind: '{pipMonitored}'
                                                },
                                                {
                                                    margin: '0 0 0 10',
                                                    boxLabel: '<b>No</b>',
                                                    itemId: 'pipMonitoredNo',
                                                    inputValue: 2,
                                                    name: 'CaseReview.IsPIPMonitored',
                                                    bind: '{pipMonitored}'
                                                }
                                            ]
                                        }
                                    ]
                                }
                                ]
                            }
                            ]
                        }
                        ]
                    }]
                }
                ]
            }

            ]
        }
        );
        me.callParent(arguments);
    }
});