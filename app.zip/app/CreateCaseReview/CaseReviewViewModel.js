﻿Ext.define('App.CaseReview.CaseReviewViewModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.caseReviewViewModel',
    stores: {
        caseReviewStore: {
            model: 'CaseReview'
        }
    },
    data: {
        caseReviewHeader: {
            caseId: null,
            caseName: null,
            caseReviewId: null,
            caseReviewRootId: null,
            caseStatusCode: null,
            reviewTypeId: null,
            reviewSubTypeId: null,
            siteCode: null,
            siteName: null,
            pipMonitored: null,
            intialQAId: null,
            intialQAName: null,
            secondLevelQAId: null,
            secondLevelQAName: null,
            secondaryOversightId: null,
            secondaryOversightName: null,
            ctSecondaryOversightId: null,
            reviewStartDate: null,
            reviewCompletedDate: null,
            reviewPeriod: null,
            reviewers: null
        }
    },
    formulas: {
        caseId: {
            bind: {
                bindTo: 'caseReviewHeader.caseId',
                deep: true,
            },
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'CaseID';

                return getStorePropertyValue(parms);
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'CaseID';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        caseName: {
            bind: {
                bindTo: 'caseReviewHeader.caseName',
                deep: true,
            },
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'CaseName';

                return getStorePropertyValue(parms);
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'CaseName';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        caseReviewId: {
            bind: {
                bindTo: 'caseReviewHeader.caseReviewId',
                deep: true,
            },
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'CaseReviewID';

                return getStorePropertyValue(parms);
            }
        },
        caseReviewRootId: {
            bind: {
                bindTo: 'caseReviewHeader.caseReviewRootId',
                deep: true,
            },
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'CaseReviewRootID';

                return getStorePropertyValue(parms);
            }
        },
        caseStatusCode: {
            bind: {
                bindTo: 'caseReviewHeader.caseStatusCode',
                deep: true,
            },
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'CaseStatusCode';

                return getStorePropertyValue(parms);
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'CaseStatusCode';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        reviewTypeId: {
            bind: {
                bindTo: 'caseReviewHeader.reviewTypeId',
                deep: true,
            },
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'ReviewTypeID';

                return getStorePropertyValue(parms);
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'ReviewTypeID';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        reviewSubTypeId: {
            bind: {
                bindTo: 'caseReviewHeader.reviewSubTypeId',
                deep: true,
            },
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'ReviewSubTypeID';

                return getStorePropertyValue(parms);
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'ReviewSubTypeID';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        siteCode: {
            bind: {
                bindTo: 'caseReviewHeader.siteCode',
                deep: true,
            },
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'SiteCode';

                return getStorePropertyValue(parms);
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'SiteCode';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        siteName: {
            bind: {
                bindTo: 'caseReviewHeader.siteName',
                deep: true,
            },
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'SiteCode';

                var siteCode = getStorePropertyValue(parms);

                return getSiteName(siteCode);
            }
        },
        pipMonitored: {
            bind: {
                bindTo: 'caseReviewHeader.pipMonitored',
                deep: true,
            },
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'IsPIPMonitored';

                return getStorePropertyValue(parms);
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'IsPIPMonitored';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        intialQAId: {
            bind: {
                bindTo: 'caseReviewHeader.initialQAId',
                deep: true,
            },
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'InitialQAUserID';

                return getStorePropertyValue(parms);
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'InitialQAUserID';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        intialQAName: {
            bind: {
                bindTo: 'caseReviewHeader.initialQAName',
                deep: true,
            },
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'InitialQAUserID';

                var reviewerId = getStorePropertyValue(parms);

                return getQAReviewerName(reviewerId);
            }
        },
        secondLevelQAId: {
            bind: {
                bindTo: 'caseReviewHeader.secondLevelQAId',
                deep: true,
            },
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'SecondQAUserID';

                return getStorePropertyValue(parms);
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'SecondQAUserID';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        secondLevelQAName: {
            bind: {
                bindTo: 'caseReviewHeader.secondLevelQAName',
                deep: true,
            },
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'SecondQAUserID';

                var reviewerId = getStorePropertyValue(parms);

                return getQAReviewerName(reviewerId);
            }
        },
        secondaryOversightId: {
            bind: {
                bindTo: 'caseReviewHeader.secondaryOversightId',
                deep: true,
            },
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'SecondaryOversightUserID';

                return getStorePropertyValue(parms);
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'SecondaryOversightUserID';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        secondaryOversightName: {
            bind: {
                bindTo: 'caseReviewHeader.secondaryOversightName',
                deep: true,
            },
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'SecondaryOversightUserID';

                var oversightId = getStorePropertyValue(parms);

                return getSecondaryOversightName(oversightId);
            }
        },
        ctSecondaryOversightId: {
            bind: {
                bindTo: 'caseReviewHeader.ctSecondaryOversightId',
                deep: true,
            },
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'CtSecondaryOversightUserID';

                return getStorePropertyValue(parms);
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'CtSecondaryOversightUserID';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        ctSecondaryOversightName: {
            bind: {
                bindTo: 'caseReviewHeader.ctSecondaryOversightName',
                deep: true,
            },
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'CtSecondaryOversightUserID';

                var oversightId = getStorePropertyValue(parms);

                return getSecondaryOversightName(oversightId);
            }
        },
        reviewStartDate: {
            bind: {
                bindTo: 'caseReviewHeader.reviewStartDate',
                deep: true,
            },
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'ReviewStartDate';

                return new Date(getStorePropertyValue(parms));
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'ReviewStartDate';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        reviewCompletedDate: {
            bind: {
                bindTo: 'caseReviewHeader.reviewCompletedDate',
                deep: true,
            },
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'ReviewCompleted';

                return new Date(getStorePropertyValue(parms));
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'ReviewCompleted';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        reviewPeriod: {
            bind: {
                bindTo: 'caseReviewHeader.reviewPeriod',
                deep: true,
            },
            get: function () {

                var reviewStartDate = this.data.reviewStartDate;
                var reviewEndDate = this.data.reviewCompletedDate;

                return Ext.Date.format(reviewStartDate, 'm/d/Y') + ' - ' + Ext.Date.format(reviewEndDate, 'm/d/Y');
            }
        },
        reviewers: {
            bind: {
                bindTo: 'caseReviewHeader.reviewers',
                deep: true,
            },
            get: function () {

                var reviewers = [];

                var reviewerStore = Ext.StoreManager.get('CR_Reviewer_CollectionStore');

                Ext.each(reviewerStore.data.items, function (reviewer) {

                    reviewers.push(reviewer);
                });

                return reviewers;
            }
        }
    }
});
