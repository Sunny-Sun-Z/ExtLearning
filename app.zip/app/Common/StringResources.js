﻿var App = App || {};
App.Common = App.Common || {};
App.Common.StringResources = {
    Stores: {
        LOOKUPTABLE1: 'LOOKUPTABLE1Store',
        CHILDREN: 'CHILDRENStore'
    },
    ItemIds: {
        combo1: 'combo1',
        MainDataFirstName: 'MainDataFirstName',
        MainDataFirstNameInputEl: 'MainDataFirstName.inputEl',
        buttonChildrenGridAdd: 'buttonChildrenGridAdd',
        buttonChildrenGridEdit: 'buttonChildrenGridEdit',
        buttonChildrenGridDelete: 'buttonChildrenGridDelete',
        gridChildren: 'gridChildren',
        caseParticipantGridAddButton: 'caseParticipantGridAddButton',
        caseParticipantGridEditButton: 'caseParticipantGridEditButton',
        caseParticipantGridDeleteButton: 'caseParticipantGridDeleteButton',
        caseParticipantGrid: 'caseParticipantGrid',
        childDemographicGridAddButton: 'childDemographicGridAddButton',
        childDemographicGridEditButton: 'childDemographicGridEditButton',
        childDemographicGridDeleteButton: 'childDemographicGridDeleteButton',
        placementGridAddButton: 'placementGridAddButton',
        placementGridEditButton: 'placementGridEditButton',
        placementGridDeleteButton: 'placementGridDeleteButton',
        goalGridAddButton: 'goalGridAddButton',
        goalGridEditButton: 'goalGridEditButton',
        goalGridDeleteButton: 'goalGridDeleteButton',
        pdHealthGridAddButton: 'pdHealthGridAddButton',
        pdHealthGridEditButton: 'pdHealthGridEditButton',
        pdHealthGridDeleteButton: 'pdHealthGridDeleteButton',
        mbHealthGridAddButton: 'mbHealthGridAddButton',
        mbHealthGridEditButton: 'mbHealthGridEditButton',
        mbHealthGridDeleteButton: 'mbHealthGridDeleteButton',
        educationGridAddButton: 'educationGridAddButton',
        educationGridEditButton: 'educationGridEditButton',
        educationGridDeleteButton: 'educationGridDeleteButton',
        safetyReportGridAddButton: 'safetyReportGridAddButton',
        safetyReportGridEditButton: 'safetyReportGridEditButton',
        safetyReportGridDeleteButton: 'safetyReportGridDeleteButton'
    },
    Permissions : {
        ViewCaseReadOnly: 1,
        CreateCaseReview: 2,
        EliminateCase: 3,
        ViewCaseLevelReports: 4,
        CompleteAdministration: 12,
        SecurityManagement: 13,
        AssignAsQA: 14,
        AssignAsSecondaryOversight: 15,
        EditCaseData: 16,
        AccessHelpTab: 17,
        AccessReportsTab: 18,
        AccessReviewReports: 19,
        SubmitToQA: 20,
        AddEditCaseNotes: 21,
        OverrideRating: 22,
        ApproveEliminateCases: 23,
        TransferToReviewer: 24,
        FinalizeAndApproveCase: 25,
        EditCaseSetup: 26,
        AssignSelfAsReviewer: 27,
        ITAdministrator: 28,
        SubmitToFinalize: 29,
        SubmitBackToQA : 30
    },
    UserRoles : {
        StateReviewer:1,
        StateSideLeader:2,
        FederalReviewer:3,
        FederaleaLeader:4,
        ConsultantReviewer:5,
        ConsultantSiteLeader:6,
        StateAdministrator:7,
        ObservererveObserver:8,
        InitialQA:15,
        SecondQA:16,
        SecondaryOverssight:17,

    },
    CaseStatus: {
        DataEntryComplete : 1,
        InProgress : 2,
        NotStarted : 3,
        QAinProgress : 4,
        FinalizedPendingApproval : 5,
        CaseEliminated : 6,
        ApprovedandFinal : 7,
        CaseEliminatedPendingApproval : 8
    },
    ItemStatus: {
        Completed: 1,
        InProgress: 2,
        NotStarted: 3,
        NotApplicable : 4
    },
    CaseSubType : {
        CFSRInHomeServices : 19,
        CFSRFosterCare : 20,
        CFSRInHomeServicesDRAR : 21,
        ACRInHomeServicesDRAR : 22,
        ACRJuvenileJustice : 23,
        ACRBehavioralHealth : 24,
        ACRInHomeServices : 25,
        ACRFosterCare : 26 
    },
    ParticipantRole: {
        Mother: 1,
        Father : 2
    },
    CheckboxState : {
        Unchanged: null,
        Checked: 1,
        Unchecked : 2
    },
    DISPLAY: 'DISPLAY',
    VALUE: 'VALUE',
    displayFieldMAINDATA_FIRSTNAME: 'displayFieldMAINDATA_FIRSTNAME',
    CHILDREN: 'CHILDREN',
    MAINDATA: {
        LOOKUP1VALUEA: 'MAINDATA.LOOKUP1VALUE',
        HIDEFIRSTNAMEFIELD: 'MAINDATA.HIDEFIRSTNAMEFIELD',
        FIRSTNAME: 'MAINDATA.FIRSTNAME',
        CHILDREN_EXIST: 'MAINDATA.CHILDREN_EXIST'
    },
    Constants: {
        AllFields : 'All'
    }
};