﻿Ext.define('App.common.Hyperlink', {
    extend: 'Ext.Component',
    alias: 'widget.hyperlink',
    config: {
        html: '',
        refItemId: null,
        refTabId: null,
        selectionCls: 'selection-color',
        refPanel: {
            parentPanelId: 'centerTabPanel',
            tabPanelId: 'wellbeingPanel'
        },
        clickTarget: null
    },

    initComponent: function () {
        var me = this,
            autoEl = { tag: 'a', href: '#' };

        Ext.apply(me, { autoEl: autoEl });

        me.callParent(arguments);
    },
    onRender: function () {
        var me = this;

        me.callParent(arguments);
        me.el.on("click", me.linkClick, me);
    },
    linkClick: function () {
        var me = this,
            params = {},
            clickTarget = me.getClickTarget()
        ;

        Ext.apply(params, me.getRefPanel());
        Ext.apply(params, { itemId: me.getRefItemId() });

        if (!Ext.isEmpty(me.getSelectionCls())) {

            me.removeSelectionCls();
            me.addCls(me.getSelectionCls());
        }
        
        var tab = me.getRefTabId();

        if(!Ext.isEmpty(tab)){

            var parentPanel = getAppController().getCenterTabPanel();
            parentPanel.setActiveTab(tab);

            updateLocationHref(tab);
        }

        if (!Ext.isEmpty(clickTarget)) {

            if (!Ext.isIE) {

                EventDispatcher.doHyperlinkClick(me);

                return;
            } else {

                var targetLink = getCRSComponent(clickTarget.itemId);

                if (!Ext.isEmpty(targetLink.getSelectionCls())) {

                    targetLink.removeSelectionCls();
                    targetLink.addCls(targetLink.getSelectionCls());
                }
            }
        }

        getContainerPosition(params);
    },
    removeSelectionCls: function () {
        var me = this,
            cls = me.getSelectionCls();

        Ext.each(me.ownerCt.items.items, function (linkObj) {

            if (linkObj.xtype == 'hyperlink') {

                linkObj.removeCls(cls);
            }
        });
    }
});

