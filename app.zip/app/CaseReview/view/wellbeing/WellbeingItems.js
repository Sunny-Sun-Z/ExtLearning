﻿//
// Item 12
//
Ext.define('app.CaseReview.view.wellbeing.Item12', {
    extend: 'Ext.container.Container',
    alias: 'widget.item12',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    items:
    [
        {
            xtype: 'component',
            itemId: 'item12',
            border: false,
            margin: '20 0 0 20',
            html: '<strong>Item 12:</strong> Needs and Services of Child, Parents, and Foster Parents',
            cls: 'outcome-item-header'
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Purpose of Assessment: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing12Purpose'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 0 0 20',
            cls: 'panel-background-color',
            html: '<strong>Item 12 Applicable Cases:</strong>'
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 0 20',
            html: '<ul> <li>Most cases are applicable for an assessment of this item because Sub-Item 12A is typically applicable to all cases. Sub-Items 12B and 12C may not be applicable to all cases, and instructions for applicability are provided before each sub-item.</li></ul>'
        }
    ]
});
//
// Item 12A
//
Ext.define('app.CaseReview.view.wellbeing.Item12A', {
    extend: 'Ext.container.Container',
    alias: 'widget.item12A',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    trackResetOnLoad: true,
    itemId: 'item12APanel',
    items:
    [
        {
            xtype: 'component',
            itemId: 'item12A',
            border: false,
            margin: '20 0 0 20',
            html: '<strong>Sub-Item 12A:</strong> Needs Assessment and Services to Children',
            cls: 'outcome-item-header'
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Sub-Item 12A Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing12AIns'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 0 0 20',
            cls: 'panel-background-color',
            html: '<strong>Item 12 Applicable Cases:</strong>'
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 0 20',
            html: '<ul> <li>All cases are applicable for an assessment of this sub-item.</li></ul>'
        },
        {
            xtype: 'itemApplicable',
            store: 'CR_Outcome_CollectionStore',
            bodyCls: 'panel-background-color',
            border: false,
            OutcomeCode: 5,
            ItemCode: 14,
            items: [
            {
                xtype: 'container',
                itemId: 'item12AChildParticipants',
                items: [
                     {
                         xtype: 'component',
                         border: false,
                         margin: '10 0 0 20',
                         cls: 'panel-background-color',
                         html: 'For in home services cases, indicate the name(s) of the child(ren) who were included in the assessment of sub-item 12A :'
                     },
                    {
                        xtype: 'validationMessage',
                        itemId: 'msgitem12AParticipantCheckboxGroupChildren',
                        itemName: 'item12A'
                    },
                    {
                        xtype: 'container',
                        bodyCls: 'panel-background-color',
                        border: false,
                        layout: 'vbox',
                        margin: '0 0 20 40',
                        items: [
                            {
                                xtype: 'checkboxgroup',
                                columns: 1,
                                vertical: true,
                                itemId: 'item12AParticipantCheckboxGroupChildren',
                                listeners: {
                                    'beforerender': function () {
                                        var checkboxgroup = this;
                                        var checkboxgroupStore = GetItemChildren();
                                        var checkbox = null;
                                        for (var iCheckboxCount = 0; iCheckboxCount < checkboxgroupStore.count() ; iCheckboxCount++) {
                                            checkbox = new Ext.form.Checkbox({
                                                boxLabel: checkboxgroupStore.getAt(iCheckboxCount).data.Name + " " + checkboxgroupStore.getAt(iCheckboxCount).data.Age,
                                                inputValue: checkboxgroupStore.getAt(iCheckboxCount).data.ChildDemographicID,
                                                itemId: 'checkbox12AChild' + checkboxgroupStore.getAt(iCheckboxCount).data.ChildDemographicID,
                                                width: 300
                                            });
                                            checkboxgroup.items.add(checkbox);
                                        }
                                    }
                                }
                            }
                        ]
                    }
                ]
            },
                {
                    xtype: 'container',
                    cls: 'panel-background-color',
                    border: false,
                    margin: '0 0 20 20',
                    items: [
                        {
                            xtype: 'component',
                            border: false,
                            margin: '10 0 0 0',
                            cls: 'panel-background-color',
                            html: 'Optional: Provide comments in the narrative field below.'
                        },
                        {
                            xtype: 'textarea',
                            itemId: 'item12AApplicabilityComments',
                            bind: '{item12AComments}',
                            enableKeyEvents: true,
                            //height: 100,  This does work with grow: true
                            //growMin: 100,
                            //growMax: 350,
                            //grow: true,
                            width: '75%',
                            maxlength: 4100,
                            enforceMaxLength: true,
                            height: 150
                        }
                    ]
                }
            ]
        }
    ]
});
//
// Item 12A Questions
//
Ext.define('app.CaseReview.view.wellbeing.Item12AQuestions', {
    extend: 'Ext.container.Container',
    alias: 'widget.item12AQuestions',
    itemId: 'item12A1',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        //*******************
        // Question A1
        //*******************
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 12A1 Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing12A1Ins'
                }                
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 0 0 20',
            cls: 'panel-background-color',
            html: '<strong>A1.</strong> During the period under review, did the agency conduct a formal or informal initial and/or ongoing comprehensive assessment that accurately assessed the children’s needs?'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '0 0 20 40',
            itemId: 'question12A1',
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'question12A1Yes',
                    inputValue: 1,
                    bind: '{isComprehensiveAssessementConducted}',
                    name: 'IsComprehensiveAssessementConducted'
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    itemId: 'question12A1No',
                    inputValue: 2,
                    bind: '{isComprehensiveAssessementConducted}',
                    name: 'IsComprehensiveAssessementConducted'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: 'If No, explain any concerns in the narrative field below.'
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            itemId: 'item12A1NeedConcerns',
            margin: '10 10 20 20',
            items: [
                {
                    xtype: 'textarea',
                    itemId: 'needConcerns',
                    name: 'CR_WellBeing_Collection.ComprehensiveAssessmentExplained',
                    bind: '{comprehensiveAssessmentExplained}',
                    enableKeyEvents: true,
                    disabled: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem12A1NeedConcerns',
                    itemName: 'item12A'
                }
            ]
        },
        //*******************
        // Question A2
        //*******************
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 12A2 Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    html: "<div class='html-content-item-margins text-justify'>" +
                        "<ul><li> If the answer to question A1 is Yes, but the result of the assessment was that no service needs were identified other than those related to education, physical health, and mental/behavioral health (including substance abuse), and therefore no services were provided other than services to address those needs, the answer to question A2 should be Not Applicable.</li>" +
                        "<li>Focus on the agency’s provision of services during the period under review. If services were provided before the period under review, and an assessment conducted during the period under review indicated no further service needs, then the answer to question A2 should be Not Applicable.</li>" +
                        "<li>Answer this question with regard to provision of services other than those related to education, physical health, or mental/behavioral health (including substance abuse). The assessment of service provision related to these issues is addressed in later items. If item 2 addresses all the safety-related services provided to the family, do not capture those services in this item.</li>" +
                        "<li>Determine whether the services provided matched identified needs. For example, were the services provided simply because those were the services available or were they provided because the assessment revealed a particular need for a particular type of service?</li>" +
                        "<li>If the case is a foster care case, independent living services should be provided to all youth age 16 and older and to children of any age with a goal of emancipation/independence or “other planned permanent living arrangement” who are expected to eventually exit foster care to independence. Consider whether concerted efforts were made to provide the child with services to adequately prepare the child for independent living when the child leaves foster care, such as post-high school planning, life skills classes, employment training, financial planning skills training, and transitional services.</li>" +
                        "<li>Examples of services that are assessed under this item include child care services that are not required for the child’s safety (those services would be covered under item 2), mentoring programs that are not related to the child’s education, recreational services, teen parenting education, preparation for adoption and other permanency goals, services that address family relationships that are not mental health in nature (for example, services to assist children in reestablishing or maintaining family ties), and services to assist the child that are recommended by a therapist or other provider but are not mental health-related (such as enrollment in an activity to assist with social skills or to boost self-esteem).</li>" +
                        "</ul></div>"
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 0 0 20',
            cls: 'panel-background-color',
            html: '<strong>A2.</strong> During the period under review, were appropriate services provided to meet the children’s identified needs?'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '0 0 20 40',
            itemId: 'question12A2',
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'question12A2Yes',
                    inputValue: 1,
                    bind: '{isAppropriateServicesProvided}',
                    name: 'IsAppropriateServicesProvided'
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    itemId: 'question12A2No',
                    inputValue: 2,
                    bind: '{isAppropriateServicesProvided}',
                    name: 'IsAppropriateServicesProvided'
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>NA</b>',
                    itemId: 'question12A2NA',
                    inputValue: 3,
                    bind: '{isAppropriateServicesProvided}',
                    name: 'IsAppropriateServicesProvided'
                }
            ]

        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: 'If No, explain any concerns in the narrative field below.'
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '10 10 20 20',
            itemId: 'item12A2AppropriateServicesProvidedExplained',
            items: [
                {
                    xtype: 'textarea',
                    itemId: 'serviceConcerns',
                    bind: '{appropriateServicesProvidedExplained}',
                    enableKeyEvents: true,
                    disabled: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem12A2AppropriateServicesProvidedExplained',
                    itemName: 'item12A'
                }
            ]
        }
    ]
});
//
// Item 12B
//
Ext.define('app.CaseReview.view.wellbeing.Item12B', {
    extend: 'Ext.container.Container',
    alias: 'widget.item12B',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'subItem12B',
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'component',
            itemId: 'item12B',
            border: false,
            margin: '20 0 0 20',
            html: '<strong>Sub-Item 12B:</strong> Needs Assessment and Services to Parents',
            cls: 'outcome-item-header'
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Sub-Item 12B Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing12BDef'
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            itemId: 'item12BPreApplicableCases',
            border: false,
            layout: 'hbox',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '20 0 0 20',
                    cls: 'panel-background-color',
                    html: '<strong>Sub-Item 12B Applicable Cases:</strong>'
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem12BPreApplicableCases',
                    itemName: 'item12B'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: "<ul class='text-justify'><li>Because multiple case participants can be assessed in these questions, consider applicability for all appropriate case participants before determining that the rating should be Not Applicable.</li>" +
                '<li>Questions in sub-item B for either parent should be answered Not Applicable if any of the following applies to all parents being assessed as Mother or Father in this sub-item (check Yes for any that apply for all parents being assessed as Mother or Father and No for any that do not apply to all parents being assessed as Mother or Father):</li></ul>'
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 0 30',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 20',
                    cls: 'panel-background-color',
                    html: '<ul><li>Parental rights remained terminated during the entire period under review</li></ul>'
                },
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 0 100',
                    inputField: 'CodeDescriptionID',
                    codeDescValue: 68,
                    itemId: 'item12BQuestion1',
                    defaults: {
                        bind: '{answerCode68}'
                    },
                    items: [
                        {
                            itemId: 'item12BApplicability1Yes',
                            inputValue: 1,
                            name: 'item12BApplicability1',
                            boxLabel: '<b>Yes</b>'
                        },
                        {
                            margin: '0 0 0 10',
                            itemId: 'item12BApplicability1No',
                            inputValue: 2,
                            name: 'item12BApplicability1',
                            boxLabel: '<b>No</b>'
                        }
                    ]
                },
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 20',
                    cls: 'panel-background-color',
                    html: '<ul><li>Parent’s whereabouts were not known during the entire period under review despite agency efforts to locate the parent </li></ul>'
                },
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 0 100',
                    inputField: 'CodeDescriptionID',
                    codeDescValue: 69,
                    itemId: 'item12BQuestion2',
                    defaults: {
                        bind: '{answerCode69}'
                    },
                    items: [
                        {
                            itemId: 'item12BApplicability2Yes',
                            inputValue: 1,
                            name: 'item12BApplicability2',
                            boxLabel: '<b>Yes</b>'
                        },
                        {
                            margin: '0 0 0 10',
                            itemId: 'item12BApplicability2No',
                            inputValue: 2,
                            name: 'item12BApplicability2',
                            boxLabel: '<b>No</b>'
                        }
                    ]
                },
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 20',
                    cls: 'panel-background-color',
                    html: '<ul><li>Parent was deceased during the entire period under review </li></ul>'
                },
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 0 100',
                    inputField: 'CodeDescriptionID',
                    codeDescValue: 70,
                    itemId: 'item12BQuestion3',
                    defaults: {
                        bind: '{answerCode70}'
                    },
                    items: [
                        {
                            itemId: 'item12BApplicability3Yes',
                            inputValue: 1,
                            name: 'item12BApplicability3',
                            boxLabel: '<b>Yes</b>'
                        },
                        {
                            margin: '0 0 0 10',
                            itemId: 'item12BApplicability3No',
                            inputValue: 2,
                            name: 'item12BApplicability3',
                            boxLabel: '<b>No</b>'
                        }
                    ]
                },
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 20',
                    cls: 'panel-background-color',
                    html: '<ul><li>During the entire period under review it was documented in the case file that it was not in the child’s best interests to involve the parent in case planning</li></ul>'
                },
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 0 100',
                    inputField: 'CodeDescriptionID',
                    codeDescValue: 71,
                    itemId: 'item12BQuestion4',
                    defaults: {
                        bind: '{answerCode71}'
                    },
                    items: [
                        {
                            itemId: 'item12BApplicability4Yes',
                            inputValue: 1,
                            name: 'item12BApplicability4',
                            boxLabel: '<b>Yes</b>'
                        },
                        {
                            margin: '0 0 0 10',
                            itemId: 'item12BApplicability4No',
                            inputValue: 2,
                            name: 'item12BApplicability4',
                            boxLabel: '<b>No</b>'
                        }
                    ]
                },
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 20',
                    cls: 'panel-background-color',
                    html: '<ul><li>During the entire period under review the parent has indicated he/she does not want to be involved in the child’s life and this was documented in the case file</li></ul>'
                },
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 0 100',
                    inputField: 'CodeDescriptionID',
                    codeDescValue: 72,
                    itemId: 'item12BQuestion5',
                    defaults: {
                        bind: '{answerCode72}'
                    },
                    items: [
                        {
                            itemId: 'item12BApplicability5Yes',
                            inputValue: 1,
                            name: 'item12BApplicability5',
                            boxLabel: '<b>Yes</b>'
                        },
                        {
                            margin: '0 0 0 10',
                            itemId: 'item12BApplicability5No',
                            inputValue: 2,
                            name: 'item12BApplicability5',
                            boxLabel: '<b>No</b>'
                        }
                    ]
                }
            ]
        },
        {
            xtype: 'validationMessage',
            itemId: 'msgItem12BApplicableCases',
            itemName: 'item12B'
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: 'Select the appropriate response. If the response is No, the case will be rated as Not Applicable in the ratings section for this sub-item.'
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: 'Is sub-item 12B applicable for Mother?'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '0 0 20 40',
            itemId: 'item12BApplicableMother',
            defaults: {
                bind: '{isNeedsServicesApplicableForMother}'
            },
            items: [
                {
                    xtype: 'radio',
                    itemId: 'item12BApplicableMotherYes',
                    boxLabel: '<b>Yes</b>',
                    inputValue: 1,
                    name: 'item12BApplicableMother'
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    itemId: 'item12BApplicableMotherNo',
                    boxLabel: '<b>No</b>',
                    inputValue: 2,
                    name: 'item12BApplicableMother'
                }
            ]
        },
        {
            xtype: 'validationMessage',
            itemId: 'msgItem12BApplicableMother',
            itemName: 'item12B'
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: 'Is sub-item 12B applicable for Father?'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '0 0 20 40',
            itemId: 'item12BApplicableFather',
            defaults: {
                bind: '{isNeedsServicesApplicableForFather}'
            },
            items: [
                {
                    xtype: 'radio',
                    itemId: 'item12BApplicableFatherYes',
                    boxLabel: '<b>Yes</b>',
                    inputValue: 1,
                    name: 'item12BApplicableFather'
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    itemId: 'item12BApplicableFatherNo',
                    boxLabel: '<b>No</b>',
                    inputValue: 2,
                    name: 'item12BApplicableFather'
                }
            ]
        },
        {
            xtype: 'validationMessage',
            itemId: 'msgItem12BApplicableFather',
            itemName: 'item12B'
        },
        {
            xtype: 'itemApplicable',
            store: 'CR_Outcome_CollectionStore',
            bodyCls: 'panel-background-color',
            border: false,
            OutcomeCode: 5,
            ItemCode: 15,
            items: [

                 {
                     xtype: 'component',
                     border: false,
                     margin: '10 0 0 20',
                     cls: 'panel-background-color',
                     html: 'Indicate the case participants who are included in this sub-item as Mother and Father:'
                 },
                {
                    xtype: 'container',
                    cls: 'panel-background-color',
                    border: false,
                    layout: 'vbox',
                    margin: '0 0 20 40',
                    itemId: 'item12BParentCaseParticipant',
                    items: [
                        {
                            xtype: 'component',
                            border: false,
                            margin: '10 0 0 10',
                            bodyCls: 'panel-background-color',
                            html: 'Mother:'
                        },
                        {
                            xtype: 'checkboxgroup',
                            columns: 1,
                            vertical: true,
                            itemId: 'item12BParticipantCheckboxGroupMother',
                            listeners: {
                                'afterrender': function () {
                                    var checkboxgroup = this;
                                    var checkboxgroupStore = GetItemParticipant(1);
                                    var checkbox = null;
                                    var participantId, participantName;
                                    var dataParms = { itemCode: 15, outcomeCode: 5 };

                                    for (var iCheckboxCount = 0; iCheckboxCount < checkboxgroupStore.count() ; iCheckboxCount++) {

                                        participantName = checkboxgroupStore.getAt(iCheckboxCount).data.Name;
                                        participantId = participants[participantName].ParticipantID;

                                        dataParms['participantId'] = participantId;
                                        dataParms['participantName'] = participantName;
                                        dataParms['codeDescriptionId'] = 269;

                                        checkbox = new Ext.form.Checkbox({
                                            boxLabel: checkboxgroupStore.getAt(iCheckboxCount).data.Name,
                                            inputValue: participantId,
                                            itemId: 'checkbox12BMother' + participantId,
                                            checked: isItemParticipantSelected(dataParms),
                                            listeners: {
                                                'change': function (cmp, newValue, oldValue, eOpts) {

                                                    var newKeys = getObjectKeys(cmp);

                                                    if (newKeys.length > 0) {

                                                        var parms = { currentVal: newValue };
                                                        var selection = (newValue) ? cmp.inputValue : 0;

                                                        var fields = [];
                                                        var field = { 'ParticipantID': selection };
                                                        fields.push(field);

                                                        field = { 'CodeDescriptionID': 269 };
                                                        fields.push(field);

                                                        field = { 'ItemParticipantID': getItemParticipantId(selection) };
                                                        fields.push(field);

                                                        field = { 'DataState': 0 };
                                                        fields.push(field);

                                                        parms['storeId'] = 'CR_ItemParticipant_CollectionStore';
                                                        parms['fields'] = fields;

                                                        parms = getStatusParms(parms, 'wellbeingItem12BRating');
                                                        parms['runValidations'] = true;
                                                        parms['dataChanged'] = true;

                                                        initValidations('Item12');

                                                        runWellbeingRules(getAppController(), 'item12BParticipantCheckboxGroupMother', parms);
                                                    }
                                                }
                                            }
                                        });
                                        checkboxgroup.items.add(checkbox);
                                    }
                                }
                            }
                        },
                        {
                            xtype: 'validationMessage',
                            itemId: 'msgItem12BMotherCaseParticipant',
                            itemName: 'item12B'
                        },
                        {
                            xtype: 'component',
                            border: false,
                            margin: '10 0 0 10',
                            bodyCls: 'panel-background-color',
                            html: 'Father:'
                        },
                        {
                            xtype: 'checkboxgroup',
                            columns: 1,
                            vertical: true,
                            itemId: 'item12BParticipantCheckboxGroupFather',
                            listeners: {
                                'afterrender': function () {

                                    var checkboxgroup = this;
                                    var checkboxgroupStore = GetItemParticipant(2);
                                    var checkbox = null;
                                    var participantId, participantName;
                                    var dataParms = { itemCode: 15, outcomeCode: 5 };

                                    for (var iCheckboxCount = 0; iCheckboxCount < checkboxgroupStore.count() ; iCheckboxCount++) {

                                        participantName = checkboxgroupStore.getAt(iCheckboxCount).data.Name;
                                        participantId = participants[participantName].ParticipantID;

                                        dataParms['participantId'] = participantId;
                                        dataParms['participantName'] = participantName;
                                        dataParms['codeDescriptionId'] = 270;

                                        checkbox = new Ext.form.Checkbox({
                                            boxLabel: checkboxgroupStore.getAt(iCheckboxCount).data.Name,
                                            inputValue: participantId,
                                            itemId: 'checkbox12BFather' + participantId,
                                            checked: isItemParticipantSelected(dataParms),
                                            width: 200,
                                            listeners: {
                                                'change': function (cmp, newValue, oldValue, eOpts) {

                                                    var newKeys = getObjectKeys(cmp);

                                                    if (newKeys.length > 0) {

                                                        var parms = { currentVal: newValue };
                                                        var selection = (newValue) ? cmp.inputValue : 0;

                                                        var fields = [];
                                                        var field = { 'ParticipantID': selection };
                                                        fields.push(field);

                                                        field = { 'CodeDescriptionID': 270 };
                                                        fields.push(field);

                                                        field = { 'ItemParticipantID': getItemParticipantId(selection) };
                                                        fields.push(field);

                                                        field = { 'DataState': 0 };
                                                        fields.push(field);

                                                        parms['storeId'] = 'CR_ItemParticipant_CollectionStore';
                                                        parms['fields'] = fields;

                                                        parms = getStatusParms(parms, 'wellbeingItem12BRating');
                                                        parms['runValidations'] = true;
                                                        parms['dataChanged'] = true;

                                                        initValidations('Item12');

                                                        runWellbeingRules(getAppController(), 'item12BParticipantCheckboxGroupFather', parms);
                                                    }
                                                }
                                            }
                                        });
                                        checkboxgroup.items.add(checkbox);
                                    }
                                }
                            }
                        },
                        {
                            xtype: 'validationMessage',
                            itemId: 'msgItem12BFatherCaseParticipant',
                            itemName: 'item12B'
                        }
                    ]
                },
                {
                    xtype: 'container',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'vbox',
                    margin: '0 0 20 20',
                    items: [
                        {
                            xtype: 'component',
                            border: false,
                            margin: '10 0 0 0',
                            bodyCls: 'panel-background-color',
                            html: 'Optional: Provide comments in the narrative field below.'
                        },
                        {
                            xtype: 'textarea',
                            itemId: 'item12BApplicabilityComments',
                            bind: '{item12BComments}',
                            enableKeyEvents: true,
                            width: '75%',
                            maxlength: 4100,
                            enforceMaxLength: true,
                            height: 150
                        }
                    ]
                }
            ]
        }
    ]
});
//
// Item 12B Questions
//
Ext.define('app.CaseReview.view.wellbeing.Question12B1', {
    extend: 'Ext.container.Container',
    alias: 'widget.question12B1',
    cls: 'panel-background-color',
    border: true,
    itemId: 'item12B1',
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 12B1 Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing12B1Ins'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: "<strong>B1.  During the period under review, did the agency conduct a formal or informal initial and/or ongoing comprehensive assessment that accurately assessed the mother’s needs?</strong>"
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: true,
            layout: 'vbox',
            margin: '10 10 20 40',
            items: [
                {
                    xtype: 'radiogroup',
                    itemId: 'item12B1Answers',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 20 0',
                    items: [
                        {
                            xtype: 'radio',
                            boxLabel: '<b>Yes</b>',
                            itemId: 'question12B1Yes',
                            inputValue: 1,
                            bind: '{isComprehensiveAssessementForMotherConducted}',
                            name: 'IsComprehensiveAssessementMotherConducted'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>No</b>',
                            itemId: 'question12B1No',
                            inputValue: 2,
                            bind: '{isComprehensiveAssessementForMotherConducted}',
                            name: 'IsComprehensiveAssessementMotherConducted'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>NA</b>',
                            itemId: 'question12B1NA',
                            inputValue: 3,
                            bind: '{isComprehensiveAssessementForMotherConducted}',
                            name: 'IsComprehensiveAssessementMotherConducted'
                        },
                        {
                            xtype: 'validationMessage',
                            itemId: 'msgItem12B1Answers',
                            itemName: 'item12B'
                        }
                    ]
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'vbox',
            margin: '-30 0 20 40',
            itemId: 'item12BQuestion1Narrative',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 0',
                    cls: 'panel-background-color',
                    html: 'If No, explain any concerns in the narrative field below.'
                },
                {
                    xtype: 'textarea',
                    itemId: 'item12B1Concerns',
                    bind: '{comprehensiveAssessementForMotherExplained}',
                    enableKeyEvents: true,
                    disabled: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem12BQuestion1Narrative',
                    itemName: 'item12B'
                }
            ]
        }
    ]
});
Ext.define('app.CaseReview.view.wellbeing.Question12B2', {
    extend: 'Ext.container.Container',
    alias: 'widget.question12B2',
    cls: 'panel-background-color',
    border: true,
    itemId: 'item12B2',
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 12B2 Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing12B2Ins'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: "<strong>B2.  During the period under review, did the agency conduct a formal or informal initial and/or ongoing comprehensive assessment that accurately assessed the father’s needs?</strong>"
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: true,
            layout: 'vbox',
            margin: '10 10 20 40',
            items: [
                {
                    xtype: 'radiogroup',
                    itemId: 'item12B2Answers',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 20 0',
                    items: [
                        {
                            xtype: 'radio',
                            boxLabel: '<b>Yes</b>',
                            itemId: 'question12B2Yes',
                            inputValue: 1,
                            bind: '{isComprehensiveAssessementForFatherConducted}',
                            name: 'IsComprehensiveAssessementFatherConducted'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>No</b>',
                            itemId: 'question12B2No',
                            inputValue: 2,
                            bind: '{isComprehensiveAssessementForFatherConducted}',
                            name: 'IsComprehensiveAssessementFatherConducted'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>NA</b>',
                            itemId: 'question12B2NA',
                            inputValue: 3,
                            bind: '{isComprehensiveAssessementForFatherConducted}',
                            name: 'IsComprehensiveAssessementFatherConducted'
                        },
                        {
                            xtype: 'validationMessage',
                            itemId: 'msgItem12B2Answers',
                            itemName: 'item12B'
                        }
                    ]
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'vbox',
            margin: '-30 0 20 40',
            itemId: 'item12BQuestion2Narrative',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 0',
                    cls: 'panel-background-color',
                    html: 'If No, explain any concerns in the narrative field below.'
                },
                {
                    xtype: 'textarea',
                    itemId: 'item12B2Concerns',
                    bind: '{comprehensiveAssessementforFatherConductedExplained}',
                    enableKeyEvents: true,
                    disabled: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem12BQuestion2Narrative',
                    itemName: 'item12B'
                }
            ]
        }
    ]
});
Ext.define('app.CaseReview.view.wellbeing.Question12B3', {
    extend: 'Ext.container.Container',
    alias: 'widget.question12B3',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'item12B3',
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 12B3 Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing12B3Ins'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: "<strong>B3.  During the period under review, did the agency provide appropriate services to the mother to meet identified needs?</strong>"
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: true,
            layout: 'vbox',
            margin: '10 10 20 40',
            items: [
                {
                    xtype: 'radiogroup',
                    itemId: 'item12B3Answers',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 20 0',
                    defaults: {
                        bind: '{isAppropriateServicesForMotherProvided}'
                    },
                    items: [
                        {
                            xtype: 'radio',
                            boxLabel: '<b>Yes</b>',
                            itemId: 'question12B3Yes',
                            inputValue: 1,
                            name: 'IsAppropriateServicesMotherProvided'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>No</b>',
                            itemId: 'question12B3No',
                            inputValue: 2,
                            name: 'IsAppropriateServicesMotherProvided'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>NA</b>',
                            itemId: 'question12B3NA',
                            inputValue: 3,
                            name: 'IsAppropriateServicesMotherProvided'
                        }
                    ]
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'vbox',
            margin: '-30 0 20 40',
            itemId: 'item12BQuestion3Narrative',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 0',
                    cls: 'panel-background-color',
                    html: 'If No, explain any concerns in the narrative field below.'
                },
                {
                    xtype: 'textarea',
                    itemId: 'item12B3Concerns',
                    bind: '{appropriateServicesForMotherExplained}',
                    enableKeyEvents: true,
                    disabled: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem12BQuestion3Narrative',
                    itemName: 'item12B'
                }
            ]
        }
    ]
});
Ext.define('app.CaseReview.view.wellbeing.Question12B4', {
    extend: 'Ext.container.Container',
    alias: 'widget.question12B4',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'item12B4',
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 12B4 Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing12B4Ins'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: "<strong>B4.  During the period under review, did the agency provide appropriate services to the father to address identified needs?</strong>"
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: true,
            layout: 'vbox',
            margin: '10 10 20 40',
            items: [
                {
                    xtype: 'radiogroup',
                    itemId: 'item12B4Answers',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 20 0',
                    defaults: {
                        bind: '{isAppropriateServicesForFatherProvided}'
                    },
                    items: [
                        {
                            xtype: 'radio',
                            boxLabel: '<b>Yes</b>',
                            itemId: 'question12B4Yes',
                            inputValue: 1,
                            name: 'IsAppropriateServicesFatherProvided'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>No</b>',
                            itemId: 'question12B4No',
                            inputValue: 2,
                            name: 'IsAppropriateServicesFatherProvided'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>NA</b>',
                            itemId: 'question12B4NA',
                            inputValue: 3,
                            name: 'IsAppropriateServicesFatherProvided'
                        }
                    ]
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'vbox',
            margin: '-30 0 20 40',
            itemId: 'item12BQuestion4Narrative',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 0',
                    cls: 'panel-background-color',
                    html: 'If No, explain any concerns in the narrative field below.'
                },
                {
                    xtype: 'textarea',
                    itemId: 'item12B4Concerns',
                    bind: '{appropriateServicesForFatherExplained}',
                    enableKeyEvents: true,
                    disabled: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem12BQuestion4Narrative',
                    itemName: 'item12B'
                }
            ]
        }
    ]
});
//
// Item 12C
//
Ext.define('app.CaseReview.view.wellbeing.Item12C', {
    extend: 'Ext.container.Container',
    alias: 'widget.item12C',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'item12CPanel',
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'component',
            border: false,
            margin: '20 0 0 20',
            html: '<strong>Sub-Item 12C:</strong> Needs Assessment and Services to Foster Parents',
            cls: 'outcome-item-header'
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Sub-Item 12C Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    html: "<div class='html-content-item-margins text-justify'>" +
                        "<ul><li>Foster parents are defined as related or non-related caregivers who have been given responsibility for care of the child by the agency while the child is under the placement and care responsibility and supervision of the agency. This includes pre-adoptive parents if the adoption has not been finalized.</li></ul>"
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 0 0 20',
            cls: 'panel-background-color',
            html: '<strong>Sub-Item 12C Applicable Cases:</strong>'
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: '<ul><li>In-home cases are not applicable for an assessment of this sub-item.</li>' +
                '<li>All foster care cases are applicable for assessment of this sub-item unless, during the entire period under review, the child was in out-of-home care in a residential facility or similar placement, but does not have foster parents.</li></ul>'
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'outcome-item-header',
            html: '<strong>Is this case applicable?</strong>'
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: 'Select the appropriate response. If the response is No, the case will be rated as Not Applicable in the ratings section for this sub-item.'
        },
        {
            xtype: 'itemApplicable',
            store: 'CR_Outcome_CollectionStore',
            bodyCls: 'panel-background-color',
            border: false,
            OutcomeCode: 5,
            ItemCode: 16,
            items: [
              {
                  xtype: 'radiogroup',
                  bodyCls: 'panel-background-color',
                  border: false,
                  layout: 'hbox',
                  itemId: 'item12C',
                  defaults: {
                      bind: '{item12CApplicable}',                                  
                      publishes: {
                          inputValue: true,
                          value: true,
                          itemId: true
                      }
                  },                              
                  margin: '0 0 20 40',
                  items: [
                      {
                          xtype: 'radio',
                          itemId: 'item12CYes',
                          boxLabel: '<b>Yes</b>',
                          inputValue: 1,
                          reference: 'item12CApplicable',
                          publishes: {
                              inputValue: true
                          },
                          bind: '{item12CApplicable}'
                      },
                      {
                          margin: '0 0 0 10',
                          xtype: 'radio',
                          itemId: 'item12CNo',
                          boxLabel: '<b>No</b>',
                          inputValue: 2,
                          reference: 'item12CApplicable',
                          publishes: {
                              inputValue: true
                          },
                          bind: '{item12CApplicable}'
                      }                                  
                  ]
              },
              {
                  xtype: 'validationMessage',
                  itemId: 'msgItem12C',
                  itemName: 'item12C'
              },
              {
                  xtype: 'container',
                  cls: 'panel-background-color',
                  border: false,
                  layout: 'vbox',
                  margin: '0 0 20 20',
                  items: [
                      {
                          xtype: 'component',
                          border: false,
                          margin: '10 0 0 0',
                          bodyCls: 'panel-background-color',
                          html: 'Optional: Provide comments in the narrative field below.'
                      },
                      {
                          xtype: 'textarea',
                          itemId: 'item12CComments',
                          bind: '{item12CComments}',
                          enableKeyEvents: true,
                          width: '75%',
                          maxlength: 4100,
                          enforceMaxLength: true,
                          height:150
                                      
                      }
                  ]
              }
            ]
        }                  
    ]
});
//
// Item 12C Questions
//
Ext.define('app.CaseReview.view.wellbeing.Question12C1', {
    extend: 'Ext.container.Container',
    alias: 'widget.question12C1',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    itemId: 'item12C1',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 12C1 Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing12C1Ins'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Sub-Item 12C Tip: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing12C1Tip'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: "<strong>C1.  During the period under review, did the agency adequately assess the needs of the foster or pre-adoptive parents on an ongoing basis (with respect to services they need to in order to provide appropriate care and supervision to ensure the safety and well-being of the children in their care)?</strong>"
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: true,
            layout: 'vbox',
            margin: '10 10 20 40',
            items: [
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 20 0',
                    itemId: 'question12C1',
                    defaults: {
                        bind: '{isNeedsOfFosterParentsAdequatelyAssessed}'
                    },
                    items: [
                        {
                            xtype: 'radio',
                            boxLabel: '<b>Yes</b>',
                            itemId: 'question12C1Yes',
                            inputValue: 1,
                            name: 'IsNeedsOfFosterParentsAssessed'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>No</b>',
                            itemId: 'question12C1No',
                            inputValue: 2,
                            name: 'IsNeedsOfFosterParentsAssessed'
                        }
                    ]
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '-10 0 0 40',
            cls: 'panel-background-color',
            html: 'If No, explain any concerns in the narrative field below.'
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '10 0 20 40',
            itemId: 'item12CQuestion1Narrative',
            items: [
                {
                    xtype: 'textarea',
                    itemId: 'item12C1Concerns',
                    bind: '{needsOfFosterParentsAdequatelyAssessedExplained}',
                    enableKeyEvents: true,
                    disabled: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem12CQuestion1Narrative',
                    itemName: 'item12C'
                }
            ]
        }
    ]
});
Ext.define('app.CaseReview.view.wellbeing.Question12C2', {
    extend: 'Ext.container.Container',
    alias: 'widget.question12C2',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    itemId: 'item12C2',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 12C2 Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing12C2Ins'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Sub-Item 12C Tip: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing12C2Tip'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: "<strong>C2.  During the period under review, were the foster or pre-adoptive parents provided with appropriate services to address identified needs that pertained to their capacity to provide appropriate care and supervision of the children in their care?</strong>"
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: true,
            layout: 'vbox',
            margin: '10 10 20 40',
            items: [
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 20 0',
                    itemId: 'question12C2',
                    defaults: {
                        bind: '{isFosterParentsProvidedAppropriateServices}'
                    },
                    items: [
                        {
                            xtype: 'radio',
                            boxLabel: '<b>Yes</b>',
                            itemId: 'question12C2Yes',
                            inputValue: 1,
                            name: 'IsFosterParentsProvidedServices'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>No</b>',
                            itemId: 'question12C2No',
                            inputValue: 2,
                            name: 'IsFosterParentsProvidedServices'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>NA</b>',
                            itemId: 'question12C2NA',
                            inputValue: 3,
                            name: 'IsFosterParentsProvidedServices'
                        }
                    ]
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '-10 0 0 40',
            cls: 'panel-background-color',
            html: 'If No, explain any concerns in the narrative field below.'
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '10 0 20 40',
            itemId: 'item12CQuestion2Narrative',
            items: [
                {
                    xtype: 'textarea',
                    itemId: 'item12C2Concerns',
                    disabled: true,
                    bind: '{fosterParentsProvidedAppropriateServicesExplained}',
                    enableKeyEvents: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem12CQuestion2Narrative',
                    itemName: 'item12C'
                }
            ]
        }
    ]
});
//
// Item 13
//
Ext.define('app.CaseReview.view.wellbeing.Item13', {
    extend: 'Ext.container.Container',
    alias: 'widget.item13',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'item13Panel',
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'component',
            itemId: 'item13',
            border: false,
            margin: '20 0 0 20',
            html: '<strong>Item 13:</strong> Child and Family Involvement in Case Planning',
            cls: 'outcome-item-header'
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Purpose of Assessment: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing13Purpose'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Item 13 Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing13Def'
                }
            ]
        },
        {
            xtype: 'container',
            itemId: 'item13ApplicableCases',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 0 20',
            items: [
                {
                    xtype: 'container',
                    cls: 'panel-background-color',
                    itemId: 'item13PreApplicability',
                    border: false,
                    layout: 'hbox',
                    items: [
                        {
                            xtype: 'component',
                            border: false,
                            margin: '20 0 0 0',
                            cls: 'panel-background-color',
                            html: '<strong>Item 13 Applicable Cases:</strong>'
                        },
                        {
                            xtype: 'validationMessage',
                            itemId: 'msgItem13PreApplicability',
                            itemName: 'item13'
                        }
                    ]
                },
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 -10',
                    cls: 'panel-background-color',
                    html: '<ul><li>Because multiple case participants can be assessed in these questions, consider applicability for all appropriate case participants before determining that the rating should be Not Applicable. All cases are applicable for an assessment of this item except as determined below (check Yes for criteria that apply and No for those that do not).</li></ul>'
                },
                {
                    xtype: 'container',
                    cls: 'panel-background-color',
                    border: false,
                    margin: '0 0 0 0',
                    items: [
                        {
                            xtype: 'component',
                            border: false,
                            margin: '0 0 0 10',
                            cls: 'panel-background-color',
                            html: '<ul><li>Cases involving children for whom participating in planning is not developmentally appropriate.</li></ul>'
                        },
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 0 100',
                            inputField: 'CodeDescriptionID',
                            codeDescValue: 73,
                            itemId: 'item13Question1',
                            defaults: {
                                bind: '{answerCode73}'
                            },
                            items: [
                                {
                                    itemId: 'item13Applicability1Yes',
                                    inputValue: 1,
                                    name: 'item13Applicability1',
                                    boxLabel: '<b>Yes</b>'
                                },
                                {
                                    margin: '0 0 0 10',
                                    itemId: 'item13Applicability1No',
                                    inputValue: 2,
                                    name: 'item13Applicability1',
                                    boxLabel: '<b>No</b>'
                                }
                            ]
                        },
                        {
                            xtype: 'component',
                            border: false,
                            margin: '10 0 0 30',
                            cls: 'panel-background-color',
                            html: 'AND:'
                        },
                        {
                            xtype: 'component',
                            border: false,
                            margin: '0 0 0 10',
                            cls: 'panel-background-color',
                            html: '<ul><li>Cases in which all parents being assessed as Mother or Father meet any of these criteria:</li></ul>'
                        },
                        {
                            xtype: 'component',
                            border: false,
                            margin: '0 0 0 30',
                            cls: 'panel-background-color',
                            html: '<ul><li>Parental rights remained terminated during the entire period under review.</li></ul>'
                        },
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 0 100',
                            inputField: 'CodeDescriptionID',
                            codeDescValue: 74,
                            itemId: 'item13Question2',
                            defaults: {
                                bind: '{answerCode74}'
                            },
                            items: [
                                {
                                    itemId: 'item13Applicability2Yes',
                                    inputValue: 1,
                                    name: 'item13Applicability2',
                                    boxLabel: '<b>Yes</b>'
                                },
                                {
                                    margin: '0 0 0 10',
                                    itemId: 'item13Applicability2No',
                                    inputValue: 2,
                                    name: 'item13Applicability2',
                                    boxLabel: '<b>No</b>'
                                }
                            ]
                        },
                        {
                            xtype: 'component',
                            border: false,
                            margin: '0 0 0 30',
                            cls: 'panel-background-color',
                            html: '<ul><li>Parent’s whereabouts were not known during the entire period under review despite agency efforts to locate the parent.</li></ul>'
                        },
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 0 100',
                            inputField: 'CodeDescriptionID',
                            codeDescValue: 75,
                            itemId: 'item13Question3',
                            defaults: {
                                bind: '{answerCode75}'
                            },
                            items: [
                                {
                                    itemId: 'item13Applicability3Yes',
                                    inputValue: 1,
                                    name: 'item13Applicability3',
                                    boxLabel: '<b>Yes</b>'
                                },
                                {
                                    margin: '0 0 0 10',
                                    itemId: 'item13Applicability3No',
                                    inputValue: 2,
                                    name: 'item13Applicability3',
                                    boxLabel: '<b>No</b>'
                                }
                            ]
                        },
                        {
                            xtype: 'component',
                            border: false,
                            margin: '0 0 0 30',
                            cls: 'panel-background-color',
                            html: '<ul><li>The Reviewer has determined that Item 12B is rated as an Area Needing Improvement due to lack of concerted efforts to find applicable parents.</li></ul>'
                        },
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 0 100',
                            inputField: 'CodeDescriptionID',
                            codeDescValue: 292,
                            itemId: 'item13Question4',
                            defaults: {
                                bind: '{answerCode292}'
                            },
                            items: [
                                {
                                    itemId: 'item13Applicability4Yes',
                                    inputValue: 1,
                                    name: 'item13Applicability4',
                                    boxLabel: '<b>Yes</b>'
                                },
                                {
                                    margin: '0 0 0 10',
                                    itemId: 'item13Applicability4No',
                                    inputValue: 2,
                                    name: 'item13Applicability4',
                                    boxLabel: '<b>No</b>'
                                }
                            ]
                        },
                        {
                            xtype: 'component',
                            border: false,
                            margin: '0 0 0 30',
                            cls: 'panel-background-color',
                            html: '<ul><li>Parent was deceased during the entire period under review.</li></ul>'
                        },
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 0 100',
                            inputField: 'CodeDescriptionID',
                            codeDescValue: 76,
                            itemId: 'item13Question5',
                            defaults: {
                                bind: '{answerCode76}'
                            },
                            items: [
                                {
                                    itemId: 'item13Applicability5Yes',
                                    inputValue: 1,
                                    name: 'item13Applicability5',
                                    boxLabel: '<b>Yes</b>'
                                },
                                {
                                    margin: '0 0 0 10',
                                    itemId: 'item13Applicability5No',
                                    inputValue: 2,
                                    name: 'item13Applicability5',
                                    boxLabel: '<b>No</b>'
                                }
                            ]
                        },
                        {
                            xtype: 'component',
                            border: false,
                            margin: '0 0 0 30',
                            cls: 'panel-background-color',
                            html: '<ul><li>During the entire period under review it was documented in the case file that it was not in the child’s best interests to involve the parent in case planning.</li></ul>'
                        },
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 0 100',
                            inputField: 'CodeDescriptionID',
                            codeDescValue: 77,
                            itemId: 'item13Question6',
                            defaults: {
                                bind: '{answerCode77}'
                            },
                            items: [
                                {
                                    itemId: 'item13Applicability6Yes',
                                    inputValue: 1,
                                    name: 'item13Applicability6',
                                    boxLabel: '<b>Yes</b>'
                                },
                                {
                                    margin: '0 0 0 10',
                                    itemId: 'item13Applicability6No',
                                    inputValue: 2,
                                    name: 'item13Applicability6',
                                    boxLabel: '<b>No</b>'
                                }
                            ]
                        },
                        {
                            xtype: 'component',
                            border: false,
                            margin: '0 0 0 30',
                            cls: 'panel-background-color',
                            html: '<ul><li>During the entire period under review the parent has indicated he/she does not want to be involved in the child’s life and this was documented in the case file.</li></ul>'
                        },
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 0 100',
                            inputField: 'CodeDescriptionID',
                            codeDescValue: 78,
                            itemId: 'item13Question7',
                            defaults: {
                                bind: '{answerCode78}'
                            },
                            items: [
                                {
                                    itemId: 'item13Applicability7Yes',
                                    inputValue: 1,
                                    name: 'item13Applicability7',
                                    boxLabel: '<b>Yes</b>'
                                },
                                {
                                    margin: '0 0 0 10',
                                    itemId: 'item13Applicability7No',
                                    inputValue: 2,
                                    name: 'item13Applicability7',
                                    boxLabel: '<b>No</b>'
                                }
                            ]
                        },
                        {
                            xtype: 'component',
                            border: false,
                            margin: '0 0 0 10',
                            cls: 'panel-background-color',
                            html: '<ul><li>In-home services cases are applicable even in states that do not require a formal case plan to be developed for in-home services cases. Therefore, the case is applicable even if there is no state requirement for a case plan and there is no case plan in the file.</li></ul>'
                        }
                    ]
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 10 10',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 10',
                    cls: 'outcome-item-header',
                    html: '<strong>Is this case applicable?</strong>'
                },
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 10',
                    cls: 'panel-background-color',
                    html: 'Select the appropriate response. If the response is No, the case will be rated as Not Applicable in the ratings section for this sub-item.'
                },
                  {
                      xtype: 'itemApplicable',
                      store: 'CR_Outcome_CollectionStore',
                      bodyCls: 'panel-background-color',
                      border: false,
                      OutcomeCode: 5,
                      ItemCode: 17,
                      items: [
                          {
                              xtype: 'container',
                              itemId: 'applicabilityQuestion13',
                              cls: 'panel-background-color',
                              border: false,
                              layout: 'hbox',
                              margin: '0 0 20 40',
                              items: [
                                  {
                                      xtype: 'radiogroup',
                                      bodyCls: 'panel-background-color',
                                      border: false,
                                      margin: '0 0 20 0',
                                      itemId: 'Question13Applicable',
                                      defaults: {
                                          bind: '{item13Applicable}'
                                      },
                                      items: [
                                          {
                                              xtype: 'radio',
                                              itemId: 'applicabilityQuestion13Yes',
                                              boxLabel: '<b>Yes</b>',
                                              inputValue: 1,
                                              name: 'applicablityItem13'
                                          },
                                          {
                                              margin: '0 0 0 10',
                                              xtype: 'radio',
                                              boxLabel: '<b>No</b>',
                                              itemId: 'applicabilityQuestion13No',
                                              inputValue: 2,
                                              name: 'applicablityItem13'
                                          }
                                      ]
                                  },
                                  {
                                      xtype: 'validationMessage',
                                      itemId: 'msgApplicabilityQuestion13',
                                      itemName: 'item13'
                                  }
                              ]
                          },
                          {
                              xtype: 'container',
                              itemId: 'item13ChildParticipants',
                              items: [
                              {
                                  xtype: 'component',
                                  border: false,
                                  margin: '10 0 0 20',
                                  cls: 'panel-background-color',
                                  html: 'For in home services cases, indicate the name(s) of the child(ren) who were included in the assessment:'
                              },
                                {
                                    xtype: 'container',
                                    cls: 'panel-background-color',
                                    border: false,
                                    layout: 'vbox',
                                    margin: '0 0 20 40',
                                    items: [
                                        {
                                            xtype: 'checkboxgroup',
                                            columns: 1,
                                            vertical: true,
                                            itemId: 'item13AParticipantCheckboxGroupChildren',
                                            listeners: {
                                                'afterrender': function () {

                                                    var checkboxgroup = this;
                                                    var checkboxgroupStore = GetItemChildren();
                                                    var checkbox = null;
                                                    var childId;

                                                    for (var iCheckboxCount = 0; iCheckboxCount < checkboxgroupStore.count() ; iCheckboxCount++) {

                                                        childId = checkboxgroupStore.getAt(iCheckboxCount).data.ChildDemographicID;

                                                        checkbox = new Ext.form.Checkbox({
                                                            boxLabel: checkboxgroupStore.getAt(iCheckboxCount).data.Name + " " + checkboxgroupStore.getAt(iCheckboxCount).data.Age,
                                                            inputValue: checkboxgroupStore.getAt(iCheckboxCount).data.ChildDemographicID,
                                                            itemId: 'checkbox13Child' + childId,
                                                            checked: isParticipantSelected(childId),
                                                            width: 300
                                                        });
                                                        checkboxgroup.items.add(checkbox);
                                                    }
                                                }

                                            }

                                        }
                                    ]
                                }]
                          },
                          {
                              xtype: 'component',
                              border: false,
                              margin: '10 0 0 20',
                              cls: 'panel-background-color',
                              html: 'Indicate the case participants who are included in this item as Mother and Father:'
                          },
                          {
                              xtype: 'container',
                              cls: 'panel-background-color',
                              border: false,
                              layout: 'vbox',
                              margin: '0 0 20 40',
                              itemId: 'item13ParentCaseParticipant',
                              items: [
                                  {
                                      xtype: 'component',
                                      border: false,
                                      margin: '10 0 0 10',
                                      cls: 'panel-background-color',
                                      html: 'Mother:'
                                  },
                                  {
                                      xtype: 'checkboxgroup',
                                      columns: 1,
                                      vertical: true,
                                      itemId: 'item13ParticipantCheckboxGroupMother',
                                      listeners: {
                                          'afterrender': function () {

                                              var checkboxgroup = this;
                                              var checkboxgroupStore = GetItemParticipant(1);
                                              var checkbox = null;
                                              var participantId, participantName;
                                              var dataParms = { itemCode: 17, outcomeCode: 5 };

                                              for (var iCheckboxCount = 0; iCheckboxCount < checkboxgroupStore.count() ; iCheckboxCount++) {

                                                  participantName = checkboxgroupStore.getAt(iCheckboxCount).data.Name;
                                                  participantId = participants[participantName].ParticipantID;

                                                  dataParms['participantId'] = participantId;
                                                  dataParms['participantName'] = participantName;
                                                  dataParms['codeDescriptionId'] = 269;

                                                  checkbox = new Ext.form.Checkbox({
                                                      boxLabel: checkboxgroupStore.getAt(iCheckboxCount).data.Name,
                                                      inputValue: participantId,
                                                      itemId: 'checkbox13Mother' + participantId,
                                                      checked: isItemParticipantSelected(dataParms),
                                                      listeners: {
                                                          'change': function (cmp, newValue, oldValue, eOpts) {

                                                              var selectedItem = getSelectedItem(newValue, oldValue);
                                                              var newKeys = getObjectKeys(selectedItem);

                                                              if (newKeys.length > 0) {

                                                                  var parms = { currentVal: newValue };
                                                                  var selection = (newValue) ? cmp.inputValue : 0;

                                                                  var fields = [];
                                                                  var field = { 'ParticipantID': selection };
                                                                  fields.push(field);

                                                                  field = { 'CodeDescriptionID': 269 };
                                                                  fields.push(field);

                                                                  field = { 'ItemParticipantID': getItemParticipantId(selection) };
                                                                  fields.push(field);

                                                                  field = { 'DataState': 0 };
                                                                  fields.push(field);

                                                                  parms['storeId'] = 'CR_ItemParticipant_CollectionStore';
                                                                  parms['fields'] = fields;

                                                                  parms = getStatusParms(parms, 'wellbeingItem13Rating');
                                                                  parms['runValidations'] = true;
                                                                  parms['dataChanged'] = true;

                                                                  initValidations('Item13');

                                                                  runWellbeingRules(getAppController(), 'item13ParticipantCheckboxGroupMother', parms);
                                                              }
                                                          }
                                                      }
                                                  });
                                                  checkboxgroup.items.add(checkbox);
                                              }
                                          }
                                      }
                                  },
                                    {
                                        xtype: 'validationMessage',
                                        itemId: 'msgItem13MotherCaseParticipant',
                                        itemName: 'item13'
                                    },
                                  {
                                      xtype: 'component',
                                      border: false,
                                      margin: '10 0 0 10',
                                      cls: 'panel-background-color',
                                      html: 'Father:'
                                  },
                                  {
                                      xtype: 'checkboxgroup',
                                      columns: 1,
                                      vertical: true,
                                      itemId: 'item13ParticipantCheckboxGroupFather',
                                      listeners: {
                                          'afterrender': function () {

                                              var checkboxgroup = this;
                                              var checkboxgroupStore = GetItemParticipant(2);
                                              var checkbox = null;
                                              var participantId, participantName;
                                              var dataParms = { itemCode: 17, outcomeCode: 5 };

                                              for (var iCheckboxCount = 0; iCheckboxCount < checkboxgroupStore.count() ; iCheckboxCount++) {

                                                  participantName = checkboxgroupStore.getAt(iCheckboxCount).data.Name;
                                                  participantId = participants[participantName].ParticipantID;

                                                  dataParms['participantId'] = participantId;
                                                  dataParms['participantName'] = participantName;
                                                  dataParms['codeDescriptionId'] = 270;

                                                  checkbox = new Ext.form.Checkbox({
                                                      boxLabel: checkboxgroupStore.getAt(iCheckboxCount).data.Name,
                                                      inputValue: participantId,
                                                      itemId: 'checkbox13Father' + participantId,
                                                      checked: isItemParticipantSelected(dataParms),
                                                      width: 200,
                                                      listeners: {
                                                          'change': function (cmp, newValue, oldValue, eOpts) {

                                                              var selectedItem = getSelectedItem(newValue, oldValue);
                                                              var newKeys = getObjectKeys(selectedItem);

                                                              if (newKeys.length > 0) {

                                                                  var parms = { currentVal: newValue };
                                                                  var selection = (newValue) ? cmp.inputValue : 0;

                                                                  var fields = [];
                                                                  var field = { 'ParticipantID': selection };
                                                                  fields.push(field);

                                                                  field = { 'CodeDescriptionID': 270 };
                                                                  fields.push(field);

                                                                  field = { 'ItemParticipantID': getItemParticipantId(selection) };
                                                                  fields.push(field);

                                                                  field = { 'DataState': 0 };
                                                                  fields.push(field);

                                                                  parms['storeId'] = 'CR_ItemParticipant_CollectionStore';
                                                                  parms['fields'] = fields;

                                                                  parms = getStatusParms(parms, 'wellbeingItem13Rating');
                                                                  parms['runValidations'] = true;
                                                                  parms['dataChanged'] = true;

                                                                  initValidations('Item13');

                                                                  runWellbeingRules(getAppController(), 'item13ParticipantCheckboxGroupFather', parms);
                                                              }
                                                          }
                                                      }
                                                  });
                                                  checkboxgroup.items.add(checkbox);
                                              }
                                          }
                                      }
                                  },
                                    {
                                        xtype: 'validationMessage',
                                        itemId: 'msgItem13FatherCaseParticipant',
                                        itemName: 'item13'
                                    }
                              ]
                          },
                          {
                              xtype: 'container',
                              bodyCls: 'panel-background-color',
                              border: false,
                              layout: 'vbox',
                              margin: '0 0 20 20',
                              items: [
                                  {
                                      xtype: 'component',
                                      border: false,
                                      margin: '10 0 0 0',
                                      cls: 'panel-background-color',
                                      html: 'Optional: Provide comments in the narrative field below.'
                                  },
                                  {
                                      xtype: 'textarea',
                                      itemId: 'item13ApplicabilityComments',
                                      bind: '{item13Comments}',
                                      enableKeyEvents: true,
                                      width: '75%',
                                      maxlength: 4100,
                                      enforceMaxLength: true,
                                      height: 150
                                  }
                              ]
                          }
                      ]
                  }
            ]
        }

    ]
});
//
// Item 13 Questions
//
Ext.define('app.CaseReview.view.wellbeing.Question13A', {
    extend: 'Ext.container.Container',
    alias: 'widget.question13A',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'item13A',
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 13A Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing13ADef'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 13A Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing13AIns'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: "<strong>A.  During the period under review, did the agency make concerted efforts to actively involve the child in the case planning process?</strong>"
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: true,
            margin: '10 10 20 40',
            items: [
                {
                    xtype: 'container',
                    itemId: 'question13AAnswers',
                    cls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 20 0',
                    items: [
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            itemId: 'question13A',
                            defaults: {
                                bind: '{isAgencyConcertedEffortsToInvolveTheChild}'
                            },
                            items: [
                                {
                                    xtype: 'radio',
                                    boxLabel: '<b>Yes</b>',
                                    itemId: 'question13AYes',
                                    inputValue: 1,
                                    name: 'AgencyConcertedEffortsInvolveTheChild'
                                },
                                {
                                    margin: '0 0 0 10',
                                    xtype: 'radio',
                                    boxLabel: '<b>No</b>',
                                    itemId: 'question13ANo',
                                    inputValue: 2,
                                    name: 'AgencyConcertedEffortsInvolveTheChild'
                                },
                                {
                                    margin: '0 0 0 10',
                                    xtype: 'radio',
                                    boxLabel: '<b>NA</b>',
                                    itemId: 'question13ANA',
                                    inputValue: 3,
                                    name: 'AgencyConcertedEffortsInvolveTheChild'
                                }
                            ]
                        },
                        {
                            xtype: 'validationMessage',
                            itemId: 'msgQuestion13AAnswers',
                            itemName: 'item13'
                        }
                    ]
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '-20 0 10 40',
            cls: 'panel-background-color',
            html: 'If No, explain any concerns in the narrative field below.'
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '10 10 20 40',
            itemId: 'item13QuestionANarrative',
            layout: 'hbox',
            items: [
                {
                    xtype: 'textarea',
                    itemId: 'item13AConcerns',
                    bind: '{agencyConcertedEffortsToInvolveTheChildExplained}',
                    disabled: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem13QuestionANarrative',
                    itemName: 'item13'
                }
            ]
        }

    ]
});
Ext.define('app.CaseReview.view.wellbeing.Question13B', {
    extend: 'Ext.container.Container',
    alias: 'widget.question13B',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'item13B',
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 13B Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing13BDef'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 13B Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing13BIns'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: "<strong>B.  During the period under review, did the agency make concerted efforts to actively involve the mother in the case planning process?</strong>"
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: true,
            layout: 'vbox',
            margin: '10 10 20 40',
            items: [
                {
                    xtype: 'container',
                    itemId: 'item13BAnswers',
                    cls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 20 0',
                    items: [
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            itemId: 'question13B',
                            defaults: {
                                bind: '{isAgencyConcertedEffortsToInvolveTheMother}'
                            },
                            items: [
                                {
                                    xtype: 'radio',
                                    boxLabel: '<b>Yes</b>',
                                    itemId: 'question13BYes',
                                    inputValue: 1,
                                    name: 'AgencyConcertedEffortsInvolveTheMother'
                                },
                                {
                                    margin: '0 0 0 10',
                                    xtype: 'radio',
                                    boxLabel: '<b>No</b>',
                                    itemId: 'question13BNo',
                                    inputValue: 2,
                                    name: 'AgencyConcertedEffortsInvolveTheMother'
                                },
                                {
                                    margin: '0 0 0 10',
                                    xtype: 'radio',
                                    boxLabel: '<b>NA</b>',
                                    itemId: 'question13BNA',
                                    inputValue: 3,
                                    name: 'AgencyConcertedEffortsInvolveTheMother'
                                }
                            ]
                        },
                        {
                            xtype: 'validationMessage',
                            itemId: 'msgItem13BAnswers',
                            itemName: 'item13'
                        }
                    ]
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '-20 0 10 40',
            cls: 'panel-background-color',
            html: 'If No, explain any concerns in the narrative field below.'
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '10 10 20 40',
            itemId: 'item13QuestionBNarrative',
            layout: 'hbox',
            items: [

                {
                    xtype: 'textarea',
                    itemId: 'item13BConcerns',
                    bind: '{agencyConcertedEffortsToInvolveTheMotherExplained}',
                    disabled: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem13QuestionBNarrative',
                    itemName: 'item13'
                }
            ]
        }
    ]
});
Ext.define('app.CaseReview.view.wellbeing.Question13C', {
    extend: 'Ext.container.Container',
    alias: 'widget.question13C',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'item13C',
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 13C Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing13CDef'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 13C Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing13CIns'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: "<strong>C.  During the period under review, did the agency make concerted efforts to actively involve the father in the case planning process?</strong>"
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: true,
            layout: 'vbox',
            margin: '10 10 20 40',
            items: [
                {
                    xtype: 'container',
                    itemId: 'item13CAnswers',
                    cls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 20 0',
                    items: [
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            itemId: 'question13C',
                            defaults: {
                                bind: '{isAgencyConcertedEffortsToInvolveTheFather}'
                            },
                            items: [
                                {
                                    xtype: 'radio',
                                    boxLabel: '<b>Yes</b>',
                                    itemId: 'question13CYes',
                                    inputValue: 1,
                                    name: 'AgencyConcertedEffortsInvolveTheFather'
                                },
                                {
                                    margin: '0 0 0 10',
                                    xtype: 'radio',
                                    boxLabel: '<b>No</b>',
                                    itemId: 'question13CNo',
                                    inputValue: 2,
                                    name: 'AgencyConcertedEffortsInvolveTheFather'
                                },
                                {
                                    margin: '0 0 0 10',
                                    xtype: 'radio',
                                    boxLabel: '<b>NA</b>',
                                    itemId: 'question13CNA',
                                    inputValue: 3,
                                    name: 'AgencyConcertedEffortsInvolveTheFather'
                                }
                            ]
                        },
                        {
                            xtype: 'validationMessage',
                            itemId: 'msgItem13CAnswers',
                            itemName: 'item13'
                        }
                    ]
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '-20 0 10 40',
            cls: 'panel-background-color',
            html: 'If No, explain any concerns in the narrative field below.'
        },
         {
             xtype: 'container',
             cls: 'panel-background-color',
             border: false,
             margin: '10 10 20 40',
             itemId: 'item13QuestionCNarrative',
             layout: 'hbox',
             items: [

                {
                    xtype: 'textarea',
                    itemId: 'item13CConcerns',
                    bind: '{agencyConcertedEffortsToInvolveTheFatherExplained}',
                    disabled: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                 {
                     xtype: 'validationMessage',
                     itemId: 'msgItem13QuestionCNarrative',
                     itemName: 'item13'
                 }
             ]
         }
    ]
});
//
// Item 14
//
Ext.define('app.CaseReview.view.wellbeing.Item14', {
    extend: 'Ext.container.Container',
    alias: 'widget.item14',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    trackResetOnLoad: true,
    itemId: 'item14Panel',
    items:
    [
        {
            xtype: 'component',
            itemId: 'item14',
            border: false,
            margin: '20 0 0 20',
            html: '<strong>Item 14:</strong> Caseworker Visits With Child',
            cls: 'outcome-item-header'
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Purpose of Assessment: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing14Purpose'
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 0 20',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '20 0 0 0',
                    cls: 'panel-background-color',
                    html: '<strong>Item 14 Applicable Cases:</strong>'
                },
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 -10',
                    cls: 'panel-background-color',
                    html: '<ul><li>All cases are applicable for an assessment of this item.</li></ul>'
                }
            ]
        }
    ]
});
//
// Item 14 Questions
//
Ext.define('app.CaseReview.view.wellbeing.Question14A1', {
    extend: 'Ext.container.Container',
    alias: 'widget.question14A1',
    itemId: 'item14A1',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 14A1 Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing14A1Def'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 14A1 Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing14A1Ins'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 20 20 20',
            cls: 'panel-background-color',
            html: '<strong>A1.</strong> During the period under review, what was the most typical pattern of visitation between the caseworker or other responsible party and the child(ren) in the case? Select the box that describes the usual pattern of visitation.'
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'vbox',
            margin: '0 0 20 20',
            itemId: 'visitationFrequency',
            items: [
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'visitationFrequency1',
                    boxLabel: '<b>More than once a week</b>',
                    inputValue: 2,
                    bind: '{responsiblePartyVisitationFrequencyCode}',
                    name: 'ResponsiblePartyVisitationFrequency'
                },
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'visitationFrequency2',
                    boxLabel: '<b>Once a week</b>',
                    inputValue: 3,
                    bind: '{responsiblePartyVisitationFrequencyCode}',
                    name: 'ResponsiblePartyVisitationFrequency'
                },
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'visitationFrequency3',
                    boxLabel: '<b>Less than once a week, but at least twice a month</b>',
                    inputValue: 4,
                    bind: '{responsiblePartyVisitationFrequencyCode}',
                    name: 'ResponsiblePartyVisitationFrequency'

                },
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'visitationFrequency4',
                    boxLabel: '<b>Less than twice a month, but at least once a month</b>',
                    inputValue: 5,
                    bind: '{responsiblePartyVisitationFrequencyCode}',
                    name: 'ResponsiblePartyVisitationFrequency'
                },
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'visitationFrequency5',
                    boxLabel: '<b>Less than once a month</b>',
                    inputValue: 6,
                    bind: '{responsiblePartyVisitationFrequencyCode}',
                    name: 'ResponsiblePartyVisitationFrequency'

                },
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'visitationFrequency6',
                    boxLabel: '<b>Never</b>',
                    inputValue: 7,
                    bind: '{responsiblePartyVisitationFrequencyCode}',
                    name: 'ResponsiblePartyVisitationFrequency'
                }
            ]
        }
    ]
});
Ext.define('app.CaseReview.view.wellbeing.Question14A', {
    extend: 'Ext.container.Container',
    alias: 'widget.question14A',
    itemId: 'item14A',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 14A Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing14ADef'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 14A Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing14AIns'
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 0 20',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 0',
                    cls: 'panel-background-color',
                    html: '<strong>A.</strong> During the period under review, was the frequency of the visits between the caseworker (or other responsible party) and the child(ren) sufficient to address issues pertaining to the safety, permanency, and well-being of the child and promote achievement of case goals?'
                },
                {
                    xtype: 'container',
                    cls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 0 20',
                    itemId: 'item14AAnswers',
                    items: [
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            itemId: 'question14A',
                            defaults: {
                                bind: '{isResponsiblePartyVisitationFrequencySufficient}'
                            },
                            items: [
                                {
                                    xtype: 'radio',
                                    boxLabel: '<b>Yes</b>',
                                    itemId: 'question14AYes',
                                    inputValue: 1,
                                    name: 'IsResponsiblePartyVisitationFrequencySufficient'
                                },
                                {
                                    margin: '0 0 0 10',
                                    xtype: 'radio',
                                    boxLabel: '<b>No</b>',
                                    itemId: 'question14ANo',
                                    inputValue: 2,
                                    name: 'IsResponsiblePartyVisitationFrequencySufficient'
                                }
                            ]
                        },
                        {
                            xtype: 'validationMessage',
                            itemId: 'msgItem14AAnswers',
                            itemName: 'item14'
                        }
                    ]
                }
            ]
        }
    ]
});
Ext.define('app.CaseReview.view.wellbeing.Question14B', {
    extend: 'Ext.container.Container',
    alias: 'widget.question14B',
    itemId: 'item14B',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 14B Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing14BIns'
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 0 20',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 20 20 0',
                    cls: 'panel-background-color',
                    html: '<strong>B.</strong> During the period under review, was the quality of the visits between the caseworker and the child(ren) sufficient to address issues pertaining to the safety, permanency, and well-being of the child(ren) and promote achievement of case goals (for example, did the visits between the caseworker or other responsible party and the child(ren) focus on issues pertinent to case planning, service delivery, and goal achievement)?'
                },
                {
                    xtype: 'container',
                    cls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 0 20',
                    itemId: 'item14BAnswers',
                    items: [
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            itemId: 'question14B',
                            defaults: {
                                bind: '{isResponsiblePartyVisitationQualitySufficient}'
                            },
                            items: [
                                {
                                    xtype: 'radio',
                                    boxLabel: '<b>Yes</b>',
                                    inputValue: 1,
                                    itemId: 'question14BYes',
                                    name: 'IsResponsiblePartyVisitationQualitySufficient'
                                },
                                {
                                    margin: '0 0 0 10',
                                    xtype: 'radio',
                                    boxLabel: '<b>No</b>',
                                    inputValue: 2,
                                    itemId: 'question14BNo',
                                    name: 'IsResponsiblePartyVisitationQualitySufficient'
                                },
                                {
                                    margin: '0 0 0 10',
                                    xtype: 'radio',
                                    boxLabel: '<b>NA</b>',
                                    inputValue: 3,
                                    itemId: 'question14BNA',
                                    name: 'IsResponsiblePartyVisitationQualitySufficient'
                                }
                            ]
                        },
                        {
                            xtype: 'validationMessage',
                            itemId: 'msgItem14BAnswers',
                            itemName: 'item14'
                        }
                    ]
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: 'If No, explain any concerns in the narrative field below.'
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '10 10 20 20',
            itemId: 'item14QuestionBNarrative',
            items: [
                {
                    xtype: 'textarea',
                    itemId: 'responsiblePartyVisitationQualityExplained',
                    bind: '{responsiblePartyVisitationQualityExplained}',
                    disabled: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem14QuestionBNarrative',
                    itemName: 'item14'
                }
            ]
        }
    ]
});
//
// Item 15
//
Ext.define('app.CaseReview.view.wellbeing.Item15', {
    extend: 'Ext.container.Container',
    alias: 'widget.item15',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'item15Panel',
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'component',
            itemId: 'item15',
            border: false,
            margin: '20 0 0 20',
            html: '<strong>Item 15:</strong> Caseworker Visits With Parents',
            cls: 'outcome-item-header'
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Purpose of Assessment: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing15Purpose'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Item 15 Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing15Def'
                }
            ]

        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 0 20',
            items: [
                {
                    xtype: 'container',
                    cls: 'panel-background-color',
                    itemId: 'item15PreApplicability',
                    border: false,
                    layout: 'hbox',
                    items: [
                        {
                            xtype: 'component',
                            border: false,
                            margin: '20 0 0 0',
                            cls: 'panel-background-color',
                            html: '<strong>Item 15 Applicable Cases:</strong>'
                        },
                        {
                            xtype: 'validationMessage',
                            itemId: 'msgItem15PreApplicability',
                            itemName: 'item15'
                        }
                    ]
                },
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 -10',
                    cls: 'panel-background-color',
                    html: "<ul class='text-justify'><li>Because multiple case participants can be assessed in these questions, consider applicability for all appropriate case participants before determining that the rating should be Not Applicable. All cases are applicable for an assessment of this item except cases in which all parents being assessed as Mother and Father meet any of the following criteria (check Yes for any that apply and No for those that do not):</li></ul>"
                },
                {
                    xtype: 'container',
                    itemId: 'item15ApplicableCases',
                    cls: 'panel-background-color',
                    border: false,
                    margin: '0 0 0 0',
                    items: [
                        {
                            xtype: 'component',
                            border: false,
                            margin: '0 0 0 10',
                            cls: 'panel-background-color',
                            html: '<ul><li>Parental rights remained terminated during the entire period under review.</li></ul>'
                        },
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 0 100',
                            inputField: 'CodeDescriptionID',
                            itemId: 'item15Question1',
                            defaults: {
                                bind: '{answerCode79}'
                            },
                            codeDescValue: 79,
                            items: [
                                {
                                    itemId: 'item15Applicability1Yes',
                                    inputValue: 1,
                                    name: 'item15Applicability1',
                                    boxLabel: '<b>Yes</b>'
                                },
                                {
                                    margin: '0 0 0 10',
                                    itemId: 'item15Applicability1No',
                                    inputValue: 2,
                                    name: 'item15Applicability1',
                                    boxLabel: '<b>No</b>'
                                }
                            ]
                        },
                        {
                            xtype: 'component',
                            border: false,
                            margin: '10 0 0 30',
                            cls: 'panel-background-color',
                            html: '<ul><li>Parent’s whereabouts were not known during the entire period under review despite agency efforts to locate the parent.</li></ul>'
                        },
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 0 100',
                            inputField: 'CodeDescriptionID',
                            codeDescValue: 80,
                            itemId: 'item15Question2',
                            defaults: {
                                bind: '{answerCode80}'
                            },
                            items: [
                                {
                                    itemId: 'item15Applicability2Yes',
                                    inputValue: 1,
                                    name: 'item15Applicability2',
                                    boxLabel: '<b>Yes</b>'
                                },
                                {
                                    margin: '0 0 0 10',
                                    itemId: 'item15Applicability2No',
                                    inputValue: 2,
                                    name: 'item15Applicability2',
                                    boxLabel: '<b>No</b>'
                                }
                            ]
                        },
                        {
                            xtype: 'component',
                            border: false,
                            margin: '0 0 0 10',
                            cls: 'panel-background-color',
                            html: '<ul><li>The Reviewer has determined that Item 12B is rated as an Area Needing Improvement due to lack of concerted efforts to find applicable parents.</li></ul>'
                        },
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 0 100',
                            inputField: 'CodeDescriptionID',
                            codeDescValue: 293,
                            itemId: 'item15Question3',
                            defaults: {
                                bind: '{answerCode293}'
                            },
                            items: [
                                {
                                    itemId: 'item15Applicability3Yes',
                                    inputValue: 1,
                                    name: 'item15Applicability3',
                                    boxLabel: '<b>Yes</b>'
                                },
                                {
                                    margin: '0 0 0 10',
                                    itemId: 'item15Applicability3No',
                                    inputValue: 2,
                                    name: 'item15Applicability3',
                                    boxLabel: '<b>No</b>'
                                }
                            ]
                        },
                        {
                            xtype: 'component',
                            border: false,
                            margin: '0 0 0 30',
                            cls: 'panel-background-color',
                            html: '<ul><li>Parent was deceased during the entire period under review.</li></ul>'
                        },
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 0 100',
                            inputField: 'CodeDescriptionID',
                            codeDescValue: 81,
                            itemId: 'item15Question4',
                            defaults: {
                                bind: '{answerCode81}'
                            },
                            items: [
                                {
                                    itemId: 'item15Applicability4Yes',
                                    inputValue: 1,
                                    name: 'item15Applicability4',
                                    boxLabel: '<b>Yes</b>'
                                },
                                {
                                    margin: '0 0 0 10',
                                    itemId: 'item15Applicability4No',
                                    inputValue: 2,
                                    name: 'item15Applicability4',
                                    boxLabel: '<b>No</b>'
                                }
                            ]
                        },
                        {
                            xtype: 'component',
                            border: false,
                            margin: '0 0 0 30',
                            cls: 'panel-background-color',
                            html: '<ul><li>During the entire period under review it was documented in the case file that it was not in the child’s best interests to involve the parent in case planning.</li></ul>'
                        },
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 0 100',
                            inputField: 'CodeDescriptionID',
                            codeDescValue: 82,
                            itemId: 'item15Question5',
                            defaults: {
                                bind: '{answerCode82}'
                            },
                            items: [
                                {
                                    itemId: 'item15Applicability5Yes',
                                    inputValue: 1,
                                    name: 'item15Applicability5',
                                    boxLabel: '<b>Yes</b>'
                                },
                                {
                                    margin: '0 0 0 10',
                                    itemId: 'item15Applicability5No',
                                    inputValue: 2,
                                    name: 'item15Applicability5',
                                    boxLabel: '<b>No</b>'
                                }
                            ]
                        },
                        {
                            xtype: 'component',
                            border: false,
                            margin: '0 0 0 30',
                            cls: 'panel-background-color',
                            html: '<ul><li>During the entire period under review the parent has indicated he/she does not want to be involved in the child’s life and this was documented in the case file.</li></ul>'
                        },
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 0 100',
                            inputField: 'CodeDescriptionID',
                            codeDescValue: 83,
                            itemId: 'item15Question6',
                            defaults: {
                                bind: '{answerCode83}'
                            },
                            items: [
                                {
                                    itemId: 'item15Applicability6Yes',
                                    inputValue: 1,
                                    name: 'item15Applicability6',
                                    boxLabel: '<b>Yes</b>'
                                },
                                {
                                    margin: '0 0 0 10',
                                    itemId: 'item15Applicability6No',
                                    inputValue: 2,
                                    name: 'item15Applicability6',
                                    boxLabel: '<b>No</b>'
                                }
                            ]
                        }
                    ]
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 10 10',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 10',
                    cls: 'outcome-item-header',
                    html: '<strong>Is this case applicable?</strong>'
                },
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 10',
                    cls: 'panel-background-color',
                    html: 'Select the appropriate response. If the response is No, the case will be rated as Not Applicable in the ratings section for this item.'
                },
                {
                    xtype: 'itemApplicable',
                    store: 'CR_Outcome_CollectionStore',
                    bodyCls: 'panel-background-color',
                    border: false,
                    OutcomeCode: 5,
                    ItemCode: 19,
                    items: [
                        {
                            xtype: 'container',
                            itemId: 'applicabilityQuestion15',
                            cls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 20 40',
                            items: [
                                {
                                    xtype: 'radiogroup',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    itemId: 'Question15Applicable',
                                    defaults: {
                                        bind: '{item15Applicable}'
                                    },
                                    items: [
                                        {
                                            xtype: 'radio',
                                            itemId: 'applicabilityQuestion15Yes',
                                            boxLabel: '<b>Yes</b>',
                                            inputValue: 1,
                                            name: 'applicablityItem15'
                                        },
                                        {
                                            margin: '0 0 0 10',
                                            xtype: 'radio',
                                            boxLabel: '<b>No</b>',
                                            itemId: 'applicabilityQuestion15No',
                                            inputValue: 2,
                                            name: 'applicablityItem15'
                                        }
                                    ]
                                },
                                {
                                    xtype: 'validationMessage',
                                    itemId: 'msgApplicabilityQuestion15',
                                    itemName: 'item15'
                                }
                            ]
                        },
                        {
                            xtype: 'component',
                            border: false,
                            margin: '10 0 0 20',
                            cls: 'panel-background-color',
                            html: 'Indicate the case participants who are included in this item as Mother and Father:'
                        },
                        {
                            xtype: 'container',
                            cls: 'panel-background-color',
                            border: false,
                            layout: 'vbox',
                            margin: '0 0 20 40',
                            itemId: 'item15ParentCaseParticipant',
                            items: [
                                {
                                    xtype: 'component',
                                    border: false,
                                    margin: '10 0 0 10',
                                    cls: 'panel-background-color',
                                    html: 'Mother:'
                                },
                                {
                                    xtype: 'checkboxgroup',
                                    columns: 1,
                                    vertical: true,
                                    itemId: 'item15ParticipantCheckboxGroupMother',
                                    listeners: {
                                        'afterrender': function () {

                                            var checkboxgroup = this;
                                            var checkboxgroupStore = GetItemParticipant(1);
                                            var checkbox = null;
                                            var participantId, participantName;
                                            var dataParms = { itemCode: 19, outcomeCode: 5 };

                                            for (var iCheckboxCount = 0; iCheckboxCount < checkboxgroupStore.count() ; iCheckboxCount++) {

                                                participantName = checkboxgroupStore.getAt(iCheckboxCount).data.Name;
                                                participantId = participants[participantName].ParticipantID;

                                                dataParms['participantId'] = participantId;
                                                dataParms['participantName'] = participantName;
                                                dataParms['codeDescriptionId'] = 269;

                                                checkbox = new Ext.form.Checkbox({
                                                    boxLabel: checkboxgroupStore.getAt(iCheckboxCount).data.Name,
                                                    inputValue: participantId,
                                                    itemId: 'checkbox15Mother' + participantId,
                                                    checked: isItemParticipantSelected(dataParms),
                                                    listeners: {
                                                        'change': function (cmp, newValue, oldValue, eOpts) {

                                                            var selectedItem = getSelectedItem(newValue, oldValue);
                                                            var newKeys = getObjectKeys(selectedItem);

                                                            if (newKeys.length > 0) {

                                                                var parms = { currentVal: newValue };
                                                                var selection = (newValue) ? cmp.inputValue : 0;

                                                                var fields = [];
                                                                var field = { 'ParticipantID': selection };
                                                                fields.push(field);

                                                                field = { 'CodeDescriptionID': 269 };
                                                                fields.push(field);

                                                                field = { 'ItemParticipantID': getItemParticipantId(selection) };
                                                                fields.push(field);

                                                                field = { 'DataState': 0 };
                                                                fields.push(field);

                                                                parms['storeId'] = 'CR_ItemParticipant_CollectionStore';
                                                                parms['fields'] = fields;

                                                                parms = getStatusParms(parms, 'wellbeingItem15Rating');
                                                                parms['runValidations'] = true;
                                                                parms['dataChanged'] = true;

                                                                initValidations('Item15');

                                                                runWellbeingRules(getAppController(), 'item15ParticipantCheckboxGroupMother', parms);
                                                            }
                                                        }
                                                    }
                                                });
                                                checkboxgroup.items.add(checkbox);
                                            }
                                        }
                                    }
                                },
                                {
                                    xtype: 'validationMessage',
                                    itemId: 'msgItem15MotherCaseParticipant',
                                    itemName: 'item15'
                                },
                                {
                                    xtype: 'component',
                                    border: false,
                                    margin: '10 0 0 10',
                                    cls: 'panel-background-color',
                                    html: 'Father:'
                                },
                                {
                                    xtype: 'checkboxgroup',
                                    columns: 1,
                                    vertical: true,
                                    itemId: 'item15ParticipantCheckboxGroupFather',
                                    listeners: {
                                        'afterrender': function () {

                                            var checkboxgroup = this;
                                            var checkboxgroupStore = GetItemParticipant(2);
                                            var checkbox = null;
                                            var participantId, participantName;
                                            var dataParms = { itemCode: 19, outcomeCode: 5 };

                                            for (var iCheckboxCount = 0; iCheckboxCount < checkboxgroupStore.count() ; iCheckboxCount++) {

                                                participantName = checkboxgroupStore.getAt(iCheckboxCount).data.Name;
                                                participantId = participants[participantName].ParticipantID;

                                                dataParms['participantId'] = participantId;
                                                dataParms['participantName'] = participantName;
                                                dataParms['codeDescriptionId'] = 270;

                                                checkbox = new Ext.form.Checkbox({
                                                    boxLabel: checkboxgroupStore.getAt(iCheckboxCount).data.Name,
                                                    inputValue: participantId,
                                                    itemId: 'checkbox15Father' + participantId,
                                                    checked: isItemParticipantSelected(dataParms),
                                                    width: 200,
                                                    listeners: {
                                                        'change': function (cmp, newValue, oldValue, eOpts) {

                                                            var selectedItem = getSelectedItem(newValue, oldValue);
                                                            var newKeys = getObjectKeys(selectedItem);

                                                            if (newKeys.length > 0) {

                                                                var parms = { currentVal: newValue };
                                                                var selection = (newValue) ? cmp.inputValue : 0;

                                                                var fields = [];
                                                                var field = { 'ParticipantID': selection };
                                                                fields.push(field);

                                                                field = { 'CodeDescriptionID': 270 };
                                                                fields.push(field);

                                                                field = { 'ItemParticipantID': getItemParticipantId(selection) };
                                                                fields.push(field);

                                                                field = { 'DataState': 0 };
                                                                fields.push(field);

                                                                parms['storeId'] = 'CR_ItemParticipant_CollectionStore';
                                                                parms['fields'] = fields;

                                                                parms = getStatusParms(parms, 'wellbeingItem15Rating');
                                                                parms['runValidations'] = true;
                                                                parms['dataChanged'] = true;

                                                                initValidations('Item15');

                                                                runWellbeingRules(getAppController(), 'item15ParticipantCheckboxGroupFather', parms);
                                                            }
                                                        }
                                                    }
                                                });
                                                checkboxgroup.items.add(checkbox);
                                            }


                                        }
                                    }

                                },
                                {
                                    xtype: 'validationMessage',
                                    itemId: 'msgItem15FatherCaseParticipant',
                                    itemName: 'item15'
                                }
                            ]
                        },
                        {
                            xtype: 'container',
                            cls: 'panel-background-color',
                            border: false,
                            layout: 'vbox',
                            margin: '0 0 20 20',
                            items: [
                                {
                                    xtype: 'component',
                                    border: false,
                                    margin: '10 0 0 0',
                                    cls: 'panel-background-color',
                                    html: 'Optional: Provide comments in the narrative field below.'
                                },
                                {
                                    xtype: 'textarea',
                                    itemId: 'item15ApplicabilityComments',
                                    bind: '{item15Comments}',
                                    enableKeyEvents: true,
                                    width: '75%',
                                    maxlength: 4100,
                                    enforceMaxLength: true,
                                    height: 150
                                }
                            ]
                        }
                    ]
                }
            ]
        }

    ]
});
//
// Item 15 Questions
//
Ext.define('app.CaseReview.view.wellbeing.Question15A1', {
    extend: 'Ext.container.Container',
    alias: 'widget.question15A1',
    itemId: 'item15A1',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 15A1 Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing15A1Def'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 15A1 Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing15A1Ins'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 20 20 20',
            cls: 'panel-background-color',
            html: '<strong>A1.</strong> During the period under review, what was the most typical pattern of visitation between the caseworker (or other responsible party) and the mother of the child(ren)? Select the appropriate response:'
        },
        {
            xtype: 'validationMessage',
            itemId: 'msgItem15A1',
            itemName: 'item15'
        },
        {
            xtype: 'container',
            itemId: 'item15A1Answers',
            cls: 'panel-background-color',
            border: false,
            layout: 'vbox',
            margin: '0 0 20 20',
            defaults: {
                bind: '{responsiblePartyVisitationFrequencyWithMotherCode}'
            },
            items: [
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'motherVisitationFrequency1',
                    boxLabel: '<b>NA</b>',
                    inputValue: 1,
                    name: 'ResponsiblePartyVisitationFrequencyWithMother'
                },
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'motherVisitationFrequency2',
                    boxLabel: '<b>More than once a week</b>',
                    inputValue: 2,
                    name: 'ResponsiblePartyVisitationFrequencyWithMother'
                },
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'motherVisitationFrequency3',
                    boxLabel: '<b>Once a week</b>',
                    inputValue: 3,
                    name: 'ResponsiblePartyVisitationFrequencyWithMother'
                },
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'motherVisitationFrequency4',
                    boxLabel: '<b>Less than once a week, but at least twice a month</b>',
                    inputValue: 4,
                    name: 'ResponsiblePartyVisitationFrequencyWithMother'

                },
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'motherVisitationFrequency5',
                    boxLabel: '<b>Less than twice a month, but at least once a month</b>',
                    inputValue: 5,
                    name: 'ResponsiblePartyVisitationFrequencyWithMother'
                },
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'motherVisitationFrequency6',
                    boxLabel: '<b>Less than once a month</b>',
                    inputValue: 6,
                    name: 'ResponsiblePartyVisitationFrequencyWithMother'

                },
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'motherVisitationFrequency7',
                    boxLabel: '<b>Never</b>',
                    inputValue: 7,
                    name: 'ResponsiblePartyVisitationFrequencyWithMother'
                }
            ]
        }
    ]
});
Ext.define('app.CaseReview.view.wellbeing.Question15A2', {
    extend: 'Ext.container.Container',
    alias: 'widget.question15A2',
    itemId: 'item15A2',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 15A2 Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing15A2Def'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 15A2 Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing15A2Ins'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 20 20 20',
            cls: 'panel-background-color',
            html: '<strong>A2.</strong> During the period under review, was the frequency of the visits between the caseworker (or other responsible party) and the mother sufficient to (1) address issues pertaining to the safety, permanency, and well-being of the child and (2) promote achievement of case goals?'
        },
        {
            xtype: 'container',
            itemId: 'item15A2Answers',
            cls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '0 0 20 20',
            items: [
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    itemId: 'question15A2',
                    defaults: {
                        bind: '{isResponsiblePartyVisitationFrequencyWithMotherSufficient}'
                    },
                    items: [
                        {
                            margin: '0 0 0 20',
                            xtype: 'radio',
                            boxLabel: '<b>Yes</b>',
                            itemId: 'question15A2Yes',
                            inputValue: 1,
                            name: 'ResponsiblePartyVisitationFrequencyMotherSufficient'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            itemId: 'question15A2No',
                            boxLabel: '<b>No</b>',
                            inputValue: 2,
                            name: 'ResponsiblePartyVisitationFrequencyMotherSufficient'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            itemId: 'question15A2NA',
                            boxLabel: '<b>NA</b>',
                            inputValue: 3,
                            name: 'ResponsiblePartyVisitationFrequencyMotherSufficient'
                        }
                    ]
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem15A2Answers',
                    itemName: 'item15'
                }
            ]
        }
    ]
});
Ext.define('app.CaseReview.view.wellbeing.Question15B1', {
    extend: 'Ext.container.Container',
    alias: 'widget.question15B1',
    itemId: 'item15B1',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 15B1 Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing15B1Def'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 15B1 Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing15B1Ins'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 20 20 20',
            cls: 'panel-background-color',
            html: '<strong>B1.</strong> During the period under review, what was the most typical pattern of visitation between the caseworker (or other responsible party) and the father of the child(ren)? Select the appropriate response:'
        },
        {
            xtype: 'validationMessage',
            itemId: 'msgItem15B1',
            itemName: 'item15'
        },
        {
            xtype: 'container',
            itemId: 'item15B1Answers',
            cls: 'panel-background-color',
            border: false,
            layout: 'vbox',
            margin: '0 0 20 20',
            defaults: {
                bind: '{responsiblePartyVisitationFrequencyWithFatherCode}'
            },
            items: [
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'fatherVisitationFrequency1',
                    boxLabel: '<b>NA</b>',
                    inputValue: 1,
                    name: 'CR_WellBeing_Collection.ResponsiblePartyVisitationFrequencyWithFather'
                },
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'fatherVisitationFrequency2',
                    boxLabel: '<b>More than once a week</b>',
                    inputValue: 2,
                    name: 'CR_WellBeing_Collection.ResponsiblePartyVisitationFrequencyWithFather'
                },
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'fatherVisitationFrequency3',
                    boxLabel: '<b>Once a week</b>',
                    inputValue: 3,
                    name: 'CR_WellBeing_Collection.ResponsiblePartyVisitationFrequencyWithFather'
                },
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'fatherVisitationFrequency4',
                    boxLabel: '<b>Less than once a week, but at least twice a month</b>',
                    inputValue: 4,
                    name: 'CR_WellBeing_Collection.ResponsiblePartyVisitationFrequencyWithFather'

                },
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'fatherVisitationFrequency5',
                    boxLabel: '<b>Less than twice a month, but at least once a month</b>',
                    inputValue: 5,
                    name: 'CR_WellBeing_Collection.ResponsiblePartyVisitationFrequencyWithFather'
                },
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'fatherVisitationFrequency6',
                    boxLabel: '<b>Less than once a month</b>',
                    inputValue: 6,
                    name: 'CR_WellBeing_Collection.ResponsiblePartyVisitationFrequencyWithFather'

                },
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'fatherVisitationFrequency7',
                    boxLabel: '<b>Never</b>',
                    inputValue: 7,
                    name: 'CR_WellBeing_Collection.ResponsiblePartyVisitationFrequencyWithFather'
                }
            ]
        }
    ]
});
Ext.define('app.CaseReview.view.wellbeing.Question15B2', {
    extend: 'Ext.container.Container',
    alias: 'widget.question15B2',
    itemId: 'item15B2',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 15B2 Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing15B2Def'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 15B2 Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing15B2Ins'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 20 20 20',
            cls: 'panel-background-color',
            html: '<strong>B2.</strong> During the period under review, was the frequency of the visits between the caseworker (or other responsible party) and the father sufficient to address issues pertaining to the safety, permanency, and well-being of the child and promote achievement of case goals?'
        },
        {
            xtype: 'container',
            itemId: 'item15B2Answers',
            cls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '0 0 20 20',
            items: [
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    itemId: 'question15B2',
                    defaults: {
                        bind: '{isResponsiblePartyVisitationFrequencyWithFatherSufficient}'
                    },
                    items: [
                        {
                            margin: '0 0 0 20',
                            xtype: 'radio',
                            itemId: 'question15B2Yes',
                            boxLabel: '<b>Yes</b>',
                            inputValue: 1,
                            name: 'IsResponsiblePartyVisitationFrequencyFatherSufficient'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            itemId: 'question15B2No',
                            boxLabel: '<b>No</b>',
                            inputValue: 2,
                            name: 'IsResponsiblePartyVisitationFrequencyFatherSufficient'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            itemId: 'question15B2NA',
                            boxLabel: '<b>NA</b>',
                            inputValue: 3,
                            name: 'IsResponsiblePartyVisitationFrequencyFatherSufficient'
                        }
                    ]
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem15B2Answers',
                    itemName: 'item15'
                }
            ]
        }
    ]
});
Ext.define('app.CaseReview.view.wellbeing.Question15C', {
    extend: 'Ext.container.Container',
    alias: 'widget.question15C',
    itemId: 'item15C',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 15C Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing15CIns'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 20 20 20',
            cls: 'panel-background-color',
            html: '<strong>C.</strong> During the period under review, was the quality of the visits between the caseworker (or other responsible party) and the mother sufficient to address issues pertaining to the safety, permanency, and well-being of the child and promote achievement of case goals?'
        },
        {
            xtype: 'container',
            itemId: 'item15CAnswers',
            cls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '0 0 20 20',
            items: [
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    itemId: 'question15C',
                    defaults: {
                        bind: '{isResponsiblePartyVisitationQualityWithMotherSufficient}'
                    },
                    items: [
                        {
                            margin: '0 0 0 20',
                            xtype: 'radio',
                            itemId: 'question15CYes',
                            boxLabel: '<b>Yes</b>',
                            inputValue: 1,
                            name: 'ResponsiblePartyVisitationQualityMotherSufficient'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            itemId: 'question15CNo',
                            boxLabel: '<b>No</b>',
                            inputValue: 2,
                            name: 'ResponsiblePartyVisitationQualityMotherSufficient'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            itemId: 'question15CNA',
                            boxLabel: '<b>NA</b>',
                            inputValue: 3,
                            name: 'ResponsiblePartyVisitationQualityMotherSufficient'
                        }
                    ]
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem15CAnswers',
                    itemName: 'item15'
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '10 10 20 20',
            itemId: 'item15QuestionCNarrative',
            items: [
                {
                    xtype: 'textarea',
                    itemId: 'responsiblePartyVisitationQualityWithMotherExplained',
                    bind: '{responsiblePartyVisitationQualityWithMotherExplained}',
                    disabled: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem15QuestionCNarrative',
                    itemName: 'item15'
                }
            ]
        }
    ]
});
Ext.define('app.CaseReview.view.wellbeing.Question15D', {
    extend: 'Ext.container.Container',
    alias: 'widget.question15D',
    itemId: 'item15D',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 15D Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing15DIns'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 20 20 20',
            cls: 'panel-background-color',
            html: '<strong>D.</strong> During the period under review, was the quality of the visits between the caseworker (or other responsible party) and the father sufficient to address issues pertaining to the safety, permanency, and well-being of the child and promote achievement of case goals?'
        },
        {
            xtype: 'container',
            itemId: 'item15DAnswers',
            cls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '0 0 20 20',
            items: [
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    itemId: 'question15D',
                    defaults: {
                        bind: '{isResponsiblePartyVisitationQualityWithFatherSufficient}'
                    },
                    items: [
                        {
                            margin: '0 0 0 20',
                            xtype: 'radio',
                            itemId: 'question15DYes',
                            boxLabel: '<b>Yes</b>',
                            inputValue: 1,
                            name: 'IsResponsiblePartyVisitationQualityFatherSufficient'
                        },
                        {
                            margin: '0 0 0 20',
                            xtype: 'radio',
                            itemId: 'question15DNo',
                            boxLabel: '<b>No</b>',
                            inputValue: 2,
                            name: 'IsResponsiblePartyVisitationQualityFatherSufficient'
                        },
                        {
                            margin: '0 0 0 20',
                            xtype: 'radio',
                            itemId: 'question15DNA',
                            boxLabel: '<b>NA</b>',
                            inputValue: 3,
                            name: 'IsResponsiblePartyVisitationQualityFatherSufficient'
                        }
                    ]
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem15D',
                    itemName: 'item15'
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '10 10 20 20',
            itemId: 'item15QuestionDNarrative',
            items: [
                {
                    xtype: 'textarea',
                    width: '40%',
                    itemId: 'responsiblePartyVisitationQualityWithFatherExplained',
                    bind: '{responsiblePartyVisitationQualityWithFatherExplained}',
                    disabled: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem15QuestionDNarrative',
                    itemName: 'item15'
                }
            ]
        }
    ]
});
//
// Item 16
//
Ext.define('app.CaseReview.view.wellbeing.WellbeingOutcome2', {
    extend: 'Ext.container.Container',
    alias: 'widget.wellbeingOutcome2',
    itemId: 'outcome2Overview',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    items:
    [
        {
            xtype: 'component',
            html: "Outcome 2: Children receive appropriate services to meet their educational needs.",
            margin: '20 20 20 20',
            cls: 'outcome-header'
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 0 0 20',
            cls: 'panel-background-color',
            html: 'What is the level of outcome achievement that best describes the extent to which this outcome is being or has been achieved, based on the rating for item 16? '
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeingOutcome2Ins'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 0 10 20',
            cls: 'panel-background-color',
            html: '<strong>Level of Outcome Achievement:</strong>'
        },
        {
            xtype: 'itemRating',
            itemId: 'wellbeingOutcome2Rating',
            page: 'Wellbeing',
            itemType: 'outcome',
            outcomeCode: 6
        }
    ]
});
Ext.define('app.CaseReview.view.wellbeing.Item16', {
    extend: 'Ext.container.Container',
    alias: 'widget.item16',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'item16Panel',
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'component',
            itemId: 'item16',
            border: false,
            margin: '20 0 0 20',
            html: '<strong>Item 16:</strong> Educational Needs of the Child',
            cls: 'outcome-item-header'
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Purpose of Assessment: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing16Purpose'
                }
            ]

        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 0 20',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '20 0 0 0',
                    cls: 'panel-background-color',
                    html: '<strong>Item 16 Applicable Cases:</strong>'
                },
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 -10',
                    cls: 'panel-background-color',
                    html: "<ul class='text-justify'><li>All foster care cases involving a school-aged child, including those in pre-school, are applicable for an assessment of this item. If a child is 2 years old or younger and has been identified as having developmental delays, the case may be applicable if the developmental delays need to be addressed through an educational approach rather than through physical therapy or some form of physical health approach. In these latter cases, the issue of developmental delays would be addressed under item 17.</li>" +
                        "<li>Foster care cases are Not Applicable if the child is age 2 or younger and there are no apparent developmental delays.</li>" +
                        "<li>In-home services cases are applicable for an assessment of this item if (1) educational issues are relevant to the reason for the agency’s involvement with the family, and/or (2) it is reasonable to expect that the agency would address educational issues given the circumstances of the case. For example, it is reasonable to expect that the agency would address educational issues in a case in which the child is the subject of a substantiated maltreatment report and, during the period under review, the maltreatment appeared to be affecting the child’s school performance.</li>" +
                        "<li>In-home services cases are Not Applicable for an assessment of this item if the reviewer determines that, during the period under review, there is no reason to expect that the agency would address educational issues for any children in the family, given the reason for agency involvement or the circumstances of the case. This “non-applicability” applies even if there is evidence in the case file that the agency has learned that the parent/caregiver has obtained educational services for the children.</li>" +
                        "</ul>"
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'vbox',
            margin: '0 0 10 10',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 10',
                    cls: 'outcome-item-header',
                    html: '<strong>Is this case applicable?</strong>'
                },
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 10',
                    cls: 'panel-background-color',
                    html: 'Select the appropriate response. If the response is No, the case will be rated as Not Applicable in the ratings section for this item.'
                },
                {
                    xtype: 'itemApplicable',
                    store: 'CR_Outcome_CollectionStore',
                    bodyCls: 'panel-background-color',
                    border: false,
                    OutcomeCode: 6,
                    ItemCode: 20,
                    items: [
                        {
                            xtype: 'container',
                            cls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 10 30',
                            itemId: 'applicabilityQuestion16',
                            items: [
                                {
                                    xtype: 'radiogroup',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    itemId: 'Question16Applicable',
                                    defaults: {
                                        bind: '{item16Applicable}'
                                    },
                                    items: [
                                        {
                                            xtype: 'radio',
                                            boxLabel: '<b>Yes</b>',
                                            inputValue: 1,
                                            itemId: 'item16ApplicableYes',
                                            name: 'applicablityItem16'
                                        },
                                        {
                                            margin: '0 0 0 10',
                                            xtype: 'radio',
                                            boxLabel: '<b>No</b>',
                                            inputValue: 2,
                                            itemId: 'item16ApplicableNo',
                                            name: 'applicablityItem16'
                                        }
                                    ]
                                },
                                {
                                    xtype: 'validationMessage',
                                    itemId: 'msgApplicabilityQuestion16',
                                    itemName: 'item16'
                                }
                            ]
                        },
                        {
                            xtype: 'container',
                            itemId: 'item16ChildParticipants',
                            items: [
                                {
                                    xtype: 'component',
                                    border: false,
                                    margin: '10 0 0 20',
                                    cls: 'panel-background-color',
                                    html: 'For in home services cases, indicate the name(s) of the child(ren) who were included in the assessment:'
                                },
                                {
                                    xtype: 'container',
                                    cls: 'panel-background-color',
                                    border: false,
                                    layout: 'vbox',
                                    margin: '0 0 20 40',
                                    items: [
                                        {
                                            xtype: 'checkboxgroup',
                                            columns: 1,
                                            vertical: true,
                                            itemId: 'item16ParticipantCheckboxGroupChildren',
                                            listeners: {
                                                'afterrender': function () {

                                                    var checkboxgroup = this;
                                                    var checkboxgroupStore = GetItemChildren();
                                                    var checkbox = null;
                                                    for (var iCheckboxCount = 0; iCheckboxCount < checkboxgroupStore.count() ; iCheckboxCount++) {
                                                        checkbox = new Ext.form.Checkbox({
                                                            boxLabel: checkboxgroupStore.getAt(iCheckboxCount).data.Name + " " + checkboxgroupStore.getAt(iCheckboxCount).data.Age,
                                                            inputValue: checkboxgroupStore.getAt(iCheckboxCount).data.ChildDemographicID,
                                                            itemId: 'checkbox16Child' + checkboxgroupStore.getAt(iCheckboxCount).data.ChildDemographicID,
                                                            width: 300
                                                        });
                                                        checkboxgroup.items.add(checkbox);
                                                    }


                                                }

                                            }

                                        }
                                    ]
                                }
                            ]
                        },

                        {
                            xtype: 'container',
                            cls: 'panel-background-color',
                            border: false,
                            layout: 'vbox',
                            margin: '0 0 20 20',
                            items: [
                                {
                                    xtype: 'component',
                                    border: false,
                                    margin: '10 0 0 0',
                                    cls: 'panel-background-color',
                                    html: 'Optional: Provide comments in the narrative field below.'
                                },
                                {
                                    xtype: 'textarea',
                                    itemId: 'item16ApplicableComments',
                                    width: 800,
                                    bind: '{item16Comments}',
                                    maxlength: 4100,
                                    enforceMaxLength: true,
                                    enableKeyEvents: true,
                                    height: 150                            
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    ]
});
//
// Item 16 Questions
//
Ext.define('app.CaseReview.view.wellbeing.Question16A', {
    extend: 'Ext.container.Container',
    alias: 'widget.question16A',
    itemId: 'item16A',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 16A Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing16AIns'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 20 20 20',
            cls: 'panel-background-color',
            html: '<strong>A.</strong> During the period under review, did the agency make concerted efforts to accurately assess the children’s educational needs?'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '0 0 20 20',
            itemId: 'question16A',
            defaults: {
                bind: '{isAgencyAssessEducationNeeds}'
            },
            items: [
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'question16AYes',
                    boxLabel: '<b>Yes</b>',
                    inputValue: 1,
                    name: 'AgencyAssessEducation'
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    itemId: 'question16ANo',
                    boxLabel: '<b>No</b>',
                    inputValue: 2,
                    name: 'AgencyAssessEducation'
                }
            ]
        }
    ]
});
Ext.define('app.CaseReview.view.wellbeing.Question16B', {
    extend: 'Ext.container.Container',
    alias: 'widget.question16B',
    itemId: 'item16B',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 16B Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing16BIns'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 20 20 20',
            cls: 'panel-background-color',
            html: '<strong>B.</strong> During the period under review, did the agency engage in concerted efforts to address the children’s educational needs through appropriate services?'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '0 0 20 20',
            itemId: 'question16B',
            defaults: {
                bind: '{isAgencyAddressEducationNeeds}'
            },
            items: [
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'question16BYes',
                    boxLabel: '<b>Yes</b>',
                    inputValue: 1,
                    name: 'IsAgencyAddressEducation'
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    itemId: 'question16BNo',
                    boxLabel: '<b>No</b>',
                    inputValue: 2,
                    name: 'IsAgencyAddressEducation'
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    itemId: 'question16BNA',
                    boxLabel: '<b>NA</b>',
                    inputValue: 3,
                    name: 'IsAgencyAddressEducation'
                }
            ]
        }
    ]
});
//
// Item 17
//
Ext.define('app.CaseReview.view.wellbeing.WellbeingOutcome3Overview', {
    extend: 'Ext.container.Container',
    alias: 'widget.wellbeingOutcome3Overview',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    items:
    [
        {
            xtype: 'component',
            itemId: 'wellbeingOutcome3',
            html: "Outcome 3: Children receive adequate services to meet their physical and mental health needs.",
            margin: '20 20 20 20',
            cls: 'outcome-header'
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 0 0 20',
            cls: 'panel-background-color',
            html: 'What is the level of outcome achievement that best describes the extent to which this outcome is being or has been achieved, based on the ratings for items 17 and 18?'
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeingOutcome3Ins'
                }
            ]

        },
        {
            xtype: 'component',
            border: false,
            margin: '20 0 10 20',
            bodyCls: 'panel-background-color',
            html: '<strong>Level of Outcome Achievement:</strong>'
        },
        {
            xtype: 'itemRating',
            itemId: 'wellbeingOutcome3Rating',
            page: 'Wellbeing',
            itemType: 'outcome',
            outcomeCode: 7
        }
    ]
});
Ext.define('app.CaseReview.view.wellbeing.Item17Applicability', {
    extend: 'Ext.container.Container',
    alias: 'widget.item17Applicability',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'item17Panel',
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'panel',
            itemId: 'item17',
            border: false,
            margin: '20 0 0 20',
            html: '<strong>Item 17:</strong> Physical Health of the Child',
            bodyCls: 'outcome-item-header'
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Purpose of Assessment: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    html: "<div class='html-content-item-margins text-justify'>" +
                        "<ul><li>To determine whether, during the period under review, the agency addressed the physical health needs of the children, including dental health needs.</li>" +
                        "</ul></div>"
                }
            ]

        },
        {
            xtype: 'container',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '0 0 0 20',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '20 0 0 0',
                    bodyCls: 'panel-background-color',
                    html: '<strong>Item 17 Applicable Cases:</strong>'
                },
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 -10',
                    bodyCls: 'panel-background-color',
                    html: "<ul class='text-justify'><li>All foster care cases are applicable for an assessment of this item.</li>" +
                        "<li>In-home services cases are applicable for an assessment of this item if (1) physical/dental health issues were relevant to the reason for the agency’s involvement with the family, and/or (2) it is reasonable to expect that the agency would address physical/dental health issues given the circumstances of the case. For example, it is reasonable to expect that the agency would address physical health issues in a case in which a child is the subject of a substantiated maltreatment report of physical neglect; and there is reason to suspect that, during the period under review, the neglect may have affected the child’s physical health.</li>" +
                        "<li>In-home services cases are Not Applicable for an assessment of this item if you determine that there is no reason to expect that the agency would address physical and dental health issues for any children in the family, given the reason for agency involvement or the circumstances of the case. This “non-applicability” applies even if there is evidence in the case file that the agency has learned that the parent is effective in taking care of the children’s physical and dental health needs.</li>" +
                        "</ul>"
                }
            ]
        },
        {
            xtype: 'container',
            itemId: 'item17ApplicabileCases',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'vbox',
            margin: '0 0 10 10',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 10',
                    cls: 'outcome-item-header',
                    html: '<strong>Is this case applicable?</strong>'
                },
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 10',
                    bodyCls: 'panel-background-color',
                    html: 'Select the appropriate response. If the response is No, the case will be rated as Not Applicable in the ratings section for this item.'
                },
                {
                    xtype: 'itemApplicable',
                    store: 'CR_Outcome_CollectionStore',
                    bodyCls: 'panel-background-color',
                    border: false,
                    OutcomeCode: 7,
                    ItemCode: 21,
                    items: [
                        {
                            xtype: 'container',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 10 30',
                            itemId: 'applicabilityQuestion17',
                            items: [
                                {
                                    xtype: 'radiogroup',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    itemId: 'Question17Applicable',
                                    defaults: {
                                        bind: '{item17Applicable}'
                                    },
                                    items: [
                                        {
                                            xtype: 'radio',
                                            itemId: 'item17Yes',
                                            boxLabel: '<b>Yes</b>',
                                            inputValue: 1,
                                            name: 'item17Applicability'
                                        },
                                        {
                                            margin: '0 0 0 10',
                                            itemId: 'item17No',
                                            xtype: 'radio',
                                            boxLabel: '<b>No</b>',
                                            inputValue: 2,
                                            name: 'item17Applicability'
                                        }
                                    ]
                                },
                                {
                                    xtype: 'validationMessage',
                                    itemId: 'msgApplicabilityQuestion17',
                                    itemName: 'item17'
                                }
                            ]
                        },
                        {
                            xtype: 'container',
                            itemId: 'item17ChildParticipants',
                            items: [
                                {
                                    xtype: 'component',
                                    border: false,
                                    margin: '10 0 0 20',
                                    bodyCls: 'panel-background-color',
                                    html: 'For in home services cases, indicate the name(s) of the child(ren) who were included in the assessment :'
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    layout: 'vbox',
                                    margin: '0 0 20 40',
                                    items: [
                                        {
                                            xtype: 'checkboxgroup',
                                            columns: 1,
                                            vertical: true,
                                            itemId: 'item17ParticipantCheckboxGroupChildren',
                                            listeners: {
                                                'afterrender': function () {

                                                    var checkboxgroup = this;
                                                    var checkboxgroupStore = GetItemChildren();
                                                    var checkbox = null;
                                                    for (var iCheckboxCount = 0; iCheckboxCount < checkboxgroupStore.count() ; iCheckboxCount++) {
                                                        checkbox = new Ext.form.Checkbox({
                                                            boxLabel: checkboxgroupStore.getAt(iCheckboxCount).data.Name + " " + checkboxgroupStore.getAt(iCheckboxCount).data.Age,
                                                            inputValue: checkboxgroupStore.getAt(iCheckboxCount).data.ChildDemographicID,
                                                            itemId: 'checkbox17Child' + checkboxgroupStore.getAt(iCheckboxCount).data.ChildDemographicID,
                                                            width: 300
                                                        });
                                                        checkboxgroup.items.add(checkbox);
                                                    }
                                                }
                                            }
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            xtype: 'container',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'vbox',
                            margin: '0 0 20 20',
                            items: [
                                {
                                    xtype: 'component',
                                    border: false,
                                    margin: '10 0 0 0',
                                    bodyCls: 'panel-background-color',
                                    html: 'Optional: Provide comments in the narrative field below.'
                                },
                                {
                                    xtype: 'textarea',
                                    itemId: 'item17ApplicableComments',
                                    bind: '{item17Comments}',
                                    enableKeyEvents: true,
                                    width: 800,
                                    maxlength: 4100,
                                    enforceMaxLength: true,
                                    height: 150
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    ]
});
Ext.define('app.CaseReview.view.wellbeing.Question17', {
    extend: 'Ext.container.Container',
    alias: 'widget.question17',
    itemId: 'item17A1',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        //***************************
        // Question 17A1 Instructions
        //***************************
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 17A1 Instructions: [SHOW]</div>",
            margin: '20 20 0 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing17A1Ins'
                }
            ]
        },
        //***************************
        // Question 17A1
        //***************************
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'vbox',
            margin: '0 0 20 20',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '20 0 0 0',
                    cls: 'panel-background-color',
                    html: "<strong>A1.</strong>During the period under review, did the agency accurately assess the children’s physical health care needs?"
                },
                {
                    xtype: 'container',
                    cls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '10 10 0 20',
                    itemId: 'item17QuestionA1',
                    items: [
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 20 20',
                            itemId: 'question17A1',
                            defaults: {
                                bind: '{isAgencyAssessPhysicalHealthNeeds}'
                            },
                            items: [
                                {
                                    xtype: 'radio',
                                    itemId: 'item17A1Yes',
                                    boxLabel: '<b>Yes</b>',
                                    inputValue: 1,
                                    name: 'AgencyAssessPhysicalHealth'
                                },
                                {
                                    margin: '0 0 0 10',
                                    xtype: 'radio',
                                    itemId: 'item17A1No',
                                    boxLabel: '<b>No</b>',
                                    inputValue: 2,
                                    name: 'AgencyAssessPhysicalHealth'
                                },
                                {
                                    margin: '0 0 0 10',
                                    xtype: 'radio',
                                    itemId: 'item17A1NA',
                                    boxLabel: '<b>NA</b>',
                                    inputValue: 3,
                                    name: 'AgencyAssessPhysicalHealth'
                                }
                            ]
                        },
                        {
                            xtype: 'validationMessage',
                            itemId: 'msgItem17QuestionA1',
                            itemName: 'item17'
                        }
                    ]
                }
            ]
        },
        //***************************
        // Question 17A2 Instructions
        //***************************
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 17A2 Instructions: [SHOW]</div>",
            margin: '20 20 0 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing17A2Ins'
                }
            ]
        },
        //***************************
        // Question 17A2
        //***************************
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'vbox',
            margin: '0 0 0 20',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '20 0 0 0',
                    cls: 'panel-background-color',
                    html: "<strong>A2.</strong> During the period under review, did the agency accurately assess the children’s dental health care needs?"
                },
                {
                    xtype: 'container',
                    cls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '10 10 20 20',
                    itemId: 'item17QuestionA2',
                    items: [
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 20 20',
                            itemId: 'item17A2',
                            defaults: {
                                bind: '{isAgencyAssessDentalHealthNeeds}'
                            },
                            items: [
                                {
                                    xtype: 'radio',
                                    itemId: 'item17A2Yes',
                                    boxLabel: '<b>Yes</b>',
                                    inputValue: 1,
                                    name: 'AgencyAssessDentalHealth'
                                },
                                {
                                    margin: '0 0 0 10',
                                    xtype: 'radio',
                                    itemId: 'item17A2No',
                                    boxLabel: '<b>No</b>',
                                    inputValue: 2,
                                    name: 'AgencyAssessDentalHealth'
                                },
                                {
                                    margin: '0 0 0 10',
                                    xtype: 'radio',
                                    itemId: 'item17A2NA',
                                    boxLabel: '<b>NA</b>',
                                    inputValue: 3,
                                    name: 'AgencyAssessDentalHealth'
                                }
                            ]
                        },
                        {
                            xtype: 'validationMessage',
                            itemId: 'msgItem17QuestionA2',
                            itemName: 'item17'
                        }
                    ]
                }
            ]
        },
        {
            xtype: 'validationMessage',
            itemId: 'msgItem17A3',
            itemName: 'item17'
        },
        //***************************
        // Question 17A3
        //***************************
        {
            xtype: 'gridpanel',
            itemId: 'pdHealthGrid',
            padding: 0,
            margin: '20 20 20 20',
            store: 'CR_Health_CollectionStore',
            title: '<strong>A3.</strong> Physical and Dental Health Table',
            border: true,
            tools: [
                    {
                        xtype: 'button',
                        text: 'Add',
                        itemId: 'pdHealthGridAddButton',
                        icon: addButtonImage
                    },
                    {
                        xtype: 'button',
                        itemId: 'pdHealthGridEditButton',
                        text: 'Edit',
                        icon: editButtonImage
                    },
                    {
                        xtype: 'button',
                        itemId: 'pdHealthGridDeleteButton',
                        text: 'Delete',
                        icon: deleteButtonImage
                    }
            ],
            plugins: [
                Ext.create('framework.grid.plugin.RowEditing',
                {
                    pluginId: 'programEditorPlugin',
                    clicksToEdit: 2,
                    errorSummary: false
                })
            ],
            columns: [
                {
                    text: 'Identified Physical or Dental Health Needs',
                    dataIndex: 'HealthNeeds',
                    width: '33%',
                    cellWrap: true
                },
                {
                    text: 'Services Provided',
                    dataIndex: 'ServicesProvided',
                    width: '30%',
                    cellWrap: true
                },
                {
                    text: 'Services Needed But Not Provided',
                    dataIndex: 'ServicesNeededNotProvided',
                    width: '40%',
                    cellWrap: true
                },
                {
                    text: 'Health Need',
                    dataIndex: 'HealthNeedCode',
                    hidden: true
                }
            ]
        },
        //***************************
        // Question 17A4 Definitions
        //***************************
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 17A4 Definitions: [SHOW]</div>",
            margin: '0 20 0 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing17A4Def'
                }
            ]
        },
        //***************************
        // Question 17A4 
        //***************************
        {
            xtype: 'container',
            itemId: 'item17A4',
            cls: 'panel-background-color',
            border: false,
            layout: 'vbox',
            margin: '0 0 0 20',
            items: [
                {
                    xtype: 'container',
                    cls: 'panel-background-color',
                    itemId: 'item17QuestionA4',
                    border: false,
                    layout: 'vbox',
                    items: [
                        {
                            xtype: 'component',
                            border: false,
                            margin: '20 0 5 0',
                            bodyCls: 'panel-background-color',
                            html: "<strong>A4.</strong> For foster care cases only, determine whether, during the period under review, there was evidence that the following case-management criteria required by federal statute were met (select each one that was met)."
                        },
                        {
                            xtype: 'validationMessage',
                            itemId: 'msgItem17QuestionA4',
                            itemName: 'item17'
                        }
                    ]
                },
                {
                    xtype: 'boundcheckboxgroup',
                    bodyCls: 'panel-background-color',
                    itemId: 'medicalNeedsCriteria',
                    columns: 1,
                    vertical: true,
                    store: 'CR_MultiAnswer_CollectionStore',
                    inputField: 'CodeDescriptionID',
                    items: [
                        {
                            itemId: 'fosterFederalCaseManagamentCriteria1',
                            boxLabel: 'NA (this is an in-home services case).',
                            inputValue: 178
                        },
                        {
                            itemId: 'fosterFederalCaseManagamentCriteria2',
                            boxLabel: 'No evidence found.',
                            inputValue: 179
                        },
                        {
                            itemId: 'fosterFederalCaseManagamentCriteria3',
                            boxLabel: "To the extent available and accessible, the child’s health records are up to date and included in the case file [Social Security Act § 475(1)(C)].",
                            inputValue: 180
                        },
                        {
                            itemId: 'fosterFederalCaseManagamentCriteria4',
                            boxLabel: "The case plan addresses the issue of health and dental care needs [Social Security Act § 475(1)(C)].",
                            inputValue: 181
                        },
                        {
                            itemId: 'fosterFederalCaseManagamentCriteria5',
                            boxLabel: "To the extent available and accessible, foster parents or foster care providers are provided with the child’s health records [Social Security Act § 475(5)(D)].",
                            inputValue: 182
                        }
                    ]
                }

            ]
        },
        //***************************
        // Question 17B1 Definitions
        //***************************
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 17B1 Definitions: [SHOW]</div>",
            margin: '0 20 0 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing17B1Def'
                }                
            ]
        },
        //***************************
        // Question 17B1 Instructions
        //***************************
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 17B1 Instructions: [SHOW]</div>",
            margin: '20 20 0 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing17B1Ins'
                }
            ]
        },
        //***************************
        // Question 17B1
        //***************************
        {
            xtype: 'container',
            itemId: 'item17B1',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 0 20',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '20 0 0 0',
                    cls: 'panel-background-color',
                    html: "<strong>B1.</strong> For foster care cases only, during the period under review, did the agency provide appropriate oversight of prescription medications for physical health issues?"
                },
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '10 10 20 20',
                    itemId: 'question17B1',
                    defaults: {
                        bind: '{isFosterOversightMedicationForPhysicalHealtyAppropriate}'
                    },
                    items: [
                        {
                            xtype: 'radio',
                            itemId: 'item17B1Yes',
                            boxLabel: '<b>Yes</b>',
                            inputValue: 1,
                            name: 'FosterOversightMedicationPhysicalHealth'
                        },
                        {
                            margin: '0 0 0 10',
                            itemId: 'item17B1No',
                            xtype: 'radio',
                            boxLabel: '<b>No</b>',
                            inputValue: 2,
                            name: 'FosterOversightMedicationPhysicalHealth'
                        },
                        {
                            margin: '0 0 0 10',
                            itemId: 'item17B1NA',
                            xtype: 'radio',
                            boxLabel: '<b>NA</b>',
                            inputValue: 3,
                            name: 'FosterOversightMedicationPhysicalHealth'
                        }
                    ]
                }
            ]
        },
        //***************************
        // Question 17B2 Instructions
        //***************************
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 17B2 Instructions: [SHOW]</div>",
            margin: '0 20 0 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing17B2Ins'
                }
            ]
        },
        //***************************
        // Question 17B2 and 17B3 Tip
        //***************************
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 17B2 and 17B3 Tip: [SHOW]</div>",
            margin: '20 20 0 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing17B2B3Tip'
                }
            ]
        },
        //***************************
        // Question 17B2
        //***************************
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            itemId: 'item17B2',
            margin: '0 0 0 20',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '20 0 0 0',
                    cls: 'panel-background-color',
                    html: "<strong>B2.</strong> During the period under review, did the agency ensure that appropriate services were provided to the children to address all identified physical health needs?"
                },
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '10 10 20 20',
                    itemId: 'question17B2',
                    defaults: {
                        bind: '{isAppropriateServicesForAllPhysicalHealthNeeds}'
                    },
                    items: [
                        {
                            xtype: 'radio',
                            itemId: 'item17B2Yes',
                            boxLabel: '<b>Yes</b>',
                            inputValue: 1,
                            name: 'AppropriateSerivcesForAllPhysicalHealth'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            itemId: 'item17B2No',
                            boxLabel: '<b>No</b>',
                            inputValue: 2,
                            name: 'AppropriateSerivcesForAllPhysicalHealth'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            itemId: 'item17B2NA',
                            boxLabel: '<b>NA</b>',
                            inputValue: 3,
                            name: 'AppropriateSerivcesForAllPhysicalHealth'
                        }
                    ]
                }
            ]
        },
        //***************************
        // Question 17B3 Instructions
        //***************************
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 17B3 Instructions: [SHOW]</div>",
            margin: '0 20 0 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing17B3Ins'
                }
            ]
        },
        //***************************
        // Question 17B3
        //***************************
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            itemId: 'item17B3',
            margin: '0 0 0 20',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '20 0 0 0',
                    cls: 'panel-background-color',
                    html: "<strong>B3.</strong> During the period under review, did the agency ensure that appropriate services were provided to the children to address all identified dental health needs?"
                },
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '10 10 20 20',
                    itemId: 'question17B3',
                    defaults: {
                        bind: '{isAppropriateServicesForAllDentalNeeds}'
                    },
                    items: [
                        {
                            xtype: 'radio',
                            itemId: 'item17B3Yes',
                            boxLabel: '<b>Yes</b>',
                            inputValue: 1,
                            name: 'AppropriateServicesForDental'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            itemId: 'item17B3No',
                            boxLabel: '<b>No</b>',
                            inputValue: 2,
                            name: 'AppropriateServicesForDental'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            itemId: 'item17B3NA',
                            boxLabel: '<b>NA</b>',
                            inputValue: 3,
                            name: 'AppropriateServicesForDental'
                        }
                    ]
                }
            ]
        }
    ]
});
//
// Item 18
//
Ext.define('app.CaseReview.view.wellbeing.Item18Applicability', {
    extend: 'Ext.container.Container',
    alias: 'widget.item18Applicability',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'item18Panel',
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'component',
            itemId: 'item18',
            border: false,
            margin: '20 0 0 20',
            html: "<strong>Item 18:</strong> Mental/Behavioral Health of the Child",
            cls: 'outcome-item-header'
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Purpose of Assessment: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing18Purpose'
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 0 20',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '20 0 0 0',
                    cls: 'panel-background-color',
                    html: '<strong>Item 18 Applicable Cases:</strong>'
                },
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 -10',
                    cls: 'panel-background-color',
                    html: "<ul class='text-justify'><li>Foster care cases are applicable for an assessment of this item if the reviewer determines that, during the period under review, the child had existing mental/behavioral health needs, including substance abuse issues. If the child had mental/behavioral health issues before the period under review that were adequately addressed and there are no remaining needs during the period under review, the case should be rated as Not Applicable.</li>" +
                            "<li>In-home services cases are applicable for an assessment of this item if (1) mental/behavioral health issues related to any of the children in the family were relevant to the reason for the agency’s involvement with the family, and/or (2) it is reasonable to expect that the agency would address mental/behavioral health issues given the circumstances of the case. For example, it is reasonable to expect that the agency would address mental health issues in a case in which a child is the subject of a substantiated maltreatment report and there is reason to suspect that, during the period under review, the maltreatment may have affected the child’s mental health.</li>" +
                            "<li>In-home services cases are Not Applicable for an assessment of this item if the reviewer determines that there is no reason to expect that, during the period under review, the agency would address mental/behavioral health issues for any children in the family, given the reason for agency involvement or the circumstances of the case. This “non-applicability” applies even if there is evidence in the case file that the agency has learned that the parent is effective in taking care of the children’s mental/behavioral health needs.</li>" +
                            "</ul>"
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 10 10',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 10',
                    cls: 'outcome-item-header',
                    html: '<strong>Is this case applicable?</strong>'
                },
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 10',
                    cls: 'panel-background-color',
                    html: 'Select the appropriate response. If the response is No, the case will be rated as Not Applicable in the ratings section for this item.'
                },
                {
                    xtype: 'itemApplicable',
                    store: 'CR_Outcome_CollectionStore',
                    bodyCls: 'panel-background-color',
                    border: false,
                    OutcomeCode: 7,
                    ItemCode: 22,
                    items: [
                        {
                            xtype: 'container',
                            cls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 10 30',
                            itemId: 'applicabilityQuestion18',
                            items: [
                                {
                                    xtype: 'radiogroup',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    itemId: 'Question18Applicable',
                                    defaults: {
                                        bind: '{item18Applicable}'
                                    },
                                    items: [
                                        {
                                            xtype: 'radio',
                                            boxLabel: '<b>Yes</b>',
                                            inputValue: 1,
                                            itemId: 'item18ApplicableYes',
                                            name: 'item18Applicable'
                                        },
                                        {
                                            margin: '0 0 0 10',
                                            xtype: 'radio',
                                            boxLabel: '<b>No</b>',
                                            name: 'item18Applicable',
                                            inputValue: 2,
                                            itemId: 'item18ApplicableNo'
                                        }
                                    ]
                                },
                                {
                                    xtype: 'validationMessage',
                                    itemId: 'msgApplicabilityQuestion18',
                                    itemName: 'item18'
                                }
                            ]
                        },
                        {
                            xtype: 'container',
                            itemId: 'item18ChildParticipants',
                            items: [
                                {
                                    xtype: 'component',
                                    border: false,
                                    margin: '10 0 0 20',
                                    cls: 'panel-background-color',
                                    html: 'For in home services cases, indicate the name(s) of the child(ren) who were included in the assessment:'
                                },
                                {
                                    xtype: 'container',
                                    cls: 'panel-background-color',
                                    border: false,
                                    layout: 'vbox',
                                    margin: '0 0 20 40',
                                    items: [
                                        {
                                            xtype: 'checkboxgroup',
                                            columns: 1,
                                            vertical: true,
                                            itemId: 'item18ParticipantCheckboxGroupChildren',
                                            listeners: {
                                                'afterrender': function () {

                                                    var checkboxgroup = this;
                                                    var checkboxgroupStore = GetItemChildren();
                                                    var checkbox = null;
                                                    for (var iCheckboxCount = 0; iCheckboxCount < checkboxgroupStore.count() ; iCheckboxCount++) {
                                                        checkbox = new Ext.form.Checkbox({
                                                            boxLabel: checkboxgroupStore.getAt(iCheckboxCount).data.Name + " " + checkboxgroupStore.getAt(iCheckboxCount).data.Age,
                                                            inputValue: checkboxgroupStore.getAt(iCheckboxCount).data.ChildDemographicID,
                                                            itemId: 'checkbox18Child' + checkboxgroupStore.getAt(iCheckboxCount).data.ChildDemographicID,
                                                            width: 300
                                                        });
                                                        checkboxgroup.items.add(checkbox);
                                                    }


                                                }

                                            }

                                        }
                                    ]
                                }
                            ]
                        },

                        {
                            xtype: 'container',
                            cls: 'panel-background-color',
                            border: false,
                            layout: 'vbox',
                            margin: '0 0 20 20',
                            items: [

                                {
                                    xtype: 'component',
                                    border: false,
                                    margin: '10 0 0 0',
                                    cls: 'panel-background-color',
                                    html: 'Optional: Provide comments in the narrative field below.'
                                },
                                {
                                    xtype: 'textarea',
                                    itemId: 'item18ApplicableComments',
                                    bind: '{item18Comments}',
                                    enableKeyEvents: true,
                                    width: '75%',
                                    maxlength: 4100,
                                    enforceMaxLength: true,
                                    height: 150
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    ]
});
Ext.define('app.CaseReview.view.wellbeing.Question18A', {
    extend: 'Ext.container.Container',
    alias: 'widget.question18A',
    itemId: 'item18A',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 18A Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing18ADef'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 18A Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing18AIns'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 20 20 20',
            cls: 'panel-background-color',
            html: '<strong>A.</strong> During the period under review, did the agency conduct an accurate assessment of the children’s mental/behavioral health needs either initially (if the child entered foster care during the period under review or if the in-home services case was opened during the period under review) and on an ongoing basis to inform case planning decisions?'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '0 0 20 20',
            itemId: 'question18A',
            defaults: {
                bind: '{isAgencyAssessMentalHealthNeeds}'
            },
            items: [
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'item18AYes',
                    boxLabel: '<b>Yes</b>',
                    inputValue: 1,
                    name: 'AgencyAssessMentalHealth'
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    itemId: 'item18ANo',
                    boxLabel: '<b>No</b>',
                    inputValue: 2,
                    name: 'AgencyAssessMentalHealth'
                }
            ]
        }
    ]
});
Ext.define('app.CaseReview.view.wellbeing.Question18B', {
    extend: 'Ext.container.Container',
    alias: 'widget.question18B',
    itemId: 'item18B',
    cls: 'cb',
    margin: '20 20 20 20',
    bodyCls: 'panel-background-color',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 18B Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing18BDef'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 18B Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing18BIns'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 20 20 20',
            cls: 'panel-background-color',
            html: '<strong>B.</strong> For foster care cases only, during the period under review, did the agency provide appropriate oversight of prescription medications for mental/behavioral health issues?'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '0 0 20 20',
            itemId: 'question18B',
            defaults: {
                bind: '{isFosterOversightMedicationForMentalHealtyAppropriate}'
            },
            items: [
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'item18BYes',
                    boxLabel: '<b>Yes</b>',
                    inputValue: 1,
                    name: 'FosterOversightMedicationMentalHealth'
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    itemId: 'item18BNo',
                    boxLabel: '<b>No</b>',
                    inputValue: 2,
                    name: 'FosterOversightMedicationMentalHealth'
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    itemId: 'item18BNA',
                    boxLabel: '<b>NA</b>',
                    inputValue: 3,
                    name: 'FosterOversightMedicationMentalHealth'
                }
            ]
        }
    ]
});
Ext.define('app.CaseReview.view.wellbeing.Question18C', {
    extend: 'Ext.container.Container',
    alias: 'widget.question18C',
    itemId: 'item18C',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 18C Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'wellbeing18CIns'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 20 20 20',
            cls: 'panel-background-color',
            html: '<strong>C.</strong> During the period under review, did the agency provide appropriate services to address the children’s mental/behavioral health needs?'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '0 0 20 20',
            itemId: 'question18C',
            defaults: {
                bind: '{isAppropriateServicesForMentalHealthNeeds}'
            },
            items: [
                {
                    margin: '0 0 0 20',
                    xtype: 'radio',
                    itemId: 'item18CYes',
                    boxLabel: '<b>Yes</b>',
                    inputValue: 1,
                    name: 'IsAppropriateServicesForMentalHealth'
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    itemId: 'item18CNo',
                    boxLabel: '<b>No</b>',
                    inputValue: 2,
                    name: 'IsAppropriateServicesForMentalHealth'
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    itemId: 'item18CNA',
                    boxLabel: '<b>NA</b>',
                    inputValue: 3,
                    name: 'IsAppropriateServicesForMentalHealth'
                }
            ]
        }
    ]
});