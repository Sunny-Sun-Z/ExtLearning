﻿Ext.define('App.CaseReview.view.wellbeing.wellbeingUI', {
    extend: 'Ext.form.Panel',
    alias: 'widget.wellbeingUI',
    baseCls: 'x-fieldset fieldset-padding',
    border: false,
    resizable: false,
    itemId: 'wellbeingTab',
    defaults: {
        stateful: true
    },
    items: [
    {
        xtype: 'panel',
        region: 'west',
        width: 200,
        scrollable: 'vertical',
        bodyCls: 'panel-background-color',
        items: [
            {
                xtype: 'panel',
                layout: 'vbox',
                border: 'false',
                bodyCls: 'panel-background-color',
                defaults: {
                    componentCls: 'left-nav-item',
                    xtype: 'hyperlink'
                },
                items: [
                    {
                        html: "<div class='left-nav-header'>Outcome 1</div>",
                        refItemId: 'wellbeingOutcome1'
                    },
                    {                        
                        html: 'Item 12',
                        itemId: 'linkItem12',
                        refItemId: 'item12'
                    },
                    {
                        html: 'Item 12 Rating',
                        refItemId: 'item12Rating'
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 12A',
                        itemId: 'linkItem12A',
                        refItemId: 'item12A',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 12A Rating',
                        refItemId: 'item12ARating',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        
                        html: 'Item 12A Notes',
                        refItemId: 'wellbeingItem12ANotes',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 12B',
                        itemId: 'linkItem12B',
                        refItemId: 'item12B',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 12B Rating',
                        refItemId: 'item12BRating',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 12B Notes',
                        refItemId: 'wellbeingItem12BNotes',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 12C',
                        itemId: 'linkItem12C',
                        refItemId: 'item12C',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 12C Rating',
                        refItemId: 'item12CRating',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 12C Notes',
                        refItemId: 'wellbeingItem12CNotes',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 13',
                        itemId: 'linkItem13',
                        refItemId: 'item13',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 13A',
                        itemId: 'linkItem13A',
                        refItemId: 'item13A',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 13B',
                        itemId: 'linkItem13B',
                        refItemId: 'item13B',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 13C',
                        itemId: 'linkItem13C',
                        refItemId: 'item13C',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 13 Rating',
                        refItemId: 'item13Rating',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 13 Notes',
                        refItemId: 'wellbeingItem13Notes',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 14',
                        itemId: 'linkItem14',
                        refItemId: 'item14',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 14 Rating',
                        refItemId: 'item14Rating',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 14 Notes',
                        refItemId: 'wellbeingItem14Notes',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 15',
                        itemId: 'linkItem15',
                        refItemId: 'item15',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 15 Rating',
                        refItemId: 'item15Rating',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 15 Notes',
                        refItemId: 'wellbeingItem15Notes',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: "<div class='left-nav-header'>Outcome 2</div>",
                        refItemId: 'wellbeingOutcome2',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 16',
                        itemId: 'linkItem16',
                        refItemId: 'item16',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 16 Rating',
                        refItemId: 'item16Rating',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 16 Notes',
                        refItemId: 'wellbeingItem16Notes',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: "<div class='left-nav-header'>Outcome 3</div>",
                        refItemId: 'wellbeingOutcome3',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 17',
                        itemId: 'linkItem17',
                        refItemId: 'item17',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 17 Rating',
                        refItemId: 'item17Rating',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 17 Notes',
                        refItemId: 'wellbeingItem17Notes',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 18',
                        itemId: 'linkItem18',
                        refItemId: 'item18',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 18 Rating',
                        refItemId: 'item18Rating',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    },
                    {
                        xtype: 'hyperlink',
                        html: 'Item 18 Notes',
                        refItemId: 'wellbeingItem18Notes',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'wellbeingPanel'
                        }
                    }
                ]
            }
        ]
    },
    {
        xtype: 'panel',
        itemId: 'wellbeingPanel',
        region: 'center',
        scrollable: 'vertical',
        viewModel: {
            type: 'wellbeingViewModel'
        },
        tbar: {
            xtype: 'headerUI',
            margin: 0
        },
        //===========================================================================
        // Added to solve flickering issue for nested collapsible panels - H Lawrence
        autoHeight: true,
        hideMode: 'offsets',
        // End of flickering solution
        //===========================================================================
        items: [
            {
                xtype: 'component',
                margin: '0 20 0 20',
                html: 'Child and Family Well-Being',
                cls: 'safety-header',
                height: 45,
                border: false
            },
            //==========================================================================//
            // Start of Outcome 1 Section
            //==========================================================================//
            //**************************************************************************//
            // Outcome 1 Overview
            //**************************************************************************//
            {
                xtype: 'container',
                margin: '20 20 20 20',
                cls: 'panel-background-color',
                border: true,
                items:
                [
                    {
                        xtype: 'component',
                        itemId: 'wellbeingOutcome1',
                        html: "Outcome 1: Families have enhanced capacity to provide for their children's needs.",
                        margin: '20 20 20 20',
                        cls: 'outcome-header'
                    },
                    {
                        xtype: 'component',
                        border: false,
                        margin: '20 0 0 20',
                        cls: 'panel-background-color',
                        html: 'What is the level of outcome achievement that best describes the extent to which this outcome is being or has been achieved, based on the ratings for items 12 through 15?'
                    },
                    {
                        xtype: 'listPanel',
                        title: "<div class='html-content-header-margins'>Instructions: [SHOW]</div>",
                        margin: '20 20 20 20',
                        padding: '0 0 0 0',
                        items: [
                            {
                                contentEl: 'wellbeingOutcome1Ins'
                            }
                        ]

                    },
                    {
                        xtype: 'component',
                        border: false,
                        margin: '20 0 10 20',
                        cls: 'panel-background-color',
                        html: '<strong>Level of Outcome Achievement:</strong>'
                    },
                    {
                        xtype: 'itemRating',
                        itemId: 'wellbeingOutcome1Rating',
                        page: 'Wellbeing',
                        itemType: 'outcome',
                        outcomeCode: 5
                    }
                ]
            },
            //**************************************************************************//
            // Item 12
            //**************************************************************************//
            {
                xtype: 'item12'
            },
           
            //**********************************************************************//
            // Sub-Item 12A
            //**********************************************************************//
            {
                xtype: 'item12A'
            },
            //**********************************************************************//
            // Sub-Item 12A Questions A1 & A2
            //**********************************************************************//
            {
                xtype: 'item12AQuestions'
            },
            //*****************************
            // Sub-Item 12A Rating Criteria
            //*****************************
            {
                xtype: 'container',
                itemId: 'item12ARating',
                margin: '20 20 20 20',
                cls: 'panel-background-color',
                border: true,
                trackResetOnLoad: true,
                items: [
                    {
                        xtype: 'listPanel',
                        title: "<div class='html-content-header-margins'>Sub-Item 12A Rating Criteria: [SHOW]</div>",
                        margin: '20 20 20 20',
                        padding: '0 0 0 0',
                        items: [
                            {
                                contentEl: 'wellbeing12ARatingCriteria'
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        border: false,
                        margin: '20 0 10 20',
                        cls: 'panel-background-color',
                        html: '<strong>Item Rating:</strong>'
                    },
                    {
                        xtype: 'container',
                        border: false,
                        margin: '10 10 20 0',
                        layout: 'hbox',
                        itemId: 'item12ARatingContainer',
                        items: [
                            {
                                xtype: 'itemRating',
                                itemId: 'wellbeingItem12ARating',
                                itemCode: 14,
                                page: 'Wellbeing',
                                itemName: 'item12A',
                                itemType: 'item',
                                outcomeCode: 5,
                                msgComponentId: 'msgItem12ARating',
                                ratingContainerId: 'item12ARatingContainer'
                            },
                            {
                                xtype: 'validationMessage',
                                itemId: 'msgItem12ARating',
                                itemName: 'item12A'
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        cls: 'panel-background-color',
                        border: false,
                        margin: '15 0 0 20',
                        html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below: '
                    },
                    {
                        xtype: 'container',
                        cls: 'panel-background-color',
                        border: false,
                        margin: '10 10 20 20',
                        items: [
                            {
                                xtype: 'textarea',
                                maxLength: 10000,
                                enableKeyEvents: true,
                                itemId: 'item12ARatingComment',
                                bind: '{item12ARatingComments}',
                                width: '75%',
                                enforceMaxLength: true,
                                height:150
                            }
                        ]
                    },
                    {
                        xtype: 'ratingOverride',
                        border: false,
                        margin: '20 0 10 20',
                        page: 'wellbeing',
                        itemNo: '12A',
                        itemCode: 14,
                        outcomeCode: 5,
                        itemId: 'wellbeingItem12ARatingOverride',
                        ratingComponentId: 'wellbeingItem12ARating',
                        outcomeRatingComponentId: 'wellbeingOutcome1Rating'
                    }
                ]
            },
            //*****************************
            // Sub-Item 12A QA Notes
            //*****************************
            {
                xtype: 'qaNotes',
                itemId: 'wellbeingItem12ANotes',
                notesTitle: 'Sub-Item 12A QA Notes',
                itemCode: 14,
                outcomeCode: 5
            },
            //*****************************
            // Sub-Item 12B
            //*****************************
            {
                xtype: 'item12B'
            },
            //*****************************
            // Sub-Item 12B1
            //*****************************
            {
                xtype: 'question12B1'
            },
            //*****************************
            // Sub-Item 12B3
            //*****************************
            {
                xtype: 'question12B3'
            },
            //*****************************
            // Sub-Item 12B2
            //*****************************
            {
                xtype: 'question12B2'
            },
            //*****************************
            // Sub-Item 12B4
            //*****************************
            {
                xtype: 'question12B4'                
            },
            //*****************************
            // Sub-Item 12B Rating Criteria
            //*****************************
            {
                xtype: 'container',
                itemId: 'item12BRating',
                margin: '20 20 20 20',
                cls: 'panel-background-color',
                border: true,
                items: [
                    {
                        xtype: 'listPanel',
                        title: "<div class='html-content-header-margins'>Sub-Item 12B Rating Criteria: [SHOW]</div>",
                        margin: '20 20 20 20',
                        padding: '0 0 0 0',
                        items: [
                            {
                                contentEl: 'wellbeing12BRatingCriteria'
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        border: false,
                        margin: '20 0 10 20',
                        cls: 'panel-background-color',
                        html: '<strong>Item Rating:</strong>'
                    },
                    {
                        xtype: 'container',
                        border: false,
                        margin: '10 10 20 0',
                        layout: 'hbox',
                        itemId: 'item12BRatingContainer',
                        items: [
                            {
                                xtype: 'itemRating',
                                itemId: 'wellbeingItem12BRating',
                                itemCode: 15,
                                page: 'Wellbeing',
                                itemName: 'item12B',
                                itemType: 'item',
                                outcomeCode: 5,
                                msgComponentId: 'msgItem12BRating',
                                ratingContainerId: 'item12BRatingContainer'
                            },
                            {
                                xtype: 'validationMessage',
                                itemId: 'msgItem12BRating',
                                itemName: 'item12B'
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        cls: 'panel-background-color',
                        border: false,
                        margin: '15 0 0 20',
                        html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below: '
                    },
                    {
                        xtype: 'container',
                        cls: 'panel-background-color',
                        border: false,
                        layout: 'hbox',
                        margin: '10 10 20 20',
                        items: [
                            {
                                xtype: 'textarea',
                                maxLength: 10000,
                                enableKeyEvents: true,
                                itemId: 'item12BRatingComment',
                                bind: '{item12BRatingComments}',
                                width: '75%',
                                enforceMaxLength: true,
                                height:150
                            }
                        ]
                    },
                    {
                        xtype: 'ratingOverride',
                        border: false,
                        margin: '20 0 10 20',
                        page: 'wellbeing',
                        itemNo: '12B',
                        itemCode: 15,
                        outcomeCode: 5,
                        itemId: 'wellbeingItem12BRatingOverride',
                        ratingComponentId: 'wellbeingItem12BRating',
                        outcomeRatingComponentId: 'wellbeingOutcome1Rating'
                    }
                ]
            },
            //*****************************
            // Sub-Item 12B QA Notes
            //*****************************
            {
                xtype: 'qaNotes',
                itemId: 'wellbeingItem12BNotes',
                notesTitle: 'Sub-Item 12B QA Notes',
                itemCode: 15,
                outcomeCode: 5
            },
            //*****************************
            // Sub-Item 12C
            //*****************************
            {
                xtype: 'item12C'
            },
            //*****************************
            // Sub-Item 12C1
            //*****************************
            {
                xtype: 'question12C1'
            },
            //*****************************
            // Sub-Item 12C2
            //*****************************
            {
                xtype: 'question12C2'
            },
            //*****************************
            // Sub-Item 12C Rating Criteria
            //*****************************
            {
                xtype: 'container',
                itemId: 'item12CRating',
                margin: '20 20 20 20',
                cls: 'panel-background-color',
                border: true,
                items: [
                    {
                        xtype: 'listPanel',
                        title: "<div class='html-content-header-margins'>Sub-Item 12C Rating Criteria: [SHOW]</div>",
                        margin: '20 20 20 20',
                        padding: '0 0 0 0',
                        items: [
                            {
                                contentEl: 'wellbeing12CRatingCriteria'
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        border: false,
                        margin: '20 0 10 20',
                        cls: 'panel-background-color',
                        html: '<strong>Item Rating:</strong>'
                    },
                    {
                        xtype: 'container',
                        border: false,
                        margin: '10 10 20 0',
                        layout: 'hbox',
                        itemId: 'item12CRatingContainer',
                        items: [
                            {
                                xtype: 'itemRating',
                                itemId: 'wellbeingItem12CRating',
                                itemCode: 16,
                                page: 'Wellbeing',
                                itemName: 'item12C',
                                itemType: 'item',
                                outcomeCode: 5,
                                msgComponentId: 'msgItem12CRating',
                                ratingContainerId: 'item12CRatingContainer'
                            },
                            {
                                xtype: 'validationMessage',
                                itemId: 'msgItem12CRating',
                                itemName: 'item12C'
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        cls: 'panel-background-color',
                        border: false,
                        margin: '15 0 0 20',
                        html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below: '
                    },
                    {
                        xtype: 'container',
                        cls: 'panel-background-color',
                        border: false,
                        layout: 'hbox',
                        margin: '10 10 20 20',
                        items: [
                            {
                                xtype: 'textarea',
                                maxLength: 10000,
                                enforceMaxLength: true,
                                enableKeyEvents: true,
                                itemId: 'item12CRatingComment',
                                bind: '{item12CRatingComments}',
                                width: '75%',
                                enforceMaxLength: true,
                                height:150
                            }
                        ]
                    },
                    {
                        xtype: 'ratingOverride',
                        border: false,
                        margin: '20 0 10 20',
                        page: 'wellbeing',
                        itemNo: '12C',
                        itemCode: 16,
                        outcomeCode: 5,
                        itemId: 'wellbeingItem12CRatingOverride',
                        ratingComponentId: 'wellbeingItem12CRating',
                        outcomeRatingComponentId: 'wellbeingOutcome1Rating'
                    }
                ]
            },
            //*****************************
            // Sub-Item 12C QA Notes
            //*****************************
            {
                xtype: 'qaNotes',
                itemId: 'wellbeingItem12CNotes',
                notesTitle: 'Sub-Item 12C QA Notes',
                itemCode: 16,
                outcomeCode: 5
            },
            //*****************************
            // Item 12 Rating Criteria
            //*****************************
            {
                xtype: 'container',
                itemId: 'item12Rating',
                margin: '20 20 20 20',
                cls: 'panel-background-color',
                border: true,
                items:
                [
                    {
                        xtype: 'listPanel',
                        title: "<div class='html-content-header-margins'>Item 12 Rating Criteria: [SHOW]</div>",
                        margin: '20 20 20 20',
                        padding: '0 0 0 0',
                        items: [
                            {
                                contentEl: 'wellbeing12RatingCriteria'
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        border: false,
                        margin: '20 0 10 20',
                        cls: 'panel-background-color',
                        html: '<strong>Item Rating:</strong>'
                    },
                    {
                        xtype: 'itemRating',
                        itemId: 'wellbeingItem12Rating',
                        itemCode: 13,
                        page: 'Wellbeing',
                        itemName: 'item12',
                        itemType: 'item',
                        outcomeCode: 5,
                        bind: '{item12OverallRating}'
                    },
                    {
                        xtype: 'container',
                        cls: 'panel-background-color',
                        border: false,
                        margin: '0 0 20 20',
                        items: [
                            {
                                xtype: 'component',
                                border: false,
                                margin: '10 0 0 0',
                                cls: 'panel-background-color',
                                html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below:'
                            },
                            {
                                xtype: 'textarea',
                                margin: '10 0 0 0',
                                maxLength: 10000,
                                enableKeyEvents: true,
                                itemId: 'item12RatingComment',
                                bind: '{item12RatingComments}',
                                width: '75%',
                                enforceMaxLength: true,
                                height:150
                            }
                        ]
                    },
                    {
                        xtype: 'ratingOverride',
                        border: false,
                        margin: '20 0 10 20',
                        page: 'wellbeing',
                        itemNo: '12',
                        itemCode: 13,
                        outcomeCode: 5,
                        itemId: 'wellbeingItem12RatingOverride',
                        ratingComponentId: 'wellbeingItem12Rating',
                        outcomeRatingComponentId: 'wellbeingOutcome1Rating'
                    }
                ]
            },
            //**************************************************************************//
            // Item 13
            //**************************************************************************//
            {
                xtype: 'item13'
                
            },
            //****************************************************
            // Item 13A
            //****************************************************
            {
                xtype: 'question13A'
            },
            //****************************************************
            // Item 13B
            //****************************************************
            {
                xtype: 'question13B'
            },
            //****************************************************
            // Item 13C
            //****************************************************
            {
                xtype: 'question13C'
            },
            //*****************************
            // Item 13 Rating Criteria
            //*****************************
            {
                xtype: 'container',
                itemId: 'item13Rating',
                margin: '20 20 20 20',
                cls: 'panel-background-color',
                border: true,
                items: [
                    {
                        xtype: 'listPanel',
                        title: "<div class='html-content-header-margins'>Sub-Item 13 Rating Criteria: [SHOW]</div>",
                        margin: '20 20 20 20',
                        padding: '0 0 0 0',
                        items: [
                            {
                                contentEl: 'wellbeing13RatingCriteria'
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        border: false,
                        margin: '20 0 10 20',
                        cls: 'panel-background-color',
                        html: '<strong>Item Rating:</strong>'
                    },
                    {
                        xtype: 'container',
                        border: false,
                        margin: '10 10 20 0',
                        layout: 'hbox',
                        itemId: 'item13RatingContainer',
                        items: [
                            {
                                xtype: 'itemRating',
                                itemId: 'wellbeingItem13Rating',
                                itemCode: 17,
                                page: 'Wellbeing',
                                itemName: 'item13',
                                itemType: 'item',
                                outcomeCode: 5,
                                msgComponentId: 'msgItem13Rating',
                                ratingContainerId: 'item13RatingContainer'
                            },
                            {
                                xtype: 'validationMessage',
                                itemId: 'msgItem13Rating',
                                itemName: 'item13'
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        cls: 'panel-background-color',
                        border: false,
                        margin: '15 0 0 20',
                        html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below: '
                    },
                    {
                        xtype: 'container',
                        cls: 'panel-background-color',
                        border: false,
                        layout: 'hbox',
                        margin: '10 10 20 20',
                        items: [
                            {
                                xtype: 'textarea',
                                maxLength: 10000,
                                enableKeyEvents: true,
                                itemId: 'item13RatingComment',
                                bind: '{item13RatingComments}',
                                width: '75%',
                                enforceMaxLength: true,
                                height:150
                            }
                        ]
                    },
                    {
                        xtype: 'ratingOverride',
                        border: false,
                        margin: '20 0 10 20',
                        page: 'wellbeing',
                        itemNo: '13',
                        itemCode: 17,
                        outcomeCode: 5,
                        itemId: 'wellbeingItem13RatingOverride',
                        ratingComponentId: 'wellbeingItem13Rating',
                        outcomeRatingComponentId: 'wellbeingOutcome1Rating'
                    }
                ]
            },
            //****************************************************
            // Item 13 QA Notes
            //****************************************************
            {
                xtype: 'qaNotes',
                itemId: 'wellbeingItem13Notes',
                notesTitle: 'Item 13 QA Notes',
                itemCode: 17,
                outcomeCode: 5
            },
            //**************************************************************************//
            // Item 14
            //**************************************************************************//
            {
                xtype: 'item14'
            },
            //**************************************************************************//
            // Item 14 Question A1
            //**************************************************************************//
            {
                xtype: 'question14A1'
            },
            //**************************************************************************//
            // Item 14 Question A
            //**************************************************************************//
            {
                xtype: 'question14A'
            },
            //**************************************************************************//
            // Item 14 Question B
            //**************************************************************************//
            {
                xtype: 'question14B'
            },
            //*****************************
            // Item 14 Rating Criteria
            //*****************************
            {
                xtype: 'container',
                itemId: 'item14Rating',
                margin: '20 20 20 20',
                cls: 'panel-background-color',
                border: true,
                items: [
                    {
                        xtype: 'listPanel',
                        title: "<div class='html-content-header-margins'>Item 14 Rating Criteria: [SHOW]</div>",
                        margin: '20 20 20 20',
                        padding: '0 0 0 0',
                        items: [
                            {
                                contentEl: 'wellbeing14RatingCriteria'
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        border: false,
                        margin: '20 0 10 20',
                        cls: 'panel-background-color',
                        html: '<strong>Item Rating:</strong>'
                    },
                    {
                        xtype: 'container',
                        border: false,
                        margin: '10 10 20 0',
                        layout: 'hbox',
                        itemId: 'item14RatingContainer',
                        items: [
                            {
                                xtype: 'itemRating',
                                itemId: 'wellbeingItem14Rating',
                                itemCode: 18,
                                page: 'Wellbeing',
                                itemName: 'item14',
                                itemType: 'item',
                                outcomeCode: 5,
                                msgComponentId: 'msgItem14Rating',
                                ratingContainerId: 'item14RatingContainer'
                            },
                            {
                                xtype: 'validationMessage',
                                itemId: 'msgItem14Rating',
                                itemName: 'item14'
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        cls: 'panel-background-color',
                        border: false,
                        margin: '15 0 0 20',
                        html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below: '
                    },
                    {
                        xtype: 'container',
                        cls: 'panel-background-color',
                        border: false,
                        layout: 'hbox',
                        margin: '10 10 20 20',
                        items: [
                            {
                                xtype: 'textarea',
                                maxLength: 10000,
                                enableKeyEvents: true,
                                itemId: 'item14RatingComment',
                                bind: '{item14RatingComments}',
                                width: '75%',
                                enforceMaxLength: true,
                                height:150
                            }
                        ]
                    },
                    {
                        xtype: 'ratingOverride',
                        border: false,
                        margin: '20 0 10 20',
                        page: 'wellbeing',
                        itemNo: '14',
                        itemCode: 18,
                        outcomeCode: 5,
                        itemId: 'wellbeingItem14RatingOverride',
                        ratingComponentId: 'wellbeingItem14Rating',
                        outcomeRatingComponentId: 'wellbeingOutcome1Rating'
                    }
                ]
            },
            //*****************************************************
            // Outcome 1 - Item 14 QA Notes
            //*****************************************************
            {
                xtype: 'qaNotes',
                itemId: 'wellbeingItem14Notes',
                notesTitle: 'Item 14 QA Notes',
                itemCode: 18, 
                outcomeCode: 5
            },
            //**************************************************************************//
            // Item 15
            //**************************************************************************//
            {
                xtype: 'item15'
            },
            //**************************************************************************//
            // Item 15 Question A1
            //**************************************************************************//
            {
                xtype: 'question15A1'
            },
            //**************************************************************************//
            // Item 15 Question A2
            //**************************************************************************//
            {
                xtype: 'question15A2'
            },
            //**************************************************************************//
            // Item 15 Question B1
            //**************************************************************************//
            {
                xtype: 'question15B1'
            },
            //**************************************************************************//
            // Item 15 Question B2
            //**************************************************************************//
            {
                xtype: 'question15B2'                
            },
            //**************************************************************************//
            // Item 15 Question C
            //**************************************************************************//
            {
                xtype: 'question15C'                
            },
            //**************************************************************************//
            // Item 15 Question D
            //**************************************************************************//
            {
                xtype: 'question15D'                
            },
            //*****************************
            // Item 15 Rating Criteria
            //*****************************
            {
                xtype: 'container',
                itemId: 'item15Rating',
                margin: '20 20 20 20',
                cls: 'panel-background-color',
                border: true,
                items: [
                    {
                        xtype: 'listPanel',
                        title: "<div class='html-content-header-margins'>Item 15 Rating Criteria: [SHOW]</div>",
                        margin: '20 20 20 20',
                        padding: '0 0 0 0',
                        items: [
                            {
                                contentEl: 'wellbeing15RatingCriteria'
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        border: false,
                        margin: '20 0 10 20',
                        cls: 'panel-background-color',
                        html: '<strong>Item Rating:</strong>'
                    },
                    {
                        xtype: 'container',
                        border: false,
                        margin: '10 10 20 0',
                        layout: 'hbox',
                        itemId: 'item15RatingContainer',
                        items: [
                            {
                                xtype: 'itemRating',
                                itemId: 'wellbeingItem15Rating',
                                itemCode: 19,
                                page: 'Wellbeing',
                                itemName: 'item15',
                                itemType: 'item',
                                outcomeCode: 5,
                                msgComponentId: 'msgItem15Rating',
                                ratingContainerId: 'item15RatingContainer'
                            },
                            {
                                xtype: 'validationMessage',
                                itemId: 'msgItem15Rating',
                                itemName: 'item15'
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        cls: 'panel-background-color',
                        border: false,
                        margin: '15 0 0 20',
                        html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below: '
                    },
                    {
                        xtype: 'container',
                        cls: 'panel-background-color',
                        border: false,
                        layout: 'hbox',
                        margin: '10 10 20 20',
                        items: [
                            {
                                xtype: 'textarea',
                                maxLength: 10000,
                                enableKeyEvents: true,
                                itemId: 'item15RatingComment',
                                bind: '{item15RatingComments}',
                                width: '75%',
                                enforceMaxLength: true,
                                height:150
                            }
                        ]
                    },
                    {
                        xtype: 'ratingOverride',
                        border: false,
                        margin: '20 0 10 20',
                        page: 'wellbeing',
                        itemNo: '15',
                        itemCode: 19,
                        outcomeCode: 5,
                        itemId: 'wellbeingItem15RatingOverride',
                        ratingComponentId: 'wellbeingItem15Rating',
                        outcomeRatingComponentId: 'wellbeingOutcome1Rating'
                    }
                ]
            },
            //*****************************************************
            // Outcome 1 - Item 15 QA Notes
            //*****************************************************
            {
                xtype: 'qaNotes',
                itemId: 'wellbeingItem15Notes',
                notesTitle: 'Item 15 QA Notes',
                itemCode: 19,
                outcomeCode: 5
            },
            //==========================================================================//
            // End of Outcome 1 Section
            //==========================================================================//
            //**************************************************************************//
            // Outcome 2 Overview
            //**************************************************************************//
            {
                xtype: 'wellbeingOutcome2'                
            },
            //**************************************************************************//
            // Item 16
            //**************************************************************************//
            {
                xtype: 'item16'                
            },
            //**************************************************************************//
            // Item 16 Question A
            //**************************************************************************//
            {
                xtype: 'question16A'                
            },
            //***********************************************************
            // Item 16A1 Education Table
            //***********************************************************
            {
                xtype: 'panel',
                itemId: 'item16A1Panel',
                items: [
                    {
                        xtype: 'validationMessage',
                        itemId: 'msgItem16A1',
                        itemName: 'item16'
                    },
                    {
                        xtype: 'gridpanel',
                        itemId: 'educationGrid',
                        store: 'CR_Education_CollectionStore',
                        border: true,
                        margin: '20 20 20 20',
                        title: "<strong>A1.&nbsp&nbspEducation Table</strong>",
                        stripeRows: true,
                        tools: [

                            {
                                xtype: 'button',
                                text: 'Add',
                                itemId: 'educationGridAddButton',
                                icon: addButtonImage
                            },
                            {
                                xtype: 'button',
                                itemId: 'educationGridEditButton',
                                text: 'Edit',
                                icon: editButtonImage
                            },
                            {
                                xtype: 'button',
                                itemId: 'educationGridDeleteButton',
                                text: 'Delete',
                                icon: deleteButtonImage
                            }
                        ],
                        plugins: [
                            Ext.create('framework.grid.plugin.RowEditing',
                            {
                                pluginId: 'programEditorPlugin',
                                clicksToEdit: 2,
                                errorSummary: false
                            })
                        ],
                        columns: [
                            {
                                text: 'Education Needs',
                                dataIndex: 'Needs',
                                width: '33%',
                                cellWrap: true
                            },
                            {
                                text: 'Services Provided',
                                dataIndex: 'ServicesProvided',
                                width: '33%',
                                cellWrap: true
                            },
                            {
                                text: 'Services Needed But Not Provided',
                                dataIndex: 'ServicesNeededNotProvided',
                                width: '33%',
                                cellWrap: true
                            }
                        ],
                        viewConfig: {
                            stripeRows: true
                        }
                    }
                ]
            },
            //**************************************************************************//
            // Item 16 Question B
            //**************************************************************************//
            {
                xtype: 'question16B'                
            },
            //*****************************
            // Item 16 Rating Criteria
            //*****************************
            {
                xtype: 'container',
                itemId: 'item16Rating',
                //cls: 'cb',
                margin: '20 20 20 20',
                cls: 'panel-background-color',
                border: true,
                items: [
                    {
                        xtype: 'listPanel',
                        title: "<div class='html-content-header-margins'>Item 16 Rating Criteria: [SHOW]</div>",
                        margin: '20 20 20 20',
                        padding: '0 0 0 0',
                        items: [
                            {
                                contentEl: 'wellbeing16RatingCriteria'
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        border: false,
                        margin: '20 0 10 20',
                        cls: 'panel-background-color',
                        html: '<strong>Item Rating:</strong>'
                    },
                    {
                        xtype: 'container',
                        border: false,
                        margin: '10 10 20 0',
                        layout: 'hbox',
                        itemId: 'item16RatingContainer',
                        items: [
                            {
                                xtype: 'itemRating',
                                itemId: 'wellbeingItem16Rating',
                                itemCode: 20,
                                page: 'Wellbeing',
                                itemName: 'item16',
                                itemType: 'item',
                                outcomeCode: 6,
                                msgComponentId: 'msgItem16Rating',
                                ratingContainerId: 'item16RatingContainer'
                            },
                            {
                                xtype: 'validationMessage',
                                itemId: 'msgItem16Rating',
                                itemName: 'item16'
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        cls: 'panel-background-color',
                        border: false,
                        margin: '15 0 0 20',
                        html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below: '
                    },
                    {
                        xtype: 'container',
                        cls: 'panel-background-color',
                        border: false,
                        layout: 'hbox',
                        margin: '10 10 20 20',
                        items: [
                            {
                                xtype: 'textarea',
                                maxLength: 10000,
                                enableKeyEvents: true,
                                itemId: 'item16RatingComment',
                                bind: '{item16RatingComments}',
                                width: '75%',
                                enforceMaxLength: true,
                                height:150
                            }
                        ]
                    },
                    {
                        xtype: 'ratingOverride',
                        border: false,
                        margin: '20 0 10 20',
                        page: 'wellbeing',
                        itemNo: '16',
                        itemCode: 20,
                        outcomeCode: 6,
                        itemId: 'wellbeingItem16RatingOverride',
                        ratingComponentId: 'wellbeingItem16Rating',
                        outcomeRatingComponentId: 'wellbeingOutcome2Rating'
                    }
                ]
            },
            //**************************************************************************//
            // Item 16 QA Notes
            //**************************************************************************//
            {
                xtype: 'qaNotes',
                itemId: 'wellbeingItem16Notes',
                notesTitle: 'Item 16 QA Notes',
                itemCode: 20,
                outcomeCode: 6
            },
            //==========================================================================//
            // End of Outcome 2 Section
            //==========================================================================//
            //**************************************************************************//
            // Outcome 3 Overview
            //**************************************************************************//
            {
                xtype: 'wellbeingOutcome3Overview'                
            },
            //**************************************************************************//
            // Item 17
            //**************************************************************************//
            {
                xtype: 'item17Applicability'                
            },
            //**************************************************************************//
            // Item 17 Questions A1,A2,A3,A4,B1,B2 & B3
            //**************************************************************************//
            {
                xtype: 'question17'
            },
            //**************************************************************************//
            // Item 17 QA Notes
            //**************************************************************************//
            {
                xtype: 'qaNotes',
                itemId: 'wellbeingItem17Notes',
                notesTitle: 'Item 17 QA Notes',
                itemCode: 21,
                outcomeCode: 7
            },
            //*****************************
            // Item 17 Rating Criteria
            //*****************************
            {
                xtype: 'panel',
                itemId: 'item17Rating',
                cls: 'cb',
                margin: '20 20 20 20',
                bodyCls: 'panel-background-color',
                border: true,
                items: [
                    {
                        xtype: 'listPanel',
                        title: "<div class='html-content-header-margins'>Item 17 Rating Criteria: [SHOW]</div>",
                        margin: '20 20 20 20',
                        padding: '0 0 0 0',
                        items: [
                            {
                                contentEl: 'wellbeing17RatingCriteria'
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        border: false,
                        margin: '20 0 10 20',
                        bodyCls: 'panel-background-color',
                        html: '<strong>Item Rating:</strong>'
                    },
                    {
                        xtype: 'container',
                        border: false,
                        margin: '10 10 20 0',
                        layout: 'hbox',
                        itemId: 'item17RatingContainer',
                        items: [
                            {
                                xtype: 'itemRating',
                                itemId: 'wellbeingItem17Rating',
                                itemCode: 21,
                                page: 'Wellbeing',
                                itemName: 'item17',
                                itemType: 'item',
                                outcomeCode: 7,
                                msgComponentId: 'msgItem17Rating',
                                ratingContainerId: 'item17RatingContainer'
                            },
                            {
                                xtype: 'validationMessage',
                                itemId: 'msgItem17Rating',
                                itemName: 'item17'
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        bodyCls: 'panel-background-color',
                        border: false,
                        margin: '15 0 0 20',
                        html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below: '
                    },
                    {
                        xtype: 'container',
                        bodyCls: 'panel-background-color',
                        border: false,
                        layout: 'hbox',
                        margin: '10 10 20 20',
                        items: [
                            {
                                xtype: 'textarea',
                                maxLength: 10000,
                                enableKeyEvents: true,
                                itemId: 'item17RatingComment',
                                bind: '{item17RatingComments}',
                                width: '75%',
                                enforceMaxLength: true,
                                height:150
                            }
                        ]
                    },
                    {
                        xtype: 'ratingOverride',
                        border: false,
                        margin: '20 0 10 20',
                        page: 'wellbeing',
                        itemNo: '17',
                        itemCode: 21,
                        outcomeCode: 7,
                        itemId: 'wellbeingItem17RatingOverride',
                        ratingComponentId: 'wellbeingItem17Rating',
                        outcomeRatingComponentId: 'wellbeingOutcome3Rating'
                    }
                ]
            },
            //**************************************************************************//
            // Item 18
            //**************************************************************************//
            {
                xtype: 'item18Applicability'                
            },
            //**************************************************************************//
            // Item 18 Question A
            //**************************************************************************//
            {
                xtype: 'question18A'                
            },
            //***********************************************************
            // Item 18A1 Mental/Behavioral Health Table
            //***********************************************************
            {
                xtype: 'container',
                itemId: 'item18A1Panel',
                items: [
                    {
                        xtype: 'validationMessage',
                        itemId: 'msgItem18A1',
                        itemName: 'item18'
                    },
                    {
                        xtype: 'gridpanel',
                        itemId: 'mbHealthGrid',
                        store: 'CR_Health_CollectionStore',
                        border: true,
                        margin: '20 20 20 20',
                        title: "<strong>A1.&nbsp&nbspMental / Behavioral Health Table</strong>",
                        tools: [
                        {
                            xtype: 'button',
                            text: 'Add',
                            itemId: 'mbHealthGridAddButton',
                            icon: addButtonImage
                        },
                        {
                            xtype: 'button',
                            itemId: 'mbHealthGridEditButton',
                            text: 'Edit',
                            icon: editButtonImage
                        },
                        {
                            xtype: 'button',
                            itemId: 'mbHealthGridDeleteButton',
                            text: 'Delete',
                            icon: deleteButtonImage
                        }
                        ],
                        plugins: [
                            Ext.create('framework.grid.plugin.RowEditing',
                            {
                                pluginId: 'programEditorPlugin',
                                clicksToEdit: 2,
                                errorSummary: false
                            }),
                            {
                                ptype: 'businessRulePlugin',
                                pluginId: 'mentalHealthTable',
                                rules: [
                                    {
                                        rType: 'ruleCheck',
                                        fields: [
                                            {
                                                eType: 'function',
                                                fieldName: 'NoItems',
                                                functionName: 'count',
                                                storeId: 'CR_Health_CollectionStore',
                                                fieldValue: undefined,
                                                columns: [
                                                    'HealthNeeds', 'ServicesProvided', 'ServicesNeededNotProvided',
                                                    'HealthNeedCode'
                                                ]
                                            }
                                        ],
                                        predicate: 'NoItems.fieldValue > 0'
                                    }
                                ],
                                action: [
                                    {
                                        type: 'ruleCheck',
                                        enable: true,
                                        disable: false
                                    }
                                ]
                            }
                        ],
                        columns: [
                            {
                                text: 'Identified Mental / Behavioral Health Needs',
                                dataIndex: 'HealthNeeds',
                                width: '25%',
                                cellWrap: true
                            },
                            {
                                text: 'Services Provided',
                                dataIndex: 'ServicesProvided',
                                width: '25%',
                                cellWrap: true
                            },
                            {
                                text: 'Services Needed But Not Provided',
                                dataIndex: 'ServicesNeededNotProvided',
                                width: '50%',
                                cellWrap: true
                            },
                            {
                                dataIndex: 'HealthNeedCode',
                                hidden: true
                            }
                        ]
                    }
                ]
            },
            //**************************************************************************//
            // Item 18 Question B
            //**************************************************************************//
            {
                xtype: 'question18B'                
            },
            //**************************************************************************//
            // Item 18 Question C
            //**************************************************************************//
            {
                xtype: 'question18C'                
            },
            //*****************************
            // Item 18 Rating Criteria
            //*****************************
            {
                xtype: 'container',
                itemId: 'item18Rating',
                margin: '20 20 20 20',
                cls: 'panel-background-color',
                border: true,
                items: [
                    {
                        xtype: 'listPanel',
                        title: "<div class='html-content-header-margins'>Item 18 Rating Criteria: [SHOW]</div>",
                        margin: '20 20 20 20',
                        padding: '0 0 0 0',
                        items: [
                            {
                                contentEl: 'wellbeing18RatingCriteria'
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        border: false,
                        margin: '20 0 10 20',
                        cls: 'panel-background-color',
                        html: '<strong>Item Rating:</strong>'
                    },
                    {
                        xtype: 'container',
                        border: false,
                        margin: '10 10 20 0',
                        layout: 'hbox',
                        itemId: 'item18RatingContainer',
                        items: [
                            {
                                xtype: 'itemRating',
                                itemId: 'wellbeingItem18Rating',
                                itemCode: 22,
                                page: 'Wellbeing',
                                itemName: 'item18',
                                itemType: 'item',
                                outcomeCode: 7,
                                msgComponentId: 'msgItem18Rating',
                                ratingContainerId: 'item18RatingContainer'
                            },
                            {
                                xtype: 'validationMessage',
                                itemId: 'msgItem18Rating',
                                itemName: 'item18'
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        cls: 'panel-background-color',
                        border: false,
                        margin: '15 0 0 20',
                        html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below: '
                    },
                    {
                        xtype: 'container',
                        cls: 'panel-background-color',
                        border: false,
                        layout: 'hbox',
                        margin: '10 10 20 20',
                        items: [
                            {
                                xtype: 'textarea',
                                maxLength: 10000,
                                enableKeyEvents: true,
                                itemId: 'item18RatingComment',
                                bind: '{item18RatingComments}',
                                width: '75%',
                                enforceMaxLength: true,
                                height:150
                            }
                        ]
                    },
                    {
                        xtype: 'ratingOverride',
                        border: false,
                        margin: '20 0 10 20',
                        page: 'wellbeing',
                        itemNo: '18',
                        itemCode: 22,
                        outcomeCode: 7,
                        itemId: 'wellbeingItem18RatingOverride',
                        ratingComponentId: 'wellbeingItem18Rating',
                        outcomeRatingComponentId: 'wellbeingOutcome3Rating'
                    }
                ]
            },
            //*****************************
            // Item 18 QA Notes
            //*****************************
            {
                xtype: 'qaNotes',
                itemId: 'wellbeingItem18Notes',
                notesTitle: 'Item 18 QA Notes',
                itemCode: 22,
                outcomeCode: 7
            }
            ]
        }
    ]
});