﻿Ext.define('App.CaseReview.view.wellbeing.WellbeingViewModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.wellbeingViewModel',
    stores: {
        wellbeingPreAppAnswers: {},
        wellbeingCollection: {},
        itemApplicability: {}
    },
    formulas: {
        //
        // Pre-applicability answers
        //
        answerCode68: {

            get: function () {

                var result;
                var items = this.data.wellbeingPreAppAnswers.query('CodeDescriptionID', 68);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {

                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem12BQuestion1().lastValue;
                    var newValue = getAppController().getItem12BQuestion1().getValue();

                    this.data.answerCode68 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 68;
                    parms['value'] = value;
                    parms['pageName'] = 'wellbeing';

                    updatePreApplicabilityAnswers(parms);
                }                
            }
        },
        answerCode69: {

            get: function () {

                var result;
                var items = this.data.wellbeingPreAppAnswers.query('CodeDescriptionID', 69);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem12BQuestion2().lastValue;
                    var newValue = getAppController().getItem12BQuestion2().getValue();

                    this.data.answerCode69 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 69;
                    parms['value'] = value;
                    parms['pageName'] = 'wellbeing';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode70: {

            get: function () {

                var result;
                var items = this.data.wellbeingPreAppAnswers.query('CodeDescriptionID', 70);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem12BQuestion3().lastValue;
                    var newValue = getAppController().getItem12BQuestion3().getValue();

                    this.data.answerCode70 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 70;
                    parms['value'] = value;
                    parms['pageName'] = 'wellbeing';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode71: {

            get: function () {

                var result;
                var items = this.data.wellbeingPreAppAnswers.query('CodeDescriptionID', 71);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem12BQuestion4().lastValue;
                    var newValue = getAppController().getItem12BQuestion4().getValue();

                    this.data.answerCode71 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 71;
                    parms['value'] = value;
                    parms['pageName'] = 'wellbeing';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode72: {

            get: function () {

                var result;
                var items = this.data.wellbeingPreAppAnswers.query('CodeDescriptionID', 72);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem12BQuestion5().lastValue;
                    var newValue = getAppController().getItem12BQuestion5().getValue();

                    this.data.answerCode72 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 72;
                    parms['value'] = value;
                    parms['pageName'] = 'wellbeing';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode73: {

            get: function () {

                var result;
                var items = this.data.wellbeingPreAppAnswers.query('CodeDescriptionID', 73);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem13Question1().lastValue;
                    var newValue = getAppController().getItem13Question1().getValue();

                    this.data.answerCode73 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 73;
                    parms['value'] = value;
                    parms['pageName'] = 'wellbeing';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode74: {

            get: function () {

                var result;
                var items = this.data.wellbeingPreAppAnswers.query('CodeDescriptionID', 74);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem13Question2().lastValue;
                    var newValue = getAppController().getItem13Question2().getValue();

                    this.data.answerCode74 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 74;
                    parms['value'] = value;
                    parms['pageName'] = 'wellbeing';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode75: {

            get: function () {

                var result;
                var items = this.data.wellbeingPreAppAnswers.query('CodeDescriptionID', 75);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem13Question3().lastValue;
                    var newValue = getAppController().getItem13Question3().getValue();

                    this.data.answerCode75 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 75;
                    parms['value'] = value;
                    parms['pageName'] = 'wellbeing';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode292: {

            get: function () {

                var result;
                var items = this.data.wellbeingPreAppAnswers.query('CodeDescriptionID', 292);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem13Question4().lastValue;
                    var newValue = getAppController().getItem13Question4().getValue();

                    this.data.answerCode292 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 292;
                    parms['value'] = value;
                    parms['pageName'] = 'wellbeing';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode76: {

            get: function () {

                var result;
                var items = this.data.wellbeingPreAppAnswers.query('CodeDescriptionID', 76);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem13Question5().lastValue;
                    var newValue = getAppController().getItem13Question5().getValue();

                    this.data.answerCode76 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 76;
                    parms['value'] = value;
                    parms['pageName'] = 'wellbeing';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode77: {

            get: function () {

                var result;
                var items = this.data.wellbeingPreAppAnswers.query('CodeDescriptionID', 77);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem13Question6().lastValue;
                    var newValue = getAppController().getItem13Question6().getValue();

                    this.data.answerCode77 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 77;
                    parms['value'] = value;
                    parms['pageName'] = 'wellbeing';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode78: {

            get: function () {

                var result;
                var items = this.data.wellbeingPreAppAnswers.query('CodeDescriptionID', 78);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem13Question7().lastValue;
                    var newValue = getAppController().getItem13Question7().getValue();

                    this.data.answerCode78 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 78;
                    parms['value'] = value;
                    parms['pageName'] = 'wellbeing';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode79: {

            get: function () {

                var result;
                var items = this.data.wellbeingPreAppAnswers.query('CodeDescriptionID', 79);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem15Question1().lastValue;
                    var newValue = getAppController().getItem15Question1().getValue();

                    this.data.answerCode79 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 79;
                    parms['value'] = value;
                    parms['pageName'] = 'wellbeing';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode80: {

            get: function () {

                var result;
                var items = this.data.wellbeingPreAppAnswers.query('CodeDescriptionID', 80);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem15Question2().lastValue;
                    var newValue = getAppController().getItem15Question2().getValue();

                    this.data.answerCode80 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 80;
                    parms['value'] = value;
                    parms['pageName'] = 'wellbeing';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode293: {

            get: function () {

                var result;
                var items = this.data.wellbeingPreAppAnswers.query('CodeDescriptionID', 293);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem15Question3().lastValue;
                    var newValue = getAppController().getItem15Question3().getValue();

                    this.data.answerCode293 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 293;
                    parms['value'] = value;
                    parms['pageName'] = 'wellbeing';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode81: {

            get: function () {

                var result;
                var items = this.data.wellbeingPreAppAnswers.query('CodeDescriptionID', 81);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem15Question4().lastValue;
                    var newValue = getAppController().getItem15Question4().getValue();

                    this.data.answerCode81 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 81;
                    parms['value'] = value;
                    parms['pageName'] = 'wellbeing';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode82: {

            get: function () {

                var result;
                var items = this.data.wellbeingPreAppAnswers.query('CodeDescriptionID', 82);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem15Question5().lastValue;
                    var newValue = getAppController().getItem15Question5().getValue();

                    this.data.answerCode82 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 82;
                    parms['value'] = value;
                    parms['pageName'] = 'wellbeing';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode83: {

            get: function () {

                var result;
                var items = this.data.wellbeingPreAppAnswers.query('CodeDescriptionID', 83);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem15Question6().lastValue;
                    var newValue = getAppController().getItem15Question6().getValue();

                    this.data.answerCode83 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 83;
                    parms['value'] = value;
                    parms['pageName'] = 'wellbeing';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        //
        // Other wellbeing data items
        //
        agencyConcertedEffortsToInvolveTheChildExplained: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.AgencyConcertedEffortsToInvolveTheChildExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.wellbeingCollection.count() == 0) {

                    return;
                }

                this.data.wellbeingCollection.getAt(0).data.AgencyConcertedEffortsToInvolveTheChildExplained = value;

                this.data.agencyConcertedEffortsToInvolveTheChildExplained = value;
            }
        },
        agencyConcertedEffortsToInvolveTheFatherExplained: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.AgencyConcertedEffortsToInvolveTheFatherExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.wellbeingCollection.count() == 0) {

                    return;
                }

                this.data.wellbeingCollection.getAt(0).data.AgencyConcertedEffortsToInvolveTheFatherExplained = value;

                this.data.agencyConcertedEffortsToInvolveTheFatherExplained = value;
            }
        },
        agencyConcertedEffortsToInvolveTheMotherExplained: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.AgencyConcertedEffortsToInvolveTheMotherExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.wellbeingCollection.count() == 0) {

                    return;
                }

                this.data.wellbeingCollection.getAt(0).data.AgencyConcertedEffortsToInvolveTheMotherExplained = value;

                this.data.agencyConcertedEffortsToInvolveTheMotherExplained = value;
            }
        },
        appropriateServicesForFatherExplained: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.AppropriateServicesForFatherExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.wellbeingCollection.count() == 0) {

                    return;
                }

                this.data.wellbeingCollection.getAt(0).data.AppropriateServicesForFatherExplained = value;

                this.data.appropriateServicesForFatherExplained = value;
            }
        },
        appropriateServicesForMotherExplained: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.AppropriateServicesForMotherExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.wellbeingCollection.count() == 0) {

                    return;
                }

                this.data.wellbeingCollection.getAt(0).data.AppropriateServicesForMotherExplained = value;

                this.data.appropriateServicesForMotherExplained = value;
            }
        },
        appropriateServicesProvidedExplained: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.AppropriateServicesProvidedExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.wellbeingCollection.count() == 0) {

                    return;
                }

                this.data.wellbeingCollection.getAt(0).data.AppropriateServicesProvidedExplained = value;

                this.data.appropriateServicesProvidedExplained = value;
            }
        },
        caseReviewId: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.CaseReviewID;
                }

                return result;
            }
        },
        comprehensiveAssessementForMotherExplained: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.ComprehensiveAssessementForMotherExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.wellbeingCollection.count() == 0) {

                    return;
                }

                this.data.wellbeingCollection.getAt(0).data.ComprehensiveAssessementForMotherExplained = value;

                this.data.comprehensiveAssessementForMotherExplained = value;
            }
        },
        comprehensiveAssessementforFatherConductedExplained: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.ComprehensiveAssessementforFatherConductedExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.wellbeingCollection.count() == 0) {

                    return;
                }

                this.data.wellbeingCollection.getAt(0).data.ComprehensiveAssessementforFatherConductedExplained = value;

                this.data.comprehensiveAssessementforFatherConductedExplained = value;
            }
        },
        comprehensiveAssessmentExplained: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.ComprehensiveAssessmentExplained;
                }

                return result;
            }
        },
        fosterParentsProvidedAppropriateServicesExplained: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.FosterParentsProvidedAppropriateServicesExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.wellbeingCollection.count() == 0) {

                    return;
                }

                this.data.wellbeingCollection.getAt(0).data.FosterParentsProvidedAppropriateServicesExplained = value;

                this.data.fosterParentsProvidedAppropriateServicesExplained = value;
            }
        },
        isAgencyAssessEducationNeeds: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsAgencyAssessEducationNeeds;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsAgencyAssessEducationNeeds = value;

                    this.data.isAgencyAssessEducationNeeds = value;
                }
            }
        },
        isAgencyAddressEducationNeeds: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsAgencyAddressEducationNeeds;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsAgencyAddressEducationNeeds = value;

                    this.data.isAgencyAddressEducationNeeds = value;
                }
            }
        },
        isAgencyAssessDentalHealthNeeds: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsAgencyAssessDentalHealthNeeds;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsAgencyAssessDentalHealthNeeds = value;

                    this.data.isAgencyAssessDentalHealthNeeds = value;
                }
            }
        },
        isAgencyAssessEducationNeeds: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsAgencyAssessEducationNeeds;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsAgencyAssessEducationNeeds = value;

                    this.data.isAgencyAssessEducationNeeds = value;
                }
            }
        },
        isAgencyAssessMentalHealthNeeds: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsAgencyAssessMentalHealthNeeds;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsAgencyAssessMentalHealthNeeds = value;

                    this.data.isAgencyAssessMentalHealthNeeds = value;
                }
            }
        },
        isAgencyAssessPhysicalHealthNeeds: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsAgencyAssessPhysicalHealthNeeds;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsAgencyAssessPhysicalHealthNeeds = value;

                    this.data.isAgencyAssessPhysicalHealthNeeds = value;
                }
            }
        },
        isAgencyConcertedEffortsToInvolveTheChild: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsAgencyConcertedEffortsToInvolveTheChild;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsAgencyConcertedEffortsToInvolveTheChild = value;

                    this.data.isAgencyConcertedEffortsToInvolveTheChild = value;
                }
            }
        },
        isAgencyConcertedEffortsToInvolveTheFather: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsAgencyConcertedEffortsToInvolveTheFather;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsAgencyConcertedEffortsToInvolveTheFather = value;

                    this.data.isAgencyConcertedEffortsToInvolveTheFather = value;
                }
            }
        },
        isAgencyConcertedEffortsToInvolveTheMother: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsAgencyConcertedEffortsToInvolveTheMother;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsAgencyConcertedEffortsToInvolveTheMother = value;

                    this.data.isAgencyConcertedEffortsToInvolveTheMother = value;
                }
            }
        },
        isAppropriateServicesForAllPhysicalHealthNeeds: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsAppropriateSerivcesForAllPhysicalHealthNeeds;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsAppropriateSerivcesForAllPhysicalHealthNeeds = value;

                    this.data.isAppropriateSerivcesForAllPhysicalHealthNeeds = value;
                }
            }
        },
        isAppropriateServicesForMentalHealthNeeds: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsAppropriateSerivcesForMentalHealthNeeds;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsAppropriateSerivcesForMentalHealthNeeds = value;

                    this.data.isAppropriateSerivcesForMentalHealthNeeds = value;
                }
            }
        },
        isAppropriateServicesForAllDentalNeeds: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsAppropriateServicesForAllDentalNeeds;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsAppropriateServicesForAllDentalNeeds = value;

                    this.data.isAppropriateServicesForAllDentalNeeds = value;
                }
            }
        },
        isAppropriateServicesForFatherProvided: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsAppropriateServicesForFatherProvided;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsAppropriateServicesForFatherProvided = value;

                    this.data.isAppropriateServicesForFatherProvided = value;
                }
            }
        },
        isAppropriateServicesForMotherProvided: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsAppropriateServicesForMotherProvided;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsAppropriateServicesForMotherProvided = value;

                    this.data.isAppropriateServicesForMotherProvided = value;
                }
            }
        },
        isAppropriateServicesProvided: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsAppropriateServicesProvided;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsAppropriateServicesProvided = value;

                    this.data.isAppropriateServicesProvided = value;
                }
            }
        },
        isComprehensiveAssessementConducted: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsComprehensiveAssessementConducted;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsComprehensiveAssessementConducted = value;

                    this.data.isComprehensiveAssessementConducted = value;
                }
            }
        },
        isComprehensiveAssessementForFatherConducted: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsComprehensiveAssessementForFatherConducted;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsComprehensiveAssessementForFatherConducted = value;

                    this.data.isComprehensiveAssessementForFatherConducted = value;
                }
            }
        },
        isComprehensiveAssessementForMotherConducted: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsComprehensiveAssessementForMotherConducted;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsComprehensiveAssessementForMotherConducted = value;

                    this.data.isComprehensiveAssessementForMotherConducted = value;
                }
            }
        },
        isFosterOversightMedicationForMentalHealtyAppropriate: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsFosterOversightMedicationForMentalHealtyAppropriate;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsFosterOversightMedicationForMentalHealtyAppropriate = value;

                    this.data.isFosterOversightMedicationForMentalHealtyAppropriate = value;
                }
            }
        },
        isFosterOversightMedicationForPhysicalHealtyAppropriate: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsFosterOversightMedicationForPhysicalHealtyAppropriate;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsFosterOversightMedicationForPhysicalHealtyAppropriate = value;

                    this.data.isFosterOversightMedicationForPhysicalHealtyAppropriate = value;
                }
            }
        },
        isFosterParentsProvidedAppropriateServices: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsFosterParentsProvidedAppropriateServices;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsFosterParentsProvidedAppropriateServices = value;

                    this.data.isFosterParentsProvidedAppropriateServices = value;
                }
            }
        },
        isNeedsOfFosterParentsAdequatelyAssessed: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsNeedsOfFosterParentsAdequatelyAssessed;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsNeedsOfFosterParentsAdequatelyAssessed = value;

                    this.data.isNeedsOfFosterParentsAdequatelyAssessed = value;
                }
            }
        },
        isNeedsServicesApplicableForFather: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsNeedsServicesApplicableForFather;
                }

                return result;
            },
            set: function (value) {
                
                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsNeedsServicesApplicableForFather = value;

                    this.data.isNeedsServicesApplicableForFather = value;
                }
            }
        },
        isNeedsServicesApplicableForMother: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsNeedsServicesApplicableForMother;
                }

                return result;
            },
            set: function (value) {
                
                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsNeedsServicesApplicableForMother = value;

                    this.data.isNeedsServicesApplicableForMother = value;
                }
            }
        },
        isResponsiblePartyVisitationFrequencySufficient: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsResponsiblePartyVisitationFrequencySufficient;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsResponsiblePartyVisitationFrequencySufficient = value;

                    this.data.isResponsiblePartyVisitationFrequencySufficient = value;
                }
            }
        },
        isResponsiblePartyVisitationFrequencyWithFatherSufficient: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsResponsiblePartyVisitationFrequencyWithFatherSufficient;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsResponsiblePartyVisitationFrequencyWithFatherSufficient = value;

                    this.data.isResponsiblePartyVisitationFrequencyWithFatherSufficient = value;
                }
            }
        },
        isResponsiblePartyVisitationFrequencyWithMotherSufficient: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsResponsiblePartyVisitationFrequencyWithMotherSufficient;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsResponsiblePartyVisitationFrequencyWithMotherSufficient = value;

                    this.data.isResponsiblePartyVisitationFrequencyWithMotherSufficient = value;
                }
            }
        },
        isResponsiblePartyVisitationQualitySufficient: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsResponsiblePartyVisitationQualitySufficient;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsResponsiblePartyVisitationQualitySufficient = value;

                    this.data.isResponsiblePartyVisitationQualitySufficient = value;
                }
            }
        },
        isResponsiblePartyVisitationQualityWithFatherSufficient: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsResponsiblePartyVisitationQualityWithFatherSufficient;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsResponsiblePartyVisitationQualityWithFatherSufficient = value;

                    this.data.isResponsiblePartyVisitationQualityWithFatherSufficient = value;
                }
            }
        },
        isResponsiblePartyVisitationQualityWithMotherSufficient: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.IsResponsiblePartyVisitationQualityWithMotherSufficient;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.wellbeingCollection.count() == 0) {

                        return;
                    }

                    this.data.wellbeingCollection.getAt(0).data.IsResponsiblePartyVisitationQualityWithMotherSufficient = value;

                    this.data.isResponsiblePartyVisitationQualityWithMotherSufficient = value;
                }
            }
        },
        needsOfFosterParentsAdequatelyAssessedExplained: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.NeedsOfFosterParentsAdequatelyAssessedExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.wellbeingCollection.count() == 0) {

                    return;
                }

                this.data.wellbeingCollection.getAt(0).data.NeedsOfFosterParentsAdequatelyAssessedExplained = value;

                this.data.needsOfFosterParentsAdequatelyAssessedExplained = value;
            }
        },
        responsiblePartyVisitationFrequencyCode: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.ResponsiblePartyVisitationFrequencyCode;
                }

                return result;
            },
            set: function (value) {

                if (this.data.wellbeingCollection.count() == 0) {

                    return;
                }

                this.data.wellbeingCollection.getAt(0).data.ResponsiblePartyVisitationFrequencyCode = value;

                this.data.responsiblePartyVisitationFrequencyCode = value;
            }
        },
        responsiblePartyVisitationFrequencyWithFatherCode: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.ResponsiblePartyVisitationFrequencyWithFatherCode;
                }

                return result;
            },
            set: function (value) {

                if (this.data.wellbeingCollection.count() == 0) {

                    return;
                }

                this.data.wellbeingCollection.getAt(0).data.ResponsiblePartyVisitationFrequencyWithFatherCode = value;

                this.data.responsiblePartyVisitationFrequencyWithFatherCode = value;
            }
        },
        responsiblePartyVisitationFrequencyWithMotherCode: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.ResponsiblePartyVisitationFrequencyWithMotherCode;
                }

                return result;
            },
            set: function (value) {

                if (this.data.wellbeingCollection.count() == 0) {

                    return;
                }

                this.data.wellbeingCollection.getAt(0).data.ResponsiblePartyVisitationFrequencyWithMotherCode = value;

                this.data.responsiblePartyVisitationFrequencyWithMotherCode = value;
            }
        },
        responsiblePartyVisitationQualityExplained: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.ResponsiblePartyVisitationQualityExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.wellbeingCollection.count() == 0) {

                    return;
                }

                this.data.wellbeingCollection.getAt(0).data.ResponsiblePartyVisitationQualityExplained = value;

                this.data.responsiblePartyVisitationQualityExplained = value;
            }
        },
        responsiblePartyVisitationQualityWithFatherExplained: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.ResponsiblePartyVisitationQualityWithFatherExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.wellbeingCollection.count() == 0) {

                    return;
                }

                this.data.wellbeingCollection.getAt(0).data.ResponsiblePartyVisitationQualityWithFatherExplained = value;

                this.data.responsiblePartyVisitationQualityWithFatherExplained = value;
            }
        },
        responsiblePartyVisitationQualityWithMotherExplained: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.ResponsiblePartyVisitationQualityWithMotherExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.wellbeingCollection.count() == 0) {

                    return;
                }

                this.data.wellbeingCollection.getAt(0).data.ResponsiblePartyVisitationQualityWithMotherExplained = value;

                this.data.responsiblePartyVisitationQualityWithMotherExplained = value;
            }
        },
        wellbeingId: {

            get: function () {

                var result;

                if (this.data.wellbeingCollection.count() > 0) {

                    result = this.data.wellbeingCollection.getAt(0).data.WellBeingID;
                }

                return result;
            }
        },        
        //
        // Item applicability
        //
        item12AApplicable: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 14;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].IsApplicable;
                }

                return result;
            },
            set: function (value) {

                if (!isApplicableValue(value)) {

                    return;
                }

                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 14;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].IsApplicable = value;

                this.data.item12AApplicable = value;
            }
        },
        item12AComments: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 14;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].Comments;
                }

                return result;
            },
            set: function (value) {

                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 14;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].Comments = value;

                this.data.item12AComments = value;
            }
        },
        item12BApplicable: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 15;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].IsApplicable;
                }

                return result;
            },
            set: function (value) {

                if (!isApplicableValue(value)) {

                    return;
                }

                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 15;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].IsApplicable = value;

                this.data.item12BApplicable = value;
            }
        },
        item12BComments: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 15;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].Comments;
                }

                return result;
            },
            set: function (value) {

                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 15;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].Comments = value;

                this.data.item12BComments = value;
            }
        },
        item12CApplicable: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 16;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].IsApplicable;
                }

                return result;
            },
            set: function (value) {
                
                if (!isApplicableValue(value)) {

                    return;
                }
                
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 16;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].IsApplicable = value;

                this.data.item12CApplicable = value;
            }
        },
        item12CComments: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 16;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].Comments;
                }

                return result;
            },
            set: function (value) {

                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 16;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].Comments = value;

                this.data.item12CComments = value;
            }
        },
        item13Applicable: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 17;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].IsApplicable;
                }

                return result;
            },
            set: function (value) {

                if (!isApplicableValue(value)) {

                    return;
                }
                
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 17;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].IsApplicable = value;

                this.data.item13Applicable = value;
            }
        },
        item13Comments: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 17;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].Comments;
                }

                return result;
            },
            set: function (value) {

                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 17;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].Comments = value;

                this.data.item13Comments = value;
            }
        },
        item14Applicable: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 18;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].IsApplicable;
                }

                return result;
            },
            set: function (value) {

                if (!isApplicableValue(value)) {

                    return;
                }

                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 18;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].IsApplicable = value;

                this.data.item14Applicable = value;
            }
        },
        item15Applicable: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 19;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].IsApplicable;
                }

                return result;
            },
            set: function (value) {

                if (!isApplicableValue(value)) {

                    return;
                }

                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 19;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].IsApplicable = value;

                this.data.item15Applicable = value;
            }
        },
        item15Comments: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 19;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].Comments;
                }

                return result;
            },
            set: function (value) {

                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 19;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].Comments = value;

                this.data.item15Comments = value;
            }
        },
        item16Applicable: {

            get: function () {

                var result;
                var outcome6 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 6;
                });

                if (outcome6.length == 0) {

                    return;
                }

                var selectedItem = outcome6[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 20;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].IsApplicable;
                }

                return result;
            },
            set: function (value) {

                if (!isApplicableValue(value)) {

                    return;
                }

                var outcome6 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 6;
                });

                if (outcome6.length == 0) {

                    return;
                }

                var selectedItem = outcome6[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 20;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].IsApplicable = value.inputValue;

                this.data.item16Applicable = value.inputValue;
            }
        },
        item16Comments: {

            get: function () {

                var result;
                var outcome6 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 6;
                });

                if (outcome6.length == 0) {

                    return;
                }

                var selectedItem = outcome6[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 20;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].Comments;
                }

                return result;
            },
            set: function (value) {

                var outcome6 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 6;
                });

                if (outcome6.length == 0) {

                    return;
                }

                var selectedItem = outcome6[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 20;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].Comments = value;

                this.data.item16Comments = value;
            }
        },
        item17Applicable: {

            get: function () {

                var result;
                var outcome7 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 7;
                });

                if (outcome7.length == 0) {

                    return;
                }

                var selectedItem = outcome7[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 21;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].IsApplicable;
                }

                return result;
            },
            set: function (value) {

                if (!isApplicableValue(value)) {

                    return;
                }

                var outcome7 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 7;
                });

                if (outcome7.length == 0) {

                    return;
                }

                var selectedItem = outcome7[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 21;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].IsApplicable = value;

                this.data.item17Applicable = value;
            }
        },
        item17Comments: {

            get: function () {

                var result;
                var outcome7 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 7;
                });

                if (outcome7.length == 0) {

                    return;
                }

                var selectedItem = outcome7[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 21;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].Comments;
                }

                return result;
            },
            set: function (value) {

                var outcome7 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 7;
                });

                if (outcome7.length == 0) {

                    return;
                }

                var selectedItem = outcome7[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 21;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].Comments = value;

                this.data.item17Comments = value;
            }
        },
        item18Applicable: {

            get: function () {

                var result;
                var outcome7 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 7;
                });

                if (outcome7.length == 0) {

                    return;
                }

                var selectedItem = outcome7[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 22;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].IsApplicable;
                }

                return result;
            },
            set: function (value) {

                if (!isApplicableValue(value)) {

                    return;
                }

                var outcome7 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 7;
                });

                if (outcome7.length == 0) {

                    return;
                }

                var selectedItem = outcome7[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 22;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].IsApplicable = value;

                this.data.item18Applicable = value;
            }
        },
        item18Comments: {

            get: function () {

                var result;
                var outcome7 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 7;
                });

                if (outcome7.length == 0) {

                    return;
                }

                var selectedItem = outcome7[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 22;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].Comments;
                }

                return result;
            },
            set: function (value) {

                var outcome7 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 7;
                });

                if (outcome7.length == 0) {

                    return;
                }

                var selectedItem = outcome7[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 22;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].Comments = value;

                this.data.item18Comments = value;
            }
        },
        //
        // Item 12 Rating
        //
        item12OverallRating: {

            get: function () {

                var result = itemRatings.getItem12Rating();

                return result;
            },
            set: function (value) {
                
                this.data.item12OverallRating = value;
            }
        },
        outcome1Rating: {

            get: function () {

                var result = outcomeRatings.wellbeing.outcome1.ratingDescription;

                return result;
            },
            set: function (value) {

                if (!Ext.isEmpty(value)) {

                    outcomeRatings.wellbeing.outcome1.ratingCode = value.ratingCode;
                    outcomeRatings.wellbeing.outcome1.outcomeCode = value.outcomeCode;
                    outcomeRatings.wellbeing.outcome1.ratingDescription = value.ratingDescription;

                    this.data.outcome1Rating = value.ratingDescription;
                }
            }
        },
        outcome2Rating: {

            get: function () {

                var result = outcomeRatings.wellbeing.outcome2.ratingDescription;

                return result;
            },
            set: function (value) {

                if (!Ext.isEmpty(value)) {

                    outcomeRatings.wellbeing.outcome2.ratingCode = value.ratingCode;
                    outcomeRatings.wellbeing.outcome2.outcomeCode = value.outcomeCode;
                    outcomeRatings.wellbeing.outcome2.ratingDescription = value.ratingDescription;

                    this.data.outcome2Rating = value.ratingDescription;
                }
            }
        },
        outcome3Rating: {

            get: function () {

                var result = outcomeRatings.wellbeing.outcome3.ratingDescription;

                return result;
            },
            set: function (value) {

                if (!Ext.isEmpty(value)) {

                    outcomeRatings.wellbeing.outcome3.ratingCode = value.ratingCode;
                    outcomeRatings.wellbeing.outcome3.outcomeCode = value.outcomeCode;
                    outcomeRatings.wellbeing.outcome3.ratingDescription = value.ratingDescription;

                    this.data.outcome3Rating = value.ratingDescription;
                }
            }
        },
        // Rating Comments
        //
        item12RatingComments: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 13;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].RatingComments;
                }

                return result;
            },
            set: function (value) {

                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 13;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].RatingComments = value;

                this.data.item12RatingComments = value;
            }
        },
        item12ARatingComments: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 14;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].RatingComments;
                }

                return result;
            },
            set: function (value) {

                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 14;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].RatingComments = value;

                this.data.item12ARatingComments = value;
            }
        },
        item12BRatingComments: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 15;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].RatingComments;
                }

                return result;
            },
            set: function (value) {

                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 15;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].RatingComments = value;

                this.data.item12BRatingComments = value;
            }
        },
        item12CRatingComments: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 16;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].RatingComments;
                }

                return result;
            },
            set: function (value) {

                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 16;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].RatingComments = value;

                this.data.item12CRatingComments = value;
            }
        },
        item13RatingComments: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 17;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].RatingComments;
                }

                return result;
            },
            set: function (value) {

                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 17;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].RatingComments = value;

                this.data.item13RatingComments = value;
            }
        },
        item14RatingComments: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 18;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].RatingComments;
                }

                return result;
            },
            set: function (value) {

                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 18;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].RatingComments = value;

                this.data.item14RatingComments = value;
            }
        },
        item15RatingComments: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 19;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].RatingComments;
                }

                return result;
            },
            set: function (value) {

                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 5;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 19;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].RatingComments = value;

                this.data.item15RatingComments = value;
            }
        },
        item16RatingComments: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 6;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 20;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].RatingComments;
                }

                return result;
            },
            set: function (value) {

                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 6;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 20;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].RatingComments = value;

                this.data.item16RatingComments = value;
            }
        },
        item17RatingComments: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 7;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 21;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].RatingComments;
                }

                return result;
            },
            set: function (value) {

                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 7;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 21;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].RatingComments = value;

                this.data.item17RatingComments = value;
            }
        },
        item18RatingComments: {

            get: function () {

                var result;
                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 7;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 22;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].RatingComments;
                }

                return result;
            },
            set: function (value) {

                var outcome5 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 7;
                });

                if (outcome5.length == 0) {

                    return;
                }

                var selectedItem = outcome5[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 22;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].RatingComments = value;

                this.data.item18RatingComments = value;
            }
        }
    }
});