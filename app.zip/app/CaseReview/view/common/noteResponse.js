﻿Ext.define('App.CaseReview.view.common.noteResponse', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.noteResponse',
    bodyCls: 'panel-background-color',
    margin: '0 20 20 20',
    border: true,
    config: {
        createDate: undefined,
        createBy: undefined,
        response: undefined,
        noteId: undefined,
        responseId: undefined,
        status: undefined,
        extRespId: undefined,
        parentId: undefined,
        noteType: 'item'
    },
    removeFromStore: function (response) {

        var self = this;
        var storeId = response.getNoteType() == 'case' ? 'CR_CaseNote_Response_CollectionStore' : 'CR_Response_CollectionStore';

        var responseStore = Ext.data.ChainedStore.create({
            source: storeId,
            filters: [
                function (record) {
                    return record.data.NoteID == self.getNoteId();
                }
            ]
        });

        Ext.each(responseStore.data.items, function (responseToRemove) {

            if (responseToRemove.data.ResponseID == response.responseId) {

                responseStore.remove(responseToRemove);

                return false;
            }
        });
    },
    items:
    [
        {
            xtype: 'container',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '0 10 0 10',
            layout: 'hbox',
            items: [
                {
                    xtype: 'component',
                    bodyCls: 'panel-background-color',
                    border: false,
                    html: '<strong>Modified Date: </strong>',
                    margin: '0 10 0 0',
                },
                {
                    xtype: 'displayfield',
                    length: 30,
                    margin: '5 20 0 0',
                    listeners: {
                        beforerender: function () {

                            var createDate = this.up('container').up().getCreateDate();
                            var formattedDate = Ext.Date.format(createDate, 'm/d/Y');

                            this.setValue(formattedDate);
                        }
                    }
                },
                {
                    xtype: 'component',
                    bodyCls: 'panel-background-color',
                    border: false,
                    html: '<strong>Modified By: </strong>'
                },
                {
                    xtype: 'displayfield',
                    length: 50,
                    margin: '5 0 0 10',
                    listeners: {
                        beforerender: function () {

                            var creator = this.up('container').up().getCreateBy();

                            this.setValue(creator);
                        }
                    }
                }
            ]
        },
        {
            xtype: 'container',
            bodyCls: 'panel-background-color',
            itemId: 'responseDisplayContainer',
            border: false,
            margin: '0 10 0 10',
            defaults: {
                listeners: {
                    beforerender: function () {

                        var val = this.up().up().getResponse();

                        this.setValue(val);
                    }
                }
            },
            items: [
                {
                    xtype: 'displayfield',
                    itemId: 'responseDisplay',
                    width: '40%'
                }
            ]
        },
        {
            xtype: 'container',
            bodyCls: 'panel-background-color',
            itemId: 'responseCharContainer',
            border: false,
            margin: '0 10 0 350',
            layout: 'hbox',
            componentCls: 'hide-element',
            items: [
                {
                    xtype: 'displayfield',
                    padding: 0,
                    value: '<strong>No. of characters remaining: </strong>'
                },
                {
                    xtype: 'displayfield',
                    margin: '0 10 0 10',
                    itemId: 'responseCharCounter',
                    value: '0'
                }
            ]
        },
        {
            xtype: 'container',
            bodyCls: 'panel-background-color',
            itemId: 'responseEditContainer',
            border: false,
            margin: '0 10 0 10',
            componentCls: 'hide-element',
            layout: 'hbox',
            defaults: {
                listeners: {
                    beforerender: function () {

                        var val = this.up().up().getResponse();

                        this.setValue(val);
                    }
                }
            },
            items: [
                {
                    xtype: 'textarea',
                    itemId: 'responseEdit',
                    width: '40%',
                    allowBlank: false,
                    msgTarget: 'under',
                    maxLength: 10000,
                    grow: true,
                    growMin: 75,
                    growMax: 250,
                    //vtype: 'alphanum',
                    listeners: {
                        beforerender: function (inputElem, eOpts) {

                            var container = this.up().findParentByType('noteResponse');
                            container.queryById('responseCharCounter').setValue(inputElem.maxLength);
                        },
                        change: function (inputElem, newValue, oldValue, eOpts) {

                            var container = this.up().findParentByType('noteResponse');
                            var charsRemaining = inputElem.maxLength - newValue.length;

                            container.queryById('responseCharCounter').setValue(charsRemaining);
                        }
                    }
                },
                {
                    xtype: 'button',
                    text: "<span class='response-button-text-color'>Cancel</span>",
                    width: 80,
                    height: 25,
                    margin: '0 10 10 10',
                    componentCls: 'response-button-color',
                    listeners: {
                        click: {
                            element: 'el',
                            fn: function () {
                                // Get parent container
                                var container = this.component.findParentByType('noteResponse');

                                // Erase changes
                                container.queryById('responseEdit').setValue('');

                                // Display and hide needed elements
                                container.queryById('responseDisplayContainer').setStyle('display', 'block');                                
                                container.queryById('responseEditButton').setStyle('display', 'block');
                                container.queryById('responseDeleteButton').setStyle('display', 'block');
                                container.queryById('responseEditContainer').setStyle('display', 'none');
                                container.queryById('responseCharContainer').setStyle('display', 'none');

                                // Refresh after change in content
                                container.updateLayout();
                            }
                        }
                    }
                },
                {
                    xtype: 'button',
                    text: "<span class='response-button-text-color'>Save</span>",
                    width: 80,
                    height: 25,
                    margin: '0 10 10 0',
                    componentCls: 'response-button-color',
                    listeners: {
                        click: {
                            element: 'el',
                            fn: function () {
                                // Get parent container
                                var container = this.component.findParentByType('noteResponse');

                                // Update comments
                                var newComments = container.queryById('responseEdit').getValue();

                                if (newComments.trim().length > 0)
                                {
                                    container.queryById('responseDisplay').setValue(newComments);
                                    container.setResponse(newComments);

                                    // Erase changes
                                    container.queryById('responseEdit').setValue('');

                                    // Display and hide needed elements
                                    container.queryById('responseDisplayContainer').setStyle('display', 'block');                                    
                                    container.queryById('responseEditButton').setStyle('display', 'block');
                                    container.queryById('responseDeleteButton').setStyle('display', 'block');
                                    container.queryById('responseEditContainer').setStyle('display', 'none');
                                    container.queryById('responseCharContainer').setStyle('display', 'none');

                                    // Refresh after change in content
                                    container.updateLayout();

                                    // Save response to store
                                    if (container.getStatus() == 'new') {
                                        container.setStatus('changed');
                                    }

                                    var parent = container.findParentByType('reviewNote');
                                    
                                    parent.save();

                                    return;
                                }

                                alert("Comments are not valid. Enter valid text!");
                                                                
                            }
                        }
                    }
                }
            ]
        },
        {
            xtype: 'container',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '0 10 10 10',
            layout: 'hbox',
            items: [
                {
                    xtype: 'button',
                    text: "<span class='response-button-text-color'>Edit</span>",
                    icon: editButtonImage,
                    margin: '0 10 0 0',
                    itemId: 'responseEditButton',
                    componentCls: 'response-button-color',
                    listeners: {
                        click: {
                            element: 'el',
                            fn: function () {
                                // Get parent container
                                var container = this.component.findParentByType('noteResponse');

                                container.queryById('responseCharContainer').setStyle('display', 'block');
                                container.queryById('responseEditContainer').setStyle('display', 'block');
                                container.queryById('responseDisplayContainer').setStyle('display', 'none');
                                container.queryById('responseEditButton').setStyle('display', 'none');
                                container.queryById('responseDeleteButton').setStyle('display', 'none');

                                var comments = container.queryById('responseDisplay').getValue();
                                container.queryById('responseEdit').setValue(comments);
                                container.setStatus('changed');

                                container.updateLayout();
                            }
                        }
                    }
                },
                {
                    xtype: 'button',
                    text: "<span class='response-button-text-color'>Delete</span>",
                    icon: deleteButtonImage,
                    itemId: 'responseDeleteButton',
                    margin: '0 10 0 0',
                    componentCls: 'response-button-color',
                    listeners: {
                        click: function () {

                            var container = this.up().up().ownerCt;
                            var response = this.up().up();

                            // Delete response  
                            if (!(response === undefined)) {

                                response.removeFromStore(response);
                                container.remove(response, true);
                            }

                            var parent = container.ownerCt;

                            if (container.items.items.length == 0) {
                                                                
                                parent.remove(container, true);
                            }

                            // Save changes to the store
                            parent.responseToDelete = response;
                            parent.save();
                        }
                    }
                }
            ]
        }
    ]
});