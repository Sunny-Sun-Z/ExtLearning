﻿Ext.define('App.casereview.view.common.SaveButtons', {
    extend: 'Ext.toolbar.Toolbar',
    alias: 'widget.savebuttons',
    dock: 'bottom',
    ui: 'footer',
    fixed: true,
    items: ['->',
        { xtype: 'button', itemId: 'saveCaseButton', text: 'Save', formBind: true },
        { xtype: 'button', itemId: 'saveCaseContinueButton', text: 'Save and Continue', formBind: true },
        { xtype: 'tbspacer', width: 50 }
    ]
});