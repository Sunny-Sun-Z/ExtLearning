﻿Ext.define('App.CaseReview.view.common.SafetyReportHelper',
{
    extend: 'Ext.window.Window',
    itemId: 'safetyReportHelper',
    title: 'Safety Report',
    width: 700,
    layout: 'vbox',

    onShow: function() {
        // Needed for EXT5
        this.callParent(arguments);
        this.center();
    },
    getDockedItems: function(selector, beforeBody) {
        var layout = this.getComponentLayout();
        if (layout.getDockedItems) {
            var dockedItems = layout.getDockedItems('render', beforeBody);
            if (selector && dockedItems.length) {
                dockedItems = Ext.ComponentQuery.query(selector, dockedItems);
            }
            return dockedItems;
        } else {
            return [];
        }
    },    
    scrollable: true,
    height: 500,
    shrinkWrap: true,
    modal: true,
    bodyStyle: 'background:#fff;',
    items: [
    {
        xtype: 'form',
        itemId: 'safetyReportHelperEdit',
        margin: 15,
        layout: 'vbox',
        border: false,
        items: [
        {
            xtype: 'combo',
            flex: 1,
            itemId: 'nameOfChild',
            fieldLabel: 'Name of Child',
            width: 450,
            labelWidth: 150,
            allowBlank: false,
            msgTarget: 'side',
            blankText: 'Please select a child.',
            editable: false,
            store: 'CR_ChildDemographic_CollectionStore',
            displayField: 'Name',
            valueField: 'ChildDemographicID',
            name: 'ChildDemographicID',
            queryMode: 'local',
            tpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '<div class="x-boundlist-item">{Name} {Age}</div>', '</tpl>'),
            displayTpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '{Name} {Age}', '</tpl>')
            //renderer: function (value, p, record) {

            //    var listValue = record.data.Name + ", " + record.data.Age ;
            //    //var Age = null;
            //    //if (!Ext.isEmpty(value) && !Ext.isEmpty(record)) {
            //    //    Age = window.framework.Date.getAge(Ext.util.Format.date(record.data.DateOfBirth,'m/d/Y'));
            //    //    listValue = record.data.Name +", " + Age.Year + " year, " + Age.Month + " months";
            //    //}
            //    return listValue;
            //}
        },
        {
            xtype: 'datefield',
            flex: 1,
            allowBlank: false,
            msgTarget: 'side',
            blankText: 'Please enter a report date that is during the PUR.',
            itemId: 'reportDate',
            fieldLabel: 'Report Date',
            width: 450,
            maxLength: 20,
            labelWidth: 150,
            name: 'ReportDate',
            maxValue: new Date(),
            minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30),
            onExpand: function () {

                var picker = this.getPicker();
                var maxDate = getMaxReportDate();

                if (picker.getValue().valueOf() > maxDate.valueOf()) {

                    picker.setValue(maxDate)
                }
            }
        },
        {
            xtype: 'boundcheckboxgroup',
            itemId: 'CR_SafetyReport_Allegation_Collection',
            store: GetSafetyReportAllegationStore(),
            columns: 1,
            vertical: true,
            inputField: 'SafetyReportAllegationCode',
            fieldLabel: 'Allegation',
            allowBlank: false,
            msgTarget: 'side',
            blankText: 'You have not selected an Allegation. Please select an Allegation for this report.',
            labelWidth: 150,
            items: [
            {
                itemId: 'reportAllegation1',
                boxLabel: 'Physical abuse',
                inputValue: 1
                //,name: 'RaceCode'
            },
            {
                itemId: 'reportAllegation2',
                boxLabel: 'Sexual abuse',
                inputValue: 2
                //,name : 'RaceCode'

            },
            {
                itemId: 'reportAllegation3',
                boxLabel: 'Emotional maltreatment',
                inputValue: 3
                //,name: 'RaceCode'
            },
            {
                itemId: 'reportAllegation4',
                boxLabel: 'Neglect (not including medical neglect)',
                inputValue: 4
                //,name: 'RaceCode'

            },
            {
                itemId: 'reportAllegation5',
                boxLabel: 'Medical neglect',
                inputValue: 5
                //,name: 'RaceCode'
            },
            {
                itemId: 'reportAllegation6',
                boxLabel: 'Abandonmnet',
                inputValue: 6
                //,name: 'RaceCode'
            },
            {
                itemId: 'reportAllegation7',
                boxLabel: 'Mental/physical health of parent',
                inputValue: 7
                //,name: 'RaceCode'
            },
            {
                itemId: 'reportAllegation8',
                boxLabel: 'Mental/physical health of child',
                inputValue: 8
                //,name: 'RaceCode'
            },
            {
                itemId: 'reportAllegation9',
                boxLabel: 'Substance abuse by parent(s)',
                inputValue: 9
                //,name: 'RaceCode'
            },
            {
                itemId: 'reportAllegation10',
                boxLabel: 'Child\'s behavior',
                inputValue: 10
                //,name: 'RaceCode'
            },
            {
                itemId: 'reportAllegation11',
                boxLabel: 'Substance abuse by child',
                inputValue: 11
                //,name: 'RaceCode'
            },
            {
                itemId: 'reportAllegation12',
                boxLabel: 'Domestic violence in child\'s home',
                inputValue: 12
                //,name: 'RaceCode'
            },
            {
                itemId: 'reportAllegation13',
                boxLabel: 'Child in juvenile justice system',
                inputValue: 13
                //,name: 'RaceCode'
            },
            {
                itemId: 'reportAllegation14',
                boxLabel: 'Other (specify)',
                inputValue: 14,
                listeners: {
                    'change': function (checkbox, newValue, oldValue) {
                        if (newValue) {
                            Ext.ComponentQuery.query('#OtherAllegation')[0].allowBlank = false;
                            Ext.ComponentQuery.query('#OtherAllegation')[0].setDisabled(false);
                        } else {
                            Ext.ComponentQuery.query('#OtherAllegation')[0].allowBlank = true;
                            Ext.ComponentQuery.query('#OtherAllegation')[0].setDisabled(true);
                            Ext.ComponentQuery.query('#OtherAllegation')[0].setValue(null);
                        }
                    }
                }
            }

            ]
            },
        {
                xtype: 'textarea',
                itemId: 'OtherAllegation',
                labelWidth: 150,
                width: 500,
                fieldLabel: 'Allegation(Other)',
                name: 'AllegationOther',
                maxLength: 100,
                disabled : true,
                enforceMaxLength: true,
                msgTarget: 'side',
                blankText: ' For Allegation, please fill out the narrative field for a response of Other.'

            },
        {
                xtype: 'combo',
                itemId: 'PriorityLevel',
                labelWidth: 150,
                width: 350,
                fieldLabel: 'Priority Level',
                name: 'PriorityLevel',
                store: 'PriorityLevelStore',
                displayField: 'DescriptionLarge',
                valueField: 'GroupID',
                allowBlank: false,
                msgTarget: 'side',
                queryMode: 'local',
                blankText: 'You have not selected Assessment or Investigation. Please select Assessment or Investigation for this report.'
            },
            {
                xtype: 'combo',
                itemId: 'AssesmenntInvestigation',
                editable: false,
                fieldLabel: 'Assessment or Investigation',
                width: 450,
                labelWidth: 200,
                store: 'AssessmentTypeStore',
                displayField: 'DescriptionLarge',
                valueField: 'GroupID',
                name: 'AssessmentCode',
                allowBlank: false,
                msgTarget: 'side',
                queryMode: 'local',
                blankText: 'You have not selected Assessment or Investigation. Please select Assessment or Investigation for this report.'
            },
            {
                layout: 'hbox',
                margin : '10 0 0 0',
                items: [
                    {
                        xtype: 'datefield',
                        itemId : 'dateAssignedforInvestigationOrAssessment',
                        fieldLabel: 'Date Assigned for an Investigation or Assessment',
                        labelWidth: 300,
                        name: 'DateAssessmentAssigned',
                        maxValue: new Date(),
                        minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30),
                        allowBlank: false,
                        msgTarget: 'side',
                        blankText: 'Please select either a date or Did not occur.'
                    },
                    {

                        xtype: 'checkbox',
                        fieldLabel: 'Did not occur',
                        itemId : 'isAssigned',
                        margin: '0 0 0 10',
                        name: 'IsAssigned',
                        inputValue: 1,
                        uncheckedValue: 2
                        //,listeners: {
                        //    'change': function (checkbox, newValue, oldValue) {
                        //        if (newValue) {
                        //            Ext.ComponentQuery.query('#dateAssignedforInvestigationOrAssessment')[0].allowBlank = true;

                        //        } else {
                        //            Ext.ComponentQuery.query('#dateAssignedforInvestigationOrAssessment')[0].allowBlank = false;
                        //            }
                        //    }
                        //}
                    }
                ]

            },
            {
                layout: 'hbox',
                margin: '10 0 0 0',
                items: [
                    {
                        xtype: 'datefield',
                        itemId: 'dateInvestigationOrAssessmentInitiated',
                        fieldLabel: 'Date Investigation or Assessment Initiated',
                        labelWidth: 300,
                        name: 'DateAssessmentInitiated',
                        maxValue: new Date(),
                        minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30),
                        allowBlank: false,
                        msgTarget: 'side',
                        blankText: 'Please select either a date or Did not occur.'
                    },
                    {
                        xtype: 'checkbox',
                        fieldLabel: 'Did not occur',
                        itemId : 'isInitiated',
                        margin: '0 0 0 10',
                        name: 'IsInitiated',
                        inputValue: 1,
                        uncheckedValue: 2
                        //,listeners: {
                        //'change': function (checkbox, newValue, oldValue) {
                        //    if (newValue) {
                        //        Ext.ComponentQuery.query('#dateInvestigationOrAssessmentInitiated')[0].allowBlank = true;
                        //        } else {
                        //        Ext.ComponentQuery.query('#dateInvestigationOrAssessmentInitiated')[0].allowBlank = false;
                        //        }
                        //    }
                        //}
                    }
                ]

            },
            {
                layout: 'hbox',
                margin: '10 0 0 0',
                items: [
                    {
                        xtype: 'datefield',
                        itemId: 'dateFaceToFace',
                        labelWidth: 300,
                        fieldLabel: 'Date of Face-to-Face Contact with Child',
                        name: 'DateFaceToFaceContact',
                        maxValue: new Date(),
                        minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30),
                        allowBlank: false,
                        msgTarget: 'side',
                        blankText: 'Please select either a date or Did not occur.'
                    },
                    {
                        xtype: 'checkbox',
                        fieldLabel: 'Did not occur',
                        margin: '0 0 0 10',
                        name: 'IsFaceToFaceContact',
                        itemId: 'isFaceToFaceContact',
                        inputValue: 1,
                        uncheckedValue: 2
                        //,listeners: {
                        //    'change': function (checkbox, newValue, oldValue) {
                        //        if (newValue) {
                        //            Ext.ComponentQuery.query('#dateFaceToFace')[0].allowBlank = true;
                        //            } else {
                        //            Ext.ComponentQuery.query('#dateFaceToFace')[0].allowBlank = false;
                        //            }
                        //     }
                        //}
                    }
                ]

            },
            {
                xtype: 'combo',
                flex: 1,
                itemId: 'perpetratorChildRelationshipCode',
                editable: false,
                fieldLabel: 'RelationShip of Alleged Perperator to Child',
                width: 450,
                labelWidth: 250,
                name: 'PerpetratorChildRelationshipCode',
                store: 'PerpetratorChildRelationshipStore',
                displayField: 'DescriptionLarge',
                valueField: 'GroupID',
                allowBlank: false,
                msgTarget: 'side',
                blankText: 'You have not selected the Relationship of Alleged Perpetrator to Child. Please select the Relationship of Alleged Perpetrator to Child for this report',
                queryMode: 'local',
                listeners : {
                    change: function (combo, newValue, oldValue) {
                        if (newValue == 7) {// Other
                            Ext.ComponentQuery.query('#perpetratorChildRelationshipOther')[0].allowBlank = false;
                            Ext.ComponentQuery.query('#perpetratorChildRelationshipOther')[0].setDisabled(false);;
                        } else {
                            Ext.ComponentQuery.query('#perpetratorChildRelationshipOther')[0].allowBlank = true;
                            Ext.ComponentQuery.query('#perpetratorChildRelationshipOther')[0].setDisabled(true);
                            Ext.ComponentQuery.query('#perpetratorChildRelationshipOther')[0].setValue(null);
                        }
                    }
                }
            },
            {
                xtype: 'textarea',
                labelWidth: 250,
                width: 600,
                flex: 1,
                fieldLabel: 'Relationship of Alleged Perpetrator to Child(Other)',
                name: 'PerpetratorChildRelationshipOther',
                itemId: 'perpetratorChildRelationshipOther',
                maxLength: 100,
                enforceMaxLength: true,
                msgTarget: 'side',
                disabled : true,
                blankText: 'For Relationship of Alleged Perpetrator to Child, please fill out the narrative field for a response of Other'

            },
            {
                xtype: 'combo',
                flex: 1,
                itemId: 'DispositionCode',
                fieldLabel: 'DispositionCode',
                width: 450,
                labelWidth: 150,
                name: 'DispositionCode',
                editable: false,
                store: 'DispositionStore',
                displayField: 'DescriptionLarge',
                valueField: 'GroupID',
                allowBlank: false,
                queryMode: 'local',
                msgTarget: 'side',
                blankText: 'You have not selected the DispositionCode. Please select the DispositionCode of this report'

            },
            {
                xtype: 'container',
                layout: 'hbox',
                items: [
                    {
                        xtype: 'button',
                        flex: 1,
                        align: 'right',
                        width: '100px',
                        text: 'Cancel',
                        itemId: 'unitCancel',
                        margin: '15 0 0 170',
                        padding: '5 5 5 5',
                        icon: window.baseUrl + '/content/icons/cross-small.png'
                    }, {
                        xtype: 'button',
                        flex: 1,
                        align: 'right',
                        style: 'float:right',
                        width: '150px',
                        text: 'Add/Update',
                        itemId: 'unitSave',
                        margin: '15 0 0 10',
                        padding: '5 5 5 5',
                        icon: window.baseUrl + '/content/icons/database_add.png'                        
                    }

                ]
            }]
    }
    ]

});