﻿/**
 * Applies drag handles to an element or component to make it resizable. 
 *
**/

Ext.define('App.CaseReview.view.common.CustomResizer', {
    extend: 'Ext.resizer.Resizer',
    alias: 'widget.customResizer',

    constructor: function (config) {

        var me = this,
            handles = me.handles,
            unselectableCls = Ext.dom.Element.unselectableCls,
            handleEls = [],
            handleDefs = [],
            resizeTarget, handleCls, possibles, tag,
            len, i, pos, el, box,
            wrapTarget, positioning, targetBaseCls;


        if (Ext.isString(config) || Ext.isElement(config) || config.dom) {

            resizeTarget = config;
            config = arguments[1] || {};
            config.target = resizeTarget;
        }

        // will apply config to this 
        me.mixins.observable.constructor.call(me, config);

        // If target is a Component, ensure that we pull the element out. 
        // Resizer must examine the underlying Element. 
        resizeTarget = me.target;

        if (resizeTarget) {
            if (resizeTarget.isComponent) {

                // Resizable Components get a new UI class on them which makes them overflow:visible 
                // if the border width is non-zero and therefore the SASS has embedded the handles 
                // in the borders using -ve position. 
                resizeTarget.addClsWithUI('resizable');

                if (resizeTarget.minWidth) {
                    me.minWidth = resizeTarget.minWidth;
                }
                if (resizeTarget.minHeight) {
                    me.minHeight = resizeTarget.minHeight;
                }
                if (resizeTarget.maxWidth) {
                    me.maxWidth = resizeTarget.maxWidth;
                }
                if (resizeTarget.maxHeight) {
                    me.maxHeight = resizeTarget.maxHeight;
                }
                if (resizeTarget.floating) {
                    if (!me.hasOwnProperty('handles')) {
                        me.handles = 'n ne e se s sw w nw';
                    }
                }
                me.el = resizeTarget.getEl();
            } else {
                resizeTarget = me.el = me.target = Ext.get(resizeTarget);
            }
        }
            // Backwards compatibility with Ext3.x's Resizable which used el as a config. 
        else {
            resizeTarget = me.target = me.el = Ext.get(me.el);
        }

        // Locally enforce border box model. 
        // https://sencha.jira.com/browse/EXTJSIV-11511 
        me.el.addCls(Ext.Component.prototype.borderBoxCls);

        // Constrain within configured maxima 
        if (Ext.isNumber(me.width)) {

            me.width = Ext.Number.constrain(me.width, me.minWidth, me.maxWidth);
        }

        if (Ext.isNumber(me.height)) {

            me.height = Ext.Number.constrain(me.height, me.minHeight, me.maxHeight);
        }

        // Size the target. 
        if (me.width !== null || me.height !== null) {

            me.target.setSize(me.width, me.height);
        }

        // Tags like textarea and img cannot 
        // have children and therefore must 
        // be wrapped 
        tag = me.el.dom.tagName.toUpperCase();

        if (tag == 'DIV') {

            if (!Ext.isEmpty(me.el.component)) {

                var tagName = me.el.component.xtype.toUpperCase();

                if (tagName === 'TEXTAREA') {

                    tag = 'TEXTAREA';
                }
            }
        }

        if (tag === 'TEXTAREA' || tag === 'IMG' || tag === 'TABLE') {
            /**
             * @property {Ext.dom.Element/Ext.Component} originalTarget
             * Reference to the original resize target if the element of the original resize target was a
             * {@link Ext.form.field.Field Field}, or an IMG or a TEXTAREA which must be wrapped in a DIV.
             */
            me.originalTarget = me.target;

            wrapTarget = resizeTarget.isComponent ? resizeTarget.getEl() : resizeTarget;

            // Tag the wrapped element with a class so thaht we can force it to use border box sizing model 
            me.el.addCls(me.wrappedCls);

            me.target = me.el = me.el.wrap({
                role: 'presentation',
                cls: me.wrapCls,
                id: me.el.id + '-rzwrap',
                style: wrapTarget.getStyle(['margin-top', 'margin-bottom'])
            });

            positioning = wrapTarget.getPositioning();

            // Transfer originalTarget's positioning+sizing+margins 
            me.el.setPositioning(positioning);

            me.isTargetWrapped = true;
        }

        // Position the element, this enables us to absolute position 
        // the handles within this.el 
        me.el.position();

        if (me.pinned) {
            me.el.addCls(me.pinnedCls);
        }

        /**
         * @property {Ext.resizer.ResizeTracker} resizeTracker
         */
        me.resizeTracker = new Ext.resizer.ResizeTracker({
            disabled: me.disabled,
            target: resizeTarget,
            el: me.el,
            constrainTo: me.constrainTo,
            handleCls: me.handleCls,
            overCls: me.overCls,
            throttle: me.throttle,

            // If we have wrapped something, instruct the ResizerTracker to use that wrapper as a proxy 
            // and we should resize the wrapped target dynamically. 
            proxy: me.originalTarget ? me.el : null,
            dynamic: me.originalTarget ? true : me.dynamic,

            originalTarget: me.originalTarget,
            delegate: '.' + me.handleCls,
            preserveRatio: me.preserveRatio,
            heightIncrement: me.heightIncrement,
            widthIncrement: me.widthIncrement,
            minHeight: me.minHeight,
            maxHeight: me.maxHeight,
            minWidth: me.minWidth,
            maxWidth: me.maxWidth
        });

        // Relay the ResizeTracker's superclass events as our own resize events 
        me.resizeTracker.on({
            mousedown: me.onBeforeResize,
            drag: me.onResize,
            dragend: me.onResizeEnd,
            scope: me
        });

        if (me.handles === 'all') {
            me.handles = 'n s e w ne nw se sw';
        }

        handles = me.handles = me.handles.split(me.delimiterRe);
        possibles = me.possiblePositions;
        len = handles.length;

        handleCls = me.handleCls + ' ' + me.handleCls + '-{0}';
        if (me.target.isComponent) {
            targetBaseCls = me.target.baseCls;
            handleCls += ' ' + targetBaseCls + '-handle ' + targetBaseCls + '-handle-{0}';
            if (Ext.supports.CSS3BorderRadius) {
                handleCls += ' ' + targetBaseCls + '-handle-{0}-br';
            }
        }

        for (i = 0; i < len; i++) {
            // if specified and possible, create 
            if (handles[i] && possibles[handles[i]]) {
                pos = possibles[handles[i]];

                handleDefs.push(
                    '<div id="', me.el.id, '-', pos, '-handle" class="', Ext.String.format(handleCls, pos), ' ', unselectableCls,
                        '" unselectable="on" role="presentation"',
                    '></div>'
                );
            }
        }
        Ext.DomHelper.append(me.el, handleDefs.join(''));

        // Let's reuse the handleEls stack to collect the actual els. 
        handleEls.length = 0;

        // store a reference to each handle element in this.east, this.west, etc 
        for (i = 0; i < len; i++) {
            // if specified and possible, create 
            if (handles[i] && possibles[handles[i]]) {
                pos = possibles[handles[i]];
                el = me[pos] = me.el.getById(me.el.id + '-' + pos + '-handle');
                handleEls.push(el);
                el.region = pos;

                if (me.transparent) {
                    el.setOpacity(0);
                }
            }
        }

        me.resizeTracker.handleEls = handleEls;

        me.resizeTo(me.resizeTracker.el.dom.clientWidth, me.resizeTracker.el.dom.clientHeight);
    }
});