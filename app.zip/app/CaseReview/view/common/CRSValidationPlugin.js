﻿Ext.define('App.CaseReview.view.common.CRSValidationPlugin', {
    extend: 'Ext.plugin.Abstract',
    alias: 'plugin.crsValidationPlugin',
    config: {        
        storeId: undefined,
        itemCode: undefined,
        validationRoutine: undefined,
        getBlankRecords: function (columns, store) {

            var items = store.data.items;
            var blankRecords = [];

            Ext.each(items, function (item) {
                var isEmpty = false;
                var emptyRow = [];

                Ext.each(columns, function (column) {
                    if (item.data[column] == 0 || item.data[column] == "" || item.data[column] == null) {

                        emptyRow.push(true);
                    }
                });

                if (emptyRow.length == columns.length) {
                    isEmpty = true;
                }

                if (isEmpty) {
                    blankRecords.push(item);
                }
            });

            return blankRecords;
        },
        validationType: undefined,
        validationInput: [],
        validateQANote: function(){
            var result = [];
            var input = this.getValidationInput();

            Ext.each(input, function (note) {
                var vResult = {};
                
                // QA note needs to have a subject
                if (note.getSubject().trim().length == 0) {

                    vResult['errObject'] = note;
                    vResult['subject'] = 'Please specify a subject.';
                }

                // QA note needs to have a message
                if (note.getText().trim().length == 0) {

                    if (vResult.errObject == undefined) {
                        vResult['errObject'] = note;
                    }

                    vResult['text'] = 'Please specify a QA Note.';
                }

                if (!(vResult.errObject == undefined)) {
                    result.push(vResult);
                }
            });

            return result;
        },
        validateRatingOverride: function () {
            var result = [];
            var input = this.getValidationInput();

            Ext.each(input, function (ratingOverride) {
                var vResult = {};
                var boxChecked = true;

                // An item rating cannot be overridden unless the box is checked. 
                if (!(ratingOverride.getOverrideInd() == ratingOverride.items[0].items[1].inputValue)) {

                    vResult['errObject'] = ratingOverride;
                    vResult['overrideInd'] = 'Please do not indicate an overridden rating unless you check the box.';
                    boxChecked = false;
                }

                // An override reason cannot be given unless the box is checked.
                if (ratingOverride.getOverrideReason().trim().length > 0 && !boxChecked) {

                    if (vResult.errObject == undefined) {
                        vResult['errObject'] = ratingOverride;                        
                    }

                    vResult['overrideReason'] = 'Please do not indicate an overridden reason unless you check the box.';
                }

                // An item rating cannot be overridden without also indicating the override reason.
                if ((boxChecked) && ratingOverride.getOverrideReason().trim().length == 0) {
                    if (vResult.errObject == undefined) {
                        vResult['errObject'] = ratingOverride;
                    }

                    vResult['overrideReason'] = 'Please provide the override reason.';
                }

                // An item cannot be overridden to the same item. 
                var isNewRatingSame = function () {
                    var ratingItems = this.down('newRating').items;
                    var retval = false;

                    Ext.each(ratingItems, function (item) {
                        if (item.getValue() == item.inputValue) {
                            if (item.boxLabel.indexOf(ratingOverride.getCurrentRating()) > -1) {
                                retval = true;

                                return false;
                            }
                        }
                    });

                    return retval;
                };

                if (isNewRatingSame()) {
                    if (vResult.errObject == undefined) {
                        vResult['errObject'] = ratingOverride;
                    }

                    vResult['overrideRating'] = 'Please select a rating that is different from the calculated rating.';
                }

                // An override reason cannot be saved without also indicating the override rating. 
                var ratingItems = this.down('newRating').items;
                var ratingSelected = false;

                Ext.each(ratingItems, function (item) {
                    if (item.getValue() == item.inputValue) {
                        ratingSelected = true;

                        return false;
                    }
                });

                if (!(ratingSelected)) {
                    if (vResult.errObject == undefined) {
                        vResult['errObject'] = ratingOverride;
                    }

                    vResult['overrideRating'] = 'Please select the overridden rating.';
                }
                // Add to array if any field is invalid
                if (!(vResult.errObject == undefined)) {
                    result.push(vResult);
                }
            });

            return result;
        },
        validateCaseElimination: function () {
            var self = this;
            var result = [];
            var input = this.getValidationInput();

            Ext.each(input, function (itemId) {
                var vResult = {};
                var reason = '';

                if (itemId == 'eliminateReason') {
                    var eliminateCaseObj = self.cmp.queryById(itemId);

                    if (!(eliminateCaseObj == null)) {
                        reason = eliminateCaseObj.items.items[0].getValue();

                        // A case cannot be eliminated without providing a reason.
                        if (reason == null) {
                            if (vResult.errObject == undefined) {
                                vResult['errObject'] = eliminateCaseObj;
                            }

                            vResult['reason'] = 'Please select a Reason.';

                        } else {

                            var eliminateTextObj = self.cmp.queryById('reasonExplanation');
                            var explanation = eliminateTextObj.items.items[0].getValue();
                            explanation = explanation == null ? '' : explanation.trim();

                            // If "Case should not be in the sample" is selected for 
                            // Reason Case Eliminated, a reason must be provided in the 
                            // following narrative field.
                            if (explanation.length == 0 && reason == 'Case should not in the sample') {
                                if (vResult.errObject == undefined) {
                                    vResult['errObject'] = eliminateTextObj;
                                }

                                vResult['explanation'] = 'Please enter reason case should not be included in the sample.';
                            }
                        }
                    }                    
                }

                if (!(vResult.errObject == undefined)) {
                    result.push(vResult);
                }
            });

            return result;
        },
        validateCaseSetup: function () {
            var self = this;
            var result = [];
            var startDateObj;
            var input = this.getValidationInput();

            Ext.each(input, function (itemId) {
                var vResult = {};
                var reason = '';
                var component = self.cmp.queryById(itemId);

                // Site (question A) is a required field. 
                if (itemId == 'stateName') {

                    var filteredItems = component.items.items.filter(function (item) {

                        return item.xtype == 'combobox';
                    });

                    var siteName = filteredItems[0].getValue();
                    siteName = siteName == null ? '' : siteName.trim();

                    if (siteName.length == 0) {
                        if (vResult.errObject == undefined) {
                            vResult['errObject'] = component;
                        }

                        vResult['siteName'] = 'Please select a site.';
                    }
                }
                // Case name (question B) is a required field. 
                if (itemId == 'caseNamePanel') {
                    var caseName = component.items.items[0].getValue();
                    caseName = caseName == null ? '' : caseName.trim();

                    if (caseName.length == 0) {
                        if (vResult.errObject == undefined) {
                            vResult['errObject'] = component;
                        }

                        vResult['caseName'] = 'Please specify a case name.';
                    }
                }
                // PUR start date (question C) is a required field. 
                if (itemId == 'revStartDate') {

                    var filteredItems = component.items.items.filter(function (item) {

                        return item.xtype == 'datefield';
                    });

                    startDate = filteredItems[0].getValue();
                    startDate = Ext.isEmpty(startDate) ? '' : startDate.trim();

                    if (startDate.length == 0) {
                        if (vResult.errObject == undefined) {
                            vResult['errObject'] = component;
                        }

                        vResult['reviewStartDate'] = 'Please enter the PUR start date.';
                    } else {
                        // PUR start date (question C) cannot begin in the future.
                        startDateObj = new Date(startDate);
                        var today = new Date();

                        if (startDateObj > today) {
                            if (vResult.errObject == undefined) {
                                vResult['errObject'] = component;
                            }

                            vResult['reviewStartDate'] = 'Please enter a PUR start date that is not a future date.';
                        }
                    }                    
                }
                // Reviewer name (question D) is a required field. 
                if (itemId == 'reviewers') {
                    var reviewer = component.items.items[0].getValue();
                    reviewer = reviewer == null ? '' : reviewer;

                    if (reviewer.length == 0) {
                        if (vResult.errObject == undefined) {
                            vResult['errObject'] = component;
                        }

                        vResult['reviewer'] = 'Please specify the reviewer name(s).';
                    }
                }
                // Date case review was completed (question E)is a required field. 
                if (itemId == 'reviewCompletedDate') {
                    var endDate = component.items.items[0].getValue();
                    endDate = endDate == null ? '' : endDate.trim();

                    if (endDate.length == 0) {
                        if (vResult.errObject == undefined) {
                            vResult['errObject'] = component;
                        }

                        vResult['reviewCompletedDate'] = 'Please specify the date case review was completed.';
                    } else {
                        // Date case review was completed (question E)must be after the PUR start date.
                        var endDateObj = new Date(endDate);

                        if (!(endDateObj > startDateObj)) {
                            if (vResult.errObject == undefined) {
                                vResult['errObject'] = component;
                            }

                            vResult['reviewCompletedDate'] = 'Please enter a date the case review was completed that is after the date in question C.';
                        }
                    }
                }
                // Case type (question F) is a required field. 
                if (itemId == 'caseType') {
                    var caseType = component.items.items[0].getValue();
                    caseType = Ext.isEmpty(caseType) ? '' : caseType;

                    if (caseType.length == 0) {
                        if (vResult.errObject == undefined) {
                            vResult['errObject'] = component;
                        }

                        vResult['caseType'] = 'Please select type of case.';
                    }
                }

                if (!(vResult.errObject == undefined)) {
                    result.push(vResult);
                }
            });

            return result;
        },
        canDeleteChild: function (value) {
            var self = this;
            var result = {};
            var store = Ext.data.StoreManager.lookup(self.getStoreId());
            
            result['canDelete'] = true;

            // If there is only one row saved to table G1, 
            // that row can be edited but not deleted.
            if (store.data.length == 1) {
                result['canDelete'] = false;
                result['message'] = 'This row cannot be deleted from table G1. Please click on the child\'s name to edit.';

                return result;
            }

            // Is child referenced in table 1A1
            var isChildReferencedIn1A1 = function () {
                var lookupStore = chainedStore('CR_ChildDemographic_CollectionStore');
                var results = lookupStore.query('ChildDemographicID', value, false, false, true);

                // A row cannot be deleted from table G1 if the child is already 
                // referenced in item 1 table 1A1.
                if (results.length > 0) {
                    result['canDelete'] = false;
                    result['message'] = 'Child cannot be deleted because this child is referenced in item 1 table 1A1.';
                }

                return result;
            }

            if (!(isChildReferencedIn1A1().canDelete)) {
                return result;
            }

            return result;
        },
        canDeleteParticipant: function (value) {
            var self = this;
            var result = {};
            var store = Ext.data.StoreManager.lookup(self.getStoreId());

            result['canDelete'] = true;

            // If there is only one row saved to table G2, 
            // that row can be edited but not deleted.
            if (store.data.length == 1) {
                result['canDelete'] = false;
                result['message'] = 'This row cannot be deleted from table G2. Please click on the participant\'s name to edit.';

                return result;
            }

            return result;
        },
        isValueValid: function(value, validValues){
            var result = false;

            Ext.each(validValues, function (validValue) {
                if (value == validValue) {
                    result = true;

                    return false;
                }
            });

            return result;
        },
        getTargetChild: function(){
            var store = Ext.data.StoreManager.lookup('CR_ChildDemographic_CollectionStore');
            var targetChild;

            Ext.each(store.data.items, function (row) {
                if (row.data.IsTargetChild == 1) {
                    targetChild = row;

                    return false;
                }
            });

            return targetChild;
        },
        getSafeDate: function(store,propertyName){
            
            var computedDate;

            if (!Ext.isEmpty(store)) {

                if (store.data.length > 0) {
                    computedDate = store.data.items[0].get(propertyName);
                }
            }
            
            return computedDate == undefined ? new Date() : new Date(computedDate);
        },
        getReviewStartDate: function () {
            var self = this;
            var store = Ext.data.StoreManager.lookup('CaseReviewStore');
            
            return self.getSafeDate(store, 'ReviewStartDate');
        },
        getReviewEndDate: function () {
            var self = this;
            var store = Ext.data.StoreManager.lookup('CaseReviewStore');
            
            return self.getSafeDate(store, 'ReviewCompleted');
        },
        getFosterCareEntryDate: function(){
            var self = this;

            //var store = Ext.data.StoreManager.lookup(self.getStoreId());
            var store = findStore(self.getStoreId());
            
            return self.getSafeDate(store, 'FosterEntryDate');
        },
        getCaseOpenDate: function () {
            var self = this;

            var store = Ext.data.StoreManager.lookup('CR_FaceSheet_CollectionStore');
            
            return self.getSafeDate(store, 'FirstCaseOpeningDate');
        },
        getCheckBoxGroup: function(storeId,groupName){
            
            var store = Ext.data.ChainedStore.create({
                source: storeId,
                filters: [
                    function (record) {
                        return record.data.GroupName == groupName;
                    }
                ]
            });

            return store.data;            
        },
        getCheckboxSelections: function(itemId){

            var checkboxes = getCRSComponent(itemId).items.items;
            selections = checkboxes.filter(function (chkbox) {

                return chkbox.checked == true;
            });

            return selections;
        },
        getLocationConcerns: function (pType) {

            var checkBoxes;
            var filteredConcerns = [];
            
            if (Ext.isEmpty(pType)) {

                return filteredConcerns;
            }

            if (pType == 'Mother') {

                if (Ext.isEmpty(getAppController().getMotherEfforts)) {
                    
                    return filteredConcerns;
                }
            }

            if (pType == 'Father') {

                if (Ext.isEmpty(getAppController().getFatherEfforts)) {

                    return filteredConcerns;
                }
            }
            
            checkBoxes = pType == 'Mother' ? getAppController().getMotherEfforts().items.items :
                         pType == 'Father' ? getAppController().getFatherEfforts().items.items : [];                         

            filteredConcerns = checkBoxes.filter(function (concern) {

                return concern.checked;
            });

            return filteredConcerns;
        },
        getDuplicateRows: function(store, row, id){

            var duplicateRows = [];
            var chainedStore;

            var isDuplicateRow = function (row) {

                if (id == 'table1A1')
                {
                    chainedStore = Ext.data.ChainedStore.create({
                        source: store,
                        filters: [
                            function (record) {
                                return (record.data.ReportDate == row.data.ReportDate &&
                                        record.data.ChildDemographicID == row.data.ChildDemographicID &&
                                        record.data.SafetyReportAllegationCode == row.data.SafetyReportAllegationCode &&
                                        record.data.PerpetratorChildRelationshipCode == row.data.PerpetratorChildRelationshipCode &&
                                        record.data.DispositionCode == row.data.DispositionCode)
                            }
                        ]
                    });
                }
                
                if (chainedStore.data.length > 1) {
                    duplicateRows.push(chainedStore);
                }
            }

            isDuplicateRow(row);

            return duplicateRows;
        },
        isFosterCareCase: function(){

            var store = Ext.data.StoreManager.lookup('CaseReviewStore');            
            var result = false;
            
            if (store.data.length > 0) {
                var caseTypeId = store.getAt(0).data.ReviewSubTypeID;

                if (caseTypeId == 18 || caseTypeId == 20) {
                    result = true;
                }
            }            

            return result;
        },
        isJuvenileJusticeCase: function () {

            var store = Ext.data.StoreManager.lookup('CaseReviewStore');
            var result = false;

            if (store.data.length > 0) {
                var caseTypeId = store.getAt(0).data.ReviewSubTypeID;

                if (caseTypeId == 23) {
                    result = true;
                }
            }

            return result;
        },
        isBehavioralHealthCase: function () {

            var store = Ext.data.StoreManager.lookup('CaseReviewStore');
            var result = false;

            if (store.data.length > 0) {
                var caseTypeId = store.getAt(0).data.ReviewSubTypeID;

                if (caseTypeId == 24) {
                    result = true;
                }
            }

            return result;
        },
        isInHomeCase: function () {

            var store = Ext.data.StoreManager.lookup('CaseReviewStore');
            var result = false;

            if (store.data.length > 0) {
                var caseTypeId = store.getAt(0).data.ReviewSubTypeID;

                if (caseTypeId == 17 || caseTypeId == 19 || caseTypeId == 21 || caseTypeId == 22) {
                    result = true;
                }
            }

            return result;
        },
        isCaseDischarged: function () {
            var self = this;
            var store = Ext.data.StoreManager.lookup(self.getStoreId());            
            var result = false;
            
            if (store.data.length > 0) {
                var notYetDischarged = store.getAt(0).data.IsEpisodeNotYetDischarged;

                if (notYetDischarged == '3') {
                    result = true;
                }
            }

            return result;
        },
        isCaseNotClosedByTimeOfReview: function () {
            var self = this;
            var store = Ext.data.StoreManager.lookup(self.getStoreId());            
            var result = false;

            if (store.data.length > 0) {
                var notYetClosed = store.getAt(0).data.IsCaseClosureNotClosed;

                if (notYetClosed == '3') {
                    result = true;
                }
            }

            return result;
        },
        isValidAssessmentCode: function (assessmentCode) {

            var lookupStore = chainedStore('AssessmentTypeStore');
            var result = false;

            Ext.each(lookupStore.data.items, function (item) {
                if (item.data.AssessmentCode == assessmentCode) {
                    result = true;

                    return false;
                }
            });

            return result;
        },
        isValidPerpetratorChildRelationship: function (relationshipCode) {

            var lookupStore = chainedStore('PerpetratorChildRelationshipStore');
            var result = false;

            Ext.each(lookupStore.data.items, function (item) {
                if (item.data.PerpetratorChildRelationshipCode == relationshipCode) {
                    result = true;

                    return false;
                }
            });

            return result;
        },
        isValidDispositionCode: function (DispositionCode) {

            var lookupStore = chainedStore('DispositionStore');
            var result = false;

            Ext.each(lookupStore.data.items, function (item) {
                if (item.data.DispositionCode == DispositionCode) {
                    result = true;

                    return false;
                }
            });

            return result;
        },
        isOtherAllegationSelected: function (allegations) {

            var lookupStore = chainedStore('CaseReasonStore');
            var result = false;

            lookupStore.filterBy(function (record) {
                var descr = record.data.DescriptionMedium.trim().split(' ');

                if (descr[0] == 'Other') {
                    return record;
                }
            });

            if (lookupStore.data.length > 0) {

                var otherId = lookupStore.getAt(0).data.GroupID;

                Ext.each(allegations, function (allegation) {

                    if (allegation.SafetyReportAllegationCode == otherId) {
                        result = true;
                    }
                });
            }            

            return result;
        },
        isOtherPerpetratorChildRelationshipSelected: function (relationshipCode) {

            var lookupStore = chainedStore('PerpetratorChildRelationshipStore');
            var result = false;

            lookupStore.filterBy(function (record) {
                var descr = record.data.DescriptionMedium.trim().split(' ');

                if (descr[0] == 'Other') {
                    return record;
                }
            });
            
            if (lookupStore.data.length > 0) {

                var otherId = lookupStore.getAt(0).data.GroupID;

                if (relationshipCode == otherId) {
                    result = true;
                }
            }

            return result;
        },
        validateItemApplicability: function(appItems){
            var self = this;
            var result = [];
            var vResult = {};
            var questionVal = {};
            var item;
            var columnVal;
            var noResponses = 0;
            var questionAns;

            item = getItem(appItems.ItemCode, appItems.OutcomeCode);

            if (!Ext.isEmpty(item)) {

                columnVal = item.IsApplicable;

                if (!Ext.isEmpty(columnVal)) {

                    noResponses++;
                }
            }
            
            if (!Ext.isEmpty(appItems.PreApplicability)) {

                if (appItems.PreApplicability[0].NoResponses > 0) {

                    noResponses++;
                }
            }
            
            if (appItems.ItemName == 'item5') {
                //
                // If a date is selected in Face Sheet question K, use the dates in Face Sheet 
                // questions J and K to determine if the child has been in foster care for 61 
                // days or longer. If so, item 5 applicability must be Yes. 
                //                
                var daysInFosterCare = getTimeInFosterCare('day');

                if (!Ext.isEmpty(daysInFosterCare)) {

                    if (daysInFosterCare > 60 && columnVal == 2) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'You indicated on the Face Sheet that the child has been in foster care more than 60 days. Please answer Yes to the question of applicability for item 5.';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('item5Applicability', appPages.Permanency);

                        if (!(container == undefined)) {

                            var msgComponent = getCRSComponent('msgItem5Applicability', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }                                        
                }                
                //
                // If question 5A3 is NA, item 5 is not applicable for assessment. 
                //
                var permanencyStore = Ext.data.ChainedStore.create({
                    source: 'CR_Permanency_CollectionStore'
                });

                var answer5A3 = permanencyStore.getAt(0).data.IsGoalSpecified;

                if (!Ext.isEmpty(answer5A3)) {

                    noResponses++;
                }

                if (answer5A3 == 3 && columnVal == 1) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'If question 5A3 is NA, item 5 is not applicable for assessment. Please return to the applicability page for item 5 and select No.';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('item5A3', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem5A3', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 5B is NA, item 5 is not applicable for assessment. 
                //
                var answer5B = permanencyStore.getAt(0).data.wereAllGoalsInTimelyManner;

                if (!Ext.isEmpty(answer5B)) {

                    noResponses++;
                }

                if (answer5B == 3 && columnVal == 1) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'If question 5B is NA, item 5 is not applicable for assessment. Please return to the applicability page for item 5 and select No.';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('item5B', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem5B', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                
                vResult['NoResponses'] = noResponses;
                result.push(vResult);

                return result;
            }

            if (appItems.ItemName == 'item8') {
                //
                // If the first pre-applicability bullet is Yes, then item 8 applicability must be Yes. 
                //                
                var preAppAnswer1;
                
                if (appItems.PreApplicability.length > 0) {

                    preAppAnswer1 = appItems.PreApplicability[0].Answers.item8Question1;
                }                

                if (!Ext.isEmpty(preAppAnswer1)) {

                    if (preAppAnswer1 == 1 && columnVal == 2) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'The answers above indicate that this case is applicable. Please review answers above.';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion8', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem8Applicability', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                }
                //
                // If the first pre-applicability bullet is No and any of the last five pre-applicability 
                // bullets are Yes, item 8 applicability must be No.  
                // 
                if (!Ext.isEmpty(preAppAnswer1)) {

                    var anyLast5Yes = false;
                    var last5No = false;
                    var all6No = false;

                    if (appItems.PreApplicability[0].Answers.item8Question2 == 1 ||
                        appItems.PreApplicability[0].Answers.item8Question3 == 1 ||
                        appItems.PreApplicability[0].Answers.item8Question4 == 1 ||
                        appItems.PreApplicability[0].Answers.item8Question5 == 1 ||
                        appItems.PreApplicability[0].Answers.item8Question6 == 1) {

                        anyLast5Yes = true;
                    }

                    if (preAppAnswer1 == 2 && (anyLast5Yes) && columnVal == 1) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'The answers above indicate that this case is not applicable. Please review answers above. ';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion8', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem8Applicability', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                    //
                    // If all of the six pre-applicability bullets are No, item 8 applicability must be Yes. 
                    //
                    if (appItems.PreApplicability[0].Answers.item8Question1 == 2 &&
                        appItems.PreApplicability[0].Answers.item8Question2 == 2 &&
                        appItems.PreApplicability[0].Answers.item8Question3 == 2 &&
                        appItems.PreApplicability[0].Answers.item8Question4 == 2 &&
                        appItems.PreApplicability[0].Answers.item8Question5 == 2 &&
                        appItems.PreApplicability[0].Answers.item8Question6 == 2) {

                        all6No = true;
                    }

                    if (all6No && columnVal == 2) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'The answers above indicate that this case is applicable. Please review answers above.';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion8', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem8Applicability', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                    //
                    // If there are no entries in Face Sheet table G2 as Mother or Other, a message 
                    // indicating that no case participants are available for assessment will show 
                    // on the item 8 applicability page. 
                    //
                    var caseParticipantStore = chainedStore('CR_CaseParticipant_CollectionStore');

                    var motherOrOther = caseParticipantStore.data.items.filter(function (item) {
                        return (item.data.RoleCode == 1 || item.data.RoleCode == 6);
                    });

                    var mother = caseParticipantStore.data.items.filter(function (item) {
                        return (item.data.RoleCode == 1);
                    });

                    var fatherOrOther = caseParticipantStore.data.items.filter(function (item) {
                        return (item.data.RoleCode == 2 || item.data.RoleCode == 6);
                    });

                    var father = caseParticipantStore.data.items.filter(function (item) {
                        return (item.data.RoleCode == 2);
                    });

                    var parms = { ItemCode: appItems.ItemCode, OutcomeCode: appItems.OutcomeCode };

                    var participants = getParticipantsSelected(parms);

                    var motherSelected = participants.Mothers;
                    var fatherSelected = participants.Fathers;

                    if (!Ext.isEmpty(mother)) {

                        if (!Ext.isEmpty(father)) {

                            noResponses++;
                        }
                    }
                    
                    if (motherOrOther.length == 0 && fatherOrOther.length == 0) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'There are no case participants in Face Sheet table G2 that can be assessed as Mother.';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Info';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion8', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem8Applicability', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Info');
                            msgComponent.updateMessages();
                        }
                    }
                    //
                    // If there are no entries in Face Sheet table G2 as Father or Other, a message 
                    // indicating that no case participants are available for assessment will show 
                    // on the item 8 applicability page. 
                    //
                    if (!Ext.isEmpty(father)) {

                        noResponses++;
                    }

                    if (fatherOrOther.length == 0) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'There are no case participants in Face Sheet table G2 that can be assessed as Father.';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Info';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion8', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem8Applicability', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Info');
                            msgComponent.updateMessages();
                        }
                    }
                    //
                    // If the first pre-applicability bullet is Yes and the remaining five pre-applicability bullets are No, 
                    // a parent must be selected for assessment. 
                    //
                    if (appItems.PreApplicability[0].Answers.item8Question2 == 2 ||
                        appItems.PreApplicability[0].Answers.item8Question3 == 2 ||
                        appItems.PreApplicability[0].Answers.item8Question4 == 2 ||
                        appItems.PreApplicability[0].Answers.item8Question5 == 2 ||
                        appItems.PreApplicability[0].Answers.item8Question6 == 2) {

                        last5No = true;
                    }
                    
                    if (preAppAnswer1 == 1 && (last5No) && father.length == 0 && mother.length == 0) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please select case participant(s) as Mother and/or Father because you indicated that this case is applicable for an assessment of this item.';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion8', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem8Applicability', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                    //
                    // If there are no siblings listed in Face Sheet table G1, and item 8 applicability is Yes, 
                    // there must be a case participant selected for Mother or Father.
                    //
                    var childDemographicStore = Ext.data.ChainedStore.create({
                        source: 'CR_ChildDemographic_CollectionStore'
                    });

                    var siblings = childDemographicStore.data.items.filter(function (item) {
                        return item.data.IsTargetChild == 2;
                    });

                    if (siblings.length == 0 && columnVal == 1 && father.length == 0 && mother.length == 0) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please select No since there are no siblings listed in this case and no case participants are included in this item as Mother or Father. ';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion8', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem8Applicability', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                    //
                    // A case participant for Mother cannot be selected if the case is not applicable for Item 8. 
                    //                    
                    if ((father.length > 0 || mother.length > 0) && columnVal == 2) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please do not select case participant(s) who are included in this item as Mother or Father because you indicated that this case is not applicable for an assessment of this item.';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion8', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem8Applicability', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                    //
                    // If the first pre-applicability bullet is Yes and any of the last five pre-applicability bullets are Yes, 
                    // and item 8 applicability is Yes, a Mother cannot be selected for assessment. 
                    //                    
                    if (preAppAnswer1 == 1 && (anyLast5Yes) && columnVal == 1 && mother.length > 0) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please do not select case participant(s) who are included in this item as Mother because you indicated that parents in this case are not applicable for an assessment of this item.';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion8', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem8Applicability', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                    //
                    // Different case participants must be selected for Mother and Father. 
                    //
                    var nameOfMother;
                    var nameOfFather;

                    if (mother.length > 0) {

                        nameOfMother = mother[0].data.Name;
                        vResult['MotherSelected'] = true;
                    }

                    if (father.length > 0) {

                        nameOfFather = father[0].data.Name;
                        vResult['FatherSelected'] = true;
                    }

                    if (!Ext.isEmpty(nameOfMother) || !Ext.isEmpty(nameOfFather)) {

                        if (nameOfMother == nameOfFather) {

                            questionVal = {};

                            if (vResult.rowNumber == undefined) {
                                vResult['page'] = appItems.PageName;
                            }

                            vResult['item'] = appItems.ItemName;
                            questionVal['Message'] = 'Please select different case participants for Mother and Father.';
                            vResult['applicability'] = questionVal['Message'];
                            vResult['messageType'] = 'Error';

                            // Get the validation message component
                            var container = getCRSComponent('applicabilityQuestion8', appPages.Permanency);

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgItem8Applicability', container);

                                msgComponent.setValidationResult(questionVal);
                                msgComponent.updateMessages();
                            }
                        }
                    }                    
                    //
                    // If question 7A is Yes, the item 8 applicability page's first pre-applicability bullet must be No. 
                    //    
                    var permanencyStore = Ext.data.ChainedStore.create({
                        source: 'CR_Permanency_CollectionStore'
                    });

                    var answer7A = permanencyStore.getAt(0).data.IsPlacedWithAllSiblings;

                    if (!Ext.isEmpty(answer7A)) {

                        noResponses++;
                    }

                    if (answer7A == 1 && preAppAnswer1 == 1) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please answer No to this question since question 7A is Yes. ';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion8', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem8Applicability', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                    //
                    // If question 7A is No, the item 8 applicability page's first pre-applicability bullet must be Yes. 
                    //
                    if (answer7A == 2 && preAppAnswer1 == 2) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please answer Yes to this question since question 7A is No. ';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion8', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem8Applicability', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                }

                vResult['CaseApplicable'] = columnVal == 1 ? 'Yes' : columnVal == 2 ? 'No' : undefined;
                vResult['NoResponses'] = noResponses;
                result.push(vResult);

                return result;
            }

            if (appItems.ItemName == 'item11') {
                //
                // If any of the six pre-applicability bullets are Yes, item 11 applicability must be No. 
                // 
                var questions = getItemQuestions('item11');
                var parms = { QuestionsObj: questions, ItemCode: 12, OutcomeCode: 4, ContainerType: 'permanency' };

                if ((appItems.PreApplicability[0].Answers.item11Question1 == 1 ||
                    appItems.PreApplicability[0].Answers.item11Question2 == 1 ||
                    appItems.PreApplicability[0].Answers.item11Question3 == 1 ||
                    appItems.PreApplicability[0].Answers.item11Question4 == 1 ||
                    appItems.PreApplicability[0].Answers.item11Question5 == 1 ||
                    appItems.PreApplicability[0].Answers.item11Question6 == 1) && columnVal == 1) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'The answers above indicate that this case is not applicable. Please review answers above.';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('item11Applicability', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem11Applicability', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If all of the six pre-applicability bullets are No, item 11 applicability must be Yes. 
                // 
                if ((appItems.PreApplicability[0].Answers.item11Question1 == 2 &&
                    appItems.PreApplicability[0].Answers.item11Question2 == 2 &&
                    appItems.PreApplicability[0].Answers.item11Question3 == 2 &&
                    appItems.PreApplicability[0].Answers.item11Question4 == 2 &&
                    appItems.PreApplicability[0].Answers.item11Question5 == 2 &&
                    appItems.PreApplicability[0].Answers.item11Question6 == 2) && columnVal == 2) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'The answers above indicate that this case is applicable. Please review answers above. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('item11Applicability', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem11Applicability', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If there are no entries in Face Sheet table G2 as Mother or Other, a message 
                // indicating that no case participants are available for assessment will show 
                // on the item 11 applicability page. 
                //
                var caseParticipantStore = chainedStore('CR_CaseParticipant_CollectionStore');

                var motherOrOther = caseParticipantStore.data.items.filter(function (item) {
                    return (item.data.RoleCode == 1 || item.data.RoleCode == 6);
                });

                var mother = caseParticipantStore.data.items.filter(function (item) {
                    return (item.data.RoleCode == 1);
                });

                if (!Ext.isEmpty(mother)) {

                    noResponses++;

                    parms['ItemName'] = 'item11';
                    parms['Question'] = 'ApplicabilityMother';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (motherOrOther.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'There are no case participants in Face Sheet table G2 that can be assessed as Mother.';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Info';

                    // Get the validation message component
                    var container = getCRSComponent('item11Applicability', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem11Applicability', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Info');
                        msgComponent.updateMessages();
                    }
                }
                //
                // If there are no entries in Face Sheet table G2 as Father or Other, a message 
                // indicating that no case participants are available for assessment will show 
                // on the item 11 applicability page. 
                //
                var fatherOrOther = caseParticipantStore.data.items.filter(function (item) {
                    return (item.data.RoleCode == 2 || item.data.RoleCode == 6);
                });

                var father = caseParticipantStore.data.items.filter(function (item) {
                    return (item.data.RoleCode == 2);
                });

                if (!Ext.isEmpty(father)) {

                    noResponses++;
                    
                    parms['ItemName'] = 'item11';
                    parms['Question'] = 'ApplicabilityFather';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (fatherOrOther.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'There are no case participants in Face Sheet table G2 that can be assessed as Father.';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Info';

                    // Get the validation message component
                    var container = getCRSComponent('item11Applicability', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem11Applicability', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Info');
                        msgComponent.updateMessages();
                    }
                }
                //
                // If the case is applicable for assessment of item 11, a case participant must be 
                // selected for Mother and/or Father.
                //
                if (columnVal == 1 && father.length == 0 && mother.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'Please select case participant(s) as Mother and/or Father because you indicated that this case is applicable for an assessment of this item. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('item11Applicability', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem11Applicability', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // A case participant for Mother cannot be selected if the case is not applicable for Item 11. 
                //
                if (columnVal == 2 && mother.length > 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'Please do not select case participant(s) who are included in this item as Mother because you indicated that this case is not applicable for an assessment of this item. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('item11Applicability', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem11Applicability', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // A case participant for Father cannot be selected if the case is not applicable for Item 11. 
                //
                if (columnVal == 2 && father.length > 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'Please do not select case participant(s) who are included in this item as Father because you indicated that this case is not applicable for an assessment of this item. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('item11Applicability', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem11Applicability', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // Different case participants must be selected for Mother and Father. 
                //
                var nameOfMother;
                var nameOfFather;

                if (mother.length > 0) {

                    nameOfMother = mother[0].data.Name;
                }

                if (father.length > 0) {

                    nameOfFather = father[0].data.Name;
                }

                if (!Ext.isEmpty(nameOfMother) || !Ext.isEmpty(nameOfFather)) {

                    if (nameOfMother == nameOfFather) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please select different case participants for Mother and Father.';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('item11Applicability', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem11Applicability', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                }

                vResult['CaseApplicable'] = columnVal == 1 ? 'Yes' : columnVal == 2 ? 'No' : undefined;
                vResult['NoResponses'] = noResponses;
                result.push(vResult);

                return result;
            }

            if (appItems.ItemName == 'item12A') {
                                
                return result;
            }

            if (appItems.ItemName == 'item12B') {

                var wellbeingStore = Ext.data.ChainedStore.create({
                    source: 'CR_WellBeing_CollectionStore'
                });

                var motherApplicable = wellbeingStore.getAt(0).data.IsNeedsServicesApplicableForMother;
                var fatherApplicable = wellbeingStore.getAt(0).data.IsNeedsServicesApplicableForFather;

                if (!Ext.isEmpty(motherApplicable)) {

                    noResponses++;
                }

                if (!Ext.isEmpty(fatherApplicable)) {

                    noResponses++;
                }

                vResult['MotherApplicable'] = motherApplicable;
                vResult['FatherApplicable'] = fatherApplicable;
                //
                // Sub-item 12B applicability for Mother is a required field.
                //
                if (motherApplicable == undefined) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'Please select Yes or No. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('subItem12B', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem12BApplicableCases', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // Sub-item 12B applicability for Father is a required field.
                //
                if (fatherApplicable == undefined) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'Please select Yes or No. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('subItem12B', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem12BApplicableCases', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If any of the five pre-applicability bullets are Yes, sub-item 12B applicability 
                // for both Mother and Father must be No. 
                //
                if ((appItems.PreApplicability[0].Answers.item12BQuestion1 == 1 ||
                   appItems.PreApplicability[0].Answers.item12BQuestion2 == 1 ||
                   appItems.PreApplicability[0].Answers.item12BQuestion3 == 1 ||
                   appItems.PreApplicability[0].Answers.item12BQuestion4 == 1 ||
                   appItems.PreApplicability[0].Answers.item12BQuestion5 == 1) &&
                    (motherApplicable == 1 || fatherApplicable == 1)) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'The answers above indicate that this case is not applicable. Please review answers above.';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('subItem12B', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem12BApplicableCases', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If all of five pre-applicability bullets are No, sub-item 12B applicability 
                // for Mother and/or Father must be Yes. 
                //
                if ((appItems.PreApplicability[0].Answers.item12BQuestion1 == 2 &&
                   appItems.PreApplicability[0].Answers.item12BQuestion2 == 2 &&
                   appItems.PreApplicability[0].Answers.item12BQuestion3 == 2 &&
                   appItems.PreApplicability[0].Answers.item12BQuestion4 == 2 &&
                   appItems.PreApplicability[0].Answers.item12BQuestion5 == 2) &&
                    (motherApplicable == 2 || fatherApplicable == 2)) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'The answers above indicate that this case is applicable. Please review answers above. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('subItem12B', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem12BApplicableCases', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If there are no entries in Face Sheet table G2 as Mother or Other, a message 
                // indicating that no case participants are available for assessment will show 
                // on the item 12B applicability page. 
                //
                var caseParticipantStore = chainedStore('CR_CaseParticipant_CollectionStore');

                var motherOrOther = caseParticipantStore.data.items.filter(function (item) {
                    return (item.data.RoleCode == 1 || item.data.RoleCode == 6);
                });

                var mother = caseParticipantStore.data.items.filter(function (item) {
                    return (item.data.RoleCode == 1);
                });

                if (!Ext.isEmpty(mother)) {

                    noResponses++;
                }

                if (motherOrOther.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'There are no case participants in Face Sheet table G2 that can be assessed as Mother.';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Info';

                    // Get the validation message component
                    var container = getCRSComponent('subItem12B', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem12BApplicableCases', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Info');
                        msgComponent.updateMessages();
                    }
                }
                //
                // If there are no entries in Face Sheet table G2 as Father or Other, a message 
                // indicating that no case participants are available for assessment will show 
                // on the item 12B applicability page. 
                //
                var fatherOrOther = caseParticipantStore.data.items.filter(function (item) {
                    return (item.data.RoleCode == 2 || item.data.RoleCode == 6);
                });

                var father = caseParticipantStore.data.items.filter(function (item) {
                    return (item.data.RoleCode == 2);
                });

                if (!Ext.isEmpty(father)) {

                    noResponses++;
                }

                if (fatherOrOther.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'There are no case participants in Face Sheet table G2 that can be assessed as Father.';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Info';

                    // Get the validation message component
                    var container = getCRSComponent('subItem12B', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem12BApplicableCases', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Info');
                        msgComponent.updateMessages();
                    }
                }
                //
                // A case participant for Mother cannot be selected if the case is not applicable for Item 12B. 
                //
                if (motherApplicable == 2 && mother.length > 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'Please do not select case participant(s) who are included in this sub-item as Mother because you indicated that sub-item 12B is not applicable for Mother. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('subItem12B', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem12BApplicableCases', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // A case participant for Father cannot be selected if the case is not applicable for Item 12B. 
                //
                if (fatherApplicable == 2 && father.length > 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'Please do not select case participant(s) who are included in this sub-item as Father because you indicated that sub-item 12B is not applicable for Father. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Info';

                    // Get the validation message component
                    var container = getCRSComponent('subItem12B', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem12BApplicableCases', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Info');
                        msgComponent.updateMessages();
                    }
                }
                //
                // If sub-item 12B is applicable for Mother, a case participant must be selected for Mother.
                //
                if (motherApplicable == 1 && mother.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'Please select case participant(s) to be included in this sub-item as Mother. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('subItem12B', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem12BApplicableCases', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If sub-item 12B is applicable for Father, a case participant must be selected for Father. 
                //
                if (fatherApplicable == 1 && father.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'Please select case participant(s) to be included in this sub-item as Father. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('subItem12B', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem12BApplicableCases', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // Different case participants must be selected for Mother and Father. 
                //
                var nameOfMother;
                var nameOfFather;

                if (mother.length > 0) {

                    nameOfMother = mother[0].data.Name;
                }

                if (father.length > 0) {

                    nameOfFather = father[0].data.Name;
                }

                if (!Ext.isEmpty(nameOfMother) || !Ext.isEmpty(nameOfFather)) {

                    if (nameOfMother == nameOfFather) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please select different case participants for Mother and Father.';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('subItem12B', appPages.Wellbeing);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem12BApplicableCases', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                }

                vResult['CaseApplicable'] = columnVal == 1 ? 'Yes' : columnVal == 2 ? 'No' : undefined;
                vResult['NoResponses'] = noResponses;
                result.push(vResult);

                return result;
            }

            if (appItems.ItemName == 'item12C') {
                //
                // Sub-item 12C applicability is a required field. 
                //
                if (self.isFosterCareCase()) {

                    if (Ext.isEmpty(columnVal)) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = appItems.Message;
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('item12C', appPages.Wellbeing);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem12C', container);

                            if (!Ext.isEmpty(msgComponent)) {
                                
                                msgComponent.setValidationResult(questionVal);
                                msgComponent.updateMessages();
                            }
                        }
                    }
                }
                
                vResult['CaseApplicable'] = columnVal == 1 ? 'Yes' : columnVal == 2 ? 'No' : undefined;
                vResult['NoResponses'] = noResponses;
                result.push(vResult);

                return result;
            }

            if (appItems.ItemName == 'item13') {
                //
                // Item 13 applicability is a required field. 
                //
                if (Ext.isEmpty(columnVal)) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = appItems.Message;
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('applicabilityQuestion13', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgApplicabilityQuestion13', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If the first pre-applicability bullet is Yes and any one of the remaining six pre-applicability 
                // bullets is Yes, item 13 applicability must be No. 
                //
                if ((appItems.PreApplicability[0].Answers.item13Question1 == 1 &&
                    (appItems.PreApplicability[0].Answers.item11Question2 == 1 ||
                    appItems.PreApplicability[0].Answers.item11Question3 == 1 ||
                    appItems.PreApplicability[0].Answers.item11Question4 == 1 ||
                    appItems.PreApplicability[0].Answers.item11Question5 == 1 ||
                    appItems.PreApplicability[0].Answers.item11Question6 == 1 ||
                    appItems.PreApplicability[0].Answers.item11Question7 == 1)) && columnVal == 1) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'The answers above indicate that this case is not applicable. Please review answers above. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('applicabilityQuestion13', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgApplicabilityQuestion13', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If the first pre-applicability bullet is No, no matter how the remaining bullets 
                // are answered, item 13 applicability must be Yes. 
                //
                if (appItems.PreApplicability[0].Answers.item13Question1 == 2  && columnVal == 2) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'The answers above indicate that this case is applicable. Please review answers above. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('applicabilityQuestion13', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgApplicabilityQuestion13', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If item 13 is applicable and any of the last six pre-applicability bullets are Yes, 
                // Mother cannot be selected for assessment.  
                //
                var motherStore = GetItemParticipant(1);

                if (motherStore.data.length > 0) {

                    noResponses++;

                    if ((appItems.PreApplicability[0].Answers.item11Question2 == 1 ||
                    appItems.PreApplicability[0].Answers.item11Question3 == 1 ||
                    appItems.PreApplicability[0].Answers.item11Question4 == 1 ||
                    appItems.PreApplicability[0].Answers.item11Question5 == 1 ||
                    appItems.PreApplicability[0].Answers.item11Question6 == 1 ||
                    appItems.PreApplicability[0].Answers.item11Question7 == 1) && columnVal == 1) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please select NA for case participants who are included in this item as Mother because you indicated that this case is not applicable for an assessment of this item. ';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion13', appPages.Wellbeing);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgApplicabilityQuestion13', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                }
                //
                // If item 13 is applicable and any of the last six pre-applicability bullets are Yes, 
                // Father cannot be selected for assessment.  
                //
                var fatherStore = GetItemParticipant(2);

                if (fatherStore.data.length > 0) {

                    noResponses++;

                    if ((appItems.PreApplicability[0].Answers.item11Question2 == 1 ||
                    appItems.PreApplicability[0].Answers.item11Question3 == 1 ||
                    appItems.PreApplicability[0].Answers.item11Question4 == 1 ||
                    appItems.PreApplicability[0].Answers.item11Question5 == 1 ||
                    appItems.PreApplicability[0].Answers.item11Question6 == 1 ||
                    appItems.PreApplicability[0].Answers.item11Question7 == 1) && columnVal == 1) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please select NA for case participants who are included in this item as Father because you indicated that this case is not applicable for an assessment of this item. ';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion13', appPages.Wellbeing);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgApplicabilityQuestion13', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                }
                //
                // If all of the last six pre-applicability bullets are No, no matter how the first bullet is 
                // answered, item 13 applicability must be Yes. 
                //
                if ((appItems.PreApplicability[0].Answers.item11Question2 == 2 &&
                    appItems.PreApplicability[0].Answers.item11Question3 == 2 &&
                    appItems.PreApplicability[0].Answers.item11Question4 == 2 &&
                    appItems.PreApplicability[0].Answers.item11Question5 == 2 &&
                    appItems.PreApplicability[0].Answers.item11Question6 == 2 &&
                    appItems.PreApplicability[0].Answers.item11Question7 == 2) && columnVal == 2) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'The answers above indicate that this case is applicable. Please review answers above. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('applicabilityQuestion13', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgApplicabilityQuestion13', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If all of the last six pre-applicability bullets are No and item 13 applicability is Yes, 
                // at least one parent must be selected for assessment. 
                //
                if (fatherStore.data.length == 0 && motherStore.data.length == 0) {

                    if ((appItems.PreApplicability[0].Answers.item11Question2 == 2 &&
                        appItems.PreApplicability[0].Answers.item11Question3 == 2 &&
                        appItems.PreApplicability[0].Answers.item11Question4 == 2 &&
                        appItems.PreApplicability[0].Answers.item11Question5 == 2 &&
                        appItems.PreApplicability[0].Answers.item11Question6 == 2 &&
                        appItems.PreApplicability[0].Answers.item11Question7 == 2) && columnVal == 1) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please select a case participant to be included in this item as Mother or Father. ';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion13', appPages.Wellbeing);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgApplicabilityQuestion13', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                }
                //
                // A case participant for Mother cannot be selected if the case is not applicable for item 13. 
                //
                if (motherStore.data.length > 0 && columnVal == 2) {
                                        
                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'Please do not select case participant(s) who are included in this item as Mother because you indicated that this case is not applicable for an assessment of this item. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('applicabilityQuestion13', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgApplicabilityQuestion13', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }                    
                }
                //
                // A case participant for Father cannot be selected if the case is not applicable for item 13. 
                //
                if (fatherStore.data.length > 0 && columnVal == 2) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'Please do not select case participant(s) who are included in this item as Father because you indicated that this case is not applicable for an assessment of this item. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('applicabilityQuestion13', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgApplicabilityQuestion13', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If item 13 is applicable, a case participant must be selected for Mother or Father. 
                //
                if (columnVal == 1 && fatherStore.data.length == 0 && motherStore.data.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'Please select case participant(s) to be included in this item as Mother or Father. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('applicabilityQuestion13', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgApplicabilityQuestion13', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If there are no entries in Face Sheet table G2 as Mother or Other, a message 
                // indicating that no case participants are available for assessment will show 
                // on the item 13 applicability page. 
                //
                var caseParticipantStore = chainedStore('CR_CaseParticipant_CollectionStore');

                var motherOrOther = caseParticipantStore.data.items.filter(function (item) {
                    return (item.data.RoleCode == 1 || item.data.RoleCode == 6);
                });

                var mother = caseParticipantStore.data.items.filter(function (item) {
                    return (item.data.RoleCode == 1);
                });

                if (motherOrOther.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'There are no case participants in Face Sheet table G2 that can be assessed as Mother. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Info';

                    // Get the validation message component
                    var container = getCRSComponent('applicabilityQuestion13', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgApplicabilityQuestion13', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Info');
                        msgComponent.updateMessages();
                    }
                }
                //
                // If there are no entries in Face Sheet table G2 as Father or Other, a message 
                // indicating that no case participants are available for assessment will show 
                // on the item 13 applicability page. 
                //
                var fatherOrOther = caseParticipantStore.data.items.filter(function (item) {
                    return (item.data.RoleCode == 2 || item.data.RoleCode == 6);
                });

                var father = caseParticipantStore.data.items.filter(function (item) {
                    return (item.data.RoleCode == 2);
                });

                if (fatherOrOther.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'There are no case participants in Face Sheet table G2 that can be assessed as Father. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Info';

                    // Get the validation message component
                    var container = getCRSComponent('applicabilityQuestion13', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgApplicabilityQuestion13', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Info');
                        msgComponent.updateMessages();
                    }
                }
                //
                // Different case participants must be selected for Mother and Father. 
                //
                var nameOfMother;
                var nameOfFather;

                if (mother.length > 0) {

                    nameOfMother = mother[0].data.Name;
                    vResult['MotherSelected'] = true;
                }

                if (father.length > 0) {

                    nameOfFather = father[0].data.Name;
                    vResult['FatherSelected'] = true;
                }

                if (!Ext.isEmpty(nameOfMother) || !Ext.isEmpty(nameOfFather)) {

                    if (nameOfMother == nameOfFather) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please select different case participants for Mother and Father.';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion13', appPages.Wellbeing);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgApplicabilityQuestion13', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    }
                }
                //
                // For in-home cases only, if the first pre­applicability bullet is Yes and item 13 
                // is applicable, a child cannot be selected for assessment. 
                //
                var caseType = getCaseType();
                var childStore = GetItemChildren();

                if ((caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') && childStore.data.length > 0) {

                    if (appItems.PreApplicability[0].Answers.item11Question1 == 1 && columnVal == 1) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please do not select a child who is included in an assessment of this item since answers to the questions above indicate that the case is not applicable for assessment of a child. ';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion13', appPages.Wellbeing);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgApplicabilityQuestion13', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    }
                }
                //
                // For in-home cases only, if the first pre­applicability bullet is No and item 13 
                // is applicable, a child must be selected for assessment. 
                //
                if ((caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') && childStore.data.length == 0) {

                    if (appItems.PreApplicability[0].Answers.item11Question1 == 2 && columnVal == 1) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please indicate the name of at least one child who is included in an assessment of this item. ';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion13', appPages.Wellbeing);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgApplicabilityQuestion13', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    }
                }
                //
                // For in-home cases only, a child cannot be selected for assessment if item 13 applicability is No. 
                //
                if ((caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') && childStore.data.length > 0) {

                    var noChildren = getNoOfChildren();

                    if (noChildren > 0 && columnVal == 2) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please do not select a child who is included in an assessment of this item if the case is not applicable. ';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion13', appPages.Wellbeing);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgApplicabilityQuestion13', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    }
                }
                
                vResult['CaseApplicable'] = columnVal == 1 ? 'Yes' : columnVal == 2 ? 'No' : undefined;
                vResult['NoResponses'] = noResponses;
                result.push(vResult);

                return result;
            }

            if (appItems.ItemName == 'item15') {
                //
                // Item 15 applicability is a required field. 
                //
                if (Ext.isEmpty(columnVal)) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'Please select Yes or No. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('applicabilityQuestion15', appPages.Wellbeing);

                    if (!(container == undefined)) {

                        var msgComponent = getCRSComponent('msgApplicabilityQuestion15', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }                    
                }
                //
                // If any of the six pre-applicability bullets are Yes, item 15 applicability must be No. 
                //
                if ((appItems.PreApplicability[0].Answers.item15Question1 == 1 ||
                    appItems.PreApplicability[0].Answers.item15Question2 == 1 ||
                    appItems.PreApplicability[0].Answers.item15Question3 == 1 ||
                    appItems.PreApplicability[0].Answers.item15Question4 == 1 ||
                    appItems.PreApplicability[0].Answers.item15Question5 == 1 ) && columnVal == 1) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'The answers above indicate that this case is not applicable. Please review answers above. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('applicabilityQuestion15', appPages.Wellbeing);

                    if (!(container == undefined)) {

                        var msgComponent = getCRSComponent('msgApplicabilityQuestion15', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //
                // If all of the six pre-applicability bullets are No, item 15 applicability must be Yes. 
                //
                if ((appItems.PreApplicability[0].Answers.item15Question1 == 2 &&
                    appItems.PreApplicability[0].Answers.item15Question2 == 2 &&
                    appItems.PreApplicability[0].Answers.item15Question3 == 2 &&
                    appItems.PreApplicability[0].Answers.item15Question4 == 2 &&
                    appItems.PreApplicability[0].Answers.item15Question5 == 2) && !(columnVal == 1)) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'The answers above indicate that this case is applicable. Please review answers above. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('applicabilityQuestion15', appPages.Wellbeing);

                    if (!(container == undefined)) {

                        var msgComponent = getCRSComponent('msgApplicabilityQuestion15', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //
                // If the case is applicable for assessment of item 15, a case participant must be selected for Mother and/or Father. 
                //
                var motherStore = GetItemParticipant(1);
                var fatherStore = GetItemParticipant(2);

                if (columnVal == 1 && motherStore.data.length == 0 && fatherStore.data.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'Please select case participant(s) as Mother and/or Father because you indicated that this case is applicable for an assessment of this item. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('applicabilityQuestion15', appPages.Wellbeing);

                    if (!(container == undefined)) {

                        var msgComponent = getCRSComponent('msgApplicabilityQuestion15', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //
                // A case participant for Mother cannot be selected if the case is not applicable for item 15. 
                //
                if (columnVal == 2 && motherStore.data.length > 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'Please do not select case participant(s) who are included in this item as Mother because you indicated that this case is not applicable for an assessment of this item. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('applicabilityQuestion15', appPages.Wellbeing);

                    if (!(container == undefined)) {

                        var msgComponent = getCRSComponent('msgApplicabilityQuestion15', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //
                // A case participant for Father cannot be selected if the case is not applicable for item 15. 
                //
                if (columnVal == 2 && fatherStore.data.length > 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'Please do not select case participant(s) who are included in this item as Father because you indicated that this case is not applicable for an assessment of this item. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('applicabilityQuestion15', appPages.Wellbeing);

                    if (!(container == undefined)) {

                        var msgComponent = getCRSComponent('msgApplicabilityQuestion15', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //
                // Different case participants must be selected for Mother and Father. 
                //
                var caseParticipantStore = chainedStore('CR_CaseParticipant_CollectionStore');

                var mother = caseParticipantStore.data.items.filter(function (item) {
                    return (item.data.RoleCode == 1);
                });

                var father = caseParticipantStore.data.items.filter(function (item) {
                    return (item.data.RoleCode == 2);
                });

                var nameOfMother;
                var nameOfFather;

                if (mother.length > 0) {

                    noResponses++;

                    nameOfMother = mother[0].data.Name;
                    vResult['MotherSelected'] = true;
                }

                if (father.length > 0) {

                    noResponses++;
                    
                    nameOfFather = father[0].data.Name;
                    vResult['FatherSelected'] = true;
                }

                if (!Ext.isEmpty(nameOfMother) || !Ext.isEmpty(nameOfFather)) {

                    if (nameOfMother == nameOfFather) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please select different case participants for Mother and Father. ';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion15', appPages.Wellbeing);

                        if (!(container == undefined)) {

                            var msgComponent = getCRSComponent('msgApplicabilityQuestion15', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    }
                }
                
                vResult['NoResponses'] = noResponses;
                vResult['CaseApplicable'] = columnVal == 1 ? 'Yes' : columnVal == 2 ? 'No' : undefined;
                result.push(vResult);

                return result;
            }

            if (appItems.ItemName == 'item16') {
                //
                // Item 16 applicability is a required field. 
                //
                if (Ext.isEmpty(columnVal)) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'Please select Yes or No. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('applicabilityQuestion16', appPages.Wellbeing);

                    if (!(container == undefined)) {

                        var msgComponent = getCRSComponent('msgApplicabilityQuestion16', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //
                // For foster care cases only, if the target child is age three or older 
                // (using first the date they exited care in Face Sheet question K, or the 
                // end of the PUR if still in care), then item 16 applicability must be Yes. 
                //
                var caseType = getCaseType();

                if (caseType == 'Foster Case') {

                    var facesheetStore = chainedStore('CR_FaceSheet_CollectionStore');                    
                    var targetChild = this.getTargetChild();
                    var compareAgeInDays = 365 * 3;
                    var reviewEndDate = this.getReviewEndDate();
                    var exitFosterCareDate = facesheetStore.getAt(0).data.EpisodeDischargeDate;
                    var targetChildDOB = Ext.isEmpty(targetChild) ? undefined : targetChild.data.DateOfBirth;
                    var endDate = Ext.isEmpty(exitFosterCareDate) ? reviewEndDate : exitFosterCareDate;

                    var targetChildAge = getDateDiff(targetChildDOB, endDate, 'day');

                    if (targetChildAge >= compareAgeInDays && !(columnVal == 1)) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please select Yes. This case is applicable for assessment because this is a foster care case of a child age three or older. ';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion16', appPages.Wellbeing);

                        if (!(container == undefined)) {

                            var msgComponent = getCRSComponent('msgApplicabilityQuestion16', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    }                    
                }
                //
                // For in-home cases only, item 16 can only be applicable if at least one child is selected for assessment. 
                //
                if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

                    var noChildren = getNoOfChildren();

                    if (noChildren == 0 && columnVal == 1) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please indicate the name of at least one child who is included in an assessment of this item. ';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion16', appPages.Wellbeing);

                        if (!(container == undefined)) {

                            var msgComponent = getCRSComponent('msgApplicabilityQuestion16', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    }
                }
                //
                // For in-home cases only, a child cannot be selected for assessment if item 16 is not applicable. 
                //
                if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

                    var noChildren = getNoOfChildren();

                    if (noChildren > 0 && columnVal == 2) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please do not select a child who is included in an assessment of this item if the case is not applicable. ';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion16', appPages.Wellbeing);

                        if (!(container == undefined)) {

                            var msgComponent = getCRSComponent('msgApplicabilityQuestion16', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    }
                }

                vResult['CaseApplicable'] = columnVal == 1 ? 'Yes' : columnVal == 2 ? 'No' : undefined;
                vResult['NoResponses'] = noResponses;
                result.push(vResult);

                return result;
            }

            if (appItems.ItemName == 'item17') {
                //
                // Item 17 applicability is a required field. 
                //
                if (Ext.isEmpty(columnVal)) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'Please select Yes or No. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('applicabilityQuestion17', appPages.Wellbeing);

                    if (!(container == undefined)) {

                        var msgComponent = getCRSComponent('msgApplicabilityQuestion17', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //
                // For in-home cases only, item 17 can only be applicable if at least one child is selected for assessment. 
                //
                var caseType = getCaseType();
                var noChildren = getNoOfChildren();

                if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

                    if (noChildren == 0 && columnVal == 1) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please indicate the name of at least one child who is included in an assessment of this item. ';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion17', appPages.Wellbeing);

                        if (!(container == undefined)) {

                            var msgComponent = getCRSComponent('msgApplicabilityQuestion17', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    }
                }
                //
                // For in-home cases only, a child cannot be selected for assessment if item 17 is not applicable. 
                //
                if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

                    if (noChildren > 0 && columnVal == 2) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please do not select a child who is included in an assessment of this item if the case is not applicable. ';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion17', appPages.Wellbeing);

                        if (!(container == undefined)) {

                            var msgComponent = getCRSComponent('msgApplicabilityQuestion17', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    }
                }

                vResult['CaseApplicable'] = columnVal == 1 ? 'Yes' : columnVal == 2 ? 'No' : undefined;
                vResult['NoResponses'] = noResponses;
                result.push(vResult);

                return result;
            }

            if (appItems.ItemName == 'item18') {
                //
                // Item 18 applicability is a required field. 
                //
                if (Ext.isEmpty(columnVal)) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = appItems.PageName;
                    }

                    vResult['item'] = appItems.ItemName;
                    questionVal['Message'] = 'Please select Yes or No. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    // Get the validation message component
                    var container = getCRSComponent('applicabilityQuestion18', appPages.Wellbeing);

                    if (!(container == undefined)) {

                        var msgComponent = getCRSComponent('msgApplicabilityQuestion18', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //
                // For in-home cases only, item 18 can only be applicable if at least one child is selected for assessment. 
                //
                var caseType = getCaseType();
                var noChildren = getNoOfChildren();

                if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

                    if (noChildren == 0 && columnVal == 1) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please indicate the name of at least one child who is included in an assessment of this item. ';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion18', appPages.Wellbeing);

                        if (!(container == undefined)) {

                            var msgComponent = getCRSComponent('msgApplicabilityQuestion18', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    }
                }
                //
                // For in-home cases only, a child cannot be selected for assessment if item 18 is not applicable. 
                //
                if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

                    if (noChildren > 0 && columnVal == 2) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = appItems.PageName;
                        }

                        vResult['item'] = appItems.ItemName;
                        questionVal['Message'] = 'Please do not select a child who is included in an assessment of this item if the case is not applicable. ';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';

                        // Get the validation message component
                        var container = getCRSComponent('applicabilityQuestion18', appPages.Wellbeing);

                        if (!(container == undefined)) {

                            var msgComponent = getCRSComponent('msgApplicabilityQuestion18', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    }
                }

                vResult['CaseApplicable'] = columnVal == 1 ? 'Yes' : columnVal == 2 ? 'No' : undefined;
                vResult['NoResponses'] = noResponses;
                result.push(vResult);

                return result;
            }

            var getItemApplicability = function (applicabilityItems) {

                if (columnVal == undefined || columnVal == null || !(self.isValueValid(columnVal, appItems.ValidValues))) {
                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = applicabilityItems.PageName;
                    }

                    vResult['item'] = applicabilityItems.ItemName;
                    vResult['applicability'] = applicabilityItems.Message;
                    vResult['messageType'] = 'Error';
                    
                } else {

                    noResponses++;
                }

                questionAns = columnVal == 1 ? 'Yes' : columnVal == 2 ? 'No' : undefined;

                vResult['ItemName'] = appItems.ItemName;
                vResult['CaseApplicable'] = questionAns;

                if (!(applicabilityItems.MotherApplicable == undefined)) {

                    vResult['MotherApplicable'] = applicabilityItems.MotherApplicable == 1 ? 'Yes' : applicabilityItems.MotherApplicable == 2 ? 'No' : undefined;
                }
                
                if (!(applicabilityItems.FatherApplicable == undefined)) {

                    vResult['FatherApplicable'] = applicabilityItems.FatherApplicable == 1 ? 'Yes' : applicabilityItems.FatherApplicable == 2 ? 'No' : undefined;
                }
                
                vResult['NoResponses'] = noResponses;

                result.push(vResult);

                return result;
            };
            
            return getItemApplicability(appItems);
        },
        validateItemPreApplicability: function (source, validValues, pageName, itemName, message) {
            var self = this;
            var result = [];
            var vResult = {};
            var iCode = self.getItemCode();
            var allQuestionsAnswered = true;
            var noResponses = 0;
            var answers = {};
                        
            var multiAnswerStore = Ext.data.ChainedStore.create({
                source: 'CR_MultiAnswer_CollectionStore'
            });

            Ext.each(validValues, function (valueObj) {

                var answer = multiAnswerStore.data.items.filter(function (item) {
                    return item.data.CodeDescriptionID == valueObj.codeDescriptionId;
                });
                
                var answerCode;
                var questionAns;

                if(answer.length > 0){

                    answerCode = answer[0].data.AnswerCode;
                    questionAns = answerCode == 1 ? 'Yes' : answerCode == 2 ? 'No' : undefined;
                }

                if (Ext.isEmpty(answerCode)) {

                    allQuestionsAnswered = false;

                } else {

                    noResponses++;
                }

                answers[valueObj.itemId] = questionAns;
            });

            if (!(allQuestionsAnswered)) {

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                vResult['PreApplicability'] = message;
                vResult['messageType'] = 'Error';
            }

            vResult['Answers'] = answers;
            vResult['NoResponses'] = noResponses;
            result.push(vResult);

            return result;
        },
        validateTable1A1: function(){
            var self = this;
            var result = [];
            var table1A1 = Ext.data.StoreManager.lookup(self.getStoreId());
            var blankRows = self.getBlankRecords(self.getColumns, table1A1);
            var noTableRows = table1A1.data.length - blankRows.length;
            var columns = self.getColumns();
            var vResult = {};

            if (Ext.isEmpty(columns)) {

                return result;
            }

            vResult['table1A1RowCount'] = noTableRows;

            if (noTableRows > 0) {
                var rowNo = 0;

                Ext.each(table1A1.data.items, function (item) {
                    
                    rowNo++;
                    var column;

                    for (i = 0; i < columns.length; i++) {

                        column = columns[i];

                        // Report Date must be during the PUR.
                        if (column == 'ReportDate')
                        {
                            var reportDate = new Date(item.data[column]);
                            
                            if (!(reportDate >= self.getReviewStartDate() && reportDate <= self.getReviewEndDate())) {
                                
                                if (vResult.rowNumber == undefined) {
                                    vResult['rowNumber'] = rowNo;
                                    vResult['page'] = 'Safety';
                                    vResult['item'] = 'Table 1A1';
                                }
                                                                
                                vResult['column'] = column;
                                vResult[column + '-Message'] = 'Please enter a report date that is during the PUR.';
                                vResult['messageType'] = 'Error';
                            }

                            continue;
                        }
                        
                        // Date Assigned for an Investigation or Assessment is a required field.
                        if (column == 'DateAssessmentAssigned') {

                            if (item.data[column] == undefined || item.data[column] == null) {

                                if (vResult.rowNumber == undefined) {
                                    vResult['rowNumber'] = rowNo;
                                    vResult['page'] = 'Safety';
                                    vResult['item'] = 'Table 1A1';
                                }

                                vResult['column'] = column;
                                vResult[column + '-Message'] = 'Please select either a date or Did not occur.';
                                vResult['messageType'] = 'Error';
                            } else {
                                // Date Assigned for an Investigation or Assessment 
                                // cannot be earlier than the Report Date.
                                var dateAssigned = new Date(item.data[column]);
                                var reportDate = new Date(item.data['ReportDate']);

                                if (dateAssigned < reportDate) {
                                    if (vResult.rowNumber == undefined) {
                                        vResult['rowNumber'] = rowNo;
                                        vResult['page'] = 'Safety';
                                        vResult['item'] = 'Table 1A1';
                                    }

                                    vResult['column'] = column;
                                    vResult[column + '-Message'] = 'Please enter a date assigned for investigation that is on or after the report date.';
                                    vResult['messageType'] = 'Error';
                                }                                
                            }

                            continue;
                        }

                        // Date Investigation or Assessment Initiated is a required field.
                        if (column == 'DateAssessmentInitiated') {

                            if (item.data[column] == undefined || item.data[column] == null) {

                                if (vResult.rowNumber == undefined) {
                                    vResult['rowNumber'] = rowNo;
                                    vResult['page'] = 'Safety';
                                    vResult['item'] = 'Table 1A1';
                                }

                                vResult['column'] = column;
                                vResult[column + '-Message'] = 'Please select either a date or Did not occur.';
                                vResult['messageType'] = 'Error';
                            } else {
                                // Date Investigation or Assessment Initiated 
                                // cannot be earlier than the Report Date.
                                var dateInitiated = new Date(item.data[column]);
                                var reportDate = new Date(item.data['ReportDate']);

                                if (dateInitiated < reportDate) {
                                    if (vResult.rowNumber == undefined) {
                                        vResult['rowNumber'] = rowNo;
                                        vResult['page'] = 'Safety';
                                        vResult['item'] = 'Table 1A1';
                                    }

                                    vResult['column'] = column;
                                    vResult[column + '-Message'] = 'Please enter a date investigation or assessment was initiated that is on or after the report date.';
                                    vResult['messageType'] = 'Error';
                                }

                                // Date Investigation or Assessment Initiated cannot 
                                // be earlier than the Date Assigned for an Investigation 
                                // or Assessment.
                                var dateAssigned = new Date(item.data['DateAssessmentAssigned']);

                                if (dateInitiated < dateAssigned) {
                                    if (vResult.rowNumber == undefined) {
                                        vResult['rowNumber'] = rowNo;
                                        vResult['page'] = 'Safety';
                                        vResult['item'] = 'Table 1A1';
                                    }

                                    vResult['column'] = column;
                                    vResult[column + '-Message'] = 'Please enter a date investigation or assessment was initiated that is on or after the date assigned for investigation.';
                                    vResult['messageType'] = 'Error';
                                }
                            }

                            continue;
                        }

                        // Date of Face-to-Face Contact With Child is a required field.
                        if (column == 'DateFaceToFaceContact') {

                            if (item.data[column] == undefined || item.data[column] == null) {

                                if (vResult.rowNumber == undefined) {
                                    vResult['rowNumber'] = rowNo;
                                    vResult['page'] = 'Safety';
                                    vResult['item'] = 'Table 1A1';
                                }

                                vResult['column'] = column;
                                vResult[column + '-Message'] = 'Please select either a date or Did not occur.';
                                vResult['messageType'] = 'Error';
                            } else {
                                // Date of Face-to-Face Contact With Child cannot 
                                // be earlier than the date assigned.
                                var faceToFaceContact = new Date(item.data[column]);
                                var dateAssigned = new Date(item.data['DateAssessmentAssigned']);

                                if (faceToFaceContact < dateAssigned) {
                                    if (vResult.rowNumber == undefined) {
                                        vResult['rowNumber'] = rowNo;
                                        vResult['page'] = 'Safety';
                                        vResult['item'] = 'Table 1A1';
                                    }

                                    vResult['column'] = column;
                                    vResult[column + '-Message'] = 'Please enter a date of face-to-face contact that is on or after the date investigation or assessment was initiated.';
                                    vResult['messageType'] = 'Error';
                                }
                            }

                            continue;
                        }

                        // Name of Child is a required field.
                        if (column == 'ChildDemographicID') {

                            var childStore = chainedStore('CR_ChildDemographic_CollectionStore');
                            childStore.filter('ChildDemographicID', item.data.ChildDemographicID);

                            var childName;

                            if (childStore.data.length > 0) {
                                childName = childStore.getAt(0).data.Name;
                            }

                            if (item.data[column] == undefined || item.data[column] == null || item.data[column] == '') {

                                if (vResult.rowNumber == undefined) {
                                    vResult['rowNumber'] = rowNo;
                                    vResult['page'] = 'Safety';
                                    vResult['item'] = 'Table 1A1';
                                }

                                vResult['column'] = column;
                                vResult[column + '-Message'] = 'You have not selected the child. Please select a child who was the subject of the report.';
                                vResult['messageType'] = 'Error';
                            }

                            continue;
                        }

                        // Allegation is a required field.
                        if (column == 'SafetyReportAllegationCode') {

                            if (item.data.CR_SafetyReport_Allegation_Collection.length == 0) {
                                if (vResult.rowNumber == undefined) {
                                    vResult['rowNumber'] = rowNo;
                                    vResult['page'] = 'Safety';
                                    vResult['item'] = 'Table 1A1';
                                }

                                vResult['column'] = column;
                                vResult[column + '-Message'] = 'You have not selected an Allegation. Please select an Allegation for this report.';
                                vResult['messageType'] = 'Error';

                                continue;
                            }

                            // If Other is selected as the Allegation, the 
                            // corresponding Other narrative is a required field.
                            if (self.isOtherAllegationSelected(item.data.CR_SafetyReport_Allegation_Collection)) {
                                if (item.data.AllegationOther.trim().length == 0) {
                                    if (vResult.rowNumber == undefined) {
                                        vResult['rowNumber'] = rowNo;
                                        vResult['page'] = 'Safety';
                                        vResult['item'] = 'Table 1A1';
                                    }

                                    vResult['column'] = column;
                                    vResult[column + '-Message'] = 'For Allegation, please fill out the narrative field for a response of Other.';
                                    vResult['messageType'] = 'Error';

                                    continue;
                                }
                            } else {
                                // Text cannot be saved to the Allegation (Other) narrative field, 
                                // unless Other is checked as the Allegation.
                                if (item.data.AllegationOther.trim().length > 0) {
                                    if (vResult.rowNumber == undefined) {
                                        vResult['rowNumber'] = rowNo;
                                        vResult['page'] = 'Safety';
                                        vResult['item'] = 'Table 1A1';
                                    }

                                    vResult['column'] = column;
                                    vResult[column + '-Message'] = 'You did not answer Other to Allegation and entered narrative to explain the answer that is not required. Please remove narrative from this field.';
                                    vResult['messageType'] = 'Error';

                                    continue;
                                }
                            }

                            // Narrative text cannot be saved unless Allegation is Other.
                            if (item.data.AllegationOther.trim().length > 0) {

                                if (!(self.isOtherAllegationSelected(item.data.CR_SafetyReport_Allegation_Collection))) {
                                    if (vResult.rowNumber == undefined) {
                                        vResult['rowNumber'] = rowNo;
                                        vResult['page'] = 'Safety';
                                        vResult['item'] = 'Table 1A1';
                                    }

                                    vResult['column'] = column;
                                    vResult[column + '-Message'] = 'You did not answer Other to Allegation and entered narrative to explain the answer that is not required. Please remove narrative from this field.';
                                    vResult['messageType'] = 'Error';

                                    continue;
                                }
                            }
                        }

                        // Assessment or Investigation is a required field.
                        if (column == 'AssessmentCode') {

                            if (!(self.isValidAssessmentCode(item.data.AssessmentCode))) {

                                if (vResult.rowNumber == undefined) {
                                    vResult['rowNumber'] = rowNo;
                                    vResult['page'] = 'Safety';
                                    vResult['item'] = 'Table 1A1';
                                }

                                vResult['column'] = column;
                                vResult[column + '-Message'] = 'You have not selected Assessment or Investigation. Please select Assessment or Investigation for this report.';
                                vResult['messageType'] = 'Error';
                            }

                            continue;
                        }

                        if (column == 'PerpetratorChildRelationshipCode') {

                            // Relationship of Alleged Perpetrator to Child is a required field.
                            if (!(self.isValidPerpetratorChildRelationship(item.data.PerpetratorChildRelationshipCode))) {

                                if (vResult.rowNumber == undefined) {
                                    vResult['rowNumber'] = rowNo;
                                    vResult['page'] = 'Safety';
                                    vResult['item'] = 'Table 1A1';
                                }

                                vResult['column'] = column;
                                vResult[column + '-Message'] = 'You have not selected the Relationship of Alleged Perpetrator to Child. Please select the Relationship of Alleged Perpetrator to Child for this report.';
                                vResult['messageType'] = 'Error';

                                continue;

                            } else {
                                // If Other is selected as the Relationship of Alleged 
                                // Perpetrator to Child, the corresponding Other narrative 
                                // is a required field.
                                if (self.isOtherPerpetratorChildRelationshipSelected(item.data.PerpetratorChildRelationshipCode)) {
                                    if (item.data.PerpetratorChildRelationshipOther.trim().length == 0) {
                                        if (vResult.rowNumber == undefined) {
                                            vResult['rowNumber'] = rowNo;
                                            vResult['page'] = 'Safety';
                                            vResult['item'] = 'Table 1A1';
                                        }

                                        vResult['column'] = column;
                                        vResult[column + '-Message'] = 'For Relationship of Alleged Perpetrator to Child, please fill out the narrative field for a response of Other.';
                                        vResult['messageType'] = 'Error';

                                        continue;
                                    }
                                }
                            }

                            // Narrative text cannot be saved unless Relationship 
                            // of Alleged Perpetrator to Child is Other.
                            if (item.data.PerpetratorChildRelationshipOther.trim().length > 0) {
                                if (!(self.isOtherPerpetratorChildRelationshipSelected(item.data.PerpetratorChildRelationshipCode))) {
                                    if (vResult.rowNumber == undefined) {
                                        vResult['rowNumber'] = rowNo;
                                        vResult['page'] = 'Safety';
                                        vResult['item'] = 'Table 1A1';
                                    }

                                    vResult['column'] = column;
                                    vResult[column + '-Message'] = 'You did not answer Other to Relationship of Alleged Perpetrator to Child and entered narrative to explain the answer that is not required. Please remove narrative from this field.';
                                    vResult['messageType'] = 'Error';

                                    continue;
                                }                                
                            }
                        }

                        // DispositionCode is a required field.
                        if (column == 'DispositionCode') {

                            if (!(self.isValidDispositionCode(item.data.DispositionCode))) {

                                if (vResult.rowNumber == undefined) {
                                    vResult['rowNumber'] = rowNo;
                                    vResult['page'] = 'Safety';
                                    vResult['item'] = 'Table 1A1';
                                }

                                vResult['column'] = column;
                                vResult[column + '-Message'] = 'You have not selected the DispositionCode. Please select the DispositionCode of this report.';
                                vResult['messageType'] = 'Error';
                            }

                            continue;
                        }
                    }

                    // Duplicate rows with the same child, report date, allegation, 
                    // relationship of alleged perpetrator, and DispositionCode are not 
                    // allowed in table 1A1.
                    var duplicateRows = self.getDuplicateRows(table1A1, item, 'table1A1')

                    if (duplicateRows.length > 0) {
                        if (vResult.rowNumber == undefined) {
                            vResult['rowNumber'] = rowNo;
                            vResult['page'] = 'Safety';
                            vResult['item'] = 'Table 1A1';
                        }

                        vResult['column'] = column;
                        vResult[column + '-Message'] = 'You have entered two rows with the same child, report date, allegation, relationship of alleged perpetrator, and DispositionCode. Please change the data or return to item 1.';
                        vResult['messageType'] = 'Error';
                    }
                });
            }

            var props = getObjectKeys(vResult);

            if (props.length > 0) {
                result.push(vResult);
            }

            return result;
        },
        validateChildTable: function () {
            var self = this;
            var result = [];
            var input = this.getValidationInput();
            var store = Ext.data.StoreManager.lookup(self.getStoreId());
            var rowNo = 0;
            var vResult = {};

            var getTargetChildrenCount = function () {
                var targetChildCount = 0;

                Ext.each(store.data.items, function (row) {
                    if (row.data.IsTargetChild == 1) {
                        targetChildCount++;
                    }
                });

                return targetChildCount;
            };

            var targetChildCount = getTargetChildrenCount();

            // Only one child can be marked as the target child in table G1.
            if (targetChildCount > 1) {
                if (vResult.rowNumber == undefined) {
                    vResult['rowNumber'] = rowNo;
                }

                vResult['targetChildCount'] = 'For table G1, you entered more than one target child. Please ensure that only one child has been identified as the target child.';
                vResult['messageType'] = 'Error';
            }
            
            if (store.data.length > 0) {
                Ext.each(store.data.items, function (row) {

                    rowNo++;

                    Ext.each(input, function (columnName) {
                        
                        // Child's Name is a required field. 
                        if (columnName == 'Name') {
                            var childName = row.data.Name;
                            childName = childName == null ? '' : childName.trim();

                            if (childName.length == 0) {

                                if (vResult.rowNumber == undefined) {
                                    vResult['rowNumber'] = rowNo;
                                }

                                vResult['name'] = 'Please specify the child\'s name.';
                                vResult['messageType'] = 'Error';
                            }
                        }
                        // Race is a required field.
                        if (columnName == 'Race') {
                            var raceSelected = row.data.CR_ChildRace_Collection.length == 0 ? false : true;

                            if (!(raceSelected)) {

                                if (vResult.rowNumber == undefined) {
                                    vResult['rowNumber'] = rowNo;
                                }

                                vResult['race'] = 'Please select race.';
                                vResult['messageType'] = 'Error';
                            }
                        }
                        // Ethnicity is a required field. 
                        if (columnName == 'EthnicityCode') {
                            var ethnicityCode = row.data.EthnicityCode;

                            if (!(ethnicityCode >= 1 && ethnicityCode <= 3)) {

                                if (vResult.rowNumber == undefined) {
                                    vResult['rowNumber'] = rowNo;
                                }

                                vResult['ethnicityCode'] = 'Please select ethnicity.';
                                vResult['messageType'] = 'Error';
                            }
                        }
                        // Date of Birth is a required field. 
                        if (columnName == 'DateOfBirth') {
                            var dob = row.data.DateOfBirth;

                            if (dob == null || dob == undefined) {

                                if (vResult.rowNumber == undefined) {
                                    vResult['rowNumber'] = rowNo;
                                }

                                vResult['dateOfBirth'] = 'Please specify date of birth.';
                            } else {
                                // The date of birth entered cannot result in the child being 
                                // over 18 on the first day of the PUR (Face Sheet question C).
                                var dobObj = new Date(dob);
                                var reviewStartDate;
                                var store = Ext.data.StoreManager.lookup('CaseReviewStore');

                                if (store.data.count() > 0) {

                                    reviewStartDate = store.getAt(0).data.ReviewStartDate;
                                }

                                var purStart = new Date(reviewStartDate);
                                var age = Ext.Date.diff(dobObj, purStart, 'y');

                                if (age > 18) {
                                    if (vResult.rowNumber == undefined) {
                                        vResult['rowNumber'] = rowNo;
                                    }

                                    vResult['dateOfBirth'] = 'The date of birth you have entered indicates that the child is over 18. Please ensure that this date is correct. Cases involving children over the age of 18 at the beginning of the PUR are not eligible for assessment.';
                                    vResult['messageType'] = 'Error';
                                }
                            }
                        }
                        // Gender is a required field. 
                        if (columnName == 'GenderCode') {
                            var genderCode = row.data.GenderCode;

                            if (!(genderCode >= 1 && genderCode <= 3)) {

                                if (vResult.rowNumber == undefined) {
                                    vResult['rowNumber'] = rowNo;
                                }

                                vResult['genderCode'] = 'Please select gender.';
                                vResult['messageType'] = 'Error';
                            }
                        }

                        if (!(vResult.rowNumber == undefined)) {
                            result.push(vResult);
                        }
                    });
                });
            } else {
                // At least one child must be entered into table G1.

                if (vResult.rowNumber == undefined) {
                    vResult['rowNumber'] = rowNo;
                }

                vResult['numberOfChildren'] = 'For table G1, you have not entered any children. Please enter at least one child.';
                vResult['messageType'] = 'Error';

                if (!(vResult.rowNumber == undefined)) {
                    result.push(vResult);
                }
            }
            
            return result;
        },
        validateParticipantTable: function () {
            var self = this;
            var result = [];
            var input = this.getValidationInput();
            var store = Ext.data.StoreManager.lookup(self.getStoreId());
            var rowNo = 0;
            var vResult = {};

            var getParticipantCount = function () {
                var participantCount = 0;

                Ext.each(store.data.items, function (row) {
                    if (!(row.data.Name == undefined)) {
                        participantCount++;
                    }
                });

                return participantCount;
            };

            var participantCount = getParticipantCount();

            // At least one participant must be entered into table G2.
            if (participantCount == 0) {
                if (vResult.rowNumber == undefined) {
                    vResult['rowNumber'] = rowNo;
                }

                vResult['participantCount'] = 'For table G2, you have not entered any participants. Please enter at least one participant.';
                vResult['messageType'] = 'Error';
            }
                        
            Ext.each(store.data.items, function (row) {

                rowNo++;

                // If the Participant's Role is Other, the following narrative field is required.
                if (row.data.RoleCode == 6) {
                    vResult = {};
                    vResult['rowNumber'] = rowNo;
                    vResult['participantName'] = row.data.Name;
                    vResult['otherRole'] = 'Please fill out the Participant\'s Role narrative field for a response of Other.';
                    vResult['messageType'] = 'Error';

                    result.push(vResult);
                }

                // Participant's Name is a required field.
                var partName = row.data.Name;
                partName = partName == null ? '' : partName.trim();

                if (partName.length == 0) {

                    if (vResult.rowNumber == undefined) {
                        vResult['rowNumber'] = rowNo;
                    }

                    vResult['participantName'] = 'Please specify the Participant\'s Name.';
                    vResult['messageType'] = 'Error';
                }

                // Participant's Role is a required field.
                if (row.data.RoleCode == undefined || row.data.RoleCode == null) {

                    if (vResult.rowNumber == undefined) {
                        vResult['rowNumber'] = rowNo;
                    }

                    vResult['participantRole'] = 'Please specify the Participant\'s Role.';
                    vResult['messageType'] = 'Error';
                }

                // Relationship to Child is a required field.
                if (row.data.RelationshipToChild == undefined || row.data.RelationshipToChild == null) {

                    if (vResult.rowNumber == undefined) {
                        vResult['rowNumber'] = rowNo;
                    }

                    vResult['relationshipToChild'] = 'Please specify the Relationship to Child.';
                    vResult['messageType'] = 'Error';
                }
            });

            //if (store.data.length > 0) {
            //    Ext.each(store.data.items, function (row) {

            //        rowNo++;

            //        Ext.each(input, function (columnName) {

            //            // Child's Name is a required field. 
            //            if (columnName == 'Name') {
            //                var childName = row.data.Name;
            //                childName = childName == null ? '' : childName.trim();

            //                if (childName.length == 0) {

            //                    if (vResult.rowNumber == undefined) {
            //                        vResult['rowNumber'] = rowNo;
            //                    }

            //                    vResult['Name'] = 'Please specify the child\'s name.';
            //                }
            //            }
            //            // Race is a required field.
            //            if (columnName == 'Race') {
            //                var raceSelected = row.data.CR_ChildRace_Collection.length == 0 ? false : true;

            //                if (!(raceSelected)) {

            //                    if (vResult.rowNumber == undefined) {
            //                        vResult['rowNumber'] = rowNo;
            //                    }

            //                    vResult['Race'] = 'Please select race.';
            //                }
            //            }
            //            // Ethnicity is a required field. 
            //            if (columnName == 'EthnicityCode') {
            //                var ethnicityCode = row.data.EthnicityCode;

            //                if (!(ethnicityCode >= 1 && ethnicityCode <= 3)) {

            //                    if (vResult.rowNumber == undefined) {
            //                        vResult['rowNumber'] = rowNo;
            //                    }

            //                    vResult['EthnicityCode'] = 'Please select ethnicity.';
            //                }
            //            }
            //            // Date of Birth is a required field. 
            //            if (columnName == 'DateOfBirth') {
            //                var dob = row.data.DateOfBirth;

            //                if (dob == null || dob == undefined) {

            //                    if (vResult.rowNumber == undefined) {
            //                        vResult['rowNumber'] = rowNo;
            //                    }

            //                    vResult['DateOfBirth'] = 'Please specify date of birth.';
            //                } else {
            //                    // The date of birth entered cannot result in the child being 
            //                    // over 18 on the first day of the PUR (Face Sheet question C).
            //                    var dobObj = new Date(dob);
            //                    var reviewStartDate;
            //                    var store = Ext.data.StoreManager.lookup('CaseReviewStore');

            //                    if (store.data.count() > 0) {

            //                        reviewStartDate = store.getAt(0).data.ReviewStartDate;
            //                    }

            //                    var purStart = new Date(reviewStartDate);
            //                    var age = Ext.Date.diff(dobObj, purStart, 'y');

            //                    if (age > 18) {
            //                        if (vResult.rowNumber == undefined) {
            //                            vResult['rowNumber'] = rowNo;
            //                        }

            //                        vResult['DateOfBirth'] = 'The date of birth you have entered indicates that the child is over 18. Please ensure that this date is correct. Cases involving children over the age of 18 at the beginning of the PUR are not eligible for assessment.';
            //                    }
            //                }
            //            }
            //            // Gender is a required field. 
            //            if (columnName == 'GenderCode') {
            //                var genderCode = row.data.GenderCode;

            //                if (!(genderCode >= 1 && genderCode <= 3)) {

            //                    if (vResult.rowNumber == undefined) {
            //                        vResult['rowNumber'] = rowNo;
            //                    }

            //                    vResult['GenderCode'] = 'Please select gender.';
            //                }
            //            }

            //            if (!(vResult.rowNumber == undefined)) {
            //                result.push(vResult);
            //            }
            //        });
            //    });
            //} else {
            //    // At least one child must be entered into table G1.

            //    if (vResult.rowNumber == undefined) {
            //        vResult['rowNumber'] = rowNo;
            //    }

            //    vResult['NumberOfChildren'] = 'For table G1, you have not entered any children. Please enter at least one child.';

            //    if (!(vResult.rowNumber == undefined)) {
            //        result.push(vResult);
            //    }
            //}

            return result;
        },
        validateFacesheet: function () {
            var self = this;
            var result = [];
            var input = this.getValidationInput();
            var store;
            var workingStore;
            var vResult = {};
            var inputObj;
            var noResponses = 0;
            var validateAllFields = false;
            var pageName = 'Facesheet';
            var itemName = 'facesheet';
            var questionVal = {};
            var item;
            var columnVal;
            var errorCount = 0;
            var childDemographicGrid = chainedStore('CR_ChildDemographic_CollectionStore');
            var participantGrid = chainedStore('CR_CaseParticipant_CollectionStore');
            var questions = getFacesheetQuestions();
            var itemCode = 23;
            var outcomeCode = 21;
            var facesheetItem;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'facesheet'};

            item = getItem(23, getOutcomeCode(23));

            if (!Ext.isEmpty(item)) {

                columnVal = item.IsApplicable;
            }

            var viewModel, caseViewModel;

            if (!Ext.isEmpty(window.facesheetViewModel)) {

                //viewModel = window.facesheetViewModel.data.facesheetData.getAt(0).data;
                viewModel = window.facesheetViewModel.data;
                caseViewModel = getApplicationViewModel().data;
            }

            if (Ext.isEmpty(window.facesheetViewModel)) {

                return;
            }

            Ext.each(input, function (columnName) {

                //workingStore = Ext.data.StoreManager.lookup('CR_FaceSheet_CollectionStore');

                store = findStore('CR_FaceSheet_CollectionStore');
                facesheetItem = store;

                if (columnName == sr.Constants.AllFields) {

                    resetValidationMessages(['facesheetCenterPanel']);

                    //
                    // At least one participant must be entered into table G2. 
                    //
                    if (participantGrid.data.length > 0) {
                                                
                        noResponses++;

                        parms['ItemName'] = 'facesheet';
                        parms['Question'] = 'QuestionG2';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }

                    //
                    // At least one child must be entered into table G1. 
                    //
                    validateAllFields = true;

                    var questionVal = {};

                    if (childDemographicGrid.data.length == 0) {

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }
                        
                        vResult['item'] = itemName;
                        questionVal['Message'] = "For table G1, you have not entered any children. Please enter at least one child. ";
                        vResult['message'] = questionVal['Message'];

                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('facesheetCenterPanel');

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgTableG1', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    } else {

                        noResponses++;
                                       
                        parms['ItemName'] = 'facesheet';
                        parms['Question'] = 'QuestionG1';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }
                    //
                    // A target child should be marked for foster care cases, even if there is only one child. 
                    //
                    validateAllFields = true;

                    var questionVal = {};
                    var caseType = getCaseType();

                    var targetChildren = childDemographicGrid.data.items.filter(function (item) {
                        return (item.data.IsTargetChild == 1);
                    });

                    if (caseType == 'Foster Case' && targetChildren.length == 0) {

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = "For table G1, you have not selected a target child. Please select a target child. ";
                        vResult['message'] = questionVal['Message'];

                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('facesheetCenterPanel');

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgTableG1', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    } else {
                        noResponses++;

                    }
                }
                //
                // Question H is a required field. 
                //
                if (columnName == 'IsCaseOpenReasonOtherAbuseNeglect' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        validateAllFields = true;
                    }

                    var questionVal = {};

                    var columnVal = viewModel['isCaseOpenReasonOtherAbuseNeglect'];

                    if (Ext.isEmpty(columnVal) || columnVal == 0) {
                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = 'Facesheet';
                        }

                        vResult['questionH'] = 'Please answer question H.';
                        vResult['messageType'] = 'Error';
                        questionVal['questionH'] = 'Please answer question H.';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('questionHPanel');

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgQuestionHPanel', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }                        
                    } else {
                        noResponses++;

                        parms['ItemName'] = 'facesheet';
                        parms['Question'] = 'QuestionH';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }
                }
                
                var caseOpenDate;

                // Question I
                if (columnName == 'FirstCaseOpeningDate' || columnName == sr.Constants.AllFields) {

                    var questionVal = {};

                    caseOpenDate = viewModel['firstCaseOpeningDate'];

                    if (!Ext.isEmpty(caseOpenDate)) {
                        
                        noResponses++;

                        parms['ItemName'] = 'facesheet';
                        parms['Question'] = 'QuestionI';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);

                        var openDate = new Date(caseOpenDate);
                        var reviewEndDate = self.getReviewEndDate();

                        // The date of the first case opening in question I must be 
                        // before the last day of the PUR.
                        if (!(openDate < reviewEndDate)) {
                            if (vResult.rowNumber == undefined) {
                                vResult['page'] = 'Facesheet';
                            }

                            vResult['questionI'] = 'For question I, please enter a date of case opening that is before the last day of the PUR.';
                            vResult['messageType'] = 'Error';
                            questionVal['questionI'] = 'For question I, please enter a date of case opening that is before the last day of the PUR.';
                            errorCount++;

                            // Get the validation message component
                            var container = getCRSComponent('questionIPanel');

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgFirstCaseOpeningDate', container);

                                msgComponent.setValidationResult(questionVal);
                                msgComponent.setMsgType('Error');
                                msgComponent.updateMessages();
                            }
                        }
                    } else {

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = 'Facesheet';
                        }

                        vResult['questionI'] = 'For question I, please enter a date of case opening that is before the last day of the PUR.';
                        vResult['messageType'] = 'Error';
                        questionVal['questionI'] = 'For question I, please enter a date of case opening that is before the last day of the PUR.';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('questionIPanel');

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgFirstCaseOpeningDate', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    }
                }

                // Question J
                var fosterEntryDate;

                if (columnName == 'FosterEntryDate' || columnName == sr.Constants.AllFields) {

                    var questionVal = {};

                    var columnVal = viewModel['fosterEntryDate'];

                    var fosterEntryDateNA = viewModel['isFosterEntryDateNA'];

                    var revEndDate = caseViewModel['reviewCompletedDate'];
                    var isFosterEntryDateNA = fosterEntryDateNA == 1 ? true : false;
                    
                    if (!(isFosterEntryDateNA)) {

                        caseOpenDate = viewModel['firstCaseOpeningDate'];

                        //
                        // Question J is a required field               
                        //
                        if (Ext.isEmpty(columnVal)) {
                            if (vResult.rowNumber == undefined) {
                                vResult['page'] = 'Facesheet';
                            }

                            vResult['questionJ'] = "For question J, please enter the date of the child's most recent entry into foster care.";
                            vResult['messageType'] = 'Error';
                            questionVal['questionJ'] = "For question J, please enter the date of the child's most recent entry into foster care.";
                            errorCount++;

                        }

                        if (!(Ext.isEmpty(columnVal))) {

                            fosterEntryDate = new Date(columnVal);
                            var store = Ext.data.StoreManager.lookup('CaseReviewStore');
                            var reviewEndDate = new Date(revEndDate);
                            //
                            // Question J is a required field               
                            //
                            if (Ext.isEmpty(fosterEntryDate)) {
                                if (vResult.rowNumber == undefined) {
                                    vResult['page'] = 'Facesheet';
                                }

                                vResult['questionJ'] = "For question J, please enter the date of the child's most recent entry into foster care.";
                                vResult['messageType'] = 'Error';
                                questionVal['questionJ'] = "For question J, please enter the date of the child's most recent entry into foster care.";
                                errorCount++;

                            }
                            //
                            // Question J: Date cannot be later than the final 
                            // date of the PUR (question C).   
                            //
                            if (fosterEntryDate > reviewEndDate) {
                                if (vResult.rowNumber == undefined) {
                                    vResult['page'] = 'Facesheet';
                                }

                                vResult['questionJ'] = 'For question J, please enter a date for the target child’s most recent entry into foster care that is before the last day of the PUR.';
                                vResult['messageType'] = 'Error';
                                questionVal['questionJ'] = 'For question J, please enter a date for the target child’s most recent entry into foster care that is before the last day of the PUR.';
                                errorCount++;

                            }
                            //
                            // Question J: Date cannot be before the date 
                            // of case opening (question I).  
                            //
                            if (fosterEntryDate < caseOpenDate) {
                                if (vResult.rowNumber == undefined) {
                                    vResult['page'] = 'Facesheet';
                                }

                                vResult['questionJ'] = 'For question J, please enter a date that is on or after the date of case opening recorded in question I.';
                                vResult['messageType'] = 'Error';
                                questionVal['questionJ'] = 'For question J, please enter a date that is on or after the date of case opening recorded in question I.';
                                errorCount++;

                            }
                            //
                            // The date of target child's most recent entry into foster care (question J) 
                            // cannot be earlier than the child's date of birth.
                            //
                            var targetChild = self.getTargetChild();

                            if (!(targetChild == undefined)) {

                                var dob = targetChild.data.DateOfBirth;

                                if (!(dob == undefined || dob == null)) {

                                    if (fosterEntryDate < dob) {
                                        if (vResult.rowNumber == undefined) {
                                            vResult['page'] = 'Facesheet';
                                        }

                                        vResult['questionJ'] = 'For question J, please enter a date for the target child’s most recent entry into foster care that is on or after the date of birth of the target child.';
                                        vResult['messageType'] = 'Error';
                                        questionVal['questionJ'] = 'For question J, please enter a date for the target child’s most recent entry into foster care that is on or after the date of birth of the target child.';
                                        errorCount++;

                                    }
                                }
                            }
                        }
                        // Get the validation message component
                        var container = getCRSComponent('questionJPanel');

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgFosterEntryDatePanel', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    }

                    if ((isFosterEntryDateNA) || !(Ext.isEmpty(fosterEntryDate))) {

                        noResponses++;

                        parms['ItemName'] = 'facesheet';
                        parms['Question'] = 'QuestionJ';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }
                }

                // Question K
                if (columnName == 'EpisodeDischargeDate' || columnName == sr.Constants.AllFields) {

                    var questionVal = {};
                    var dischargeDate;
                    var dischargeDateNA;
                    var notYetdischargeDate;
                    
                    dischargeDate = viewModel['episodeDischargeDate'];
                    dischargeDateNA = viewModel['isEpisodeDischargeDateNA'];
                    notYetdischargeDate = viewModel['isEpisodeNotYetDischarged'];
                    
                    var isDischargeDateNA = dischargeDateNA == 1 ? true : false;
                    var isNotYetDischarged = notYetdischargeDate == 1 ? true : false;

                    if ((isDischargeDateNA) || (isNotYetDischarged) || !Ext.isEmpty(dischargeDate)) {

                        noResponses++;

                        parms['ItemName'] = 'facesheet';
                        parms['Question'] = 'QuestionK';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }

                    if (!(isDischargeDateNA) && !(isNotYetDischarged)) {

                        // Question K is a required field.
                        if (Ext.isEmpty(dischargeDate)) {

                            if (vResult.rowNumber == undefined) {
                                vResult['page'] = 'Facesheet';
                            }

                            vResult['questionK'] = 'Please answer question K.';
                            vResult['messageType'] = 'Error';
                            questionVal['questionK'] = 'Please answer question K.';
                            errorCount++;

                        }

                        if (!(Ext.isEmpty(dischargeDate))) {

                            var store = Ext.data.StoreManager.lookup(self.getStoreId());

                            // For foster care cases only, date of discharge 
                            // from foster care (question K) cannot be NA.
                            
                            if (dischargeDateNA == 3 && self.isFosterCareCase()) {
                                if (vResult.rowNumber == undefined) {
                                    vResult['page'] = 'Facesheet';
                                }

                                vResult['questionK'] = 'For question K, please enter a date of discharge or select Not Yet Discharged since this is a foster care case.';
                                vResult['messageType'] = 'Error';
                                questionVal['questionK'] = 'For question K, please enter a date of discharge or select Not Yet Discharged since this is a foster care case.';
                                errorCount++;

                            }

                            // For foster care cases only, the date of discharge (question K) 
                            // cannot be after the last day of the PUR (question E)
                            var reviewEndDate = self.getReviewEndDate();

                            if ((self.isFosterCareCase()) && dischargeDate > reviewEndDate) {
                                if (vResult.rowNumber == undefined) {
                                    vResult['page'] = 'Facesheet';
                                }

                                vResult['questionK'] = 'For question K, please enter a date of discharge that is on or before the last day of the PUR.';
                                vResult['messageType'] = 'Error';
                                questionVal['questionK'] = 'For question K, please enter a date of discharge that is on or before the last day of the PUR.';
                                errorCount++;

                            }

                            // For foster care cases, the date of discharge from foster care (question K) must be 
                            // after the child's most recent entry into foster care (question J).
                            var fosterCareEntryDate = self.getFosterCareEntryDate();

                            if ((self.isFosterCareCase()) && dischargeDate <= fosterEntryDate) {
                                if (vResult.rowNumber == undefined) {
                                    vResult['page'] = 'Facesheet';
                                }

                                vResult['questionK'] = 'For question K, please enter a date of discharge that is after the target child’s most recent entry into foster care.';
                                vResult['messageType'] = 'Error';
                                questionVal['questionK'] = 'For question K, please enter a date of discharge that is after the target child’s most recent entry into foster care.';
                                errorCount++;

                            }

                            // For foster care cases, the date of discharge from 
                            // foster care (question K) must be after the child's date of birth.
                            var targetChild = self.getTargetChild();

                            if (!(targetChild == undefined)) {
                                if ((self.isFosterCareCase()) && dischargeDate < targetChild.data.DateOfBirth) {
                                    if (vResult.rowNumber == undefined) {
                                        vResult['page'] = 'Facesheet';
                                    }

                                    vResult['questionK'] = 'For question K, please enter a date of discharge that is after the date of birth of the target child.';
                                    vResult['messageType'] = 'Error';
                                    questionVal['questionK'] = 'For question K, please enter a date of discharge that is after the date of birth of the target child.';
                                    errorCount++;

                                }
                            }
                        }

                        // Get the validation message component
                        var container = getCRSComponent('questionKPanel');

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgEpisodeDischargeDate', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    }
                }

                // Question L
                if (columnName == 'CaseClosureDate' || columnName == sr.Constants.AllFields) {

                    var questionVal = {};
                    var closureDate;
                    var caseNotClosed;

                    var fosterCareEntryDate = self.getFosterCareEntryDate();
                    
                    closureDate = viewModel['caseClosureDate'];
                    caseNotClosed = viewModel['isCaseClosureNotClosed'];

                    if (caseNotClosed == 1 || !Ext.isEmpty(closureDate)) {

                        noResponses++;

                        parms['ItemName'] = 'facesheet';
                        parms['Question'] = 'QuestionL';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }

                    if (!(caseNotClosed == 1)) {

                        // The date of the most recent case closure in question L cannot be 
                        // before the date of the child's most recent entry into foster 
                        // care in question J.
                        if (self.isFosterCareCase()) {

                            if (!(Ext.isEmpty(closureDate)) && !(Ext.isEmpty(fosterEntryDate))) {

                                if (closureDate < fosterEntryDate) {
                                    if (vResult.rowNumber == undefined) {
                                        vResult['page'] = 'Facesheet';
                                    }

                                    vResult['questionL'] = 'For question L, please enter the date of the most recent case closure that is after the target child\'s most recent entry into foster care.';
                                    vResult['messageType'] = 'Error';
                                    questionVal['questionL'] = 'For question L, please enter the date of the most recent case closure that is after the target child\'s most recent entry into foster care.';
                                    errorCount++;

                                }
                            }
                        }                        
                        // For foster care cases only, if question K is Not Yet Discharged, 
                        // question L must be Case not closed by time of review.
                        if ((self.isFosterCareCase()) && !(self.isCaseDischarged())) {

                            var revStartDate = self.getReviewStartDate();

                            if (closureDate < revStartDate) {
                                if (vResult.rowNumber == undefined) {
                                    vResult['page'] = 'Facesheet';
                                }

                                vResult['questionL'] = 'For question L, please select Case not closed by time of review since question K is Not Yet Discharged.';
                                vResult['messageType'] = 'Error';
                                questionVal['questionL'] = 'For question L, please select Case not closed by time of review since question K is Not Yet Discharged.';
                                errorCount++;

                            }
                        }

                        // The date of the most recent case closure (question L) must 
                        // be on or before the last day of the PUR (question E).
                        if (!(Ext.isEmpty(closureDate))) {
                            var reviewEndDate = self.getReviewEndDate();

                            if (!(Ext.isEmpty(reviewEndDate))) {

                                if (closureDate > reviewEndDate) {

                                    if (vResult.rowNumber == undefined) {
                                        vResult['page'] = 'Facesheet';
                                    }

                                    vResult['questionL'] = 'For question L, please enter the date of the most recent case closure that is on or before the last day of the PUR.';
                                    vResult['messageType'] = 'Error';
                                    questionVal['questionL'] = 'For question L, please enter the date of the most recent case closure that is on or before the last day of the PUR.';
                                    errorCount++;

                                }
                            }
                        }

                        // The date of the most recent case closure (question L) 
                        // must be on or after the first day of the PUR (question C).
                        if (!(closureDate == undefined || closureDate == null)) {
                            var reviewStartDate = self.getReviewStartDate();

                            if (closureDate < reviewStartDate) {
                                if (vResult.rowNumber == undefined) {
                                    vResult['page'] = 'Facesheet';
                                }

                                vResult['questionL'] = 'For question L, please enter the date of the most recent case closure that is on or after the first day of the PUR.';
                                vResult['messageType'] = 'Error';
                                questionVal['questionL'] = 'For question L, please enter the date of the most recent case closure that is on or after the first day of the PUR.';
                                errorCount++;

                            }
                        }

                        // For non-foster care cases, the date of the most recent case 
                        // closure (question L) cannot be on or before the date the 
                        // case was opened for services during the PUR (question I).
                        if (!(Ext.isEmpty(closureDate))) {
                            var openDate = self.getCaseOpenDate();

                            if (!(self.isFosterCareCase()) && !(closureDate > openDate)) {
                                if (vResult.rowNumber == undefined) {
                                    vResult['page'] = 'Facesheet';
                                }

                                vResult['questionL'] = 'For question L, please enter the date of the most recent case closure that is after the date the case was opened for services during the PUR.';
                                vResult['messageType'] = 'Error';
                                questionVal['questionL'] = 'For question L, please enter the date of the most recent case closure that is after the date the case was opened for services during the PUR.';
                                errorCount++;

                            }
                        }

                        // For foster care cases only, the date of the most recent case 
                        // closure (question L) must be after the date of birth of the 
                        // target child (if a date of birth is entered). 
                        if (!(closureDate == undefined || closureDate == null)) {
                            var targetChild = self.getTargetChild();

                            // Ritesh : put the check if targetChild is empty to fix the case review search.
                            if (!Ext.isEmpty(targetChild)) {


                                if (!(targetChild.data.DateOfBirth == undefined || targetChild.data.DateOfBirth == null)) {
                                    if ((self.isFosterCareCase()) && !(closureDate > targetChild.data.DateOfBirth)) {
                                        if (vResult.rowNumber == undefined) {
                                            vResult['page'] = 'Facesheet';
                                        }

                                        vResult['questionL'] = 'For question L, please enter the date of the most recent case closure that is after the date of birth of the target child.';
                                        vResult['messageType'] = 'Error';
                                        questionVal['questionL'] = 'For question L, please enter the date of the most recent case closure that is after the date of birth of the target child.';
                                        errorCount++;

                                    }
                                }
                            }
                        }

                        // Question L cannot save both a date and 
                        // "Case not closed by time of review". 
                        if (!(closureDate == undefined || closureDate == null)) {
                            var notClosed = self.isCaseNotClosedByTimeOfReview();

                            if (notClosed) {
                                if (vResult.rowNumber == undefined) {
                                    vResult['page'] = 'Facesheet';
                                }

                                vResult['questionL'] = 'Please answer question L.';
                                vResult['messageType'] = 'Error';
                                questionVal['questionL'] = 'Please answer question L.';
                                errorCount++;

                                result.push(vResult);
                            }
                        }

                        // Question L is a required field. 
                        if (closureDate == undefined || closureDate == null) {
                            var notClosed = self.isCaseNotClosedByTimeOfReview();

                            if (!(notClosed)) {
                                if (vResult.rowNumber == undefined) {
                                    vResult['page'] = 'Facesheet';
                                }

                                vResult['questionL'] = 'For question L, please either specify a date or choose Case not closed by time of review.';
                                vResult['messageType'] = 'Error';
                                questionVal['questionL'] = 'For question L, please either specify a date or choose Case not closed by time of review.';
                                errorCount++;

                            }
                        }

                        // Get the validation message component
                        var container = getCRSComponent('questionLPanel');

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgCaseClosureDate', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    }
                }
            });

            // Question M is a required field.
            store = Ext.data.StoreManager.lookup(self.getStoreId());

            var questionVal = {};

            // Need to get the current selections
            var checkBoxGroup = self.getCheckBoxGroup('CR_MultiAnswer_CollectionStore', 'CaseReason');
            var multiAnswers = getMultiAnswerStore('CaseReason');

            if (multiAnswers.data.length == 0) {
                if (vResult.rowNumber == undefined) {
                    vResult['page'] = 'Facesheet';
                }

                vResult['questionM'] = 'Please answer question M.';
                vResult['messageType'] = 'Error';
                questionVal['questionM'] = 'Please answer question M.';
                errorCount++;

            } else {

                noResponses++;

                parms['ItemName'] = 'facesheet';
                parms['Question'] = 'QuestionM';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            // If question M is Other, the following narrative field is required.
            var otherNarrative;
            var facesheetStore = findStore('CR_FaceSheet_CollectionStore');

            if (!Ext.isEmpty(facesheetStore)) {

                otherNarrative = facesheetStore.data.OtherCaseReason;
            }
            
            otherNarrative = otherNarrative == undefined ? '' : otherNarrative == null ? '' : otherNarrative.trim();
            var otherCheckbox;

            Ext.each(multiAnswers.data.items, function (checkBox) {
                if (checkBox.data.CodeDescriptionID == 14 && otherNarrative.length == 0) {
                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = 'Facesheet';
                    }

                    vResult['questionM'] = 'For question M, please fill out the narrative field for a response of Other.';
                    vResult['messageType'] = 'Error';
                    questionVal['questionM'] = 'For question M, please fill out the narrative field for a response of Other.';
                    errorCount++;

                }

                if (checkBox.data.CodeDescriptionID == 14) {
                    otherCheckbox = checkBox;
                }
            });

            // Narrative text cannot be saved unless Face Sheet question M is Other. 
            if (otherNarrative.length > 0 && otherCheckbox == undefined) {
                if (vResult.rowNumber == undefined) {
                    vResult['page'] = 'Facesheet';
                }

                vResult['questionM'] = 'For question M, please fill out the narrative field for a response of Other.';
                vResult['messageType'] = 'Error';
                questionVal['questionM'] = 'For question M, please fill out the narrative field for a response of Other.';
                errorCount++;

            }

            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 23;
            vResult['OutcomeCode'] = 21;

            result.push(vResult);

            var facesheetQuestions = getFacesheetQuestions();
            facesheetQuestions[0].errorsExist = false;

            if (errorCount > 0) {

                facesheetQuestions[0].errorsExist = true;
            }

            // Get the validation message component
            var container = getCRSComponent('questionMPanel');

            if (!(container == undefined)) {
                var msgComponent = getCRSComponent('msgQuestionM', container);

                msgComponent.setValidationResult(questionVal);
                msgComponent.setMsgType('Error');
                msgComponent.updateMessages();
            }

            validationResults['facesheet'] = result;

            // Make item status accessible
            var itemStatus;
            var facesheet = getCRSComponent('facesheetCenterPanel');

            itemStatus = getItemStatus(vResult['ItemCode']);

            result['itemStatus'] = itemStatus;
            itemStatuses['facesheet'] = itemStatus;

            return result;
        },
        validateItem1: function(input){
            var self = this;
            var result = [];
            var input = self.getValidationInput();
            var vResult = {};
            var applicabilityItems = {};
            var answers = [];
            var inputObj;
            var noResponses = 0;
            var validateAllFields = false;
            var pageName = 'Safety';
            var itemName = 'item1';
            var questions = getItemQuestions('item1');
            var itemCode = 2;
            var outcomeCode = 1;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'safety' };
            var errorCount = 0;
            var safetyStoreId = 'CR_SafetyReport_CollectionStore';
            var table1A1Columns = ["ReportDate", "ChildDemographicID", "SafetyReportAllegationCode", "PriorityLevel", "AssessmentCode",
                                   "DateAssessmentAssigned", "DateAssessmentInitiated", "DateFaceToFaceContact",
                                   "PerpetratorChildRelationshipCode", "DispositionCode"];

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.safetyViewModel)) {

                var vModel = createViewModel('safety');

                window.safetyViewModel = vModel;
            }

            if (!Ext.isEmpty(window.safetyViewModel)) {

                viewModel = window.safetyViewModel.data;
                isViewModelValid = true;
            }

            Ext.each(input, function (columnName) {

                var store = Ext.data.StoreManager.lookup(safetyStoreId);

                // Item 1 applicability is a required field. 
                if (columnName == 'Applicability' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        resetValidationMessages(['question1BContainer', 'question1CContainer']);

                        validateAllFields = true;
                    }

                    var validValues = [1, 2];

                    applicabilityItems['Source'] = store;
                    applicabilityItems['ValidValues'] = validValues;
                    applicabilityItems['PageName'] = pageName;
                    applicabilityItems['ItemName'] = itemName;
                    applicabilityItems['Message'] = 'Please select Yes or No.';
                    applicabilityItems['ItemCode'] = itemCode;
                    applicabilityItems['OutcomeCode'] = outcomeCode;

                    result = self.validateItemApplicability(applicabilityItems);

                    if (!Ext.isEmpty(result[0].CaseApplicable)) {

                        noResponses++;

                        parms['ItemName'] = 'item1';
                        parms['Question'] = 'Applicability';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }
                }

                if (columnName == 'ValidateItem1' || columnName == sr.Constants.AllFields) {
                    var table1A1 = Ext.data.StoreManager.lookup(safetyStoreId);
                    var blankRows = self.getBlankRecords(table1A1Columns, table1A1);
                    var noTableRows = table1A1.data.length - blankRows.length;

                    if (noTableRows > 0) {

                        noResponses++;

                        parms['ItemName'] = 'item1';
                        parms['Question'] = 'Question1A1';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    // If there is only one row saved to table 1A1, 
                    // that row can be edited but not deleted.
                    if (noTableRows == 1) {
                        
                        vResult['item'] = itemName;
                        vResult['canDelete'] = false;
                        vResult['message'] = 'This row cannot be deleted from table 1A1. Please click on the report date to edit.';
                        vResult['messageType'] = 'Info';

                    }

                    // If a substantiated or indicated maltreatment report is checked in 
                    // question 3D1, the item 1 page cannot then be saved with no 
                    // substantiated or indicated reports in table 1A1.
                    var incidents = self.getCheckBoxGroup('CR_MultiAnswer_CollectionStore', 'SafetyRelatedIncidents');
                    var maltreatmenReportChecked = false;

                    Ext.each(incidents.items, function (incident) {

                        if (incident.data.CodeDescriptionID == 88 || incident.data.CodeDescriptionID == 89) {
                            maltreatmenReportChecked = true;

                            return false;
                        }
                    });

                    if ((maltreatmenReportChecked) && noTableRows == 0) {
                        
                        vResult['item'] = itemName;
                        vResult['item1'] = 'You indicated in question 3D1 that there was a substantiated or indicated maltreatment report. Please compare the information you have in table 1A1 to ensure that you selected substantiated or indicated for the DispositionCode of a report during the PUR.';
                        vResult['messageType'] = 'Info';

                    }

                    // If a substantiated or indicated maltreatment report is 
                    // checked in question 3D1, item 1 cannot then be saved as NA.
                    var itemStore = Ext.data.ChainedStore.create({
                        source: 'CR_Item_CollectionStore',
                        filters: [
                            function (record) {
                                return record.data.ItemCode == itemCode;
                            }
                        ]
                    });

                    var item1Rating;

                    if (itemStore.data.length > 0) {
                        item1Rating = itemStore.getAt(0).data.ItemRatingCode;
                    }
                    
                    if ((maltreatmenReportChecked) && item1Rating == 3) {
                        
                        vResult['item'] = itemName;
                        vResult['item1'] = 'You indicated in question 3D1 that there were maltreatment reports during the PUR. Please change your answers to question 3D1 or mark item 1 as applicable.';
                        vResult['messageType'] = 'Error';
                        errorCount++;
                    }

                    // If a substantiated or indicated maltreatment report is 
                    // checked in question 3F1, item 1 cannot then be saved as NA.                    
                    if ((maltreatmenReportChecked) && item1Rating == 3) {
                        
                        vResult['item'] = itemName;
                        vResult['item1'] = 'You indicated in question 3F1 that there were maltreatment reports during the PUR. Please change your answers to question 3F1 or mark item 1 as applicable.';
                        vResult['messageType'] = 'Error';
                        errorCount++;
                    }

                    // Validate Table 1A1
                    var tableValidationResults = self.validateTable1A1();

                    if (!Ext.isEmpty(tableValidationResults)) {

                        if (tableValidationResults.length > 0) {
                            result = result.concat(tableValidationResults);
                        }
                    }
                    
                    // Question 1A is a required field and must be numeric.
                    var safetyStore = Ext.data.ChainedStore.create({
                        source: 'CR_Safety_CollectionStore'
                    });

                    var safetyReportStore = Ext.data.ChainedStore.create({
                        source: 'CR_SafetyReport_CollectionStore'
                    });

                    var answer1A;
                    var questionVal = {};

                    if (isViewModelValid) {

                        answer1A = viewModel['reportsNotInAccordance'];

                    } else {

                        if (safetyStore.data.length > 0) {

                            answer1A = safetyStore.getAt(0).data.ReportsNotInAccordance;
                        }
                    }
                                        
                    if (!Ext.isEmpty(answer1A)) {
                    
                        if (noTableRows > 0) {

                            parms['ItemName'] = 'item1';
                            parms['Question'] = 'Question1A';
                            parms['Answered'] = true;

                            updateQuestionsAnswered(parms);

                            // Get the validation message component and delete all error messages.
                            var container = getCRSComponent('question1AContainer', appPages.Safety);

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgQuestion1A', container);
                                                                
                                msgComponent.initMessages();
                            }
                        }
                    }
                    
                    if (Ext.isEmpty(answer1A) || isNaN(answer1A)) {
                        
                        vResult['item'] = 'Item1A';
                        vResult['item1A'] = 'For question 1A, please enter a number.';
                        vResult['messageType'] = 'Error';
                        questionVal['item1A'] = 'For question 1A, please enter a number.';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('question1AContainer', appPages.Safety);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgQuestion1A', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    } else {

                        noResponses++;                     
                    }

                    // Question 1B is a required field and must be numeric.                    
                    var answer1B;
                    var delayReason;

                    questionVal = {};

                    if (isViewModelValid) {

                        answer1B = viewModel['faceToFaceReportsNotInAccordance'];
                        delayReason = viewModel['delayReason'];

                    } else {

                        if (safetyStore.data.length > 0) {

                            answer1B = safetyStore.getAt(0).data.FaceToFaceReportsNotInAccordance;
                            delayReason = safetyStore.getAt(0).data.DelayReason;
                        }
                    }
                    
                    answer1B = Ext.isEmpty(answer1B) ? safetyStore.getAt(0).data.FaceToFaceReportsNotInAccordance : answer1B;
                    delayReason = Ext.isEmpty(delayReason) ? safetyStore.getAt(0).data.DelayReason : delayReason;

                    if (!Ext.isEmpty(answer1B)) {

                        if (noTableRows > 0) {

                            parms['ItemName'] = 'item1';
                            parms['Question'] = 'Question1B';
                            parms['Answered'] = true;

                            updateQuestionsAnswered(parms);
                            
                            // Get the validation message component and delete all error messages.
                            var container = getCRSComponent('question1BContainer', appPages.Safety);

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgQuestion1B', container);

                                msgComponent.initMessages();
                            }
                        }
                    }

                    if (Ext.isEmpty(answer1B) || isNaN(answer1B)) {
                        
                        vResult['item'] = 'Item1B';
                        vResult['item1B'] = 'For question 1B, please enter a number.';
                        vResult['messageType'] = 'Error';
                        questionVal['item1B'] = 'For question 1B, please enter a number.';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('question1BContainer', appPages.Safety);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgQuestion1B', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    } else {

                        noResponses++;

                    }

                    // If either question 1A or 1B is greater than zero, 
                    // the following narrative field is required.
                    if (answer1A > 0 || answer1B > 0) {

                        noResponses++;

                        if (!(delayReason == undefined)) {
                            if (delayReason.trim().length == 0) {
                                
                                vResult['item'] = 'Item1B';
                                vResult['item1B'] = 'Please fill out the narrative field if question 1A or 1B is greater than zero.';
                                vResult['messageType'] = 'Error';
                                questionVal['item1B'] = 'Please fill out the narrative field if question 1A or 1B is greater than zero.';
                                errorCount++;

                                // Get the validation message component
                                var container = getCRSComponent('question1BContainer', appPages.Safety);

                                if (!(container == undefined)) {
                                    var msgComponent = getCRSComponent('msgQuestion1B', container);

                                    msgComponent.setValidationResult(questionVal);
                                    msgComponent.setMsgType('Error');
                                    msgComponent.updateMessages();
                                }
                            }
                        }
                    }

                    // If questions 1A and 1B are both either blank or zero, 
                    // no text can be saved in the following narrative field 
                    // (i.e. either question 1A or 1B must be greater than zero 
                    // for the narrative field to be applicable).
                    if ((answer1A == undefined || isNaN(answer1A)) && (answer1B == undefined || isNaN(answer1B))) {

                        if (!(delayReason == undefined)) {

                            if (delayReason.trim().length > 0) {
                                
                                vResult['item'] = 'Item1B';
                                vResult['item1B'] = 'You have not entered a number greater than zero for question 1A or 1B and have entered a narrative explanation that was not required. Please remove the narrative explanation. Please provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field in the rating section of this item.';
                                vResult['messageType'] = 'Error';
                                questionVal['item1B'] = 'You have not entered a number greater than zero for question 1A or 1B and have entered a narrative explanation that was not required. Please remove the narrative explanation. Please provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field in the rating section of this item.';
                                errorCount++;

                                // Get the validation message component
                                var container = getCRSComponent('question1BContainer', appPages.Safety);

                                if (!(container == undefined)) {
                                    var msgComponent = getCRSComponent('msgQuestion1B', container);

                                    msgComponent.setValidationResult(questionVal);
                                    msgComponent.setMsgType('Error');
                                    msgComponent.updateMessages();
                                }
                            }
                        }
                    }

                    questionVal = {};

                    var answer1C;
                    
                    if (isViewModelValid) {

                        answer1C = viewModel['isDelayBeyondAgencyControl'];
                    } else {

                        answer1C = safetyStore.getAt(0).data.IsDelayBeyondAgencyControl;
                    }

                    answer1C = Ext.isEmpty(answer1C) ? safetyStore.getAt(0).data.IsDelayBeyondAgencyControl : answer1C;

                    // If questions 1A and 1B are both zero, question 1C must be NA.
                    if ((answer1A == undefined || isNaN(answer1A) || answer1A == 0) && (answer1B == undefined || isNaN(answer1B) || answer1B == 0) && safetyReportStore.count() > 0) {
                        
                        if (Ext.isEmpty(answer1C)) {

                            vResult['item'] = 'Item1C';
                            vResult['item1C'] = 'For question 1C, please select NA since both questions 1A and 1B are zero.';
                            vResult['messageType'] = 'Error';
                            questionVal['item1C'] = 'For question 1C, please select NA since both questions 1A and 1B are zero.';
                            errorCount++;

                            // Get the validation message component
                            var container = getCRSComponent('question1CContainer', appPages.Safety);

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgQuestion1C', container);

                                msgComponent.setValidationResult(questionVal);
                                msgComponent.setMsgType('Error');
                                msgComponent.updateMessages();
                            }
                        }
                    }

                    if (!Ext.isEmpty(answer1C)) {

                        parms['ItemName'] = 'item1';
                        parms['Question'] = 'Question1C';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }

                    // Question 1C cannot be NA if questions 1A or 1B are greater than zero.
                    if (answer1A > 0 || answer1B > 0 && safetyReportStore.count() > 0) {
                                                
                        if ((answer1C < 1 || answer1C > 2) || Ext.isEmpty(answer1C)) {

                            vResult['item'] = 'Item1C';
                            vResult['item1C'] = 'For question 1C, please select Yes or No since delays related to reports are indicated in question 1A or 1B.';
                            vResult['messageType'] = 'Error';
                            questionVal['item1C'] = 'For question 1C, please select Yes or No since delays related to reports are indicated in question 1A or 1B.';
                            errorCount++;

                            // Get the validation message component
                            var container = getCRSComponent('question1CContainer', appPages.Safety);

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgQuestion1C', container);

                                msgComponent.setValidationResult(questionVal);
                                msgComponent.setMsgType('Error');
                                msgComponent.updateMessages();
                            }
                        }
                    }
                }
            });

            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 2;
            vResult['OutcomeCode'] = 1;

            result.push(vResult);

            if (input[0] == sr.Constants.AllFields) {

                validationResults['item1'] = result;
            }

            var itemQuestions = getItemQuestions('item1');
            itemQuestions[0].errorsExist = false;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus)
            {
                errorCount = 0;
            }

            if (errorCount > 0) {

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            return result;
        },
        validateItem2: function (input) {
            var self = this;
            var result = [];
            var input = self.getValidationInput();
            var vResult = {};
            var questionVal = {};
            var applicabilityItems = {};
            var inputObj;
            var validateAllFields = false;
            var anyFirst5Yes = false;
            var anyFirst5No = false;
            var allFirst5No = false;
            var question6Answer;
            var noResponses = 0;
            var pageName = 'Safety';
            var itemName = 'item2';
            var questions = getItemQuestions('item2');
            var itemCode = 3;
            var outcomeCode = 2;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'safety' };
            var safetyStoreId = 'CR_SafetyReport_CollectionStore';
            var errorCount = 0;

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.safetyViewModel)) {

                var vModel = createViewModel('safety');

                window.safetyViewModel = vModel;
            }
            
            if (!Ext.isEmpty(window.safetyViewModel)) {

                viewModel = window.safetyViewModel.data;
                isViewModelValid = true;
            }

            Ext.each(input, function (columnName) {

                // All pre-applicability questions must be answered.
                if (columnName == 'PreApplicability' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        resetValidationMessages(['safetyItem2', 'question2APanel', 'question2BPanel']);

                        validateAllFields = true;
                    }

                    var store = Ext.data.StoreManager.lookup('CR_MultiAnswer_CollectionStore');
                    questionVal = {};

                    var inHomeValues = [{ itemId: 'item2Question1', codeDescriptionId: 51 },
                                       { itemId: 'item2Question2', codeDescriptionId: 52 },
                                       { itemId: 'item2Question6', codeDescriptionId: 56 }
                    ];

                    var fosterCareValues = [{ itemId: 'item2Question3', codeDescriptionId: 53 },
                                       { itemId: 'item2Question4', codeDescriptionId: 54 },
                                       { itemId: 'item2Question5', codeDescriptionId: 55 },
                                       { itemId: 'item2Question6', codeDescriptionId: 56 }
                    ];

                    var caseType = getCaseType();
                    var validValues = (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') ? inHomeValues : fosterCareValues;

                    result = self.validateItemPreApplicability(store, validValues, 'Safety', 'Item2', 'Please answer all questions on this page.');

                    if (result.length > 0) {

                        if (result[0].NoResponses == validValues.length) {

                            noResponses++;

                            parms['ItemName'] = 'item2';
                            parms['Question'] = 'PreApplicability';
                            parms['Answered'] = true;

                            updateQuestionsAnswered(parms);
                        }

                        if (!Ext.isEmpty(result[0].PreApplicability)) {

                            questionVal['PreApplicability'] = result[0].PreApplicability;

                        }
                                                
                        var first5NoCount = (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') ? 3 :
                                            caseType == 'Foster Case' ? 2 : 0;


                        var questionAnswers = result[0].Answers;
                        
                        question6Answer = questionAnswers['item2Question6'];

                        for (key in questionAnswers) {

                            if (questionAnswers[key] == 'Yes') {

                                anyFirst5Yes = true;
                            }

                            if (questionAnswers[key] == 'No') {

                                anyFirst5No = true;

                                if (!(key == 'item2Question6')) {

                                    first5NoCount++;
                                }                                
                            }

                            if (first5NoCount > 4) {

                                allFirst5No = true;
                            }
                        }

                        var errors = result.filter(function (obj) {

                            return obj.messageType == 'Error';
                        });

                        if (errors.length > 0) {

                            errorCount++;

                            // Get the validation message component
                            var container = getCRSComponent('item2PreApplicableCases', appPages.Safety);

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgItem2PreApplicableCases', container);

                                msgComponent.setValidationResult(questionVal);
                                msgComponent.updateMessages();
                            }
                        }
                    }                    
                }

                // Item 2 applicability is a required field. 
                if (columnName == 'Applicability' || columnName == sr.Constants.AllFields) {

                    questionVal = {};
                    //var store = Ext.data.StoreManager.lookup(self.getStoreId());
                    var store = Ext.data.StoreManager.lookup('CR_Item_CollectionStore');

                    var validValues = [1, 2];

                    applicabilityItems['Source'] = store;
                    applicabilityItems['ValidValues'] = validValues;
                    applicabilityItems['PageName'] = pageName;
                    applicabilityItems['ItemName'] = itemName;
                    applicabilityItems['Message'] = 'Please select Yes or No.';
                    applicabilityItems['ItemCode'] = itemCode;
                    applicabilityItems['OutcomeCode'] = outcomeCode;

                    result = result.concat(self.validateItemApplicability(applicabilityItems));

                    if (!Ext.isEmpty(result[result.length - 1].CaseApplicable == 'Yes')) {

                        noResponses++;
                        
                        parms['ItemName'] = 'item2';
                        parms['Question'] = 'Applicability';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);

                        if (!Ext.isEmpty(result[0].Applicability)) {

                            questionVal['Applicability'] = result[0].applicability;
                        }

                        // Get other validation messages
                        if ((anyFirst5Yes) && question6Answer == 'No') {

                            if (result[result.length - 1].CaseApplicable == 'No') {

                                questionVal['Applicability_1'] = 'The answers above indicate that this case is applicable. Please review answers above.';
                            }                            
                        }

                        if ((anyFirst5Yes) && question6Answer == 'Yes') {

                            if (result[result.length - 1].CaseApplicable == 'Yes') {

                                questionVal['Applicability_2'] = 'The answers above indicate that this case is not applicable. Please review answers above.';
                            }                            
                        }

                        if ((allFirst5No) && question6Answer == 'Yes') {

                            if (result[result.length - 1].CaseApplicable == 'Yes') {

                                questionVal['Applicability_3'] = 'The answers above indicate that this case is not applicable. Please review answers above.';
                            }                            
                        }

                        if ((allFirst5No) && question6Answer == 'No') {

                            if (result[result.length - 1].CaseApplicable == 'Yes') {

                                questionVal['Applicability_4'] = 'The answers above indicate that this case is not applicable. Please review answers above.';
                            }                            
                        }

                        var noProps = getObjectKeys(questionVal).length;

                        if (noProps > 0) {

                            errorCount++;

                            // Get the validation message component
                            var container = getCRSComponent('item2CaseContainer', appPages.Safety);

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgItem2CaseApplicable', container);

                                msgComponent.setValidationResult(questionVal);
                                msgComponent.updateMessages();
                            }
                        }                        
                    }
                }
            });
            
            // Get answers to question 2A and 2B
            var safetyStore = Ext.data.ChainedStore.create({
                source: 'CR_Safety_CollectionStore'
            });

            var answer2A;
            var answer2B;
            var narrative2A;
            var narrative2B;

            if (safetyStore.data.length > 0) {

                questionVal = {};

                vResult['PageName'] = pageName;
                vResult['ItemName'] = itemName;

                if (isViewModelValid) {

                    answer2A = viewModel['isEffortToPreventReEntry'];
                    narrative2A = viewModel['effortToPreventReEntryExplained'];
                    answer2B = viewModel['isChildRemovedToEnsureSafety'];
                    narrative2B = viewModel['childRemovedToEnsureSafetyExplained'];

                } else {

                    answer2A = safetyStore.getAt(0).data.IsEffortToPreventReEntry;
                    narrative2A = safetyStore.getAt(0).data.EffortToPreventReEntryExplained;
                    answer2B = safetyStore.getAt(0).data.IsChildRemovedToEnsureSafety;
                    narrative2B = safetyStore.getAt(0).data.ChildRemovedToEnsureSafetyExplained;
                }

                vResult['item2Question2A'] = answer2A == 1 ? 'Yes' : answer2A == 2 ? 'No' : undefined;
                vResult['item2Question2B'] = answer2B == 1 ? 'Yes' : answer2B == 2 ? 'No' : answer2B == 3 ? 'NA' : undefined;

                if (!Ext.isEmpty(vResult['item2Question2A'])) {

                    noResponses++;

                    parms['ItemName'] = 'item2';
                    parms['Question'] = 'Question2A';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (!Ext.isEmpty(vResult['item2Question2B'])) {

                    noResponses++;

                    parms['ItemName'] = 'item2';
                    parms['Question'] = 'Question2B';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (!Ext.isEmpty(narrative2A)) {

                    noResponses++;
                }

                if (!Ext.isEmpty(narrative2B)) {

                    noResponses++;
                }

                if (answer2A == 1 && answer2B == 2) {
                    
                    vResult['Message'] = 'The answer to question 2B cannot be No if the answer to question 2A is Yes. Please review your answers and refer to the instructions for guidance.';
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item2Question2B', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem2Question2B', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }

                if (answer2A == 2 && narrative2A.length == 0) {

                    questionVal = {};

                    vResult['Message'] = 'For question 2A, please fill out the narrative field for a response of No.';
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('question2ANarrative', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgQuestion2ANarrative', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }

                if (answer2B == 2 && narrative2B.length == 0) {

                    questionVal = {};

                    vResult['Message'] = 'For question 2B, please fill out the narrative field for a response of No.';
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('question2BNarrative', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgQuestion2BNarrative', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
            }

            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 3;
            vResult['OutcomeCode'] = 2;

            result.push(vResult);

            if (input[0] == sr.Constants.AllFields) {

                validationResults['item2'] = result;
            }

            var itemQuestions = getItemQuestions('item2');
            itemQuestions[0].errorsExist = false;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus) {
                errorCount = 0;
            }

            if (errorCount > 0) {

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            return result;
        },
        validateItem3: function (input) {
            var self = this;
            var result = [];
            var vResult = {};
            var applicabilityItems = {};
            var inputObj;
            var validateAllFields = false;
            var noResponses = 0;
            var pageName = 'Safety';
            var itemName = 'item3';
            var questions = getItemQuestions('item3');
            var itemCode = 4;
            var outcomeCode = 2;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'safety' };
            var errorCount = 0;
            
            // Get answers to question 2A and 2B
            var safetyStore = Ext.data.ChainedStore.create({
                source: 'CR_Safety_CollectionStore'
            });

            var answer3A;
            var answer3A1A;
            var answer3A1B;
            var answer3B;
            var answer3C;
            var answer3D;
            var answer3D1;
            var answer3E;
            var answer3E1;
            var answer3F;
            var answer3F1;
            var narrative3A;
            var narrative3B;
            var narrative3C;
            var narrative3D1;
            var narrative3E1;
            var narrative3F1;
            var questionD1CheckBoxGroup;
            var questionE1CheckBoxGroup;
            var questionF1CheckBoxGroup;

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.safetyViewModel)) {

                var vModel = createViewModel('safety');

                window.safetyViewModel = vModel;
            }

            if (!Ext.isEmpty(window.safetyViewModel)) {

                viewModel = window.safetyViewModel.data;
                isViewModelValid = true;
            }

            if (safetyStore.data.length > 0) {

                resetValidationMessages(['section3A', 'section3B', 'section3C', 'section3D1', 'section3D', 'section3E1', 'section3E', 'section3F1', 'section3F']);

                vResult['PageName'] = pageName;
                vResult['ItemName'] = itemName;

                questionVal = {};

                questionD1CheckBoxGroup = getMultiAnswerStore('SafetyRelatedIncidents').data;
                questionE1CheckBoxGroup = getMultiAnswerStore('FosterSafety').data;
                questionF1CheckBoxGroup = getMultiAnswerStore('FosterPlacementConcern').data;

                if (questionD1CheckBoxGroup.length > 0) {

                    noResponses++;

                    parms['ItemName'] = 'item3';
                    parms['Question'] = 'Question3D1';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (questionE1CheckBoxGroup.length > 0) {

                    noResponses++;

                    parms['ItemName'] = 'item3';
                    parms['Question'] = 'Question3E1';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);

                }

                if (questionF1CheckBoxGroup.length > 0) {

                    noResponses++;

                    parms['ItemName'] = 'item3';
                    parms['Question'] = 'Question3F1';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);

                }

                //if (isViewModelValid) {

                //    answer3A = viewModel['isInitialAssesmentForAllChildrenInHome'];
                //    answer3A1A = viewModel['isFamilyMaltreatmentAllegations'];
                //    answer3A1B = viewModel['isMaltreatmentNotSubstantiated'];
                //    answer3B = viewModel['isOngoingAssesementForAllChildrenInHome'];
                //    answer3C = viewModel['isSafetyPlanDevelopedAndMonitored'];
                //    answer3D = viewModel['isSafetyConcernForOtherChildren'];
                //    answer3E = viewModel['isFosterSafetyConcernDuringVisitation'];
                //    answer3F = viewModel['isFosterSafetyConcernNotAddressed'];
                //    narrative3A = viewModel['initialAssesmentForAllChildrenInHomeExplained'];
                //    narrative3B = viewModel['ongoingAssessmentForAllChildrenInHomeExplained'];
                //    narrative3C = viewModel['safetyPlanDevelopedAndMonitoredExplained'];
                //    narrative3D1 = viewModel['otherSafetyConcernExplained'];
                //    narrative3E1 = viewModel['fosterSafetyOtherExplained'];
                //    narrative3F1 = viewModel['fosterPlacementConcerOtherExplained'];
                //} else {

                    answer3A = safetyStore.getAt(0).data.IsInitialAssesmentForAllChildrenInHome;
                    answer3A1A = safetyStore.getAt(0).data.IsFamilyMaltreatmentAllegations;
                    answer3A1B = safetyStore.getAt(0).data.IsMaltreatmentNotSubstantiated;
                    answer3B = safetyStore.getAt(0).data.IsOngoingAssesementForAllChildrenInHome;
                    answer3C = safetyStore.getAt(0).data.IsSafetyPlanDevelopedAndMonitored;
                    answer3D = safetyStore.getAt(0).data.IsSafetyConcernForOtherChildren;
                    answer3E = safetyStore.getAt(0).data.IsFosterSafetyConcernDuringVisitation;
                    answer3F = safetyStore.getAt(0).data.IsFosterSafetyConcernNotAddressed;
                    narrative3A = safetyStore.getAt(0).data.InitialAssesmentForAllChildrenInHomeExplained;
                    narrative3B = safetyStore.getAt(0).data.OngoingAssessmentForAllChildrenInHomeExplained;
                    narrative3C = safetyStore.getAt(0).data.SafetyPlanDevelopedAndMonitoredExplained
                    narrative3D1 = safetyStore.getAt(0).data.OtherSafetyConcernExplained;
                    narrative3E1 = safetyStore.getAt(0).data.FosterSafetyOtherExplained;
                    narrative3F1 = safetyStore.getAt(0).data.FosterPlacementConcerOtherExplained;
                //}

                vResult['item3QuestionA'] = answer3A == 1 ? 'Yes' : answer3A == 2 ? 'No' : answer3A == 3 ? 'NA' : undefined;

                var result3A1A = answer3A1A == 1 ? 'Yes' : answer3A1A == 2 ? 'No' : undefined;
                var result3A1B = answer3A1B == 1 ? 'Yes' : answer3A1B == 2 ? 'No' : undefined;

                vResult['item3QuestionB'] = answer3B == 1 ? 'Yes' : answer3B == 2 ? 'No' : answer3B == 3 ? 'NA' : undefined;
                vResult['item3QuestionC'] = answer3C == 1 ? 'Yes' : answer3C == 2 ? 'No' : answer3C == 3 ? 'NA' : undefined;
                vResult['item3QuestionD'] = answer3D == 1 ? 'Yes' : answer3D == 2 ? 'No' : answer3D == 3 ? 'NA' : undefined;
                vResult['item3QuestionE'] = answer3E == 1 ? 'Yes' : answer3E == 2 ? 'No' : answer3E == 3 ? 'NA' : undefined;
                vResult['item3QuestionF'] = answer3F == 1 ? 'Yes' : answer3F == 2 ? 'No' : answer3F == 3 ? 'NA' : undefined;

                if (!Ext.isEmpty(result3A1A) && !Ext.isEmpty(result3A1B)) {

                    if (answer3A1A == 1 && answer3A1B == 1) {

                        vResult['item3QuestionA1'] = 'Yes';
                    } else {
                        vResult['item3QuestionA1'] = 'No';
                    }
                } else {
                    vResult['item3QuestionA1'] = undefined;
                }

                if (!Ext.isEmpty(vResult['item3QuestionA1'])) {

                    parms['ItemName'] = 'item3';
                    parms['Question'] = 'Question3A1';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (!Ext.isEmpty(vResult['item3QuestionA'])) {

                    parms['ItemName'] = 'item3';
                    parms['Question'] = 'Question3A';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (!Ext.isEmpty(vResult['item3QuestionB'])) {

                    parms['ItemName'] = 'item3';
                    parms['Question'] = 'Question3B';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (!Ext.isEmpty(vResult['item3QuestionC'])) {

                    parms['ItemName'] = 'item3';
                    parms['Question'] = 'Question3C';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (!Ext.isEmpty(vResult['item3QuestionD'])) {

                    parms['ItemName'] = 'item3';
                    parms['Question'] = 'Question3D';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (!Ext.isEmpty(vResult['item3QuestionE'])) {

                    parms['ItemName'] = 'item3';
                    parms['Question'] = 'Question3E';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (!Ext.isEmpty(vResult['item3QuestionF'])) {

                    parms['ItemName'] = 'item3';
                    parms['Question'] = 'Question3F';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                //
                // Questions 3A and 3B cannot both be NA.  
                //
                if (answer3A == 3 && answer3B == 3) {
                    
                    vResult['Message'] = 'Please change question 3A or 3B so that both are not NA.';
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item3QuestionB', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem3QuestionB', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 3A is No, the following narrative field is required.  
                //
                if (answer3A == 2 && narrative3A.length == 0) {

                    questionVal = {};

                    vResult['Message'] = 'For question 3A, please fill out the narrative field for a response of No.';
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item3QuestionANarrative', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem3QuestionANarrative', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 3B is No, the following narrative field is required.  
                //
                if (answer3B == 2 && narrative3B.length == 0) {

                    questionVal = {};

                    vResult['Message'] = 'For question 3B, please fill out the narrative field for a response of No.';
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item3QuestionBNarrative', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem3QuestionBNarrative', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 3C is No, the following narrative field is required.  
                //
                if (answer3C == 2 && narrative3C.length == 0) {

                    questionVal = {};

                    vResult['Message'] = 'For question 3C, please fill out the narrative field for a response of No.';
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item3QuestionCNarrative', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem3QuestionCNarrative', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //==========================================================
                // Question D1 validation section
                //==========================================================
                var answerOther = questionD1CheckBoxGroup.items.filter(function (item) {
                    return item.data.CodeDescriptionID == 91;
                });
                
                var answerNA = questionD1CheckBoxGroup.items.filter(function (item) {
                    return item.data.CodeDescriptionID == 86;
                });

                var answerNoIncidents = questionD1CheckBoxGroup.items.filter(function (item) {
                    return item.data.CodeDescriptionID == 87;
                });

                var answerIncidents = questionD1CheckBoxGroup.items.filter(function (item) {
                    return item.data.CodeDescriptionID == 88;
                });
                //
                // If question 3D1 is Other, the following narrative field is required.  
                //
                if (answerOther.length > 0 && narrative3D1.length == 0) {

                    questionVal = {};

                    vResult['Message'] = 'For question 3D1, please fill out the narrative field for a response of Other.';
                    vResult['messageType'] = 'Error';
                    questionVal['Message'] = vResult['Message'];
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item3QuestionD1Narrative', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem3QuestionD1Narrative', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 3D1 is NA, no other selections can be made.  
                //
                if (answerNA.length > 0 && questionD1CheckBoxGroup.length > 1) {

                    questionVal = {};

                    vResult['Message'] = 'For question 3D1, if you have selected NA, please ensure that no other selections were made.';
                    vResult['messageType'] = 'Error';
                    questionVal['Message'] = vResult['Message'];
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item3QuestionD1', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem3QuestionD1', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 3D1 is "No safety-related incidents…" then no other selections can be made.  
                //
                if (answerNoIncidents.length > 0 && questionD1CheckBoxGroup.length > 1) {

                    vResult['Message'] = 'For question 3D1, if you have selected "No safety-related incidents occurred that were not adequately addressed by the agency", please ensure that no other selections were made.';
                    vResult['messageType'] = 'Error';
                    questionVal['Message'] = vResult['Message'];
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item3QuestionD1', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem3QuestionD1', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }                
                //==========================================================
                // Question D validation section
                //==========================================================
                //
                // If NA is checked in question 3D1, then question 3D must be NA.  
                //
                if (answer3D > 0) {

                    if (answerNA.length > 0 && !(answer3D == 3)) {

                        vResult['Message'] = 'For question 3D, please select NA since NA is selected in question 3D1.';
                        vResult['messageType'] = 'Error';
                        questionVal['Message'] = vResult['Message'];
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('item3QuestionD', appPages.Safety);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem3QuestionD', container);

                            questionVal['Message'] = vResult['Message'];

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    }
                }
                //
                // Question 3D cannot be No or NA if there is a safety-related incident identified in question 3D1. 
                //
                if (answer3D > 0) {

                    if (answerNA.length == 0 && answerNoIncidents.length == 0 && questionD1CheckBoxGroup.length > 0 && !(answer3D == 1)) {

                        vResult['Message'] = 'For question 3D, please select Yes since safety-related incidents were identified in question 3D1.';
                        vResult['messageType'] = 'Error';
                        questionVal['Message'] = vResult['Message'];
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('item3QuestionD', appPages.Safety);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem3QuestionD', container);

                            questionVal['Message'] = vResult['Message'];

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    }
                }                
                //
                // If no safety-related incidents are identified in question 3D1, question 3D cannot be Yes. 
                //
                if ((answerNA.length > 0 || answerNoIncidents.length > 0) && questionD1CheckBoxGroup.length == 1 && answer3D == 1) {

                    vResult['Message'] = 'For question 3D, please select Yes only if a safety concern was identified in question 3D1.';
                    vResult['messageType'] = 'Error';
                    questionVal['Message'] = vResult['Message'];
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item3QuestionD', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem3QuestionD', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //==========================================================
                // Question E1 validation section
                //==========================================================
                var answerE1Other = questionE1CheckBoxGroup.items.filter(function (item) {
                    return item.data.CodeDescriptionID == 97;
                });

                var answerE1NA = questionE1CheckBoxGroup.items.filter(function (item) {
                    return item.data.CodeDescriptionID == 92;
                });

                var answerE1NoIncidents = questionE1CheckBoxGroup.items.filter(function (item) {
                    return item.data.CodeDescriptionID == 93;
                });
                //
                // If question 3E1 is Other, the following narrative field is required. 
                //
                if (answerE1Other.length > 0 && narrative3E1.length == 0) {

                    vResult['Message'] = 'For question 3E1, please fill out the narrative field for a response of Other.';
                    vResult['messageType'] = 'Error';
                    questionVal['Message'] = vResult['Message'];
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item3QuestionE1Narrative', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem3QuestionE1Narrative', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 3E1 is NA, no other selections are allowed. 
                //
                if (answerE1NA.length > 0 && questionE1CheckBoxGroup.length > 1) {

                    questionVal = {};

                    vResult['Message'] = 'For question 3E1, if you have selected NA, please ensure that no other selections were made.';
                    vResult['messageType'] = 'Error';
                    questionVal['Message'] = vResult['Message'];
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item3QuestionE1', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem3QuestionE1', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 3E1 is No safety concerns, no other selections are allowed.
                //
                if (answerE1NoIncidents.length > 0 && questionE1CheckBoxGroup.length > 1) {

                    vResult['Message'] = 'For question 3E1, if you have selected "No safety concerns related to visitation were present", please ensure that no other selections were made.';
                    vResult['messageType'] = 'Error';
                    questionVal['Message'] = vResult['Message'];
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item3QuestionE1', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem3QuestionE1', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //==========================================================
                // Question E validation section
                //==========================================================
                //
                // For question 3E, please select Yes only if a safety concern was identified in question 3E1.
                //
                if ((answerE1NA.length > 0 || answerE1NoIncidents.length > 0) && answer3E == 1) {

                    vResult['Message'] = 'For question 3E, please select Yes only if a safety concern was identified in question 3E1.';
                    vResult['messageType'] = 'Error';
                    questionVal['Message'] = vResult['Message'];
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item3E', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem3E', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //
                // Question 3E cannot be No or NA if there are safety concerns identified in question 3E1.
                //
                if (answer3E > 0) {

                    if (answerE1NA.length == 0 && answerE1NoIncidents.length == 0 && questionE1CheckBoxGroup.length > 0 && !(answer3E == 1)) {

                        vResult['Message'] = 'For question 3E, please select Yes since safety concerns were identified in question 3E1.';
                        vResult['messageType'] = 'Error';
                        questionVal['Message'] = vResult['Message'];
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('item3E', appPages.Safety);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem3E', container);

                            questionVal['Message'] = vResult['Message'];

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType('Error');
                            msgComponent.updateMessages();
                        }
                    }
                }
                //==========================================================
                // Question F1 validation section
                //==========================================================
                var answerF1Other = questionF1CheckBoxGroup.items.filter(function (item) {
                    return item.data.CodeDescriptionID == 104;
                });

                var answerF1NA = questionF1CheckBoxGroup.items.filter(function (item) {
                    return item.data.CodeDescriptionID == 98;
                });

                var answerF1NoIncidents = questionF1CheckBoxGroup.items.filter(function (item) {
                    return item.data.CodeDescriptionID == 99;
                });

                var caseType = getCaseType();
                //
                // Question 3F1 cannot be NA for foster care cases.
                //
                if (answerF1NA.length > 0 && caseType == 'Foster Case') {

                    vResult['Message'] = 'For question 3F1, please select a response other than NA because this is a foster care case.';
                    vResult['messageType'] = 'Error';
                    questionVal['Message'] = vResult['Message'];
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item3QuestionF1', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem3QuestionF1', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 3F1 is Other, the following narrative field is required.
                //
                if (answerF1Other.length > 0 && narrative3F1.length == 0) {

                    vResult['Message'] = 'For question 3F1, please fill out the narrative field for a response of Other.';
                    vResult['messageType'] = 'Error';
                    questionVal['Message'] = vResult['Message'];
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item3QuestionF1Narrative', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem3QuestionF1Narrative', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 3F1 is No concerns existed, no other selections are allowed. 
                //
                if (answerF1NoIncidents.length > 0 && questionF1CheckBoxGroup.length > 1) {

                    vResult['Message'] = 'For question 3F1, if you have selected "No concerns existed for the target child while in foster care placement that were not adequately addressed", please ensure that no other selections were made.';
                    vResult['messageType'] = 'Error';
                    questionVal['Message'] = vResult['Message'];
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item3QuestionF1', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem3QuestionF1', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 3F1 is NA, no other selections are allowed.  
                //
                if (answerF1NA.length > 0 && questionF1CheckBoxGroup.length > 1) {

                    vResult['Message'] = 'For question 3F1, if you have selected NA, please ensure that no other selections were made.';
                    vResult['messageType'] = 'Error';
                    questionVal['Message'] = vResult['Message'];
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item3QuestionF1', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem3QuestionF1', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //==========================================================
                // Question F validation section
                //==========================================================
                //
                // For foster care cases only, question 3F cannot be NA.
                //
                if (caseType == 'Foster Case' && answer3F == 3) {

                    vResult['Message'] = 'For question 3F, please select Yes or No since this is a foster care case.';
                    vResult['messageType'] = 'Error';
                    questionVal['Message'] = vResult['Message'];
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item3F', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem3F', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
                //
                // If concerns are identified in question 3F1, then question 3F must be Yes.
                //
                if (caseType == 'Foster Case') {

                    if (answer3F > 0) {

                        if (answerF1NA.length == 0 && answerF1NoIncidents.length == 0 && questionF1CheckBoxGroup.length > 0 && !(answer3F == 1)) {

                            vResult['Message'] = 'For question 3F, please select Yes since concerns were identified in question 3F1.';
                            vResult['messageType'] = 'Error';
                            questionVal['Message'] = vResult['Message'];
                            errorCount++;

                            // Get the validation message component
                            var container = getCRSComponent('item3F', appPages.Safety);

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgItem3F', container);

                                questionVal['Message'] = vResult['Message'];

                                msgComponent.setValidationResult(questionVal);
                                msgComponent.setMsgType('Error');
                                msgComponent.updateMessages();
                            }
                        }
                    }
                }                
                //
                // If question 3F1 is No concerns, NA, or blank, question 3F cannot be Yes.
                //
                if ((answerF1NA.length > 0 || answerF1NoIncidents.length > 0 || questionF1CheckBoxGroup.length == 0) && answer3F == 1) {

                    vResult['Message'] = 'For question 3F, please select Yes only if a safety concern was identified in question 3F1.';
                    vResult['messageType'] = 'Error';
                    questionVal['Message'] = vResult['Message'];
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item3F', appPages.Safety);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem3F', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Error');
                        msgComponent.updateMessages();
                    }
                }
            }

            var answers = [answer3A, answer3B, answer3C, answer3D, answer3E, answer3F, narrative3A, narrative3B, narrative3C, narrative3D1, narrative3E1, narrative3F1];
            noResponses += getNumberOfResponses(answers);

            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 4;
            vResult['OutcomeCode'] = 2;

            result.push(vResult);

            validationResults['item3'] = result;

            var itemQuestions = getItemQuestions('item3');
            itemQuestions[0].errorsExist = false;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus) {
                errorCount = 0;
            }

            if (errorCount > 0) {

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            return result;
        },
        validateItem4: function (input)
        {
            var self = this;
            var result = [];
            var vResult = {};
            var questionVal = {};
            var applicabilityItems = {};
            var inputObj;
            var validateAllFields = false;
            var answer4A;
            var answer4B;
            var answer4C;
            var answer4C1;
            var pageName = 'Permanency';
            var itemName = 'item4';
            var question4C1CheckBoxGroup;
            var narrative4C1;
            var noResponses = 0;
            var input = self.getValidationInput();
            var childDemographicGrid = chainedStore('CR_ChildDemographic_CollectionStore');
            var questions = getItemQuestions('item4');
            var itemCode = 5;
            var outcomeCode = 3;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'permanency' };
            var errorCount = 0;

            // Get answers to question 2A and 2B
            var permanencyStore = Ext.data.ChainedStore.create({
                source: 'CR_Permanency_CollectionStore'
            });

            var placementTableStore = Ext.data.ChainedStore.create({
                source: 'CR_Placement_CollectionStore'
            });
            
            if (placementTableStore.data.length > 0) {

                parms['ItemName'] = 'item4';
                parms['Question'] = 'Question4A1';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.permanencyViewModel)) {
                                
                var vModel = createViewModel('permanency');

                window.permanencyViewModel = vModel;
            }

            if (!Ext.isEmpty(window.permanencyViewModel)) {
                
                viewModel = window.permanencyViewModel.data;
                isViewModelValid = true;
            }
            
            var targetChildren = childDemographicGrid.data.items.filter(function (item) {
                return (item.data.IsTargetChild == 1);
            });

            var dob;

            if (targetChildren.length > 0) {

                dob = targetChildren[0].data.DateOfBirth;
            }

            var purDate = this.getReviewEndDate();

            if (permanencyStore.data.length > 0) {

                vResult['PageName'] = pageName;
                vResult['ItemName'] = itemName;

                questionVal = {};
                answer4A = permanencyStore.getAt(0).data.NumberOfPlacementSettings;

                if (!Ext.isEmpty(answer4A)) {

                    parms['ItemName'] = 'item4';
                    parms['Question'] = 'Question4A';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                //if (columns[0] == sr.Constants.AllFields) {

                    resetValidationMessages(['item4Panel']);
                //}

                var caseClosureDate = getCaseClosureDate();
 
                Ext.each(placementTableStore.data.items, function (item) {
                    //
                    // None of the placement dates in table 4A1 should be before 
                    // the target child's date of birth (Face Sheet table G1). 
                    //
                    if (item.data.Date < dob) {

                        vResult['Message'] = 'Please enter a placement date that is on or after the date of birth of the target child. ';
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('item4Panel', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem4Panel', container);

                            questionVal['Message'] = vResult['Message'];

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType(vResult['messageType']);
                            msgComponent.updateMessages();
                        }
                    }
                    //
                    // If there is a date listed for case closure in Face Sheet question L, 
                    // the placement date in table 4A1 cannot be on or after that date. 
                    //     
                    if (!Ext.isEmpty(caseClosureDate)) {

                        if (item.data.Date >= caseClosureDate) {

                            vResult['Message'] = 'Please enter a placement date that is before the date of case closure listed in Face Sheet question L. ';
                            vResult['messageType'] = 'Error';
                            errorCount++;

                            // Get the validation message component
                            var container = getCRSComponent('item4Panel', appPages.Permanency);

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgItem4Panel', container);

                                questionVal['Message'] = vResult['Message'];

                                msgComponent.setValidationResult(questionVal);
                                msgComponent.setMsgType(vResult['messageType']);
                                msgComponent.updateMessages();
                            }
                        }
                    }
                    //
                    // If there is no date listed for case closure in Face Sheet question L, 
                    // the placement date in table 4A1 must be before the end of the PUR. 
                    //                       
                    if (Ext.isEmpty(caseClosureDate)) {

                        if (item.data.Date >= purDate) {

                            vResult['Message'] = 'Please enter a placement date that is before the end of the PUR. ';
                            vResult['messageType'] = 'Error';
                            errorCount++;

                            // Get the validation message component
                            var container = getCRSComponent('item4Panel', appPages.Permanency);

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgItem4Panel', container);

                                questionVal['Message'] = vResult['Message'];

                                msgComponent.setValidationResult(questionVal);
                                msgComponent.setMsgType(vResult['messageType']);
                                msgComponent.updateMessages();
                            }
                        }
                    }
                });                    
                
                Ext.each(input, function (columnName) {
                                        
                    if (columnName == 'item4QuestionA' || columnName == sr.Constants.AllFields) {
                        //
                        // Question 4A will only accept numeric values. 
                        //
                        if (!Ext.isNumeric(answer4A)) {
                            vResult['Message'] = 'For question 4A, please enter a number.';
                            vResult['messageType'] = 'Error';
                            errorCount++;

                            // Get the validation message component
                            var container = getCRSComponent('item4QuestionA', appPages.Permanency);

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgItem4QuestionA', container);

                                questionVal['Message'] = vResult['Message'];

                                msgComponent.setValidationResult(questionVal);
                                msgComponent.setMsgType(vResult['messageType']);
                                msgComponent.updateMessages();
                            }
                        }
                    }

                    if (columnName == 'item4QuestionB' || columnName == sr.Constants.AllFields) {
                        //
                        // If there is only one placement listed in question 4A, then question 4B must be NA. 
                        //
                        answer4B = permanencyStore.getAt(0).data.wereAllPlacementChangesPlanned;

                        if (!Ext.isEmpty(answer4B)) {

                            parms['ItemName'] = 'item4';
                            parms['Question'] = 'Question4B';
                            parms['Answered'] = true;

                            updateQuestionsAnswered(parms);
                        }

                        if (Ext.isNumeric(answer4A) && answer4A == 1) {

                            questionVal = {};

                            if (!(answer4B == 3)) {

                                vResult['Message'] = 'For question 4B, please select NA since there was only one placement indicated in question 4A.';
                                vResult['messageType'] = 'Error';
                                errorCount++;

                                // Get the validation message component
                                var container = getCRSComponent('item4QuestionB', appPages.Permanency);

                                if (!(container == undefined)) {
                                    var msgComponent = getCRSComponent('msgItem4QuestionB', container);

                                    questionVal['Message'] = vResult['Message'];

                                    msgComponent.setValidationResult(questionVal);
                                    msgComponent.setMsgType(vResult['messageType']);
                                    msgComponent.updateMessages();
                                }
                            }
                        }
                        //
                        // If there is more than one placement listed in question 4A, then question 4B cannot be NA. 
                        //
                        if (Ext.isNumeric(answer4A) && answer4A > 1) {

                            questionVal = {};

                            if (answer4B == 3) {

                                vResult['Message'] = 'For question 4B, please select Yes or No since there was more than one placement indicated in question 4A.';
                                vResult['messageType'] = 'Error';
                                errorCount++;

                                // Get the validation message component
                                var container = getCRSComponent('item4QuestionB', appPages.Permanency);

                                if (!(container == undefined)) {
                                    var msgComponent = getCRSComponent('msgItem4QuestionB', container);

                                    questionVal['Message'] = vResult['Message'];

                                    msgComponent.setValidationResult(questionVal);
                                    msgComponent.setMsgType(vResult['messageType']);
                                    msgComponent.updateMessages();
                                }
                            }
                        }
                    }

                    if (columnName == 'item4C1Placement' || columnName == sr.Constants.AllFields) {

                        question4C1CheckBoxGroup = self.getCheckBoxGroup('CR_MultiAnswer_CollectionStore', 'PlacementApplicableCircumstances');

                        if (question4C1CheckBoxGroup.length > 0) {

                            noResponses++;

                            parms['ItemName'] = 'item4';
                            parms['Question'] = 'Question4C1';
                            parms['Answered'] = true;

                            updateQuestionsAnswered(parms);                            
                        }

                        var answerOther = question4C1CheckBoxGroup.items.filter(function (item) {
                            return item.data.CodeDescriptionID == 126;
                        });
                        
                        narrative4C1 = permanencyStore.getAt(0).data.PlacementApplicableCircumstancesOther;

                        //
                        // If question 4C1 is Other, the following narrative field is required. 
                        //
                        if (answerOther.length > 0 && Ext.isEmpty(narrative4C1)) {
                            vResult['Message'] = 'For question 4C1, please fill out the narrative field for a response of Other.';
                            vResult['messageType'] = 'Error';
                            errorCount++;

                            // Get the validation message component
                            var container = getCRSComponent('item4C1Placement', appPages.Permanency);

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgItem4C1Placement', container);

                                questionVal['Message'] = vResult['Message'];

                                msgComponent.setValidationResult(questionVal);
                                msgComponent.setMsgType(vResult['messageType']);
                                msgComponent.updateMessages();
                            }
                        }
                        
                        var stablePlacement = question4C1CheckBoxGroup.items.filter(function (item) {
                            return item.data.CodeDescriptionID == 121;
                        });

                        //
                        // If question 4C1 is "None apply, placement is stable", no other selections are possible. 
                        //
                        if (stablePlacement.length > 0 && question4C1CheckBoxGroup.length > 1) {
                            vResult['Message'] = 'For question 4C1, if you have selected "None apply, placement is stable", please ensure that no other selections were made.';
                            vResult['messageType'] = 'Error';
                            errorCount++;

                            // Get the validation message component
                            var container = getCRSComponent('item4C1Question', appPages.Permanency);

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgItem4C1Question', container);

                                questionVal['Message'] = vResult['Message'];

                                msgComponent.setValidationResult(questionVal);
                                msgComponent.setMsgType(vResult['messageType']);
                                msgComponent.updateMessages();
                            }
                        }
                    }

                    if (columnName == 'item4CPlacementSetting' || columnName == sr.Constants.AllFields) {

                        question4C1CheckBoxGroup = self.getCheckBoxGroup('CR_MultiAnswer_CollectionStore', 'PlacementApplicableCircumstances');
                        
                        var stablePlacement = question4C1CheckBoxGroup.items.filter(function (item) {
                            return item.data.CodeDescriptionID == 121;
                        });

                        answer4C = permanencyStore.getAt(0).data.IsCurrentPlacementSettingStable;

                        if (!Ext.isEmpty(answer4C)) {

                            parms['ItemName'] = 'item4';
                            parms['Question'] = 'Question4C';
                            parms['Answered'] = true;

                            updateQuestionsAnswered(parms);
                        }
                        //
                        // If any of the question 4C1 boxes are checked (except for "None apply, placement is stable"), then 
                        // question 4C must be No.  
                        //
                        if (stablePlacement.length == 0 && question4C1CheckBoxGroup.length > 0 && answer4C == 1) {

                            vResult['Message'] = 'For question 4C, please select No since case circumstances were identified in question 4C1.';
                            vResult['messageType'] = 'Error';
                            errorCount++;

                            // Get the validation message component
                            var container = getCRSComponent('item4CPlacementSetting', appPages.Permanency);

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgItem4CPlacementSetting', container);

                                questionVal['Message'] = vResult['Message'];

                                msgComponent.setValidationResult(questionVal);
                                msgComponent.setMsgType(vResult['messageType']);
                                msgComponent.updateMessages();
                            }
                        }

                        //
                        // If "None apply, placement is stable" is checked in question 4C1, then question 4C must be Yes.
                        //
                        if (stablePlacement.length > 0 && answer4C == 2) {

                            vResult['Message'] = 'For question 4C, please select Yes since "None apply, placement is stable" is selected in question 4C1.';
                            vResult['messageType'] = 'Error';
                            errorCount++;

                            // Get the validation message component
                            var container = getCRSComponent('item4CPlacementSetting', appPages.Permanency);

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgItem4CPlacementSetting', container);

                                questionVal['Message'] = vResult['Message'];

                                msgComponent.setValidationResult(questionVal);
                                msgComponent.setMsgType(vResult['messageType']);
                                msgComponent.updateMessages();
                            }
                        }
                    }

                });                                              
            }

            var answers = [answer4A, answer4B, answer4C];
            noResponses += getNumberOfResponses(answers);

            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 5;
            vResult['OutcomeCode'] = 3;

            result.push(vResult);

            if (input[0] == sr.Constants.AllFields) {

                validationResults['item4'] = result;
            }

            var itemQuestions = getItemQuestions('item4');
            itemQuestions[0].errorsExist = false;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus) {
                errorCount = 0;
            }

            if (errorCount > 0) {

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            return result;
        },
        validateItem5: function (input) {
            var self = this;
            var result = [];
            var input = self.getValidationInput();
            var vResult = {};
            var applicabilityItems = {};
            var inputObj;
            var validateAllFields = false;
            var columnVal;
            var pageName = 'Permanency';
            var itemName = 'item5';
            var questionVal = {};
            var permanencyGoals = [];
            var noResponses = 0;
            var answer5A3;
            var answer5B;
            var answer5C;
            var answer5D;
            var answer5E;
            var answer5F;
            var questions = getItemQuestions('item5');
            var itemCode = 6;
            var outcomeCode = 3;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'permanency' };
            var errorCount = 0;
            var isCurrentGoal = false;

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.permanencyViewModel)) {

                var vModel = createViewModel('permanency');

                window.permanencyViewModel = vModel;
            }

            if (!Ext.isEmpty(window.permanencyViewModel)) {

                viewModel = window.permanencyViewModel.data;
                isViewModelValid = true;
            }

            var daysInFosterCare = getTimeInFosterCare('day');
            var item = getItem(6, getOutcomeCode(6));

            if (!Ext.isEmpty(item)) {

                columnVal = item.IsApplicable;
            }
                        
            // Reset all validation messages
            resetValidationMessages(['item5Panel']);
            
            var columnName = Ext.isEmpty(input) ? [] : input[0];

            // Item 5 applicability is a required field. 
            if (columnName == 'Applicability' || columnName == sr.Constants.AllFields) {

                var store = Ext.data.StoreManager.lookup('CR_Item_CollectionStore');

                if (columnName == sr.Constants.AllFields) {

                    validateAllFields = true;
                }

                var validValues = [1, 2];

                applicabilityItems['Source'] = store;
                applicabilityItems['ValidValues'] = validValues;
                applicabilityItems['PageName'] = pageName;
                applicabilityItems['ItemName'] = itemName;
                applicabilityItems['Message'] = 'Please select Yes or No.';
                applicabilityItems['ItemCode'] = itemCode;
                applicabilityItems['OutcomeCode'] = outcomeCode;

                result = self.validateItemApplicability(applicabilityItems);

                if (!Ext.isEmpty(result[0].CaseApplicable)) {

                    noResponses++;

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Applicability';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }
            }

            var goalStore = chainedStore('CR_Goal_CollectionStore');
            var purDate = this.getReviewEndDate();
            var childDemographicGrid = chainedStore('CR_ChildDemographic_CollectionStore');
                        
            var targetChildren = childDemographicGrid.data.items.filter(function (item) {
                return (item.data.IsTargetChild == 1);
            });

            var targetChildDob;

            if (targetChildren.length > 0) {

                targetChildDob = targetChildren[0].data.DateOfBirth;
            }
            
            if (goalStore.data.length > 0) {

                noResponses++;

                parms['ItemName'] = 'item5';
                parms['Question'] = 'Question5A1';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            //
            // Validate Permanency Goal Table
            //
            Ext.each(goalStore.data.items, function (item) {
                //
                // Date Established is a required field and cannot be after the last day of the PUR. 
                //   
                if (!Ext.isEmpty(item.data.Date) && !Ext.isEmpty(purDate)) {

                    if (item.data.Date > purDate) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = 'Please enter a date the goal was established that is on or before the last day of the PUR. ';
                        vResult['message'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('permanencyGoalPanel', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgPermanencyGoalPanel', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType(vResult['messageType']);
                            msgComponent.updateMessages();
                        }
                    }
                }
                //
                // Date Established must be on or after the target child's date of birth. 
                //
                if (!Ext.isEmpty(item.data.DateEstablished) && !Ext.isEmpty(targetChildDob)) {

                    if (item.data.DateEstablished < targetChildDob) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = 'Please enter a date the goal was established that is on or after the date of birth of the target child. ';
                        vResult['message'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('permanencyGoalPanel', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgPermanencyGoalPanel', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType(vResult['messageType']);
                            msgComponent.updateMessages();
                        }
                    }
                }
                //
                // Date Goal Change is a required field when Reason for Goal Change is entered. 
                //
                var dateGoalChanged = item.data.DateGoalChanged;
                var reasonGoalChanged = item.data.ReasonForGoalChange;

                if (!Ext.isEmpty(reasonGoalChanged)) {

                    if (Ext.isEmpty(dateGoalChanged)) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = 'You have entered a Reason For Goal Change without a date the goal changed. Please enter a date the goal changed. ';
                        vResult['message'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('permanencyGoalPanel', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgPermanencyGoalPanel', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType(vResult['messageType']);
                            msgComponent.updateMessages();
                        }
                    }
                }
                //
                // Date Goal Changed must indicate either a date or that the goal indicated is/was the current goal. 
                //
                isCurrentGoal = item.data.IsCurrentGoal == 1 ? true : false;

                if (Ext.isEmpty(dateGoalChanged) && !(isCurrentGoal)) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'Please select either a date or NA. This is/was the current goal. ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('permanencyGoalPanel', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgPermanencyGoalPanel', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType(vResult['messageType']);
                        msgComponent.updateMessages();
                    }
                }
                //
                // A Reason for Goal Change should not be entered if Date Goal Change is "NA. This is/was the current goal." 
                //
                if (Ext.isEmpty(dateGoalChanged) && (isCurrentGoal) && reasonGoalChanged.length > 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'Please do not enter a Reason for Goal Change if you have selected NA. This is/was the current goal. ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('permanencyGoalPanel', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgPermanencyGoalPanel', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType(vResult['messageType']);
                        msgComponent.updateMessages();
                    }
                }
                //
                // The date a goal was changed must be on or after the target child's date of birth. 
                //
                if (!Ext.isEmpty(dateGoalChanged) && !Ext.isEmpty(targetChildDob)) {

                    if (dateGoalChanged < targetChildDob) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = 'Please enter a date the goal changed that is after the date of birth of the target child. ';
                        vResult['message'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('permanencyGoalPanel', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgPermanencyGoalPanel', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType(vResult['messageType']);
                            msgComponent.updateMessages();
                        }
                    }
                }
                //
                // The date a goal was changed cannot be later than the last day of the PUR. 
                //
                if (!Ext.isEmpty(dateGoalChanged) && !Ext.isEmpty(purDate)) {

                    if (dateGoalChanged > purDate) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = 'Please enter a date the goal changed that is before the last day of the PUR. ';
                        vResult['message'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('permanencyGoalPanel', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgPermanencyGoalPanel', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType(vResult['messageType']);
                            msgComponent.updateMessages();
                        }
                    }
                }
                //
                // The date a goal was changed cannot be earlier than the date the goal was established. 
                //
                if (!Ext.isEmpty(dateGoalChanged) && !Ext.isEmpty(item.data.DateEstablished)) {

                    if (dateGoalChanged < item.data.DateEstablished) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = 'Please enter a date the goal changed that is after the date it was established. ';
                        vResult['message'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('permanencyGoalPanel', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgPermanencyGoalPanel', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType(vResult['messageType']);
                            msgComponent.updateMessages();
                        }
                    }
                }                
            });
            //
            // One of the rows of the table must indicate that it is the current goal. 
            //
            var currentGoals = goalStore.data.items.filter(function (item) {
                return (item.data.IsCurrentGoal == 1);
            });

            if (currentGoals.length > 0) {

                parms['ItemName'] = 'item5';
                parms['Question'] = 'Question5A2';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            if (currentGoals.length == 0) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For table 5A1, please ensure that one of the rows indicates that this is the current goal. ';
                vResult['message'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('permanencyGoalPanel', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgPermanencyGoalPanel', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.setMsgType(vResult['messageType']);
                    msgComponent.updateMessages();
                }
            }
            //
            // If there are two current goals in table 5A1, they cannot be the same goal. 
            //
            if (currentGoals.length == 2) {

                var goal1 = currentGoals[0].data.GoalCode;
                var goal2 = currentGoals[1].data.GoalCode;

                if (goal1 == goal2) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For table 5A1, please complete Date Goal Changed and Reason for Goal Change for all non-current goals. Please do not list two concurrent goals that are the same. ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('permanencyGoalPanel', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgPermanencyGoalPanel', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType(vResult['messageType']);
                        msgComponent.updateMessages();
                    }
                }                
            }
            //
            // Non-current goals must indicate the date the goal changed and the reason for change. 
            // There can be a maximum of two current goals. 
            //
            if (currentGoals.length > 2) {
                
                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For table 5A1, please complete Date Goal Changed and Reason for Goal Change for all non-current goals. Please record only two concurrent goals. ';
                vResult['message'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('permanencyGoalPanel', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgPermanencyGoalPanel', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.setMsgType(vResult['messageType']);
                    msgComponent.updateMessages();
                }                
            }
            //
            // Applicability validations
            //
            Ext.each(input, function (columnName) {

                var store = Ext.data.StoreManager.lookup('CR_Permanency_CollectionStore');
                //
                // Item 5 applicability is a required field. 
                //
                if (columnName == 'IsApplicable' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        validateAllFields = true;
                    }

                    var validValues = [1, 2];

                    applicabilityItems['Source'] = store;
                    applicabilityItems['ValidValues'] = validValues;
                    applicabilityItems['PageName'] = 'Permanency';
                    applicabilityItems['ItemName'] = 'item5';
                    applicabilityItems['Message'] = 'Please select Yes or No.';
                    applicabilityItems['ItemCode'] = 6;

                    result = self.validateItemApplicability(applicabilityItems);

                    if (result.length > 0) {

                        parms['ItemName'] = 'item5';
                        parms['Question'] = 'Applicability';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }
                }
                //
                // If a date is selected in Face Sheet question K, use the dates in Face Sheet questions J and K 
                // to determine if the child has been in foster care for 61 days or longer. If so, question 5A3 cannot be NA. 
                //  
                var permanencyStore = Ext.data.ChainedStore.create({
                    source: 'CR_Permanency_CollectionStore'
                });

                answer5A3 = permanencyStore.getAt(0).data.IsGoalSpecified;

                if (!Ext.isEmpty(answer5A3)) {

                    parms['ItemName'] = 'item5';
                    parms['Question'] = 'Question5A3';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (answer5A3 == 3 && daysInFosterCare > 60) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'You indicated on the Face Sheet that the child has been in foster care more than 60 days. Please answer Yes or No to question 5A3.';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item5A3', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem5A3', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType(vResult['messageType']);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If a date is selected in Face Sheet question K, use the dates in Face Sheet questions J and K 
                // to determine if the child has been in foster care for 61 days or longer. If so, question 5B cannot be NA. 
                //  
                answer5B = permanencyStore.getAt(0).data.wereAllGoalsInTimelyManner;

                if (!Ext.isEmpty(answer5B)) {

                    parms['ItemName'] = 'item5';
                    parms['Question'] = 'Question5B';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (answer5B == 3 && daysInFosterCare > 60) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'You indicated on the Face Sheet that the child has been in foster care more than 60 days. Please answer Yes or No to question 5B.';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item5B', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem5B', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType(vResult['messageType']);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 5B is No, the following narrative field is required.
                //
                var goalsExplanation = permanencyStore.getAt(0).data.AllGoalsInTimelyMannerExplained;

                if (answer5B == 2 && goalsExplanation.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 5B, please fill out the narrative field for a response of No.';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item5BGoalsExplanation', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem5BGoalsExplanation', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType(vResult['messageType']);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 5C is No, the following narrative field is required.
                //
                answer5C = permanencyStore.getAt(0).data.wereAllGoalsAppropriate;

                if (!Ext.isEmpty(answer5C)) {

                    parms['ItemName'] = 'item5';
                    parms['Question'] = 'Question5C';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                var goalsAppropriate = permanencyStore.getAt(0).data.AllGoalsAppropriateExplained;

                if (answer5C == 2 && goalsAppropriate.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 5C, please fill out the narrative field for a response of No.';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item5CGoalsAppropriate', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem5CGoalsAppropriate', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType(vResult['messageType']);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 5D is No, question 5E cannot be NA.
                //
                answer5D = permanencyStore.getAt(0).data.IsInFoster15OutOf22;

                if (!Ext.isEmpty(answer5D)) {

                    parms['ItemName'] = 'item5';
                    parms['Question'] = 'Question5D';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                answer5E = permanencyStore.getAt(0).data.meetsTerminationOfParentalRights;

                if (!Ext.isEmpty(answer5E)) {

                    parms['ItemName'] = 'item5';
                    parms['Question'] = 'Question5E';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (answer5D == 2 && answer5E == 3) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 5E, please answer Yes or No since No is selected in question 5D.';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item5EParentalRights', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem5EParentalRights', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType(vResult['messageType']);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 5D is Yes, then question 5E is automatically rated NA.
                //
                if (answer5D == 1 && !(answer5E == 3)) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'If question 5D is Yes, then question 5E is automatically rated NA.';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item5EParentalRights', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem5EParentalRights', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType(vResult['messageType']);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If questions 5D and 5E are No, then question 5F must be NA.
                //
                answer5F = permanencyStore.getAt(0).data.IsAgencyJointTerminationOfParentalRights;

                if (!Ext.isEmpty(answer5F)) {

                    parms['ItemName'] = 'item5';
                    parms['Question'] = 'Question5F';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if ((answer5D == 2 && answer5E == 2) && !(answer5F == 3)) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 5F, please select NA since No is selected for both questions 5D and 5E.';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item5F', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem5F', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType(vResult['messageType']);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 5F is Yes, then question 5G1 must be NA. 
                //
                var checkBoxGroup5G1;
                
                if (Ext.isEmpty(getAppController().getItem5G1Group)) {
                    return;
                }

                checkBoxGroup5G1 = getAppController().getItem5G1Group().items.items;
                //var question5G1CheckBoxGroup = getMultiAnswerStore('TerminationExceptions');

                var question5G1CheckBoxGroup = checkBoxGroup5G1.filter(function (checkBox) {

                    return checkBox.checked == true;
                });

                //if (question5G1CheckBoxGroup.data.length > 0) {
                if (question5G1CheckBoxGroup.length > 0) {

                    noResponses++;

                    parms['ItemName'] = 'item5';
                    parms['Question'] = 'Question5G1';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                var answer5G1NA = [];

                if (question5G1CheckBoxGroup.length > 0) {

                    answer5G1NA = question5G1CheckBoxGroup.filter(function (item) {
                        return item.inputValue == 138;
                    });
                }
                
                if (answer5G1NA.length == 0) {

                    if (answer5F == 1 || answer5F == 3) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;

                        if (answer5F == 1) {

                            questionVal['Message'] = 'For question 5G1, please select NA since Yes is selected for question 5F.';
                        }

                        if (answer5F == 3) {

                            questionVal['Message'] = 'For question 5G1, please select NA since NA is selected for question 5F.';
                        }

                        vResult['message'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('item5G1Question', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem5G1Question', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.setMsgType(vResult['messageType']);
                            msgComponent.updateMessages();
                        }
                    }
                }
                
                if (answer5F == 2 && answer5G1NA.length > 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 5G1, please do not select NA since the answer to question 5F is No.';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item5G1Question', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem5G1Question', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType(vResult['messageType']);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If questions 5D and 5E are No, then question 5G1 must be NA.
                //
                if ((answer5D == 2 && answer5E == 2) && answer5G1NA.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 5G1, please select NA since No is selected for both questions 5D and 5E.';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item5G1Question', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem5G1Question', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType(vResult['messageType']);
                        msgComponent.updateMessages();
                    }
                }
                //
                // No selections can be made in question 5G1 in addition to NA.
                //
                if (answer5G1NA.length > 0 && question5G1CheckBoxGroup.length > 1) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 5G1, please ensure that no other selections are made in addition to NA.';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item5G1Question', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem5G1Question', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType(vResult['messageType']);
                        msgComponent.updateMessages();
                    }
                }

                var answer5G1NoExceptions = question5G1CheckBoxGroup.filter(function (item) {
                    return item.inputValue == 139;
                });
                //
                // If "No exceptions apply" is selected in question 5G1, no other selections can be made.
                //
                if (answer5G1NoExceptions.length > 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 5G1, if you have selected "No exceptions apply", please ensure that no other selections were made.';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Info';

                    // Get the validation message component
                    var container = getCRSComponent('item5G1Question', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem5G1Question', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType(vResult['messageType']);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 5F is No, question 5G cannot be NA.
                //
                var answer5G = permanencyStore.getAt(0).data.IsExceptionForTermination;

                if (!Ext.isEmpty(answer5G)) {

                    parms['ItemName'] = 'item5';
                    parms['Question'] = 'Question5G';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (answer5F == 2 && answer5G == 3) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 5G, please select Yes or No since the answer to question 5F is No. ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item5GQuestion', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem5GQuestion', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType(vResult['messageType']);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If "exceptions" are selected in question 5G1, question 5G must be Yes. 
                //
                var answer5G1Exceptions = question5G1CheckBoxGroup.filter(function (item) {
                    return (item.inputValue == 140 || item.inputValue == 141 || item.inputValue == 142);
                });

                if (answer5G1Exceptions.length > 0 && !(answer5G == 1)) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 5G, please select Yes since exceptions were selected in question 5G1.';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item5GQuestion', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem5GQuestion', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType(vResult['messageType']);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 5G1 is NA, question 5G cannot be Yes. 
                //
                if (answer5G1NA.length > 0 && answer5G == 1) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 5G, please do not select Yes since question 5G1 was answered NA.';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item5GQuestion', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem5GQuestion', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType(vResult['messageType']);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 5F is Yes, then question 5G must be NA. 
                //
                if (answer5F == 1 && !(answer5G == 3)) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 5G, please select NA since Yes is selected for question 5F.';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item5GQuestion', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem5GQuestion', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType(vResult['messageType']);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 5F is NA, then question 5G must be NA. 
                //
                if (answer5F == 3 && !(answer5G == 3)) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 5G, please select NA since NA is selected for question 5F.';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item5GQuestion', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem5GQuestion', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType(vResult['messageType']);
                        msgComponent.updateMessages();
                    }
                }
            });

            var answers = [answer5A3, answer5B, answer5C, answer5D, answer5E, answer5F];
            noResponses += getNumberOfResponses(answers);

            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 6;
            vResult['OutcomeCode'] = 3;

            result.push(vResult);

            if (input[0] == sr.Constants.AllFields) {

                validationResults['item5'] = result;
            }

            var itemQuestions = getItemQuestions('item5');
            itemQuestions[0].errorsExist = false;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus) {
                errorCount = 0;
            }

            if (errorCount > 0) {

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            return result;
        },
        validateItem6: function (input) {
            var self = this;
            var result = [];
            var vResult = {};
            var applicabilityItems = {};
            var inputObj;
            var validateAllFields = false;
            var noResponses = 0;
            var pageName = 'Permanency';
            var itemName = 'item6';
            var questions = getItemQuestions('item6');
            var itemCode = 7;
            var outcomeCode = 3;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'permanency' };
            var errorCount = 0;
            var answerOPPLA;

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.permanencyViewModel)) {

                var vModel = createViewModel('permanency');

                window.permanencyViewModel = vModel;
            }

            if (!Ext.isEmpty(window.permanencyViewModel)) {

                viewModel = window.permanencyViewModel.data;
                isViewModelValid = true;
            }

            var facesheetStore = Ext.data.ChainedStore.create({
                source: 'CR_FaceSheet_CollectionStore'
            });

            var permanencyStore = Ext.data.ChainedStore.create({
                source: 'CR_Permanency_CollectionStore'
            });

            var childDemographicStore = Ext.data.ChainedStore.create({
                source: 'CR_ChildDemographic_CollectionStore'
            });

            var answer6A1 = facesheetStore.getAt(0).data.FosterEntryDate;

            if (!Ext.isEmpty(answer6A1)) {

                parms['ItemName'] = 'item6';
                parms['Question'] = 'Question6A1';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer6A2 = permanencyStore.getAt(0).data.TimeInCare;

            if (!Ext.isEmpty(answer6A2)) {

                parms['ItemName'] = 'item6';
                parms['Question'] = 'Question6A2';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer6A3 = facesheetStore.getAt(0).data.EpisodeDischargeDate;
            var isDischargedDateNA = permanencyStore.getAt(0).data.IsDischargeDateNA;

            answer6A3 = Ext.isEmpty(answer6A3) ? (isDischargedDateNA == 0 ? undefined : isDischargedDateNA) : answer6A3;

            if (!Ext.isEmpty(answer6A3)) {

                parms['ItemName'] = 'item6';
                parms['Question'] = 'Question6A3';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer6B = permanencyStore.getAt(0).data.IsAgencyConcertedEfforts;
            answer6B = Ext.isEmpty(answer6B) ? (answer6B == 0 ? undefined : answer6B) : answer6B;

            if (!Ext.isEmpty(answer6B)) {

                parms['ItemName'] = 'item6';
                parms['Question'] = 'Question6B';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer6BNarrative = permanencyStore.getAt(0).data.AgencyConcertedEffortsExplained;
            var question6A4CheckBoxGroup = self.getCheckBoxGroup('CR_MultiAnswer_CollectionStore', 'PermanencyGoal1');

            if (question6A4CheckBoxGroup.length > 0) {

                noResponses++;

                parms['ItemName'] = 'item6';
                parms['Question'] = 'Question6A4';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            if (question6A4CheckBoxGroup.items.length > 0) {

                answerOPPLA = question6A4CheckBoxGroup.items.filter(function (item) {
                    return item.data.CodeDescriptionID == 130;
                });
            }
            
            // Reset all validation messages
            resetValidationMessages(['item6Panel']);

            //
            // Question 6B must be NA if the only goal shown in question 6A4 is OPPLA. 
            // 
            if(!Ext.isEmpty(answerOPPLA)){

                if ((answerOPPLA.length > 0 && question6A4CheckBoxGroup.length == 1) && !(answer6B == 3)) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'Please select NA for question 6B, since OPPLA is the only goal selected in question 6A4.';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item6BQuestion', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem6BQuestion', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
            }            
            //
            // Question 6B cannot be NA if OPPLA is not selected in A4. 
            // 
            if (!Ext.isEmpty(answerOPPLA)) {

                if (answerOPPLA.length == 0 && answer6B == 3) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'Please select Yes or No for question 6B, since OPPLA was not selected as a goal in question 6A4.';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item6BQuestion', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem6BQuestion', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
            }
            //
            // If question 6B is No, the following narrative field is required. 
            // 
            if (answer6B == 2 && Ext.isEmpty(answer6BNarrative)) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 6B, please fill out the narrative field for a response of No.';
                vResult['message'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item6BQuestion', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem6BQuestion', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            //
            // Question 6C1 cannot be NA if OPPLA is selected as the goal (or one of the goals) in question 6A4. 
            // Exception: Question 6C1 can be NA if OPPLA is one of two goals and question 6B is Yes.  
            // 
            var answer6C1 = permanencyStore.getAt(0).data.LivingArrangementCode;
            var modifiedAnswer6C1 = answer6C1 == 0 ? undefined : answer6C1;

            if (!Ext.isEmpty(modifiedAnswer6C1)) {

                parms['ItemName'] = 'item6';
                parms['Question'] = 'Question6C1';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            if (!Ext.isEmpty(answerOPPLA)) {

                if (answerOPPLA.length > 0 && answer6C1 == 1) {

                    if (!(question6A4CheckBoxGroup.length == 2 && answer6B == 1)) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = 'For question 6C1, please select an answer other than NA since OPPLA was selected as a goal in question 6A4.';
                        vResult['message'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('item6C1Question', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem6C1Question', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                }
            }
            //
            // Question 6C2 cannot be NA if OPPLA is selected as the goal (or one of the goals) in question 6A4. 
            // Exception: Question 6C2 can be NA if OPPPLA is one of two goals and question 6B is Yes. 
            // 
            var answer6C2NA = permanencyStore.getAt(0).data.IsOtherPlannedArrangementNA;
            answer6C2NA = answer6C2NA == 0 ? undefined : answer6C2NA;

            if (!Ext.isEmpty(answerOPPLA)) {

                if (answerOPPLA.length > 0 && answer6C2NA == 1) {

                    if (!(question6A4CheckBoxGroup.length == 2 && answer6B == 1)) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = 'For question 6C2, please select an answer other than NA since OPPLA was selected as a goal in question 6A4. ';
                        vResult['message'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('item6C2Question', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem6C2Question', container);

                            msgComponent.setValidationResult(questionVal);

                            msgComponent.updateMessages();
                        }
                    }
                }
            }
            //
            // The date entered in question 6C2 cannot be before the date of birth of the child (Face Sheet table G1).
            // 
            var answer6C2DocumentDate = Date.parse(permanencyStore.getAt(0).data.OtherPlannedArrangementDocumentationDate);
            var reviewEndDate;
            var childDemographic;
            var dob;

            childDemographic = childDemographicStore.data.items.filter(function (item) {
                return item.data.IsTargetChild == 1;
            });

            if (childDemographic.length == 0) {

                childDemographic = childDemographicStore.data.items.filter(function (item) {
                    return item.data.IsTargetChild == 2;
                });
            }

            if (childDemographic.length > 0) {
                
                dob = Date.parse(childDemographic[0].data.DateOfBirth);
            }

            if (!(isNaN(answer6C2DocumentDate) && isNaN(dob))) {

                if (answer6C2DocumentDate < dob) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = "For question 6C2, please enter a date that is after the child's date of birth.";
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item6C2Question', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem6C2Question', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
            }
            //
            // The date entered in question 6C2 cannot be after the PUR. 
            // 
            var reviewEndDate = Date.parse(self.getReviewEndDate());

            if (!(isNaN(answer6C2DocumentDate) && isNaN(reviewEndDate))) {

                if (answer6C2DocumentDate > reviewEndDate) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = "For question 6C2, please enter a date that is on or before the last day of the PUR. ";
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item6C2Question', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem6C2Question', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
            }
            //
            // Question 6C2 cannot be No Date and have a date entered.  
            // 
            var noDate = permanencyStore.getAt(0).data.IsOtherPlannedArrangementNoDate;
            noDate = noDate == 0 ? undefined : noDate;

            if (!Ext.isEmpty(noDate) || !(isNaN(answer6C2DocumentDate)) || !Ext.isEmpty(answer6C2NA)) {

                parms['ItemName'] = 'item6';
                parms['Question'] = 'Question6C2';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            if (!(isNaN(answer6C2DocumentDate)) && noDate == 1) {
                
                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = "For question 6C2, please either specify a date or choose No Date. ";
                vResult['message'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item6C2Question', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem6C2Question', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }                
            }
            //
            // Question 6C2 cannot be both NA and No Date. 
            // 
            if (answer6C2NA == 1 && noDate == 1) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = "For question 6C2, please choose NA or No Date, but not both.";
                vResult['message'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item6C2Question', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem6C2Question', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            //
            // If there are two goals stated in question 6A4 and one goal is OPPLA, questions 6B and 6C 
            // cannot both be Yes, or a combination of Yes and No.  
            // 
            var answer6C = permanencyStore.getAt(0).data.IsOtherPlannedConcertedEffort;
            answer6C = answer6C == 0 ? undefined : answer6C;

            if (!Ext.isEmpty(answer6C)) {

                parms['ItemName'] = 'item6';
                parms['Question'] = 'Question6C';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            if (!Ext.isEmpty(answerOPPLA)) {

                if (question6A4CheckBoxGroup.length > 1 && answerOPPLA.length > 0) {

                    if ((answer6B == 1 && answer6C == 1) || (answer6B == 1 && answer6C == 2) || (answer6B == 2 && answer6C == 1)) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = "If concurrent goals are in place and one of the goals has been, or will likely be, achieved in a timely manner, answer question 6B or 6C based on the goal that has been or will be achieved and answer the other question as NA.";
                        vResult['message'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('item6CQuestion', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem6CQuestion', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                }
            }
            //
            // Question 6C cannot be NA if OPPLA is selected as the goal (or one of the goals) in question 6A4. 
            // Exception: Question 6C can be NA if OPPLA is one of two goals and question 6B is Yes.
            // 
            if (!Ext.isEmpty(answerOPPLA)) {

                if (answerOPPLA.length > 0 && answer6C == 3) {

                    if (!(question6A4CheckBoxGroup.length > 1 && answer6B == 1)) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = "For question 6C, please select an answer other than NA since OPPLA was selected as a goal in question 6A4. ";
                        vResult['message'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('item6CQuestion', appPages.Permanency);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem6CQuestion', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                }
            }
            //
            // If question 6C is No, the following narrative field is required. 
            // 
            var answer6CNarrative = permanencyStore.getAt(0).data.OtherPlannedConcertedEffortExplained;

            if (answer6C == 2 && Ext.isEmpty(answer6CNarrative)) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 6C, please fill out the narrative field for a response of No. ';
                vResult['message'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item6CNarrative', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem6CNarrative', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }

            var answer6C2 = !(Ext.isEmpty(noDate)) ? noDate : !(Ext.isEmpty(answer6C2NA)) ? answer6C2NA : answer6C2DocumentDate;
            var answers = [answer6A1, answer6A2, answer6A3, answer6B, answer6C, answer6C1, answer6C2];
            noResponses += getNumberOfResponses(answers);

            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 7;
            vResult['OutcomeCode'] = 3;

            result.push(vResult);

            validationResults['item6'] = result;

            var itemQuestions = getItemQuestions('item6');
            itemQuestions[0].errorsExist = false;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus) {
                errorCount = 0;
            }

            if (errorCount > 0) {

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            return result;
        },
        validateItem7: function (input) {
            var self = this;
            var result = [];
            var vResult = {};
            var applicabilityItems = {};
            var inputObj;
            var validateAllFields = false;
            var input = self.getValidationInput();
            var noResponses = 0;
            var pageName = 'Permanency';
            var itemName = 'item7';
            var questions = getItemQuestions(itemName);
            var itemCode = 8;
            var outcomeCode = 4;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'permanency' };
            var errorCount = 0;

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.permanencyViewModel)) {

                var vModel = createViewModel('permanency');

                window.permanencyViewModel = vModel;
            }

            if (!Ext.isEmpty(window.permanencyViewModel)) {

                viewModel = window.permanencyViewModel.data;
                isViewModelValid = true;
            }

            var permanencyStore = Ext.data.ChainedStore.create({
                source: 'CR_Permanency_CollectionStore'
            });
            //
            // Applicability validations
            //
            Ext.each(input, function (columnName) {

                var store = Ext.data.StoreManager.lookup('CR_Permanency_CollectionStore');
                //
                // Item 5 applicability is a required field. 
                //
                if (columnName == 'IsApplicable' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {
                        
                        // Reset all validation messages
                        resetValidationMessages(['item7BPanel']);

                        validateAllFields = true;
                    }

                    var validValues = [1, 2];

                    applicabilityItems['Source'] = store;
                    applicabilityItems['ValidValues'] = validValues;
                    applicabilityItems['PageName'] = pageName;
                    applicabilityItems['ItemName'] = itemName;
                    applicabilityItems['Message'] = 'Please select Yes or No.';
                    applicabilityItems['ItemCode'] = itemCode;
                    applicabilityItems['OutcomeCode'] = outcomeCode;

                    result = self.validateItemApplicability(applicabilityItems);

                    if (!Ext.isEmpty(result[result.length - 1].CaseApplicable)) {

                        parms['ItemName'] = itemName;
                        parms['Question'] = 'Applicability';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }
                }
            });

            var answer7A = permanencyStore.getAt(0).data.IsPlacedWithAllSiblings;
            answer7A = answer7A == 0 ? undefined : answer7A;

            if (!Ext.isEmpty(answer7A)) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question7A';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer7B = permanencyStore.getAt(0).data.IsValidReasonForSeparation;
            answer7B = answer7B == 0 ? undefined : answer7B;

            if (!Ext.isEmpty(answer7B)) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question7B';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer7BNarrative = permanencyStore.getAt(0).data.ValidReasonForSeparationExplained;
            //
            // If question 7A is Yes, then question 7B must be NA. 
            // 
            if (answer7A == 1 && !(answer7B == 3)) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 7B, please select NA since Yes is selected in question 7A.';
                vResult['message'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item7BQuestion', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem7BQuestion', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            //
            // If question 7A is No, then question 7B cannot be NA. 
            // 
            if (answer7A == 2 && answer7B == 3) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 7B, please select Yes or No since No is selected in question 7A.';
                vResult['message'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item7BQuestion', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem7BQuestion', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            //
            // If question 7B is No, the following narrative field is required. 
            // 
            if (answer7B == 2 && Ext.isEmpty(answer7BNarrative)) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 7B, please fill out the narrative field for a response of No.';
                vResult['message'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item7BQuestion', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem7BQuestion', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }

            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 8;
            vResult['OutcomeCode'] = 4;

            result.push(vResult);

            validationResults['item7'] = result;

            var itemQuestions = getItemQuestions('item7');
            itemQuestions[0].errorsExist = false;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus) {
                errorCount = 0;
            }

            if (errorCount > 0) {

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            return result;
        },
        validateItem8: function (input) {
            var self = this;
            var result = [];
            var input = self.getValidationInput();
            var vResult = {};
            var applicabilityItems = {};
            var inputObj;
            var validateAllFields = false;
            var pageName = 'Permanency';
            var itemName = 'item8';
            var noResponses = 0;
            var questions = getItemQuestions('item8');
            var itemCode = 9;
            var outcomeCode = 4;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'permanency' };
            var errorCount = 0;

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.permanencyViewModel)) {

                var vModel = createViewModel('permanency');

                window.permanencyViewModel = vModel;
            }

            if (!Ext.isEmpty(window.permanencyViewModel)) {

                viewModel = window.permanencyViewModel.data;
                isViewModelValid = true;
            }

            Ext.each(input, function (columnName) {

                // All pre-applicability questions must be answered.
                if (columnName == 'PreApplicability' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        // Reset all validation messages
                        resetValidationMessages(['item8Panel','item8APanel','item8BPanel','item8CPanel','item8DPanel','item8EPanel','item8FPanel']);

                        validateAllFields = true;
                    }

                    var store = Ext.data.StoreManager.lookup('CR_Permanency_CollectionStore');

                    questionVal = {};

                    var validValues = [{ itemId: 'item8Question1', codeDescriptionId: 57 },
                                       { itemId: 'item8Question2', codeDescriptionId: 58 },
                                       { itemId: 'item8Question3', codeDescriptionId: 59 },
                                       { itemId: 'item8Question4', codeDescriptionId: 60 },
                                       { itemId: 'item8Question5', codeDescriptionId: 61 },
                                       { itemId: 'item8Question6', codeDescriptionId: 62 }
                    ];

                    result = self.validateItemPreApplicability(store, validValues, 'Permanency', 'Item8', 'Please answer all questions on this page.');

                    if (result.length > 0) {

                        if (result[0].NoResponses == validValues.length) {

                            parms['ItemName'] = 'item8';
                            parms['Question'] = 'PreApplicability';
                            parms['Answered'] = true;

                            updateQuestionsAnswered(parms);
                        }

                        if (!Ext.isEmpty(result[0].PreApplicability)) {

                            questionVal['PreApplicability'] = result[0].PreApplicability;
                            
                            var errors = result.filter(function (obj) {

                                return obj.messageType == 'Error';
                            });

                            if (errors.length > 0) {

                                // Get the validation message component
                                var container = getCRSComponent('item8PreApplicableCases', appPages.Permanency);

                                if (!(container == undefined)) {
                                    var msgComponent = getCRSComponent('msgItem8PreApplicableCases', container);

                                    msgComponent.setValidationResult(questionVal);
                                    msgComponent.updateMessages();
                                }
                            }
                        }
                    }
                }

                // Item 8 applicability is a required field. 
                if (columnName == 'IsApplicable' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        validateAllFields = true;
                    }

                    var validValues = [1, 2];

                    applicabilityItems['Source'] = store;
                    applicabilityItems['ValidValues'] = validValues;
                    applicabilityItems['PageName'] = pageName;
                    applicabilityItems['ItemName'] = itemName;
                    applicabilityItems['Message'] = 'Please select Yes or No.';
                    applicabilityItems['ItemCode'] = itemCode;
                    applicabilityItems['OutcomeCode'] = outcomeCode;
                    applicabilityItems['PreApplicability'] = result;

                    result = result.concat(self.validateItemApplicability(applicabilityItems));

                    if (!Ext.isEmpty(result[result.length-1].CaseApplicable)) {

                        parms['ItemName'] = 'item8';
                        parms['Question'] = 'Applicability';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }

                    if ((result[result.length - 1].MotherSelected) || (result[result.length - 1].FatherSelected)) {

                        parms['ItemName'] = itemName;
                        parms['Question'] = 'MotherOrFatherApplicable';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }
                }
            });

            var permanencyStore = Ext.data.ChainedStore.create({
                source: 'CR_Permanency_CollectionStore'
            });

            var parms1 = { ItemCode: itemCode, OutcomeCode: outcomeCode };

            var participants = getParticipantsSelected(parms1);

            var motherSelected = participants.Mothers;
            var fatherSelected = participants.Fathers;

            //var motherStore = GetItemParticipant(1);

            if (motherSelected.length > 0) {

                parms['ItemName'] = 'item8';
                parms['Question'] = 'ApplicabilityMother';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            //var fatherStore = GetItemParticipant(2);

            if (fatherSelected.length > 0) {

                parms['ItemName'] = 'item8';
                parms['Question'] = 'ApplicabilityFather';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer8A = permanencyStore.getAt(0).data.IsSufficientFrequencyForMotherVisitation;
            answer8A = answer8A == 0 ? undefined : answer8A;

            if (!Ext.isEmpty(answer8A)) {

                parms['ItemName'] = 'item8';
                parms['Question'] = 'Question8A';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer8A1 = permanencyStore.getAt(0).data.MotherVisitationFrequencyCode;
            answer8A1 = answer8A1 == 0 ? undefined : answer8A1;

            if (!Ext.isEmpty(answer8A1)) {

                parms['ItemName'] = 'item8';
                parms['Question'] = 'Question8A1';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer8B = permanencyStore.getAt(0).data.IsSufficientFrequencyForFatherVisitation;
            answer8B = answer8B == 0 ? undefined : answer8B;

            if (!Ext.isEmpty(answer8B)) {

                parms['ItemName'] = 'item8';
                parms['Question'] = 'Question8B';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer8B1 = permanencyStore.getAt(0).data.FatherVisitationFrequencyCode;
            answer8B1 = answer8B1 == 0 ? undefined : answer8B1;

            if (!Ext.isEmpty(answer8B1)) {

                parms['ItemName'] = 'item8';
                parms['Question'] = 'Question8B1';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer8C = permanencyStore.getAt(0).data.IsSufficientQualityForMotherVisitation;
            answer8C = answer8C == 0 ? undefined : answer8C;

            if (!Ext.isEmpty(answer8C)) {

                parms['ItemName'] = 'item8';
                parms['Question'] = 'Question8C';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer8D = permanencyStore.getAt(0).data.IsSufficentQualityForFatherVisitation;
            answer8D = answer8D == 0 ? undefined : answer8D;

            if (!Ext.isEmpty(answer8D)) {

                parms['ItemName'] = 'item8';
                parms['Question'] = 'Question8D';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer8E = permanencyStore.getAt(0).data.IsSufficientFrequencyForSiblingVisitation;
            answer8E = answer8E == 0 ? undefined : answer8E;

            if (!Ext.isEmpty(answer8E)) {

                parms['ItemName'] = 'item8';
                parms['Question'] = 'Question8E';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer8E1 = permanencyStore.getAt(0).data.SiblingVisitationFrequencyCode;
            answer8E1 = answer8E1 == 0 ? undefined : answer8E1;

            if (!Ext.isEmpty(answer8E1)) {

                parms['ItemName'] = 'item8';
                parms['Question'] = 'Question8E1';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer8F = permanencyStore.getAt(0).data.IsSufficentQualityForSiblingVisitation;
            answer8F = answer8F == 0 ? undefined : answer8F;

            if (!Ext.isEmpty(answer8F)) {

                parms['ItemName'] = 'item8';
                parms['Question'] = 'Question8F';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }
            //
            // If question 8A1 is NA, then question 8A must be NA.
            // 
            if (answer8A1 == 1 && !(answer8A == 3)) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 8A, please select NA since NA is selected in question 8A1. ';
                vResult['message'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item8AQuestion', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem8AQuestion', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            //
            // If NA is not selected in question 8A1, then question 8A must be Yes or No. 
            // 
            if (!(answer8A1 == 1) && answer8A == 3) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 8A, please select Yes or No since NA is not selected in question 8A1. ';
                vResult['message'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item8AQuestion', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem8AQuestion', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            //
            // If question 8A is NA, then question 8C must be NA. 
            // 
            if (answer8A == 3 && !(answer8C == 3)) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 8C, please select NA since NA is selected in question 8A. ';
                vResult['message'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item8CQuestion', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem8CQuestion', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            //
            // If question 8A1 is Never, question 8C must be NA. 
            // 
            if (answer8A1 == 7 && !(answer8C == 3)) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 8C, please select NA since Never is selected in question 8A1. ';
                vResult['message'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item8CQuestion', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem8CQuestion', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            //
            // If question 8B1 is NA, then question 8B must be NA. 
            // 
            //if (!Ext.isEmpty(answer8B)) {

                if (answer8B1 == 1 && !(answer8B == 3)) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 8B, please select NA since NA is selected in question8B1. ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item8BQuestion', appPages.Permanency);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem8BQuestion', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
            //}            
            //
            // If NA is not selected in question 8B1, then question 8B must be Yes or No. 
            // 
            if (!(answer8B1 == 1) && answer8B == 3) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 8B, please select Yes or No since NA is not selected in question 8B1. ';
                vResult['message'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item8BQuestion', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem8BQuestion', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            //
            // If question 8B is NA, then question 8D must be NA. 
            // 
            if (answer8B == 3 && !(answer8D == 3)) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 8D, please select NA since NA is selected in question 8B. ';
                vResult['message'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item8DQuestion', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem8DQuestion', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            //
            // If question 8B1 is Never, question 8D must be NA. 
            // 
            if (answer8B1 == 7 && !(answer8D == 3)) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 8D, please select NA since Never is selected in question 8B1. ';
                vResult['message'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item8DQuestion', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem8DQuestion', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            //
            // If NA is not selected in question 8E1, then question 8E must be Yes or No. 
            // 
            if (!(answer8E1 == 1) && answer8E == 3) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 8E, please select Yes or No since NA is not selected in question 8E1. ';
                vResult['message'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item8EQuestion', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem8EQuestion', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            //
            // If question 8E is NA, then question 8F must be NA. 
            // 
            if (answer8E == 3 && !(answer8F == 3)) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 8F, please select NA since NA is selected in question 8E. ';
                vResult['message'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item8FQuestion', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem8FQuestion', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }

            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 9;
            vResult['OutcomeCode'] = 4;

            result.push(vResult);

            if (input[0] == sr.Constants.AllFields) {

                validationResults['item8'] = result;
            }

            var itemQuestions = getItemQuestions('item8');
            itemQuestions[0].errorsExist = false;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus) {
                errorCount = 0;
            }

            if (errorCount > 0) {

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            return result;
        },
        validateItem9: function (input) {
            var self = this;
            var result = [];
            var input = self.getValidationInput();
            var vResult = {};
            var applicabilityItems = {};
            var inputObj;
            var validateAllFields = false;
            var pageName = 'Permanency';
            var itemName = 'item9';
            var noResponses = 0;
            var questions = getItemQuestions('item9');
            var itemCode = 10;
            var outcomeCode = 4;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'permanency' };
            var errorCount = 0;

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.permanencyViewModel)) {

                var vModel = createViewModel('permanency');

                window.permanencyViewModel = vModel;
            }

            if (!Ext.isEmpty(window.permanencyViewModel)) {

                viewModel = window.permanencyViewModel.data;
                isViewModelValid = true;
            }

            Ext.each(input, function (columnName) {

                var store = Ext.data.StoreManager.lookup('CR_Permanency_CollectionStore');

                // Item 9 applicability is a required field. 
                if (columnName == 'IsApplicable' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        // Reset all validation messages
                        resetValidationMessages(['item9DPanel']);

                        validateAllFields = true;
                    }

                    var validValues = [1, 2];

                    applicabilityItems['Source'] = store;
                    applicabilityItems['ValidValues'] = validValues;
                    applicabilityItems['PageName'] = pageName;
                    applicabilityItems['ItemName'] = itemName;
                    applicabilityItems['Message'] = 'Please select Yes or No.';
                    applicabilityItems['ItemCode'] = itemCode;
                    applicabilityItems['OutcomeCode'] = outcomeCode;

                    result = self.validateItemApplicability(applicabilityItems);

                    if (!Ext.isEmpty(result[result.length - 1].CaseApplicable)) {

                        parms['ItemName'] = itemName;
                        parms['Question'] = 'Applicability';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }
                }
            });
            //
            // If C is NA (not a member of a Tribe), then D is NA. 
            //
            var permanencyStore = Ext.data.ChainedStore.create({
                source: 'CR_Permanency_CollectionStore'
            });

            var answer9A = permanencyStore.getAt(0).data.IsConcertedEffortsForImportantConnections;
            answer9A = answer9A == 0 ? undefined : answer9A;

            if (!Ext.isEmpty(answer9A)) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question9A';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer9B = permanencyStore.getAt(0).data.IsSufficientInquiryForIndianTribe;
            answer9B = answer9B == 0 ? undefined : answer9B;

            if (!Ext.isEmpty(answer9B)) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question9B';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer9C = permanencyStore.getAt(0).data.IsTribeProvidedTimelyNotification;
            answer9C = answer9C == 0 ? undefined : answer9C;

            if (!Ext.isEmpty(answer9C)) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question9C';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer9D = permanencyStore.getAt(0).data.IsAccordanceWithIndianChildWelfareAct;
            answer9D = answer9D == 0 ? undefined : answer9D;

            if (!Ext.isEmpty(answer9D)) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question9D';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            if (answer9C == 3 && !(answer9D == 3)) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 9D, please select NA since NA is selected in question 9C. ';
                vResult['applicability'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item9DQuestion', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem9DQuestion', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            
            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 10;
            vResult['OutcomeCode'] = 4;

            result.push(vResult);

            if (input[0] == sr.Constants.AllFields) {

                validationResults['item9'] = result;
            }

            var itemQuestions = getItemQuestions('item9');
            itemQuestions[0].errorsExist = false;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus) {
                errorCount = 0;
            }

            if (errorCount > 0) {

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            // Make item status accessible
            var caseType = getCaseType();
            var itemStatus;

            if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

                itemStatus = 'Not Applicable';
                var statusObj = { ItemCode: itemCode, StatusDesc: itemStatus, OutcomeCode: outcomeCode };

                updateItemStatusCode(statusObj);
            } else {

                itemStatus = calculateItemStatus(result);
            }

            result['itemStatus'] = itemStatus;
            itemStatuses['item9'] = itemStatus;

            return result;
        },
        validateItem10: function (input) {
            var self = this;
            var result = [];
            var input = self.getValidationInput();
            var vResult = {};
            var applicabilityItems = {};
            var inputObj;
            var validateAllFields = false;
            var pageName = 'Permanency';
            var itemName = 'item10';
            var noResponses = 0;
            var questions = getItemQuestions('item10');
            var itemCode = 11;
            var outcomeCode = 4;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'permanency' };
            var errorCount = 0;

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.permanencyViewModel)) {

                var vModel = createViewModel('permanency');

                window.permanencyViewModel = vModel;
            }

            if (!Ext.isEmpty(window.permanencyViewModel)) {

                viewModel = window.permanencyViewModel.data;
                isViewModelValid = true;
            }

            Ext.each(input, function (columnName) {

                var store = Ext.data.StoreManager.lookup('CR_Permanency_CollectionStore');

                // Item 10 applicability is a required field. 
                if (columnName == 'IsApplicable' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        // Reset all validation messages
                        resetValidationMessages(['item10A1','item10A2','item10B','item10C']);

                        validateAllFields = true;
                    }

                    var validValues = [1, 2];

                    applicabilityItems['Source'] = store;
                    applicabilityItems['ValidValues'] = validValues;
                    applicabilityItems['PageName'] = pageName;
                    applicabilityItems['ItemName'] = itemName;
                    applicabilityItems['Message'] = 'Please select Yes or No.';
                    applicabilityItems['ItemCode'] = itemCode;
                    applicabilityItems['OutcomeCode'] = outcomeCode;

                    result = self.validateItemApplicability(applicabilityItems);

                    if (!Ext.isEmpty(result[result.length - 1].CaseApplicable)) {

                        parms['ItemName'] = itemName;
                        parms['Question'] = 'Applicability';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }
                }
            });
            //
            // Item 10 cannot be completed until at least one placement is entered in table 4A1. 
            //
            var placementTable = chainedStore('CR_Placement_CollectionStore');

            if (placementTable.length == 0) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'Please complete table 4A1 before answering questions in this item.';
                vResult['applicability'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item10A1Question', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem10A1Question', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.setMsgType(vResult['messageType']);
                    msgComponent.updateMessages();
                }
            }
            //
            // If question 10A1 is No, then question 10A2 must be NA. 
            //
            var permanencyStore = Ext.data.ChainedStore.create({
                source: 'CR_Permanency_CollectionStore'
            });

            var answer10A1 = permanencyStore.getAt(0).data.IsRecentPlacementWithRelative;
            answer10A1 = answer10A1 == 0 ? undefined : answer10A1;

            if (!Ext.isEmpty(answer10A1)) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question10A1';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer10A2 = permanencyStore.getAt(0).data.IsPlacementWithRelativeStable;
            answer10A2 = answer10A2 == 0 ? undefined : answer10A2;

            if (!Ext.isEmpty(answer10A2)) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question10A2';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            if (answer10A1 == 2 && !(answer10A2 == 3)) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 10A2, please select NA since No is selected in question 10A1.';
                vResult['applicability'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item10A2Question', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem10A2Question', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.setMsgType(vResult['messageType']);
                    msgComponent.updateMessages();
                }
            }
            //
            // If question 10A1 is Yes, then question 10A2 cannot be NA. 
            //
            if (answer10A1 == 1 && answer10A2 == 3) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 10A2, please select Yes or No since Yes is selected in question 10A1.';
                vResult['applicability'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item10A2Question', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem10A2Question', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.setMsgType(vResult['messageType']);
                    msgComponent.updateMessages();
                }
            }
            //
            // If questions 10A1 and 10A2 are both Yes, then question 10B must be NA. 
            //
            var answer10B = permanencyStore.getAt(0).data.IsConcertedEffortToLocateMaternalRelatives;
            answer10B = answer10B == 0 ? undefined : answer10B;

            if (!Ext.isEmpty(answer10B)) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question10B';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            if (answer10A1 == 1 && answer10A2 == 1 && !(answer10B == 3)) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 10B, please select NA since Yes is selected in both questions 10A1 and 10A2. ';
                vResult['applicability'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item10BQuestion', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem10BQuestion', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.setMsgType(vResult['messageType']);
                    msgComponent.updateMessages();
                }
            }
            //
            // If question 10B is No, at least one of the four checkboxes that follows must be selected. 
            //

            //var question10BCheckBoxGroup = self.getCheckBoxGroup('CR_MultiAnswer_CollectionStore', 'PlacementEffortConcernsMother');

            var question10BCheckBoxGroup = self.getLocationConcerns('Mother');

            if (answer10B == 2 && question10BCheckBoxGroup.length == 0) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 10B, please specify the area in which concerns existed for a response of No.';
                vResult['applicability'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item10BQuestion', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem10BQuestion', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.setMsgType(vResult['messageType']);
                    msgComponent.updateMessages();
                }
            }
            //
            // If questions 10A1 and 10A2 are both Yes, then question 10C must be NA. 
            //
            var answer10C = permanencyStore.getAt(0).data.IsConcertedEffortToLocatePaternalRelatives;
            answer10C = answer10C == 0 ? undefined : answer10C;

            if (!Ext.isEmpty(answer10C)) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question10C';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            if (answer10A1 == 1 && answer10A2 == 1 && !(answer10C == 3)) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 10C, please select NA since Yes is selected in both questions 10A1 and 10A2. ';
                vResult['applicability'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item10CQuestion', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem10CQuestion', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.setMsgType(vResult['messageType']);
                    msgComponent.updateMessages();
                }
            }
            //
            // If question 10C is No, at least one of the four checkboxes that follows must be selected. 
            //

            //var question10CCheckBoxGroup = self.getCheckBoxGroup('CR_MultiAnswer_CollectionStore', 'PlacementEffortConcernsFather');

            var question10CCheckBoxGroup = self.getLocationConcerns('Father');

            if (answer10C == 2 && question10CCheckBoxGroup.length == 0) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 10C, please specify the area in which concerns existed for a response of No. ';
                vResult['applicability'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item10CQuestion', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem10CQuestion', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.setMsgType(vResult['messageType']);
                    msgComponent.updateMessages();
                }
            }

            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 11;
            vResult['OutcomeCode'] = 4;

            result.push(vResult);

            if (input[0] == sr.Constants.AllFields) {

                validationResults['item10'] = result;
            }

            var itemQuestions = getItemQuestions('item10');
            itemQuestions[0].errorsExist = false;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus) {
                errorCount = 0;
            }

            if (errorCount > 0) {

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            return result;
        },
        validateItem11: function (input) {
            var self = this;
            var result = [];
            var input = self.getValidationInput();
            var vResult = {};
            var applicabilityItems = {};
            var inputObj;
            var validateAllFields = false;
            var pageName = 'Permanency';
            var itemName = 'item11';
            var noResponses = 0;
            var questions = getItemQuestions('item11');
            var itemCode = 12;
            var outcomeCode = 4;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'permanency' };
            var errorCount = 0;

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.permanencyViewModel)) {

                var vModel = createViewModel('permanency');

                window.permanencyViewModel = vModel;
            }

            if (!Ext.isEmpty(window.permanencyViewModel)) {

                viewModel = window.permanencyViewModel.data;
                isViewModelValid = true;
            }

            Ext.each(input, function (columnName) {

                var store = Ext.data.StoreManager.lookup('CR_Permanency_CollectionStore');

                // All pre-applicability questions must be answered.
                if (columnName == 'PreApplicability' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        // Reset all validation messages
                        resetValidationMessages(['item11Panel', 'item11APanel', 'item11A1Panel', 'item11BPanel', 'item11B1Panel']);

                        validateAllFields = true;
                    }

                    questionVal = {};

                    var validValues = [{ itemId: 'item11Question1', codeDescriptionId: 63 },
                                       { itemId: 'item11Question2', codeDescriptionId: 64 },
                                       { itemId: 'item11Question3', codeDescriptionId: 65 },
                                       { itemId: 'item11Question4', codeDescriptionId: 66 },
                                       { itemId: 'item11Question5', codeDescriptionId: 67 },
                                       { itemId: 'item11Question6', codeDescriptionId: 261 }
                    ];

                    result = self.validateItemPreApplicability(store, validValues, 'Permanency', 'Item11', 'Please answer all questions on this page.');

                    if (result.length > 0) {

                        if (result[0].NoResponses > 0) {

                            parms['ItemName'] = itemName;
                            parms['Question'] = 'PreApplicability';
                            parms['Answered'] = true;

                            updateQuestionsAnswered(parms);
                        }

                        if (!Ext.isEmpty(result[0].PreApplicability)) {

                            questionVal['PreApplicability'] = result[0].PreApplicability;

                        }
                        
                        var errors = result.filter(function (obj) {

                            return obj.messageType == 'Error';
                        });

                        if (errors.length > 0) {

                            // Get the validation message component
                            var container = getCRSComponent('item11PreApplicableCases', appPages.Permanency);

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgItem11PreApplicableCases', container);

                                msgComponent.setValidationResult(questionVal);
                                msgComponent.updateMessages();
                            }
                        }
                    }
                }

                // Item 11 applicability is a required field. 
                if (columnName == 'IsApplicable' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        validateAllFields = true;
                    }

                    var validValues = [1, 2];

                    applicabilityItems['Source'] = store;
                    applicabilityItems['ValidValues'] = validValues;
                    applicabilityItems['PageName'] = pageName;
                    applicabilityItems['ItemName'] = itemName;
                    applicabilityItems['Message'] = 'Please select Yes or No.';
                    applicabilityItems['ItemCode'] = itemCode;
                    applicabilityItems['OutcomeCode'] = outcomeCode;
                    applicabilityItems['PreApplicability'] = result;

                    result = result.concat(self.validateItemApplicability(applicabilityItems));

                    if (!Ext.isEmpty(result[result.length - 1].CaseApplicable)) {

                        parms['ItemName'] = itemName;
                        parms['Question'] = 'Applicability';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);

                        if (!Ext.isEmpty(self.getCmp())) {

                            var motherCheckboxGroup = self.getCmp().getItem11ParticipantCheckboxGroupMother();
                            var fatherCheckboxGroup = self.getCmp().getItem11ParticipantCheckboxGroupFather();

                            if (motherCheckboxGroup.items.length > 0 || fatherCheckboxGroup.items.length > 0) {

                                parms['ItemName'] = 'item11';
                                parms['Question'] = 'MotherOrFatherApplicable';
                                parms['Answered'] = true;

                                updateQuestionsAnswered(parms);
                            }
                        }
                    }
                }
            });

            var parms1 = { ItemCode: itemCode, OutcomeCode: outcomeCode };

            var participants = getParticipantsSelected(parms1);

            var participantMotherStore = participants.Mothers;
            var participantFatherStore = participants.Fathers;

            var permanencyStore = Ext.data.ChainedStore.create({
                source: 'CR_Permanency_CollectionStore'
            });
            
            var answer11A = permanencyStore.getAt(0).data.IsConcertedEffortMotherFosterRelationship;
            answer11A = answer11A == 0 ? undefined : answer11A;

            if (!Ext.isEmpty(answer11A)) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question11A';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var question11A1CheckBoxGroup = self.getCheckboxSelections('question11A1');

            //var question11A1CheckBoxGroup = self.getCheckBoxGroup('CR_MultiAnswer_CollectionStore', 'EffortsToSupportMotherFosterRelationship');

            if (question11A1CheckBoxGroup.length > 0) {

                noResponses++;

                parms['ItemName'] = 'item11';
                parms['Question'] = 'Question11A1';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer11B = permanencyStore.getAt(0).data.IsConcertedEffortFatherFosterRelationship;
            answer11B = answer11B == 0 ? undefined : answer11B;

            if (!Ext.isEmpty(answer11A)) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question11B';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            //var question11B1CheckBoxGroup = self.getCheckBoxGroup('CR_MultiAnswer_CollectionStore', 'EffortsToSupportFatherFosterRelationship');
            var question11B1CheckBoxGroup = self.getCheckboxSelections('question11B1');

            if (question11B1CheckBoxGroup.length > 0) {

                noResponses++;

                parms['ItemName'] = 'item11';
                parms['Question'] = 'Question11B1';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            if (participantMotherStore.length > 0) {

                parms['ItemName'] = 'item11';
                parms['Question'] = 'ApplicabilityMother';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            if (participantFatherStore.length > 0) {

                parms['ItemName'] = 'item11';
                parms['Question'] = 'ApplicabilityFather';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            //
            // If Mother was selected on the applicability page, question 11A cannot be NA. 
            //
            if (participantMotherStore.length > 0 && answer11A == 3) {
                
                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 11A, please do not select NA since a case participant was selected as Mother and marked applicable for assessment in this item. ';
                vResult['applicability'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item11AQuestion', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem11AQuestion', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            //
            // If question 11A is Yes, question 11A1 cannot be NA. 
            //
            var answer11A1NA = question11A1CheckBoxGroup.filter(function (item) {
                return item.inputValue == 164;
            });

            if (answer11A == 1 && answer11A1NA.length > 0) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 11A1, please select a response other than NA since question 11A is Yes. ';
                vResult['applicability'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item11A1ConcertedEfforts', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem11A1ConcertedEfforts', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            //
            // If question 11A is No, question 11A1 must be NA. 
            //
            if (answer11A == 2 && answer11A1NA.length == 0) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 11A1, please select NA since No is selected in question 11A. ';
                vResult['applicability'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item11A1ConcertedEfforts', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem11A1ConcertedEfforts', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            //
            // If question 11A1 is Other, the following narrative field is required. 
            //
            var answer11A1Other = question11A1CheckBoxGroup.filter(function (item) {
                return item.inputValue == 170;
            });

            var answer11A1Narrative = permanencyStore.getAt(0).data.EffortsMotherFosterOther;
            
            if (answer11A1Other.length > 0 && answer11A1Narrative.length == 0) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 11A1, please fill out the narrative field for a response of Other. ';
                vResult['applicability'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item11A1ConcertedEfforts', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem11A1ConcertedEfforts', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            //
            // If question 11A1 is NA, no other selections can be made. If other selections should be made, NA cannot be selected. 
            //
            if (answer11A1NA.length > 0 && question11A1CheckBoxGroup.length > 1) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 11A1, if you have selected NA, please ensure that no other selections were made. ';
                vResult['applicability'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item11A1ConcertedEfforts', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem11A1ConcertedEfforts', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            //
            // If Father was selected on the applicability page, question 11B cannot be NA. 
            //
            if (participantFatherStore.length > 0 && answer11B == 3) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 11B, please do not select NA since a case participant was selected as Father and marked applicable for assessment in this item. ';
                vResult['applicability'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item11BQuestion', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem11BQuestion', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }

            var answer11B1NA = question11B1CheckBoxGroup.filter(function (item) {
                return item.inputValue == 171;
            });
            //
            // If question 11B is Yes, question 11B1 cannot be NA. 
            //
            if (answer11B == 1 && answer11B1NA.length > 0) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 11B1, please select a response other than NA since question 11B is Yes. ';
                vResult['applicability'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item11B1ConcertedEfforts', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem11B1ConcertedEfforts', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            //
            // If question 11B is No, question 11B1 must be NA. 
            //
            if (answer11B == 2 && answer11B1NA.length == 0) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 11B1, please select NA since No is selected in question 11B. ';
                vResult['applicability'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item11B1ConcertedEfforts', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem11B1ConcertedEfforts', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            //
            // If question 11B1 is Other, the following narrative field is required. 
            //
            var answer11B1Other = question11B1CheckBoxGroup.filter(function (item) {
                return item.inputValue == 177;
            });

            var answer11B1Narrative = permanencyStore.getAt(0).data.EffortFatherFosterRelationshipOther;
            
            if (answer11B1Other.length > 0 && answer11B1Narrative.length == 0) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 11B1, please fill out the narrative field for a response of Other. ';
                vResult['applicability'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item11B1ConcertedEfforts', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem11B1ConcertedEfforts', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }
            //
            // If question 11B1 is NA, no other selections can be made. If other selections should be made, NA cannot be selected. 
            //
            if (answer11B1NA.length > 0 && question11B1CheckBoxGroup.length > 1) {

                questionVal = {};

                if (vResult.rowNumber == undefined) {
                    vResult['page'] = pageName;
                }

                vResult['item'] = itemName;
                questionVal['Message'] = 'For question 11B1, if you have selected NA, please ensure that no other selections were made. ';
                vResult['applicability'] = questionVal['Message'];
                vResult['messageType'] = 'Error';
                errorCount++;

                // Get the validation message component
                var container = getCRSComponent('item11B1ConcertedEfforts', appPages.Permanency);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent('msgItem11B1ConcertedEfforts', container);

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.updateMessages();
                }
            }

            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 12;
            vResult['OutcomeCode'] = 4;

            result.push(vResult);

            if (input[0] == sr.Constants.AllFields) {

                validationResults['item11'] = result;
            }

            var itemQuestions = getItemQuestions('item11');
            itemQuestions[0].errorsExist = false;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus) {
                errorCount = 0;
            }

            if (errorCount > 0) {

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            return result;
        },
        validateItem12: function (input) {
            var self = this;
            var result = [];
            var vResult = {};
            var applicabilityItems = {};
            var inputObj;
            var validateAllFields = false;
            var noResponses = 0;
            var pageName = 'Wellbeing';
            var itemName = 'item12';
            var questions = getItemQuestions('item12');
            var itemCode = 13;
            var outcomeCode = 5;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'wellbeing' };
            var errorCount = 0;

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.wellbeingViewModel)) {

                var vModel = createViewModel('wellbeing');

                window.wellbeingViewModel = vModel;
            }

            if (!Ext.isEmpty(window.wellbeingViewModel)) {

                viewModel = window.wellbeingViewModel.data;
                isViewModelValid = true;
            }

            var result12A = this.validateItem12A(['All']);
            var result12B = this.validateItem12B(['All']);
            var result12C = this.validateItem12C(['All']);

            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 13;
            vResult['OutcomeCode'] = 5;

            result.push(vResult);

            validationResults['item12'] = result;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus) {
                errorCount = 0;
            }

            if (errorCount > 0) {

                var itemQuestions = getItemQuestions('item12');

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            // Make item status accessible
            var status = calculateItem12Status();

            result['itemStatus'] = status;
            itemStatuses['item12'] = status;

            // Update Item Status
            if (!Ext.isEmpty(itemCode) && !Ext.isEmpty(outcomeCode)) {

                var statusObj = { ItemCode: itemCode, StatusDesc: status, OutcomeCode: outcomeCode };

                updateItemStatusCode(statusObj);
            }

            return result;
        },
        validateItem12A: function (input) {
            var self = this;
            var result = [];
            var input = self.getValidationInput();
            var vResult = {};
            var applicabilityItems = {};
            var inputObj;
            var validateAllFields = false;
            var noResponses = 0;
            var pageName = 'Wellbeing';
            var itemName = 'item12A';
            var questions = getItemQuestions('item12A');
            var itemCode = 14;
            var outcomeCode = 5;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'wellbeing' };
            var errorCount = 0;

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.wellbeingViewModel)) {

                var vModel = createViewModel('wellbeing');

                window.wellbeingViewModel = vModel;
            }

            if (!Ext.isEmpty(window.wellbeingViewModel)) {

                viewModel = window.wellbeingViewModel.data;
                isViewModelValid = true;
            }

            Ext.each(input, function (columnName) {

                var store = Ext.data.StoreManager.lookup(self.getStoreId());

                // For in-home cases, at least one child must 
                // be selected on the sub-item 12A applicability page.
                if (columnName == 'IsApplicable' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        // Reset all validation messages
                        resetValidationMessages(['item12A1']);

                        validateAllFields = true;
                    }

                    var validValues = [];

                    applicabilityItems['Source'] = store;
                    applicabilityItems['ValidValues'] = validValues;
                    applicabilityItems['PageName'] = pageName;
                    applicabilityItems['ItemName'] = itemName;
                    applicabilityItems['Message'] = 'Please indicate the name of at least one child who is included in an assessment of this item.';
                    applicabilityItems['ItemCode'] = itemCode;
                    applicabilityItems['OutcomeCode'] = outcomeCode;

                    result = self.validateItemApplicability(applicabilityItems);

                }
                
            });

            var wellBeingStore = Ext.data.ChainedStore.create({
                source: 'CR_WellBeing_CollectionStore'
            });

            var answer12A1;
            var answer12A2;
            var narrative12A1;
            var narrative12A2;

            if (wellBeingStore.data.length > 0) {

                vResult['PageName'] = 'Well Being';
                vResult['ItemName'] = 'Item 12A';

                questionVal = {};

                answer12A1 = wellBeingStore.getAt(0).data.IsComprehensiveAssessementConducted;
                answer12A1 = answer12A1 == 0 ? undefined : answer12A1;

                if (!Ext.isEmpty(answer12A1)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question12A1';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                answer12A2 = wellBeingStore.getAt(0).data.IsAppropriateServicesProvided;
                answer12A2 = answer12A2 == 0 ? undefined : answer12A2;

                if (!Ext.isEmpty(answer12A2)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question12A2';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                narrative12A1 = wellBeingStore.getAt(0).data.ComprehensiveAssessmentExplained;
                narrative12A2 = wellBeingStore.getAt(0).data.AppropriateServicesProvidedExplained;
               
                vResult['item12AQuestionA1'] = answer12A1 == 1 ? 'Yes' : answer12A1 == 2 ? 'No' : answer12A1 == 3 ? 'NA' : undefined;
                vResult['item12AQuestionA2'] = answer12A2 == 1 ? 'Yes' : answer12A2 == 2 ? 'No' : answer12A2 == 3 ? 'NA' : undefined;
               
                //
                // If question 12A1 is No, the following narrative field is required.  
                //
                if (answer12A1 == 2 && narrative12A1.length == 0) {

                    questionVal['Message'] = 'For question 12A1, please fill out the narrative field for a response of No.';
                    vResult['Message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item12A1NeedConcerns', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem12A1NeedConcerns', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 12A2 is No, the following narrative field is required.  
                //
                if (answer12A2 == 2 && narrative12A2.length == 0) {

                    questionVal['Message'] = 'For question 12A2, please fill out the narrative field for a response of No.';
                    vResult['Message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item12A2AppropriateServicesProvidedExplained', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem12A2AppropriateServicesProvidedExplained', container);
                        
                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
            }

            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 14;
            vResult['OutcomeCode'] = 5;

            result.push(vResult);

            if (input[0] == sr.Constants.AllFields) {

                validationResults['item12A'] = result;
            }

            var itemQuestions = getItemQuestions('item12A');
            itemQuestions[0].errorsExist = false;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus) {
                errorCount = 0;
            }

            if (errorCount > 0) {

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            return result;
        },
        validateItem12B: function (input) {
            var self = this;
            var result = [];
            var input = self.getValidationInput();
            var vResult = {};
            var applicabilityItems = {};
            var inputObj;
            var validateAllFields = false;
            var pageName = 'Wellbeing';
            var itemName = 'item12B';
            var questionVal = {};
            var noResponses = 0;
            var questions = getItemQuestions('item12B');
            var itemCode = 15;
            var outcomeCode = 5;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'wellbeing' };
            var errorCount = 0;

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.wellbeingViewModel)) {

                var vModel = createViewModel('wellbeing');

                window.wellbeingViewModel = vModel;
            }

            if (!Ext.isEmpty(window.wellbeingViewModel)) {

                viewModel = window.wellbeingViewModel.data;
                isViewModelValid = true;
            }

            Ext.each(input, function (columnName) {

                var store = Ext.data.StoreManager.lookup(self.getStoreId());
                //
                // All pre-applicability questions must be answered.
                //
                if (columnName == 'PreApplicability' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        // Reset all validation messages
                        resetValidationMessages(['item12B1', 'item12B2', 'item12B3', 'item12B4']);

                        validateAllFields = true;
                    }

                    questionVal = {};

                    var validValues = [{ itemId: 'item12BQuestion1', codeDescriptionId: 68 },
                                       { itemId: 'item12BQuestion2', codeDescriptionId: 69 },
                                       { itemId: 'item12BQuestion3', codeDescriptionId: 70 },
                                       { itemId: 'item12BQuestion4', codeDescriptionId: 71 },
                                       { itemId: 'item12BQuestion5', codeDescriptionId: 72 }
                    ];

                    result = self.validateItemPreApplicability(store, validValues, 'Wellbeing', 'Item12B', 'Please answer all questions on this page.');

                    if (result.length > 0) {

                        if (result[0].NoResponses == validValues.length) {

                            parms['ItemName'] = itemName;
                            parms['Question'] = 'PreApplicability';
                            parms['Answered'] = true;

                            updateQuestionsAnswered(parms);
                        }

                        if (!Ext.isEmpty(result[0].PreApplicability)) {

                            questionVal['PreApplicability'] = result[0].PreApplicability;

                        }
                        
                        var errors = result.filter(function (obj) {

                            return obj.messageType == 'Error';
                        });

                        if (errors.length > 0) {

                            // Get the validation message component
                            var container = getCRSComponent('item12BPreApplicableCases', appPages.Wellbeing);

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgItem12BPreApplicableCases', container);

                                msgComponent.setValidationResult(questionVal);
                                msgComponent.updateMessages();
                            }
                        }
                    }
                }
                //
                // Item applicability determination
                //
                if (columnName == 'IsApplicable' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        validateAllFields = true;
                    }

                    var validValues = [1, 2];

                    applicabilityItems['Source'] = store;
                    applicabilityItems['ValidValues'] = validValues;
                    applicabilityItems['PageName'] = pageName;
                    applicabilityItems['ItemName'] = itemName;
                    applicabilityItems['Message'] = 'Please select Yes or No.';
                    applicabilityItems['ItemCode'] = itemCode;
                    applicabilityItems['OutcomeCode'] = outcomeCode;
                    applicabilityItems['PreApplicability'] = result;

                    result = result.concat(self.validateItemApplicability(applicabilityItems));
                    var caseApplicable = result[result.length - 1].CaseApplicable == 1 ? true : false;
                    var motherApplicable = result[result.length - 1].MotherApplicable == 1 ? true : false;
                    var fatherApplicable = result[result.length - 1].FatherApplicable == 1 ? true : false;

                    if (caseApplicable) {

                        parms['ItemName'] = itemName;
                        parms['Question'] = 'Applicability';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }

                    if ((motherApplicable) || (fatherApplicable)) {

                        parms['ItemName'] = itemName;
                        parms['Question'] = 'MotherOrFatherApplicable';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }                    
                }
            });

            var wellBeingStore = Ext.data.ChainedStore.create({
                source: 'CR_WellBeing_CollectionStore'
            });

            var answer12B1;
            var answer12B2;
            var answer12B3;
            var answer12B4;

            var narrative12B1;
            var narrative12B2;
            var narrative12B3;
            var narrative12B4;

            var answer12BMotherApplicability;
            var answer12BFatherApplicability;
            var motherStore = GetItemParticipant(1);
            var fatherStore = GetItemParticipant(2);

            var parms1 = { ItemCode: itemCode, OutcomeCode: outcomeCode };

            var participants = getParticipantsSelected(parms1);

            var motherSelected = participants.Mothers;
            var fatherSelected = participants.Fathers;

            if (wellBeingStore.data.length > 0) {

                answer12B1 = wellBeingStore.getAt(0).data.IsComprehensiveAssessementForMotherConducted;
                answer12B1 = answer12B1 == 0 ? undefined : answer12B1;

                if (!Ext.isEmpty(answer12B1)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question12B1';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                answer12B3 = wellBeingStore.getAt(0).data.IsAppropriateServicesForMotherProvided;
                answer12B3 = answer12B3 == 0 ? undefined : answer12B3;

                if (!Ext.isEmpty(answer12B3)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question12B3';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                answer12B2 = wellBeingStore.getAt(0).data.IsComprehensiveAssessementForFatherConducted;
                answer12B2 = answer12B2 == 0 ? undefined : answer12B2;

                if (!Ext.isEmpty(answer12B2)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question12B2';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                answer12B4 = wellBeingStore.getAt(0).data.IsAppropriateServicesForFatherProvided;
                answer12B4 = answer12B4 == 0 ? undefined : answer12B4;

                if (!Ext.isEmpty(answer12B4)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question12B4';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                var motherApplicable = result.length == 0 ? 0 : result[result.length - 1].MotherApplicable;
                motherApplicable = motherApplicable == 0 ? undefined : motherApplicable;

                if (!(Ext.isEmpty(motherApplicable))) {
                    
                    parms['ItemName'] = itemName;
                    parms['Question'] = 'ApplicabilityMother';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                var fatherApplicable = result.length == 0 ? 0 : result[result.length - 1].FatherApplicable;
                fatherApplicable = fatherApplicable == 0 ? undefined : fatherApplicable;

                if (!(Ext.isEmpty(fatherApplicable))) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'ApplicabilityFather';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (motherSelected.length > 0) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'MotherSelected';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (fatherSelected.length > 0) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'FatherSelected';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }


                if (motherSelected.length > 0 || fatherSelected.length > 0) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'MotherOrFatherApplicable';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }


                narrative12B1 = wellBeingStore.getAt(0).data.ComprehensiveAssessementForMotherExplained;
                narrative12B3 = wellBeingStore.getAt(0).data.AppropriateServicesForMotherExplained;
                narrative12B2 = wellBeingStore.getAt(0).data.ComprehensiveAssessementforFatherConductedExplained;
                narrative12B4 = wellBeingStore.getAt(0).data.AppropriateServicesForFatherExplained;

                vResult['item12BQuestion1'] = answer12B1 == 1 ? 'Yes' : answer12B1 == 2 ? 'No' : answer12B1 == 3 ? 'NA' : undefined;
                vResult['item12BQuestion3'] = answer12B3 == 1 ? 'Yes' : answer12B3 == 2 ? 'No' : answer12B3 == 3 ? 'NA' : undefined;
                vResult['item12BQuestion2'] = answer12B2 == 1 ? 'Yes' : answer12B2 == 2 ? 'No' : answer12B2 == 3 ? 'NA' : undefined;
                vResult['item12BQuestion4'] = answer12B4 == 1 ? 'Yes' : answer12B4 == 2 ? 'No' : answer12B4 == 3 ? 'NA' : undefined;
                //
                // If question 12B1 is No, the following narrative field is required. 
                //
                if (answer12B1 == 2 && narrative12B1.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 12B1, please fill out the narrative field for a response of No. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    vResult['Message'] = questionVal['Message'];

                    // Get the validation message component
                    var container = getCRSComponent('item12BQuestion1Narrative', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem12BQuestion1Narrative', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If Mother was selected on the applicability page, question 12B1 cannot be NA. 
                //
                if (result.length > 0) {

                    if (result[0].MotherApplicable == 'Yes' && answer12B1 == 3) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = 'For question 12B1, please do not select NA since a case participant was selected as Mother and marked applicable for assessment in this item. ';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        vResult['Message'] = questionVal['Message'];

                        // Get the validation message component
                        var container = getCRSComponent('item12B1Answers', appPages.Wellbeing);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem12B1Answers', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                }                
                //
                // If question 12B3 is No, the following narrative field is required. 
                //
                if (answer12B3 == 2 && narrative12B3.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 12B3, please fill out the narrative field for a response of No.';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';

                    vResult['Message'] = questionVal['Message'];

                    // Get the validation message component
                    var container = getCRSComponent('item12BQuestion3Narrative', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem12BQuestion3Narrative', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 12B2 is No, the following narrative field is required. 
                //
                if (answer12B2 == 2 && narrative12B2.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 12B2, please fill out the narrative field for a response of No.';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    vResult['Message'] = questionVal['Message'];

                    // Get the validation message component
                    var container = getCRSComponent('item12BQuestion2Narrative', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem12BQuestion2Narrative', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If Father was selected on the applicability page, question 12B2 cannot be NA. 
                //
                if (result.length > 0) {

                    if (result[0].FatherApplicable == 'Yes' && answer12B2 == 3) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = 'For question 12B2, please do not select NA since a case participant was selected as Father and marked applicable for assessment in this item. ';
                        vResult['applicability'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        vResult['Message'] = questionVal['Message'];

                        // Get the validation message component
                        var container = getCRSComponent('item12B2Answers', appPages.Wellbeing);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem12B2Answers', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                }                
                //
                // If question 12B4 is No, the following narrative field is required. 
                //
                if (answer12B4 == 2 && narrative12B4.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 12B4, please fill out the narrative field for a response of No.';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    vResult['Message'] = questionVal['Message'];

                    // Get the validation message component
                    var container = getCRSComponent('item12BQuestion4Narrative', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem12BQuestion4Narrative', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
            }
            
            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 15;
            vResult['OutcomeCode'] = 5;

            result.push(vResult);

            if (input[0] == sr.Constants.AllFields) {

                validationResults['item12B'] = result;
            }

            var itemQuestions = getItemQuestions('item12B');
            itemQuestions[0].errorsExist = false;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus) {
                errorCount = 0;
            }

            if (errorCount > 0) {

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            return result;
        },
        validateItem12C: function (input) {
            var self = this;
            var result = [];
            var input = self.getValidationInput();
            var vResult = {};
            var applicabilityItems = {};
            var inputObj;
            var validateAllFields = false;
            var pageName = 'Wellbeing';
            var itemName = 'item12C';
            var questionVal = {};
            var noResponses = 0;
            var questions = getItemQuestions('item12C');
            var itemCode = 16;
            var outcomeCode = 5;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'wellbeing' };
            var errorCount = 0;

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.wellbeingViewModel)) {

                var vModel = createViewModel('wellbeing');

                window.wellbeingViewModel = vModel;
            }

            if (!Ext.isEmpty(window.wellbeingViewModel)) {

                viewModel = window.wellbeingViewModel.data;
                isViewModelValid = true;
            }

            Ext.each(input, function (columnName) {

                var store = Ext.data.StoreManager.lookup(self.getStoreId());
                                
                if (columnName == 'IsApplicable' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        // Reset all validation messages
                        resetValidationMessages(['item12CPanel', 'item12C1', 'item12C2']);

                        validateAllFields = true;
                    }

                    var validValues = [1, 2];

                    applicabilityItems['Source'] = store;
                    applicabilityItems['ValidValues'] = validValues;
                    applicabilityItems['PageName'] = pageName;
                    applicabilityItems['ItemName'] = itemName;
                    applicabilityItems['Message'] = 'Please select Yes or No.';
                    applicabilityItems['ItemCode'] = itemCode;
                    applicabilityItems['OutcomeCode'] = outcomeCode;

                    result = self.validateItemApplicability(applicabilityItems);
                    
                    if (!Ext.isEmpty(result[result.length - 1].CaseApplicable)) {

                        parms['ItemName'] = itemName;
                        parms['Question'] = 'Applicability';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }
                }
            });

            var wellBeingStore = Ext.data.ChainedStore.create({
                source: 'CR_WellBeing_CollectionStore'
            });

            var answer12C1;
            var answer12C2;            
            var narrative12C1;
            var narrative12C2;
            
            if (wellBeingStore.data.length > 0) {

                questionVal = {};

                answer12C1 = wellBeingStore.getAt(0).data.IsNeedsOfFosterParentsAdequatelyAssessed;
                answer12C1 = answer12C1 == 0 ? undefined : answer12C1;

                answer12C2 = wellBeingStore.getAt(0).data.IsFosterParentsProvidedAppropriateServices;
                answer12C2 = answer12C2 == 0 ? undefined : answer12C2;

                narrative12C1 = wellBeingStore.getAt(0).data.NeedsOfFosterParentsAdequatelyAssessedExplained;
                narrative12C2 = wellBeingStore.getAt(0).data.FosterParentsProvidedAppropriateServicesExplained;
                
                vResult['item12CQuestion1'] = answer12C1 == 1 ? 'Yes' : answer12C1 == 2 ? 'No' : answer12C1 == 3 ? 'NA' : undefined;                
                vResult['item12CQuestion2'] = answer12C2 == 1 ? 'Yes' : answer12C2 == 2 ? 'No' : answer12C2 == 3 ? 'NA' : undefined;
                
                //
                // If question 12C1 is No, the following narrative field is required. 
                //
                if (answer12C1 == 2 && narrative12C1.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 12C1, please fill out the narrative field for a response of No. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    vResult['Message'] = questionVal['Message'];

                    // Get the validation message component
                    var container = getCRSComponent('item12CQuestion1Narrative', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem12CQuestion1Narrative', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 12C2 is No, the following narrative field is required. 
                //
                if (answer12C2 == 2 && narrative12C2.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 12C2, please fill out the narrative field for a response of No.';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    vResult['Message'] = questionVal['Message'];

                    // Get the validation message component
                    var container = getCRSComponent('item12CQuestion2Narrative', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem12CQuestion2Narrative', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
            }

            if (!Ext.isEmpty(answer12C1)) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question12C1';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            if (!Ext.isEmpty(answer12C2)) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question12C2';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 16;
            vResult['OutcomeCode'] = 5;

            if (!self.isFosterCareCase()) {

                vResult['ItemStatus'] = 'Completed';
            }

            result.push(vResult);

            if (input[0] == sr.Constants.AllFields) {

                validationResults['item12C'] = result;
            }
            
            var itemQuestions = getItemQuestions('item12C');
            itemQuestions[0].errorsExist = false;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus) {
                errorCount = 0;
            }

            if (errorCount > 0) {

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            return result;
        },
        validateItem13: function (input) {
            var self = this;
            var result = [];
            var input = self.getValidationInput();
            var vResult = {};
            var applicabilityItems = {};
            var inputObj;
            var validateAllFields = false;
            var pageName = 'Wellbeing';
            var itemName = 'item13';
            var questionVal = {};
            var item;
            var columnVal;
            var preAppAnswers;
            var noResponses = 0;
            var questions = getItemQuestions('item13');
            var itemCode = 17;
            var outcomeCode = 5;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'wellbeing' };
            var errorCount = 0;

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.wellbeingViewModel)) {

                var vModel = createViewModel('wellbeing');

                window.wellbeingViewModel = vModel;
            }

            if (!Ext.isEmpty(window.wellbeingViewModel)) {

                viewModel = window.wellbeingViewModel.data;
                isViewModelValid = true;
            }

            viewModel = window.wellbeingViewModel.data;

            var caseParticipantStore = chainedStore('CR_CaseParticipant_CollectionStore');
            var itemParticipantStore = chainedStore('CR_ItemParticipant_CollectionStore');

            var mother = caseParticipantStore.data.items.filter(function (item) {
                return (item.data.RoleCode == 1);
            });

            var father = caseParticipantStore.data.items.filter(function (item) {
                return (item.data.RoleCode == 2);
            });

            var parms1 = { ItemCode: itemCode, OutcomeCode: outcomeCode };

            var participants = getParticipantsSelected(parms1);

            var motherSelected = participants.Mothers;
            var fatherSelected = participants.Fathers;

            Ext.each(input, function (columnName) {

                var store = Ext.data.StoreManager.lookup(self.getStoreId());
                //
                // All pre-applicability questions must be answered.
                //
                if (columnName == 'PreApplicability' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        // Reset all validation messages
                        resetValidationMessages(['item13Panel', 'item13A', 'item13B','item13C']);

                        validateAllFields = true;
                    }

                    questionVal = {};

                    var validValues = [{ itemId: 'item13Question1', codeDescriptionId: 73 },
                                       { itemId: 'item13Question2', codeDescriptionId: 74 },
                                       { itemId: 'item13Question3', codeDescriptionId: 75 },
                                       { itemId: 'item13Question4', codeDescriptionId: 292 },
                                       { itemId: 'item13Question5', codeDescriptionId: 76 },
                                       { itemId: 'item13Question6', codeDescriptionId: 77 },
                                       { itemId: 'item13Question7', codeDescriptionId: 78 }
                    ];

                    result = self.validateItemPreApplicability(store, validValues, 'Wellbeing', 'Item13', 'Please answer all questions on this page.');

                    if (result.length > 0) {

                        if (result[0].NoResponses == validValues.length) {

                            parms['ItemName'] = itemName;
                            parms['Question'] = 'PreApplicability';
                            parms['Answered'] = true;

                            updateQuestionsAnswered(parms);
                        }

                        if (!Ext.isEmpty(result[0].PreApplicability)) {

                            questionVal['PreApplicability'] = result[0].PreApplicability;

                        }
                        
                        var errors = result.filter(function (obj) {

                            return obj.messageType == 'Error';
                        });

                        if (errors.length > 0) {

                            // Get the validation message component
                            var container = getCRSComponent('item13PreApplicability', appPages.Wellbeing);

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgItem13PreApplicability', container);

                                msgComponent.setValidationResult(questionVal);
                                msgComponent.updateMessages();
                            }
                        }
                    }
                }
                //
                // Item applicability determination
                //
                if (columnName == 'IsApplicable' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        validateAllFields = true;
                    }

                    var validValues = [1, 2];

                    applicabilityItems['Source'] = store;
                    applicabilityItems['ValidValues'] = validValues;
                    applicabilityItems['PageName'] = pageName;
                    applicabilityItems['ItemName'] = itemName;
                    applicabilityItems['Message'] = 'Please select Yes or No.';
                    applicabilityItems['ItemCode'] = itemCode;
                    applicabilityItems['OutcomeCode'] = outcomeCode;
                    applicabilityItems['PreApplicability'] = result;

                    result = result.concat(self.validateItemApplicability(applicabilityItems));

                    preAppAnswers = result[0].Answers;

                    if (!Ext.isEmpty(result[result.length - 1].CaseApplicable)) {

                        parms['ItemName'] = itemName;
                        parms['Question'] = 'Applicability';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }
                    
                    if ((result[result.length - 1].MotherSelected) || (result[result.length - 1].FatherSelected)) {

                        parms['ItemName'] = itemName;
                        parms['Question'] = 'MotherOrFatherApplicable';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }
                }
            });

            var wellBeingStore = Ext.data.ChainedStore.create({
                source: 'CR_WellBeing_CollectionStore'
            });

            var answer13A;
            var answer13B;
            var answer13C;
            
            var narrative13A;
            var narrative13B;
            var narrative13C;
            
            if (wellBeingStore.data.length > 0) {

                questionVal = {};

                answer13A = wellBeingStore.getAt(0).data.IsAgencyConcertedEffortsToInvolveTheChild;
                answer13A = answer13A == 0 ? undefined : answer13A;

                if (!Ext.isEmpty(answer13A)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question13A';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                answer13B = wellBeingStore.getAt(0).data.IsAgencyConcertedEffortsToInvolveTheMother;
                answer13B = answer13B == 0 ? undefined : answer13B;

                if (!Ext.isEmpty(answer13B)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question13B';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                answer13C = wellBeingStore.getAt(0).data.IsAgencyConcertedEffortsToInvolveTheFather;
                answer13C = answer13C == 0 ? undefined : answer13C;

                if (!Ext.isEmpty(answer13C)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question13C';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (motherSelected.length > 0) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Mother';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);                    
                }

                if (fatherSelected.length > 0) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Father';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (motherSelected.length > 0 || fatherSelected.length > 0) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'MotherOrFatherApplicable';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                narrative13A = wellBeingStore.getAt(0).data.AgencyConcertedEffortsToInvolveTheChildExplained;
                narrative13B = wellBeingStore.getAt(0).data.AgencyConcertedEffortsToInvolveTheMotherExplained;
                narrative13C = wellBeingStore.getAt(0).data.AgencyConcertedEffortsToInvolveTheFatherExplained;

                vResult['item13QuestionA'] = answer13A == 1 ? 'Yes' : answer13A == 2 ? 'No' : answer13A == 3 ? 'NA' : undefined;
                vResult['item13QuestionB'] = answer13B == 1 ? 'Yes' : answer13B == 2 ? 'No' : answer13B == 3 ? 'NA' : undefined;
                vResult['item13QuestionC'] = answer13C == 1 ? 'Yes' : answer13C == 2 ? 'No' : answer13C == 3 ? 'NA' : undefined;
                //
                // If the first pre-applicability bullet is No, item 13 applicability is Yes, but no case participant is 
                // selected for either Mother or Father, question 13A cannot be NA. 
                //
                if (!(Ext.isEmpty(preAppAnswers))) {

                    if (preAppAnswers.item13Question1 == 2 && columnVal == 1 && mother.length == 0 && father.length == 0) {

                        if (answer13A == 3) {

                            questionVal = {};

                            if (vResult.rowNumber == undefined) {
                                vResult['page'] = pageName;
                            }

                            vResult['item'] = itemName;
                            questionVal['Message'] = 'When question 13A is NA and no case participants are included in this item as Mother or Father, item 13 is not applicable for assessment. Please return to the applicability page for item 13 and select No.';
                            vResult['applicability'] = questionVal['Message'];
                            vResult['messageType'] = 'Error';
                            errorCount++;

                            vResult['Message'] = questionVal['Message'];

                            // Get the validation message component
                            var container = getCRSComponent('question13AAnswers', appPages.Wellbeing);

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgQuestion13AAnswers', container);

                                msgComponent.setValidationResult(questionVal);
                                msgComponent.updateMessages();
                            }
                        }
                    }
                }                
                //
                // If question 13A is No, the following narrative field is required. 
                //
                if (answer13A == 2 && narrative13A.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 13A, please fill out the narrative field for a response of No.';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    vResult['Message'] = questionVal['Message'];

                    // Get the validation message component
                    var container = getCRSComponent('item13QuestionANarrative', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem13QuestionANarrative', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If a case participant was selected for Mother on the applicability page, question 13B cannot be NA. 
                //
                if (motherSelected.length > 0 && answer13B == 3) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 13B, please do not select NA since a case participant was selected as Mother and marked applicable for assessment in this item. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    vResult['Message'] = questionVal['Message'];

                    // Get the validation message component
                    var container = getCRSComponent('item13BAnswers', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem13BAnswers', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }                    
                }
                //
                // If question 13B is No, the following narrative field is required. 
                //
                if (answer13B == 2 && narrative13B.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 13B, please fill out the narrative field for a response of No.';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    vResult['Message'] = questionVal['Message'];

                    // Get the validation message component
                    var container = getCRSComponent('item13QuestionBNarrative', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem13QuestionBNarrative', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If a case participant was selected for Father on the applicability page, question 13C cannot be NA. 
                //
                if (fatherSelected.length > 0 && answer13C == 3) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 13C, please do not select NA since a case participant was selected as Father and marked applicable for assessment in this item. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    vResult['Message'] = questionVal['Message'];

                    // Get the validation message component
                    var container = getCRSComponent('item13CAnswers', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem13CAnswers', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 13C is No, the following narrative field is required. 
                //
                if (answer13C == 2 && narrative13C.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 13C, please fill out the narrative field for a response of No.';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    vResult['Message'] = questionVal['Message'];

                    // Get the validation message component
                    var container = getCRSComponent('item13QuestionCNarrative', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem13QuestionCNarrative', container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
            }

            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 17;
            vResult['OutcomeCode'] = 5;

            result.push(vResult);

            if (input[0] == sr.Constants.AllFields) {

                validationResults['item13'] = result;
            }

            var itemQuestions = getItemQuestions('item13');
            itemQuestions[0].errorsExist = false;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus) {
                errorCount = 0;
            }

            if (errorCount > 0) {

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            return result;
        },
        validateItem14: function (input) {
            var self = this;
            var result = [];
            var vResult = {};
            var applicabilityItems = {};
            var inputObj;
            var validateAllFields = false;
            var pageName = 'Wellbeing';
            var itemName = 'item14';
            var questionVal = {};
            var item;
            var answer14A;
            var answer14A1;
            var answer14B;
            var narrative14B;
            var noResponses = 0;
            var questions = getItemQuestions('item14');
            var itemCode = 18;
            var outcomeCode = 5;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'wellbeing' };
            var errorCount = 0;

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.wellbeingViewModel)) {

                var vModel = createViewModel('wellbeing');

                window.wellbeingViewModel = vModel;
            }

            if (!Ext.isEmpty(window.wellbeingViewModel)) {

                viewModel = window.wellbeingViewModel.data;
                isViewModelValid = true;
            }

            var wellBeingStore = Ext.data.ChainedStore.create({
                source: 'CR_WellBeing_CollectionStore'
            });

            // Reset all validation messages
            resetValidationMessages(['item14A', 'item14B']);

            if (wellBeingStore.data.length > 0) {

                answer14A = wellBeingStore.getAt(0).data.IsResponsiblePartyVisitationFrequencySufficient;
                answer14A = answer14A == 0 ? undefined : answer14A;

                if (!Ext.isEmpty(answer14A)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question14A';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                answer14A1 = wellBeingStore.getAt(0).data.ResponsiblePartyVisitationFrequencyCode;
                answer14A1 = answer14A1 == 0 ? undefined : answer14A1;

                if (!Ext.isEmpty(answer14A1)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question14A1';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                answer14B = wellBeingStore.getAt(0).data.IsResponsiblePartyVisitationQualitySufficient;
                answer14B = answer14B == 0 ? undefined : answer14B;

                if (!Ext.isEmpty(answer14B)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question14B';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                narrative14B = wellBeingStore.getAt(0).data.ResponsiblePartyVisitationQualityExplained;
                //
                // If question 14A1 is Never, question 14A must be No. 
                //
                if (answer14A1 == 7 && !(answer14A == 2)) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 14A, please select No since Never is selected in question 14A1. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    vResult['message'] = questionVal['Message'];

                    // Get the validation message component
                    var container = getCRSComponent('item14AAnswers', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem14AAnswers', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 14A1 is Never, question 14B must be NA. 
                //
                if (answer14A1 == 7 && !(answer14B == 3)) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 14B, please select NA since Never is selected in question 14A1. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    vResult['message'] = questionVal['Message'];

                    // Get the validation message component
                    var container = getCRSComponent('item14BAnswers', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem14BAnswers', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 14A is Yes, question 14B cannot be NA. 
                //
                if (answer14A == 1 && answer14B == 3) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 14B, please select Yes or No since Yes is selected in question 14A. ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    vResult['message'] = questionVal['Message'];

                    // Get the validation message component
                    var container = getCRSComponent('item14BAnswers', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem14BAnswers', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 14B is No, the following narrative field is required. 
                //
                if (answer14B == 2 && narrative14B.length == 0) {

                    questionVal = {};

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    vResult['item14QuestionB'] = answer14B == 1 ? 'Yes' : answer14B == 2 ? 'No' : answer14B == 3 ? 'NA' : undefined;
                    questionVal['Message'] = 'For question 14B, please fill out the narrative field for a response of No.  ';
                    vResult['applicability'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    vResult['message'] = questionVal['Message'];

                    // Get the validation message component
                    var container = getCRSComponent('item14QuestionBNarrative', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem14QuestionBNarrative', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }                    
                }
            }

            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 18;
            vResult['OutcomeCode'] = 5;

            result.push(vResult);

            if (input[0] == sr.Constants.AllFields) {

                validationResults['item14'] = result;
            }
                        
            var itemQuestions = getItemQuestions('item14');
            itemQuestions[0].errorsExist = false;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus) {
                errorCount = 0;
            }

            if (errorCount > 0) {

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            return result;
        },
        validateItem15: function (input) {
            var self = this;
            var result = [];
            var vResult = {};
            var applicabilityItems = {};
            var inputObj;
            var validateAllFields = false;
            var pageName = 'Wellbeing';
            var itemName = 'item15';
            var questionVal = {};
            var item;
            var columnVal;
            var preAppAnswers;
            var noResponses = 0;
            var questions = getItemQuestions('item15');
            var itemCode = 19;
            var outcomeCode = 5;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'wellbeing' };
            var errorCount = 0;

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.wellbeingViewModel)) {

                var vModel = createViewModel('wellbeing');

                window.wellbeingViewModel = vModel;
            }

            if (!Ext.isEmpty(window.wellbeingViewModel)) {

                viewModel = window.wellbeingViewModel.data;
                isViewModelValid = true;
            }

            item = getItem(19, getOutcomeCode(19));

            if (!Ext.isEmpty(item)) {

                columnVal = item.IsApplicable;
            }
           
            var caseParticipantStore = chainedStore('CR_CaseParticipant_CollectionStore');

            var mother = GetItemParticipant(1);
            var father = GetItemParticipant(2);

            var parms1 = { ItemCode: itemCode, OutcomeCode: outcomeCode };

            var participants = getParticipantsSelected(parms1);

            var motherSelected = participants.Mothers;
            var fatherSelected = participants.Fathers;

            Ext.each(input, function (columnName) {

                var store = Ext.data.StoreManager.lookup(self.getStoreId());
                //
                // All pre-applicability questions must be answered.
                //
                if (columnName == 'PreApplicability' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        // Reset all validation messages
                        resetValidationMessages(['item15Panel', 'item15A1', 'item15A2', 'item15B1', 'item15B2', 'item15B2Answers', 'item15C', 'item15D']);

                        validateAllFields = true;
                    }

                    questionVal = {};

                    var validValues = [{ itemId: 'item15Question1', codeDescriptionId: 79 },
                                       { itemId: 'item15Question2', codeDescriptionId: 80 },
                                       { itemId: 'item15Question3', codeDescriptionId: 293 },
                                       { itemId: 'item15Question4', codeDescriptionId: 81 },
                                       { itemId: 'item15Question5', codeDescriptionId: 82 },
                                       { itemId: 'item15Question6', codeDescriptionId: 83 },
                    ];

                    result = self.validateItemPreApplicability(store, validValues, 'Wellbeing', 'Item15', 'Please answer all questions on this page.');

                    if (result.length > 0) {

                        if (result[0].NoResponses == validValues.length) {

                            parms['ItemName'] = itemName;
                            parms['Question'] = 'PreApplicability';
                            parms['Answered'] = true;

                            updateQuestionsAnswered(parms);
                        }

                        if (!Ext.isEmpty(result[0].PreApplicability)) {

                            questionVal['PreApplicability'] = result[0].PreApplicability;

                        }
                        
                        var errors = result.filter(function (obj) {

                            return obj.messageType == 'Error';
                        });

                        if (errors.length > 0) {

                            // Get the validation message component
                            var container = getCRSComponent('item15PreApplicability', appPages.Wellbeing);

                            if (!(container == undefined)) {
                                var msgComponent = getCRSComponent('msgItem15PreApplicability', container);

                                msgComponent.setValidationResult(questionVal);
                                msgComponent.updateMessages();
                            }
                        }
                    }
                }
                //
                // Item applicability determination
                //
                if (columnName == 'IsApplicable' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        validateAllFields = true;
                    }

                    var validValues = [1, 2];

                    applicabilityItems['Source'] = store;
                    applicabilityItems['ValidValues'] = validValues;
                    applicabilityItems['PageName'] = pageName;
                    applicabilityItems['ItemName'] = itemName;
                    applicabilityItems['Message'] = 'Please select Yes or No.';
                    applicabilityItems['ItemCode'] = itemCode;
                    applicabilityItems['OutcomeCode'] = outcomeCode;
                    applicabilityItems['PreApplicability'] = result;

                    result = result.concat(self.validateItemApplicability(applicabilityItems));

                    preAppAnswers = result[0].Answers;

                    if (!Ext.isEmpty(result[result.length - 1].CaseApplicable)) {

                        parms['ItemName'] = itemName;
                        parms['Question'] = 'Applicability';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }

                    if ((result[result.length - 1].MotherSelected) || (result[result.length - 1].FatherSelected)) {
                        
                        parms['ItemName'] = itemName;
                        parms['Question'] = 'MotherOrFatherApplicable';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);                        
                    }
                }
            });

            var answer15A1;
            var answer15A2;
            var answer15B1;
            var answer15B2;
            var answer15C;
            var answer15D;

            var narrative15C;
            var narrative15D;

            var wellBeingStore = Ext.data.ChainedStore.create({
                source: 'CR_WellBeing_CollectionStore'
            });

            if (wellBeingStore.data.length > 0) {

                questionVal = {};

                answer15A1 = wellBeingStore.getAt(0).data.ResponsiblePartyVisitationFrequencyWithMotherCode;
                answer15A1 = answer15A1 == 0 ? undefined : answer15A1;

                if (!Ext.isEmpty(answer15A1)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question15A1';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                answer15A2 = wellBeingStore.getAt(0).data.IsResponsiblePartyVisitationFrequencyWithMotherSufficient;
                answer15A2 = answer15A2 == 0 ? undefined : answer15A2;

                if (!Ext.isEmpty(answer15A2)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question15A2';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                answer15B1 = wellBeingStore.getAt(0).data.ResponsiblePartyVisitationFrequencyWithFatherCode;
                answer15B1 = answer15B1 == 0 ? undefined : answer15B1;

                if (!Ext.isEmpty(answer15B1)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question15B1';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                answer15B2 = wellBeingStore.getAt(0).data.IsResponsiblePartyVisitationFrequencyWithFatherSufficient;
                answer15B2 = answer15B2 == 0 ? undefined : answer15B2;

                if (!Ext.isEmpty(answer15B2)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question15B2';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                answer15C = wellBeingStore.getAt(0).data.IsResponsiblePartyVisitationQualityWithMotherSufficient;
                answer15C = answer15C == 0 ? undefined : answer15C;

                if (!Ext.isEmpty(answer15C)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question15C';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                narrative15C = wellBeingStore.getAt(0).data.ResponsiblePartyVisitationQualityWithMotherExplained;
                answer15D = wellBeingStore.getAt(0).data.IsResponsiblePartyVisitationQualityWithFatherSufficient;
                answer15D = answer15D == 0 ? undefined : answer15D;

                if (!Ext.isEmpty(answer15D)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question15D';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (motherSelected.length > 0) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'MotherSelected';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (fatherSelected.length > 0) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'FatherSelected';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                if (fatherSelected.length > 0 || motherSelected.length > 0) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'MotherOrFatherApplicable';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                narrative15D = wellBeingStore.getAt(0).data.ResponsiblePartyVisitationQualityWithFatherExplained;

                vResult['item15QuestionC'] = answer15C == 1 ? 'Yes' : answer15C == 2 ? 'No' : answer15C == 3 ? 'NA' : undefined;
                vResult['item15QuestionD'] = answer15D == 1 ? 'Yes' : answer15D == 2 ? 'No' : answer15D == 3 ? 'NA' : undefined;
                //
                // If a case participant was selected for Mother on the applicability page, question 15A1 cannot be NA. 
                //
                if (motherSelected.length > 0 && answer15A1 == 1) {

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 15A1, please do not select NA since a case participant was selected as Mother and marked applicable for assessment in this item. ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item15A1', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem15A1', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If a case participant was selected for Mother on the applicability page, question 15A2 cannot be NA. 
                //
                if (motherSelected.length > 0 && answer15A2 == 3) {

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 15A2, please do not select NA since a case participant was selected as Mother and marked applicable for assessment in this item. ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item15A2Answers', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem15A2Answers', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 15A1 is NA, question 15A2 must be NA. 
                //
                if (answer15A1 == 1 && !(answer15A2 == 3)) {

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 15A2, please select NA since NA is selected in question 15A1. ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item15A2Answers', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem15A2Answers', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If a case participant was selected for Father on the applicability page, question 15B1 cannot be NA. 
                //
                if (fatherSelected.length > 0 && answer15B1 == 1) {

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 15B1, please do not select NA since a case participant was selected as Father and marked applicable for assessment in this item. ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item15B1', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem15B1', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If a case participant was selected for Father on the applicability page, question 15B2 cannot be NA. 
                //
                if (fatherSelected.length > 0 && answer15B2 == 3) {

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 15B2, please do not select NA since a case participant was selected as Father and marked applicable for assessment in this item. ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item15B2Answers', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem15B2Answers', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 15B1 is NA, question 15B2 must be NA. 
                //
                if (answer15B1 == 1 && !(answer15B2 == 3)) {

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 15B2, please select NA since NA is selected in question 15B1. ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item15B2Answers', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem15B2Answers', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 15A1 is NA, question 15C must be NA. 
                //
                if (answer15A1 == 1 && !(answer15C == 3)) {

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 15C, please select NA since NA is selected in question 15A1. ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item15CAnswers', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem15CAnswers', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 15A1 is Never, question 15C must be NA. 
                //
                if (answer15A1 == 7 && !(answer15C == 3)) {

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 15C, please select NA since Never is selected in question 15A1. ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item15CAnswers', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem15CAnswers', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 15C is No, the following narrative field is required. 
                //
                if (answer15C == 2 && narrative15C.length == 0) {

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 15C, please fill out the narrative field for a response of No.  ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item15QuestionCNarrative', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem15QuestionCNarrative', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 15B1 is NA, question 15D must be NA. 
                //
                if (answer15B1 == 1 && !(answer15D == 3)) {

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 15D, please select NA since NA is selected in question 15B1. ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item15D', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem15D', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 15B1 is Never, question 15D must be NA. 
                //
                if (answer15B1 == 7 && !(answer15D == 3)) {

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 15D, please select NA since Never is selected in question 15B1. ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item15D', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem15D', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If question 15D is No, the following narrative field is required. 
                //
                if (answer15D == 2 && narrative15D.length == 0) {

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 15D, please fill out the narrative field for a response of No.  ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item15QuestionDNarrative', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem15QuestionDNarrative', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }

            }

            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 19;
            vResult['OutcomeCode'] = 5;

            result.push(vResult);

            if (input[0] == sr.Constants.AllFields) {

                validationResults['item15'] = result;
            }

            var itemQuestions = getItemQuestions('item15');
            itemQuestions[0].errorsExist = false;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus) {
                errorCount = 0;
            }

            if (errorCount > 0) {

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            return result;
        },
        validateItem16: function (input) {
            var self = this;
            var result = [];
            var vResult = {};
            var applicabilityItems = {};
            var inputObj;
            var validateAllFields = false;
            var pageName = 'Wellbeing';
            var itemName = 'item16';
            var questionVal = {};
            var item;
            var columnVal;
            var noResponses = 0;
            var questions = getItemQuestions('item16');
            var itemCode = 20;
            var outcomeCode = 6;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'wellbeing' };
            var errorCount = 0;

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.wellbeingViewModel)) {

                var vModel = createViewModel('wellbeing');

                window.wellbeingViewModel = vModel;
            }

            if (!Ext.isEmpty(window.wellbeingViewModel)) {

                viewModel = window.wellbeingViewModel.data;
                isViewModelValid = true;
            }

            item = getItem(20, getOutcomeCode(20));

            if (!Ext.isEmpty(item)) {

                columnVal = item.IsApplicable;
            }

            var educationStore = chainedStore('CR_Education_CollectionStore');
            var wellbeingStore = chainedStore('CR_WellBeing_CollectionStore');
            
            // Reset all validation messages
            resetValidationMessages(['item16Panel','item16A1Panel']);

            //
            // Education Table Validations
            //
            if (educationStore.data.length > 0) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question16A1';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);

                Ext.each(educationStore.data.items, function (item) {
                    //
                    // Educational Needs is a required field. 
                    //                  
                    if (item.data.Needs.length == 0) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = 'You have not entered any educational needs. Please enter educational needs or enter None. ';
                        vResult['message'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('wellbeingPanel', appPages.Wellbeing);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem16A1', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                    //
                    // Services Provided is a required field. 
                    //                  
                    if (item.data.ServicesProvided.length == 0) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = 'You have not entered any services provided. Please enter services provided or enter None. ';
                        vResult['message'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('wellbeingPanel', appPages.Wellbeing);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem16A1', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                    //
                    // Services Needed But Not Provided is a required field. 
                    //                  
                    if (item.data.ServicesNeededNotProvided.length == 0) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = 'You have not entered any services needed but not provided. Please enter services needed but not provided or enter None. ';
                        vResult['message'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('wellbeingPanel', appPages.Wellbeing);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem16A1', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                });
            } else {

                if (item.IsApplicable == 1) {

                    var parms = {
                        questions: questions,
                        itemName: itemName,
                        msgComponent: getAppController().getMsgItem16A1(),
                        message: 'The education table is required since you indicated that this item is applicable.'
                    };

                    recalculateItemStatus(parms);
                }
            }
            
            var answer16A = wellbeingStore.getAt(0).data.IsAgencyAssessEducationNeeds;
            answer16A = answer16A == 0 ? undefined : answer16A;

            if (!Ext.isEmpty(answer16A)) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question16A';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer16B = wellbeingStore.getAt(0).data.IsAgencyAddressEducationNeeds;
            answer16B = answer16B == 0 ? undefined : answer16B;

            if (!Ext.isEmpty(answer16B)) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question16B';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            Ext.each(input, function (columnName) {

                var store = Ext.data.StoreManager.lookup(self.getStoreId());
                
                //
                // Item applicability determination
                //
                if (columnName == 'IsApplicable' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        validateAllFields = true;
                    }

                    var validValues = [1, 2];

                    applicabilityItems['Source'] = store;
                    applicabilityItems['ValidValues'] = validValues;
                    applicabilityItems['PageName'] = 'Wellbeing';
                    applicabilityItems['ItemName'] = 'item16';
                    applicabilityItems['Message'] = 'Please select Yes or No.';
                    applicabilityItems['ItemCode'] = itemCode;
                    applicabilityItems['OutcomeCode'] = outcomeCode;

                    result = self.validateItemApplicability(applicabilityItems);

                    if (!Ext.isEmpty(result[result.length - 1].CaseApplicable)) {

                        parms['ItemName'] = itemName;
                        parms['Question'] = 'Applicability';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }
                }
            });

            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 20;
            vResult['OutcomeCode'] = 6;

            result.push(vResult);

            if (input[0] == sr.Constants.AllFields) {

                validationResults['item16'] = result;
            }

            var itemQuestions = getItemQuestions('item16');
            itemQuestions[0].errorsExist = false;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus) {
                errorCount = 0;
            }

            if (errorCount > 0) {

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            return result;
        },
        validateItem17: function (input) {
            var self = this;
            var result = [];
            var vResult = {};
            var applicabilityItems = {};
            var inputObj;
            var validateAllFields = false;
            var pageName = 'Wellbeing';
            var itemName = 'item17';
            var questionVal = {};
            var item;
            var columnVal;
            var noResponses = 0;
            var questions = getItemQuestions('item17');
            var itemCode = 21;
            var outcomeCode = 7;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'wellbeing' };
            var errorCount = 0;

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.wellbeingViewModel)) {

                var vModel = createViewModel('wellbeing');

                window.wellbeingViewModel = vModel;
            }

            if (!Ext.isEmpty(window.wellbeingViewModel)) {

                viewModel = window.wellbeingViewModel.data;
                isViewModelValid = true;
            }

            item = getItem(21, getOutcomeCode(21));

            if (!Ext.isEmpty(item)) {

                columnVal = item.IsApplicable;
            }

            var healthStore = Ext.data.ChainedStore.create({
                source: 'CR_Health_CollectionStore',
                filters: [
                    function (record) {
                        return record.get('HealthNeedCode') == 1;
                    }
                ]
            });

            // Reset all validation messages
            resetValidationMessages(['item17Panel', 'item17A1']);

            //
            // Physical and Dental Health Table Validations
            //
            if (healthStore.data.length > 0) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question17A3';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);

                Ext.each(healthStore.data.items, function (item) {
                    //
                    // Identified Physical or Dental Health Needs is a required field. 
                    //                  
                    if (item.data.HealthNeeds.length == 0) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = 'You have not entered any identified physical or dental health needs. Please enter identified physical or dental health needs or enter None. ';
                        vResult['message'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('wellbeingPanel', appPages.Wellbeing);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem17A3', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                    //
                    // Services Provided is a required field. 
                    //                  
                    if (item.data.ServicesProvided.length == 0) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = 'You have not entered any services provided. Please enter services provided or enter None. ';
                        vResult['message'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('wellbeingPanel', appPages.Wellbeing);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem17A3', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                    //
                    // Services Needed But Not Provided is a required field. 
                    //                  
                    if (item.data.ServicesNeededNotProvided.length == 0) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = 'You have not entered any services needed but not provided. Please enter services needed but not provided or enter None. ';
                        vResult['message'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('wellbeingPanel', appPages.Wellbeing);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem17A3', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                });
            } else {
                
                if (item.IsApplicable == 1) {

                    var parms = {
                        questions: questions,
                        itemName: itemName,
                        msgComponent: getAppController().getMsgItem17A3(),
                        message: 'The physical and dental health table is required since you indicated that this item is applicable.'
                    };

                    recalculateItemStatus(parms);
                }
            }

            Ext.each(input, function (columnName) {

                var store = Ext.data.StoreManager.lookup(self.getStoreId());

                //
                // Item applicability determination
                //
                if (columnName == 'IsApplicable' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        validateAllFields = true;
                    }

                    var validValues = [1, 2];

                    applicabilityItems['Source'] = store;
                    applicabilityItems['ValidValues'] = validValues;
                    applicabilityItems['PageName'] = pageName;
                    applicabilityItems['ItemName'] = itemName;
                    applicabilityItems['Message'] = 'Please select Yes or No.';
                    applicabilityItems['ItemCode'] = itemCode;
                    applicabilityItems['OutcomeCode'] = outcomeCode;

                    result = self.validateItemApplicability(applicabilityItems);

                    if (!Ext.isEmpty(result[result.length - 1].CaseApplicable)) {

                        parms['ItemName'] = itemName;
                        parms['Question'] = 'Applicability';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }                    
                }
            });

            var answer17A1;
            var answer17A2;
            var caseType = getCaseType();

            var wellBeingStore = Ext.data.ChainedStore.create({
                source: 'CR_WellBeing_CollectionStore'
            });
                        
            if (wellBeingStore.data.length > 0) {

                questionVal = {};

                var answer17B1 = wellBeingStore.getAt(0).data.IsFosterOversightMedicationForPhysicalHealtyAppropriate;
                answer17B1 = answer17B1 == 0 ? undefined : answer17B1;

                if (!Ext.isEmpty(answer17B1)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question17B1';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                var answer17B2 = wellBeingStore.getAt(0).data.IsAppropriateSerivcesForAllPhysicalHealthNeeds;
                answer17B2 = answer17B2 == 0 ? undefined : answer17B2;

                if (!Ext.isEmpty(answer17B2)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question17B2';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                var answer17B3 = wellBeingStore.getAt(0).data.IsAppropriateServicesForAllDentalNeeds;
                answer17B3 = answer17B3 == 0 ? undefined : answer17B3;

                if (!Ext.isEmpty(answer17B3)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question17B3';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                answer17A1 = wellBeingStore.getAt(0).data.IsAgencyAssessPhysicalHealthNeeds;
                answer17A1 = answer17A1 == 0 ? undefined : answer17A1;

                if (!Ext.isEmpty(answer17A1)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question17A1';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                answer17A2 = wellBeingStore.getAt(0).data.IsAgencyAssessDentalHealthNeeds;
                answer17A2 = answer17A2 == 0 ? undefined : answer17A2;

                if (!Ext.isEmpty(answer17A2)) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question17A2';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                //
                // For foster care cases only, question 17A1 cannot be NA. 
                //
                if (caseType == 'Foster Case' && answer17A1 == 3) {

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 17A1, for foster care cases, please answer Yes or No. ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item17QuestionA1', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem17QuestionA1', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // For in-home cases only, since item 17 is only applicable if a child is selected 
                // for assessment, questions 17A1 and 17A2 cannot both be NA. 
                //
                if ((caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') && answer17A1 == 3 && answer17A2 == 3) {

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For questions 17A1 and 17A2, please answer Yes or No to at least one question since a child was selected as applicable for assessment in this item. ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item17QuestionA2', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem17QuestionA2', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // For foster care cases only, question 17A4 cannot be NA. 
                //
                var multiAnswerStore = self.getCheckBoxGroup('CR_MultiAnswer_CollectionStore', 'FosterFederalCaseManagamentCriteria');
                
                if (multiAnswerStore.length > 0) {

                    parms['ItemName'] = itemName;
                    parms['Question'] = 'Question17A4';
                    parms['Answered'] = true;

                    updateQuestionsAnswered(parms);
                }

                var answer17A4NA = multiAnswerStore.items.filter(function (item) {
                    return item.data.CodeDescriptionID == 178;
                });

                if (caseType == 'Foster Case' && answer17A4NA.length > 0) {

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 17A4, please do not select NA since this is a foster care case. ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item17QuestionA4', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem17QuestionA4', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
                //
                // If "No exceptions apply" is selected in question 17A4, no other selections can be made.  
                //
                var answer17A4NoEvidence = multiAnswerStore.items.filter(function (item) {
                    return item.data.CodeDescriptionID == 179;
                });

                if (answer17A4NoEvidence.length > 0 && multiAnswerStore.length > 1) {

                    if (vResult.rowNumber == undefined) {
                        vResult['page'] = pageName;
                    }

                    vResult['item'] = itemName;
                    questionVal['Message'] = 'For question 17A4, if you have selected "No evidence found", please ensure that no other selections were made. ';
                    vResult['message'] = questionVal['Message'];
                    vResult['messageType'] = 'Error';
                    errorCount++;

                    // Get the validation message component
                    var container = getCRSComponent('item17QuestionA4', appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent('msgItem17QuestionA4', container);

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.updateMessages();
                    }
                }
            }

            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 21;
            vResult['OutcomeCode'] = 7;

            result.push(vResult);

            if (input[0] == sr.Constants.AllFields) {

                validationResults['item17'] = result;
            }

            var itemQuestions = getItemQuestions('item17');
            itemQuestions[0].errorsExist = false;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus) {
                errorCount = 0;
            }

            if (errorCount > 0) {

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            return result;
        },
        validateItem18: function (input)
        {
            var self = this;
            var result = [];
            var vResult = {};
            var applicabilityItems = {};
            var inputObj;
            var validateAllFields = false;
            var pageName = 'Wellbeing';
            var itemName = 'item18';
            var questionVal = {};
            var item;
            var columnVal;
            var noResponses = 0;
            var questions = getItemQuestions('item18');
            var itemCode = 22;
            var outcomeCode = 7;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'permanency' };
            var errorCount = 0;

            var viewModel;
            var isViewModelValid = false;

            if (Ext.isEmpty(window.wellbeingViewModel)) {

                var vModel = createViewModel('wellbeing');

                window.wellbeingViewModel = vModel;
            }

            if (!Ext.isEmpty(window.wellbeingViewModel)) {

                viewModel = window.wellbeingViewModel.data;
                isViewModelValid = true;
            }

            item = getItem(22, getOutcomeCode(22));

            if (!Ext.isEmpty(item)) {

                columnVal = item.IsApplicable;
            }

            var healthStore = Ext.data.ChainedStore.create({
                source: 'CR_Health_CollectionStore',
                filters: [
                    function (record) {
                        return record.get('HealthNeedCode') == 2;
                    }
                ]
            });

            // Reset all validation messages
            resetValidationMessages(['item18Panel', 'item18A1Panel']);

            //
            // Mental/Behavioral Health Table Validations
            //
            if (healthStore.data.length > 0) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question18A1';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);

                Ext.each(healthStore.data.items, function (item) {
                    //
                    // Identified Mental/Behavioral Health Needs is a required field. 
                    //                  
                    if (item.data.HealthNeeds.length == 0) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = 'You have not entered any identified mental/behavioral health needs. Please enter identified mental/behavioral health needs or enter None. ';
                        vResult['message'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('wellbeingPanel', appPages.Wellbeing);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem18A1', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                    //
                    // Services Provided is a required field. 
                    //                  
                    if (item.data.ServicesProvided.length == 0) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = 'You have not entered any services needed but not provided. Please enter services needed but not provided or enter None. ';
                        vResult['message'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('wellbeingPanel', appPages.Wellbeing);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem18A1', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                    //
                    // Services Needed But Not Provided is a required field. 
                    //                  
                    if (item.data.ServicesNeededNotProvided.length == 0) {

                        questionVal = {};

                        if (vResult.rowNumber == undefined) {
                            vResult['page'] = pageName;
                        }

                        vResult['item'] = itemName;
                        questionVal['Message'] = 'You have not entered any services needed but not provided. Please enter services needed but not provided or enter None. ';
                        vResult['message'] = questionVal['Message'];
                        vResult['messageType'] = 'Error';
                        errorCount++;

                        // Get the validation message component
                        var container = getCRSComponent('wellbeingPanel', appPages.Wellbeing);

                        if (!(container == undefined)) {
                            var msgComponent = getCRSComponent('msgItem18A1', container);

                            msgComponent.setValidationResult(questionVal);
                            msgComponent.updateMessages();
                        }
                    }
                });
            } else {

                if (item.IsApplicable == 1) {

                    var parms = {
                        questions: questions,
                        itemName: itemName,
                        msgComponent: getAppController().getMsgItem18A1(),
                        message: 'The mental/behavioral health table is required since you indicated that this item is applicable.'
                    };

                    recalculateItemStatus(parms);
                }
            }

            var wellBeingStore = Ext.data.ChainedStore.create({
                source: 'CR_WellBeing_CollectionStore'
            });

            var answer18A = wellBeingStore.getAt(0).data.IsAgencyAssessMentalHealthNeeds;
            answer18A = answer18A == 0 ? undefined : answer18A;

            if (!Ext.isEmpty(answer18A)) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question18A';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer18B = wellBeingStore.getAt(0).data.IsFosterOversightMedicationForMentalHealtyAppropriate;
            answer18B = answer18B == 0 ? undefined : answer18B;
            var caseType = getCaseType();

            if (!Ext.isEmpty(answer18B) || (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health')) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question18B';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            var answer18C = wellBeingStore.getAt(0).data.IsAppropriateSerivcesForMentalHealthNeeds;
            answer18C = answer18C == 0 ? undefined : answer18C;
            var caseType = getCaseType();

            if (!Ext.isEmpty(answer18C) || (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health')) {

                parms['ItemName'] = itemName;
                parms['Question'] = 'Question18C';
                parms['Answered'] = true;

                updateQuestionsAnswered(parms);
            }

            Ext.each(input, function (columnName) {

                var store = Ext.data.StoreManager.lookup(self.getStoreId());

                //
                // Item applicability determination
                //
                if (columnName == 'IsApplicable' || columnName == sr.Constants.AllFields) {

                    if (columnName == sr.Constants.AllFields) {

                        validateAllFields = true;
                    }

                    var validValues = [1, 2];

                    applicabilityItems['Source'] = store;
                    applicabilityItems['ValidValues'] = validValues;
                    applicabilityItems['PageName'] = pageName;
                    applicabilityItems['ItemName'] = itemName;
                    applicabilityItems['Message'] = 'Please select Yes or No.';
                    applicabilityItems['ItemCode'] = itemCode;
                    applicabilityItems['OutcomeCode'] = outcomeCode;

                    result = self.validateItemApplicability(applicabilityItems);

                    if (!Ext.isEmpty(result[result.length - 1].CaseApplicable)) {

                        parms['ItemName'] = itemName;
                        parms['Question'] = 'Applicability';
                        parms['Answered'] = true;

                        updateQuestionsAnswered(parms);
                    }
                }
            });

            vResult['NoResponses'] = noResponses;
            vResult['ItemName'] = itemName;
            vResult['ItemCode'] = 22;
            vResult['OutcomeCode'] = 7;

            result.push(vResult);

            if (input[0] == sr.Constants.AllFields) {

                validationResults['item18'] = result;
            }

            var itemQuestions = getItemQuestions('item18');
            itemQuestions[0].errorsExist = false;

            var parms = { 'ItemName': itemName, 'ItemCode': vResult['ItemCode'] };
            var itemApplicabilityStatus = setItemNotApplicableComplete(parms);

            if (itemApplicabilityStatus) {
                errorCount = 0;
            }

            if (errorCount > 0) {

                if (itemQuestions.length > 0) {

                    itemQuestions[0].errorsExist = true;
                }
            }

            return result;
        },
        validateRating: function (input){
            var self = this;
            var result = [];
            var vResult = {};

            return result;
        },
        validateSafety: function () {
            var self = this;
            var vResult;
            var result;
            var input = self.getValidationInput();  
            
            if (Ext.isEmpty(self.getValidationRoutine())) {

                result = self.validateItem1(input);

                if (!Ext.isEmpty(result)) {

                    result = result.concat(self.validateItem2(input));

                    result = result.concat(self.validateItem3(input));

                    result = removeDuplicatesFromJsonArray(result);
                }
                
                return result;
            }
            
            if (self.getValidationRoutine() == 'ValidateItem1') {

                result = self.validateItem1(input);

                return result;
            }

            if (self.getValidationRoutine() == 'ValidateItem2') {

                result = self.validateItem2(input);

                return result;
            }

            if (self.getValidationRoutine() == 'ValidateItem3') {

                result = self.validateItem3(input);

                return result;
            }

            return result;
        },
        validatePermanency: function () {
            var self = this;
            var result;
            var vMethod = self.getValidationRoutine();

            var input = self.getValidationInput();

            if (Ext.isEmpty(vMethod)) {

                result = self.validateItem4(input);

                if (!Ext.isEmpty(result)) {

                    result = result.concat(self.validateItem5(input));

                    result = result.concat(self.validateItem6(input));

                    result = result.concat(self.validateItem7(input));

                    result = result.concat(self.validateItem8(input));

                    result = result.concat(self.validateItem9(input));

                    result = result.concat(self.validateItem10(input));

                    result = result.concat(self.validateItem11(input));

                    result = removeDuplicatesFromJsonArray(result);
                }
                                
                return result;
            } 

            if (self.getValidationRoutine() == 'ValidateItem4') {

                result = self.validateItem4(input);

                return result;
            }

            if (self.getValidationRoutine() == 'ValidateItem5') {

                result = self.validateItem5(input);

                return result;
            }

            if (self.getValidationRoutine() == 'ValidateItem6') {

                result = self.validateItem6(input);

                return result;
            }

            if (self.getValidationRoutine() == 'ValidateItem7') {

                result = self.validateItem7(input);

                return result;
            }

            if (self.getValidationRoutine() == 'ValidateItem8') {

                result = self.validateItem8(input);

                return result;
            }

            if (self.getValidationRoutine() == 'ValidateItem9') {

                result = self.validateItem9(input);

                return result;
            }

            if (self.getValidationRoutine() == 'ValidateItem10') {

                result = self.validateItem10(input);

                return result;
            }

            if (self.getValidationRoutine() == 'ValidateItem11') {

                result = self.validateItem11(input);

                return result;
            }

            return result;
        },
        validateWellbeing: function () {
            var self = this;
            var result;

            var input = self.getValidationInput();
            var vMethod = self.getValidationRoutine();

            if (Ext.isEmpty(vMethod)) {

                result = self.validateItem12(input);

                if (!Ext.isEmpty(result)) {

                    result = result.concat(self.validateItem13(input));

                    result = result.concat(self.validateItem14(input));

                    result = result.concat(self.validateItem15(input));

                    result = result.concat(self.validateItem16(input));

                    result = result.concat(self.validateItem17(input));

                    result = result.concat(self.validateItem18(input));

                    result = removeDuplicatesFromJsonArray(result);
                }
                
                return result;
            }

            if (self.getValidationRoutine() == 'ValidateItem12') {

                result = self.validateItem12(input);

                return result;
            }

            if (self.getValidationRoutine() == 'ValidateItem13') {

                result = self.validateItem13(input);

                return result;
            }

            if (self.getValidationRoutine() == 'ValidateItem14') {

                result = self.validateItem14(input);

                return result;
            }

            if (self.getValidationRoutine() == 'ValidateItem15') {

                result = self.validateItem15(input);

                return result;
            }

            if (self.getValidationRoutine() == 'ValidateItem16') {

                result = self.validateItem16(input);

                return result;
            }

            if (self.getValidationRoutine() == 'ValidateItem17') {

                result = self.validateItem17(input);

                return result;
            }

            if (self.getValidationRoutine() == 'ValidateItem18') {

                result = self.validateItem18(input);

                return result;
            }

            return result;
        },
        validateFields: function () {

            // Update fields
            this.evaluateFields();

            var rules = this.getValidationRules();

            // Evaluate validation rules
            Ext.each(rules, function (rule) {

                var variables = '';

                // Declare needed variables
                rule.fields.forEach(function (field) {
                    variables += 'var ' + field.fieldName + ' = ' + JSON.stringify(field) + ';';
                });

                variables += 'var result = false;';

                // Evaluate rule and determine result
                var ruleEval = variables + " if (" + rule.predicate + "){ result = true;} return result;";

                var func = new Function(ruleEval);

                rule.evalResult = func();
            });

            this.evalResult();
        },
        evalResult: function () {

            var rules = this.getValidationRules();
            var ruleCheckResult = '';
            var validityCheckResult = '';
            this.rulesEvalResult = false;

            // Evaluate rules
            Ext.each(rules, function (rule) {

                if (rule.rType == 'validityCheck') {
                    validityCheckResult += rule.evalResult + ' ' + (rule.joinChar == undefined ? '' : rule.joinChar);
                }

                if (rule.rType == 'ruleCheck') {
                    ruleCheckResult += rule.evalResult + ' ' + (rule.joinChar == undefined ? '' : rule.joinChar);
                }

            });

            // Get result for validity check
            var validityResult = false;
            var func;
            var variables = 'var result = false;';
            var rulesResult = variables + "if (" + validityCheckResult + "){ result = true;} return result;";

            if (validityCheckResult.trim().length > 0) {
                func = new Function(rulesResult);
                validityResult = func();
            }

            // Get result for rule check
            rulesResult = variables + "if (" + ruleCheckResult + "){ result = true;} return result;";

            if (ruleCheckResult.trim().length > 0) {
                func = new Function(rulesResult);
                ruleResult = func();
            }

            var evalResult = '{ "validityResult":' + validityResult + ', "ruleResult":' + ruleResult + '}';

            this.rulesEvalResult = JSON.parse(evalResult);
        },
        validationResult: undefined,
        columns: []
    },
    runValidationRules: function () {

        var result = [];

        if (this.getValidationType() == 'QANote') {
            result = this.validateQANote();

            this.setValidationResult(result);

            return result;
        }

        if (this.getValidationType() == 'RatingOverride') {
            result = this.validateRating();

            this.setValidationResult(result);

            return result;
        }

        if (this.getValidationType() == 'CaseElimination') {
            result = this.validateCaseElimination();

            this.setValidationResult(result);

            return result;
        }

        if (this.getValidationType() == 'CaseSetup') {
            result = this.validateCaseSetup();

            this.setValidationResult(result);

            return result;
        }

        if (this.getValidationType() == 'ChildTable') {
            result = this.validateChildTable();

            this.setValidationResult(result);

            return result;
        }

        if (this.getValidationType() == 'ParticipantTable') {
            result = this.validateParticipantTable();

            this.setValidationResult(result);

            return result;
        }

        if (this.getValidationType() == 'Facesheet') {
            result = this.validateFacesheet();

            this.setValidationResult(result);

            return result;
        }

        if (this.getValidationType() == 'Safety') {
            result = this.validateSafety();

            this.setValidationResult(result);

            return result;
        }

        if (this.getValidationType() == 'Permanency') {
            result = this.validatePermanency();

            this.setValidationResult(result);

            return result;
        }

        if (this.getValidationType() == 'Wellbeing') {
            result = this.validateWellbeing();

            this.setValidationResult(result);

            return result;
        }

        return result;
    },
    runItemValidationRules: function(itemCode){
        var result = [];
        var input = ['All'];
        var self = this;

        // Facesheet    
        if (itemCode == 23) {
            result = this.validateFacesheet();

            this.setValidationResult(result);

            return result;
        }

        // Safety items
        if (itemCode == 2) {
            result = self.validateItem1(input);

            this.setValidationResult(result);

            return result;
        }

        if (itemCode == 3) {
            result = self.validateItem2(input);

            this.setValidationResult(result);

            return result;
        }

        if (itemCode == 4) {
            result = self.validateItem3(input);

            this.setValidationResult(result);

            return result;
        }

        // Permanency items
        if (itemCode == 5) {
            result = self.validateItem4(input);

            this.setValidationResult(result);

            return result;
        }

        if (itemCode == 6) {
            result = self.validateItem5(input);

            this.setValidationResult(result);

            return result;
        }

        if (itemCode == 7) {
            result = self.validateItem6(input);

            this.setValidationResult(result);

            return result;
        }

        if (itemCode == 8) {
            result = self.validateItem7(input);

            this.setValidationResult(result);

            return result;
        }

        if (itemCode == 9) {
            result = self.validateItem8(input);

            this.setValidationResult(result);

            return result;
        }

        if (itemCode == 10) {
            result = self.validateItem9(input);

            this.setValidationResult(result);

            return result;
        }

        if (itemCode == 11) {
            result = self.validateItem10(input);

            this.setValidationResult(result);

            return result;
        }

        if (itemCode == 12) {
            result = self.validateItem11(input);

            this.setValidationResult(result);

            return result;
        }

        // Wellbeing items
        if (itemCode == 13) {
            result = self.validateItem12(input);

            this.setValidationResult(result);

            return result;
        }

        if (itemCode == 14) {
            result = self.validateItem12A(input);

            this.setValidationResult(result);

            return result;
        }

        if (itemCode == 15) {
            result = self.validateItem12B(input);

            this.setValidationResult(result);

            return result;
        }

        if (itemCode == 16) {
            result = self.validateItem12C(input);

            this.setValidationResult(result);

            return result;
        }

        if (itemCode == 17) {
            result = self.validateItem13(input);

            this.setValidationResult(result);

            return result;
        }

        if (itemCode == 18) {
            result = self.validateItem14(input);

            this.setValidationResult(result);

            return result;
        }

        if (itemCode == 19) {
            result = self.validateItem15(input);

            this.setValidationResult(result);

            return result;
        }

        if (itemCode == 20) {
            result = self.validateItem16(input);

            this.setValidationResult(result);

            return result;
        }

        if (itemCode == 21) {
            result = self.validateItem17(input);

            this.setValidationResult(result);

            return result;
        }

        if (itemCode == 22) {
            result = self.validateItem18(input);

            this.setValidationResult(result);

            return result;
        }

        return result;
    },
    checkforMotherFatherParticipants: function (parentComponent,motherComponent, fatherComponent, vResult) {

        var cpMotherStore = Ext.data.ChainedStore.create({
                source: 'CR_CaseParticipant_CollectionStore',
                filters: [
                    function (record) {
                        return record.get('RoleCode') == sr.ParticipantRole.Mother;
                    }
                ]
            });

            var cpFatherStore = Ext.data.ChainedStore.create({
                source: 'CR_CaseParticipant_CollectionStore',
                filters: [
                    function (record) {
                        return record.get('RoleCode') == sr.ParticipantRole.Father;
                    }
                ]
            });

            if (cpMotherStore.count() <= 0) {
                vResult['Message'] = 'There are no case participants in Face Sheet table G2 that can be assessed as Mother. ';
                
                    // Get the validation message component
                var container = getCRSComponent(parentComponent, appPages.Wellbeing);

                    if (!(container == undefined)) {
                        var msgComponent = getCRSComponent(motherComponent, container);

                        questionVal['Message'] = vResult['Message'];

                        msgComponent.setValidationResult(questionVal);
                        msgComponent.setMsgType('Info');
                        msgComponent.updateMessages();
                    }
            }

            if (cpFatherStore.count() <= 0) {
                vResult['Message'] = 'There are no case participants in Face Sheet table G2 that can be assessed as Father. ';
                
                // Get the validation message component
                var container = getCRSComponent(parentComponent, appPages.Wellbeing);

                if (!(container == undefined)) {
                    var msgComponent = getCRSComponent(fatherComponent, container);

                    questionVal['Message'] = vResult['Message'];

                    msgComponent.setValidationResult(questionVal);
                    msgComponent.setMsgType('Info');
                    msgComponent.updateMessages();
                }
            }

    },
    init: function (cmp) {

        this.setCmp(cmp);

        this.runValidationRules();
    }
});