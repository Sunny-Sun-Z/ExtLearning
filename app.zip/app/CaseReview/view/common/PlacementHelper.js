﻿Ext.define('App.CaseReview.view.common.PlacementHelper',
{
    extend: 'Ext.window.Window',
    itemId: 'placementHelper',
    title: 'Placement',
    width: 650,
    layout: 'vbox',

    onShow: function() {
        // Needed for EXT5
        this.callParent(arguments);
        this.center();
    },
    getDockedItems: function (selector, beforeBody) {
        var layout = this.getComponentLayout();
        if (layout.getDockedItems) {
            var dockedItems = layout.getDockedItems('render', beforeBody);
            if (selector && dockedItems.length) {
                dockedItems = Ext.ComponentQuery.query(selector, dockedItems);
            }
            return dockedItems;
        }
        else {
            return [];
        }
    },
    scrollable: true,
    shrinkWrap: true,
    modal: true,
    bodyStyle: 'background:#fff;',
    closeAction: 'destroy',
    items: [
    {
        xtype: 'form',
        itemId: 'placementHelperEdit',
        margin: 15,
        layout: 'vbox',
        border: false,
        items: [
        {
            xtype: 'datefield',
            flex: 1,
            allowBlank: false,
            msgTarget: 'side',
            blankText: 'You have not selected a placement date. Please select a placement date.',
            itemId: 'placementDate',
            fieldLabel: 'Placement Date',
            width: 300,
            maxLength: 20,
            labelWidth: 150,
            name: 'Date',
            maxValue: new Date(),
            minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30)
        },
        {
                xtype: 'combobox',
                allowBlank: false,
                msgTarget: 'side',
                blankText: 'You have not selected a placement type. Please select a placement type.',
                flex: 1,
                itemId: 'placementTypeCombo',
                fieldLabel: 'Placement Type',
                store: 'PlacementTypeStore',
                displayField: 'DescriptionLarge',
                valueField: 'GroupID',
                typeahead: true,
                editable: false,
                triggerAction: 'all',
                autoSelect: true,
                lastQuery: '',
                forceSelection: true,
                width: 450,
                labelWidth: 150,
                name: 'TypeCode',
                renderer: function (value) {
                    var lookupStore = chainedStore('PlacementType');
                    var results = lookupStore.query('GroupID', value, false, false, true);
                    if (results.length > 0) {
                        return results.getAt(0).data.DescriptionLarge;
                    }
                    return '';
                },
                listeners: {
                    change: function (combo, newValue, oldValue) {
                        if (newValue == 7) {// Other
                            Ext.ComponentQuery.query('#placementTypeOther')[0].allowBlank = false;
                            Ext.ComponentQuery.query('#placementTypeOther')[0].setDisabled(false);
                        } else {
                            Ext.ComponentQuery.query('#placementTypeOther')[0].allowBlank = true;
                            Ext.ComponentQuery.query('#placementTypeOther')[0].setDisabled(true);
                            Ext.ComponentQuery.query('#placementTypeOther')[0].setValue(null);
                        }
                    }
                }
        },
        {
            xtype: 'textarea',
            itemId: 'placementTypeOther',
            labelWidth: 150,
            width: 450,
            fieldLabel: 'Placement Type(Other)',
            name: 'TypeOther',
            maxLength: 100,
            enforceMaxLength : true,
            msgTarget: 'side',
            blankText: 'For Placement Type, please fill out the narrative field for a response of Other.',
            disabled : true

        },
        {
            xtype: 'combobox',
            allowBlank: false,
            msgTarget: 'side',
            blankText: 'Please enter a Reason for Change or indicate that this is the current placement.',
            flex: 1,
            itemId: 'reasonForChangeCombo',
            fieldLabel: 'Reason for Change in Placement Setting',
            store: 'PlacementChangeReasonStore',
            displayField: 'DescriptionLarge',
            valueField: 'GroupID',
            typeahead: true,
            triggerAction: 'all',
            editable: false,
            autoSelect: true,
            lastQuery: '',
            forceSelection: true,
            width: 450,
            labelWidth: 150,
            name: 'ChangeReasonCode',
            renderer: function (value) {
                var lookupStore = chainedStore('PlacementChangeReason');
                var results = lookupStore.query('GroupID', value, false, false, true);
                if (results.length > 0) {
                    return results.getAt(0).data.DescriptionLarge;
                }
                return '';
            },
            listeners: {
                    change: function (combo, newValue, oldValue) {
                        if (newValue == 8) {// Other
                            Ext.ComponentQuery.query('#changeReasonOther')[0].allowBlank = false;
                            Ext.ComponentQuery.query('#changeReasonOther')[0].setDisabled(false);
                        } else {
                            Ext.ComponentQuery.query('#changeReasonOther')[0].allowBlank = true;
                            Ext.ComponentQuery.query('#changeReasonOther')[0].setDisabled(true);
                            Ext.ComponentQuery.query('#changeReasonOther')[0].setValue(null);
                        }
                    }
            }
        },
        {
            xtype: 'textarea',
            itemId: 'changeReasonOther',
            labelWidth: 150,
            width : 450,
            fieldLabel: 'Change Reason(Other)',
            name: 'ChangeReasonOther',
            maxLength: 100,
            enforceMaxLength: true,
            msgTarget: 'side',
            blankText: 'For Reason for Change in Placement Setting, please fill out the narrative field for a response of Other.',
            disabled: true

        },

        {
                xtype: 'container',
                layout: 'hbox',
                items: [
                    {
                        xtype: 'button',
                        flex: 1,
                        align: 'right',
                        width: '100px',
                        text: 'Cancel',
                        itemId: 'unitCancel',
                        margin: '15 0 0 170',
                        padding: '5 5 5 5',
                        icon: window.baseUrl + '/content/icons/cross-small.png'
                    }, {
                        xtype: 'button',
                        flex: 1,
                        align: 'right',
                        style: 'float:right',
                        width: '150px',
                        text: 'Add/Update',
                        itemId: 'unitSave',
                        margin: '15 0 0 10',
                        padding: '5 5 5 5',
                        icon: window.baseUrl + '/content/icons/database_add.png'
                    }

                ]
            }]
    }
    ]

});