﻿Ext.define('App.CaseReview.view.common.itemStatus', {
    extend: 'Ext.form.field.Display',
    alias: 'widget.itemStatus',
    fieldLabel: '<span><strong>Status</strong></span>',
    labelWidth : 50,
    config: {
        itemCode: undefined,
        itemType: undefined,
        itemName: undefined,
        outcomeCode: undefined
    },
    calculateItemStatus: function(){
        
        var input = ['All'];
        var vCalculator = App.CaseReview.view.common.CRSValidationPlugin.create();

        vCalculator.setValidationInput(input);

        var result = vCalculator.runItemValidationRules(this.itemCode);
        var item = getItem(this.itemCode, getOutcomeCode(this.itemCode));

        var statusCode = Ext.isEmpty(item) ? 3 : Ext.isEmpty(item.StatusCode) ? 3 : item.StatusCode;

        return statusCode;
    },
    getCaseStatus: function () {

        var store = Ext.data.StoreManager.lookup('CaseReviewStore');
        var status;
        var statusCode = null;

        if (Ext.isEmpty(store)) {

            return status;
        }

        if (store.data.length > 0) {

            statusCode = store.data.items[0].data.CaseStatusCode;
        }

        var currentStatus = calculateCaseStatus();

        statusCode = Ext.isEmpty(statusCode) ? currentStatus : statusCode;

        var caseStatusStore = Ext.data.ChainedStore.create({
            source: 'CaseStatusStore',
            filters: [
                function (record) {
                    return record.data.GroupID == statusCode;
                }
            ]
        });

        status = caseStatusStore.data.length == 0 ? 'Invalid Status' : caseStatusStore.getAt(0).data.DescriptionLarge;

        return status;
    },
    getItemStatus: function () {

        var status;

        var item = getItem(this.itemCode, getOutcomeCode(this.itemCode));
        var caseType = getCaseType();

        if (!(caseType == 'Foster Case')) {

            if (this.itemCode == 5 || this.itemCode == 6 || this.itemCode == 7 || this.itemCode == 8 || this.itemCode == 9 || this.itemCode == 10 || this.itemCode == 11 || this.itemCode == 12) {

                return "Not Applicable";
            }
        }

        var statusCode = Ext.isEmpty(item) ? 3 : Ext.isEmpty(item.StatusCode) ? this.calculateItemStatus() : item.StatusCode;
        
        // This is temporary until the appropriate collection is built in c#
        status = statusCode == 1 ? 'Completed' :
                 statusCode == 2 ? 'In Progress' :
                 statusCode == 3 ? 'Not Started' :
                 statusCode == 4 ? 'Not Applicable' : 'Invalid Status';

        return status;
    },
    updateItemStatusDesc: function(status){

        this.setValue(status);
    },
    saveItemStatus: function(){

        var inputObj = { ItemCode: this.itemCode, OutcomeCode: this.outcomeCode, ItemName: this.itemName };

        updateItemNAStatus(inputObj);
    },
    renderer: function () {
        
        if (this.itemType == 'case') {

            return this.getCaseStatus();
        }

        return this.getItemStatus();
    },
    listeners: {
        
    }

});