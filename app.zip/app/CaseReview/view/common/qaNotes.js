﻿Ext.define('App.CaseReview.view.common.qaNotes', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.qaNotes',
    bodyCls: 'panel-background-color',
    margin: '0 20 20 20',
    scrollable: 'vertical',
    //collapsible: true,
    //collapsed: true,
    //title: '',
    //titleCollapse: true,
    maxHeight: 850,
    config: {
        reviewNotes: undefined,  //Passed in as array of reviewNote objects
        notesTitle: undefined,
        itemCode: undefined,
        itemId: undefined,
        noteItemId: undefined,
        outcomeCode: undefined,
        noteType: 'item',
        messages: [],
        removeNote: function (note) {

            this.remove(note);
        },
        getQANotes: function () {
            // Set the title

            var notes = [];
            var newNote;
            var noteResp;
            var responseItems;
            var itemCode = this.getItemCode();
            var outcomeCode = this.getOutcomeCode();

            // Add the notes. This is for development purposes only.
            if (itemCode === undefined) {
                notes = this.getReviewNotes();
            } else {
                // Get note collection for item
                var noteType = this.getNoteType();
                var noteColl = getNoteCollection(itemCode, noteType);
                var itemId = noteColl.length == 0 ? undefined : noteColl[0].ItemID;
                var iCode = itemId == undefined ? itemCode : itemId;
                var item = getItem(iCode, getOutcomeCode(iCode));

                if (Ext.isEmpty(item)) {

                    item = getItem(itemCode, getOutcomeCode(itemCode));
                }

                if (noteColl.length > 0) {
                    var cntr = 0;
                    var nItemId = itemCode == 0 ? undefined : item.ItemID;
                    var updatedItemId = getLatestItemId(itemCode, outcomeCode);

                    if (!(nItemId == updatedItemId)) {

                        if (!(Ext.isEmpty(updatedItemId))) {

                            nItemId = updatedItemId;
                        }
                    }

                    this.setNoteItemId(nItemId);

                    if (noteType == 'item') {

                        Ext.each(noteColl, function (note) {

                            cntr++;

                            if (!(Ext.isEmpty(note.Subject)) && (!Ext.isEmpty(note.Description))) {
                                var noteSpecs = { NoteObj: note, ItemCode: itemCode, NoteItemId: nItemId, NoteType: noteType, OutcomeCode: outcomeCode };

                                newNote = buildQANote(noteSpecs);

                                // Add note to notes array
                                if (!newNote.isDestroyed) {

                                    notes.push(newNote);
                                }
                            }
                        });
                    }

                    if (noteType == 'case') {

                        if (!Ext.isEmpty(qaNotesSummary)) {

                            var itemNotes = qaNotesSummary.notesCollection;

                            Ext.each(itemNotes, function (note) {

                                Ext.each(note.objValue, function (itemNote) {

                                    if (!itemNote.isDestroyed) {

                                        notes.push(itemNote);
                                    }
                                });
                            });
                        }
                    }
                }
            }

            return notes;
        },
        reloadNotes: function () {

            var notesContainer = this.query('[xtype=listPanel]')[0];

            if (Ext.isEmpty(notesContainer.container)) {

                return;
            }
            //
            // Update all notes
            //
            var currentNotes = notesContainer.container.component.query('[xtype=reviewNote]');

            Ext.each(currentNotes, function (currNote) {

                notesContainer.remove(currNote);
            });

            var updatedNotes = this.getQANotes();

            Ext.each(updatedNotes, function (note) {

                try {

                    notesContainer.add(note);

                } catch (err) {
                    var errObj = {};

                    errObj['ErrorObj'] = note;
                    errObj['MessageObj'] = err;

                    this.messages.push(errObj);
                }
            });
        }
    },
    listeners: {
        click: {
            element: 'el',
            fn: function (source, eOpts) {

                var winHeight = this.component.getHeight();
                var maxHeight = Ext.getBody().getViewSize().height;

                if (winHeight > maxHeight) {

                    this.component.maxHeight = Ext.getBody().getViewSize().height * 0.8;
                }
            }
        }
        //,
        //collapse: function (p) {
        //    p.setTitle(p.getNotesTitle() + '[SHOW]');
        //},
        //expand: function (p) {
        //    p.setTitle(p.getNotesTitle() + '[HIDE]');
        //}
    },
    items: [
        {
            xtype: 'listPanel',
            border: 'true',
            margin: '20 0 20 20',
            padding: '0 0 0 0',
            listeners: {
                beforerender: function () {

                    // Set the title
                    var self = this;
                    this.collapsed = true;

                    if (this.up().collapsed == false && this.up().itemId == 'caseNotes') {

                        this.collapsed = this.up().collapsed;
                    }

                    var collapsedText = this.collapsed ? ": [SHOW]</div>" : ": [HIDE]</div>";
                    var notesTitle = "<div class='html-content-header-margins'>" + this.up().getNotesTitle().trim() + collapsedText;
                    var container = this;
                    var itemCode = this.up().getItemCode();
                    var outcomeCode = this.up().getOutcomeCode();
                    var titleArr = this.up().getNotesTitle().trim().split(' ');

                    container.setTitle(notesTitle);

                    var notes = this.up().getQANotes();

                    Ext.each(notes, function (note) {

                        container.add(note);
                    });
                }
            },
            items: [
                {
                    xtype: 'container',
                    bodyCls: 'panel-background-color',
                    border: false,
                    margin: '0 10 20 10',
                    items: [
                        {
                            xtype: 'button',
                            icon: addButtonImage,
                            text: 'Create Note',
                            itemId: 'createNote',
                            margin: '0 0 0 10',
                            width: 110,
                            height: 25,
                            listeners: {
                                click: {
                                    element: 'el',
                                    fn: function () {
                                        // Get parent container
                                        var container = this.component.findParentByType('qaNotes');

                                        // Display and hide needed elements
                                        var notesContainer = container.queryById('notesContainer');

                                        notesContainer.show();
                                        container.queryById('createNoteButtons').show();
                                        container.queryById('createNote').hide();
                                    }
                                }
                            }
                        },
                        {
                            xtype: 'listPanel',
                            border: 'false',
                            padding: '0 0 0 10',
                            margin: '10 0 0 10',
                            componentCls: 'case-filter-link-style',
                            itemId: 'qaNotesFilter',
                            items: [
                                {
                                    xtype: 'container',
                                    border: false,
                                    margin: '20 0 0 20',
                                    bodyCls: 'panel-background-color',
                                    layout: 'hbox',
                                    items: [
                                        {
                                            xtype: 'combobox',
                                            itemId: 'resolvedStatus',
                                            fieldLabel: 'Resolved',
                                            labelAlign: 'left',
                                            labelWidth: 80,
                                            allowBlank: false,
                                            editable: true,
                                            store: resolvedOptions,
                                            queryMode: 'local',
                                            displayField: 'displayText',
                                            valueField: 'fldValue',
                                            emptyText: 'Any',
                                            forceSelection: true,
                                            width: 260,
                                            listeners: {
                                                select: function (combo, record, eOpts) {

                                                    // Get selection
                                                    var newValue = record.data.fldValue;
                                                    var selection = newValue == 0 ? 'Any' : newValue == 1 ? 'Yes' : newValue == 2 ? 'No' : 'Any';

                                                    qaNotesSummary.getSearchParms()['ResolvedStatus'] = selection;
                                                },
                                                change: function (inputElem, newValue, oldValue, eOpts) {

                                                    if (newValue == 'Any' && Ext.isEmpty(oldValue)) {

                                                        qaNotesSummary.getSearchParms()['ResolvedStatus'] = newValue;
                                                    }
                                                }
                                            }
                                        },
                                        {
                                            xtype: 'combobox',
                                            itemId: 'items',
                                            fieldLabel: 'Item',
                                            labelAlign: 'right',
                                            labelWidth: 80,
                                            allowBlank: false,
                                            disabled: false,
                                            editable: true,
                                            queryMode: 'local',
                                            displayField: 'itemName',
                                            valueField: 'fldValue',
                                            emptyText: 'Any',
                                            forceSelection: true,
                                            selectOnFocus: true,
                                            triggerAction: 'all',
                                            width: 260,
                                            store: itemNameList,
                                            listeners: {
                                                select: function (combo, record, eOpts) {

                                                    // Get selection
                                                    var newValue = record.data.itemName;

                                                    qaNotesSummary.getSearchParms()['Item'] = newValue;
                                                },
                                                change: function (inputElem, newValue, oldValue, eOpts) {

                                                    if (newValue == 'Any' && Ext.isEmpty(oldValue)) {

                                                        qaNotesSummary.getSearchParms()['Item'] = newValue;
                                                    }
                                                }
                                            }
                                        }
                                    ]
                                },
                                {
                                    xtype: 'container',
                                    border: false,
                                    margin: '20 0 0 20',
                                    bodyCls: 'panel-background-color',
                                    items: [
                                        {
                                            xtype: 'combobox',
                                            itemId: 'noteCreator',
                                            fieldLabel: 'Creator',
                                            labelAlign: 'left',
                                            labelWidth: 80,
                                            allowBlank: false,
                                            disabled: false,
                                            editable: true,
                                            queryMode: 'local',
                                            displayField: 'userName',
                                            valueField: 'fldValue',
                                            emptyText: 'Any',
                                            autoSelect: true,
                                            forceSelection: true,
                                            selectOnFocus: true,
                                            triggerAction: 'all',
                                            lastQuery: '',
                                            width: 260,
                                            store: userList,
                                            listeners: {
                                                afterrender: function () {

                                                    var usrStore = userStore();

                                                    if (!Ext.isEmpty(usrStore)) {

                                                        userList.setData(usrStore.getData());
                                                    }
                                                },
                                                select: function (combo, record, eOpts) {

                                                    // Get selection
                                                    var newValue = record.data.userName;

                                                    qaNotesSummary.getSearchParms()['User'] = newValue;
                                                },
                                                change: function (inputElem, newValue, oldValue, eOpts) {

                                                    if (newValue == 'Any' && Ext.isEmpty(oldValue)) {

                                                        qaNotesSummary.getSearchParms()['User'] = newValue;
                                                    }
                                                }
                                            }
                                        }
                                    ]
                                },
                                {
                                    xtype: 'container',
                                    border: false,
                                    margin: '20 0 0 20',
                                    bodyCls: 'panel-background-color',
                                    layout: 'hbox',
                                    margin: '30 0 0 350',
                                    items: [
                                        {
                                            xtype: 'button',
                                            text: "Reset",
                                            width: 80,
                                            height: 25,
                                            margin: '0 10 0 10',
                                            itemId: 'resetList',
                                            listeners: {
                                                click: {
                                                    element: 'el',
                                                    fn: function () {

                                                        var qaNotes = qaNotesSummary.reset();

                                                        // Reset display content
                                                        var container = this.component.findParentByType('qaNotes');
                                                        var notes = container.items.items[0];

                                                        Ext.each(notes.items.items, function (item) {

                                                            if (item.xtype == 'reviewNote') {

                                                                item.show();
                                                            }
                                                        });
                                                        //
                                                        // Reset filter
                                                        //
                                                        var notesFilter = getCRSComponent('qaNotesFilter');

                                                        // Update resolved statues filter Display
                                                        var resolvedList = notesFilter.down('#resolvedStatus');

                                                        // Update items filter Display
                                                        var itemList = notesFilter.down('#items');

                                                        // Update users filter Display
                                                        var userList = notesFilter.down('#noteCreator');
                                                    }
                                                }
                                            }
                                        },
                                        {
                                            xtype: 'button',
                                            text: "Search",
                                            width: 80,
                                            height: 25,
                                            margin: '0 10 0 10',
                                            itemId: 'searchList',
                                            listeners: {
                                                click: {
                                                    element: 'el',
                                                    fn: function () {

                                                        var qaNotes = qaNotesSummary.search();
                                                        var notesToRemove = [];

                                                        // Reset display content
                                                        var container = this.component.findParentByType('qaNotes');
                                                        var notes = container.items.items[0];

                                                        Ext.each(notes.items.items, function (item) {

                                                            if (item.xtype == 'reviewNote') {

                                                                item.show();
                                                            }
                                                        });

                                                        // Hide all item notes not needed  
                                                        var itemNotes = qaNotesSummary.notesCollection;
                                                        var keepNote = false;

                                                        if (!Ext.isEmpty(qaNotes)) {

                                                            if (qaNotes.length == 0) {

                                                                Ext.each(itemNotes, function (note) {

                                                                    Ext.each(note.objValue, function (itemNote) {

                                                                        itemNote.hide();
                                                                    });
                                                                });

                                                            } else {

                                                                Ext.each(itemNotes, function (note) {

                                                                    Ext.each(note.objValue, function (itemNote) {

                                                                        keepNote = false;

                                                                        Ext.each(qaNotes, function (noteObj) {

                                                                            Ext.each(noteObj.objValue, function (noteToKeep) {

                                                                                if (itemNote.id == noteToKeep.id) {

                                                                                    keepNote = true;
                                                                                }
                                                                            });

                                                                            if (keepNote) {

                                                                                itemNote.show();
                                                                            } else {

                                                                                itemNote.hide();
                                                                            }
                                                                        });
                                                                    });
                                                                });
                                                            }
                                                        } else {

                                                            Ext.each(itemNotes, function (note) {

                                                                Ext.each(note.objValue, function (itemNote) {

                                                                    itemNote.hide();
                                                                });
                                                            });
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    ]
                                }
                            ],
                            listeners: {
                                beforerender: function () {
                                    // Set the title
                                    var self = this;
                                    this.collapsed = true;
                                    this.hide();

                                    if (this.up().up().up().itemId == 'caseNotes') {

                                        this.show();
                                    }

                                    var collapsedText = this.collapsed ? ": [SHOW]</div>" : ": [HIDE]</div>";
                                    var filterTitle = "<div class='html-content-header-margins'>Filter QA Notes" + collapsedText;
                                    var container = this;

                                    container.setTitle(filterTitle);
                                }
                            }
                        },
                        {
                            xtype: 'container',
                            bodyCls: 'panel-background-color',
                            border: false,
                            margin: '0 10 20 0',
                            layout: 'hbox',
                            hidden: true,
                            //componentCls: 'hide-element',
                            itemId: 'createNoteButtons',
                            autoRender: true,
                            items: [
                                {
                                    xtype: 'button',
                                    text: "Cancel",
                                    width: 80,
                                    height: 25,
                                    margin: '0 10 0 10',
                                    itemId: 'cancelNote',
                                    listeners: {
                                        click: {
                                            element: 'el',
                                            fn: function () {
                                                // Get parent container
                                                var container = this.component.findParentByType('qaNotes');

                                                // Erase changes
                                                container.queryById('noteSubject').setValue('');
                                                container.queryById('noteComment').setValue('');

                                                // Display and hide needed elements
                                                container.queryById('notesContainer').hide();
                                                container.queryById('createNoteButtons').hide();
                                                container.queryById('createNote').show();
                                            }
                                        }
                                    }
                                },
                                {
                                    xtype: 'button',
                                    text: 'Save',
                                    width: 80,
                                    height: 25,
                                    margin: '0 10 0 0',
                                    itemId: 'saveNote',
                                    listeners: {
                                        click: {
                                            element: 'el',
                                            fn: function () {
                                                // Get parent container
                                                var me = this,
                                                    container = me.component.findParentByType('qaNotes'),
                                                    notes = container.items.items[0],
                                                    subjectField = container.queryById('noteSubject'),
                                                    subject = subjectField.getValue(),
                                                    commentField = container.queryById('noteComment'),
                                                    titleCharCounter=   container.queryById('titleCharCounter'),
                                                    commentCharCounter=  container.queryById('commentCharCounter'),
                                                    comment = commentField.getValue(),
                                                    subjectLen = subject.trim().length,
                                                    commentLen = comment.trim().length
                                                    loggedInUser = GetLoggedInUser(),
                                                    currentUser = loggedInUser.getFullname(),
                                                    nItemId = container.getNoteItemId(),
                                                    latestItemId = getLatestItemId(container.getItemCode(), container.getOutcomeCode())
                                                ;

                                                if (subjectLen == 0 || commentLen == 0) {

                                                    alert('Subject and Comments are required!');

                                                    return;
                                                }

                                                if (subjectLen > subjectField.maxLength) {

                                                    alert('Subject contains too many characters!');

                                                    return;
                                                }

                                                if (commentLen > commentField.maxLength) {

                                                    alert('Comments contain too many characters!');

                                                    return;
                                                }

                                                // Get current user
                                               
                                                if (loggedInUser.getCaseRole().length > 0) {
                                                    currentUser += ' (' + loggedInUser.getCaseRole() + ')';
                                                }                                          
                                               
                                                if (!(nItemId == latestItemId)) {

                                                    if (!Ext.isEmpty(latestItemId)) {

                                                        nItemId = latestItemId;
                                                    }
                                                }

                                                var newNote = App.CaseReview.view.common.reviewNote.create({
                                                    createDate: new Date(),
                                                    createBy: currentUser,
                                                    resolved: false,
                                                    subject: subject,
                                                    text: comment,
                                                    responseItems: undefined,
                                                    noteItemId: nItemId,
                                                    status: 'new',
                                                    noteType: container.getNoteType(),
                                                    outcomeCode: container.getOutcomeCode()
                                                });

                                                notes.add(newNote);

                                                // Erase changes
                                               
                                                subjectField.setValue('');
                                                titleCharCounter.setValue('<strong>No. of characters remaining: </strong> ' + subjectField.maxLength);
                                                                                                
                                                commentField.setValue('');
                                                commentCharCounter.setValue('<strong>No. of characters remaining: </strong> ' + commentField.maxLength);

                                                // Display and hide needed elements
                                                container.queryById('notesContainer').hide();
                                                container.queryById('createNoteButtons').hide();
                                                container.queryById('createNote').show();

                                                newNote.save();

                                                qaNotesContainer = container;
                                            }
                                        }
                                    }
                                }
                            ]
                        },
                        {
                            xtype: 'container',
                            margin: '10 20 0 0',
                            itemId: 'notesContainer',
                            hidden: true,
                            //componentCls: 'hide-element',
                            defaults: {
                                xtype: 'container',
                                layout: 'hbox'
                            },
                            autoRender: true,
                            items: [
                                {
                                    items: [
                                        {
                                            xtype: 'textfield',
                                            flex: 2,
                                            margin: '0 20 0 10',
                                            itemId: 'noteSubject',
                                            allowBlank: false,
                                            msgTarget: 'under',
                                            fieldLabel: '<strong>Subject:</strong>',
                                            maxLength: 200,
                                            listeners: {
                                                blur: function (inputElem, event, eOpts) {

                                                    var container = this.findParentByType('qaNotes');
                                                    var charsRemaining = inputElem.maxLength - inputElem.getValue().length;

                                                    container.queryById('titleCharCounter').setValue('<strong>No. of characters remaining: </strong>' + charsRemaining);
                                                }
                                            }
                                        },
                                        {
                                            xtype: 'displayfield',
                                            margin: '0 10 0 10',
                                            flex: 1,
                                            itemId: 'titleCharCounter',
                                            value: '<strong>No. of characters remaining: </strong> 200'
                                        }
                                    ]
                                },
                                {
                                    items: [
                                        {
                                            xtype: 'textarea',
                                            itemId: 'noteComment',
                                            flex: 2,
                                            margin: '0 20 0 10',
                                            allowBlank: false,
                                            msgTarget: 'under',
                                            fieldLabel: '<strong>Comments:</strong>',
                                            maxLength: 10000,
                                            grow: true,
                                            growMin: 75,
                                            growMax: 250,
                                            listeners: {
                                                blur: function (inputElem, event, eOpts) {

                                                    var container = this.findParentByType('qaNotes');
                                                    var charsRemaining = inputElem.maxLength - inputElem.getValue().length;

                                                    container.queryById('commentCharCounter').setValue('<strong>No. of characters remaining: </strong>' + charsRemaining);

                                                }
                                            }
                                        },
                                        {
                                            xtype: 'displayfield',
                                            margin: '0 10 0 10',
                                            flex: 1,
                                            itemId: 'commentCharCounter',
                                            value: '<strong>No. of characters remaining: </strong> 10000'
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    ]
});
