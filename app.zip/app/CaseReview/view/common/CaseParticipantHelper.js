﻿Ext.define('App.CaseReview.view.common.CaseParticipantHelper',
{
    extend: 'Ext.window.Window',
    itemId: 'caseParticipantHelper',
    title: 'Case Participant',
    width: 650,
    layout: 'vbox',
    onShow: function() {
        // Needed for EXT5
        this.callParent(arguments);
        this.center();
    },
    getDockedItems: function (selector, beforeBody) {
        var layout = this.getComponentLayout();
        if (layout.getDockedItems) {
            var dockedItems = layout.getDockedItems('render', beforeBody);
            if (selector && dockedItems.length) {
                dockedItems = Ext.ComponentQuery.query(selector, dockedItems);
            }
            return dockedItems;
        }
        else {
            return [];
        }
    },
    scrollable: true,
    shrinkWrap: true,
    modal: true,
    bodyStyle: 'background:#fff;',
    closeAction: 'destroy',
    items: [
    {
        xtype: 'form',
        itemId: 'caseParticipantHelperEdit',
        margin: 15,
        layout: 'vbox',
        border: false,
        items: [
        {
            xtype: 'textarea',
            flex: 1,
            allowBlank: false,
            msgTarget: 'side',
            blankText: 'Please specify the Participant\'s Name',
            itemId: 'participantsName',
            fieldLabel: 'Participant\'s Name',
            width: 450,
            maxLength: 100,
            enforceMaxLength: true,
            labelWidth: 150,
            name: 'Name'
        },
        {
                xtype: 'combobox',
                allowBlank: false,
                msgTarget: 'side',
                blankText: 'Please specify the Participant\'s Role.',
                //flex: 1,
                itemId: 'participantRoleCombo',
                fieldLabel: 'Participant\'s Role',
                store: 'ParticipantRoleStore',//GetParticipantRole(),
                displayField: 'DescriptionLarge',
                valueField: 'GroupID',
                forceSelection: true,
                editable: false,
                width: 450,
                labelWidth: 150,
                name: 'RoleCode',
                queryMode: 'local',
                //renderer: function (value) {
                //    var lookupStore = chainedStore('ParticipantRole');
                //    var results = lookupStore.query('GroupID', value, false, false, true);
                //    if (results.length > 0) {
                //        return results.getAt(0).data.DescriptionLarge;
                //    }
                //    return '';
                //},
                listeners: {
                        change: function (combo, newValue, oldValue) {
                            if (newValue == 6) {// Other
                                Ext.ComponentQuery.query('#participantsRoleOther')[0].allowBlank = false;
                                Ext.ComponentQuery.query('#participantsRoleOther')[0].setDisabled(false);
                            } else {
                                Ext.ComponentQuery.query('#participantsRoleOther')[0].allowBlank = true;
                                Ext.ComponentQuery.query('#participantsRoleOther')[0].setDisabled(true);
                                Ext.ComponentQuery.query('#participantsRoleOther')[0].setValue(null);
                            }
                        },
                        'beforerender': function () {
                            this.setStore(GetParticipantRole());
                        }

            }   
        },
        {
            xtype: 'textarea',
            itemId: 'participantsRoleOther',
            fieldLabel: 'Participant\'s  Role(Other)',
            labelWidth: 150,
            maxLength: 100,
            enforceMaxLength: true,
            width: 450,
            disabled : true,
            name: 'OtherRole',
            msgTarget: 'side',
            blankText: 'Please fill out the Participant\'s Role narrative field for a response of Other.'
        },
        {
            xtype: 'textarea',
            flex: 1,
            itemId: 'relationshipToChild',
            fieldLabel: 'Relationship to Child',
            width: 450,
            maxLength: 100,
            enforceMaxLength: true,
            labelWidth: 150,
            name: 'RelationshipToChild',
            allowBlank: false,
            msgTarget: 'side',
            blankText: 'Please specify the Relationship to Child.'
        },
        {
                xtype: 'checkbox',
                flex: 1,
                itemId: 'isParticipantInterviewed',
                fieldLabel: 'Is Interviewed',
                width: 450,
                maxLength: 1,
                labelWidth: 150,
                name: 'IsInterviewed',                
                inputValue: 1,
                uncheckedValue: 2,
                value : null
         },
        {
                xtype: 'container',
                layout: 'hbox',
                items: [
                    {
                        xtype: 'button',
                        flex: 1,
                        align: 'right',
                        width: '100px',
                        text: 'Cancel',
                        itemId: 'unitCancel',
                        margin: '15 0 0 170',
                        padding: '5 5 5 5',
                        icon: window.baseUrl + '/content/icons/cross-small.png'
                    }, {
                        xtype: 'button',
                        flex: 1,
                        align: 'right',
                        style: 'float:right',
                        width: '150px',
                        text: 'Add/Update',
                        itemId: 'unitSave',
                        margin: '15 0 0 10',
                        padding: '5 5 5 5',
                        icon: window.baseUrl + '/content/icons/database_add.png'
                    }

                ]
            }]
    }
    ]

});