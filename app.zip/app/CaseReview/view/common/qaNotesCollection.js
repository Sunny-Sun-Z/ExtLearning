﻿Ext.define('App.CaseReview.view.common.qaNotesCollection', {
    extend: 'Ext.Base',
    alias: 'widget.qaNotesCollection',
    config: {
        notesCollection: undefined,
        searchParms: undefined,
        deletedNotes:[]
    },
    init: function () {

        this.notesCollection = [];
        this.searchParms = {};
    },
    constructor: function () {

        this.init();
    },
    addNote: function (note) {
        
        this.notesCollection.push(note);
    },
    removeNote: function (noteObj) {

        Ext.each(this.notesCollection, function (note) {

            if(note.Name == noteObj.Name){

                Ext.each(note.objValue, function(obj){

                    if(obj.noteId == noteObj.noteId){

                        var objRemoved = note.objValue.remove(obj);

                        return false;
                    }
                });
            }
        });
    },
    updateNote: function (noteObj) {

        Ext.each(this.notesCollection, function (note) {

            if (note.Name == noteObj.Name) {

                Ext.each(note.objValue, function (obj) {

                    if (obj.noteId == noteObj.noteId) {

                        obj = noteObj.objValue;

                        return false;
                    }
                });
            }
        });        
    },
    filterByUser: function (userName, collection) {
        
        var result = [];
        var notesColl = collection == undefined ? this.notesCollection : collection;

        Ext.each(notesColl, function (note) {

            var selections = [];

            Ext.each(note.objValue, function (obj) {

                if (obj.createBy == userName || userName == 'Any') {

                    selections.push(obj);
                }
            });

            if (selections.length > 0) {

                var selection = { Name: note.Name, objValue: selections };

                result.push(selection);
            }
        });

        return result;
    },
    filterByResolvedStatus: function (status, collection) {

        var result = [];
        
        var notesColl = collection == undefined ? this.notesCollection : collection;

        Ext.each(notesColl, function (note) {

            var selections = [];

            Ext.each(note.objValue, function (obj) {

                var isResolved = obj.getResolved();
                var searchStatus = status == 'Yes' ? true : status == 'No' ? false : undefined;

                if (isResolved == searchStatus || Ext.isEmpty(searchStatus)) {

                    selections.push(obj);
                }
            });

            if (selections.length > 0) {

                var selection = { Name: note.Name, objValue: selections };

                result.push(selection);
            }
        });

        return result;
    },
    filterByItem: function (itemName, collection) {
        
        var result = [];
        var notesColl = collection == undefined ? this.notesCollection : collection;

        Ext.each(notesColl, function (note) {

            if (note.Name == itemName || itemName == 'Any') {

                result.push(note);
            }
        });

        return result;
    },
    reset: function () {
        
        this.searchParms = {};
        this.deletedNotes = [];

        return this.notesCollection;
    },
    search: function () {
        
        var result;
        
        if(Ext.isEmpty(this.searchParms.User)){

            this.searchParms.User = 'Any';
        }

        if (Ext.isEmpty(this.searchParms.Item)) {

            this.searchParms.Item = 'Any';
        }

        if (Ext.isEmpty(this.searchParms.ResolvedStatus)) {

            this.searchParms.ResolvedStatus = 'Any';
        }

        if (!Ext.isEmpty(this.searchParms.User)) {

            result = (result == undefined) ? this.filterByUser(this.searchParms.User) : this.filterByUser(this.searchParms.User, result);
        }

        if (!Ext.isEmpty(this.searchParms.Item)) {

            result = (result == undefined) ? this.filterByItem(this.searchParms.Item) : this.filterByItem(this.searchParms.Item, result);
        }

        if (!Ext.isEmpty(this.searchParms.ResolvedStatus)) {

            result = (result == undefined) ? this.filterByResolvedStatus(this.searchParms.ResolvedStatus) : this.filterByResolvedStatus(this.searchParms.ResolvedStatus, result);
        }

        return result;
    },
    getUsers: function () {

        var result = [];

        Ext.each(this.notesCollection, function (note) {

            var alreadySelected = false;

            Ext.each(note.objValue, function (obj) {

                Ext.each(result, function (user) {

                    if (user.userName == obj.createBy) {

                        alreadySelected = true;
                    }
                });

                if (!(alreadySelected)) {

                    var dataObj = { "userName": obj.createBy, "fldValue": obj.createBy };

                    result.push(dataObj);

                    alreadySelected = false;
                }                
            });
        });

        // Add a default value
        var dataObj = { "userName": "Any", "fldValue": "Any" };

        result.push(dataObj);

        // Sort in ascending order
        result.sort(orderBy('userName', 'asc'));

        return result;
    },
    getItems: function () {

        var result = [];

        Ext.each(this.notesCollection, function (note) {

            var alreadySelected = false;

            Ext.each(result, function (itemObj) {

                if (note.Name == itemObj.itemName) {

                    alreadySelected = true;
                }
            });

            if (!(alreadySelected)) {

                var dataObj = { "itemName": note.Name, "fldValue": note.Name };

                result.push(dataObj);

                alreadySelected = false;
            }
        });

        // Add a default value
        var dataObj = { "itemName": "Any", "fldValue": "Any" };

        result.push(dataObj);

        // Sort in ascending order
        result.sort(orderBy('itemName', 'asc'));

        return result;
    },
    getSearchParms: function () {

        return this.searchParms;
    }
});