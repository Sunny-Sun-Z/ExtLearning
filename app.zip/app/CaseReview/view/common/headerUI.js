﻿Ext.define('App.CaseReview.view.common.headerUI', {
    extend: 'Ext.form.FieldSet',
    alias: 'widget.headerUI',
    baseCls: 'x-fieldset fieldset-padding',
    border: false,
    resizable: false,
    items: [
            {
                xtype: 'panel',
                margin: 0,
                style: 'background: #e7f5fe none repeat scroll 0 0 !important;',
                bodyCls: 'maingridcolor',
                itemCls: 'case-summary',
                itemId: 'reviewHeader',
                border: false,  
                viewModel: {
                    type: 'caseReviewViewModel'
                },
                layout: {
                    type: 'table',
                    columns: 3,
                    tableAttrs: {
                        style: {
                            width: '100%',
                            margin: '20 20 20 20',
                            padding: '0px',
                            border: '0px'                            
                        }
                    }
                },
                defaults: {
                    labelWidth: '20%'
                },                
                items:
                [
                    {
                        xtype: 'displayfield',
                        fieldLabel: '<strong>Case ID</strong>',
                        bind: '{caseId}',
                        itemId: 'caseId'
                    },
                    {
                        xtype: 'displayfield',
                        fieldLabel: '<strong>Reviewer(s)</strong>',
                        bind: '{reviewers}'
                    },
                    {
                        xtype: 'displayfield',
                        fieldLabel: '<strong>Case Type</strong>',
                        bind: '{caseType}'
                    },
                    {
                        xtype: 'displayfield',
                        fieldLabel: '<strong>Case Name</strong>',
                        bind: '{caseName}',
                        itemId: 'caseName'
                    },
                    {
                        xtype: 'displayfield',
                        fieldLabel: '<strong>Initial QA</strong>',
                        bind: '{intialQAName}'
                    },
                    {
                        xtype: 'displayfield',
                        fieldLabel: '<strong>Period Under Review</strong>',
                        bind: '{reviewPeriod}'
                    },
                    {
                        xtype: 'displayfield',
                        fieldLabel: '<strong>Status</strong>',
                        itemId: 'caseStatus',
                        bind: '{caseStatus}'
                    },
                    {
                        xtype: 'displayfield',
                        fieldLabel: '<strong>Second Level QA</strong>',
                        bind: '{secondLevelQAName}'
                    },
                    {
                        xtype: 'displayfield',
                        fieldLabel: '<strong>Secondary Oversight</strong>',
                        bind: '{secondaryOversightName}'
                    },
                    {
                        xtype: 'displayfield',
                        fieldLabel: '<strong>State and County</strong>',
                        bind: '{siteName}'
                    },
                    {},
                    {
                        xtype: 'displayfield',
                        fieldLabel: '<strong>CT Secondary Oversight</strong>',
                        bind: '{ctSecondaryOversightName}'
                    },
                    {
                        xtype: 'component',
                        margin: '10 0 10 0',
                        padding: '0 0 0 0'
                    }
                ]
            }
        ]
});