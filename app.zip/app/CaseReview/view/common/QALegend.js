﻿Ext.define('App.CaseReview.view.common.QALegend', {
    extend: 'Ext.container.Container',
    alias: 'widget.qaLegend',
    border: true,
    layout: {
        type: 'column'
    },
    items: [
        {
            xtype: 'fieldset',
            items: [
                {
                    fieldLabel: 'Review',
                    name: 'review'
                },
                {
                    fieldLabel: 'QA',
                    name: 'qa'
                }
            ]
        }
    ]
});