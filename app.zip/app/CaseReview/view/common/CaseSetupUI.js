﻿Ext.define('App.CaseReview.view.common.CaseSetUpUI', {
    extend: Ext.panel.Panel.$className,
    alias: 'widget.caseSetupUI',
    baseCls: 'x-fieldset fieldset-padding',
    itemId : 'caseSetupUI',
    border: false,
    resizable: true,
    closeAction: 'hide',
    
initComponent: function () {
        var me = this;
        var sr = App.Common.StringResources;
        // these values keep us from having to type everything out
        // every time we want to put icons on the screen and makes it
        // easy to change their values in one place

        Ext.applyIf(me, {
            componentCls: 'panel-background-color',
            items: [
                {
                    xtype: 'form',
                    itemId: 'caseSetupForm',
                    flex: 1,
                    region: 'center',
                    width: '100%',
                    scrollable: 'vertical',
                    viewModel: {
                        type: 'caseReviewViewModel'
                    },
                    plugins: [
                        {
                            ptype: 'crsValidationPlugin',
                            pluginId: 'caseSetup',
                            validationType: 'CaseSetup',
                            validationInput: ['stateName', 'caseNamePanel', 'revStartDate',
                                              'reviewers', 'initialQAReviewer', 'secondQAReviewer', 'secondQAOversight',
                                              'reviewCompletedDate', 'caseType']
                        }
                    ],
                    items: [
                            {
                                xtype: 'panel',
                                margin: '0 20 20 20',                                
                                animCollapse: false,
                                bodyCls: 'panel-background-color',
                                border: true,
                                //defaults: {
                                //    bodyCls: 'panel-background-color',
                                //    border: false
                                //},
                                items:
                                [
                                    {
                                            xtype: 'panel',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout: 'hbox',
                                            margin: '20 20 20 40',
                                            items: [
                                                {
                                                    xtype: 'component',
                                                    width: 300,
                                                    html: '<strong>Case ID (<span style="color:red">*</span>)</strong>'
                                                },
                                                {
                                                    xtype: 'numberfield',
                                                    itemId: 'caseID',
                                                    bind: '{caseId}',
                                                    min: 0,                                                    
                                                    allowBlank: false,
                                                    max: 2147483647,
                                                    hideTrigger: true,
                                                    keyNavEnabled: false,
                                                    mouseWheelEnabled: false,
                                                    allowDecimals: false,
                                                    listeners: {
                                                        render: function (comp, eOpts) {

                                                            var parms = {};

                                                            parms['storeId'] = 'CaseReviewStore';
                                                            parms['propertyName'] = 'CaseID';

                                                            var result = getStorePropertyValue(parms);

                                                            if (Ext.isNumber(result)) {

                                                                this.setDisabled(true);
                                                            }
                                                        }
                                                    }
                                                }
                                            ]
                                        },
                                    {
                                        xtype: 'panel',
                                        title: "<div class='html-content-header-margins'>Definition and Instructions for Questions A through F below: [SHOW]</div>",
                                        baseCls: 'x-panel panel-background-list',
                                        collapsible: 'true',
                                        collapsed: true,
                                        titleCollapse: true,
                                        width: '95%',
                                        //flex: 1,
                                        margin: '20 0 20 20',
                                        padding: '0 0 0 0',
                                        defaults: {
                                            bodyStyle: 'border-top: 1px solid #DDD !important'
                                        },
                                        //html: "<div class='html-content-item-margins text-justify' style='border-top: 1px solid #DDD !important'>" +
                                        //               "<ul><li>For the local area, use the name that is used by the state for the review. This may be a region rather than a county, or may be multiple counties.</li>" +
                                        //               "<li>Enter the case name that is the official name on the case file.</li>" +
                                        //               "<li>The period under review is the time frame used for making decisions about the case. It begins with the sampling period start date and ends with the date the case review was completed.</li>" +
                                        //               "</ul></div>"
                                        items: [
                                            {
                                                html: "<div class='html-content-item-margins text-justify'>" +
                                                       "<ul><li>For the local area, use the name that is used by the state for the review. This may be a region rather than a county, or may be multiple counties.</li>" +
                                                       "<li>Enter the case name that is the official name on the case file.</li>" +
                                                       "<li>The period under review is the time frame used for making decisions about the case. It begins with the sampling period start date and ends with the date the case review was completed.</li>" +
                                                       "</ul></div>"
                                            }
                                        ]

                                    },
                                    {
                                        xtype: 'component',
                                        //bodyCls: 'panel-background-color',
                                        //border: false,
                                        margin: '15 0 0 20',
                                        html: "<p style='font-size:1.1em'>The answer to question A cannot be changed. To indicate a different site, please eliminate this case and create a new case.</p>"
                                    },
                                    //**********************************************************************
                                    // Question A
                                    //**********************************************************************
                                    //{
                                    //    xtype: 'component',
                                    //    bodyCls: 'panel-background-color',
                                    //    border: false,
                                    //    margin: '15 0 0 20',
                                    //    html: '<strong>A. Name of state and county (or local area):</strong>'
                                    //},
                                    {
                                        xtype: 'container',
                                        itemId: 'stateName',
                                        border: false,
                                        margin: '20 0 0 40',
                                        layout: 'hbox',
                                        bodyCls: 'panel-background-color',
                                        items: [
                                            {
                                                xtype: 'component',
                                                width: 300,
                                                html: '<strong>A. Name of state and county (or local area) <span style="color:red">*</span></strong>'
                                            },
                                            {
                                                xtype: 'combobox',                                                     
                                                store: 'SiteStore',
                                                displayField: 'DescriptionLarge',
                                                valueField: 'GroupID',
                                                itemId: 'state',
                                                editable: false,
                                                bind: '{siteCode}',
                                                width: '21%',
                                                allowBlank: false,
                                                listeners: {
                                                    render: function (comp, eOpts) {

                                                        var parms = {};

                                                        parms['storeId'] = 'CaseReviewStore';
                                                        parms['propertyName'] = 'SiteCode';

                                                        var result = getStorePropertyValue(parms);

                                                        if (!Ext.isEmpty(result)) {

                                                            this.setDisabled(true);
                                                        }
                                                    }
                                                }
                                            }
                                        ]
                                    },
                                    //**********************************************************************
                                    // Question B
                                    //**********************************************************************
                                    //{
                                    //    xtype: 'component',
                                    //    bodyCls: 'panel-background-color',
                                    //    border: false,
                                    //    margin: '15 0 0 20',
                                    //    html: '<strong>B. Case Name:</strong>'
                                    //},
                                    {
                                        xtype: 'panel',
                                        itemId: 'caseNamePanel',
                                        bodyCls: 'panel-background-color',
                                        border: false,
                                        layout: 'hbox',
                                        margin: '20 20 20 40',
                                        items: [
                                            {
                                                xtype: 'textfield',
                                                length: 300,
                                                fieldLabel: '<strong>B. Case Name</strong>',
                                                labelWidth: 295,
                                                width: '60%',
                                                labelSeparator: ' (<span style="color:red">*</span>)',
                                                allowBlank: false,
                                                itemId: 'CaseName',
                                                bind: '{caseName}',
                                            }
                                        ]
                                    },
                                    //**********************************************************************
                                    // Question C
                                    //**********************************************************************
                                    {
                                        xtype: 'component',
                                        bodyCls: 'panel-background-color',
                                        border: false,
                                        margin: '15 0 0 20',
                                        html: "<p style='font-size:1.1em'>The answer to question C cannot be changed. To indicate a different PUR start date, please eliminate this case and create <br>" + "a new case.</p>"
                                    },
                                    //{
                                    //    xtype: 'component',
                                    //    bodyCls: 'panel-background-color',
                                    //    border: false,
                                    //    margin: '15 0 0 20',
                                    //    html: '<strong>C. Period under review begins on:</strong>'
                                    //},
                                    {
                                        xtype: 'panel',
                                        itemId: 'revStartDate',
                                        bodyCls: 'panel-background-color',
                                        border: false,
                                        layout: 'hbox',
                                        margin: '20 20 20 40',
                                        items: [
                                            {
                                                xtype: 'component',
                                                width: 300,
                                                html: '<strong>C. Period under review begins on (<span style="color:red">*</span>)</strong>'
                                            },
                                            {
                                                xtype: 'datefield',
                                                length: 300,
                                                itemId: 'reviewBeginDate',
                                                bind: '{reviewStartDate}',
                                                width: '22%',
                                                allowBlank: false,
                                                maxValue: new Date(),
                                                //minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30),
                                                msgTarget: 'under',
                                                listeners: {
                                                    render: function (comp, eOpts) {

                                                        var parms = {};

                                                        parms['storeId'] = 'CaseReviewStore';
                                                        parms['propertyName'] = 'ReviewStartDate';

                                                        var result = new Date(getStorePropertyValue(parms));

                                                        if (Ext.isDate(result)) {

                                                            this.setDisabled(true);
                                                        }
                                                    }
                                                }
                                            }
                                        ]
                                    },
                                    //**********************************************************************
                                    // Question D
                                    //**********************************************************************
                                    {
                                        xtype: 'component',
                                        bodyCls: 'panel-background-color',
                                        border: false,
                                        margin: '15 0 0 20',
                                        html: '<strong>D. Review Participants:</strong></p>'
                                    },
                                    {
                                        xtype: 'component',
                                        bodyCls: 'panel-background-color',
                                        border: false,
                                        margin: '15 0 0 40',
                                        html: 'Please select up to 3 reviewers.</strong>'
                                    },
                                    {
                                        xtype: 'panel',
                                        itemId: 'reviewers',
                                        border: true,
                                        margin: '20 20 0 40',
                                        //bodyCls: 'panel-background-color',
                                        height: 300,
                                        weight: 250,
                                        scrollable: true,
                                        items: [
                                                {
                                                    xtype: 'boundcheckboxgroup',
                                                    columns: 5,
                                                    columnWidth: 200,
                                                    vertical: true,
                                                    store: 'CR_Reviewer_CollectionStore',
                                                    inputField: 'UserID',
                                                    itemId: 'reviewerCheckboxGroup',
                                                    listeners: {
                                                        'beforerender': function () {
                                                            Ext.log("beforerender");
                                                            var checkboxgroup = this;
                                                            var checkboxgroupStore = Ext.StoreManager.get('CaseReviewReviewersStore');
                                                           var checkbox = null;
                                                            for (var iCheckboxCount = 0; iCheckboxCount < checkboxgroupStore.count() ; iCheckboxCount++) {
                                                                checkbox = new Ext.form.Checkbox({
                                                                    boxLabel: checkboxgroupStore.getAt(iCheckboxCount).data.FirstName + " " + checkboxgroupStore.getAt(iCheckboxCount).data.LastName,
                                                                    inputValue: checkboxgroupStore.getAt(iCheckboxCount).data.UserID,
                                                                    itemId: 'checkbox' + iCheckboxCount,
                                                                    listeners:  {
                                                                            'change': function () {
                                                                                var checkbox = this;
                                                                                var checkboxGroup = Ext.ComponentQuery.query('#reviewerCheckboxGroup')[0];
                                                                                if (checkboxGroup.getChecked().length >3) {
                                                                                    alert("A max of 3 reviwers can be selected per case.");
                                                                                    checkbox.setValue(false);
                                                                                    return false;
                                                                                }
                                                                                return true;
                                                                            }
                                                                        }
                                                                });
                                                                checkboxgroup.items.add(checkbox);
                                                            }

                                                            
                                                    },
                                                        'afterrender' : function() {
                                                            this.store = 'CR_Reviewer_CollectionStore';
                                                        }
                                                    }

                                                }
                                        ]
                                    },
                                    //{
                                    //    xtype: 'component',
                                    //    bodyCls: 'panel-background-color',
                                    //    border: false,
                                    //    margin: '15 0 0 40',
                                    //    html: '<strong>Initial QA completed by (name):</strong>'
                                    //},
                                    {
                                        xtype: 'container',
                                        itemId: 'initialQAReviewer',
                                        border: false,
                                        margin: '20 0 0 40',
                                        bodyCls: 'panel-background-color',
                                        items: [
                                           {
                                               xtype: 'combo',
                                               itemId: 'intitalQA',
                                               //flex: 1,
                                               store: 'CaseReviewQAStore',
                                               valueField: 'UserID',
                                               displayField: 'LastName',
                                               autoSelect: true,
                                               fieldLabel: '<strong>Initial QA completed by (name)</strong>',
                                               labelWidth: 300,
                                               width: '60%',
                                               labelSeparator: ' <span style="color:red">*</span>',
                                               allowBlank: false,
                                               forceSelection: true,
                                               editable: false,                                               
                                               bind: '{intialQAId}',
                                               tpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '<div class="x-boundlist-item">{FirstName} {LastName}</div>', '</tpl>'),
                                               displayTpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '{FirstName} {LastName}', '</tpl>')
                                           }
                                        ]
                                    },
                                    //{
                                    //    xtype: 'component',
                                    //    bodyCls: 'panel-background-color',
                                    //    border: false,
                                    //    margin: '15 0 0 40',
                                    //    html: '<strong>Second Level QA completed by (name):</strong>'
                                    //},
                                    {
                                        xtype: 'container',
                                        itemId: 'secondQAReviewer',
                                        border: false,
                                        margin: '20 0 0 40',
                                        bodyCls: 'panel-background-color',
                                        items: [
                                              {
                                                  xtype: 'combo',
                                                  itemId: 'secondQA',
                                                  flex: 1,
                                                  store: 'CaseReviewQAStore',
                                                  valueField: 'UserID',
                                                  displayField: 'LastName',
                                                  autoSelect: true,
                                                  forceSelection: true,
                                                  editable: false,
                                                  fieldLabel: '<strong>Second Level QA completed by (name)</strong>',
                                                  labelWidth: 300,
                                                  width: '60%',
                                                  labelSeparator: ' <span style="color:red">*</span>',
                                                  allowBlank: false,
                                                  bind: '{secondLevelQAId}',
                                                  tpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '<div class="x-boundlist-item">{FirstName} {LastName}</div>', '</tpl>'),
                                                  displayTpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '{FirstName} {LastName}', '</tpl>')
                                              }
                                        ]
                                    },
                                    //{
                                    //    xtype: 'component',
                                    //    bodyCls: 'panel-background-color',
                                    //    border: false,
                                    //    margin: '15 0 0 40',
                                    //    html: '<strong>Secondary Oversight completed by (name):</strong>'
                                    //},
                                    {
                                        xtype: 'container',
                                        itemId: 'secondQAOversight',
                                        border: false,
                                        margin: '20 0 0 40',
                                        bodyCls: 'panel-background-color',
                                        items: [
                                              {
                                                  xtype: 'combo',
                                                  itemId: 'secondOversight',
                                                  flex: 1,
                                                  store: 'CaseReviewSecondaryOversightStore',
                                                  valueField: 'UserID',
                                                  displayField: 'LastName',
                                                  autoSelect: true,
                                                  forceSelection: true,
                                                  editable: false,
                                                  fieldLabel: '<strong>Secondary Oversight completed by (name)</strong>',
                                                  labelWidth: 300,
                                                  width: '60%',
                                                  labelSeparator: ' <span style="color:red">*</span>',
                                                  allowBlank: false,
                                                  bind: '{secondaryOversightId}',
                                                  tpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '<div class="x-boundlist-item">{FirstName} {LastName}</div>', '</tpl>'),
                                                  displayTpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '{FirstName} {LastName}', '</tpl>')
                                              }
                                        ]
                                    },
                                    //{
                                    //    xtype: 'component',
                                    //    bodyCls: 'panel-background-color',
                                    //    border: false,
                                    //    margin: '15 0 0 40',
                                    //    html: '<strong>Secondary CT Oversight completed by (name):</strong>'
                                    //},
                                    {
                                        xtype: 'container',
                                        itemId: 'secondCTQAOversight',
                                        border: false,
                                        margin: '20 0 0 40',
                                        bodyCls: 'panel-background-color',
                                        items: [
                                              {
                                                  xtype: 'combo',
                                                  itemId: 'secondCTOversight',
                                                  //flex: 1,
                                                  store: 'CaseReviewSecondaryOversightStore',
                                                  valueField: 'UserID',
                                                  displayField: 'LastName',
                                                  autoSelect: true,
                                                  forceSelection: true,
                                                  editable: false,
                                                  fieldLabel: '<strong>Secondary CT Oversight completed by (name)</strong>',
                                                  labelWidth: 300,
                                                  width: '60%',
                                                  bind: '{ctSecondaryOversightId}',
                                                  tpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '<div class="x-boundlist-item">{FirstName} {LastName}</div>', '</tpl>'),
                                                  displayTpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '{FirstName} {LastName}', '</tpl>')
                                              }
                                        ]
                                    },
                                    //**********************************************************************
                                    // Question E
                                    //**********************************************************************
                                    //{
                                    //    xtype: 'component',
                                    //    bodyCls: 'panel-background-color',
                                    //    border: false,
                                    //    margin: '15 0 0 20',
                                    //    html: '<strong>E. Date case review was completed:</strong>'
                                    //},
                                    {
                                        xtype: 'panel',
                                        itemId: 'reviewCompletedDate',
                                        bodyCls: 'panel-background-color',
                                        border: false,
                                        layout: 'hbox',
                                        margin: '20 20 20 20',
                                        items: [
                                            {
                                                xtype: 'datefield',
                                                itemId: 'reviewCompleted',
                                                bind: '{reviewCompletedDate}',
                                                fieldLabel: '<strong>E.    Date case review was completed</strong>',
                                                labelWidth: 320,
                                                width: '62%',
                                                labelSeparator: ' (<span style="color:red">*</span>)',
                                                allowBlank: false,
                                                msgTarget: 'under',
                                                maxValue: new Date()
                                                //minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30)
                                            }
                                        ]
                                    },
                                    //**********************************************************************
                                    // Question F Instructions
                                    //**********************************************************************
                                    {
                                        xtype: 'panel',
                                        title: "<div class='html-content-header-margins'>Question F Instructions: [SHOW]</div>",
                                        baseCls: 'x-panel panel-background-list',
                                        width: '95%',
                                        collapsible: 'true',
                                        collapsed: true,
                                        titleCollapse: true,
                                        margin: '20 20 20 20',
                                        padding: '0 0 0 0',
                                        defaults: {
                                            bodyStyle: 'border-top: 1px solid #DDD !important'
                                        },
                                        items: [
                                            {
                                                html: "<div class='html-content-item-margins text-justify'>" +
                                                       "<ul><li>The case is a foster care case if the target child was in foster care at any time during the period under review. A child is considered to be in foster care if the state child welfare agency or another public agency with whom the agency has a title IV-E agreement (hereafter 'the agency') has placement and care responsibility for the child. This includes a child who is placed by the agency with relatives or in other kin-type placements, but the agency maintains placement and care responsibility. It does not include a child who is living with relatives (or caregivers other than parents) but who is not under the placement and care responsibility of the agency.</li>" +
                                                       "<li>The case is an in-home services case if no child in the family was in foster care at any time during the period under review, and the case was open for at least 45 days.</li>" +
                                                       "<li>The case is an in-home services differential/alternative response case if the state has some form of differential/alternative response program during the period under review and the in-home services case was served through that program.</li>" +
                                                       "</ul></div>"
                                            }
                                        ]
                                    },
                                    {
                                        xtype: 'component',
                                        bodyCls: 'panel-background-color',
                                        border: false,
                                        margin: '15 0 0 20',
                                        html: "<p style='font-size:1.1em'>The answer to question F cannot be changed. To indicate a different case type, please eliminate this case and create <br>" + "a new case.</p>"
                                    },
                                    {
                                        xtype: 'component',
                                        bodyCls: 'panel-background-color',
                                        border: false,
                                        margin: '15 0 0 20',
                                        html: '<strong>F. What is the type of case reviewed:</strong>'
                                    },
                                    {
                                         xtype: 'container',
                                         itemId: 'caseType',
                                         layout: 'vbox',
                                         margin: '0 0 0 40',
                                         listeners: {
                                             render: function (comp, eOpts) {

                                                 var parms = {};

                                                 parms['storeId'] = 'CaseReviewStore';
                                                 parms['propertyName'] = 'ReviewSubTypeID';

                                                 var result = getStorePropertyValue(parms);

                                                 if (!Ext.isEmpty(result)) {

                                                     Ext.each(comp.items.items, function (radio) {

                                                         if (!(radio.inputValue == result)) {

                                                             radio.setDisabled(true);
                                                         }
                                                     });
                                                 }
                                             }
                                         },
                                         items: [
                                             {
                                                 xtype: 'radio',
                                                 boxLabel: 'In-Home Services',
                                                 bind: '{reviewSubTypeId}',
                                                 itemId: 'reviewSubType1',
                                                 inputValue: 19,
                                                 readOnly : true

                                             },
                                             {
                                                 xtype: 'radio',
                                                 boxLabel: 'Foster Care',
                                                 bind: '{reviewSubTypeId}',
                                                 itemId: 'reviewSubType2',
                                                 inputValue: 20,
                                                 readOnly: true
                                             },
                                             {
                                                 xtype: 'radio',
                                                 boxLabel: 'In-Home Services – DR/AR ',
                                                 bind: '{reviewSubTypeId}',
                                                 itemId: 'reviewSubType3',
                                                 inputValue: 21,
                                                 readOnly: true
                                             }
                                         ]
                                    },
                                    //**********************************************************************
                                    // PIP Monitored Instructions
                                    //**********************************************************************
                                    {
                                        xtype: 'panel',
                                        title: "<div class='html-content-header-margins'>PIP Monitored Instructions: [SHOW]</div>",
                                        baseCls: 'x-panel panel-background-list',
                                        //flex: 1,
                                        width: '95%',
                                        collapsible: 'true',
                                        collapsed: true,
                                        titleCollapse: true,
                                        margin: '20 20 20 20',
                                        padding: '0 0 0 0',
                                        defaults: {
                                            bodyStyle: 'border-top: 1px solid #DDD !important'
                                        },
                                        items: [
                                            {
                                                html: "<div class='html-content-item-margins text-justify'>" +
                                                    "Cases can be marked as \"PIP Monitored\" at case creation by selecting the checkbox below. " +
                                                    "Only check this box for a case that has been identified in advance as a case being used for PIP monitoring purposes. " +
                                                    "Once the Case Setup page is saved and the case is created, the \"PIP Monitored\" checkbox cannot be changed by the state user " +
                                                    "and can only be changed by contacting the CWRP Help Desk. " +
                                                    "Marking a case as \"PIP Monitored\" allows the case to be filtered as such on the Cases page and in the reports.</div>"
                                            }
                                        ]
                                    },
                                    {
                                        xtype: 'radiogroup',
                                        bodyCls: 'panel-background-color',
                                        border: false,
                                        layout: 'hbox',
                                        margin: '0 0 0 20',
                                        listeners: {
                                            render: function (comp, eOpts) {

                                                var parms = {};

                                                parms['storeId'] = 'CaseReviewStore';
                                                parms['propertyName'] = 'IsPIPMonitored';

                                                var result = getStorePropertyValue(parms);

                                                if (!Ext.isEmpty(result)) {

                                                    Ext.each(comp.items.items, function (item) {

                                                        if (item.isRadio) {

                                                            if (!(item.inputValue == result)) {

                                                                item.setDisabled(true);
                                                            }
                                                        }
                                                    });
                                                }
                                            }
                                        },
                                        items: [
                                            {
                                                xtype: 'displayfield',
                                                fieldLabel: '<strong>PIP Monitored (<span style="color:red">*</span>)</strong>',
                                                labelWidth: 310
                                            },
                                            {
                                                boxLabel: '<b>Yes</b>',
                                                itemId: 'pipMonitoredYes',
                                                inputValue: 1,
                                                bind: '{pipMonitored}'
                                            },
                                            {
                                                margin: '0 0 0 10',
                                                boxLabel: '<b>No</b>',
                                                itemId: 'pipMonitoredNo',
                                                inputValue: 2,
                                                bind: '{pipMonitored}'
                                            }
                                        ]
                                    }
                                ]
                            }
                    ]
                }
                //{
                //    //*****************************************************
                //    // Case Setup [Save and Cancel buttons]
                //    //*****************************************************
                //    xtype: 'container',
                //    margin: '10 20 10 0',
                //    border: false,
                //    layout:
                //        {
                //            type: 'table',
                //            columns: 3
                //        },
                //    cls: 'panel-background-color align-right',
                //    items: [
                //        {
                //            //CANCEL BUTTON
                //            xtype: 'button',
                //            baseCls: 'x-btn borderless-button-style',
                //            margin: '0 10 0 0',
                //            text: 'Cancel',
                //            itemId: 'caseSetupCancel',
                //            scale: 'medium',
                //            handler: function () {
                                
                //                this.up('.window').close();
                //            }
                //        },
                //        {
                //            //SAVE BUTTON
                //            xtype: 'button',
                //            baseCls: 'x-btn borderless-button-style',
                //            margin: '0 20 0 0',
                //            itemId: 'caseSetupSave',
                //            text: "Save",
                //            scale: 'medium',
                //            handler: function () {
                //                // Enable all tabs
                //                var parentPanel = Ext.ComponentQuery.query('#overviewTab')[0].up('#centerTabPanel');
                //                var children = parentPanel.query()[0];

                //                Ext.each(children, function (tab) {

                //                    tab.setDisabled(false);

                //                });

                //                return false;

                //            }
                //        }
                //    ]
                //}
            ]
        });

        me.callParent(arguments);
    }
});