﻿//
// This is the click event handler for the safety page
//
var processItem1YesChange = function (radio) {

    var controller = getAppController();

    var valueChanged = radio.isDirty();

    if (!valueChanged) {

        return;
    }

    var newValue = radio.getValue();

    if (pageLoadStatus['Safety'] == 'rendered') {

        if (newValue) {

            var optionalComments = getAppController().getItem1ApplicableComments();
            optionalComments.enable();

            var item = getItem(2, 1);

            if (!(item == undefined)) {

                item.IsApplicable = 1;
                updateItem(item);
            }

            // Enable section for Item 1
            enableContainerItems(['safetyReportGrid']);

            var vmFields = [];
            var vmField = { 'item1Applicable': 1 };

            vmFields.push(vmField);

            var parms = {
                control: radio,
                runValidations: true,
                dataChanged: true,
                vmFields: vmFields
            };

            parms = getStatusParms(parms, 'safetyItem1Rating');
            
            initValidations('Item1');

            runSafetyRules(controller, 'ValidateItem1', 'ValidateItem1', parms);
        }
    }
}
var processItem1NoChange = function (radio) {

    var controller = getAppController();

    var valueChanged = radio.isDirty();

    if (!valueChanged) {

        return;
    }

    var newValue = radio.getValue();

    if (pageLoadStatus['Safety'] == 'rendered') {

        if (newValue) {

            var optionalComments = getAppController().getItem1ApplicableComments();
            optionalComments.enable();

            var item = getItem(2, 1);

            if (!(item == undefined)) {

                item.IsApplicable = 2;
                updateItem(item);
            }

            // Disable section for Item 1
            disableContainerItems(['safetyReportGrid', 'item1Questions']);

            setDisabledFieldValuesInContainer(['safetyReportGrid', 'item1Questions']);

            // Update Grid Layout
            var reportGrid = getAppController().getSafetyReportGrid();

            reportGrid.getView().refresh();

            var vmFields = [];
            var vmField = { 'item1Applicable': 2 };

            vmFields.push(vmField);

            var parms = {
                control: radio,
                runValidations: true,
                dataChanged: true,
                vmFields: vmFields,
                ratingDefault: 'NA'
            };

            parms = getStatusParms(parms, 'safetyItem1Rating');

            initValidations('Item1');

            runSafetyRules(controller, 'ValidateItem1', 'ValidateItem1', parms);
        }
    }
}
var processItem1CChange = function (radio) {

    var controller = getAppController();

    var valueChanged = radio.isDirty();

    if (!valueChanged) {

        return;
    }

    var newValue = radio.getValue();

    if (pageLoadStatus['Safety'] == 'rendered') {

        if (newValue) {

            resetRadioButton(radio);

            var safetyStore = chainedStore('CR_Safety_CollectionStore');
            var isDelayControllable = radio.inputValue;
            safetyStore.getAt(0).data.IsDelayBeyondAgencyControl = isDelayControllable;

            var vmFields = [];
            var vmField = { 'isDelayBeyondAgencyControl': isDelayControllable };

            vmFields.push(vmField);

            var parms = {
                control: radio,
                runValidations: true,
                dataChanged: true,
                vmFields: vmFields
            };

            parms = getStatusParms(parms, 'safetyItem1Rating');

            initValidations('Item1');

            runSafetyRules(controller, 'ValidateItem1', 'ValidateItem1', parms);
        }
    }
}
var processItem1CYesChange = function (radio) {

    var controller = getAppController();

    var valueChanged = radio.isDirty();

    if (!valueChanged) {

        return;
    }

    var newValue = radio.getValue();

    if (pageLoadStatus['Safety'] == 'rendered') {

        if (newValue) {

            resetRadioButton(radio);

            var safetyStore = chainedStore('CR_Safety_CollectionStore');
            var isDelayControllable = radio.inputValue;
            safetyStore.getAt(0).data.IsDelayBeyondAgencyControl = isDelayControllable;

            var vmFields = [];
            var vmField = { 'isDelayBeyondAgencyControl': isDelayControllable };

            vmFields.push(vmField);

            var parms = {
                control: radio,
                runValidations: true,
                dataChanged: true,
                vmFields: vmFields
            };

            parms = getStatusParms(parms, 'safetyItem1Rating');

            initValidations('Item1');

            runSafetyRules(controller, 'ValidateItem1', 'ValidateItem1', parms);
        }
    }
}
var processItem1CNoChange = function (radio) {

    var controller = getAppController();

    var valueChanged = radio.isDirty();

    if (!valueChanged) {

        return;
    }

    var newValue = radio.getValue();

    if (pageLoadStatus['Safety'] == 'rendered') {

        if (newValue) {

            resetRadioButton(radio);

            var safetyStore = chainedStore('CR_Safety_CollectionStore');
            var isDelayControllable = radio.inputValue;
            safetyStore.getAt(0).data.IsDelayBeyondAgencyControl = isDelayControllable;

            var vmFields = [];
            var vmField = { 'isDelayBeyondAgencyControl': isDelayControllable };

            vmFields.push(vmField);

            var parms = {
                control: radio,
                runValidations: true,
                dataChanged: true,
                vmFields: vmFields
            };

            parms = getStatusParms(parms, 'safetyItem1Rating');

            initValidations('Item1');

            runSafetyRules(controller, 'ValidateItem1', 'ValidateItem1', parms);
        }
    }
}
var processItem1CNAChange = function (radio) {

    var controller = getAppController();

    var valueChanged = radio.isDirty();

    if (!valueChanged) {

        return;
    }

    var newValue = radio.getValue();

    if (pageLoadStatus['Safety'] == 'rendered') {

        if (newValue) {

            resetRadioButton(radio);

            var safetyStore = chainedStore('CR_Safety_CollectionStore');
            var isDelayControllable = radio.inputValue;
            safetyStore.getAt(0).data.IsDelayBeyondAgencyControl = isDelayControllable;

            var vmFields = [];
            var vmField = { 'isDelayBeyondAgencyControl': isDelayControllable };

            vmFields.push(vmField);

            var parms = {
                control: radio,
                runValidations: true,
                dataChanged: true,
                vmFields: vmFields
            };

            parms = getStatusParms(parms, 'safetyItem1Rating');

            initValidations('Item1');

            runSafetyRules(controller, 'ValidateItem1', 'ValidateItem1', parms);
        }
    }
}
var processPreApplicabilityChange = function (radio, objParms) {

    var controller = getAppController();

    var valueChanged = radio.isDirty();

    if (!valueChanged) {

        return;
    }

    var newValue = getLastRadioSelection(objParms.newValue, objParms.oldValue);

    if (pageLoadStatus[objParms.pageName] == 'rendered') {

        if (newValue) {

            var parms = getRadioSelections2(radio, newValue, objParms.groupName),
                parms2 = {
                    control: radio,
                    runValidations: true,
                    dataChanged: objParms.dataChanged,
                    itemName: objParms.itemName,
                    groupItemName: objParms.groupItemName,
                    groupMembers: objParms.groupMembers
                };

            parms = concatJsonObjects(parms, [parms2]);

            parms = getStatusParms(parms, objParms.ratingId);

            initValidations(objParms.itemName);

            if (objParms.pageName == 'Safety') {

                runSafetyRules(controller, objParms.section, objParms.validationMethod, parms);
            }

            if (objParms.pageName == 'Permanency') {

                runPermanencyRules(controller, objParms.section, parms);
            }

            if (objParms.pageName == 'Wellbeing') {

                runWellbeingRules(controller, objParms.section, parms);
            }
        }
    }
}
var processSafetyNotApplicable = function () {

    var controller = getAppController();

    var fields = [];
    var vmFields = [];

    var field = { 'IsEffortToPreventReEntry': 0 };
    var vmField = { 'isEffortToPreventReEntry': 0 };

    fields.push(field);
    vmFields.push(vmField);

    field = { 'IsChildRemovedToEnsureSafety': 0 };
    fields.push(field);
    vmField = { 'isChildRemovedToEnsureSafety': 0 };
    vmFields.push(vmField);

    field = { 'EffortToPreventReEntryExplained': '' };
    fields.push(field);
    vmField = { 'effortToPreventReEntryExplained': '' };
    vmFields.push(vmField);

    field = { 'ChildRemovedToEnsureSafetyExplained': '' };
    fields.push(field);
    vmField = { 'childRemovedToEnsureSafetyExplained': '' };
    vmFields.push(vmField);

    var parms = {
        storeId: 'CR_Safety_CollectionStore',
        fields: fields,
        vmFields: vmFields
    };

    runSafetyRules(controller, null, null, parms, true);

    return true;
}
var processApplicabilityChange = function (radio, objParms) {

    var controller = getAppController();

    var valueChanged = radio.isDirty();

    if (!valueChanged) {

        return;
    }

    var newValue = radio.getValue();

    if (pageLoadStatus[objParms.pageName] == 'rendered') {

        if (newValue) {

            if (radio.inputValue == 2) {

                var result = window[objParms.preProcessMethod]();
            }

            var vmFields = [];
            var vmField = { 'item2Applicable': radio.inputValue };

            vmFields.push(vmField);

            var parms = {
                control: radio,
                runValidations: true,
                ratingDefault: objParms.ratingDefault,
                vmFields: vmFields,
                dataChanged: objParms.dataChanged
            };

            parms = getStatusParms(parms, objParms.ratingId);

            initValidations(objParms.itemName);

            runSafetyRules(controller, objParms.section, objParms.validationMethod, parms);
        }
    }
}
var processItem2Question2AChange = function (radio, methodName) {

    var controller = getAppController();

    var valueChanged = radio.isDirty();

    if (!valueChanged) {

        return;
    }

    var newValue = radio.getValue();

    if (pageLoadStatus['Safety'] == 'rendered') {

        if (newValue) {

            var fields = [];
            var vmFields = [];
            var vmField = { 'isEffortToPreventReEntry': radio.inputValue };
            var field = { 'IsEffortToPreventReEntry': radio.inputValue };

            fields.push(field);
            vmFields.push(vmField);

            var parms = {
                currentVal: newValue,
                storeId: 'CR_Safety_CollectionStore',
                fields: fields,
                control: radio,
                runValidations: true,
                dataChanged: true,
                vmFields: vmFields
            };

            parms = getStatusParms(parms, 'safetyItem2Rating');

            initValidations('Item2');

            if (methodName == 'ValidateItem2') {

                runSafetyRules(controller, methodName, null, parms);

                var concerns2A = controller.getAgencyEffortConcerns();
                var retObj = concerns2A.setValue('');
                concerns2A.disable();
            } else {

                runSafetyRules(controller, 'Question2ANo_change', 'ValidateItem2', parms);

                radio.enable();
            }            
        }
    }
}
var processItem2Question2AYesChange = function (radio) {

    var controller = getAppController();

    var valueChanged = radio.isDirty();

    if (!valueChanged) {

        return;
    }

    var newValue = radio.getValue();

    if (pageLoadStatus['Safety'] == 'rendered') {

        if (newValue) {

            var fields = [];
            var vmFields = [];
            var vmField = { 'isEffortToPreventReEntry': radio.inputValue };
            var field = { 'IsEffortToPreventReEntry': radio.inputValue };

            fields.push(field);
            vmFields.push(vmField);

            var parms = {
                currentVal: newValue,
                storeId: 'CR_Safety_CollectionStore',
                fields: fields,
                control: radio,
                runValidations: true,
                dataChanged: true,
                vmFields: vmFields
            };

            parms = getStatusParms(parms, 'safetyItem2Rating');

            initValidations('Item2');

            runSafetyRules(controller, 'ValidateItem2', null, parms);

            var concerns2A = controller.getAgencyEffortConcerns();
            var retObj = concerns2A.setValue('');
            concerns2A.disable();
        }
    }
}
var processItem2Question2ANoChange = function (radio) {

    var controller = getAppController();

    var valueChanged = radio.isDirty();

    if (!valueChanged) {

        return;
    }

    var newValue = radio.getValue();

    if (pageLoadStatus['Safety'] == 'rendered') {

        if (newValue) {

            var fields = [];
            var vmFields = [];
            var vmField = { 'isEffortToPreventReEntry': radio.inputValue };
            var field = { 'IsEffortToPreventReEntry': radio.inputValue };

            fields.push(field);
            vmFields.push(vmField);

            var parms = {
                currentVal: newValue,
                storeId: 'CR_Safety_CollectionStore',
                fields: fields,
                control: radio,
                runValidations: true,
                dataChanged: true,
                vmFields: vmFields
            };

            parms = getStatusParms(parms, 'safetyItem2Rating');

            initValidations('Item2');

            runSafetyRules(controller, 'Question2ANo_change', 'ValidateItem2', parms);

            radio.enable();

        }
    }
}
var processQuestion2BChange = function (radio) {

    var controller = getAppController();

    var valueChanged = radio.isDirty();

    if (!valueChanged) {

        return;
    }

    var newValue = radio.getValue();

    if (pageLoadStatus['Safety'] == 'rendered') {

        if (newValue) {

            var fields = [];
            var vmFields = [];
            var vmField = { 'isChildRemovedToEnsureSafety': radio.inputValue };
            var field = { 'IsChildRemovedToEnsureSafety': radio.inputValue };

            fields.push(field);
            vmFields.push(vmField);

            var parms = {
                currentVal: newValue,
                storeId: 'CR_Safety_CollectionStore',
                fields: fields,
                control: radio,
                runValidations: true,
                dataChanged: true,
                vmFields: vmFields
            };

            parms = getStatusParms(parms, 'safetyItem2Rating');

            initValidations('Item2');

            if (radio.inputValue == 1) {

                field = { 'ChildRemovedToEnsureSafetyExplained': '' };
                vmField = { 'childRemovedToEnsureSafetyExplained': '' };

                fields.push(field);

                field = { 'DataState': 0 };
                fields.push(field);

                vmFields.push(vmField);

                parms['fields'] = fields;
                parms['vmFields'] = vmFields;

                runSafetyRules(controller, 'ValidateItem2', null, parms);

                var concerns2B = controller.getChildRemovalConcerns();
                var retObj = concerns2B.setValue('');
                concerns2B.disable();

                getAppController().getQuestion2BNo().setValue(false);
                getAppController().getQuestion2BNA().setValue(false);
            }

            if (radio.inputValue == 2) {

                runSafetyRules(controller, 'Question2BNo_change', 'ValidateItem2', parms);

                getAppController().getQuestion2BYes().setValue(false);
                getAppController().getQuestion2BNA().setValue(false);
            }

            if (radio.inputValue == 3) {

                field = { 'ChildRemovedToEnsureSafetyExplained': '' };
                vmField = { 'childRemovedToEnsureSafetyExplained': '' };

                fields.push(field);

                field = { 'DataState': 0 };
                fields.push(field);

                vmFields.push(vmField);

                parms['fields'] = fields;
                parms['vmFields'] = vmFields;

                runSafetyRules(controller, 'ValidateItem2', null, parms);

                var concerns2BNA = controller.getChildRemovalConcerns();
                var retObj = concerns2BNA.setValue('');
                concerns2BNA.disable();

                getAppController().getQuestion2BNo().setValue(false);
                getAppController().getQuestion2BYes().setValue(false);
            }
        }
    }
}
var processQuestion3Change = function (radio, fieldName, additionalField) {

    var controller = getAppController();
    var selectedItem = getSelectedItem(radio);
    var savedData;

    if (Ext.isEmpty(selectedItem)) {

        return;
    }

    //var valueChanged = selectedItem.isDirty();
    var dataSource = window.safetyViewModel.data.safetyCollection.getAt(0).data;

    savedData = dataSource[fieldName];

    var valueChanged = isDataChangedByUser(selectedItem, selectedItem.inputValue, savedData);

    if (!valueChanged) {

        return;
    }

    var newValue = selectedItem.getValue();

    if (pageLoadStatus['Safety'] == 'rendered') {

        if (newValue) {

            var fields = [];
            var field = {};
            var vmFields = [];
            var vmField = {};

            var vmFieldName = fieldName.charAt(0).toLowerCase() + fieldName.slice(1);

            field[fieldName] = selectedItem.inputValue;
            vmField[vmFieldName] = selectedItem.inputValue;

            fields.push(field);

            field = { 'DataState': 0 };
            fields.push(field);

            vmFields.push(vmField);

            if (!Ext.isEmpty(additionalField)) {

                fields.push(additionalField);

                var keys = Object.keys(additionalField);

                vmFieldName = keys[0].charAt(0).toLowerCase() + keys[0].slice(1);

                vmField[vmFieldName] = additionalField[keys[0]];
                vmFields.push(vmField);
            }

            var parms = {
                currentVal: newValue,
                storeId: 'CR_Safety_CollectionStore',
                fields: fields,
                control: selectedItem,
                runValidations: true,
                dataChanged: true,
                vmFields: vmFields
            };

            parms = getStatusParms(parms, 'safetyItem3Rating');

            initValidations('Item3');

            runSafetyRules(controller, 'ValidateItem3', 'ValidateItem3', parms);
        }
    }
}
//
// Resusable methods
//
var getSelectedItem = function (cmp) {

    var selection;

    if (Ext.isEmpty(cmp.items)) {

        return cmp;
    }

    Ext.each(cmp.items.items, function (item) {

        if (item.checked) {

            selection = item;

            return false;
        }
    });

    return selection;
}