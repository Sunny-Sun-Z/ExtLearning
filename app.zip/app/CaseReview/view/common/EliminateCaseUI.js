﻿Ext.define('App.CaseReview.view.common.EliminateCaseUI', {
    extend: Ext.panel.Panel.$className,
    alias: 'widget.eliminateCaseUI',
    baseCls: 'x-fieldset fieldset-padding',
    itemId: 'eliminateCaseUI',
    border: false,
    resizable: false,
    //defaults: {
    //    stateful: true
    //},
    closeAction : 'hide',
    initComponent: function () {
        var me = this;
        var sr = App.Common.StringResources;
        
        Ext.applyIf(me, {
            items: [
                {
                    xtype: 'form',
                    itemId: 'eliminateCaseForm',
                    bodyCls: 'panel-background-color',
                    flex: 1,
                    region: 'center',
                    height: 400,
                    width: 625,
                    scrollable: 'vertical',
                    plugins: [                                       
                        {
                            ptype: 'crsValidationPlugin',
                            pluginId: 'eliminateCase',
                            validationType: 'CaseElimination',
                            validationInput: ['eliminateReason']                            
                        }
                    ],
                    items: [
                        {
                            xtype: 'panel',
                            margin: '0 20 20 20',
                            bodyCls: 'panel-background-color',
                            border: true,
                            animCollapse: false,
                            layout: 'hbox',
                            items:
                            [   
                                {
                                    xtype: 'component',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '15 0 0 0',
                                    html: "<strong>Reason Case Eliminated:</strong>"
                                },
                                {
                                    xtype: 'container',
                                    border: false,
                                    margin: '15 0 10 20',
                                    bodyCls: 'panel-background-color',
                                    items: [
                                        {
                                            xtype: 'combobox',
                                            store: 'CaseEliminationReasonStore',
                                            displayField: 'DescriptionLarge',
                                            editable: false,
                                            valueField: 'GroupID',
                                            itemId: 'eliminationReason',
                                            name : 'CaseReview.EliminationReasonCode',
                                            width: 400
                                        }
                                    ]
                                }                              
                            ]
                        },
                        {
                            xtype: 'container',
                            bodyCls: 'panel-background-color',
                            border: false,
                            margin: '15 0 0 20',
                            layout: 'vbox',
                            items: [
                                {
                                    xtype: 'component',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '15 0 0 0',
                                    html: "<strong>If this case should not be in the sample, please explain below:</strong>"
                                },
                                {                                           
                                    xtype: 'container',
                                    itemId: 'reasonExplanation',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    layout: 'hbox',
                                    margin: '10 10 20 0',
                                    items: [
                                        {
                                            xtype: 'textarea',
                                            itemId: 'eliminationReasonExplained',
                                            name: 'CaseReview.EliminationReasonExplained',
                                            width: 575
                                        }
                                    ]
                                },
                              
                                {                                           
                                    xtype: 'container',
                                    itemId: 'userReviewContainer',
                                    hidden : true,
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '10 10 20 0',
                                    items: [
                                          {
                                              xtype: 'component',
                                              bodyCls: 'panel-background-color',
                                              border: false,
                                              margin: '15 0 0 0',
                                              html: "<strong>QA Signoff:</strong>"
                                          },
                                            {
                                                xtype: 'checkbox',
                                                itemId: 'reviewCheckbox',
                                                bodyCls: 'panel-background-color',
                                                border: false,
                                                margin: '15 0 0 0',
                                                fieldLabel: "I have reviewed the narrative above(if any) and confirm that the case elimination explanation does not contain the proper names",
                                                labelAlign: "left",
                                                labelWidth : 500

                                            }
                                       
                                    ]
                                }
                            ]
                        },
                        {
                            //*****************************************************
                            // Cancel and 'Save and Continue' buttons]
                            //*****************************************************
                            xtype: 'container',
                            margin: '10 30 10 0',
                            border: false,
                            layout:
                                {
                                    type: 'table',
                                    columns: 2
                                },
                            cls: 'align-right',
                            items: [
                                {
                                    //SAVE and CONTINUE BUTTON
                                    xtype: 'button',
                                    baseCls: 'x-btn borderless-button-style',
                                    margin: '15 30 0 30',
                                    text: 'Save',
                                    itemId: 'eliminateToApproveSave',
                                    scale: 'medium',
                                    hidden: true,
                                    listeners: {
                                        click: function () {
                                            window.submitEliminateToApprove = true;
                                        }
                                    }
                                    
                                },
                                {
                                    //SAVE and CONTINUE BUTTON
                                    xtype: 'button',
                                    baseCls: 'x-btn borderless-button-style',
                                    margin: '15 0 0 30',
                                    text: 'Approve and Eliminate',
                                    itemId: 'approveNEliminateSave', 
                                    scale: 'medium',
                                    //hidden: true,
                                    listeners: {
                                        click: function () {
                                            window.submitToEliminate = true;
                                        }
                                    }

                                }
                            ]
                        }
                    ]
                }
            ]
       });
       
          me.callParent(arguments);
    }
});