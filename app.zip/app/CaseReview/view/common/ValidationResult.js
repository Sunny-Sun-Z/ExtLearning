﻿Ext.define('App.CaseReview.view.common.ValidationResult', {
    extend: 'Ext.form.Panel',
    alias: 'widget.validationResult',
    title: 'Validation Messages',
    width: '100%',
    bodyPadding: 10,
    items: [{
        xtype: 'fieldcontainer',
        labelWidth: 75,
        defaultType: 'textarea',
        layout: 'hbox',
        defaults: {
            layout: '100%'
        },
        fieldDefaults: {
            labelAlign: 'top',
            padding: '0 10 10 10',
            border: 1,
            width: 300,
            readOnly: true
        },

        items: [{
            fieldLabel: '<u><b>First Name</b></u>',
            name: 'firstName',
            value: 'Very Long Name',
            style: {
                borderColor: 'red',
                borderStyle: 'dashed'
            }
        }, {
            fieldLabel: '<u><b>Last Name</b></u>',
            name: 'lastName',
            value: 'Mannnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn',
            style: {
                borderColor: 'red',
                borderStyle: 'dashed'
            }
        }]
    }]
});