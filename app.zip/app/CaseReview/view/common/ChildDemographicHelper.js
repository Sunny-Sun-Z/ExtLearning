﻿Ext.define('App.CaseReview.view.common.ChildDemographicHelper',
{
    extend: 'Ext.window.Window',
    itemId: 'childDemographicHelper',
    title: 'Child Demographic',
    width: 650,
    layout: 'vbox',
    onShow: function() {
        // Needed for EXT5
        this.callParent(arguments);
        this.center();
    },
    getDockedItems: function (selector, beforeBody) {
        var layout = this.getComponentLayout();
        if (layout.getDockedItems) {
            var dockedItems = layout.getDockedItems('render', beforeBody);
            if (selector && dockedItems.length) {
                dockedItems = Ext.ComponentQuery.query(selector, dockedItems);
            }
            return dockedItems;
        }
        else {
            return [];
        }
    },
    scrollable: true,
    shrinkWrap: true,
    modal: true,
    bodyStyle: 'background:#fff;',
    //closeAction: 'destroy',
    items: [
    {
        xtype: 'form',
        itemId: 'childDemographicHelperEdit',
        margin: 15,
        layout: 'vbox',
        border: false,
        items: [
        {
            xtype: 'checkbox',
            flex: 1,
            itemId: 'isTargetChild',
            fieldLabel: 'Is Target Child',
            width: 450,
            maxLength: 1,
            labelWidth: 150,
            name: 'IsTargetChild',
            inputValue: 1,
            uncheckedValue: 2,
            listeners: {
                afterrender: function () {

                    var caseType = getCaseType();

                    if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

                        this.disable();
                    }                    
                }
            }
        }, {
            xtype: 'textfield',
            flex: 1,           
            itemId: 'childsName',
            //fieldLabel: 'Child Name <span style = "color: Red" >* </span>',
            fieldLabel: 'Child Name',
            width: 450,
            maxLength: 100,
            enforceMaxLength: true,
            labelWidth: 150,
            name: 'Name',
            allowBlank: false,
            msgTarget: 'under',
            blankText: 'Please specify the childs name'
        },
        {
            xtype: 'boundcheckboxgroup',
            itemId: 'CR_ChildRace_Collection',
            store: GetChildRaceStore(),
            allowBlank : false,
            columns: 1,
            vertical: true,
            inputField: 'RaceCode',
            fieldLabel: 'Race',
            labelWidth: 150,
            msgTarget: 'side',
            blankText : 'Please select at least one race',
            items: [
                     {
                         itemId:'childRace1',
                         boxLabel: 'American Indian or Alaskan Native',
                         inputValue: 1
                         //,name: 'RaceCode'
                     },
                     {
                         itemId: 'childRace2',
                         boxLabel: 'Asian',
                         inputValue: 2
                         //,name : 'RaceCode'

                     },
                     {
                         itemId: 'childRace3',
                         boxLabel: 'Black or African American',
                         inputValue: 3
                         //,name: 'RaceCode'
                     },
                     {
                         itemId: 'childRace4',
                         boxLabel: 'Native Hawaiian or Other Pacific Islander',
                         inputValue: 4
                         //,name: 'RaceCode'

                     },
                     {
                         itemId: 'childRace5',
                         boxLabel: 'White',
                         inputValue: 5
                         //,name: 'RaceCode'
                     },
                     {
                         itemId: 'childRace6',
                         boxLabel: 'Unknown or Unable to Determine',
                         inputValue: 6
                         //,name: 'RaceCode'
                     }
                 ]
        },
        {
                xtype: 'combobox',
                allowBlank: false,
                msgTarget: 'side',
                blankText: 'Please select ethnicity',
                flex: 1,
                itemId: 'ethnicityCombo',
                fieldLabel: 'Ethnicity',
                store: 'EthnicityStore',
                displayField: 'DescriptionLarge',
                valueField: 'GroupID',
                typeahead: true,
                triggerAction: 'all',
                editable: false,
                autoSelect: true,
                lastQuery: '',
                forceSelection: true,
                width: 450,
                labelWidth: 150,
                name: 'EthnicityCode',
                renderer: function (value) {
                    var lookupStore = chainedStore('EthnicityStore');
                    var results = lookupStore.query('GroupID', value, false, false, true);
                    if (results.length > 0) {
                        return results.getAt(0).data.DescriptionLarge;
                    }
                    return '';
                }
            },
        {
            xtype: 'datefield',//neeed to restrict format
            itemId: 'dateOfBirth',
            labelWidth: 150,
            fieldLabel: 'Date of Birth',
            allowBlank: false,
            msgTarget: 'side',
            blankText: 'Please specify date of birth',
            width: 300,
            name: 'DateOfBirth',
            renderer: Ext.util.Format.dateRenderer('m/d/Y'),
            maxValue: new Date(),
            minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30)
           
            },
        
        {
                xtype: 'combobox',
                allowBlank: false,
                msgTarget: 'side',
                blankText: 'Please select gender',
                flex: 1,
                itemId: 'genderCombo',
                fieldLabel: 'Gender',
                store: 'GenderStore',
                displayField: 'DescriptionLarge',
                valueField: 'GroupID',
                //typeahead: true,
                editable : false,
                triggerAction: 'all',
                autoSelect: true,
                lastQuery: '',
                forceSelection: true,
                width: 450,
                labelWidth: 150,
                name: 'GenderCode',
                renderer: function (value) {
                    var lookupStore = chainedStore('GenderStore');
                    var results = lookupStore.query('GroupID', value, false, false, true);
                    if (results.length > 0) {
                        return results.getAt(0).data.DescriptionLarge;
                    }
                    return '';
                }
            },
        {
                xtype: 'checkbox',
                flex: 1,
                itemId: 'isInterviewed',
                fieldLabel: 'Is Interviewed',
                width: 450,
                maxLength: 1,
                labelWidth: 150,
                name: 'IsInterviewed',                
                inputValue: 1,
                uncheckedValue: 2
            },
        {
                xtype: 'container',
                layout: 'hbox',
                items: [
                    {
                        xtype: 'button',
                        flex: 1,
                        align: 'right',
                        width: '100px',
                        text: 'Cancel',
                        itemId: 'unitCancel',
                        margin: '15 0 0 170',
                        padding: '5 5 5 5',
                        icon: window.baseUrl + '/content/icons/cross-small.png'
                    }, {
                        xtype: 'button',
                        flex: 1,
                        align: 'right',
                        style: 'float:right',
                        width: '150px',
                        text: 'Add/Update',
                        itemId: 'unitSave',
                        margin: '15 0 0 10',
                        padding: '5 5 5 5',
                        icon: window.baseUrl + '/content/icons/database_add.png'
                    }

                ]
            }]
    }
    ]

});