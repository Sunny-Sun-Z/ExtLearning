﻿Ext.define('App.CaseReview.view.common.CRSUser', {
    extend: 'Ext.Base',
    alias: 'widget.crsUser',
    config: {
        userId: undefined,
        firstname: undefined,
        lastname: undefined,
        fullname: undefined,
        loginId: undefined,
        isStateAdmin: undefined,
        isFedTeamMember: undefined,
        effectiveRole: undefined
    },
    init: function () {
        var roleStore = chainedStore('CrSecurityUserRolePermissionsStore');

        this.setUserId(roleStore.getAt(0).data.UserID);
        this.setFirstname(roleStore.getAt(0).data.FirstName.trim());
        this.setLastname(roleStore.getAt(0).data.LastName.trim());
        this.setFullname(this.getFirstname() + ' ' + this.getLastname());
        this.setLoginId(roleStore.getAt(0).data.LoginID.trim());
        this.setIsStateAdmin(this.isStateAdministrator());
        this.setIsFedTeamMember(this.isFederalTeamMember());
        this.setEffectiveRole(this.determineEffectiveRole());
    },
    constructor: function () {
        this.init();
    },
    isInRole: function (roleName) {
        var result = false;
        var roleStore = chainedStore('CrSecurityUserRolePermissionsStore');

        Ext.each(roleStore.getAt(0).data.CrUserRoleMappings, function (role) {
            if (role.RoleID == roleName || role.Description == roleName) {
                result = true;

                return false;
            }
        });

        return result;
    },
    isStateAdministrator: function(){

        var result = false;

        var filteredRoles = this.userRoles().filter(function (role) {

            return role.RoleID == 7;
        });

        if (filteredRoles.length > 0) {

            result = true;
        }

        return result;
    },
    isFederalTeamMember: function () {

        var result = false;

        var filteredRoles = this.userRoles().filter(function (role) {

            return role.RoleID == 3 || role.RoleID == 4;
        });

        if (filteredRoles.length > 0) {

            result = true;
        }

        return result;
    },
    determineEffectiveRole: function () {

        var result, filteredRole;
        var roles = this.userRoles();
        var actionsAllowed = [];

        if (this.getIsFedTeamMember()) {

            actionsAllowed = actionsAllowed.concat(CaseReviewRoles.reviewRoles.fedTeamMember.actionsAllowed);
        }

        if (this.getIsStateAdmin()) {

            actionsAllowed = actionsAllowed.concat(CaseReviewRoles.reviewRoles.stateAdmin.actionsAllowed);
        }

        filteredRole = roles.filter(function (role) {

            return role.RoleID == 17;
        });

        if (filteredRole.length > 0) {

            actionsAllowed = actionsAllowed.concat(CaseReviewRoles.reviewRoles.secondaryOversight.actionsAllowed);
        }

        filteredRole = roles.filter(function (role) {

            return role.RoleID == 16;
        });

        if (filteredRole.length > 0) {

            actionsAllowed = actionsAllowed.concat(CaseReviewRoles.reviewRoles.secondLevelQA.actionsAllowed);
        }

        filteredRole = roles.filter(function (role) {

            return role.RoleID == 15;
        });

        if (filteredRole.length > 0) {

            actionsAllowed = actionsAllowed.concat(CaseReviewRoles.reviewRoles.initialQA.actionsAllowed);
        }

        filteredRole = roles.filter(function (role) {

            return role.RoleID == 1;
        });

        if (filteredRole.length > 0) {

            actionsAllowed = actionsAllowed.concat(CaseReviewRoles.reviewRoles.reviewer.actionsAllowed);
        }

        actionsAllowed.sort();

        actionsAllowed = dedupeStringArray(actionsAllowed);

        result = {};
        result['actionsAllowed'] = actionsAllowed;

        return result;
    },
    hasPermission: function (permissionName) {
        var result = false;
        var roleStore = chainedStore('CrSecurityUserRolePermissionsStore');

        Ext.each(roleStore.getAt(0).data.CrUserRolePermissionMappings, function (permission) {
            if (permission.PermissionID == permissionName || permission.Description == permissionName) {
                result = true;

                return false;
            }
        });

        return result;
    },
    userRoles : function(){
        
        var uId = window.userID;

        var roleStore = Ext.data.ChainedStore.create({
            source: 'CrSecurityUserRolePermissionsStore',
            filters: [
                function (record) {
                    return record.data.UserID == uId;
                }
            ]
        });

        return roleStore.getAt(0).data.CrUserRoleMappings;
    },
    userPermissions: function () {
        var result = false;
        var roleStore = chainedStore('CrSecurityUserRolePermissionsStore');
        var uId = roleStore.getAt(0).data.UserID;

        var roleStore = Ext.data.ChainedStore.create({
            source: 'CrSecurityUserRolePermissionsStore',
            filters: [
                function (record) {
                    return record.data.UserID == uId;
                }
            ]
        });

        return roleStore.getAt(0).data.CrUserRolePermissionMappings;
    },
    getCaseRole: function (userId, formatResult) {
        var self = this;

        var result = '';
        var uId = userId == undefined ? self.getUserId() : userId;

        var roleStore = chainedStore('CaseReviewStore');
        
        // Check QA and Oversight roles first
        if (!(roleStore.getAt(0) == undefined || roleStore.getAt(0) == null)) {

            if (roleStore.getAt(0).data.InitialQAUserID == uId) {

                result = 'Initial QA';

                if (formatResult) {

                    result = 'initialQA';
                }
                
                return result;
            }

            if (roleStore.getAt(0).data.SecondQAUserID == uId) {

                result = 'Second Level QA';

                if (formatResult) {

                    result = 'secondLevelQA';
                }

                return result;
            }

            if (roleStore.getAt(0).data.SecondaryOversightUserID == uId) {

                result = 'Secondary Oversight';

                if (formatResult) {

                    result = 'secondaryOversight';
                }

                return result;
            }

            if (roleStore.getAt(0).data.CtSecondaryOversightUserID == uId) {

                result = 'CT Secondary Oversight';

                if (formatResult) {

                    result = 'ctSecondaryOversight';
                }

                return result;
            }
        }
        
        // Check reviewers
        var reviewerStore = Ext.data.ChainedStore.create({
            source: 'CR_Reviewer_CollectionStore',
            filters: [
                function (record) {
                    return record.data.UserID == uId;
                }
            ]
        });

        if (reviewerStore.data.length > 0) {

            result = 'Reviewer';

            if (formatResult) {

                result = 'reviewer';
            }

            return result;
        }

        return result;
    },
    getObjectCreator: function (userId) {
        var self = this;

        var result = '';
        var uId = userId == undefined ? self.getUserId() : userId;

        var roleStore = Ext.data.ChainedStore.create({
            source: 'CrSecurityUserStore',
            filters: [
                function (record) {
                    return record.data.UserID == uId;
                }
            ]
        });

        var firstName;
        var lastName;

        if (!(Ext.isEmpty(roleStore))) {

            if (roleStore.data.length > 0) {

                firstName = roleStore.getAt(0).data.FirstName.trim();
                lastName = roleStore.getAt(0).data.LastName.trim();
            } else {
                firstName = self._firstname;
                lastName = self._lastname;
            }            
        }
        
        return firstName + ' ' + lastName;
    }
});