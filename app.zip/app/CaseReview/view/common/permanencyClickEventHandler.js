﻿//
// This is the click event handler for the Permanency page
//
var processPermanencyClick = function (input, additionalField) {

    var controller = getAppController();
    var selectedItem = getSelectedItem(input.Component);

    if (Ext.isEmpty(selectedItem)) {

        return;
    }

    var valueChanged = selectedItem.isDirty();

    if (!valueChanged) {

        return;
    }

    var newValue = selectedItem.getValue();

    if (pageLoadStatus['Permanency'] == 'rendered') {

        if (newValue) {

            var fields = [];
            var field = {};
            var vmFields = [];
            var vmField = {};
            var vmFieldName = input.FieldName.charAt(0).toLowerCase() + input.FieldName.slice(1);

            field[input.FieldName] = selectedItem.inputValue;
            vmField[vmFieldName] = selectedItem.inputValue;

            fields.push(field);

            field = { 'DataState': 0 };
            fields.push(field);

            vmFields.push(vmField);

            if (!Ext.isEmpty(additionalField)) {

                fields.push(additionalField);

                var keys = Object.keys(additionalField);

                vmFieldName = keys[0].charAt(0).toLowerCase() + keys[0].slice(1);

                vmField[vmFieldName] = additionalField[keys[0]];
                vmFields.push(vmField);
            }

            var parms = {
                currentVal: newValue,
                storeId: 'CR_Permanency_CollectionStore',
                fields: fields,
                vmFields: vmFields,
                control: input.Component,
                runValidations: true
            };

            parms = getStatusParms(parms, input.RatingItemId);

            initValidations(input.ItemName);

            parms['dataChanged'] = true;
            
            var itemId = Ext.isEmpty(input.ItemId) ? selectedItem.itemId : input.ItemId;

            runPermanencyRules(controller, itemId, parms);
        }
    }
}
var processPermanencyItemApplicable = function (input) {

    var controller = getAppController();
    var selectedItem = getSelectedApplicableComponent(input.Component);

    if (Ext.isEmpty(selectedItem)) {

        return;
    }

    var valueChanged = selectedItem.isDirty();

    if (!valueChanged) {

        return;
    }

    var newValue = selectedItem.getValue();

    if (pageLoadStatus['Permanency'] == 'rendered') {

        if (newValue) {

            //deselectPrevChoices(selectedItem);
            var item = getItem(input.ItemCode, input.OutcomeCode);

            if (!(item == undefined)) {

                item.IsApplicable = input.Component.inputValue;
                updateItem(item);
            }

            var vmFields = [];
            var vmField = {};

            vmField[input.FieldName] = selectedItem.inputValue;

            vmFields.push(vmField);

            var parms = {
                control: input.Component,
                runValidations: true,
                vmFields: vmFields
            };

            parms = getStatusParms(parms, input.RatingItemId);

            initValidations(input.ItemName);

            parms['dataChanged'] = true;

            var itemId = Ext.isEmpty(input.ItemId) ? selectedItem.itemId : input.ItemId;

            if (selectedItem.inputValue == 2) {

                parms['ratingDefault'] = 'NA';

                runPermanencyRules(controller, itemId, parms)

                return;
            }

            runPermanencyRules(controller, itemId, parms);
        }
    }
}
var getSelectedApplicableComponent = function (container) {

    var result;

    if (container.xtype == 'radio') {

        if (container.checked) {

            return container;
        }
        
        return result;
    }

    var radioComponents = container.query('radio');

    Ext.each(radioComponents, function (comp) {

        if (comp.checked) {

            result = comp;

            return false;
        }
    });

    return result;
}