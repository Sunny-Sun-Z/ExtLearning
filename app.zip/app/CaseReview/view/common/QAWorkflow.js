﻿Ext.define('App.CaseReview.view.common.QAStageIndicator', {
    extend: 'Ext.container.Container',
    alias: 'widget.qaStageIndicator',
    border: true,
    layout: {
        type: 'hbox',
        pack: 'center',
        align: 'middle'
    },
    items: [
        {            
            xtype: 'qaLegend'
        }
    ]
});