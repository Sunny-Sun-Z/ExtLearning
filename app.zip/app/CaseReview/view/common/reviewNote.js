﻿Ext.define('App.CaseReview.view.common.reviewNote', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.reviewNote',
    bodyCls: 'panel-background-color',
    margin: '0 20 20 20',
    border: true,
    defaults: {
        padding: '0 0 0 0'
    },
    config: {
        createDate: undefined,
        createBy: undefined,
        resolved: false,
        subject: undefined,
        text: undefined,
        responseItems: undefined,
        responseToDelete: undefined,
        noteId: undefined,
        noteItemId: undefined,
        itemCode: undefined,
        status: undefined,
        extNoteId: undefined,
        noteType: 'item',
        outcomeCode: undefined
    },
    createNote: function (nItemId, subj, desc, idCode) {

        var noteType = this.getNoteType();
        var outcomeCode = this.getOutcomeCode();
        var noteObj;
        var userId = GetLoggedInUser().getUserId();

        if (noteType == 'item') {

            var inputObj = { storeId: 'CR_Outcome_CollectionStore', alternateId: 'OutcomeCode', alternateIdValue: outcomeCode };
            var store = getObjectStore(inputObj);

            if (store.count() > 0) {
                // Create item if needed    
                var item = store.getAt(0).data.CR_Item_Collection.filter(function (itemObj) {
                    return (itemObj.ItemCode ==idCode);
                });

                if (!(nItemId > 0)) {

                    nItemId = item.length == 0 ? 0 : item[0].ItemID;
                }

                var latestItemId = getLatestItemId(idCode, outcomeCode);

                if (!(nItemId == latestItemId)) {

                    if (!Ext.isEmpty(latestItemId)) {

                        nItemId = latestItemId;
                    }
                }
            }

            noteObj = App.model.CR_Note.create({
                Subject: subj,
                Description: desc,
                DataState: 0,
                ItemID: nItemId,
                IsResolved: 2,
                data: {},
                extNoteId: undefined,
                TS_CR: new Date(),
                TS_UP: new Date(),
                ID_CR: userId,
                ID_UP: userId,
                LastModifiedDate: new Date(),
                LastModifiedUserID: userId,
                ItemCode: idCode,
                status: 'new',
                idProperty: 'ExtId'
            });

            noteObj.data.CR_Response_Collection = [];

            var inputObj = { objectType: 'note', outcomeCode: outcomeCode, DataState: 0, objValue: noteObj.data };
            addCRSObject(inputObj);
        }
        
        if (noteType == 'case') {

            noteObj = App.model.CR_CaseNote.create({
                Subject: subj,
                Description: desc,
                DataState: 0,
                CaseReviewID: idCode,
                IsResolved: 2,
                data: {},
                extNoteId: undefined,
                TS_CR: new Date(),
                TS_UP: new Date(),
                ID_CR: userId,
                ID_UP: userId,
                LastModifiedDate: new Date(),
                LastModifiedUserID: userId,
                status: 'new',
                idProperty: 'ExtId'
            });

            noteObj.data.CR_CaseNote_Response_Collection = [];
        }
        
        return noteObj;
    },
    cloneNote: function (note) {

        var noteType = this.getNoteType();
        var clonedNote = note;

        if (noteType == 'item') {

            if (Ext.isEmpty(note.data)) {

                clonedNote.data = {};
                clonedNote.data.CR_Response_Collection = [];
            }

            return clonedNote;
        }
        
        if (noteType == 'case') {

            if (Ext.isEmpty(note.data)) {

                clonedNote.data = {};
                clonedNote.data.CR_CaseNote_Response_Collection = [];
            }

            return clonedNote;
        }

        return clonedNote;
    },
    createResponse: function (noteId, desc, extId) {
        var noteType = this.getNoteType();
        var respObj;
        var userId = GetLoggedInUser().getUserId();

        if (noteType == 'item') {
            respObj = App.model.CR_Response.create({
                Description: desc,
                DataState: 0,
                NoteID: noteId,
                extRespId: undefined,
                TS_CR: new Date(),
                TS_UP: new Date(),
                ID_CR: userId,
                ID_UP: userId,
                LastModifiedDate: new Date(),
                parentId: extId,
                status: 'new',
                idProperty: 'ExtId'
            });

            return respObj;
        }
        
        if (noteType == 'case') {
            respObj = App.model.CR_CaseNote_Response.create({
                Description: desc,
                DataState: 0,
                NoteID: noteId,
                extRespId: undefined,
                TS_CR: new Date(),
                TS_UP: new Date(),
                ID_CR: userId,
                ID_UP: userId,
                LastModifiedDate: new Date(),
                parentId: extId,
                status: 'new',
                idProperty: 'ExtId'
            });

            return respObj;
        }

        return respObj;
    },
    removeFromStore: function (note) {

        var self = this;
        var itemId;
        var item;
        var caseReviewStore;
        var noteColl;

        if (self.getNoteType() == 'item') {

            //itemId = note.ItemCode == undefined ? note.noteItemId : note.ItemCode;
            var result;

            if (Ext.isEmpty(note.ItemCode)) {

                result = getNoteItemId(note.subject, note.text);

                if (Ext.isEmpty(result)) {

                    result = {};
                }
            } 

            itemId = note.ItemCode == undefined ? result.ItemID : note.ItemCode;

            if (!Ext.isEmpty(itemId)) {

                item = getItem(itemId, getOutcomeCode(itemId));
            }
            
            if (!Ext.isEmpty(item)) {

                noteColl = item.CR_Note_Collection;

                var index = -1;

                for (var i = 0; i < noteColl.length; i++) {

                    if (noteColl[i].NoteID == note.noteId) {
                        index = i;

                        i = noteColl.length;
                    }
                }

                if (index > -1) {

                    var removedNote = noteColl.splice(index, 1);

                    deletedQANotes.push(removedNote);

                }
            }            
        }
        
        if (self.getNoteType() == 'case') {

            var caseNoteStore = Ext.data.ChainedStore.create({
                source: 'CR_CaseNote_CollectionStore'
            });

            if (caseNoteStore.data.length > 0) {

                // Remove note
                Ext.each(caseNoteStore.data.items, function (noteToRemove) {

                    if (noteToRemove.data.NoteID == note.noteId) {

                        var removedNote = caseNoteStore.data.remove(noteToRemove);

                        return false;
                    }
                });
            }
        }
    },
    getStore: function(storeName){

        var self = this;
        var result;

        switch (storeName) {

            case 'note':

                var itemCode = self.getItemCode() == undefined ? self.ownerCt.ownerCt.getItemCode() : self.getItemCode();

                result = getNoteCollection(itemCode, self.getNoteType());

                break;

            case 'item':

                var itemCode = self.getItemCode();

                result = getItemFromGraph(itemCode, getOutcomeCode(itemCode));

                break;

            case 'response':

                var note;

                if (self.getNoteType() == 'case') {
                    note = self.cloneNote(self);
                }

                result = getResponseCollection(self.getItemCode(), self.getNoteId(), note);

                break;

            default:

                break;
        }

        return result;
    },
    updateNote: function(noteColl, noteId, itemCode){
        var self = this;
        var changedNote = null;
        var userId = GetLoggedInUser().getUserId();

        if (noteColl.length == 0) {
            self.setNoteItemId(0);
        } else {
            self.setNoteItemId(noteColl[0].ItemID);
        }

        if (Ext.isEmpty(noteColl)) {

            if (self.getStatus() == 'new') {

                var itemId = self.getNoteItemId() === undefined ? noteColl[0].ItemID : self.getNoteItemId();
                self.setNoteItemId(itemId);

                var newNote = self.createNote(itemId, self.getSubject(), self.getText(), itemCode);
                self.setExtNoteId(newNote.data.ExtId);

                if (self.getResolved()) {

                    newNote.IsResolved = 1;
                }

                newNote.status = 'stored';
                newNote.data.status = 'stored';
                changedNote = newNote.data;

                self.setStatus('stored');

                // Update item collection if necessary
                updateNoteCollection(itemCode, changedNote, self.getNoteType());
            }

            return changedNote;
        }

        Ext.each(noteColl, function (note) {
            if (self.getStatus() == 'changed') {

                if (note.NoteID == noteId) {

                    note.DataState = 0;
                    note.Subject = self.getSubject();
                    note.Description = self.getText();
                    note.IsResolved = self.getResolved() ? 1 : 2;
                    note.LastModifiedDate = new Date();
                    note.LastModifiedUserID = userId,
                    note.ID_UP = userId;

                    note.status = 'stored';

                    changedNote = note;

                    self.setStatus('stored');

                    return false;
                }
            }

            if (self.getStatus() == 'new') {

                var itemId = self.getNoteItemId() === undefined ? noteColl[0].ItemID : self.getNoteItemId();
                self.setNoteItemId(itemId);

                var newNote = self.createNote(itemId, self.getSubject(), self.getText(), itemCode);                
                self.setExtNoteId(newNote.data.ExtId);

                if (self.getResolved()) {

                    newNote.IsResolved = 1;
                }

                newNote.status = 'stored';
                newNote.data.status = 'stored';
                changedNote = newNote.data;

                self.setStatus('stored');

                // Update item collection if necessary
                updateNoteCollection(itemCode, changedNote, self.getNoteType());

                return false;
            }

            if (note.NoteID == noteId && noteId > 0 || (!(note.ExtId == undefined) && note.ExtId == self.getExtNoteId())) {
                
                changedNote = note;
                updateNoteCollection(itemCode, note,self.getNoteType());

                return false;
            }
        });

        if (Ext.isEmpty(changedNote)) {

            var filteredNote = noteColl.filter(function (noteInColl) { 

                return noteInColl.Subject == self.getSubject() &&
                       noteInColl.Description == self.getText() &&
                       noteInColl.ItemID == self.getNoteItemId();
            });

            if (filteredNote.length > 0) {

                changedNote = filteredNote[0];
            }
        }

        return changedNote == null ? self.createNote(self.getNoteItemId(), self.getSubject(), self.getText(), itemCode) : changedNote;
    },
    updateResponse: function(changedNote,responses, responseToDelete){
        var self = this;
        var operationType = 'delete';
        var userId = GetLoggedInUser().getUserId();

        if (!(responses === undefined)) {            

            var responseItems = responses.items === undefined ? responses : responses.items;

            Ext.each(responseItems, function (resp) {

                if (resp.getStatus() == 'changed') {

                    operationType = 'change';
                    var respId = resp.getResponseId();

                    Ext.each(changedNote.CR_Response_Collection, function (response) {

                        if ((response.ResponseID == respId && response.ResponseID > 0) ||
                             response.extRespId == resp.id) {

                            response.Description = resp.response;
                            response.LastModifiedDate = new Date();
                            response.LastModifiedUserID = userId,
                            response.ID_CR = userId;
                            response.status = 'stored';

                            return false;
                        }
                    });
                }
            });

            // Create new response, if needed
            var responseColl = self.getStore('response');
            changedNote = self.cloneNote(changedNote);

            if (changedNote.CR_Response_Collection == undefined) {
                changedNote.CR_Response_Collection = [];
            }

            var newResponses = [];

            Ext.each(responseItems, function (resp) {

                if (resp.getStatus() == 'new') {

                    operationType = 'add';
                    var respId = resp.getResponseId();

                    if (respId === undefined) {

                        var cr_response = self.createResponse(self.getNoteId(), resp.response, changedNote.data.ExtId);
                        cr_response.data.extRespId = resp.id;
                        cr_response.data.TS_CR = new Date();
                        cr_response.data.TS_UP = new Date();
                        cr_response.data.LastModifiedDate = new Date();
                        cr_response.data.ID_CR = userId;
                        cr_response.data.ID_UP = userId;
                        cr_response.data.LastModifiedUserID = userId;
                        cr_response.data.status = 'new';

                        var oldResp = responseColl.filter(function (respObj) {
                            return respObj.extRespId == resp.id;
                        });
                        
                        if (oldResp.length == 0) {
                            cr_response.data.status = 'stored';
                            resp.setStatus('stored');

                            var parms = {};

                            parms['note'] = changedNote;
                            parms['response'] = cr_response;
                            parms['noteType'] = self.getNoteType();
                            parms['itemCode'] = self.getItemCode();

                            updateResponseCollection(parms);
                            newResponses.push(cr_response.data);
                        }                        
                    }
                }
            });                        
        }

        if (operationType == 'delete') {
            // Response deletion
            if (!Ext.isEmpty(changedNote)) {

                if (!Ext.isEmpty(changedNote.CR_Response_Collection)) {

                    if (changedNote.CR_Response_Collection.length > 0) {

                        if (!Ext.isEmpty(responses)) {

                            if (changedNote.CR_Response_Collection.length > responses.length) {

                                var oldRespColl = changedNote.CR_Response_Collection;
                                changedNote.CR_Response_Collection = [];

                                var responsesToKeep = oldRespColl.filter(function (respObj) {

                                    return !(respObj.ResponseID == responseToDelete.responseId &&
                                             respObj.Description == responseToDelete.response);
                                });

                                if (responsesToKeep.length > 0) {

                                    Ext.each(responsesToKeep, function (resp) {

                                        changedNote.CR_Response_Collection.push(resp);
                                    });                                    
                                }
                            }
                        }

                        updateNoteCollection(changedNote.ItemID, changedNote);
                    }
                }
            }            
        }

        return changedNote;
    },
    save: function () {

        // Get store reference
        var self = this;

        var noteStore = self.getStore('note');
        var responseStore = self.getStore('response');

        var responses = self.getResponseItems();

        responses = Ext.isEmpty(responses) ? undefined : Ext.isEmpty(responses.items) ? responses : responses.items;
        var noteId = self.getNoteId() === undefined ? 0 : self.getNoteId();
        
        if (noteId == 0) {

            self.setNoteId(0);
        }

        // Update note
        var itemCode = self.ownerCt.ownerCt.getItemCode();

        if (self.getNoteType() == 'item') {

            itemCode = self.getItemCode() == undefined ? itemCode : self.getItemCode();

            if (!Ext.isEmpty(itemCode)) {

                self.setItemCode(itemCode);

                if (noteStore.length == 0) {

                    noteStore = self.getStore('note');
                }
            }
        }

        var changedNote = self.updateNote(noteStore, noteId, itemCode);
        
        // Update responses
        changedNote = self.updateResponse(changedNote, responses, self.responseToDelete);

        // Update response items
        responses = self.getResponseItems() === undefined ? undefined : self.getResponseItems().items;

        if (!(responses === undefined)) {
            Ext.each(responses.items, function (noteResponse) {
                if (noteResponse.getStatus() == 'new') {

                    Ext.each(changedNote.data.CR_Response_Collection, function (cr_response) {

                        if (cr_response.extRespId == noteResponse.id) {

                            noteResponse.status = 'stored';
                            noteResponse.extRespId = cr_response.ExtId;
                            noteResponse.parentId = changedNote.ExtId === undefined ? changedNote.data.ExtId : changedNote.ExtId;                            
                        }
                    });
                }
            });
        }
        
        self.setResponseItems(responses);

        //
        // Persist to database
        //
        silentSave = true;

        initializeResultsContainer();

        getAppController().saveData();
    },
    items:
    [
        {
            xtype: 'displayfield',
            itemId: 'titleDisplay',
            width: '25%',
            margin: '5 0 0 10',
            listeners: {
                beforerender: function () {

                    var title = this.up().getSubject();

                    this.setValue("<span class='note-header'>" + title + "</span>");
                }
            }
        },
        {
            xtype: 'container',
            layout: 'hbox',
            itemId: 'titleEditCharContainer',
            componentCls: 'hide-element',
            items: [
                {
                    xtype: 'container',
                    bodyCls: 'panel-background-color',
                    border: false,
                    margin: '10 20 0 60',
                    layout: 'hbox',
                    items: [
                        {
                            xtype: 'container',
                            bodyCls: 'panel-background-color',
                            border: false,
                            margin: '0 10 0 360',
                            layout: 'hbox',
                            items: [
                                {
                                    xtype: 'displayfield',
                                    padding: 0,
                                    value: '<strong>No. of characters remaining: </strong>'
                                },
                                {
                                    xtype: 'displayfield',
                                    margin: '0 10 0 10',
                                    itemId: 'titleEditCharCounter',
                                    value: '0'
                                }
                            ]
                        }
                    ]
                }
            ]
        },
        {
            xtype: 'container',
            itemId: 'titleContainer',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '-10 10 0 10',
            layout: 'hbox',
            html: '<strong>Title</strong>',
            componentCls: 'hide-element',
            items: [                
                {
                    xtype: 'textfield',
                    width: '39.5%',
                    margin: '5 20 0 70',
                    itemId: 'titleEdit',
                    allowBlank: false,
                    msgTarget: 'under',
                    maxLength: 100,
                    listeners: {
                        change: function (inputElem, newValue, oldValue, eOpts) {
                            
                            // Get parent container
                            var container = this.findParentByType('reviewNote');
                            var charsRemaining = inputElem.maxLength - newValue.length;

                            container.queryById('titleEditCharCounter').setValue(charsRemaining);
                        }
                    }
                }
            ]
        },
        {
            xtype: 'container',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '10 10 0 10',
            layout: 'hbox',
            items: [
                {
                    xtype: 'component',
                    bodyCls: 'panel-background-color',
                    border: false,
                    html: '<strong>Date Modified: </strong>',
                    margin: '0 10 0 0'
                },
                {
                    xtype: 'displayfield',
                    length: 30,
                    margin: '5 20 0 0',
                    listeners: {
                        beforerender: function () {

                            var createDate = this.up('container').up().getCreateDate();
                            var formattedDate = Ext.Date.format(createDate, 'm/d/Y');

                            this.setValue(formattedDate);
                        }
                    }
                },
                {
                    xtype: 'component',
                    bodyCls: 'panel-background-color',
                    border: false,
                    html: '<strong>Modified By: </strong>'
                },
                {
                    xtype: 'displayfield',
                    length: 50,
                    margin: '5 0 0 10',
                    listeners: {
                        beforerender: function () {

                            var creator = this.up('container').up().getCreateBy();

                            this.setValue(creator);
                        }
                    }
                },
                {
                    xtype: 'component',
                    bodyCls: 'panel-background-color',
                    border: false,
                    html: '<strong>Resolved: </strong>',
                    margin: '0 10 0 20'
                },
                {
                    xtype: 'displayfield',
                    itemId: 'resolvedText',
                    length: 30,
                    margin: '5 0 0 0',                    
                    listeners: {
                        beforerender: function () {

                            var resolved = this.up('container').up().getResolved();

                            if (resolved) {
                                this.setValue("Yes");
                            } else {
                                this.setValue("<span class='text-color-red'>No</span>");
                            }
                        }
                    }
                }
            ]
        },
        {
            xtype: 'displayfield',
            itemId: 'commentsDisplay',
            width: '40%',
            margin: '5 0 0 10',
            listeners: {
                beforerender: function () {

                    var content = this.up().getText();

                    this.setValue(content);
                }
            }
        },
        {
            xtype: 'container',
            layout: 'hbox',
            itemId: 'commentsEditCharContainer',
            componentCls: 'hide-element',
            items: [
                {
                    xtype: 'container',
                    bodyCls: 'panel-background-color',
                    border: false,
                    margin: '20 20 0 60',
                    layout: 'hbox',
                    items: [
                        {
                            xtype: 'container',
                            bodyCls: 'panel-background-color',
                            border: false,
                            margin: '0 10 0 360',
                            layout: 'hbox',
                            items: [
                                {
                                    xtype: 'displayfield',
                                    padding: 0,
                                    value: '<strong>No. of characters remaining: </strong>'
                                },
                                {
                                    xtype: 'displayfield',
                                    margin: '0 10 0 10',
                                    itemId: 'commentsEditCharCounter',
                                    value: '0'
                                }
                            ]
                        }
                    ]
                }
            ]
        },
        {
            xtype: 'container',
            itemId: 'commentsContainer',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '-5 10 0 10',
            layout: 'hbox',
            html: '<strong>Comments</strong>',
            componentCls: 'hide-element',
            items: [
                 {
                     xtype: 'textarea',
                     itemId: 'commentsEdit',
                     width: '40%',
                     margin: '5 20 0 70',
                     allowBlank: false,
                     msgTarget: 'under',
                     maxLength: 10000,
                     grow: true,
                     growMin: 75,
                     growMax: 250,
                     //vtype: 'alphanum',
                     listeners: {
                         change: function (inputElem, newValue, oldValue, eOpts) {

                             // Get parent container
                             var container = this.findParentByType('reviewNote');
                             var charsRemaining = inputElem.maxLength - newValue.length;

                             container.queryById('commentsEditCharCounter').setValue(charsRemaining);
                         }
                     }
                 },
                 {
                     xtype: 'button',
                     text: 'Cancel',
                     width: 80,
                     height: 25,
                     margin: '5 10 10 -10',
                     listeners: {
                         click: {
                             element: 'el',
                             fn: function () {
                                 // Get parent container
                                 var container = this.component.findParentByType('reviewNote');

                                 // Erase changes
                                 container.queryById('titleEdit').setValue('');
                                 container.queryById('commentsEdit').setValue('');

                                 // Display and hide needed elements
                                 container.queryById('titleDisplay').setStyle('display', 'block');
                                 container.queryById('titleContainer').setStyle('display', 'none');
                                 container.queryById('titleEditCharContainer').setStyle('display', 'none');

                                 container.queryById('commentsDisplay').setStyle('display', 'block');
                                 container.queryById('commentsContainer').setStyle('display', 'none');
                                 container.queryById('commentsEditCharContainer').setStyle('display', 'none');

                                 // Refresh after change in content
                                 container.updateLayout();
                             }
                         }
                     }
                 },
                 {
                     xtype: 'button',
                     text: 'Save',
                     width: 80,
                     height: 25,
                     margin: '5 10 10 0',
                     listeners: {
                         click: {
                             element: 'el',
                             fn: function () {
                                 // Get parent container
                                 var container = this.component.findParentByType('reviewNote');

                                 // Update subject
                                 var newSubject = container.queryById('titleEdit').getValue();
                                 container.queryById('titleDisplay').setValue(newSubject);
                                 container.setSubject(newSubject);

                                 // Update comments
                                 var newComments = container.queryById('commentsEdit').getValue();
                                 container.queryById('commentsDisplay').setValue(newComments);
                                 container.setText(newComments);

                                 // Erase changes
                                 container.queryById('titleEdit').setValue('');
                                 container.queryById('commentsEdit').setValue('');

                                 // Display and hide needed elements
                                 container.queryById('titleDisplay').setStyle('display', 'block');
                                 container.queryById('titleContainer').setStyle('display', 'none');
                                 container.queryById('titleEditCharContainer').setStyle('display', 'none');

                                 container.queryById('commentsDisplay').setStyle('display', 'block');
                                 container.queryById('commentsContainer').setStyle('display', 'none');
                                 container.queryById('commentsEditCharContainer').setStyle('display', 'none');

                                 // Refresh after change in content
                                 container.updateLayout();

                                 // Update note store
                                 container.save();

                                 //buildCaseNotesCollection();
                             }
                         }
                     }
                 }
            ]
        },       
        {
            xtype: 'container',
            itemId: 'responseItems',
            margin: '0 0 10 0',
            items: 
            {
                xtype: 'container',
                listeners: {
                    beforerender: function () {

                        var responseItems = this.up().up().getResponseItems();

                        if (responseItems) {
                            var index = this.up().up().items.length - 2;

                            this.up().up().insert(index,responseItems);
                        }
                    }
                }
            }                       
        },
        {
            xtype: 'container',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '0 10 0 10',
            layout: 'hbox',
            items: [
                {
                    xtype: 'button',
                    text: 'Respond',
                    width: 80,
                    height: 25,
                    margin: '0 10 10 0',
                    listeners: {
                        afterrender: function(cmp, eOpts){

                            // Get parent container
                            var container = this.ownerCt.findParentByType('reviewNote');

                            if (Ext.isEmpty(container.getNoteId())) {

                                this.disable();
                            }
                        },
                        click: {
                            element: 'el',
                            fn: function () {

                                // Get parent container
                                var container = this.component.findParentByType('reviewNote');

                                if (container.getNoteId() > 0) {

                                    container.queryById('responseContainer').setStyle('display', 'block');

                                    // Refresh after change in content
                                    container.updateLayout();
                                }                            
                            }
                        }
                    }
                },
                {
                    xtype: 'button',
                    text: 'Edit',
                    width: 80,
                    height: 25,
                    icon: editButtonImage,
                    margin: '0 10 10 0',
                    listeners: {
                        click: {
                            element: 'el',
                            fn: function () {
                                // Get parent container
                                var container = this.component.findParentByType('reviewNote');

                                container.setStatus('changed');

                                // Prepare content to be edited
                                var subject = container.getSubject();
                                container.queryById('titleEdit').setValue(subject);

                                var comments = container.getText();
                                container.queryById('commentsEdit').setValue(comments);
                                
                                // Display and hide needed elements
                                container.queryById('titleDisplay').setStyle('display','none');
                                container.queryById('titleContainer').setStyle('display', 'block');
                                container.queryById('titleEditCharContainer').setStyle('display', 'block');
                                
                                container.queryById('commentsDisplay').setStyle('display', 'none');
                                container.queryById('commentsContainer').setStyle('display', 'block');
                                container.queryById('commentsEditCharContainer').setStyle('display', 'block');

                                // Refresh after change in content
                                container.updateLayout();
                            }
                        }
                    }
                },
                {
                    xtype: 'button',
                    text: 'Delete',
                    width: 80,
                    height: 25,
                    icon: deleteButtonImage,
                    margin: '0 10 10 0',
                    listeners: {
                        click: function () {

                            var container = this.up().up().ownerCt;
                            var note = this.up().up();

                            // Delete items from the container
                            if (!(note === undefined))
                            {
                                note.removeFromStore(note);

                                container.remove(note, true);

                                //
                                // Persist to database
                                //
                                silentSave = true;

                                initializeResultsContainer();

                                getAppController().saveData();

                                //buildCaseNotesCollection();
                            }

                            // Save note changes to store
                            //container.container.component.findParentByType('reviewNote').save();
                        }
                    }
                },
                {
                    xtype: 'container',
                    bodyCls: 'panel-background-color',
                    border: false,
                    margin: '0 10 0 0',
                    layout: 'vbox',
                    items: [
                        {
                            xtype: 'button',
                            itemId: 'resolvedBut',
                            text: 'Resolve',
                            width: 90,
                            height: 25,
                            margin: '0 10 10 0',
                            listeners: {
                                afterrender: function (cmp, eOpts) {

                                    // Get parent container
                                    var container = this.ownerCt.findParentByType('reviewNote');

                                    if (Ext.isEmpty(container.getNoteId())) {

                                        this.disable();
                                    }
                                },
                                click: {
                                    element: 'el',
                                    fn: function () {
                                        // Get parent container
                                        var container = this.component.findParentByType('reviewNote');

                                        if (container.getNoteId() > 0) {

                                            var resolved = container.getResolved();

                                            if (resolved) {
                                                container.queryById('resolvedText').setValue("<span class='text-color-red'>No</span>");
                                                container.setResolved(false);
                                                container.queryById('unresolvedBut').setStyle('display', 'none');
                                                this.setStyle('display', 'block');
                                            } else {
                                                container.queryById('resolvedText').setValue("Yes");
                                                container.setResolved(true);
                                                container.queryById('unresolvedBut').setStyle('display', 'block');
                                                this.setStyle('display', 'none');
                                            }

                                            // Refresh after change in content
                                            container.updateLayout();

                                            // Update note store
                                            container.setStatus('changed');

                                            container.save();
                                        }
                                    }
                                }
                            }
                        },
                        {
                            xtype: 'button',
                            itemId: 'unresolvedBut',
                            text: 'UnResolve',
                            width: 90,
                            height: 25,
                            margin: '-35 10 10 0',
                            componentCls: 'hide-element',
                            listeners: {
                                beforerender: {
                                    element: 'el',
                                    fn: function () {

                                        // Get parent container
                                        var container = this.component.findParentByType('reviewNote');
                                        var resolved = container.getResolved();

                                        if (resolved) {
                                            container.queryById('resolvedBut').setStyle('display', 'none');
                                            this.setStyle('display', 'block');
                                        }
                                    }
                                },
                                click: {
                                    element: 'el',
                                    fn: function () {
                                        // Get parent container
                                        var container = this.component.findParentByType('reviewNote');

                                        var resolved = container.getResolved();

                                        if (resolved) {
                                            container.queryById('resolvedText').setValue("<span class='text-color-red'>No</span>");
                                            container.setResolved(false);
                                            container.queryById('resolvedBut').setStyle('display', 'block');
                                            this.setStyle('display', 'none');
                                        } else {
                                            container.queryById('resolvedText').setValue("Yes");
                                            container.setResolved(true);
                                            container.queryById('resolvedBut').setStyle('display', 'none');
                                            this.setStyle('display', 'block');
                                        }

                                        // Refresh after change in content
                                        container.updateLayout();

                                        // Update note store
                                        container.setStatus('changed');

                                        container.save();
                                    }
                                }
                            }
                        }
                    ]
                }
            ]
        },
        //******************************************************************************
        // Response creation
        //******************************************************************************        
        {
            xtype: 'panel',
            bodyCls: 'panel-background-color',
            itemId: 'responseContainer',
            margin: '0 20 0 0',
            componentCls: 'hide-element',
            items: [
                {
                    xtype: 'container',
                    bodyCls: 'panel-background-color',
                    border: false,
                    margin: '10 20 10 10',
                    layout: 'hbox',            
                    items: [
                        {
                            xtype: 'component',
                            bodyCls: 'panel-background-color',
                            border: false,
                            html: '<strong>Type in response below:</strong>',
                            margin: '0 20 0 10'
                        },
                        {
                            xtype: 'container',
                            bodyCls: 'panel-background-color',
                            border: false,
                            margin: '0 10 0 170',
                            layout: 'hbox',
                            items: [
                                {
                                    xtype: 'displayfield',
                                    padding: 0,
                                    value: '<strong>No. of characters remaining: </strong>'
                                },
                                {
                                    xtype: 'displayfield',
                                    margin: '0 10 0 10',
                                    itemId: 'noteRespCounter',
                                    value: '0'
                                }
                            ]
                        }
                    ]
                },                
                {
                    xtype: 'container',
                    bodyCls: 'panel-background-color',
                    border: false,
                    margin: '5 20 10 10',
                    layout: 'hbox',            
                    items: [                        
                        {
                            xtype: 'textarea',
                            itemId: 'responseCreate',
                            width: '40%',
                            margin: '0 20 0 0',
                            allowBlank: false,
                            msgTarget: 'under',
                            maxLength: 10000,
                            grow: true,
                            growMin: 75,
                            growMax: 250,
                            //vtype: 'alphanum',
                            listeners: {
                                beforerender: function (inputElem, eOpts) {

                                    var container = this.findParentByType('reviewNote');
                                    container.queryById('noteRespCounter').setValue(inputElem.maxLength);
                                },
                                change: function (inputElem, newValue, oldValue, eOpts) {

                                    var container = this.findParentByType('reviewNote');
                                    var charsRemaining = inputElem.maxLength - newValue.length;

                                    container.queryById('noteRespCounter').setValue(charsRemaining);
                                }
                            }
                        },                        
                        {
                            xtype: 'button',
                            text: 'Cancel',
                            width: 80,
                            height: 25,
                            margin: '0 10 10 -10',
                            listeners: {
                                click: {
                                    element: 'el',
                                    fn: function () {
                                        // Get parent container
                                        var container = this.component.findParentByType('reviewNote');

                                        // Erase changes
                                        container.queryById('responseCreate').setValue('');

                                        // Display and hide needed elements
                                        container.queryById('responseContainer').setStyle('display', 'none');

                                        // Refresh after change in content
                                        container.updateLayout();
                                    }
                                }
                            }
                        },
                        {
                            xtype: 'button',
                            text: 'Save',
                            width: 80,
                            height: 25,
                            margin: '0 10 10 0',
                            listeners: {
                                click: {
                                    element: 'el',
                                    fn: function () {
                                        // Get parent container
                                        var container = this.component.findParentByType('reviewNote');

                                        // Get the responses
                                        var responses = container.query('listPanel')[0];
                                         
                                        var newResp = container.queryById('responseCreate').getValue();

                                        // Get current user
                                        var loggedInUser = GetLoggedInUser();
                                        var currentUser = loggedInUser.getFullname() + ' (' + loggedInUser.getCaseRole() + ')';
                                        
                                        var noteResp = App.CaseReview.view.common.noteResponse.create({
                                            createDate: new Date(),
                                            createBy: currentUser,
                                            response: newResp,
                                            status: 'new',
                                            noteType: container.getNoteType()
                                        });
                                         
                                        if (responses === undefined) {
                                            responses = framework.ListPanel.create({
                                                border: 'true',
                                                baseCls: 'x-panel panel-background-list-note',
                                                title: "<div class='html-content-header-margins'>Responses [SHOW]</div>",
                                                margin: '20 20 20 10',
                                                padding: '0 0 0 0'
                                            });

                                            container.setResponseItems(undefined);
                                        }

                                        responses.add(noteResp);
                                         
                                        if (container.getResponseItems() === undefined) {

                                            container.setResponseItems(responses);
                                            var index = container.items.length - 2;

                                            container.insert(index, responses);
                                        }

                                        // Erase saved content
                                        container.queryById('responseCreate').setValue('');

                                        // Display and hide needed elements
                                        container.queryById('responseContainer').setStyle('display', 'none');

                                        // Refresh after change in content
                                        container.updateLayout();

                                        // Update note store
                                        container.save();
                                    }
                                }
                            }
                        }
                    ]
                }
            ]
        }        
    ]
});