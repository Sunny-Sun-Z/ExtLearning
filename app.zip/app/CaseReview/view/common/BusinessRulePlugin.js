﻿Ext.define('App.CaseReview.view.common.BusinessRulePlugin', {
    extend: 'Ext.plugin.Abstract',
    alias: 'plugin.businessRulePlugin',
    config: {
        rules: [],
        getBlankRecords: function (columns, store) {

            var items = store.data.items;
            var blankRecords = [];

            Ext.each(items, function (item) {
                var isEmpty = true;

                Ext.each(columns, function (column) {
                    if (!(item.data[column] == 0 || item.data[column] == "" || item.data[column] == null)) {

                        isEmpty = false;
                        return false;
                    }
                });

                if (isEmpty) {
                    blankRecords.push(item);
                }
            });

            return blankRecords;
        },
        evaluateFields: function () {

            var self = this;
            var bRules = this.getRules();

            Ext.each(bRules, function (bRule) {
                                
                if (!(bRule.fields[0].storeId == undefined) || !(bRule.storeId == null))  {
                    Ext.each(bRule.fields, function (rField) {

                        if (rField.eType == 'lookup') {

                            var store = Ext.data.StoreManager.lookup(rField.storeId);

                            store.each(function (record) {
                                Ext.each(record.fields, function (field) {
                                    if (field.name == rField.fieldName) {
                                        rField.fieldValue = record.get(rField.fieldName);

                                        return false;
                                    }
                                });
                            });
                        }                        

                        if (rField.eType == 'function') {

                            var store = Ext.data.StoreManager.lookup(rField.storeId);
                            
                            var blankRecords = self.getBlankRecords(this.columns, store);

                            switch (rField.functionName) {
                                case "count":

                                    rField.fieldValue = store.count() - blankRecords.length;

                                    break;

                                default:

                                    rField.fieldValue = store.count() - blankRecords.length;
                            }
                        }

                        if (rField.eType == 'fieldVal') { }

                    });
                }                
            });
        },        
        evaluateRules: function(){

            // Update fields
            this.evaluateFields();

            var rules = this.getRules();

            // Evaluate rules
            Ext.each(rules, function (rule) {

                var variables = '';

                // Declare needed variables
                rule.fields.forEach(function (field) {
                    variables += 'var ' + field.fieldName + ' = ' + JSON.stringify(field) + ';';
                });

                variables += 'var result = false;';

                // Evaluate rule and determine result
                var ruleEval = variables + " if (" + rule.predicate + "){ result = true;} return result;";

                var func = new Function(ruleEval);

                rule.evalResult = func();
            });

            this.evalResult();
        },
        action: {},
        evalResult: function () {

            var rules = this.getRules();
            var ruleCheckResult = '';
            var validityCheckResult = '';
            this.rulesEvalResult = false;

            // Evaluate rules
            Ext.each(rules, function (rule) {
                      
                if (rule.rType == 'validityCheck') {
                    validityCheckResult += rule.evalResult + ' ' + (rule.joinChar == undefined ? '' : rule.joinChar);
                }
                
                if (rule.rType == 'ruleCheck') {
                    ruleCheckResult += rule.evalResult + ' ' + (rule.joinChar == undefined ? '' : rule.joinChar);
                }

            });

            // Get result for validity check
            var validityResult = false;
            var func;
            var variables = 'var result = false;';
            var rulesResult = variables + "if (" + validityCheckResult + "){ result = true;} return result;";

            if (validityCheckResult.trim().length > 0)
            {
                func = new Function(rulesResult);
                validityResult = func();
            }
            
            // Get result for rule check
            rulesResult = variables + "if (" + ruleCheckResult + "){ result = true;} return result;";

            if (ruleCheckResult.trim().length > 0)
            {
                func = new Function(rulesResult);
                ruleResult = func();
            }

            var evalResult = '{ "validityResult":' + validityResult + ', "ruleResult":' + ruleResult + '}';

            this.rulesEvalResult = JSON.parse(evalResult);
        },
        rulesEvalResult: undefined,
        columns: []
    },
    isInHomeCase: function () {

        var store = Ext.data.StoreManager.lookup('CaseReviewStore');
        var result = false;

        if (store.data.length > 0) {
            var caseTypeId = store.getAt(0).data.ReviewSubTypeID;

            if (caseTypeId == 17 || caseTypeId == 19 || caseTypeId == 21 || caseTypeId == 22) {
                result = true;
            }
        }

        return result;
    },
    isFosterCareCase: function () {

        var store = Ext.data.StoreManager.lookup('CaseReviewStore');
        var result = false;

        if (store.data.length > 0) {
            var caseTypeId = store.getAt(0).data.ReviewSubTypeID;

            if (caseTypeId == 18 || caseTypeId == 20) {
                result = true;
            }
        }

        return result;
    },
    runBusinessRules: function () {

        this.evaluateRules();
        var result = this.getRulesEvalResult();

        var actions = this.getAction();

        Ext.each(actions, function (action) {

            if (action.type == 'ruleCheck') {
                for (var key in action) {

                    if (action[key] == result.ruleResult) {

                        result.ruleResult = key;
                    }
                }
            }

            if (action.type == 'validityCheck') {
                for (var key in action) {

                    if (action[key] == result.validityResult) {

                        result.validityResult = key;
                    }
                }
            }
        });
    },
    init: function (cmp) {

        this.setCmp(cmp);

        this.runBusinessRules();
    }
});