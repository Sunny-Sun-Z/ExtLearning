﻿Ext.define('App.CaseReview.view.common.PDHealthHelper',
{
    extend: 'Ext.window.Window',
    itemId: 'pdHealthHelper',
    title: 'Physical and Dental Health',
    width: 650,
    layout: 'vbox',
    onShow: function() {
        // Needed for EXT5
        this.callParent(arguments);
        this.center();
    },
    getDockedItems: function (selector, beforeBody) {
        var layout = this.getComponentLayout();
        if (layout.getDockedItems) {
            var dockedItems = layout.getDockedItems('render', beforeBody);
            if (selector && dockedItems.length) {
                dockedItems = Ext.ComponentQuery.query(selector, dockedItems);
            }
            return dockedItems;
        }
        else {
            return [];
        }
    },
    scrollable: true,
    shrinkWrap: true,
    modal: true,
    bodyStyle: 'background:#fff;',
    closeAction: 'destroy',
    items: [
    {
        xtype: 'form',
        itemId: 'pdHealthHelperEdit',
        margin: 15,
        layout: 'vbox',
        border: false,
        items: [

        {
            xtype: 'textarea',
            itemId: 'healthNeeds',
            fieldLabel: 'Identified Physical or Dental Health Needs',
            labelWidth: 150,
            width: 600,
            maxLength: 4100,
            enforceMaxLength: true,
            name: 'HealthNeeds',
            allowBlank: false,
            msgTarget: 'side',
            blankText: 'You have not entered any identified physical or dental health needs. Please enter identified physical or dental health needs or enter None'

        },
        {
            xtype: 'textarea',
            itemId: 'servicesProvided',
            fieldLabel: 'Services Provided',
            labelWidth: 150,
            width: 600,
            maxLength: 4100,
            enforceMaxLength: true,
            name: 'ServicesProvided',
            allowBlank: false,
            msgTarget: 'side',
            blankText: 'You have not entered any services provided. Please enter services provided or enter None'

        },
        {
            xtype: 'textarea',
            itemId: 'servicesNeededNotProvided',
            fieldLabel: 'Services Needed but Not Provided',
            labelWidth: 150,
            width: 600,
            maxLength: 4100,
            enforceMaxLength: true,
            name: 'ServicesNeededNotProvided',
            allowBlank: false,
            msgTarget: 'side',
            blankText: 'You have not entered any services needed but not provided. Please enter services needed but not provided or enter None.'

        },
        {
              xtype: 'hiddenfield',
              itemId: 'healthNeedCode',
              name: 'HealthNeedCode',
              value : 1

          },
        {
                xtype: 'container',
                layout: 'hbox',
                items: [
                    {
                        xtype: 'button',
                        flex: 1,
                        align: 'right',
                        width: '100px',
                        text: 'Cancel',
                        itemId: 'unitCancel',
                        margin: '15 0 0 170',
                        padding: '5 5 5 5',
                        icon: window.baseUrl + '/content/icons/cross-small.png'
                    }, {
                        xtype: 'button',
                        flex: 1,
                        align: 'right',
                        style: 'float:right',
                        width: '150px',
                        text: 'Add/Update',
                        itemId: 'unitSave',
                        margin: '15 0 0 10',
                        padding: '5 5 5 5',
                        icon: window.baseUrl + '/content/icons/database_add.png'
                    }

                ]
            }]
    }
    ]

});