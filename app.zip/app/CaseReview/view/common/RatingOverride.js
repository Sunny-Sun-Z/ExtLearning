﻿Ext.define('App.CaseReview.view.common.RatingOverride', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ratingOverride',
    bodyCls: 'panel-background-color',
    margin: '0 20 20 20',
    border: true,
    config: {
        overrideInd: undefined,
        overrideRating: undefined,
        overrideOutcomeRating: undefined,
        overrideReason: undefined,
        itemNo: undefined,
        itemCode: undefined,
        ratingComponentId: undefined,
        outcomeRatingComponentId: undefined,
        page: undefined,
        currentRating: undefined,
        validate: false,
        validationResult: undefined,
        outcomeCode: undefined
    },
    validateRating: function () {
        var self = this;
        var result = [];
        var vResult = {};

        var rating = self.getOverrideRating();

        // When overriding item 16, an overridden outcome rating must be selected as well. 
        if (self.getItemNo() == '16' && (!(self.isOutcomeRatingSelected()))) {
            if (vResult.rowNumber == undefined) {
                vResult['page'] = self.getPage();
            }

            vResult['item'] = 'Item' + self.getItemNo();
            vResult['message'] = 'Please select an Overriden outcome rating.';

            result.push(vResult);

            vResult = {};
        }

        return result;
    },
    isOutcomeRatingSelected: function () {

        var self = this;
        var result = false;

        var outcomeRating = self.getOverrideOutcomeRating();

        if (!(outcomeRating == undefined)) {
            result = true;
        }

        return result;
    },
    recalculateRating: function (cmp, recalcNeeded, input) {
        var self = this;
        var iValue = cmp.inputValue;

        // Recalculate rating
        var ratingOverride = App.CaseReview.view.common.RatingOverride.create({
            overrideInd: cmp.ownerCt.ownerCt.getOverrideInd(),
            overrideRating: iValue,
            overrideReason: cmp.ownerCt.ownerCt.getOverrideReason(),
            itemNo: cmp.ownerCt.ownerCt.getItemNo(),
            itemCode: cmp.ownerCt.ownerCt.getItemCode(),
            page: cmp.ownerCt.ownerCt.getPage(),
            ratingComponentId: cmp.ownerCt.ownerCt.getRatingComponentId(),
            outcomeRatingComponentId: cmp.ownerCt.ownerCt.getOutcomeRatingComponentId()
        });

        var componentId = ratingOverride.getRatingComponentId();
        var ratingCmp = getCRSComponent(componentId);

        if (!(ratingCmp == undefined)) {

            var ratingCalculator = App.CaseReview.view.common.itemRating.create({
                itemCode: ratingCmp.getItemCode(),
                page: ratingCmp.getPage(),
                itemName: ratingCmp.getItemName(),
                changesExist: true,
                recalcNeeded: recalcNeeded,
                ratingOverride: ratingOverride,
                outcomeCode: ratingCmp.getOutcomeCode(),
                userInput: input
            });

            var rating = ratingCalculator.calculateRating();

            // Display updated item rating
            ratingCmp.setValue(rating.CodeDescription);

            // Update current rating
            self.setCurrentRating(rating.RatingCode);

            // Calculate outcome rating            
            var outcomeRating = updateOutcomeRating('#' + ratingOverride.ratingComponentId, '#' + ratingOverride.getItemId(), input);
        }
    },
    getItemInput: function(itemNo){

        var self = this;
        var userInput = null;

        switch (itemNo) {
            case '1':

                userInput = self.getItem1Input();
                break;

            case '2':

                userInput = self.getItem2Input();
                break;

            case '3':

                userInput = self.getItem3Input();
                break;

            case '4':

                userInput = self.getItem4Input();
                break;

            case '5':

                userInput = self.getItem5Input();
                break;

            case '6':

                userInput = self.getItem6Input();
                break;

            case '7':

                userInput = self.getItem7Input();
                break;

            case '8':

                userInput = self.getItem8Input();
                break;

            case '9':

                userInput = self.getItem9Input();
                break;

            case '10':

                userInput = self.getItem10Input();
                break;

            case '11':

                userInput = self.getItem11Input();
                break;

            case '12':

                userInput = self.getItem12Input();
                break;

            case '12A':

                userInput = self.getItem12AInput();
                break;

            case '12B':

                userInput = self.getItem12BInput();
                break;

            case '12C':

                userInput = self.getItem12CInput();
                break;

            case '13':

                userInput = self.getItem13Input();
                break;

            case '14':

                userInput = self.getItem14Input();
                break;

            case '15':

                userInput = self.getItem15Input();
                break;

            case '16':

                userInput = self.getItem16Input();
                break;

            case '17':

                userInput = self.getItem17Input();
                break;

            case '18':

                userInput = self.getItem18Input();
                break;

            default:

                break;
        }

        return userInput;
    },
    //=============================================
    // Safety tab items
    //=============================================
    getItem1Input: function () {

        var userInput = {};
        var question1a = {};
        var question1b = {};
        var beyondAgencyControl = {};
        var itemApplicable;

        var safetyStore = chainedStore('CR_Safety_CollectionStore');

        if (safetyStore.data.length > 0) {

            question1a['value'] = safetyStore.getAt(0).data.ReportsNotInAccordance;
            question1b['value'] = safetyStore.getAt(0).data.FaceToFaceReportsNotInAccordance;
            beyondAgencyControl['value'] = safetyStore.getAt(0).data.IsDelayBeyondAgencyControl;
            itemApplicable = isCaseApplicable(2, 1);
        }
        
        userInput['ReportsNotInAccordance'] = question1a.value;
        userInput['FaceToFaceReportsNotInAccordance'] = question1b.value;
        userInput['IsDelayBeyondAgencyControl'] = beyondAgencyControl.value;

        userInput['ItemApplicable'] = (itemApplicable) ? 'Yes' : itemApplicable == false ? 'No' : undefined;
        userInput['Item1Applicable'] = (itemApplicable) ? 'Yes' : itemApplicable == false ? 'No' : undefined;

        return userInput;
    },
    getItem2Input: function () {

        var userInput = {};
        var question2A;
        var question2B;
        var itemApplicable;

        var safetyStore = chainedStore('CR_Safety_CollectionStore');

        if (safetyStore.data.length > 0) {

            question2A = safetyStore.getAt(0).data.IsEffortToPreventReEntry;
            question2B = safetyStore.getAt(0).data.IsChildRemovedToEnsureSafety;
            itemApplicable = isCaseApplicable(3, 2);
        }

        userInput['Answer2A'] = question2A == 1 ? 'Yes' : question2A == 2 ? 'No' : '';
        userInput['Answer2B'] = question2B == 1 ? 'Yes' : question2B == 2 ? 'No' : question2B == 3 ? 'NA' : '';

        userInput['ItemApplicable'] = (itemApplicable) ? 'Yes' : itemApplicable == false ? 'No' : undefined;
        userInput['Item2Applicable'] = (itemApplicable) ? 'Yes' : itemApplicable == false ? 'No' : undefined;

        return userInput;
    },
    getItem3Input: function () {

        var userInput = {};
        var question3A;
        var question3B;
        var question3C;
        var question3D;
        var question3E;
        var question3F;
        var itemApplicable;

        var safetyStore = chainedStore('CR_Safety_CollectionStore');

        if (safetyStore.data.length > 0) {

            question3A = safetyStore.getAt(0).data.IsInitialAssesmentForAllChildrenInHome;
            question3B = safetyStore.getAt(0).data.IsOngoingAssesementForAllChildrenInHome;
            question3C = safetyStore.getAt(0).data.IsSafetyPlanDevelopedAndMonitored;
            question3D = safetyStore.getAt(0).data.IsSafetyConcernForOtherChildren;
            question3E = safetyStore.getAt(0).data.IsFosterSafetyConcernDuringVisitation;
            question3F = safetyStore.getAt(0).data.IsFosterSafetyConcernNotAddressed;
            itemApplicable = isCaseApplicable(4, 2);
        }

        userInput['Answer3A'] = question3A == 1 ? 'Yes' : question3A == 2 ? 'No' : question3A == 3 ? 'NA' : '';
        userInput['Answer3B'] = question3B == 1 ? 'Yes' : question3B == 2 ? 'No' : question3B == 3 ? 'NA' : '';
        userInput['Answer3C'] = question3C == 1 ? 'Yes' : question3C == 2 ? 'No' : question3C == 3 ? 'NA' : '';
        userInput['Answer3D'] = question3D == 1 ? 'Yes' : question3D == 2 ? 'No' : question3D == 3 ? 'NA' : '';
        userInput['Answer3E'] = question3E == 1 ? 'Yes' : question3E == 2 ? 'No' : question3E == 3 ? 'NA' : '';
        userInput['Answer3F'] = question3F == 1 ? 'Yes' : question3F == 2 ? 'No' : question3F == 3 ? 'NA' : '';

        userInput['ItemApplicable'] = true;
        userInput['Item3Applicable'] = (itemApplicable) ? 'Yes' : itemApplicable == false ? 'No' : undefined;

        return userInput;
    },
    //=============================================
    // Permanency tab items
    //=============================================
    getItem4Input: function () {

        var userInput = {};
        var question4A;
        var question4B;
        var question4C;
        var itemApplicable;

        var permanencyStore = chainedStore('CR_Permanency_CollectionStore');

        var placementStore = chainedStore('CR_Placement_CollectionStore');

        if (permanencyStore.data.length > 0) {

            question4A = permanencyStore.getAt(0).data.NumberOfPlacementSettings;
            question4B = permanencyStore.getAt(0).data.wereAllPlacementChangesPlanned;
            question4C = permanencyStore.getAt(0).data.IsCurrentPlacementSettingStable;
            itemApplicable = isCaseApplicable(5, 3);
        }

        userInput['Answer4A'] = question4A == 0 ? 1 : question4A == undefined ? placementStore.count() : question4A;
        userInput['Answer4B'] = question4B == 1 ? 'Yes' :
                                question4B == 2 ? 'No' :
                                question4B == 3 ? 'NA' : '';
        userInput['Answer4C'] = question4C == 1 ? 'Yes' :
                                question4C == 2 ? 'No' :
                                question4C == 3 ? 'NA' : '';

        userInput['Item4Applicable'] = (itemApplicable) ? 'Yes' : itemApplicable == false ? 'No' : undefined;

        return userInput;
    },
    getItem5Input: function () {

        var userInput = {};
        var question5A3;
        var question5B;
        var question5C;
        var question5D;
        var question5E;
        var question5F;
        var question5G;
        var itemApplicable;

        var permanencyStore = chainedStore('CR_Permanency_CollectionStore');

        if (permanencyStore.data.length > 0) {

            question5A3 = permanencyStore.getAt(0).data.IsGoalSpecified;
            question5B = permanencyStore.getAt(0).data.wereAllGoalsInTimelyManner;
            question5C = permanencyStore.getAt(0).data.wereAllGoalsAppropriate;
            question5D = permanencyStore.getAt(0).data.IsInFoster15OutOf22;
            question5E = permanencyStore.getAt(0).data.meetsTerminationOfParentalRights;
            question5F = permanencyStore.getAt(0).data.IsAgencyJointTerminationOfParentalRights;
            question5G = permanencyStore.getAt(0).data.IsExceptionForTermination;

            itemApplicable = isCaseApplicable(6, 3);
        }

        userInput['Answer5A3'] = question5A3 == 1 ? 'Yes' :
                                 question5A3 == 2 ? 'No' :
                                 question5A3 == 3 ? 'NA' : '';
        userInput['Answer5B'] =  question5B == 1 ? 'Yes' :
                                 question5B == 2 ? 'No' :
                                 question5B == 3 ? 'NA' : '';
        userInput['Answer5C'] =  question5C == 1 ? 'Yes' :
                                 question5C == 2 ? 'No' : '';
        userInput['Answer5D'] =  question5D == 1 ? 'Yes' :
                                 question5D == 2 ? 'No' : '';
        userInput['Answer5E'] =  question5E == 1 ? 'Yes' :
                                 question5E == 2 ? 'No' :
                                 question5E == 3 ? 'NA' : '';
        userInput['Answer5F'] =  question5F == 1 ? 'Yes' :
                                 question5F == 2 ? 'No' :
                                 question5F == 3 ? 'NA' : '';
        userInput['Answer5G'] =  question5G == 1 ? 'Yes' :
                                 question5G == 2 ? 'No' :
                                 question5G == 3 ? 'NA' : '';

        userInput['Item5Applicable'] = (itemApplicable) ? 'Yes' :
                                        itemApplicable == false ? 'No' : undefined;

        return userInput;
    },
    getItem6Input: function () {

        var userInput = {};
        var question6B;
        var question6C;
        var itemApplicable;

        var permanencyStore = chainedStore('CR_Permanency_CollectionStore');

        if (permanencyStore.data.length > 0) {

            question6B = permanencyStore.getAt(0).data.IsAgencyConcertedEfforts;
            question6C = permanencyStore.getAt(0).data.IsOtherPlannedConcertedEffort;

            itemApplicable = isCaseApplicable(7, 3);
        }

        userInput['Answer6B'] =  question6B == 1 ? 'Yes' :
                                 question6B == 2 ? 'No' :
                                 question6B == 3 ? 'NA' : '';
        userInput['Answer6C'] =  question6C == 1 ? 'Yes' :
                                 question6C == 2 ? 'No' :
                                 question6C == 3 ? 'NA' : '';

        userInput['ItemApplicable'] = true;
        userInput['Item6Applicable'] = 'Yes';

        return userInput;
    },
    getItem7Input: function () {

        var userInput = {};
        var question7A;
        var question7B;
        var itemApplicable;

        var permanencyStore = chainedStore('CR_Permanency_CollectionStore');

        if (permanencyStore.data.length > 0) {

            question7A = permanencyStore.getAt(0).data.IsPlacedWithAllSiblings;
            question7B = permanencyStore.getAt(0).data.IsValidReasonForSeparation;

            itemApplicable = isCaseApplicable(8, 4);
        }

        userInput['Answer7A'] =  question7A == 1 ? 'Yes' :
                                 question7A == 2 ? 'No' : '';
        userInput['Answer7B'] =  question7B == 1 ? 'Yes' :
                                 question7B == 2 ? 'No' :
                                 question7B == 3 ? 'NA' : '';
        userInput['Item7Applicable'] = (itemApplicable) ? 'Yes' :
                                        itemApplicable == false ? 'No' : undefined;

        return userInput;
    },
    getItem8Input: function () {

        var userInput = {};
        var question8A;
        var question8B;
        var question8C;
        var question8D;
        var question8E;
        var question8F;
        var itemApplicable;

        var permanencyStore = chainedStore('CR_Permanency_CollectionStore');

        if (permanencyStore.data.length > 0) {

            question8A = permanencyStore.getAt(0).data.IsSufficientFrequencyForMotherVisitation;
            question8B = permanencyStore.getAt(0).data.IsSufficientFrequencyForFatherVisitation;
            question8C = permanencyStore.getAt(0).data.IsSufficientQualityForMotherVisitation;
            question8D = permanencyStore.getAt(0).data.IsSufficentQualityForFatherVisitation;
            question8E = permanencyStore.getAt(0).data.IsSufficientFrequencyForSiblingVisitation;
            question8F = permanencyStore.getAt(0).data.IsSufficentQualityForSiblingVisitation;

            itemApplicable = isCaseApplicable(9, 4);
        }

        userInput['Answer8A'] =  question8A == 1 ? 'Yes' :
                                 question8A == 2 ? 'No' :
                                 question8A == 3 ? 'NA' : '';

        userInput['Answer8B'] =  question8B == 1 ? 'Yes' :
                                 question8B == 2 ? 'No' :
                                 question8B == 3 ? 'NA' : '';

        userInput['Answer8C'] =  question8C == 1 ? 'Yes' :
                                 question8C == 2 ? 'No' :
                                 question8C == 3 ? 'NA' : '';

        userInput['Answer8D'] =  question8D == 1 ? 'Yes' :
                                 question8D == 2 ? 'No' :
                                 question8D == 3 ? 'NA' : '';

        userInput['Answer8E'] =  question8E == 1 ? 'Yes' :
                                 question8E == 2 ? 'No' :
                                 question8E == 3 ? 'NA' : '';

        userInput['Answer8F'] =  question8F == 1 ? 'Yes' :
                                 question8F == 2 ? 'No' :
                                 question8F == 3 ? 'NA' : '';

        userInput['Item8Applicable'] = (itemApplicable) ? 'Yes' :
                                        itemApplicable == false ? 'No' : undefined;

        return userInput;
    },
    getItem9Input: function () {

        var userInput = {};
        var question9A;
        var question9C;
        var question9D;
        var itemApplicable;

        var permanencyStore = chainedStore('CR_Permanency_CollectionStore');

        if (permanencyStore.data.length > 0) {

            question9A = permanencyStore.getAt(0).data.IsConcertedEffortsForImportantConnections;
            question9C = permanencyStore.getAt(0).data.IsTribeProvidedTimelyNotification;
            question9D = permanencyStore.getAt(0).data.IsAccordanceWithIndianChildWelfareAct;

            itemApplicable = isCaseApplicable(10, 4);
        }

        userInput['Answer9A'] =  question9A == 1 ? 'Yes' :
                                 question9A == 2 ? 'No' : '';
        userInput['Answer9C'] =  question9C == 1 ? 'Yes' :
                                 question9C == 2 ? 'No' :
                                 question9C == 3 ? 'NA' : '';
        userInput['Answer9D'] =  question9D == 1 ? 'Yes' :
                                 question9D == 2 ? 'No' :
                                 question9D == 3 ? 'NA' : '';
        
        userInput['Item9Applicable'] = (itemApplicable) ? 'Yes' :
                                        itemApplicable == false ? 'No' : undefined;

        return userInput;
    },
    getItem10Input: function () {

        var userInput = {};
        var question10A1;
        var question10A2;
        var question10B;
        var question10C;
        var itemApplicable;

        var permanencyStore = chainedStore('CR_Permanency_CollectionStore');

        if (permanencyStore.data.length > 0) {

            question10A1 = permanencyStore.getAt(0).data.IsRecentPlacementWithRelative;
            question10A2 = permanencyStore.getAt(0).data.IsPlacementWithRelativeStable;
            question10B = permanencyStore.getAt(0).data.IsConcertedEffortToLocateMaternalRelatives;
            question10C = permanencyStore.getAt(0).data.IsConcertedEffortToLocatePaternalRelatives;

            itemApplicable = isCaseApplicable(11, 4);
        }

        userInput['Answer10A1'] = question10A1 == 1 ? 'Yes' :
                                  question10A1 == 2 ? 'No' : '';
        userInput['Answer10A2'] = question10A2 == 1 ? 'Yes' :
                                  question10A2 == 2 ? 'No' :
                                  question10A2 == 3 ? 'NA' : '';
        userInput['Answer10B'] =  question10B == 1 ? 'Yes' :
                                  question10B == 2 ? 'No' :
                                  question10B == 3 ? 'NA' : '';
        userInput['Answer10C'] =  question10C == 1 ? 'Yes' :
                                  question10C == 2 ? 'No' :
                                  question10C == 3 ? 'NA' : '';

        userInput['Item10Applicable'] = (itemApplicable) ? 'Yes' :
                                        itemApplicable == false ? 'No' : undefined;

        return userInput;
    },
    getItem11Input: function () {

        var userInput = {};
        var question11A;
        var question11B;
        var itemApplicable;

        var permanencyStore = chainedStore('CR_Permanency_CollectionStore');

        if (permanencyStore.data.length > 0) {

            question11A = permanencyStore.getAt(0).data.IsConcertedEffortMotherFosterRelationship;
            question11B = permanencyStore.getAt(0).data.IsConcertedEffortFatherFosterRelationship;

            itemApplicable = isCaseApplicable(12, 4);
        }

        userInput['Answer11A'] =  question11A == 1 ? 'Yes' :
                                  question11A == 2 ? 'No' :
                                  question11A == 3 ? 'NA' : '';
        userInput['Answer11B'] =  question11B == 1 ? 'Yes' :
                                  question11B == 2 ? 'No' :
                                  question11B == 3 ? 'NA' : '';
        userInput['Item11Applicable'] = (itemApplicable) ? 'Yes' :
                                        itemApplicable == false ? 'No' : undefined;

        return userInput;
    },
    //=============================================
    // Wellbeing tab items
    //=============================================
    getItem12Input: function () {

        var userInput12A = this.getItem12AInput();
        var userInput12B = this.getItem12BInput();
        var userInput12C = this.getItem12CInput();
        var userInput = {};

        userInput['UserInput12A'] = userInput12A;
        userInput['UserInput12B'] = userInput12B;
        userInput['UserInput12C'] = userInput12C;

        return userInput;
    },
    getItem12AInput: function () {

        var userInput = {};
        var question12A1;
        var question12A2;

        var wellbeingStore = chainedStore('CR_WellBeing_CollectionStore');

        if (wellbeingStore.data.length > 0) {

            question12A1 = wellbeingStore.getAt(0).data.IsComprehensiveAssessementConducted;
            question12A2 = wellbeingStore.getAt(0).data.IsAppropriateServicesProvided;
        }

        userInput['Answer12A1'] = question12A1 == 1 ? 'Yes' :
                                  question12A1 == 2 ? 'No' : '';
        userInput['Answer12A2'] = question12A2 == 1 ? 'Yes' :
                                  question12A2 == 2 ? 'No' :
                                  question12A2 == 3 ? 'NA' : '';

        userInput['ItemApplicable'] = true;
        userInput['Item12Applicable'] = 'Yes';

        return userInput;
    },
    getItem12BInput: function () {

        var userInput = {};
        var question12B1;
        var question12B2;
        var question12B3;
        var question12B4;
        var itemApplicableMother;
        var itemApplicableFather;

        var wellbeingStore = chainedStore('CR_WellBeing_CollectionStore');

        if (wellbeingStore.data.length > 0) {

            question12B1 = wellbeingStore.getAt(0).data.IsComprehensiveAssessementForMotherConducted;
            question12B2 = wellbeingStore.getAt(0).data.IsComprehensiveAssessementForFatherConducted;
            question12B3 = wellbeingStore.getAt(0).data.IsAppropriateServicesForMotherProvided;
            question12B4 = wellbeingStore.getAt(0).data.IsAppropriateServicesForFatherProvided;
        }

        var controller = getAppController();

        var applicableMotherYes = controller.getItem12BApplicableMotherYes();
        var applicableMotherNo = controller.getItem12BApplicableMotherNo();
        var applicableFatherYes = controller.getItem12BApplicableFatherYes();
        var applicableFatherNo = controller.getItem12BApplicableFatherNo();

        userInput['Answer12B1'] = question12B1 == 1 ? 'Yes' :
                                  question12B1 == 2 ? 'No' :
                                  question12B1 == 3 ? 'NA' : '';
        userInput['Answer12B2'] = question12B2 == 1 ? 'Yes' :
                                  question12B2 == 2 ? 'No' :
                                  question12B2 == 3 ? 'NA' : '';
        userInput['Answer12B3'] = question12B3 == 1 ? 'Yes' :
                                  question12B3 == 2 ? 'No' :
                                  question12B3 == 3 ? 'NA' : '';
        userInput['Answer12B4'] = question12B4 == 1 ? 'Yes' :
                                  question12B4 == 2 ? 'No' :
                                  question12B4 == 3 ? 'NA' : '';

        userInput['Item12BApplicableMother'] = (applicableMotherYes.value) ? 'Yes' :
                                               (applicableMotherNo.value) ? 'No' : undefined;
        userInput['Item12BApplicableFather'] = (applicableFatherYes.value) ? 'Yes' :
                                               (applicableFatherNo.value) ? 'No' : undefined;

        return userInput;
    },
    getItem12CInput: function () {

        var userInput = {};
        var question12C1;
        var question12C2;
        var itemApplicable;

        var wellbeingStore = chainedStore('CR_WellBeing_CollectionStore');

        if (wellbeingStore.data.length > 0) {

            question12C1 = wellbeingStore.getAt(0).data.IsNeedsOfFosterParentsAdequatelyAssessed;
            question12C2 = wellbeingStore.getAt(0).data.IsFosterParentsProvidedAppropriateServices;

            itemApplicable = isCaseApplicable(16, 5);
        }

        userInput['Answer12C1'] = question12C1 == 1 ? 'Yes' :
                                  question12C1 == 2 ? 'No' : '';
        userInput['Answer12C2'] = question12C2 == 1 ? 'Yes' :
                                  question12C2 == 2 ? 'No' :
                                  question12C2 == 3 ? 'NA' : '';
        userInput['Item12CApplicable'] = (itemApplicable) ? 'Yes' :
                                        itemApplicable == false ? 'No' : undefined;

        return userInput;
    },
    getItem13Input: function () {

        var userInput = {};
        var question13A;
        var question13B;
        var question13C;
        var itemApplicable;

        var wellbeingStore = chainedStore('CR_WellBeing_CollectionStore');

        if (wellbeingStore.data.length > 0) {

            question13A = wellbeingStore.getAt(0).data.IsAgencyConcertedEffortsToInvolveTheChild;
            question13B = wellbeingStore.getAt(0).data.IsAgencyConcertedEffortsToInvolveTheMother;
            question13C = wellbeingStore.getAt(0).data.IsAgencyConcertedEffortsToInvolveTheFather;

            itemApplicable = isCaseApplicable(17, 5);
        }

        userInput['Answer13A'] =  question13A == 1 ? 'Yes' :
                                  question13A == 2 ? 'No' :
                                  question13A == 3 ? 'NA' : '';
        userInput['Answer13B'] =  question13B == 1 ? 'Yes' :
                                  question13B == 2 ? 'No' :
                                  question13B == 3 ? 'NA' : '';
        userInput['Answer13C'] =  question13C == 1 ? 'Yes' :
                                  question13C == 2 ? 'No' :
                                  question13C == 3 ? 'NA' : '';
        userInput['Item13Applicable'] = (itemApplicable) ? 'Yes' :
                                        itemApplicable == false ? 'No' : undefined;

        return userInput;
    },
    getItem14Input: function () {

        var userInput = {};
        var question14A;
        var question14B;

        var wellbeingStore = chainedStore('CR_WellBeing_CollectionStore');

        if (wellbeingStore.data.length > 0) {

            question14A = wellbeingStore.getAt(0).data.IsResponsiblePartyVisitationFrequencySufficient;
            question14B = wellbeingStore.getAt(0).data.IsResponsiblePartyVisitationQualitySufficient;
        }

        userInput['Answer14A'] =  question14A == 1 ? 'Yes' :
                                  question14A == 2 ? 'No' : '';
        userInput['Answer14B'] =  question14B == 1 ? 'Yes' :
                                  question14B == 2 ? 'No' :
                                  question14B == 3 ? 'NA' : '';

        userInput['Item14Applicable'] = 'Yes';

        return userInput;
    },
    getItem15Input: function () {

        var userInput = {};
        var question15A2;
        var question15B2;
        var question15C;
        var question15D;
        var itemApplicable;

        var wellbeingStore = chainedStore('CR_WellBeing_CollectionStore');

        if (wellbeingStore.data.length > 0) {

            question15A2 = wellbeingStore.getAt(0).data.IsResponsiblePartyVisitationFrequencyWithMotherSufficient;
            question15B2 = wellbeingStore.getAt(0).data.IsResponsiblePartyVisitationFrequencyWithFatherSufficient;
            question15C = wellbeingStore.getAt(0).data.IsResponsiblePartyVisitationQualityWithMotherSufficient;
            question15D = wellbeingStore.getAt(0).data.IsResponsiblePartyVisitationQualityWithFatherSufficient;

            itemApplicable = isCaseApplicable(19, 5);
        }

        userInput['Answer15A2'] = question15A2 == 1 ? 'Yes' :
                                  question15A2 == 2 ? 'No' :
                                  question15A2 == 3 ? 'NA' : '';
        userInput['Answer15B2'] = question15B2 == 1 ? 'Yes' :
                                  question15B2 == 2 ? 'No' :
                                  question15B2 == 3 ? 'NA' : '';
        userInput['Answer15C'] =  question15C == 1 ? 'Yes' :
                                  question15C == 2 ? 'No' :
                                  question15C == 3 ? 'NA' : '';
        userInput['Answer15D'] =  question15D == 1 ? 'Yes' :
                                  question15D == 2 ? 'No' :
                                  question15D == 3 ? 'NA' : '';
        userInput['Item15Applicable'] = (itemApplicable) ? 'Yes' :
                                        itemApplicable == false ? 'No' : undefined;

        return userInput;
    },
    getItem16Input: function () {

        var userInput = {};
        var question16A;
        var question16B;
        var itemApplicable;

        var wellbeingStore = chainedStore('CR_WellBeing_CollectionStore');

        if (wellbeingStore.data.length > 0) {

            question16A = wellbeingStore.getAt(0).data.IsAgencyAssessEducationNeeds;
            question16B = wellbeingStore.getAt(0).data.IsAgencyAddressEducationNeeds;

            itemApplicable = isCaseApplicable(20, 6);
        }

        userInput['Answer16A'] =  question16A == 1 ? 'Yes' :
                                  question16A == 2 ? 'No' : '';
        userInput['Answer16B'] =  question16B == 1 ? 'Yes' :
                                  question16B == 2 ? 'No' :
                                  question16B == 3 ? 'NA' : '';
        userInput['Item16Applicable'] = (itemApplicable) ? 'Yes' :
                                        itemApplicable == false ? 'No' : undefined;

        return userInput;
    },
    getItem17Input: function () {

        var userInput = {};
        var question17A1;
        var question17A2;
        var question17B1;
        var question17B2;
        var question17B3;
        var itemApplicable;

        var wellbeingStore = chainedStore('CR_WellBeing_CollectionStore');

        if (wellbeingStore.data.length > 0) {

            question17A1 = wellbeingStore.getAt(0).data.IsAgencyAssessPhysicalHealthNeeds;
            question17A2 = wellbeingStore.getAt(0).data.IsAgencyAssessDentalHealthNeeds;
            question17B1 = wellbeingStore.getAt(0).data.IsFosterOversightMedicationForPhysicalHealtyAppropriate;
            question17B2 = wellbeingStore.getAt(0).data.IsAppropriateSerivcesForAllPhysicalHealthNeeds;
            question17B3 = wellbeingStore.getAt(0).data.IsAppropriateServicesForAllDentalNeeds;

            itemApplicable = isCaseApplicable(21, 7);
        }

        userInput['Answer17A1'] = question17A1 == 1 ? 'Yes' :
                                  question17A1 == 2 ? 'No' :
                                  question17A1 == 3 ? 'NA' : '';
        userInput['Answer17A2'] = question17A2 == 1 ? 'Yes' :
                                  question17A2 == 2 ? 'No' :
                                  question17A2 == 3 ? 'NA' : '';
        userInput['Answer17B1'] = question17B1 == 1 ? 'Yes' :
                                  question17B1 == 2 ? 'No' :
                                  question17B1 == 3 ? 'NA' : '';
        userInput['Answer17B2'] = question17B2 == 1 ? 'Yes' :
                                  question17B2 == 2 ? 'No' :
                                  question17B2 == 3 ? 'NA' : '';
        userInput['Answer17B3'] = question17B3 == 1 ? 'Yes' :
                                  question17B3 == 2 ? 'No' :
                                  question17B3 == 3 ? 'NA' : '';
        userInput['Item17Applicable'] = (itemApplicable) ? 'Yes' :
                                        itemApplicable == false ? 'No' : undefined;

        return userInput;
    },
    getItem18Input: function () {

        var userInput = {};
        var question18A;
        var question18B;
        var question18C;
        var itemApplicable;

        var wellbeingStore = chainedStore('CR_WellBeing_CollectionStore');

        if (wellbeingStore.data.length > 0) {

            question18A = wellbeingStore.getAt(0).data.IsAgencyAssessMentalHealthNeeds;
            question18B = wellbeingStore.getAt(0).data.IsFosterOversightMedicationForMentalHealtyAppropriate;
            question18C = wellbeingStore.getAt(0).data.IsAppropriateSerivcesForMentalHealthNeeds;

            itemApplicable = isCaseApplicable(22, 7);
        }

        userInput['Answer18A'] =  question18A == 1 ? 'Yes' :
                                  question18A == 2 ? 'No' : '';
        userInput['Answer18B'] =  question18B == 1 ? 'Yes' :
                                  question18B == 2 ? 'No' :
                                  question18B == 3 ? 'NA' : '';
        userInput['Answer18C'] =  question18C == 1 ? 'Yes' :
                                  question18C == 2 ? 'No' :
                                  question18C == 3 ? 'NA' : '';
        userInput['Item18Applicable'] = (itemApplicable) ? 'Yes' :
                                        itemApplicable == false ? 'No' : undefined;

        return userInput;
    },
    items:
    [
        {
            xtype: 'container',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '10 10 20 0',
            layout: 'hbox',
            items: [
                {
                    xtype: 'component',
                    bodyCls: 'panel-background-color',
                    border: false,
                    disabled : false,
                    html: 'Override this rating?'
                },
                {
                    xtype: 'checkbox',
                    margin: '-5 0 0 10',
                    inputValue: 1,
                    itemId: 'ratingOverrideCheckbox',
                    disabled: true,
                    listeners: {
                        beforerender: function () {
                            var self = this;
                            var ratingCmpId = self.ownerCt.ownerCt.getRatingComponentId();
                            var ratingCmp = getCRSComponent(ratingCmpId);
                            var itemStore = ratingCmp.getItemStore(ratingCmp.getItemCode());

                            // Get saved rating code
                            var item;

                            if (itemStore.data.length > 0) {
                                item = itemStore.getAt(0).data.CR_Item_Collection[0];
                            }

                            if (!(item == undefined)) {

                                var val = item.isRatingOverride;

                                self.up().up().setOverrideInd(val);

                                if (self.inputValue == val) {
                                    self.setValue(val);
                                    self.ownerCt.ownerCt.setCurrentRating(val);
                                }
                            }
                        },
                        change: function (currentObj, newValue, oldValue, eOpts) {
                            var self = this;

                            self.up().up().setOverrideInd(0);

                            if (currentObj.checked) {
                                self.up().up().setOverrideInd(1);
                            } else {
                                // Clear all values
                                var items = self.ownerCt.ownerCt.down('#newRating').items.items;

                                Ext.each(items, function (item) {

                                    item.setValue(false);

                                });

                                var itemNo = self.up().up().getItemNo();

                                var userInput = self.up().up().getItemInput(itemNo);
                                
                                if (!(userInput == null)) {
                                    self.up().up().recalculateRating(self, true, userInput);
                                }
                            }
                        }
                    }
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '20 0 10 0',
            bodyCls: 'panel-background-color',
            html: "Overridden rating:",
            disabled: true,
        },
        {
            xtype: 'container',
            itemId: 'newRating',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '10 10 10 0',
            layout: 'hbox',
            defaults: {
                listeners: {
                    beforerender: function () {
                        var self = this;
                        var ratingCmpId = self.ownerCt.ownerCt.getRatingComponentId();
                        var ratingCmp = getCRSComponent(ratingCmpId);
                        var itemStore = ratingCmp.getItemStore(ratingCmp.getItemCode());

                        // Get saved rating code
                        var item;

                        if (itemStore.data.length > 0) {
                            
                            item = itemStore.getAt(0).data.CR_Item_Collection.filter(function (itemObj) {
                                return (itemObj.ItemCode == ratingCmp.itemCode);
                            });
                        }

                        if (!(item == undefined)) {

                            var val;
                            var ratingOverridden;
                            var reason;

                            if (item.length > 0) {

                                val = item[0].OverriddenRatingCode;
                                ratingOverridden = item[0].isRatingOverride == 1 ? true : false;
                                reason = item[0].OverrideReason;
                            }
                            
                            self.up().up().setOverrideRating(val);

                            if (ratingOverridden) {
                                if (self.inputValue == val) {
                                    self.setValue(val);
                                    self.up().up().setOverrideReason(reason);
                                }
                            }
                        }
                    },
                    click: {
                        element: 'el',
                        fn: function () {
                            // Set all siblings to default value
                            var self = this;
                            var items = this.component.ownerCt.items.items;
                            var iValue = self.component.inputValue;

                            self.component.setValue(iValue);
                            this.component.ownerCt.ownerCt.setCurrentRating(iValue);

                            Ext.each(items, function (item) {
                                if (item.id != self.component.id) {
                                    item.setValue(false);
                                }
                            });

                            // Recalculate rating
                            self.component.ownerCt.ownerCt.recalculateRating(this.component, false);
                        }
                    }
                }
            },
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Strength</b>',
                    inputValue: 1,
                    disabled: true
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>Area Needing Improvement</b>',
                    inputValue: 2,
                    disabled: true
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>NA</b>',
                    inputValue: 3,
                    disabled: true
                }
            ]
        },
        {
            xtype: 'component',
            itemId: 'overriddenOutcomeRatingHdg',
            border: false,
            margin: '20 0 10 0',
            bodyCls: 'panel-background-color',
            html: "Overridden outcome rating:",
            listeners: {
                beforerender: function () {

                    var self = this.ownerCt;

                    if (!(self.getItemNo() == '16')) {

                        this.hide();
                    }
                }
            },
            disabled: true
        },
        {
            xtype: 'container',
            itemId: 'newOutcomeRating',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '10 10 0 0',
            layout: 'hbox',
            defaults: {
                listeners: {
                    beforerender: function () {

                        var self = this.ownerCt.ownerCt;

                        if (!(self.getItemNo() == '16')) {

                            this.hide();
                        }

                        var val = self.getOverrideOutcomeRating();

                        if (this.inputValue == val) {
                            this.setValue(val);
                        }

                        // Validate rating
                        var ratingResult = self.validateRating();
                    },
                    change: function (currentObj, newValue, oldValue, eOpts) {
                        // Set all siblings to default value

                        var items = this.up('container').items.items;

                        Ext.each(items, function (item) {
                            if (item.id != currentObj.id) {
                                item.setValue(false);
                            }
                        });
                    }
                }
            },
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Substantially Achieved</b>',
                    inputValue: 1,
                    disabled: true
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>Partially Achieved</b>',
                    inputValue: 2,
                    disabled: true
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>Not Achieved</b>',
                    inputValue: 3,
                    disabled: true
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>NA</b>',
                    inputValue: 4,
                    disabled: true
                }
            ]
        },
        {
            xtype: 'component',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '20 0 0 0',
            html: 'Override reason: ',
            disabled: true
        },
        {
            xtype: 'container',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '10 10 20 0',
            items: [
                {
                    xtype: 'textarea',
                    width: '75%',
                    grow: true,
                    growMin: 100,
                    growMax: 350,
                    listeners: {
                        beforerender: function () {

                            var ratingCmpId = this.up().up().getRatingComponentId();
                            var ratingCmp = getCRSComponent(ratingCmpId);
                            var itemCode = ratingCmp.getItemCode();
                            
                            var overrideElements = ratingCmp.getOverriddenElements(itemCode);

                            this.setValue(overrideElements.OverrideReason);
                        },
                        change: function () {

                            var ratingCmpId = this.up().up().getRatingComponentId();
                            var parent = getCRSComponent(ratingCmpId);
                            var overrideReason = this.getValue();
                            //var overrideRatingCode = this.up().up().getCurrentRating();
                            var overrideRatingCode = this.up().up().getOverrideRating();
                            var overrideInput = {};

                            overrideInput['RatingCode'] = overrideRatingCode;
                            overrideInput['OverrideReason'] = overrideReason;

                            parent.updateOverriddenElements(parent.getItemCode(), overrideInput);
                        }
                    },
                    disabled: true
                }
            ]
        }
    ]
});