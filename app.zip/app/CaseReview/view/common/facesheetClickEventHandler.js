﻿//
// This is the click event handler for the facesheet
//
var processFacesheetClick = function (input) {

    var controller = getAppController();

    var valueChanged = input.Component.isDirty();

    if (!valueChanged) {

        return;
    }

    var newValue = input.Component.getValue();

    if (pageLoadStatus['Facesheet'] == 'rendered') {

        if (newValue) {

            var selection = (newValue) ? input.Component.inputValue : 0,
                fields = [],
                field = {};

            field[input.FieldName] = selection;

            fields.push(field);

            field = { 'DataState': 0 };
            fields.push(field);

            if (input.FieldName == 'IsFosterEntryDateNA') {

                field = { 'FosterEntryDate': null };
                fields.push(field);
            }

            if (input.FieldName == 'IsEpisodeNotYetDischarged') {

                field = { 'EpisodeDischargeDate': null };
                fields.push(field);

                field = { 'IsEpisodeDischargeDateNA': null };
                fields.push(field);
            }

            if (input.FieldName == 'IsEpisodeDischargeDateNA') {

                field = { 'IsEpisodeNotYetDischarged': null };
                fields.push(field);

                field = { 'EpisodeDischargeDate': null };
                fields.push(field);
            }
            
            if (input.FieldName == 'IsCaseClosureNotClosed') {

                field = { 'CaseClosureDate': null };
                fields.push(field);
            }

            var parms = {
                currentVal: newValue,
                storeId: 'CR_FaceSheet_CollectionStore',
                fields: fields,
                itemName: 'facesheet',
                itemCode: 23,
                runValidations: true,
                dataChanged: true,
                vmFields: input.vmFields
            };
            
            if (!(layoutRuns.Facesheet)) {

                parms['allowLayout'] = true;
            }

            initValidations('Facesheet');

            runFacesheetRules(controller, input.ItemId, parms);

            if(FacesheetFunctions.saveEnabled){
                return;
            }

            if (!Ext.isEmpty(input.ParentForm)) {
                FacesheetFunctions.fireFocusEvent();
            }
        }
    }

    if (input.ItemId == 'dischargeNA_change') {
        
        // if its a foster care case
        var caseReviewStore = Ext.StoreManager.get('CaseReviewStore');
        var caseReviewSubType = caseReviewStore.getAt(0).data.ReviewSubTypeID;

        if (controller.getNotYetDischarged().checked) {
            controller.getQuestion6A3().setValue(controller.getNotYetDischarged().inputValue);
        } else {
            controller.getQuestion6A3().setValue(null);
        }
    }

    if (input.ItemId == 'notYetDischarged_change') {

        // if its a foster care case
        var caseReviewStore = Ext.StoreManager.get('CaseReviewStore');
        var caseReviewSubType = caseReviewStore.getAt(0).data.ReviewSubTypeID;

        if (controller.getNotYetDischarged().checked) {

            controller.getQuestion6A3().setValue(controller.getNotYetDischarged().inputValue);
            controller.getPermanencyDischargeDate().setValue(null);

        } else {

            controller.getQuestion6A3().setValue(null);
        }
    }
}
//
// Question M
//
var processQuestionMChange = function (cmp, oldValue) {

    var controller = getAppController();

    var valueChanged = cmp.isDirty();

    if (!valueChanged) {

        return;
    }

    var newValue = cmp.getValue();

    var validateOther = function () {

        var otherComments = controller.getQuestionMNarrative();

        otherComments.setValue(null);
        otherComments.disable();

        var fields = [],
            field = { 'OtherCaseReason': '' };

        fields.push(field);

        field = { 'DataState': 0 };
        fields.push(field);

        var parms = {
            currentVal: newValue,
            storeId: 'CR_FaceSheet_CollectionStore',
            fields: fields,
            itemName: 'facesheet',
            itemCode: 23,
            runValidations: true,
            dataChanged: true
        };

        initValidations('Facesheet');
        
        runFacesheetRules(controller, sr.Constants.AllFields, parms);
    };

    if (pageLoadStatus['Facesheet'] == 'rendered') {

        var parms = {
            itemName: 'facesheet',
            itemCode: 23,
            runValidations: true,
            dataChanged: true,
            groupMembers: getCodeDescriptionGroup('CaseReason')
        };

        var parms2 = getCheckboxSelections(newValue, 'CaseReason', 'MultiAnswer');

        parms = concatJsonObjects(parms, [parms2]);

        if (!(layoutRuns.Facesheet)) {

            parms['allowLayout'] = true;
        }

        initValidations('Facesheet');

        var result = getLastSelection(cmp, newValue, oldValue);
        var otherObj = {};

        if (result.length == 0) {

            if(isOtherUnchecked(newValue,oldValue)){

                validateOther();

            } else {
                
                runFacesheetRules(controller, 'questionM', parms);
            }
            
            return;
        }

        if (result[result.length - 1].itemId == 'caseRsn14') {

            var otherComments = controller.getQuestionMNarrative();

            if (newValue) {

                runFacesheetRules(controller, 'caseRsn14_change', parms);

                otherComments.enable();
                otherComments.setReadOnly(false);

            } else {

                validateOther();
            }

        } else {

            var otherComments = controller.getQuestionMNarrative();

            if (otherComments.getValue().length > 0) {

                var isCaseRsn14Selected = false;
                var updatedSelections = Ext.isEmpty(oldValue) ? {} : oldValue;
                var propertyId;

                Ext.each(result, function (selection) {

                    propertyId = selection.id;

                    updatedSelections[propertyId] = selection.inputValue;
                });

                var updatedKeys = Object.keys(updatedSelections);

                Ext.each(updatedKeys, function (key) {

                    if (updatedSelections[key] == 14) {

                        isCaseRsn14Selected = true;

                        return false;
                    }
                });

                if (!isCaseRsn14Selected) {

                    validateOther();
                }
            }

            runFacesheetRules(controller, 'questionM', parms);
        }
    }
}
var isOtherUnchecked = function (newSelection, oldSelection) {

    var unCheckedValue;
    var keys;

    var newKeys = Object.keys(newSelection);
    var oldKeys = Object.keys(oldSelection);

    if (newKeys.length < oldKeys.length) {

        Ext.each(oldKeys, function (oldKey) {

            keys = newKeys.filter(function (key) {

                return oldKey == key;
            });

            if (keys.length == 0) {

                unCheckedValue = oldSelection[oldKey];

                return false;
            }
        });

        if (unCheckedValue == 14) {

            return true;
        }
    }
    
    return false;    
}