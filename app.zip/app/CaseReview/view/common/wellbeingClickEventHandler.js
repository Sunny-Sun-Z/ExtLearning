﻿//
// This is the click event handler for the Wellbeing page
//
var processWellbeingClick = function (input) {

    var controller = getAppController();
    var selectedItem = getSelectedItem(input.Component);

    if (Ext.isEmpty(selectedItem)) {

        return;
    }

    var valueChanged = selectedItem.isDirty();

    if (!valueChanged) {

        return;
    }

    var newValue = selectedItem.getValue();

    if (pageLoadStatus['Wellbeing'] == 'rendered') {

        if (newValue) {

            var fields = [];
            var field = {};
            field[input.FieldName] = selectedItem.inputValue;

            fields.push(field);

            field = { 'DataState': 0 };
            fields.push(field);

            var parms = {
                currentVal: newValue,
                storeId: 'CR_WellBeing_Collection',
                fields: fields,
                control: input.Component,
                runValidations: true,
                dataChanged: true
            };

            parms = getStatusParms(parms, input.RatingItemId);

            initValidations(input.ItemName);

            var itemId = Ext.isEmpty(input.ItemId) ? selectedItem.itemId : input.ItemId;

            runWellbeingRules(controller, itemId, parms);
        }
    }
}
var processWellbeingItemApplicable = function (input) {

    var controller = getAppController();
    var selectedItem = getSelectedApplicableComponent(input.Component);

    if (Ext.isEmpty(selectedItem)) {

        return;
    }

    var valueChanged = selectedItem.isDirty();

    if (!valueChanged) {

        return;
    }

    var newValue = selectedItem.getValue();

    if (pageLoadStatus['Wellbeing'] == 'rendered') {

        if (newValue) {

            var parms = {
                control: input.Component,
                runValidations: true,
                dataChanged: true
            };
            var parms = getStatusParms(parms, input.RatingItemId);

            initValidations(input.ItemName);

            var itemId = Ext.isEmpty(input.ItemId) ? selectedItem.itemId : input.ItemId;

            if (selectedItem.inputValue == 2) {

                parms['ratingDefault'] = 'NA';

                runPermanencyRules(controller, itemId, parms)

                return;
            }

            runWellbeingRules(controller, itemId, parms);
        }
    }
}