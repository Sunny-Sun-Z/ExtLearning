﻿var ratingComponents = [];
var statusComponents = [];

var synchronizeRatings = function () {
    //
    // Sync Ratings if item is started
    //
    var itemNames = ['item1', 'item2', 'item3', 'item4', 'item5', 'item6', 'item7', 'item8', 'item9', 'item10', 'item11',
                    'item12A', 'item12B', 'item12C', 'item13', 'item14', 'item15', 'item16', 'item17', 'item18'];
    var parms = {};
    var retval;
    var itemObjRating, cachedRating;
    var ratingPropName;

    Ext.each(itemNames, function (itemName) {

        retval = isItemStarted(itemName);

        if (retval.itemStarted) {

            ratingPropName = itemName.replace('i', 'I') + 'Rating';
            itemObjRating = getCRSComponent(retval.questionObj.ratingItemId).getValue();
            cachedRating = itemRatings[ratingPropName];

            if (!(itemObjRating == cachedRating)) {

                var ratingParms = {
                    'RatingItemId': retval.questionObj.ratingItemId,
                    'RatingOverrideItemId': retval.questionObj.ratingItemId + 'Override',
                    'RatingItemName': itemName
                };

                calculateItemRating(ratingParms);
                //
                // Calculate Status
                //
                var container = getCRSComponent(retval.questionObj.containerId)
                var itemCodes = getItemCodeFromName(itemName);

                parms['itemCode'] = itemCodes.ItemCode;
                parms['outcomeCode'] = itemCodes.OutcomeCode;
                parms['itemName'] = itemName;

                updateItemStatus(container, parms);
            }
        }
    });

    updateCaseStatus();
};

var isItemStarted = function (itemName) {

    var itemQuestions;
    var result;
    var parms = {};

    var checkIfItemStarted = function () {

        var itemStarted = false;
        var questions;
        
        Ext.each(itemQuestions,function (item) {

            if (!Ext.isEmpty(item[itemName])) {

                questions = item[itemName];
                
                parms['questionObj'] = item;
                parms['questions'] = questions;

                return false;
            }
        });

        var keys;
        var objValue;

        Ext.each(questions, function (question) {

            keys = Object.keys(question);

            objValue = question[keys[0]];

            if (objValue['answered']) {

                itemStarted = true;

                return false;
            }
        });
                
        parms['itemStarted'] = itemStarted;

        return parms;
    }

    switch (itemName) {

        case 'item1':
        case 'item2':
        case 'item3':

            itemQuestions = safetyQuestions;

            result = checkIfItemStarted();

            break;

        case 'item4':
        case 'item5':
        case 'item6':
        case 'item7':
        case 'item8':
        case 'item9':
        case 'item10':
        case 'item11':

            itemQuestions = permanencyQuestions;

            result = checkIfItemStarted();

            break;

        case 'item12A':
        case 'item12B':
        case 'item12C':
        case 'item13':
        case 'item14':
        case 'item15':
        case 'item16':
        case 'item17':
        case 'item18':

            itemQuestions = wellbeingQuestions;

            result = checkIfItemStarted();

            break;

        default:

            break;
    }

    return result;
}