﻿Ext.define('App.CaseReview.view.common.itemRating', {
    extend: 'Ext.form.field.Display',
    alias: 'widget.itemRating',
    margin: '0 0 10 20',
    fieldCls: 'rating-style',
    initComponent: function() {
        this.callParent(arguments);
    },
    config: {
        itemCode: undefined,
        itemType: undefined,
        validate: true,
        validationResult: undefined,
        page: undefined,
        itemName: undefined,
        outcomeName: undefined,
        changesExist: false,
        recalcNeeded: false,
        recalcCompleted: false,
        ratingOverride: undefined,
        userInput: undefined,
        outcomeCode: undefined,
        ratingComments: undefined,
        msgComponentId: undefined,
        ratingContainerId: undefined,
        ratingResult: undefined
    },
    getRatingComments: function(itemCode){

        if (Ext.isEmpty(itemCode)) {

            return '';
        }

        var item = getItem(itemCode, getOutcomeCode(itemCode));

        if (!Ext.isEmpty(item)) {

            return item.RatingComments;
        }

        return '';
    },
    updateRatingComments: function (itemCode,comments) {

        if (Ext.isEmpty(itemCode)) {

            return;
        }

        var itemStore = this.getItemStore(itemCode);

        if (itemStore.data.length > 0) {

            var item = itemStore.getAt(0).data.CR_Item_Collection.filter(function (itemInList) {
                return (itemInList.ItemCode == itemCode);
            });

            item[0].RatingComments = comments;
        }
    },
    getOverriddenElements: function (itemCode) {

        var result = {};

        if (Ext.isEmpty(itemCode)) {

            return result;
        }
        
        var itemStore = this.getItemStore(itemCode);

        if (itemStore.data.length > 0) {
            
            var item = itemStore.getAt(0).data.CR_Item_Collection.filter(function (itemObj) {
                return (itemObj.ItemCode == itemCode);
            });

            if (item.length > 0) {

                result['RatingCode'] = item[0].OverriddenRatingCode;
                result['OverrideReason'] = item[0].OverrideReason;
            }            
        }

        return result;
    },
    updateOverriddenElements: function (itemCode, elements) {

        var itemStore = this.getItemStore(itemCode);

        if (Ext.isEmpty(itemStore)) {

            return;
        }

        if (itemStore.data.length > 0) {

            var item = itemStore.getAt(0).data.CR_Item_Collection.filter(function (itemObj) {
                return (itemObj.ItemCode == itemCode);
            });

            //item[0].OverriddenRatingCode = elements.RatingCode;
            item[0].OverrideReason = elements.OverrideReason;
        }
    },
    getItemRating: function () {

        var self = this;
        var result = {};
        var ratingCode = null;
        var overrideRatingCode = null;
        var rating;

        var item = getItem(this.itemCode, this.outcomeCode);

        if (Ext.isEmpty(item)) {

            result['CodeDescription'] = 'Not Yet Rated';

            return result;
        }

        ratingCode = item.ItemRatingCode;
        overrideRatingCode = item.OverriddenRatingCode;
        
        ratingCode = Ext.isEmpty(ratingCode) ? overrideRatingCode : ratingCode;

        if (Ext.isEmpty(ratingCode)) {


            var caseType = getCaseType();
            var ratingResult = self.getRatingResult();

            ratingResult = Ext.isEmpty(ratingResult) ? { 'CodeDescription': 'Not Yet Rated' } : ratingResult;

            if (self.itemCode == 16 && (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health')) {

                self.changesExist = true;
                self.setUserInput({});

                var recalcRating;

                if (!self.recalcCompleted) {

                    recalcRating = self.calculateRating();
                }

                rating = ratingResult['CodeDescription'];

                return ratingResult;

            } else {

                rating = ratingResult['CodeDescription'];

                self.setValue(rating);

                return ratingResult;
            }
        }

        result['RatingCode'] = ratingCode;
        
        if (Ext.isEmpty(ratingCode)) {

            rating = 'Unable to Rate';
        } else {

            if (ratingCode == 0) {

                rating = 'Not Yet Rated';
            } else {

                var itemRatingStore = Ext.data.ChainedStore.create({
                    source: 'ItemRatingStore',
                    filters: [
                        function (record) {
                            return record.data.GroupID == ratingCode;
                        }
                    ]
                });

                rating = itemRatingStore.data.length == 0 ? 'Unable to Rate' : itemRatingStore.getAt(0).data.DescriptionLarge;
            }
        }
                
        result['CodeDescription'] = rating;

        self.setValue(rating);
        
        // Validate Rating
        if (self.getValidate()) {
            var validationResult = self.validateRating();

            self.setValidationResult(validationResult);
        }

        return result;
    },
    getRatingText: function(){

        var self = this;
        var result = {};
        var ratingCode = null;
        var overrideRatingCode = null;
        var permanencyItemCodes = [5,6]

        var caseType = getCaseType();

        if ((self.itemCode > 4 && self.itemCode < 13) && (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health')) {

            result['CodeDescription'] = 'Not Applicable';

            return result;
        }

        var item = getItem(this.itemCode, this.outcomeCode);

        if (Ext.isEmpty(item)) {

            result['CodeDescription'] = 'Not Yet Rated';

            return result;
        }

        ratingCode = item.ItemRatingCode;
        overrideRatingCode = item.OverriddenRatingCode;

        ratingCode = Ext.isEmpty(ratingCode) ? overrideRatingCode : ratingCode;

        if (Ext.isEmpty(ratingCode)) {

            if (self.itemCode == 16 && (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health')) {

                self.changesExist = true;
                self.setUserInput({});

                var recalcRating;

                if (!self.recalcCompleted) {

                    recalcRating = self.calculateRating();
                }

                if (Ext.isEmpty(recalcRating)) {

                    recalcRating = 'Not Yet Rated';
                }

                result['CodeDescription'] = Ext.isEmpty(recalcRating.CodeDescription) ? recalcRating : recalcRating.CodeDescription;

                itemRatings['Item12CRating'] = result['CodeDescription'];

            } else {

                result['CodeDescription'] = self.getItemRating().CodeDescription;

                if (self.itemCode == 14) {

                    itemRatings['Item12ARating'] = result['CodeDescription'];
                }

                if (self.itemCode == 15) {

                    itemRatings['Item12BRating'] = result['CodeDescription'];
                }
            }
            
            return result;
        }

        result['RatingCode'] = ratingCode;

        var itemRatingStore = Ext.data.ChainedStore.create({
            source: 'ItemRatingStore',
            filters: [
                function (record) {
                    return record.data.GroupID == ratingCode;
                }
            ]
        });

        var rating;

        if (itemRatingStore.data.length == 0) {

            if (ratingCode == 0) {

                rating = 'Not Yet Rated';
            }

            if (ratingCode == 4) {

                rating = 'Unable to Rate';
            }
        } else {

            rating = itemRatingStore.getAt(0).data.DescriptionLarge;
        }

        result['CodeDescription'] = rating;

        if (self.itemCode == 14) {

            itemRatings['Item12ARating'] = result['CodeDescription'];
        }

        if (self.itemCode == 15) {

            itemRatings['Item12BRating'] = result['CodeDescription'];
        }

        if (self.itemCode == 16) {

            itemRatings['Item12CRating'] = result['CodeDescription'];
        }

        return result;
    },
    getItemStore: function (itemCode) {

        var inputObj = { storeId: 'CR_Outcome_CollectionStore', alternateId: 'OutcomeCode', alternateIdValue: this.getOutcomeCode() };

        var outcomeStore = getObjectStore(inputObj);

        if (outcomeStore.count() > 0) {

            if (outcomeStore.data.length > 0) {

                if (outcomeStore.getAt(0).data.CR_Item_Collection.length > 0) {

                    itemStore = Ext.data.ChainedStore.create({
                        source: outcomeStore,
                        filters: [
                            function (record) {

                                if (!Ext.isEmpty(record.data.CR_Item_Collection)) {

                                    var selectedRecord = record.data.CR_Item_Collection.filter(function (item) {

                                        if (item.ItemCode == itemCode) {
                                            return item;
                                        }
                                    });

                                    if (selectedRecord.length > 0) {

                                        return record;
                                    }
                                }
                            }
                        ]
                    });                    
                } else {
                    // Create item if needed  

                    var item = { ItemCode: itemCode, OutcomeCode: this.getOutcomeCode(), DataState: 0 };
                    updateItem(item);

                    var outcomeStore2 = getObjectStore(inputObj);

                    if (outcomeStore2.data.length > 0) {
                        if (outcomeStore2.getAt(0).data.CR_Item_Collection.length > 0) {

                            itemStore = Ext.data.ChainedStore.create({
                                source: outcomeStore2,
                                filters: [
                                    function (record) {

                                        if (!Ext.isEmpty(record.data.CR_Item_Collection)) {

                                            var selectedRecord = record.data.CR_Item_Collection.filter(function (item) {

                                                if (item.ItemCode == itemCode) {
                                                    return item;
                                                }
                                            });

                                            if (selectedRecord.length > 0) {

                                                return record;
                                            }
                                        }                                        
                                    }
                                ]
                            });
                        }
                    }                    
                }
            }            
        } else {

            // Create new Outcome, Item Collection
            var model = Ext.data.StoreManager.get(inputObj.storeId).add({});
            var item = { ItemCode: itemCode, OutcomeCode: this.getOutcomeCode(), DataState: 0 };

            model[0].set("OutcomeCode", this.getOutcomeCode());
            model[0].set("DataState", 0);
            model[0].set("CR_Item_Collection", [item]);

            var outcomeStore2 = getObjectStore(inputObj);

            if (outcomeStore2.data.length > 0) {
                if (outcomeStore2.getAt(0).data.CR_Item_Collection.length > 0) {

                    itemStore = Ext.data.ChainedStore.create({
                        source: outcomeStore2,
                        filters: [
                            function (record) {

                                if (!Ext.isEmpty(record.data.CR_Item_Collection)) {

                                    var selectedRecord = record.data.CR_Item_Collection.filter(function (item) {

                                        if (item.ItemCode == itemCode) {
                                            return item;
                                        }
                                    });

                                    if (selectedRecord.length > 0) {

                                        return record;
                                    }
                                }
                            }
                        ]
                    });
                }
            }
        }
        
        return itemStore;
    },
    getOutcomeRating: function (outcomeCode) {

        var self = this;
        var caseType = getCaseType();

        if (Ext.isEmpty(outcomeCode)) {

            return rating;
        }

        var getRatingCode = function () {

            var store = Ext.data.ChainedStore.create({
                source: 'CR_Outcome_CollectionStore',
                filters: [
                    function (record) {
                        return record.data.OutcomeCode == outcomeCode;
                    }
                ]
            });

            var outcomeRatingCode = null;

            if (store.data.length > 0) {

                outcomeRatingCode = store.data.items[0].data.OutcomeRatingCode;
            }

            return outcomeRatingCode;
        }
        
        if ((outcomeCode > 2 && outcomeCode < 5) && (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health')) {

            self.setValue('Not Applicable');

            return 'Not Applicable';
        }

        var outcomeRatingCode = getRatingCode();

        if (Ext.isEmpty(outcomeRatingCode)) {

            var parms = {};

            parms['OutcomeCode'] = outcomeCode;
            
            parms = this.getOutcomeCalculationParms(parms);

            outcomeRating = this.calculateOutcomeRating(parms);

            self.updateOutcomeStore(outcomeRating);

            outcomeRatingCode = getRatingCode();

            if (Ext.isEmpty(outcomeRatingCode)) {

                self.setValue('Not Yet Determined');

                return 'Not Yet Determined';
            }
        }

        var outcomeRatingStore = Ext.data.ChainedStore.create({
            source: 'OutComeRatingStore',
            filters: [
                function (record) {
                    return record.data.GroupID == outcomeRatingCode;
                }
            ]
        });

        var rating = outcomeRatingStore.data.length == 0 ? 'Not Yet Determined' : outcomeRatingStore.getAt(0).data.DescriptionLarge;
        
        self.setValue(rating);

        // Validate Rating
        if (self.getValidate()) {
            var validationResult = self.validateRating();

            self.setValidationResult(validationResult);
        }

        return rating;
    },
    getOutcomeRatingText: function (outcomeCode) {

        var self = this;
        var rating;
        var outcomeRatingCode = null;

        if (Ext.isEmpty(outcomeCode)) {

            return rating;
        }

        var caseType = getCaseType();

        if ((outcomeCode > 2 && outcomeCode < 5) && (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health')) {

            outcomeRatings.permanency.outcome1.ratingDescription = 'Not Applicable';
            outcomeRatings.permanency.outcome2.ratingDescription = 'Not Applicable';

            return 'Not Applicable';
        }

        var getRatingCode = function () {

            var store = Ext.data.ChainedStore.create({
                source: 'CR_Outcome_CollectionStore',
                filters: [
                    function (record) {
                        return record.data.OutcomeCode == outcomeCode;
                    }
                ]
            });

            var outcomeRatingCode = null;

            if (store.data.length > 0) {

                outcomeRatingCode = store.data.items[0].data.OutcomeRatingCode;
            }

            return outcomeRatingCode;
        }
        
        outcomeRatingCode = getRatingCode();

        if (Ext.isEmpty(outcomeRatingCode)) {

            var parms = {};

            parms['OutcomeCode'] = outcomeCode;

            parms = this.getOutcomeCalculationParms(parms);

            outcomeRating = this.calculateOutcomeRating(parms);

            self.updateOutcomeStore(outcomeRating);

            outcomeRatingCode = getRatingCode();

            if (Ext.isEmpty(outcomeRatingCode)) {

                rating = 'Not Yet Determined';

                return rating;
            }
        }

        var outcomeRatingStore = Ext.data.ChainedStore.create({
            source: 'OutComeRatingStore',
            filters: [
                function (record) {
                    return record.data.GroupID == outcomeRatingCode;
                }
            ]
        });

        var rating = outcomeRatingStore.data.length == 0 ? 'Not Yet Determined' : outcomeRatingStore.getAt(0).data.DescriptionLarge;
        
        return rating;
    },
    validateRating: function(){
        var self = this;
        var result = [];
        var vResult = {};

        var rating = self.getValue();

        // All questions within an item must be answered to generate a rating. 
        if (rating == 'Not Yet Rated' || 'Not Yet Determined') {

            if (Ext.isEmpty(vResult.rowNumber)) {
                vResult['page'] = self.getPage();
            }

            vResult['item'] = self.getItemName();
            vResult['message'] = 'Please complete all questions for this item to generate a rating.';

            result.push(vResult);

            vResult = {};
        }

        return result;
    },
    updateItemStore: function (ratingResult) {
        var self = this;
        var iCode = this.itemCode;
        var itemStore;
        var item;

        var inputObj = { objectType: 'item', outcomeCode: getOutcomeCode(iCode), DataState: 0, objValue: this };
        addCRSObject(inputObj);

        itemStore = this.getItemStore(iCode);

        if (itemStore.data.length > 0) {
            
            item = itemStore.getAt(0).data.CR_Item_Collection.filter(function (itemObj) {
                return (itemObj.ItemCode == iCode);
            });
        }

        if (ratingResult.isRatingOverride) {

            var overrideCmp = self.getRatingOverride();

            item[0].DataState = 0;
            item[0].OverriddenRatingCode = ratingResult.RatingCode;
            item[0].isRatingOverride = ratingResult.isRatingOverride;
            item[0].OverrideReason = overrideCmp.getOverrideReason();
            
            return;

        } else {

            if (Ext.isEmpty(ratingResult.RatingCode)) {

                if (!Ext.isEmpty(item)) {
                    item[0].DataState = 0;
                    item[0].ItemRatingCode = null;
                    item[0].isRatingOverride = ratingResult.isRatingOverride;
                }

                return;

            } else {

                if (!Ext.isEmpty(item)) {

                    item[0].DataState = 0;
                    item[0].ItemRatingCode = ratingResult.RatingCode;
                    item[0].isRatingOverride = ratingResult.isRatingOverride;
                }
            }
        }
    },
    updateOutcomeStore: function(ratingResult){

        var inputObj = { storeId: 'CR_Outcome_CollectionStore', alternateId: 'OutcomeCode', alternateIdValue: this.getOutcomeCode() };
        var outcomeStore = getObjectStore(inputObj);
        var outcome;
        var outcomeRatingCode;

        if (!(Ext.isEmpty(outcomeStore))) {

            if (outcomeStore.data.length > 0) {

                outcome = outcomeStore.getAt(0).data;
            }            
        }
        
        if (!(Ext.isEmpty(outcome))) {

            outcome.DataState = 0;
            outcome.OutcomeRatingCode = ratingResult.RatingCode;
        }
    },
    setItemRating: function(ratingDesc){
        var self = this;

        var userInput = self.getUserInput();
        var overrideCmp = self.getRatingOverride();
        var iCode = this.itemCode;
        var ratingResult;

        if (Ext.isEmpty(overrideCmp)) {

            return;
        }

        if (Ext.isEmpty(userInput)) {

            return;
        }

        var item = getItem(this.itemCode, this.outcomeCode);

        if (Ext.isEmpty(item)) {

            return;
        }

        if (!(item.IsApplicable == 1 || item.IsApplicable == 2) && ratingDesc == 'NA') {

            return;
        }

        var ratingCalculator = App.CaseReview.view.common.CRSRatingCalculator.create({});

        ratingResult = ratingCalculator.getRatingCode(ratingDesc);

        // Update item rating
        self.setValue(ratingDesc);

        self.updateItemStore(ratingResult);

        // Update outcome rating
        var outcomeRating = updateOutcomeRating('#' + overrideCmp.ratingComponentId, '#' + overrideCmp.getItemId(), userInput);

        self.updateOutcomeStore(outcomeRating);
    },
    calculateRating: function () {

        var self = this;
        var ratingCalculator;
        var userInput;
        var overrideCmp = self.getRatingOverride();
        var iCode = this.itemCode;
        var itemRating;

        if (Ext.isEmpty(overrideCmp)) {

            return itemRating;
        }
                
        if (self.getChangesExist()) {

            ratingCalculator = App.CaseReview.view.common.CRSRatingCalculator.create({});

            var itemNo = self.getItemName().replace('item', '');
            var iName = self.getItemName() + 'Rating';
            var uName = iName.replace('item', 'Item');

            userInput = overrideCmp.getItemInput(itemNo);

            if (Ext.isEmpty(userInput)) {
            
                userInput = {};
                userInput['ItemApplicable'] = undefined;
            }

            var item = getItem(overrideCmp.itemCode, overrideCmp.outcomeCode);

            userInput.ItemApplicable = Ext.isEmpty(item) ? undefined :
                                        item.IsApplicable == 1 ? 'Yes' :
                                        item.IsApplicable == 2 ? 'No' : undefined;

            ratingCalculator.setItemName(self.getItemName());
            ratingCalculator.setOutcomeName(self.getOutcomeName());
            ratingCalculator.setRatingOverride(self.getRatingOverride());
            ratingCalculator.setRecalcNeeded(self.getRecalcNeeded());
            ratingCalculator.setUserInput(userInput);

            var ratingResult = ratingCalculator.calculateRatingCode();

            ratingResult['CodeDescription'] = ratingResult.RatingDescription;

            self.setRatingResult(ratingResult);

            itemRatings[uName] = ratingResult.RatingDescription;

            self.updateItemStore(ratingResult);

            self.recalcCompleted = true;
        }
                
        itemRating = this.getItemRating();

        var outcomeRating = updateOutcomeRating('#' + overrideCmp.ratingComponentId, '#' + overrideCmp.getItemId(), userInput);

        self.updateOutcomeStore(outcomeRating);
        
        return itemRating;
    },
    //=============================================
    // Outcome rating calculations
    //=============================================
    calculateOutcomeRating: function(ratingInput){

        var outcomeRating;
        var ratingCalculator = App.CaseReview.view.common.CRSRatingCalculator.create({});

        switch (ratingInput.OutcomeCode) {

            case 1:

                outcomeRating = ratingCalculator.calculateSafetyOutcome1Rating(ratingInput);

                break;

            case 2:

                outcomeRating = ratingCalculator.calculateSafetyOutcome2Rating(ratingInput);

                break;

            case 3:

                outcomeRating = ratingCalculator.calculatePermanencyOutcome1Rating(ratingInput);

                break;

            case 4:

                outcomeRating = ratingCalculator.calculatePermanencyOutcome2Rating(ratingInput);

                break;

            case 5:

                outcomeRating = ratingCalculator.calculateWellbeingOutcome1Rating(ratingInput);

                break;

            case 6:

                outcomeRating = ratingCalculator.calculateWellbeingOutcome2Rating(ratingInput);

                break;

            case 7:

                outcomeRating = ratingCalculator.calculateWellbeingOutcome3Rating(ratingInput);

                break;

            default:

                break;
        }

        return outcomeRating;
    },
    getOutcomeCalculationParms:  function(parms){

        switch (parms.OutcomeCode) {

            case 1:

                parms['Item1Rating'] = Ext.isEmpty(itemRatings.Item1Rating) ? this.getSavedItemRating(2,1) : itemRatings.Item1Rating;

                break;

            case 2:

                parms['Item2Rating'] = Ext.isEmpty(itemRatings.Item2Rating) ? this.getSavedItemRating(3, 2) : itemRatings.Item2Rating;
                parms['Item3Rating'] = Ext.isEmpty(itemRatings.Item3Rating) ? this.getSavedItemRating(4, 2) : itemRatings.Item2Rating;

                break;

            case 3:

                parms['Item4Rating'] = Ext.isEmpty(itemRatings.Item4Rating) ? this.getSavedItemRating(5, 3) : itemRatings.Item4Rating;
                parms['Item5Rating'] = Ext.isEmpty(itemRatings.Item5Rating) ? this.getSavedItemRating(6, 3) : itemRatings.Item5Rating;
                parms['Item6Rating'] = Ext.isEmpty(itemRatings.Item6Rating) ? this.getSavedItemRating(7, 3) : itemRatings.Item6Rating;

                break;

            case 4:

                parms['Item7Rating'] = Ext.isEmpty(itemRatings.Item7Rating) ? this.getSavedItemRating(8, 4) : itemRatings.Item7Rating;
                parms['Item8Rating'] = Ext.isEmpty(itemRatings.Item8Rating) ? this.getSavedItemRating(9, 4) : itemRatings.Item8Rating;
                parms['Item9Rating'] = Ext.isEmpty(itemRatings.Item9Rating) ? this.getSavedItemRating(10, 4) : itemRatings.Item9Rating;
                parms['Item10Rating'] = Ext.isEmpty(itemRatings.Item10Rating) ? this.getSavedItemRating(11, 4) : itemRatings.Item10Rating;
                parms['Item11Rating'] = Ext.isEmpty(itemRatings.Item11Rating) ? this.getSavedItemRating(12, 4) : itemRatings.Item11Rating;

                break;

            case 5:

                parms['Item12Rating'] = Ext.isEmpty(itemRatings.Item12Rating) ? this.getSavedItemRating(13, 5) : itemRatings.Item12Rating;
                parms['Item12ARating'] = Ext.isEmpty(itemRatings.Item12ARating) ? this.getSavedItemRating(14, 5) : itemRatings.Item12ARating;
                parms['Item12BRating'] = Ext.isEmpty(itemRatings.Item12BRating) ? this.getSavedItemRating(15, 5) : itemRatings.Item12BRating;
                parms['Item12CRating'] = Ext.isEmpty(itemRatings.Item12CRating) ? this.getSavedItemRating(16, 5) : itemRatings.Item12CRating;
                parms['Item13Rating'] = Ext.isEmpty(itemRatings.Item13Rating) ? this.getSavedItemRating(17, 5) : itemRatings.Item13Rating;
                parms['Item14Rating'] = Ext.isEmpty(itemRatings.Item14Rating) ? this.getSavedItemRating(18, 5) : itemRatings.Item14Rating;
                parms['Item15Rating'] = Ext.isEmpty(itemRatings.Item15Rating) ? this.getSavedItemRating(19, 5) : itemRatings.Item15Rating;

                break;

            case 6:

                parms['Item16Rating'] = Ext.isEmpty(itemRatings.Item16Rating) ? this.getSavedItemRating(20, 6) : itemRatings.Item16Rating;

                break;

            case 7:

                parms['Item17Rating'] = Ext.isEmpty(itemRatings.Item17Rating) ? this.getSavedItemRating(21, 7) : itemRatings.Item17Rating;
                parms['Item18Rating'] = Ext.isEmpty(itemRatings.Item18Rating) ? this.getSavedItemRating(22, 7) : itemRatings.Item18Rating;

                break;

            default:

                break;
        }

        return parms;
    },
    getSavedItemRating: function (itemCode, outcomeCode) {

        var rating = 'Not Yet Rated';

        var item = getItem(itemCode, outcomeCode);

        if (!Ext.isEmpty(item)) {

            switch (item.ItemRatingCode) {

                case 1:

                    rating = 'Strength';

                    break;

                case 2:

                    rating = 'Area Needing Improvement';

                    break;

                case 3:

                    rating = 'NA';

                    break;

                case 4:

                    rating = 'Unable to Rate';

                    break;

                default:

                    break;
            }
        } 
      
        return rating;
    }
});