﻿Ext.define('App.CaseReview.view.common.CRSRatingCalculator', {
    extend: 'Ext.Base',
    alias: 'widget.crsRatingCalculator',
    config: {
        itemName: undefined,
        outcomeName: undefined,
        questionResponses: undefined,
        itemRatingStore: undefined,
        outcomeRatingStore: undefined,
        ratingOverride: undefined,
        recalcNeeded: false,
        userInput: undefined
    },
    init: function () {

        var itemRatingStore = Ext.data.ChainedStore.create({
            source: 'ItemRatingStore'
        });

        var outcomeRatingStore = Ext.data.ChainedStore.create({
            source: 'OutComeRatingStore'
        });

        this.setItemRatingStore(itemRatingStore);
        this.setOutcomeRatingStore(outcomeRatingStore);
    },
    constructor: function () {
        this.init();
    },
    calculateParticipantItemRating: function(parms){

        var self = this;
        var allAnswersYes = true;
        var atLeast1AnswerNo = false;
        var allQuestionsAnswered = true;
        var ratingDesc;

        if (Ext.isEmpty(parms)) {

            return self.getRatingCode('Unable to Rate');
        }

        if (parms.ItemApplicable == 'No') {

            return self.getRatingCode('NA');
        }
                
        Ext.each(parms.Answers, function (answer) {

            if (answer.Answer == 'No') {

                atLeast1AnswerNo = true;
                allAnswersYes = false;
            }

            if (answer.Answer == 'NA' || Ext.isEmpty(answer.Answer)) {

                allAnswersYes = false;

                if (Ext.isEmpty(answer.Answer)) {

                    allQuestionsAnswered = false;
                }
            }
        });

        if ((allAnswersYes) || (allQuestionsAnswered && !(atLeast1AnswerNo))) {

            ratingDesc = 'Strength';

            return self.getRatingCode(ratingDesc);
        }

        if (atLeast1AnswerNo) {

            ratingDesc = 'Area Needing Improvement';

            return self.getRatingCode(ratingDesc);
        } else {

            ratingDesc = 'Unable to Rate';
        }

        return self.getRatingCode(ratingDesc);
    },
    getRatingCode: function (ratingDesc) {
        var self = this;
        var result = {};

        result['RatingDescription'] = ratingDesc;
        var ratingCode = undefined;

        if (Ext.isEmpty(ratingDesc)) {

            return result;
        }

        var itemRatingStore = Ext.data.ChainedStore.create({
            source: self.getItemRatingStore(),
            filters: [
                function (record) {
                    return record.data.DescriptionLarge == ratingDesc;
                }
            ]
        });

        if (!(itemRatingStore.getAt(0) == null)) {

            result['RatingCode'] = itemRatingStore.getAt(0).data.GroupID;
        } else {

            if (ratingDesc == 'Not Yet Rated') {

                result['RatingCode'] = 0;
            } else {

                if (ratingDesc == 'Unable to Rate') {

                    result['RatingCode'] = 4;
                }
            }
        }

        return result;
    },
    getOutcomeRatingCode: function (ratingDesc) {
        var self = this;
        var result = {};

        result['RatingDescription'] = ratingDesc;
        var ratingCode = undefined;

        if (Ext.isEmpty(ratingDesc)) {

            return result;
        }

        var outcomeRatingStore = Ext.data.ChainedStore.create({
            source: self.getOutcomeRatingStore(),
            filters: [
                function (record) {
                    return record.data.DescriptionLarge == ratingDesc;
                }
            ]
        });

        if (!(outcomeRatingStore.getAt(0) == null)) {
            result['RatingCode'] = outcomeRatingStore.getAt(0).data.GroupID;
        }

        return result;
    },
    getOverrideRating: function(){
        var self = this;
        var result = {};
        var overrideRatingCmp = this.getRatingOverride();

        if (!Ext.isEmpty(overrideRatingCmp)) {

            return result;
        }

        if (overrideRatingCmp.overrideInd > 0) {
            // Check if Item Rating is overridden
            var newRating = overrideRatingCmp.getOverrideRating();

            if (!(newRating == undefined)) {

                result['isRatingOverride'] = overrideRatingCmp.overrideInd;
                result['RatingCode'] = newRating;

                var itemRatingStore = Ext.data.ChainedStore.create({
                    source: self.getItemRatingStore(),
                    filters: [
                        function (record) {
                            return record.data.GroupID == newRating;
                        }
                    ]
                });

                result['RatingDescription'] = itemRatingStore.getAt(0).data.DescriptionLarge;

                return result;
            }

            var itemRatingStore = Ext.data.ChainedStore.create({
                source: self.getItemRatingStore(),
                filters: [
                    function (record) {
                        return record.data.GroupID == overrideRatingCmp.getOverrideRating();
                    }
                ]
            });

            if (!(itemRatingStore.getAt(0) == null)) {
                result['isRatingOverride'] = overrideRatingCmp.overrideInd;
                result['RatingCode'] = itemRatingStore.getAt(0).data.GroupID;
                result['RatingDescription'] = itemRatingStore.getAt(0).data.DescriptionLarge;
            }

            return result;
        }
                
        return result;
    },
    getCaseType: function(){

        var lookupStore = chainedStore('CaseReviewStore');

        if (Ext.isEmpty(lookupStore)) {

            return 0;
        }

        if (Ext.isEmpty(lookupStore.data)) {

            return 0;
        }

        if (lookupStore.data.length > 0) {

            return lookupStore.getAt(0).data.ReviewSubTypeID;
        }

        return 0;
    },
    //=============================================
    // Safety tab item calculations
    //=============================================
    calculateItem1Rating: function () {

        var self = this;

        var ratingOvr = self.getOverrideRating();

        if (!(self.getRecalcNeeded())) {

            return ratingOvr;
        }

        var ratingDesc = 'Not Yet Rated';
        var safetyStore = chainedStore('CR_Safety_CollectionStore');
        var safetyReportStore = chainedStore('CR_SafetyReport_CollectionStore');
        var userInput = self.getUserInput();
       
        var reportsNotInAccordance = safetyStore.getAt(0).data.ReportsNotInAccordance;

        var face2faceNotInAccordance = safetyStore.getAt(0).data.FaceToFaceReportsNotInAccordance;

        var unavoidableDelays = safetyStore.getAt(0).data.IsDelayBeyondAgencyControl;

        var item = getItem(2, getOutcomeCode(2));

        if (Ext.isEmpty(item)) {

            itemRatings['Item1Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        var item1Applicability = Ext.isEmpty(item.IsApplicable) ? 0 : item.IsApplicable;
        
        if (item1Applicability == 0) {

            itemRatings['Item1Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        if (item1Applicability == 2) {

            ratingDesc = 'NA';

            itemRatings['Item1Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        if (safetyReportStore.count() > 0) {

            if (Ext.isEmpty(userInput.ReportsNotInAccordance) &&
                Ext.isEmpty(userInput.FaceToFaceReportsNotInAccordance) &&
                Ext.isEmpty(userInput.IsDelayBeyondAgencyControl)) {

                itemRatings['Item1Rating'] = ratingDesc;

                return self.getRatingCode(ratingDesc);
            }

            if ((reportsNotInAccordance + face2faceNotInAccordance) == 0 ||
                (unavoidableDelays == 1) || ((reportsNotInAccordance + face2faceNotInAccordance) == 0 && unavoidableDelays == 3)) {
                ratingDesc = 'Strength';

                itemRatings['Item1Rating'] = ratingDesc;

                return self.getRatingCode(ratingDesc);
            }

            if ((reportsNotInAccordance + face2faceNotInAccordance) > 0 &&
                (unavoidableDelays == 2)) {
                ratingDesc = 'Area Needing Improvement';

                itemRatings['Item1Rating'] = ratingDesc;

                return self.getRatingCode(ratingDesc);
            }
        }
        
        itemRatings['Item1Rating'] = ratingDesc;

        return self.getRatingCode(ratingDesc);
    },
    calculateItem2Rating: function () {
        var self = this;

        var ratingOvr = self.getOverrideRating();

        if (!(ratingOvr.RatingCode == undefined)) {

            return ratingOvr;
        }

        var ratingDesc = 'Not Yet Rated';
        var userInput = self.getUserInput();

        if (Ext.isEmpty(userInput)) {

            itemRatings['Item2Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        var answer2A = userInput.Answer2A;
        var answer2B = userInput.Answer2B;
        var caseApplicable = userInput.ItemApplicable == 'Yes' ? true : userInput.ItemApplicable == 'No' ? false : undefined;

        if (Ext.isEmpty(caseApplicable)) {

            itemRatings['Item2Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Not Applicable
        if (!Ext.isEmpty(caseApplicable)) {

            if (!(caseApplicable)) {

                ratingDesc = 'NA';

                itemRatings['Item2Rating'] = ratingDesc;

                return self.getRatingCode(ratingDesc);
            }
        }

        if (Ext.isEmpty(answer2A) && Ext.isEmpty(answer2B)) {

            itemRatings['Item2Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Strength
        if ((answer2A == 'Yes' && answer2B == 'NA') || (answer2A == 'No' && answer2B == 'Yes')) {

            ratingDesc = 'Strength';

            itemRatings['Item2Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Area Needing Improvement
        if ((answer2A == 'No' && answer2B == 'No') || (answer2A == 'No' && answer2B == 'NA')) {

            ratingDesc = 'Area Needing Improvement';
        } else {

            ratingDesc = 'Unable to Rate';
        }

        itemRatings['Item2Rating'] = ratingDesc;

        return self.getRatingCode(ratingDesc);
    },
    calculateItem3Rating: function () {
        var self = this;

        var ratingOvr = self.getOverrideRating();

        if (!(ratingOvr.RatingCode == undefined)) {

            return ratingOvr;
        }

        var ratingDesc = 'Not Yet Rated';
        var userInput = self.getUserInput();

        if (Ext.isEmpty(userInput)) {

            itemRatings['Item3Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        if (Ext.isEmpty(userInput.Answer3A) && Ext.isEmpty(userInput.Answer3B) &&
                Ext.isEmpty(userInput.Answer3C) && Ext.isEmpty(userInput.Answer3D) &&
                Ext.isEmpty(userInput.Answer3E) && Ext.isEmpty(userInput.Answer3F)) {

            itemRatings['Item3Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Strength
        if ((userInput.Answer3A == 'Yes' && userInput.Answer3B == 'Yes') ||
            (((userInput.Answer3A == 'Yes' && userInput.Answer3B == 'NA') ||
             (userInput.Answer3A == 'NA' && userInput.Answer3B == 'Yes')) &&
            (userInput.Answer3C == 'Yes' || userInput.Answer3C == 'NA') &&
            ((userInput.Answer3D == 'No' || userInput.Answer3D == 'NA') &&
             (userInput.Answer3E == 'No' || userInput.Answer3E == 'NA') &&
             (userInput.Answer3F == 'No' || userInput.Answer3F == 'NA')))) {

            ratingDesc = 'Strength';

            itemRatings['Item3Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Area Needing Improvement
        if ((userInput.Answer3A == 'No' || userInput.Answer3B == 'No' || userInput.Answer3C == 'No') ||
            (userInput.Answer3D == 'Yes' || userInput.Answer3E == 'Yes' || userInput.Answer3F == 'Yes')) {

            ratingDesc = 'Area Needing Improvement';
        } else {

            ratingDesc = 'Unable to Rate';
        }

        itemRatings['Item3Rating'] = ratingDesc;

        return self.getRatingCode(ratingDesc);
    },
    //=============================================
    // Permanency tab item calculations
    //=============================================
    calculateItem4Rating: function () {

        var self = this;

        var ratingOvr = self.getOverrideRating();

        if (!(ratingOvr.RatingCode == undefined)) {

            return ratingOvr;
        }

        var ratingDesc = 'Not Yet Rated';
        var userInput = self.getUserInput();

        if (Ext.isEmpty(userInput)) {

            itemRatings['Item4Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        var caseType = getCaseType();

        if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

            itemRatings['Item4Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        if (Ext.isEmpty(userInput.Answer4A) && Ext.isEmpty(userInput.Answer4B) && Ext.isEmpty(userInput.Answer4C)) {

            itemRatings['Item4Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Strength
        if ((userInput.Answer4A == 1 && userInput.Answer4B == 'NA' && userInput.Answer4C == 'Yes') ||
            ((userInput.Answer4A > 1 && userInput.Answer4B == 'Yes' && userInput.Answer4C == 'Yes'))) {

            ratingDesc = 'Strength';

            itemRatings['Item4Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Area Needing Improvement
        if ((userInput.Answer4A == 1 && userInput.Answer4C == 'No') ||
            ((userInput.Answer4A > 1 && (userInput.Answer4B == 'No' || userInput.Answer4C == 'No')))) {

            ratingDesc = 'Area Needing Improvement';
        } else {

            ratingDesc = 'Unable to Rate';
        }

        itemRatings['Item4Rating'] = ratingDesc;

        return self.getRatingCode(ratingDesc);
    },
    calculateItem5Rating: function () {

        var self = this;

        var ratingOvr = self.getOverrideRating();

        if (!(ratingOvr.RatingCode == undefined)) {

            return ratingOvr;
        }

        var ratingDesc = 'Not Yet Rated';
        var userInput = self.getUserInput();

        if (Ext.isEmpty(userInput)) {

            itemRatings['Item5Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        var caseType = getCaseType();

        if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

            itemRatings['Item5Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Not Applicable
        if (userInput.Item5Applicable == 'No') {

            ratingDesc = 'NA';

            itemRatings['Item5Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        var question5DAnswered = userInput.Answer5D == 'Yes' ? true :
                                 userInput.Answer5D == 'No' ? true : false;
        var question5A3Answered = userInput.Answer5A3 == 'Yes' ? true :
                                 userInput.Answer5A3 == 'No' ? true :
                                 userInput.Answer5A3 == 'NA' ? true : false;
        var question5EAnswered = userInput.Answer5E == 'Yes' ? true :
                                 userInput.Answer5E == 'No' ? true :
                                 userInput.Answer5E == 'NA' ? true : false;
        var question5FAnswered = userInput.Answer5F == 'Yes' ? true :
                                 userInput.Answer5F == 'No' ? true :
                                 userInput.Answer5F == 'NA' ? true : false;

        if (!(question5A3Answered) && !(question5DAnswered) && !(question5EAnswered) && !(question5FAnswered)) {

            itemRatings['Item5Rating'] = 'Not Yet Rated';

            return self.getRatingCode('Not Yet Rated');
        }

        // Strength
        if ((!(userInput.Answer5A3 == 'No' || userInput.Answer5B == 'No' || userInput.Answer5C == 'No') &&
            (userInput.Answer5D == 'No' && userInput.Answer5E == 'No')) ||
            (!(userInput.Answer5A3 == 'No' || userInput.Answer5B == 'No' || userInput.Answer5C == 'No') &&
            (userInput.Answer5D == 'Yes' && userInput.Answer5F == 'Yes')) ||
            (!(userInput.Answer5A3 == 'No' || userInput.Answer5B == 'No' || userInput.Answer5C == 'No') &&
            (userInput.Answer5D == 'No' && (userInput.Answer5E == 'Yes' && userInput.Answer5F == 'Yes'))) ||
            (!(userInput.Answer5A3 == 'No' || userInput.Answer5B == 'No' || userInput.Answer5C == 'No') &&
            (userInput.Answer5D == 'Yes' || userInput.Answer5E == 'Yes') && (userInput.Answer5F == 'No' && userInput.Answer5G == 'Yes'))) {

            ratingDesc = 'Strength';

            itemRatings['Item5Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Area Needing Improvement
        if ((userInput.Answer5A3 == 'No' || userInput.Answer5B == 'No' || userInput.Answer5C == 'No') ||
            (!(userInput.Answer5A3 == 'No' || userInput.Answer5B == 'No' || userInput.Answer5C == 'No') &&
              (userInput.Answer5D == 'Yes' || userInput.Answer5E == 'Yes') &&
              (userInput.Answer5F == 'No' && userInput.Answer5G == 'No'))) {

            ratingDesc = 'Area Needing Improvement';
        } else {

            ratingDesc = 'Unable to Rate';
        }

        itemRatings['Item5Rating'] = ratingDesc;

        return self.getRatingCode(ratingDesc);
    },
    calculateItem6Rating: function () {

        var self = this;

        var ratingOvr = self.getOverrideRating();

        if (!(ratingOvr.RatingCode == undefined)) {

            return ratingOvr;
        }

        var ratingDesc = 'Not Yet Rated';
        var userInput = self.getUserInput();

        if (Ext.isEmpty(userInput)) {

            itemRatings['Item6Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        var caseType = getCaseType();

        if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

            itemRatings['Item6Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        if (Ext.isEmpty(userInput.Answer6B) && Ext.isEmpty(userInput.Answer6C)) {

            itemRatings['Item6Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Strength
        if (userInput.Answer6B == 'Yes' || userInput.Answer6C == 'Yes') {

            ratingDesc = 'Strength';

            itemRatings['Item6Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Area Needing Improvement
        if (!(userInput.Answer6B == 'Yes') && !(userInput.Answer6C == 'Yes')) {

            ratingDesc = 'Area Needing Improvement';

        } else {

            ratingDesc = 'Unable to Rate';
        }

        itemRatings['Item6Rating'] = ratingDesc;

        return self.getRatingCode(ratingDesc);
    },
    calculateItem7Rating: function () {

        var self = this;

        var ratingOvr = self.getOverrideRating();

        if (!(ratingOvr.RatingCode == undefined)) {

            return ratingOvr;
        }

        var ratingDesc = 'Not Yet Rated';
        var userInput = self.getUserInput();

        if (Ext.isEmpty(userInput)) {

            itemRatings['Item7Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        var caseType = getCaseType();

        if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

            itemRatings['Item7Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Not Applicable
        if (userInput.Item7Applicable == 'No') {

            ratingDesc = 'NA';

            itemRatings['Item7Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        if (Ext.isEmpty(userInput.Answer7A) && Ext.isEmpty(userInput.Answer7B)) {

            itemRatings['Item7Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Strength
        if (userInput.Answer7A == 'Yes' || userInput.Answer7A == 'No' && userInput.Answer7B == 'Yes') {

            ratingDesc = 'Strength';

            itemRatings['Item7Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Area Needing Improvement
        if (userInput.Answer7A == 'No' && userInput.Answer7B == 'No') {

            ratingDesc = 'Area Needing Improvement';
        } else {

            ratingDesc = 'Unable to Rate';
        }

        itemRatings['Item7Rating'] = ratingDesc;

        return self.getRatingCode(ratingDesc);
    },
    calculateItem8Rating: function () {

        var self = this;
        var ratingDesc = 'Not Yet Rated';
        var parms = {};
        var answers = [];
        var answer = {};
        var result;

        var parms1 = { ItemCode: self.getRatingOverride().itemCode, OutcomeCode: self.getRatingOverride().outcomeCode };

        var participants = getParticipantsSelected(parms1);

        var ratingOvr = self.getOverrideRating();

        if (!(ratingOvr.RatingCode == undefined)) {

            return ratingOvr;
        }

        var userInput = self.getUserInput();

        if (Ext.isEmpty(userInput)) {

            itemRatings['Item8Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        var caseType = getCaseType();

        if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

            itemRatings['Item8Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        parms['ItemApplicable'] = userInput.Item8Applicable;
        parms['MotherSelected'] = participants.MotherSelected;
        parms['FatherSelected'] = participants.FatherSelected;

        answer['Answer'] = userInput.Answer8A;
        answer['ParticipantType'] = 'Mother';
        answers.push(answer);

        answer = {};
        answer['Answer'] = userInput.Answer8C;
        answer['ParticipantType'] = 'Mother';
        answers.push(answer);

        answer = {};
        answer['Answer'] = userInput.Answer8B;
        answer['ParticipantType'] = 'Father';
        answers.push(answer);

        answer = {};
        answer['Answer'] = userInput.Answer8D;
        answer['ParticipantType'] = 'Father';
        answers.push(answer);

        answer = {};
        answer['Answer'] = userInput.Answer8E;
        answer['ParticipantType'] = 'Sibling';
        answers.push(answer);

        answer = {};
        answer['Answer'] = userInput.Answer8F;
        answer['ParticipantType'] = 'Sibling';
        answers.push(answer);

        parms['Answers'] = answers;

        result = self.calculateParticipantItemRating(parms);

        itemRatings['Item8Rating'] = result.RatingDescription;

        return result;
    },
    calculateItem9Rating: function () {

        var self = this;

        var ratingOvr = self.getOverrideRating();

        if (!(ratingOvr.RatingCode == undefined)) {

            return ratingOvr;
        }

        var ratingDesc = 'Not Yet Rated';
        var userInput = self.getUserInput();

        if (Ext.isEmpty(userInput)) {

            itemRatings['Item9Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        var caseType = getCaseType();

        if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

            itemRatings['Item9Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Not Applicable
        if (userInput.Item9Applicable == 'No') {

            ratingDesc = 'NA';

            itemRatings['Item9Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        var question9AAnswered = userInput.Answer9A == 'Yes' ? true :
                                 userInput.Answer9A == 'No' ? true : false;
        var question9CAnswered = userInput.Answer9C == 'Yes' ? true :
                                 userInput.Answer9C == 'No' ? true :
                                 userInput.Answer9C == 'NA' ? true : false;
        var question9DAnswered = userInput.Answer9D == 'Yes' ? true :
                                 userInput.Answer9D == 'No' ? true :
                                 userInput.Answer9D == 'NA' ? true : false;

        if (!(question9AAnswered) && !(question9CAnswered) && !(question9DAnswered)) {

            itemRatings['Item9Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Strength
        if (userInput.Answer9A == 'Yes' && !(userInput.Answer9C == 'No' || userInput.Answer9D == 'No')) {

            ratingDesc = 'Strength';

            itemRatings['Item9Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Area Needing Improvement
        if ((userInput.Answer9A == 'Yes' && (userInput.Answer9C == 'No' || userInput.Answer9D == 'No')) ||
            (userInput.Answer9A == 'No')) {

            ratingDesc = 'Area Needing Improvement';
        } else {

            ratingDesc = 'Unable to Rate';
        }

        itemRatings['Item9Rating'] = ratingDesc;

        return self.getRatingCode(ratingDesc);
    },
    calculateItem10Rating: function () {

        var self = this;
        var self = this;

        var ratingOvr = self.getOverrideRating();

        if (!(ratingOvr.RatingCode == undefined)) {

            return ratingOvr;
        }

        var ratingDesc = 'Not Yet Rated';
        var userInput = self.getUserInput();

        if (Ext.isEmpty(userInput)) {

            itemRatings['Item10Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        var caseType = getCaseType();

        if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

            itemRatings['Item10Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Not Applicable
        if (userInput.Item10Applicable == 'No') {

            ratingDesc = 'NA';

            itemRatings['Item10Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        var question10A1Answered = userInput.Answer10A1 == 'Yes' ? true :
                                 userInput.Answer10A1 == 'No' ? true : false;
        var question10BAnswered = userInput.Answer10B == 'Yes' ? true :
                                 userInput.Answer10B == 'No' ? true :
                                 userInput.Answer10B == 'NA' ? true : false;
        var question10CAnswered = userInput.Answer10C == 'Yes' ? true :
                                 userInput.Answer10C == 'No' ? true :
                                 userInput.Answer10C == 'NA' ? true : false;

        if (!(question10A1Answered) && !(question10BAnswered) && !(question10CAnswered)) {

            itemRatings['Item10Rating'] = 'Not Yet Rated';

            return self.getRatingCode('Not Yet Rated');
        }

        // Strength
        if ((userInput.Answer10A1 == 'Yes' && userInput.Answer10A2 == 'Yes') ||
            ((userInput.Answer10A1 == 'No' || userInput.Answer10A2 == 'No') &&
            !(userInput.Answer10B == 'No' || userInput.Answer10C == 'No'))) {

            ratingDesc = 'Strength';

            itemRatings['Item10Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Area Needing Improvement
        if ((userInput.Answer10A1 == 'No' || userInput.Answer10A2 == 'No') ||
            (userInput.Answer10B == 'No' || userInput.Answer10C == 'No')) {

            ratingDesc = 'Area Needing Improvement';
        } else {

            ratingDesc = 'Unable to Rate';
        }

        itemRatings['Item10Rating'] = ratingDesc;

        return self.getRatingCode(ratingDesc);
    },
    calculateItem11Rating: function () {

        var self = this;

        var ratingOvr = self.getOverrideRating();

        if (!(ratingOvr.RatingCode == undefined)) {

            return ratingOvr;
        }

        var parms = {};
        var answers = [];
        var answer = {};
        var result;
        var ratingDesc = 'Not Yet Rated';
        var userInput = self.getUserInput();

        if (Ext.isEmpty(userInput)) {

            itemRatings['Item11Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        var caseType = getCaseType();

        if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

            itemRatings['Item11Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        var parms1 = { ItemCode: self.getRatingOverride().itemCode, OutcomeCode: self.getRatingOverride().outcomeCode };

        var participants = getParticipantsSelected(parms1);

        parms['ItemApplicable'] = userInput.Item11Applicable;
        parms['MotherSelected'] = participants.MotherSelected;
        parms['FatherSelected'] = participants.FatherSelected;

        answer['Answer'] = userInput.Answer11A;
        answer['ParticipantType'] = 'Mother';
        answers.push(answer);

        answer = {};
        answer['Answer'] = userInput.Answer11B;
        answer['ParticipantType'] = 'Father';
        answers.push(answer);

        parms['Answers'] = answers;

        result = self.calculateParticipantItemRating(parms);

        itemRatings['Item11Rating'] = result.RatingDescription;

        return result;
    },
    //=============================================
    // Wellbeing tab item calculations
    //=============================================
    calculate12ARating: function (userInput) {

        var ratingDesc = 'Not Yet Rated';

        if (Ext.isEmpty(userInput)) {

            return ratingDesc;
        }

        if (Ext.isEmpty(userInput.Answer12A1) || Ext.isEmpty(userInput.Answer12A2)) {

            return ratingDesc;
        }

        // Strength
        if ((userInput.Answer12A1 == 'Yes' && userInput.Answer12A2 == 'Yes') ||
            (userInput.Answer12A1 == 'Yes' && userInput.Answer12A2 == 'NA')) {

            ratingDesc = 'Strength';

            return ratingDesc;
        }

        // Area Needing Improvement
        if (userInput.Answer12A1 == 'No' || userInput.Answer12A2 == 'No') {

            ratingDesc = 'Area Needing Improvement';
        } else {

            ratingDesc = 'Unable to Rate';
        }

        return ratingDesc;
    },
    calculate12BRating: function (userInput) {

        var self = this;
        var ratingDesc = 'Not Yet Rated';
        var parms = {};
        var answers = [];
        var answer = {};

        if (Ext.isEmpty(userInput)) {

            return ratingDesc;
        }

        var parms1 = { ItemCode: self.getRatingOverride().itemCode, OutcomeCode: self.getRatingOverride().outcomeCode };

        var participants = getParticipantsSelected(parms1);

        parms['ItemApplicable'] = 'Yes';

        // Not Applicable
        if (userInput.Item12BApplicableMother == 'No' && userInput.Item12BApplicableFather == 'No') {

            parms['ItemApplicable'] = 'No';
        }

        parms['MotherSelected'] = participants.MotherSelected;
        parms['FatherSelected'] = participants.FatherSelected;

        answer['Answer'] = userInput.Answer12B1;
        answer['ParticipantType'] = 'Mother';
        answers.push(answer);

        answer = {};
        answer['Answer'] = userInput.Answer12B3;
        answer['ParticipantType'] = 'Mother';
        answers.push(answer);

        answer = {};
        answer['Answer'] = userInput.Answer12B2;
        answer['ParticipantType'] = 'Father';
        answers.push(answer);

        answer = {};
        answer['Answer'] = userInput.Answer12B4;
        answer['ParticipantType'] = 'Father';
        answers.push(answer);

        parms['Answers'] = answers;

        var result = self.calculateParticipantItemRating(parms);

        return result.RatingDescription;
    },
    calculate12CRating: function (userInput) {

        var ratingDesc = 'Not Yet Rated';

        if (Ext.isEmpty(userInput)) {

            return ratingDesc;
        }

        var caseType = getCaseType();

        if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

            return 'NA';
        }

        // Not Applicable
        if (userInput.Item12CApplicable == 'No') {

            ratingDesc = 'NA';

            return ratingDesc;
        }

        if (Ext.isEmpty(userInput.Answer12C1) && Ext.isEmpty(userInput.Answer12C2)){
                        
            return ratingDesc;
        }

        // Strength
        if ((userInput.Answer12C1 == 'Yes' && userInput.Answer12C2 == 'Yes') ||
            (userInput.Answer12C1 == 'Yes' && userInput.Answer12C2 == 'NA')) {

            ratingDesc = 'Strength';

            return ratingDesc;
        }

        // Area Needing Improvement
        if (userInput.Answer12C1 == 'No' || userInput.Answer12C2 == 'No') {

            ratingDesc = 'Area Needing Improvement';
        } else {

            ratingDesc = 'Unable to Rate';
        }

        return ratingDesc;
    },
    calculateItem12Rating: function () {

        var self = this;
        var ratingDesc = 'Not Yet Rated';

        var updateRating = function () {

            itemRatings['Item12Rating'] = ratingDesc;

            var viewModel = window.wellbeingViewModel;

            if (!Ext.isEmpty(viewModel)) {

                viewModel.set('item12OverallRating', ratingDesc);

                var ratingItem = getAppController().getWellbeingItem12Rating();

                ratingItem.setValue(ratingDesc);
            }
        };

        var userInput = self.getUserInput();

        if (Ext.isEmpty(userInput)) {

            updateRating();

            return self.getRatingCode(ratingDesc);
        }

        var ratingOvr = self.getOverrideRating();

        if (!(Ext.isEmpty(ratingOvr.RatingCode))) {

            return ratingOvr;
        }

        var item12ARating = self.calculate12ARating(userInput.UserInput12A);
        var item12BRating = self.calculate12BRating(userInput.UserInput12B);
        var item12CRating = self.calculate12CRating(userInput.UserInput12C);

        if (item12ARating == 'Unable to Rate' || item12BRating == 'Unable to Rate' || item12CRating == 'Unable to Rate') {

            ratingDesc = 'Unable to Rate';

            updateRating();

            return self.getRatingCode(ratingDesc);
        }

        // Strength
        if ((item12ARating == 'Strength' && item12BRating == 'Strength' && item12CRating == 'Strength') ||
           ((item12ARating == 'Strength' || item12BRating == 'Strength' || item12CRating == 'Strength') &&
            (!(item12ARating == 'Area Needing Improvement' || item12BRating == 'Area Needing Improvement' ||
             item12CRating == 'Area Needing Improvement')))) {

            ratingDesc = 'Strength';

            updateRating();

            return self.getRatingCode(ratingDesc);
        }

        // Area Needing Improvement
        if (item12ARating == 'Area Needing Improvement' || item12BRating == 'Area Needing Improvement' ||
             (item12CRating == 'Area Needing Improvement' || item12CRating == 'NA')) {

            ratingDesc = 'Area Needing Improvement';
        }

        updateRating();
        
        return self.getRatingCode(ratingDesc);
    },
    calculateItem12Rating2: function () {

        var self = this;
        var ratingDesc = 'Not Yet Rated';

        var updateRating = function () {

            itemRatings['Item12Rating'] = ratingDesc;

            var viewModel = window.wellbeingViewModel;

            if (!Ext.isEmpty(viewModel)) {

                viewModel.set('item12OverallRating', ratingDesc);

                var ratingItem = getAppController().getWellbeingItem12Rating();

                ratingItem.setValue(ratingDesc);
            }
        };

        var item12ARating = itemRatings.Item12ARating;
        var item12BRating = itemRatings.Item12BRating;
        var item12CRating = itemRatings.Item12CRating;

        if (item12ARating == 'Unable to Rate' || item12BRating == 'Unable to Rate' || item12CRating == 'Unable to Rate') {

            ratingDesc = 'Unable to Rate';

            updateRating();

            return self.getRatingCode(ratingDesc);
        }

        // Strength
        if ((item12ARating == 'Strength' && item12BRating == 'Strength' && item12CRating == 'Strength') ||
            ((item12ARating == 'Strength' || item12BRating == 'Strength' || item12CRating == 'Strength') &&
            (!(item12ARating == 'Area Needing Improvement' || item12BRating == 'Area Needing Improvement' ||
                item12CRating == 'Area Needing Improvement')))) {

            ratingDesc = 'Strength';

            updateRating();

            return self.getRatingCode(ratingDesc);
        }

        // Area Needing Improvement
        if (item12ARating == 'Area Needing Improvement' || item12BRating == 'Area Needing Improvement' ||
                (item12CRating == 'Area Needing Improvement' || item12CRating == 'NA')) {

            ratingDesc = 'Area Needing Improvement';
        }

        updateRating();

        return self.getRatingCode(ratingDesc);
    },
    calculateItem12ARating: function () {

        var self = this;
        var ratingDesc = 'Not Yet Rated';

        var ratingOvr = self.getOverrideRating();

        if (!(Ext.isEmpty(ratingOvr.RatingCode))) {

            return ratingOvr;
        }
                
        var userInput = self.getUserInput();

        if (Ext.isEmpty(userInput)) {

            itemRatings['Item12ARating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        ratingDesc = self.calculate12ARating(userInput);

        itemRatings['Item12ARating'] = ratingDesc;
        
        return self.getRatingCode(ratingDesc);
    },
    calculateItem12BRating: function () {

        var self = this;
        var ratingDesc = 'Not Yet Rated';

        var ratingOvr = self.getOverrideRating();

        if (!(Ext.isEmpty(ratingOvr.RatingCode))) {

            return ratingOvr;
        }
                
        var userInput = self.getUserInput();

        if (Ext.isEmpty(userInput)) {

            itemRatings['Item12BRating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        ratingDesc = self.calculate12BRating(userInput);

        itemRatings['Item12BRating'] = ratingDesc;

        return self.getRatingCode(ratingDesc);
    },
    calculateItem12CRating: function () {

        var self = this;
        var caseType = getCaseType();
        var ratingDesc = 'Not Yet Rated';

        if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

            return self.getRatingCode('NA');
        }

        var ratingOvr = self.getOverrideRating();

        if (!(Ext.isEmpty(ratingOvr.RatingCode))) {

            return ratingOvr;
        }

        var userInput = self.getUserInput();

        if (Ext.isEmpty(userInput)) {

            itemRatings['Item12CRating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        ratingDesc = self.calculate12CRating(userInput);

        itemRatings['Item12CRating'] = ratingDesc;

        return self.getRatingCode(ratingDesc);
    },
    calculateItem13Rating: function () {

        var self = this;
        var ratingDesc = 'Not Yet Rated';
        var parms = {};
        var answers = [];
        var result;
        var answer = {};

        var parms1 = { ItemCode: self.getRatingOverride().itemCode, OutcomeCode: self.getRatingOverride().outcomeCode };

        var participants = getParticipantsSelected(parms1);

        var ratingOvr = self.getOverrideRating();

        if (!(Ext.isEmpty(ratingOvr.RatingCode))) {

            return ratingOvr;
        }

        var userInput = self.getUserInput();

        if (Ext.isEmpty(userInput)) {

            itemRatings['Item13Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        parms['ItemApplicable'] = userInput.Item13Applicable;
        parms['MotherSelected'] = participants.MotherSelected;
        parms['FatherSelected'] = participants.FatherSelected;

        answer['Answer'] = userInput.Answer13A;
        answer['ParticipantType'] = 'Child';
        answers.push(answer);

        answer = {};
        answer['Answer'] = userInput.Answer13B;
        answer['ParticipantType'] = 'Mother';
        answers.push(answer);

        answer = {};
        answer['Answer'] = userInput.Answer13C;
        answer['ParticipantType'] = 'Father';
        answers.push(answer);

        parms['Answers'] = answers;

        result = self.calculateParticipantItemRating(parms);

        itemRatings['Item13Rating'] = result.RatingDescription;

        return result;
    },
    calculateItem14Rating: function () {

        var self = this;

        var ratingOvr = self.getOverrideRating();

        if (!(ratingOvr.RatingCode == undefined)) {

            return ratingOvr;
        }

        var ratingDesc = 'Not Yet Rated';
        var userInput = self.getUserInput();

        if (Ext.isEmpty(userInput)) {

            itemRatings['Item14Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        if (Ext.isEmpty(userInput.Answer14A) && Ext.isEmpty(userInput.Answer14B)) {

            itemRatings['Item14Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Strength
        if (userInput.Answer14A == 'Yes' && userInput.Answer14B == 'Yes') {

            ratingDesc = 'Strength';

            itemRatings['Item14Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Area Needing Improvement
        if (userInput.Answer14A == 'No' || userInput.Answer14B == 'No') {

            ratingDesc = 'Area Needing Improvement';
        } else {

            ratingDesc = 'Unable to Rate';
        }

        itemRatings['Item14Rating'] = ratingDesc;

        return self.getRatingCode(ratingDesc);
    },
    calculateItem15Rating: function () {

        var self = this;
        var ratingDesc = 'Not Yet Rated';
        var parms = {};
        var answers = [];
        var result;
        var answer = {};

        var parms1 = { ItemCode: self.getRatingOverride().itemCode, OutcomeCode: self.getRatingOverride().outcomeCode };

        var participants = getParticipantsSelected(parms1);

        var ratingOvr = self.getOverrideRating();

        if (!(Ext.isEmpty(ratingOvr.RatingCode))) {

            return ratingOvr;
        }

        var userInput = self.getUserInput();

        if (Ext.isEmpty(userInput)) {

            itemRatings['Item15Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        parms['ItemApplicable'] = userInput.Item15Applicable;
        parms['MotherSelected'] = participants.MotherSelected;
        parms['FatherSelected'] = participants.FatherSelected;

        answer['Answer'] = userInput.Answer15A2;
        answer['ParticipantType'] = 'Mother';
        answers.push(answer);

        answer = {};
        answer['Answer'] = userInput.Answer15B2;
        answer['ParticipantType'] = 'Father';
        answers.push(answer);

        answer = {};
        answer['Answer'] = userInput.Answer15C;
        answer['ParticipantType'] = 'Mother';
        answers.push(answer);

        answer = {};
        answer['Answer'] = userInput.Answer15D;
        answer['ParticipantType'] = 'Father';
        answers.push(answer);

        parms['Answers'] = answers;

        result = self.calculateParticipantItemRating(parms);

        itemRatings['Item15Rating'] = result.RatingDescription;

        return result;
    },
    calculateItem16Rating: function () {

        var self = this;

        var ratingOvr = self.getOverrideRating();

        if (!(Ext.isEmpty(ratingOvr.RatingCode))) {

            return ratingOvr;
        }

        var ratingDesc = 'Not Yet Rated';
        var userInput = self.getUserInput();

        if (Ext.isEmpty(userInput)) {

            itemRatings['Item16Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Not Applicable
        if (userInput.Item16Applicable == 'No') {

            ratingDesc = 'NA';

            return self.getRatingCode(ratingDesc);
        }

        // Strength
        if ((userInput.Answer16A == 'Yes' && userInput.Answer16B == 'Yes') ||
            (userInput.Answer16A == 'Yes' && userInput.Answer16B == 'NA')) {

            ratingDesc = 'Strength';

            itemRatings['Item16Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Area Needing Improvement
        if (userInput.Answer16A == 'No' || userInput.Answer16B == 'No') {

            ratingDesc = 'Area Needing Improvement';
        } else {

            ratingDesc = 'Unable to Rate';
        }

        itemRatings['Item16Rating'] = ratingDesc;

        return self.getRatingCode(ratingDesc);
    },
    calculateItem17Rating: function () {

        var self = this;
        var answers = [];

        var ratingOvr = self.getOverrideRating();

        if (!(ratingOvr.RatingCode == undefined)) {

            return ratingOvr;
        }

        var ratingDesc = 'Not Yet Rated';
        var userInput = self.getUserInput();
        
        // Not Applicable
        if (userInput.Item17Applicable == 'No') {

            ratingDesc = 'NA';

            itemRatings['Item17Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        var caseTypeId = self.getCaseType();
        var isFosterCareCase = caseTypeId == 18 ? true :
                               caseTypeId == 20 ? true : false;

        if (Ext.isEmpty(userInput)) {

            itemRatings['Item17Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        answers.push(userInput.Answer17A1);
        answers.push(userInput.Answer17A2);
        answers.push(userInput.Answer17B1);
        answers.push(userInput.Answer17B2);
        answers.push(userInput.Answer17B3);

        var question17A1Answered = userInput.Answer17A1 == 'Yes' ? true :
                                 userInput.Answer17A1 == 'No' ? true :
                                 userInput.Answer17A1 == 'NA' ? true : false;
        var question17A2Answered = userInput.Answer17A2 == 'Yes' ? true :
                                 userInput.Answer17A2 == 'No' ? true :
                                 userInput.Answer17A2 == 'NA' ? true : false;
        var question17B1Answered = userInput.Answer17B1 == 'Yes' ? true :
                                 userInput.Answer17B1 == 'No' ? true :
                                 userInput.Answer17B1 == 'NA' ? true : false;
        var question17B2Answered = userInput.Answer17B2 == 'Yes' ? true :
                                 userInput.Answer17B2 == 'No' ? true :
                                 userInput.Answer17B2 == 'NA' ? true : false;
        var question17B3Answered = userInput.Answer17B3 == 'Yes' ? true :
                                 userInput.Answer17B3 == 'No' ? true :
                                 userInput.Answer17B3 == 'NA' ? true : false;

        if (!(question17A1Answered) && !(question17A2Answered) && !(question17B1Answered) && !(question17B2Answered)
            && !(question17B3Answered)) {

            itemRatings['Item17Rating'] = 'Not Yet Rated';

            return self.getRatingCode('Not Yet Rated');
        }

        var yesAnswers = answers.filter(function (answer) {

            return answer == 'Yes';
        });

        var noAnswers = answers.filter(function (answer) {

            return answer == 'No';
        });

        var naAnswers = answers.filter(function (answer) {

            return answer == 'NA';
        });

        // Strength
        var isStrength = yesAnswers.length > 0 ? ((yesAnswers.length + naAnswers.length) == answers.length ? true : false) : false;

        if (isStrength) {

            ratingDesc = 'Strength';

            itemRatings['Item17Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Area Needing Improvement

        if (noAnswers.length > 0) {

            ratingDesc = 'Area Needing Improvement';
        } else {

            ratingDesc = 'Unable to Rate';
        }

        itemRatings['Item17Rating'] = ratingDesc;

        return self.getRatingCode(ratingDesc);
    },
    calculateItem18Rating: function () {

        var self = this;
        var answers = [];

        var ratingOvr = self.getOverrideRating();

        if (!(Ext.isEmpty(ratingOvr.RatingCode))) {

            return ratingOvr;
        }

        var ratingDesc = 'Not Yet Rated';
        var userInput = self.getUserInput();

        if (Ext.isEmpty(userInput)) {

            itemRatings['Item18Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Not Applicable
        if (userInput.Item18Applicable == 'No') {

            ratingDesc = 'NA';

            itemRatings['Item18Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        answers.push(userInput.Answer18A);
        answers.push(userInput.Answer18B);
        answers.push(userInput.Answer18C);

        var question18AAnswered = userInput.Answer18A == 'Yes' ? true :
                                 userInput.Answer18A == 'No' ? true : false;
        var question18BAnswered = userInput.Answer18B == 'Yes' ? true :
                                 userInput.Answer18B == 'No' ? true :
                                 userInput.Answer18B == 'NA' ? true : false;
        var question18CAnswered = userInput.Answer18C == 'Yes' ? true :
                                 userInput.Answer18C == 'No' ? true :
                                 userInput.Answer18C == 'NA' ? true : false;

        if (!(question18AAnswered) && !(question18BAnswered) && !(question18CAnswered)) {

            return self.getRatingCode('Not Yet Rated');
        }

        var yesAnswers = answers.filter(function (answer) {

            return answer == 'Yes';
        });

        var noAnswers = answers.filter(function (answer) {

            return answer == 'No';
        });

        var naAnswers = answers.filter(function (answer) {

            return answer == 'NA';
        });

        // Strength
        var isStrength = yesAnswers.length > 0 ? ((yesAnswers.length + naAnswers.length) == answers.length ? true : false) : false;

        //if ((userInput.Answer18A == 'Yes' && (userInput.Answer18B == 'Yes' || userInput.Answer18B == 'NA') &&
        //    (userInput.Answer18C == 'Yes' || userInput.Answer18C == 'NA'))) {

        if (isStrength) {

            ratingDesc = 'Strength';

            itemRatings['Item18Rating'] = ratingDesc;

            return self.getRatingCode(ratingDesc);
        }

        // Area Needing Improvement
        //if (userInput.Answer18A == 'No' || userInput.Answer18B == 'No' || userInput.Answer18C == 'No') {

        if (noAnswers.length > 0) {

            ratingDesc = 'Area Needing Improvement';
        } else {

            ratingDesc = 'Unable to Rate';
        }

        itemRatings['Item18Rating'] = ratingDesc;

        return self.getRatingCode(ratingDesc);
    },
    //=============================================
    // Outcome rating calculations
    //=============================================
    calculateSafetyOutcome1Rating: function (ratingInput) {

        var self = this;
        var ratingDesc;
        
        if (Ext.isEmpty(ratingInput)) {

            return self.getOutcomeRatingCode('');
        }

        if (ratingInput.Item1Rating == 'Strength') {

            ratingDesc = 'Substantially Achieved';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        if (ratingInput.Item1Rating == 'Area Needing Improvement') {

            ratingDesc = 'Not Achieved';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        if (ratingInput.Item1Rating == 'NA') {

            ratingDesc = 'NA';
        }

        if (ratingInput.Item1Rating == 'Unable to Rate') {

            ratingDesc = '';
        }

        return self.getOutcomeRatingCode(ratingDesc);
    },
    calculateSafetyOutcome2Rating: function (ratingInput) {

        var self = this;
        var ratingDesc;

        if (Ext.isEmpty(ratingInput)) {

            return self.getOutcomeRatingCode('');
        }

        if ((ratingInput.Item2Rating == 'Strength' && ratingInput.Item3Rating == 'Strength') ||
            (ratingInput.Item2Rating == 'NA' && ratingInput.Item3Rating == 'Strength')) {

            ratingDesc = 'Substantially Achieved';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        if ((ratingInput.Item2Rating == 'Strength' || ratingInput.Item3Rating == 'Strength') &&
            (ratingInput.Item2Rating == 'Area Needing Improvement' || ratingInput.Item3Rating == 'Area Needing Improvement')) {

            ratingDesc = 'Partially Achieved';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        if ((ratingInput.Item2Rating == 'Area Needing Improvement' && ratingInput.Item3Rating == 'Area Needing Improvement') ||
            (ratingInput.Item2Rating == 'NA' && ratingInput.Item3Rating == 'Area Needing Improvement')) {

            ratingDesc = 'Not Achieved';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        return self.getOutcomeRatingCode(ratingDesc);
    },
    calculatePermanencyOutcome1Rating: function (ratingInput) {

        var self = this;
        var ratingDesc;

        if (Ext.isEmpty(ratingInput)) {

            return self.getOutcomeRatingCode('');
        }

        if ((ratingInput.Item4Rating == 'Strength' && ratingInput.Item5Rating == 'Strength' &&
            ratingInput.Item6Rating == 'Strength') ||
            (ratingInput.Item4Rating == 'Strength' && ratingInput.Item6Rating == 'Strength' &&
            ratingInput.Item5Rating == 'NA')) {

            ratingDesc = 'Substantially Achieved';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        if (ratingInput.Item4Rating == 'Strength' || ratingInput.Item5Rating == 'Strength' ||
            ratingInput.Item6Rating == 'Strength') {

            ratingDesc = 'Partially Achieved';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        if ((ratingInput.Item4Rating == 'Area Needing Improvement' && ratingInput.Item5Rating == 'Area Needing Improvement' &&
            ratingInput.Item6Rating == 'Area Needing Improvement') ||
            (ratingInput.Item4Rating == 'Area Needing Improvement' && ratingInput.Item6Rating == 'Area Needing Improvement' &&
            ratingInput.Item5Rating == 'NA')) {

            ratingDesc = 'Not Achieved';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        return self.getOutcomeRatingCode(ratingDesc);
    },
    calculatePermanencyOutcome2Rating: function (ratingInput) {

        var self = this;
        var ratingDesc;
        var aniRatings = 0;
        var strengthRatings = 0;
        var naRatings = 0;

        if (Ext.isEmpty(ratingInput)) {

            return self.getOutcomeRatingCode('');
        }

        for (ratingKey in ratingInput) {

            if(ratingKey == 'Item7Rating' || ratingKey == 'Item8Rating' || ratingKey == 'Item9Rating' ||
               ratingKey == 'Item10Rating' || ratingKey == 'Item11Rating') {

                if (ratingInput[ratingKey] == 'Area Needing Improvement') {

                    aniRatings++;
                }

                if (ratingInput[ratingKey] == 'Strength') {

                    strengthRatings++;
                }

                if (ratingInput[ratingKey] == 'NA') {

                    naRatings++;
                }
            }
        }

        if ((ratingInput.Item7Rating == 'Strength' || ratingInput.Item8Rating == 'Strength' ||
            ratingInput.Item9Rating == 'Strength' || ratingInput.Item10Rating == 'Strength' || ratingInput.Item11Rating == 'Strength') &&
            aniRatings < 2) {

            ratingDesc = 'Substantially Achieved';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        if ((ratingInput.Item7Rating == 'Strength' || ratingInput.Item8Rating == 'Strength' ||
            ratingInput.Item9Rating == 'Strength' || ratingInput.Item10Rating == 'Strength' || ratingInput.Item11Rating == 'Strength') &&
            (aniRatings > 1 && aniRatings < 5)) {

            ratingDesc = 'Partially Achieved';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        if (strengthRatings == 0 && aniRatings > 0) {

            ratingDesc = 'Not Achieved';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        if (naRatings == 5) {

            ratingDesc = 'NA';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        return self.getOutcomeRatingCode(ratingDesc);
    },
    calculateWellbeingOutcome1Rating: function (ratingInput) {

        var self = this;
        var ratingDesc;
        var item12Rating;

        if (Ext.isEmpty(ratingInput)) {

            return self.getOutcomeRatingCode('');
        }

        item12Rating = self.calculateItem12Rating2().RatingDescription;

        if (!(item12Rating == 'Not Yet Rated' || item12Rating == 'Unable to Rate')) {

            ratingInput.Item12Rating = item12Rating;
        }

        var otherRatings = [ratingInput.Item13Rating, ratingInput.Item14Rating, ratingInput.Item15Rating];

        var otherStrengths = otherRatings.filter(function (rating) {

            return rating == 'Strength';
        });

        var otherANI = otherRatings.filter(function (rating) {

            return rating == 'Area Needing Improvement';
        });

        var otherNA = otherRatings.filter(function (rating) {

            return rating == 'NA';
        });

        var otherNotRated = otherRatings.filter(function (rating) {

            return rating == 'Unable to Rate' || rating == 'Not Yet Rated' || Ext.isEmpty(rating);
        });

        if (ratingInput.Item12Rating == 'Strength' && otherANI.length <= 1 &&
           (otherStrengths.length > 0 && otherStrengths.length <= 3) && otherNA.length <= 2) {

            ratingDesc = 'Substantially Achieved';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        if ((ratingInput.Item12Rating == 'Area Needing Improvement' && otherStrengths.length > 0) ||            
            (ratingInput.Item12Rating == 'Strength' && otherANI.length >= 2)) {

            ratingDesc = 'Partially Achieved';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        if (ratingInput.Item12Rating == 'Area Needing Improvement' && otherANI.length == 3) {

            ratingDesc = 'Not Achieved';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        return self.getOutcomeRatingCode(ratingDesc);
    },
    calculateWellbeingOutcome2Rating: function (ratingInput) {

        var self = this;
        var ratingDesc;

        if (Ext.isEmpty(ratingInput)) {

            return self.getOutcomeRatingCode('');
        }

        if (ratingInput.Item16Rating == 'Strength') {

            ratingDesc = 'Substantially Achieved';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        if (ratingInput.Item16Rating == 'Area Needing Improvement' &&
            (ratingInput.Item16A == 'Yes' ||ratingInput.Item16B == 'Yes')) {

            ratingDesc = 'Partially Achieved';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        if (ratingInput.Item16Rating == 'Area Needing Improvement' &&
            (ratingInput.Item16A == 'No' && ratingInput.Item16B == 'No')) {

            ratingDesc = 'Not Achieved';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        if (ratingInput.Item16Rating == 'NA') {

            ratingDesc = 'NA';
        }

        return self.getOutcomeRatingCode(ratingDesc);
    },
    calculateWellbeingOutcome3Rating: function (ratingInput) {

        var self = this;
        var ratingDesc;

        if (Ext.isEmpty(ratingInput)) {

            return self.getOutcomeRatingCode('');
        }

        if ((ratingInput.Item17Rating == 'Strength' && ratingInput.Item18Rating == 'Strength') ||
            ((ratingInput.Item17Rating == 'Strength' || ratingInput.Item18Rating == 'Strength') && 
             (ratingInput.Item17Rating == 'NA' || ratingInput.Item18Rating == 'NA'))) {

            ratingDesc = 'Substantially Achieved';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        if ((ratingInput.Item17Rating == 'Strength' || ratingInput.Item18Rating == 'Strength') &&
            (ratingInput.Item17Rating == 'Area Needing Improvement' || ratingInput.Item18Rating == 'Area Needing Improvement')) {

            ratingDesc = 'Partially Achieved';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        if ((ratingInput.Item17Rating == 'Area Needing Improvement' && ratingInput.Item18Rating == 'Area Needing Improvement') ||
            ((ratingInput.Item17Rating == 'Area Needing Improvement' || ratingInput.Item18Rating == 'Area Needing Improvement') &&
             (ratingInput.Item17Rating == 'NA' || ratingInput.Item18Rating == 'NA'))) {

            ratingDesc = 'Not Achieved';

            return self.getOutcomeRatingCode(ratingDesc);
        }

        if (ratingInput.Item17Rating == 'NA' || ratingInput.Item18Rating == 'NA') {

            ratingDesc = 'NA';
        }

        return self.getOutcomeRatingCode(ratingDesc);
    },
    //=============================================
    // End of outcome rating calculations
    //=============================================
    calculateRatingCode: function () {
        var self = this;
        var result = undefined;

        // Get Item Rating Code
        switch (self.getItemName()) {
            case 'item1':

                result = self.calculateItem1Rating();

                break;
            case 'item2':

                result = self.calculateItem2Rating();

                break;
            case 'item3':

                result = self.calculateItem3Rating();

                break;
            case 'item4':

                result = self.calculateItem4Rating();

                break;
            case 'item5':

                result = self.calculateItem5Rating();

                break;
            case 'item6':

                result = self.calculateItem6Rating();

                break;
            case 'item7':

                result = self.calculateItem7Rating();

                break;
            case 'item8':

                result = self.calculateItem8Rating();

                break;
            case 'item9':

                result = self.calculateItem9Rating();

                break;
            case 'item10':

                result = self.calculateItem10Rating();

                break;
            case 'item11':

                result = self.calculateItem11Rating();

                break;
            case 'item12':

                result = self.calculateItem12Rating();

                break;
            case 'item12A':

                result = self.calculateItem12ARating();

                break;
            case 'item12B':

                result = self.calculateItem12BRating();

                break;
            case 'item12C':

                result = self.calculateItem12CRating();

                break;
            case 'item13':

                result = self.calculateItem13Rating();

                break;
            case 'item14':

                result = self.calculateItem14Rating();

                break;
            case 'item15':

                result = self.calculateItem15Rating();

                break;
            case 'item16':

                result = self.calculateItem16Rating();

                break;
            case 'item17':

                result = self.calculateItem17Rating();

                break;
            case 'item18':

                result = self.calculateItem18Rating();

                break;

            default:
                break;
        }

        if (!(result == undefined)) {
            return result;
        }

        // Get Outcome Rating
        switch (self.getOutcomeName()) {
            
            case 'safety1':

                result = self.calculateSafetyOutcome1Rating();

                break;
            case 'safety2':

                result = self.calculateSafetyOutcome2Rating();

                break;
            case 'permanency1':

                result = self.calculatePermanencyOutcome1Rating();

                break;
            case 'permanency2':

                result = self.calculatePermanencyOutcome2Rating();

                break;
            case 'wellbeing1':

                result = self.calculateWellbeingOutcome1Rating();

                break;
            case 'wellbeing2':

                result = self.calculateWellbeingOutcome2Rating();

                break;
            case 'wellbeing3':

                result = self.calculateWellbeingOutcome3Rating();

                break;

            default:
                break;
        }

        return result;
    }
});