﻿Ext.define('App.CaseReview.view.common.ValidationMessage', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.validationMessage',
    baseCls: 'panel-background-error-message',
    margin: '0 0 0 20',
    hideMode: 'visibility',
    config: {
        itemId: undefined,
        itemName: undefined,
        validationResult: undefined,
        msgType: undefined,
        msgContainerWidth: 350,
        orientation: undefined,
        hasMessages: false,
        showMessages: function () {

            var results = this.getValidationResult();
            var msgItemsContainer = this.queryById('validationMessages');
            var msgAlreadyAdded;
            var msgColor, msgText;
            var self = this;
            var storedMsg;

            for (key in results) {

                if (!Ext.isEmpty(results[key])) {

                    msgAlreadyAdded = false;

                    Ext.each(msgItemsContainer.items.items, function (item) {

                        if (!Ext.isEmpty(item)) {

                            if (!Ext.isEmpty(item.getValue())) {

                                if (self.getMsgType() == 'Info') {

                                    msgText = 'INFO : ' + results[key];

                                } else {

                                    //msgText = 'ERROR : ' + results[key];
                                    msgText = results[key];
                                }

                                if (item.getValue() == msgText) {

                                    msgAlreadyAdded = true;

                                    return false;
                                }
                            }
                        }                        
                    });

                    if (!msgAlreadyAdded) {

                        msgColor = 'error-message-color';
                        var msgWidthPct = window.viewportWidth < 1400 ? 0.16 : 0.2;

                        if (self.getOrientation() == 'wide') {

                            msgWidthPct = 0.4;
                        }

                        var msgWidth = Math.floor(window.viewportWidth * msgWidthPct);
                        
                        self.setMsgContainerWidth(msgWidth);

                        if (self.getMsgType() == 'Info') {

                            msgColor = 'info-message-color';
                            msgText = 'INFO : ' + results[key];

                        } else {

                            //msgText = 'ERROR : ' + results[key];
                            msgText = results[key];
                        }

                        var msg = new Ext.form.field.TextArea({ xtype: 'textareafield', value: msgText, fieldCls: msgColor, grow: true, readOnly: true, width: self.getMsgContainerWidth() });

                        var msgAdded = msgItemsContainer.add(msg);
                        
                        if (msgItemsContainer.items.length > 0) {

                            self.setHasMessages(true);
                        }

                        self.ownerCt.updateLayout();
                    }
                }
            }
        },
        resetMessages: function () {

            var msgItemsContainer = this.queryById('validationMessages');

            var filteredMsgs = msgItemsContainer.items.items.filter(function (msg) {

                return msg.xtype == 'textareafield';
            });

            if (filteredMsgs.length > 0) {

                Ext.each(filteredMsgs, function (item) {

                    var msgRemoved = msgItemsContainer.remove(item);

                    item.setRawValue('');

                    item.updateLayout();
                });
            }

            this.setHasMessages(false);
        }
    },
    items: [
        {
            xtype: 'container',
            itemId: 'validationMessages',
            border: false,
            layout: 'vbox',
            margin: '0 0 -5 0'
        }
    ],
    updateMessages: function () {

        this.showMessages();
    },
    initMessages: function () {

        this.resetMessages();
    }
});