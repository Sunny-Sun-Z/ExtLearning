﻿Ext.define('App.CaseReview.view.common.GoalHelper',
{
    extend: 'Ext.window.Window',
    itemId: 'goalHelper',
    title: 'Goal',
    width: 650,
    layout: 'vbox',

    onShow: function() {
        // Needed for EXT5
        this.callParent(arguments);
        this.center();
    },
    getDockedItems: function (selector, beforeBody) {
        var layout = this.getComponentLayout();
        if (layout.getDockedItems) {
            var dockedItems = layout.getDockedItems('render', beforeBody);
            if (selector && dockedItems.length) {
                dockedItems = Ext.ComponentQuery.query(selector, dockedItems);
            }
            return dockedItems;
        }
        else {
            return [];
        }
    },
    scrollable: true,
    shrinkWrap: true,
    modal: true,
    bodyStyle: 'background:#fff;',
    closeAction: 'destroy',
    items: [
    {
        xtype: 'form',
        itemId: 'goalHelperEdit',
        margin: 15,
        layout: 'vbox',
        border: false,
        items: [
    
        {
                xtype: 'combobox',
                allowBlank: false,
                msgTarget: 'side',
                blankText: 'You have not selected a Permanency Goal. Please select a Permanency Goal.',
                flex: 1,
                itemId: 'permanencyGoalCombo',
                fieldLabel: 'Permanency Goal',
                store: 'PermanencyGoal1Store',
                displayField: 'DescriptionLarge',
                valueField: 'GroupID',
                typeahead: true,
                editable: false,
                triggerAction: 'all',
                autoSelect: true,
                lastQuery: '',
                forceSelection: true,
                width: 450,
                labelWidth: 150,
                name: 'GoalCode',
                renderer: function (value) {
                    var lookupStore = chainedStore('PermanencyGoal1');
                    var results = lookupStore.query('GroupID', value, false, false, true);
                    if (results.length > 0) {
                        return results.getAt(0).data.DescriptionLarge;
                    }
                    return '';
                }
        },
        {
            xtype: 'datefield',
            flex: 1,
            allowBlank: false,
            msgTarget: 'side',
            blankText: 'Please enter a date the goal was established that is on or before the last day of the PUR.',
            itemId: 'dateEstablished',
            fieldLabel: 'Date Established',
            width: 450,
            maxLength: 20,
            labelWidth: 150,
            name: 'DateEstablished',
            maxValue: new Date(),
            minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30)
        },
        {
            layout: 'hbox',
            items: [
            {
                xtype: 'numberfield',
                hideTrigger: true,
                keyNavEnabled: false,
                mouseWheelEnabled: false,
                allowDecimals: false,
                itemId: 'timeInFosterCare',
                fieldLabel: 'Time in Foster Care Before Goal Established',
                width: 450,
                labelWidth: 150,
                name: 'TimeInFosterCare',
                allowBlank: false,
                msgTarget: 'side',
                blankText: 'Please enter a numeric value.',

            },
            {
                xtype: 'combobox',
                allowBlank: false,
                msgTarget: 'side',
                blankText : 'Please select a value.',
                flex: 1,
                itemId: 'timeUnitCombo',
                store: 'TimeUnitStore',
                displayField: 'DescriptionLarge',
                valueField: 'GroupID',
                typeahead: true,
                editable: false,
                triggerAction: 'all',
                autoSelect: true,
                lastQuery: '',
                forceSelection: true,
                width : 100 ,
                name: 'TimeUnitCode',
                margin : '8 0 0 5',
                renderer: function (value) {
                    var lookupStore = chainedStore('TimeUnit');
                    var results = lookupStore.query('GroupID', value, false, false, true);
                    if (results.length > 0) {
                        return results.getAt(0).data.DescriptionLarge;
                    }
                    return '';
                }
            }
            ]
        },
         {
             xtype: 'datefield',
             flex: 1,
             allowBlank: false,
             msgTarget: 'side',
             blankText: 'Please select either a date or select NA. This is/was the current goal.',
             itemId: 'dateGoalChanged',
             fieldLabel: 'Date Goal Changed',
             width: 450,
             maxLength: 20,
             labelWidth: 150,
             name: 'DateGoalChanged',
             maxValue: new Date(),
             minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30),
             listeners: {
                 'change': function (dateField, newValue, oldValue, e0Pts) {
                     //if (newValue) {
                     //    Ext.ComponentQuery.query('#dateGoalChanged')[0].allowBlank= true;
                     //   } else {
                     //    Ext.ComponentQuery.query('#dateGoalChanged')[0].allowBlank = false;
                     //   }
                    }
             }

         },
         {
             xtype: 'checkbox',
             flex: 1,
             itemId: 'IsCurrentGoal',
             fieldLabel: 'NA. This is/was the current goal',
             width: 450,
             maxLength: 1,
             labelWidth: 150,
             name: 'IsCurrentGoal',
             inputValue: 1,
             uncheckedValue : 2,
             listeners : {
                 //'change': function (checkbox, newValue, oldValue, e0Pts) {
                 //    if (newValue) {
                 //        Ext.ComponentQuery.query('#dateGoalChanged')[0].allowBlank = true;
                 //        Ext.ComponentQuery.query('#reasonForGoalChange')[0].allowBlank = true;
                 //        Ext.ComponentQuery.query('#dateGoalChanged')[0].setDisabled(true);
                 //        Ext.ComponentQuery.query('#reasonForGoalChange')[0].setDisabled(true);
                 //        Ext.ComponentQuery.query('#dateGoalChanged')[0].setValue(null);
                 //        Ext.ComponentQuery.query('#reasonForGoalChange')[0].setValue(null);
                 //    } else {
                 //        Ext.ComponentQuery.query('#dateGoalChanged')[0].allowBlank = false;
                 //        Ext.ComponentQuery.query('#reasonForGoalChange')[0].allowBlank = false;
                 //        Ext.ComponentQuery.query('#dateGoalChanged')[0].setDisabled(false);
                 //        Ext.ComponentQuery.query('#reasonForGoalChange')[0].setDisabled(false);
                 //    }
                 //}
             }

         },
        {
            xtype: 'textarea',
            itemId: 'reasonForGoalChange',
            fieldLabel: 'Reason for Goal Change',
            width: 450,
            labelWidth: 150,
            maxLength: 4100,
            enforceMaxLength: true,
            name: 'ReasonForGoalChange',
            allowBlank: false,
            msgTarget: 'side',
            blankText: 'Please select either a date or select NA. This is/was the current goal.',

        },
        {
                xtype: 'container',
                layout: 'hbox',
                items: [
                    {
                        xtype: 'button',
                        flex: 1,
                        align: 'right',
                        width: '100px',
                        text: 'Cancel',
                        itemId: 'unitCancel',
                        margin: '15 0 0 170',
                        padding: '5 5 5 5',
                        icon: window.baseUrl + '/content/icons/cross-small.png'
                    }, {
                        xtype: 'button',
                        flex: 1,
                        align: 'right',
                        style: 'float:right',
                        width: '150px',
                        text: 'Add/Update',
                        itemId: 'unitSave',
                        margin: '15 0 0 10',
                        padding: '5 5 5 5',
                        icon: window.baseUrl + '/content/icons/database_add.png'
                    }

                ]
            }]
    }
    ]

});