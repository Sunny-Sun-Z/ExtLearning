﻿Ext.define('App.CaseReview.view.CaseReviewViewModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.caseReviewViewModel',
    stores: {
        caseReviewStore: {            
            source: 'CaseReviewStore'
        }
    },
    data: {
    },
    formulas: {
        caseId: {
            get: function () {
                
                return this.data.caseReviewStore.getAt(0).data.CaseID;
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'CaseID';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        caseName: {
            get: function () {

                return this.data.caseReviewStore.getAt(0).data.CaseName;
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'CaseName';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        caseReviewId: {
            get: function () {

                return this.data.caseReviewStore.getAt(0).data.CaseReviewID;
            }
        },
        caseReviewRootId: {
            get: function () {

                return this.data.caseReviewStore.getAt(0).data.CaseReviewRootID;
            }
        },
        caseStatusCode: {
            get: function () {

                return this.data.caseReviewStore.getAt(0).data.CaseStatusCode;
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'CaseStatusCode';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        caseStatus: {
            get: function () {

                return getSavedCaseStatus();
            }
        },
        caseType: {
            get: function () {

                return getCaseType();
            }
        },
        reviewTypeId: {
            get: function () {

                return this.data.caseReviewStore.getAt(0).data.ReviewTypeID;
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'ReviewTypeID';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        reviewSubTypeId: {
            get: function () {

                return this.data.caseReviewStore.getAt(0).data.ReviewSubTypeID;
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'ReviewSubTypeID';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        siteCode: {
            get: function () {

                return this.data.caseReviewStore.getAt(0).data.SiteCode;
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'SiteCode';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        siteName: {
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'SiteCode';

                var siteCode = getStorePropertyValue(parms);

                return getSiteName(siteCode);
            }
        },
        pipMonitored: {
            get: function () {

                return this.data.caseReviewStore.getAt(0).data.IsPIPMonitored;
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'IsPIPMonitored';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        intialQAId: {
            get: function () {

                return this.data.caseReviewStore.getAt(0).data.InitialQAUserID;
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'InitialQAUserID';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        intialQAName: {
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'InitialQAUserID';

                var reviewerId = getStorePropertyValue(parms);

                return getQAReviewerName(reviewerId);
            }
        },
        secondLevelQAId: {
            get: function () {

                return this.data.caseReviewStore.getAt(0).data.SecondQAUserID;
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'SecondQAUserID';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        secondLevelQAName: {
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'SecondQAUserID';

                var reviewerId = getStorePropertyValue(parms);

                return getQAReviewerName(reviewerId);
            }
        },
        secondaryOversightId: {
            get: function () {

                return this.data.caseReviewStore.getAt(0).data.SecondaryOversightUserID;
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'SecondaryOversightUserID';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        secondaryOversightName: {
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'SecondaryOversightUserID';

                var oversightId = getStorePropertyValue(parms);

                return getSecondaryOversightName(oversightId);
            }
        },
        ctSecondaryOversightId: {
            get: function () {

                return this.data.caseReviewStore.getAt(0).data.CtSecondaryOversightUserID;
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'CtSecondaryOversightUserID';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        ctSecondaryOversightName: {
            get: function () {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'CtSecondaryOversightUserID';

                var oversightId = getStorePropertyValue(parms);

                return getSecondaryOversightName(oversightId);
            }
        },
        reviewStartDate: {
            get: function () {

                return this.data.caseReviewStore.getAt(0).data.ReviewStartDate;
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'ReviewStartDate';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        reviewCompletedDate: {
            get: function () {

                return this.data.caseReviewStore.getAt(0).data.ReviewCompleted;
            },
            set: function (value) {

                var parms = {};

                parms['storeId'] = 'CaseReviewStore';
                parms['propertyName'] = 'ReviewCompleted';
                parms['propertyValue'] = value;

                setStorePropertyValue(parms);
            }
        },
        reviewPeriod: {
            get: function () {

                var reviewStartDate = this.data.caseReviewStore.getAt(0).data.ReviewStartDate,
                    reviewEndDate = this.data.caseReviewStore.getAt(0).data.ReviewCompleted;

                return Ext.Date.format(reviewStartDate, 'm/d/Y') + ' - ' + Ext.Date.format(reviewEndDate, 'm/d/Y');
            }
        },
        reviewers: {
            get: function () {

                var reviewers = [];

                var reviewerColl = this.data.caseReviewStore.getAt(0).data.CR_Reviewer_Collection;

                Ext.each(reviewerColl, function (reviewer) {

                    reviewers.push(reviewer.FullName);
                });

                return reviewers;
            }
        }
    }
});