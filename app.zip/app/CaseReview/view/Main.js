﻿/* globals App*/
var chainedStore = function (parentStore) {

    if (Ext.data.StoreManager.get(parentStore) == null) {
        return [];
    }
    return new Ext.data.ChainedStore({ source: parentStore });

};


var GetMultipleAnswerStore = function(groupName) {

    if (Ext.data.StoreManager.get('CR_MultiAnswer_CollectionStore') != null) {

        var tempStore = Ext.data.ChainedStore({ source: 'CR_MultiAnswer_CollectionStore' });
        tempStore = tempStore.queryBy(function(record) {
            return (record.get('GroupName') == groupName);
        });
    }
};

var GetHealthStore = function (healthNeedCode) {

    if (Ext.data.StoreManager.get('CR_Health_CollectionStore') != null) {

        var tempStore = Ext.data.ChainedStore.create({
            source: 'CR_Health_CollectionStore',
            filters: [
                function (record) {
                    return record.get('HealthNeedCode') == healthNeedCode;
                }
            ]
        });

        return tempStore;
    }

    return Ext.data.StoreManager.get('CR_Health_CollectionStore');
};

var GetItemParticipant = function (itemParticipantCode) {

    if (Ext.data.StoreManager.get('CR_CaseParticipant_CollectionStore') != null) {

        var tempStore = Ext.data.ChainedStore.create({
            source: 'CR_CaseParticipant_CollectionStore',
            filters: [
                function (record) {

                    //return record.get('RoleCode') == itemParticipantCode;
                    return record.get('RoleCode') == itemParticipantCode || record.get('RoleCode') == 6;
                }
            ]
        });
        return tempStore;
    }
    return Ext.data.StoreManager.get('CR_CaseParticipant_CollectionStore');
};

var GetSelectedParticipant = function (parms) {

    if (Ext.data.StoreManager.get('CR_ItemParticipant_CollectionStore') != null) {

        var tempStore = Ext.data.ChainedStore.create({
            source: 'CR_ItemParticipant_CollectionStore',
            filters: [
                function (record) {
                    return record.get('CodeDescriptionID') == parms.ParticipantCode &&
                           record.get('ItemID') == parms.ItemId;
                }
            ]
        });

        return tempStore;
    }

    return Ext.data.StoreManager.get('CR_ItemParticipant_CollectionStore');
};
var GetItemChildren = function () {

    if (Ext.data.StoreManager.get('CR_ChildDemographic_CollectionStore') != null) {

        var tempStore = Ext.data.ChainedStore.create({
            source: 'CR_ChildDemographic_CollectionStore',
            filters: [
                function (record) {
                    //return record.get('RoleCode') == itemParticipantCode || record.get('RoleCode') == 6;
                    return record;
                }
            ]
        });
        return tempStore;
    }
    return Ext.data.StoreManager.get('CR_ChildDemographic_CollectionStore');
};
var GetChildRaceStore = function() {
    //if (Ext.data.StoreManager.get('CR_ChildRace_CollectionStore') != null) {
    //    return Ext.data.StoreManager.get('CR_ChildRace_CollectionStore');
    //} else {
        var newStore = new Ext.data.Store({
            model: 'App.model.CR_ChildRace'

        });
        return newStore;
    //}
};


var GetParticipantRole = function() {
    if (Ext.data.StoreManager.get('ParticipantRoleStore') != null) {
        var tempStore = Ext.data.ChainedStore.create({
            source: 'ParticipantRoleStore',
            filters: [
                function (record) {
                    if (Ext.data.StoreManager.get('CaseReviewStore').getAt(0).data.ReviewSubTypeID == 20)
                        return record;
                    else if (Ext.data.StoreManager.get('CaseReviewStore').getAt(0).data.ReviewSubTypeID != 20 && record.get('GroupID') != 3) 
                      return record;
                    
                }
            ]
        });
        return tempStore;
    }
    return Ext.data.StoreManager.get('ParticipantRoleStore');
};
var GetSafetyReportAllegationStore = function () {
    //if (Ext.data.StoreManager.get('CR_ChildRace_CollectionStore') != null) {
    //    return Ext.data.StoreManager.get('CR_ChildRace_CollectionStore');
    //} else {
    var newStore = new Ext.data.Store({
        model: 'App.model.CR_SafetyReport_Allegation'

    });
    return newStore;
    //}
};


var offset = 200;

var GetLoggedInUser = function () {
    
    var crsUser = new App.CaseReview.view.common.CRSUser();

    return crsUser;
}

Ext.state.Manager.setProvider(new Ext.state.CookieProvider());
//var chainedStore;
Ext.define('App.CaseReview.view.Main',
{
    // Forms have to be children of tabs so our top level
    // control is derived from a Panel.
    //
    // This view is launched by the controller.
    extend: Ext.panel.Panel.$className,
    renderTo: 'ext',
    border: false,
    initComponent: function () {
        //if you don't have any stores yet, use this instead        
        //var chainedStore = function (parentStore) {
        //    return [];
        //};

        var me = this;
        var sr = App.Common.StringResources;
        //var currentTab = Ext.isEmpty(activeTab) ? 'caseOverview' : activeTab;
        var currentTab = 'caseOverview';
        // these values keep us from having to type everything out
        // every time we want to put icons on the screen and makes it
        // easy to change their values in one place

        var config = {
            xtype: 'container',
            plugins: 'viewport',
            layout: 'fit',
            items: [
            {
                xtype: 'viewport',
                title: 'Border Layout',
                layout: 'border',
                bodyBorder: false,
                resizable: false,
                items: [
                {
                    region: 'south',
                    width: 100,
                    xtype: 'panel',
                    split: true,
                    //layout: 'fit',
                    contentEl: 'divfootertext',
                    collapsible: true,
                    collapsed: true
                    
                },
                {
                    region: 'center',
                    xtype: 'container',
                    layout: 'fit',
                    itemId: 'caseReviewViewport',
                    scrollable: true,
                    items: [
                    {
                        xtype: 'tabpanel',
                        layout: 'fit',
                        itemId: 'centerTabPanel',
                        activeTab: currentTab,
                        draggable: false,
                        items: [
                            {
                                title: 'CRS',
                                iconCls: 'brand',
                                style : 'font-size :20'
                            },
                            {
                                title: 'Dashboard',
                                itemId: 'dashboard',
                            },
                            {
                                title: 'Case Overview',
                                itemId: 'caseOverview',
                                layout: 'fit',                                
                                items: [
                                    {
                                        xtype: 'overviewUI',                                        
                                        layout: 'border'
                                        //flex: 1
                                    }
                                ]
                            },
                            {
                                title: 'Face Sheet',
                                itemId: 'faceSheet',
                                layout: 'fit',
                                items: [
                                    {
                                        xtype: 'facesheetUI',
                                        layout: 'border'
                                        //flex: 1
                                    }
                                ]
                            },
                            {
                                title: 'Safety',
                                itemId: 'safety',
                                layout: 'fit',
                                items: [
                                    {
                                        xtype: 'safetyUI',
                                        layout: 'border'
                                    }
                                ]
                            },
                            {
                                title: 'Permanency',
                                itemId: 'permanency',
                                layout: 'fit',
                                items: [
                                    {
                                        xtype: 'permanencyUI',
                                        layout: 'border'
                                    }
                                ]
                            },
                            {
                                title: 'Well Being',
                                itemId: 'wellBeing',
                                layout: 'fit',
                                items: [
                                    {
                                        xtype: 'wellbeingUI',
                                        layout: 'border'
                                    }
                                ]
                            },
                            {
                                title: 'Create New Case',
                                itemId: 'createCaseReview',
                                layout: 'fit'
                            }
                            //{
                            //    title: 'Save Case',
                            //    itemId: 'saveCaseButton',
                            //    layout: 'fit'
                            //}
                        ]
                    }]
                }
                ]
            }

            ]
        };

        Ext.applyIf(me, config);

        me.callParent(arguments);
    }
});