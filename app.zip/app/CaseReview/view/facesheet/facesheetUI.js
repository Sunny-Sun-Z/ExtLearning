﻿Ext.define('App.casereview.view.facesheet.FacesheetUI', {
    extend: 'Ext.form.Panel',
    alias: 'widget.facesheetUI',
    baseCls: 'x-fieldset fieldset-padding',
    border: false,
    resizable: false,
    itemId: 'facesheetTab',
    defaults: {
        stateful: true
    },
    focusable: true,
    tabIndex: 1,
    trackResetOnLoad: true,
    initComponent: function () {
        var me = this;
        var sr = App.Common.StringResources;
        // these values keep us from having to type everything out
        // every time we want to put icons on the screen and makes it
        // easy to change their values in one place

        Ext.applyIf(me, {
            items: [
                {
                    xtype: 'panel',
                    scrollable: 'vertical',
                    region: 'west',
                    width: 200,
                    bodyCls: 'panel-background-color',
                    layout: 'vbox',
                    border: 'false',
                    defaults: {
                        componentCls: 'left-nav-item',
                        xtype: 'hyperlink',
                        refPanel: {
                            parentPanelId: 'centerTabPanel',
                            tabPanelId: 'facesheetCenterPanel'
                        }
                    },
                    items: [
                        {
                            xtype: 'component',
                            autoEl: {
                                html: "<div class='left-nav-header'>Facesheet Items</div>"
                            }
                        },
                        {                                                        
                            html: 'Case Information',
                            refItemId: 'g1Instructions'
                        },
                        {
                            html: 'Child Table',
                            refItemId: 'childDemographicGrid'
                        },
                        {
                            html: 'Child Participant Table',
                            refItemId: 'caseParticipantGrid'
                        },
                        {
                            html: 'Facesheet Notes',
                            refItemId: 'facesheetNotes'
                        }
                    ]
                },
                {
                    xtype: 'panel',
                    itemId: 'facesheetCenterPanel',
                    flex: 1,
                    region: 'center',
                    scrollable: 'vertical',
                    viewModel: {
                        type: 'facesheetViewModel'
                    },
                    tbar: {
                        xtype: 'headerUI',
                        margin: 0
                    },
                    dockedItems: [
                        {
                            xtype: 'savebuttons'
                        }
                    ],
                    items: [
                            {
                                xtype: 'listPanel',
                                title: "<div class='html-content-header-margins'>Table G1 Instructions: [SHOW]</div>",
                                margin: '20 20 20 20',
                                padding: '0 0 0 0',
                                itemId: 'g1Instructions',
                                items: [
                                    {
                                        contentEl: 'facesheetG1'
                                    }                                    
                                    //{
                                    //    html: "<div class='html-content-item-margins'>" +
                                    //           "<ul><li>For both foster care cases and in-home services cases, enter the first and last names (first name first) " +
                                    //            "of all children in the family as identified in the case file. If the case is a foster care case, " +
                                    //            "check the box to indicate if the child is the target child. It is essential that the target child be " +
                                    //            "clearly identified for all foster care cases.</li></ul>" +

                                    //            "<ul><li>Enter the race and ethnicity information as provided in the case file. " +
                                    //            "If the child is of two or more races, list all that are provided in the case file " +
                                    //            "(for example, White and Asian, or White and American Indian). If you learn during the course of the interviews " +
                                    //            "that a child is of a different race or ethnicity than is noted in the file or is of two or " +
                                    //            "more races and only one is noted in the file (for example, Non-Hispanic instead of Hispanic, or both White andAmerican Indian), " +
                                    //            "please change the race or ethnicity identification information presented to reflect the accurate information.</li></ul>" +

                                    //           "<ul><li>Select from the following options for ethnicity: \"Hispanic\", \"Non-hispanic,\" or \"Unknown or Unable to Determine.\"</li></ul>" +
                                    //            "<ul><li> Select from the following options for race:" +
                                    //                    "<ul><li>American Indian or Alaskan Native</li></ul>" +
                                    //                    "<ul><li>Asian</li></ul>" +
                                    //                    "<ul><li>Black or African American</li></ul>" +
                                    //                    "<ul><li>Native Hawaiian or Other Pacific Islander</li></ul>" +
                                    //                    "<ul><li>White</li></ul>" +
                                    //                    "<ul><li>Unknown or Unable to Determine</li></ul></li></ul>" +
                                    //            "<ul><li>Provide the date of birth for every child in the family, even if this is a foster care case.</li></ul>" +
                                    //            "<ul><li>If the child is abandoned or the date of birth is otherwise unknown, enter an approximate date of birth. Use the 15th as the day of birth.</li></ul></div>"
                                    //}
                                ]

                            },
                            //***********************************************************
                            // G1. Child Table
                            //***********************************************************                            
                            {
                                xtype: 'validationMessage',
                                itemId: 'msgTableG1',
                                itemName: 'facesheet'
                            },
                            {
                                //RESULTS GRID
                                xtype: 'gridpanel',
                                itemId: 'childDemographicGrid',
                                border: true,
                                stripeRows: true,
                                margin: '20 20 20 20',
                                title: 'G1. Child Table',
                                store: 'CR_ChildDemographic_CollectionStore',
                                tools: [
                                    {
                                        xtype: 'button',
                                        text: 'Add',
                                        itemId: 'childDemographicGridAddButton',
                                        icon: addButtonImage
                                    },
                                    {
                                        xtype: 'button',
                                        itemId: 'childDemographicGridEditButton',
                                        text: 'Edit',
                                        icon: editButtonImage
                                    },
                                    {
                                        xtype: 'button',
                                        itemId: 'childDemographicGridDeleteButton',
                                        text: 'Delete',
                                        icon: deleteButtonImage
                                    }
                                ],
                                plugins: [
                                    Ext.create('framework.grid.plugin.RowEditing',
                                    {
                                        pluginId: 'programEditorPlugin',
                                        clicksToEdit: 2,
                                        errorSummary: false
                                    }),
                                    {
                                        ptype: 'businessRulePlugin',
                                        pluginId: 'childTable',
                                        rules: [
                                            {
                                                rType: 'ruleCheck',
                                                fields: [
                                                    {
                                                        eType: 'function',
                                                        fieldName: 'NoItems',
                                                        functionName: 'count',
                                                        storeId: 'CR_ChildDemographic_CollectionStore',
                                                        fieldValue: undefined,
                                                        columns: [
                                                            'IsTargetChild', 'Name', 'EthnicityCode',
                                                            'DateOfBirth', 'GenderCode', 'IsInterviewed'
                                                        ]
                                                    }
                                                ],
                                                predicate: 'NoItems.fieldValue > 0'
                                            }
                                        ],
                                        action: [
                                            {
                                                type: 'ruleCheck',
                                                enable: true,
                                                disable: false
                                            }
                                        ]
                                    },
                                    {
                                        ptype: 'crsValidationPlugin',
                                        pluginId: 'childTableG1',
                                        storeId: 'CR_ChildDemographic_CollectionStore',
                                        validationType: 'ChildTable',
                                        validationInput: [
                                            'IsTargetChild', 'Name', 'Race',
                                            'EthnicityCode', 'DateOfBirth', 'Age', 'GenderCode',
                                            'IsInterviewed'
                                        ]
                                    }
                                ],
                                columns: [
                                    {
                                        xtype: 'rownumberer',
                                        align: 'center'
                                    },
                                    {
                                        text: 'Target Child',
                                        align: 'center',
                                        dataIndex: 'IsTargetChild',
                                        renderer: function (value) {
                                            var lookupStore = chainedStore('YesNoNaStore');
                                            var results = lookupStore.query('GroupID', value, false, false, true);
                                            if (results.length > 0) {
                                                return results.getAt(0).data.DescriptionLarge;
                                            }

                                            if (value == true) {
                                                return "Yes";
                                            } else {
                                                return "No";
                                            }
                                            return '';
                                        }
                                    },
                                    {
                                        text: 'Childs Name',
                                        dataIndex: 'Name',
                                        cellWrap: true,
                                        flex: 1,
                                        align: 'center'
                                    },
                                    {
                                        text: "Race",
                                        cellWrap: true,
                                        flex: 1,
                                        align: 'center',
                                        renderer: function (value, p, record) {
                                            var raceValue = "";
                                            if (!Ext.isEmpty(record)) {
                                                if (!Ext.isEmpty(record.data["CR_ChildRace_Collection"])) {
                                                    Ext.Array.forEach(record.data["CR_ChildRace_Collection"], function (crChildRaceRecord) {
                                                        var lookupStore = chainedStore('RaceStore');
                                                        var results = lookupStore.query('GroupID', crChildRaceRecord.RaceCode, false, false, true);
                                                        if (results.length > 0) {
                                                            raceValue = raceValue + results.getAt(0).data.DescriptionLarge + " ,\n";
                                                        }

                                                    }
                                                    );
                                                }
                                            }

                                            raceValue = raceValue.substring(0, raceValue.lastIndexOf(','));

                                            return raceValue;
                                        }
                                    },
                                    {
                                        text: 'Ethnicity',
                                        flex: 1,
                                        align: 'center',
                                        dataIndex: 'EthnicityCode',
                                        cellWrap: true,
                                        renderer: function (value) {
                                            var lookupStore = chainedStore('EthnicityStore');
                                            var results = lookupStore.query('GroupID', value, false, false, true);
                                            if (results.length > 0) {
                                                return results.getAt(0).data.DescriptionLarge;
                                            }
                                            return '';
                                        }
                                    },
                                    {
                                        text: 'Date of Birth',
                                        dataIndex: 'DateOfBirth',
                                        align: 'center',
                                        renderer: Ext.util.Format.dateRenderer('m/d/Y')
                                    },
                                    {
                                        header: "Age on PUR completed",
                                        flex: 1,
                                        align: 'center',
                                        dataIndex: 'Age'
                                    },
                                    {
                                        text: 'Gender',
                                        align: 'center',
                                        dataIndex: 'GenderCode',
                                        renderer: function (value) {
                                            var lookupStore = chainedStore('GenderStore');
                                            var results = lookupStore.query('GroupID', value, false, false, true);
                                            if (results.length > 0) {
                                                return results.getAt(0).data.DescriptionLarge;
                                            }
                                            return '';
                                        }
                                    },
                                    {
                                        text: 'Interviewed',
                                        align: 'center',
                                        dataIndex: 'IsInterviewed',
                                        renderer: function (value) {
                                            var lookupStore = chainedStore('YesNoNaStore');
                                            var results = lookupStore.query('GroupID', value, false, false, true);

                                            if (results.length > 0) {

                                                return results.getAt(0).data.DescriptionLarge;
                                            }

                                            if (value == true) {

                                                return "Yes";
                                            } else {

                                                return "No";
                                            }

                                            return '';
                                        }
                                    }
                                ]
                            },
                            {
                                xtype: 'listPanel',
                                title: "<div class='html-content-header-margins'>Table G2 Instructions: [SHOW]</div>",
                                margin: '20 20 20 20',
                                padding: '0 0 0 0',
                                itemId: 'g2Instructions',
                                items: [
                                    {
                                        contentEl: 'facesheetG2'
                                    }
                                    //{
                                    //    html: "<div class='html-content-item-margins'>" +
                                    //           "<ul><li>In the Name column, for both foster care and in-home services cases, enter the first and last names " +
                                    //            "(first name first) of the key case participants whose participation in this case will be assessed in the instrument " +
                                    //            "and other persons who were interviewed to provide relevant information.</li></ul>" +

                                    //            "<ul><li>In the Role column, list one of the following options for each participant listed: Mother, Father, " +
                                    //            "Caregiver, Foster Parent, Caseworker, Caseworker's Supervisor, Other. The same role may be indicated for more than one person " +
                                    //            "(for example, a biological father may have the role of Father, and a stepfather may have the role of Father).</li></ul>" +

                                    //           "<ul><li>In the Relationship to Child column, indicate how the person is involved in the case and/or related to the child. " +
                                    //            "Indicate whether the person is/was living with the child and/or in a caregiving role. For example: boyfriend of (child name)'s mother, " +
                                    //            "lives in the home; biological mother of (children's names), not living in the home, not a caregiver; legal father of (child's name), " +
                                    //            "not living in the home</li></ul>" +

                                    //            "<ul><li>In the Interviewed column, note whether the person has been interviewed regarding the case.</li></ul></div>"
                                    //}
                                ]

                            },
                            //***********************************************************
                            // Case Participant Table
                            //***********************************************************
                            {
                                //RESULTS GRID
                                xtype: 'gridpanel',
                                itemId: sr.ItemIds.caseParticipantGrid,
                                margin: '20 20 20 20',
                                border: true,
                                title: 'G2. Case Participant Table',
                                store: 'CR_CaseParticipant_CollectionStore',
                                tools: [
                                    {
                                        xtype: 'button',
                                        text: 'Add',
                                        itemId: 'caseParticipantGridAddButton',
                                        icon: addButtonImage
                                    },
                                    {
                                        xtype: 'button',
                                        itemId: 'caseParticipantGridEditButton',
                                        text: 'Edit',
                                        icon: editButtonImage
                                    },
                                    {
                                        xtype: 'button',
                                        itemId: 'caseParticipantGridDeleteButton',
                                        text: 'Delete',
                                        icon: deleteButtonImage
                                    }
                                ],
                                plugins: [
                                    Ext.create('framework.grid.plugin.RowEditing',
                                    {
                                        pluginId: 'programEditorPlugin',
                                        clicksToEdit: 2,
                                        errorSummary: false
                                    }),
                                    {
                                        ptype: 'businessRulePlugin',
                                        pluginId: 'participantTable',
                                        rules: [
                                            {
                                                rType: 'ruleCheck',
                                                fields: [
                                                    {
                                                        eType: 'function',
                                                        fieldName: 'NoItems',
                                                        functionName: 'count',
                                                        storeId: 'CR_CaseParticipant_CollectionStore',
                                                        fieldValue: undefined,
                                                        columns: [
                                                            'Name', 'RoleCode', 'RelationshipToChild',
                                                            'IsInterviewed'
                                                        ]
                                                    }
                                                ],
                                                predicate: 'NoItems.fieldValue > 0'
                                            }
                                        ],
                                        action: [
                                            {
                                                type: 'ruleCheck',
                                                enable: true,
                                                disable: false
                                            }
                                        ]
                                    },
                                    {
                                        ptype: 'crsValidationPlugin',
                                        storeId: 'CR_CaseParticipant_CollectionStore',
                                        pluginId: 'participantTableG2',
                                        validationType: 'ParticipantTable',
                                        validationInput: ['Name', 'RoleCode', 'RelationshipToChild', 'IsInterviewed'
                                        ]
                                    }
                                ],
                                scrollable: true,
                                columns: [
                                    {
                                        xtype: 'rownumberer',
                                        align: 'center'
                                    },
                                    {
                                        text: "Participant's Name",
                                        dataIndex: 'Name',
                                        cellWrap: true,
                                        flex: 1,
                                        align: 'center'
                                    },
                                    {
                                        text: "Participant's Role",
                                        dataIndex: 'RoleCode',
                                        flex: 1,
                                        align: 'center',
                                        renderer: function (value, p, record) {
                                            var lookupStore = chainedStore('ParticipantRoleStore');
                                            var results = lookupStore.query('GroupID', value, false, false, true);
                                            if (results.length > 0) {
                                                if (results.getAt(0).data.DescriptionLarge == "Other") {

                                                    return results.getAt(0).data.DescriptionLarge + " - " + record.data.OtherRole;
                                                }

                                                return results.getAt(0).data.DescriptionLarge;
                                            }
                                            return '';
                                        },
                                        cellWrap: true
                                    },
                                    {
                                        header: "Relationship to Child",
                                        dataIndex: 'RelationshipToChild',
                                        cellWrap: true,
                                        align: 'center',
                                        flex: 1
                                    },
                                    {
                                        text: 'Interviewed',
                                        dataIndex: 'IsInterviewed',
                                        flex: 1,
                                        align: 'center',
                                        renderer: function (value) {
                                            var lookupStore = chainedStore('YesNoNaStore');
                                            var results = lookupStore.query('GroupID', value, false, false, true);

                                            if (results.length > 0) {

                                                return results.getAt(0).data.DescriptionLarge;
                                            }
                                            if (value == true) {

                                                return "Yes";
                                            } else {

                                                return "No";
                                            }

                                            return '';
                                        }
                                    }
                                ]
                            },
                            //***********************************************************
                            // Question H
                            //***********************************************************
                            {
                                xtype: 'questionH'
                            },
                            //***********************************************************
                            // Question I
                            //***********************************************************
                            {
                                xtype: 'questionI'
                            },
                            //***********************************************************
                            // Question J
                            //***********************************************************
                            {
                                xtype: 'questionJ'
                            },
                            //***********************************************************
                            // Question K
                            //***********************************************************
                            {
                                xtype: 'questionK'
                            },
                            //***********************************************************
                            // Question L
                            //***********************************************************
                            {
                                xtype: 'questionL'
                            },
                            //***********************************************************
                            // Question M
                            //***********************************************************
                            {
                                xtype: 'questionM'
                            },                            
                            //***********************************************************
                            // Face Sheet - QA Notes
                            //***********************************************************
                            {
                                xtype: 'qaNotes',
                                itemId: 'facesheetNotes',
                                notesTitle: 'Face Sheet - QA Notes',
                                itemCode: 23,
                                outcomeCode: 21
                            }
                    ]
                }
            ]
        });

        me.callParent(arguments);
    }
});