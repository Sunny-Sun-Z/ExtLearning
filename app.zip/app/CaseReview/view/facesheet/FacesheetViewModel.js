﻿Ext.define('App.CaseReview.view.facesheet.FacesheetViewModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.facesheetViewModel',
    stores: {
        facesheetData: {}
    },
    formulas: {

        caseClosureDate: {

            get: function () {

                var result;

                if (this.data.facesheetData.count() > 0) {

                    result = this.data.facesheetData.getAt(0).data.CaseClosureDate;
                }

                return result;
            },
            set: function (value) {

                if (this.data.facesheetData.count() > 0) {

                    this.data.facesheetData.getAt(0).data.CaseClosureDate = value;

                    this.data.caseClosureDate = value;
                }
            }
        },
        caseName: {

            get: function () {

                var result;

                if (this.data.facesheetData.count() > 0) {

                    result = this.data.facesheetData.getAt(0).data.CaseName;
                }

                return result;
            }
        },
        caseReviewId: {

            get: function () {

                var result;

                if (this.data.facesheetData.count() > 0) {

                    result = this.data.facesheetData.getAt(0).data.CaseReviewID;
                }

                return result;
            }
        },
        episodeDischargeDate: {

            get: function () {

                var result;

                if (this.data.facesheetData.count() > 0) {

                    result = this.data.facesheetData.getAt(0).data.EpisodeDischargeDate;
                }

                return result;
            },
            set: function (value) {

                if (this.data.facesheetData.count() > 0) {

                    this.data.facesheetData.getAt(0).data.EpisodeDischargeDate = value;

                    this.data.episodeDischargeDate = value;
                }
            }
        },
        faceSheetId: {

            get: function () {

                var result;

                if (this.data.facesheetData.count() > 0) {

                    result = this.data.facesheetData.getAt(0).data.FaceSheetID;
                }

                return result;
            }
        },
        firstCaseOpeningDate: {

            get: function () {

                var result;

                if (this.data.facesheetData.count() > 0) {

                    result = this.data.facesheetData.getAt(0).data.FirstCaseOpeningDate;
                }

                return result;
            },
            set: function (value) {

                if (this.data.facesheetData.count() > 0) {

                    this.data.facesheetData.getAt(0).data.FirstCaseOpeningDate = value;

                    this.data.firstCaseOpeningDate = value;
                }
            }
        },
        fosterEntryDate: {

            get: function () {

                var result;

                if (this.data.facesheetData.count() > 0) {

                    result = this.data.facesheetData.getAt(0).data.FosterEntryDate;
                }

                return result;
            },
            set: function (value) {

                if (this.data.facesheetData.count() > 0) {

                    this.data.facesheetData.getAt(0).data.FosterEntryDate = value;

                    this.data.fosterEntryDate = value;
                }
            }
        },
        isCaseClosureNotClosed: {

            get: function () {

                var result;

                if (this.data.facesheetData.count() > 0) {

                    result = this.data.facesheetData.getAt(0).data.IsCaseClosureNotClosed;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.facesheetData.count() > 0) {

                        this.data.facesheetData.getAt(0).data.IsCaseClosureNotClosed = value;

                        this.data.isCaseClosureNotClosed = value;
                    }
                }
            }
        },
        isCaseOpenReasonOtherAbuseNeglect: {

            get: function () {

                var result;

                if (this.data.facesheetData.count() > 0) {

                    result = this.data.facesheetData.getAt(0).data.IsCaseOpenReasonOtherAbuseNeglect;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.facesheetData.count() > 0) {

                        this.data.facesheetData.getAt(0).data.IsCaseOpenReasonOtherAbuseNeglect = value;

                        this.data.isCaseOpenReasonOtherAbuseNeglect = value;
                    }
                }                
            }
        },
        isEpisodeDischargeDateNA: {

            get: function () {

                var result;

                if (this.data.facesheetData.count() > 0) {

                    result = this.data.facesheetData.getAt(0).data.IsEpisodeDischargeDateNA;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.facesheetData.count() > 0) {

                        this.data.facesheetData.getAt(0).data.IsEpisodeDischargeDateNA = value;

                        this.data.isEpisodeDischargeDateNA = value;
                    }
                }
            }
        },
        isEpisodeNotYetDischarged: {

            get: function () {

                var result;

                if (this.data.facesheetData.count() > 0) {

                    result = this.data.facesheetData.getAt(0).data.IsEpisodeNotYetDischarged;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.facesheetData.count() > 0) {

                        this.data.facesheetData.getAt(0).data.IsEpisodeNotYetDischarged = value;

                        this.data.isEpisodeNotYetDischarged = value;
                    }
                }
            }
        },
        isFosterEntryDateNA: {

            get: function () {

                var result;

                if (this.data.facesheetData.count() > 0) {

                    result = this.data.facesheetData.getAt(0).data.IsFosterEntryDateNA;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.facesheetData.count() > 0) {

                        this.data.facesheetData.getAt(0).data.IsFosterEntryDateNA = value;

                        this.data.isFosterEntryDateNA = value;
                    }
                }
            }
        },
        otherCaseReason: {

            get: function () {

                var result;

                if (this.data.facesheetData.count() > 0) {

                    result = this.data.facesheetData.getAt(0).data.OtherCaseReason;
                }

                return result;
            },
            set: function (value) {

                if (this.data.facesheetData.count() > 0) {

                    this.data.facesheetData.getAt(0).data.OtherCaseReason = value;

                    this.data.otherCaseReason = value;
                }
            }
        }
    }
});
