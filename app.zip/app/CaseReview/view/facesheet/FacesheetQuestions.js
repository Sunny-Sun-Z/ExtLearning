﻿//
// Question H
//
Ext.define('app.CaseReview.view.facesheet.QuestionH', {
    extend: 'Ext.container.Container',
    alias: 'widget.questionH',
    margin: '0 20 20 20',
    cls: 'panel-background-color',
    border: true,
    animCollapse: false,
    itemId: 'questionHPanel',
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question H Instructions: [SHOW]</div>",
            itemId: 'questionHins',
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'facesheetHins'
                }
                //{
                //    html: "<div class='html-content-item-margins text-justify'>" +
                //            "<ul><li>Examples of cases opened for reasons other than child abuse or neglect include: (1) cases opened because of the child's behavior, including juvenile delinquency, substance abuse, or \"child in need of supervision,\" and there were no maltreatment concerns in the family; or (2) cases opened because parents requested mental/behavioral health services for their child(ren).</li>" +
                //            "</ul></div>"
                //}
            ]
        },
        {
            // SECTION A-1
            xtype: 'component',
            cls: 'panel-background-color facesheet-enable-disable-question-H-M',
            border: false,
            margin: '15 0 0 20',
            html: '<b>H. Was this case opened for reasons other than child abuse and neglect?</b>'
        },
        {
            // SECTION A-1 RADIO BUTTTONS
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '20 20 20 20',
            itemId: 'questionHGrp',
            plugins: [
                {
                    ptype: 'crsValidationPlugin',
                    storeId: 'CR_FaceSheet_CollectionStore',
                    pluginId: 'questionH',
                    validationType: 'Facesheet',
                    validationInput: ['IsCaseOpenReasonOtherAbuseNeglect']
                }
            ],
            items: [
                {
                    xtype: 'radio',
                    cls: 'facesheet-enable-disable-question-H-M',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'hYes',
                    inputValue: 1,
                    bind: '{isCaseOpenReasonOtherAbuseNeglect}',
                    name: 'CaseOpenReasonOtherAbuseNeglect',
                    trackResetOnLoad: true
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    cls: 'facesheet-enable-disable-question-H-M',
                    boxLabel: '<b>No</b>',
                    itemId: 'hNo',
                    inputValue: 2,
                    name: 'CaseOpenReasonOtherAbuseNeglect',
                    bind: '{isCaseOpenReasonOtherAbuseNeglect}',
                    trackResetOnLoad: true
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgQuestionHPanel',
                    itemName: 'facesheet'
                }
            ]
        }
    ]
});
//
// Question I
//
Ext.define('app.CaseReview.view.facesheet.QuestionI', {
    extend: 'Ext.container.Container',
    alias: 'widget.questionI',
    margin: '0 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'questionIPanel',
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question I Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'facesheetIins'
                }
                //{
                //    html: "<div class='html-content-item-margins text-justify'>" +
                //           "<ul><li>Using the MM/DD/YYYY format, enter the date on which the case was actually opened within the agency. Consider all cases that were open for services during the period under review, if there were multiple case openings. If the first case that was open during the period under review was opened before the period under review began, include it as the first case opening date for the period.</li>" +
                //           "<li>If a child was on a trial home visit and returned to a foster care placement, the return to foster care is not considered a “case opening” unless the trial home visit was longer than 6 months and there was no court order extending the trial home visit beyond 6 months.</li>" +
                //           "<li>If the family received in-home services before the removal of a child and placement of the child in foster care, and the case was not closed before placement, enter the date on which the case was opened for in-home services. The date of the child’s removal from home will be captured in the next question.</li>" +
                //           "</ul></div>"
                //}
            ]
        },
        {
            // SECTION A-1
            xtype: 'component',
            cls: 'panel-background-color facesheet-enable-disable-question-H-M',
            border: false,
            margin: '15 0 0 20',
            html: "<b>I. What is the date of the first case opening, of the cases open for services during the period under review?</b>"
        },
        {
            // SECTION A-1 RADIO BUTTTONS
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '20 20 20 20',
            plugins: [
                {
                    ptype: 'crsValidationPlugin',
                    storeId: 'CR_FaceSheet_CollectionStore',
                    pluginId: 'questionI',
                    validationType: 'Facesheet',
                    validationInput: ['FirstCaseOpeningDate']
                }
            ],
            items: [
                {
                    xtype: 'datefield',
                    itemId: 'firstCaseOpeningDate',
                    cls: 'facesheet-enable-disable-question-H-M',
                    name: 'FirstCaseOpeningDate',
                    bind: '{firstCaseOpeningDate}',
                    renderer: Ext.util.Format.dateRenderer('m/d/Y'),
                    enableKeyEvents: true,
                    msgTarget: 'under',
                    maxValue: new Date(),
                    minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30)
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgFirstCaseOpeningDate',
                    itemName: 'facesheet'
                }
            ]
        }
    ]
});
//
// Question J
//
Ext.define('app.CaseReview.view.facesheet.QuestionJ', {
    extend: 'Ext.container.Container',
    alias: 'widget.questionJ',
    margin: '0 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'questionJPanel',
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question J Definition: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'facesheetJins'
                }
                //{
                //    html: "<div class='html-content-item-margins text-justify'>" +
                //           "<ul><li>\"Entry into foster care\" refers to a child's removal from his or her normal place of residence and placement in a substitute care setting under the placement and care responsibility of the state or local title IV-B/IV-E agency. Children are considered to have entered foster care if the child has been in substitute care for 24 hours or more.</li>" +
                //           "</ul></div>"
                //}
            ]

        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question J Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    html: "<div class='html-content-item-margins text-justify'>" +
                           "<ul><li>Using the MM/DD/YYYY format, enter the date of the child's most recent entry into foster care.</li>" +
                           "<li>If a child was on a trial home visit and returned to a foster care placement, the return is not considered an \"entry into foster care\" unless the trial home visit was longer than 6 months and there was no court order extending the trial home visit beyond 6 months.</li>" +
                           "<li>If the case is an in-home services case, J is Not Applicable</li>" +
                           "</ul></div>"
                }
            ]
        },
        {
            // SECTION A-1
            xtype: 'component',
            cls: 'panel-background-color facesheet-enable-disable-question-H-M',
            border: false,
            margin: '15 0 0 20',
            html: "<b>J. What is the date of the child's most recent entry into foster care?</b>"
        },
        {
            // SECTION A-1 RADIO BUTTTONS
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '20 20 20 20',
            itemId: 'fosterEntryDatePanel',
            items: [
                {
                    xtype: 'datefield',
                    itemId: 'fosterEntryDate',
                    cls: 'facesheet-enable-disable-question-H-M',
                    length: 50,
                    name: 'FosterEntryDate',
                    bind: '{fosterEntryDate}',
                    renderer: Ext.util.Format.dateRenderer('m/d/Y'),
                    enableKeyEvents: true,
                    msgTarget: 'under',
                    plugins: [
                        {
                            ptype: 'businessRulePlugin',
                            pluginId: 'fosterCareEntryDate',
                            rules: [
                                {
                                    rType: 'validityCheck',
                                    fields: [
                                        {
                                            eType: 'lookup',
                                            fieldName: 'ReviewSubTypeID',
                                            storeId: 'CaseReviewStore',
                                            fieldValue: undefined
                                        }
                                    ],
                                    predicate: 'ReviewSubTypeID.fieldValue == 17 || ReviewSubTypeID.fieldValue == 19 || ReviewSubTypeID.fieldValue == 21 || ReviewSubTypeID.fieldValue == 22'
                                },
                                {
                                    rType: 'ruleCheck',
                                    fields: [
                                        {
                                            eType: 'lookup',
                                            fieldName: 'FosterEntryDate',
                                            storeId: 'CR_FaceSheet_CollectionStore',
                                            fieldValue: undefined
                                        },
                                        {
                                            eType: 'lookup',
                                            fieldName: 'ReviewStartDate',
                                            storeId: 'CaseReviewStore',
                                            fieldValue: undefined
                                        },
                                        {
                                            eType: 'lookup',
                                            fieldName: 'DateOfBirth',
                                            storeId: 'CR_ChildDemographic_CollectionStore',
                                            fieldValue: undefined
                                        },
                                        {
                                            eType: 'lookup',
                                            fieldName: 'ReviewCompleted',
                                            storeId: 'CaseReviewStore',
                                            fieldValue: undefined
                                        }
                                    ],
                                    predicate: 'FosterEntryDate.fieldValue >= ReviewStartDate.fieldValue && FosterEntryDate.fieldValue >= DateOfBirth.fieldValue && FosterEntryDate.fieldValue < ReviewCompleted.fieldValue'
                                }
                            ],
                            action: [
                                {
                                    type: 'validityCheck',
                                    inHomeCase: true,
                                    other: false
                                },
                                {
                                    type: 'ruleCheck',
                                    enable: true,
                                    disable: false
                                }
                            ]
                        },
                        {
                            ptype: 'crsValidationPlugin',
                            storeId: 'CR_FaceSheet_CollectionStore',
                            pluginId: 'questionJ',
                            validationType: 'Facesheet',
                            validationInput: ['FosterEntryDate']
                        }
                    ],
                    maxValue: new Date()
                    //minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30)
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'checkbox',
                    cls: 'facesheet-enable-disable-question-H-M',
                    boxLabel: '<b>NA</b>',
                    itemId: 'isFosterCareDateNA',
                    name: 'IsFosterEntryDateNA',
                    bind: '{isFosterEntryDateNA}',
                    inputValue: 1,
                    uncheckedValue: 2
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgFosterEntryDatePanel',
                    itemName: 'facesheet'
                }
            ]
        }
    ]
});
//
// Question K
//
Ext.define('app.CaseReview.view.facesheet.QuestionK', {
    extend: 'Ext.container.Container',
    alias: 'widget.questionK',
    margin: '0 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'questionKPanel',
    trackResetOnLoad: true,
    items: [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question K Definition: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'facesheetKdefs'
                }
                //{
                //    html: "<div class='html-content-item-margins text-justify'>" +
                //            "<ul><li> \"Discharge from foster care\" is defined as the point when the child is no longer in foster care under the placement and care responsibility or supervision of the agency.</li>" +
                //            "</ul></div>"
                //}
            ]

        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question K Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'facesheetKins'
                }
                //{
                //    html: "<div class='html-content-item-margins text-justify'>" +
                //            "<ul><li>Using the MM/DD/YYYY format, enter the date of discharge from foster care for the most recent foster care episode.</li>" +
                //            "<li>If a child returns home on a trial home visit and the agency retains responsibility or supervision of the child, the child should be considered discharged from foster care only if the trial home visit was longer than 6 months, and there was no court order extending the trial home visit beyond 6 months.</li>" +
                //            "<li>If the child is in foster care but has not yet been discharged, select Not Yet Discharged.</li>" +
                //            "<li>If the case is an in-home services case, K is Not Applicable:</li>" +
                //            "</ul></div>"
                //}
            ]
        },
        {
            // SECTION A-1
            xtype: 'component',
            cls: 'panel-background-color facesheet-enable-disable-question-H-M',
            border: false,
            margin: '15 0 0 20',
            html: "<b>K. What is the date of discharge from foster care for the most recent foster care episode?</b>"
        },
        {
            // SECTION A-1 RADIO BUTTTONS
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '20 20 20 20',
            items: [
                {
                    xtype: 'datefield',
                    cls: 'facesheet-enable-disable-question-H-M',
                    length: 50,
                    itemId: 'episodeDischargeDate',
                    bind: '{episodeDischargeDate}',
                    renderer: Ext.util.Format.dateRenderer('m/d/Y'),
                    enableKeyEvents: true,
                    msgTarget: 'under',
                    plugins: [
                        {
                            ptype: 'businessRulePlugin',
                            pluginId: 'dischargeNA',
                            rules: [
                                {
                                    rType: 'validityCheck',
                                    fields: [
                                        {
                                            eType: 'lookup',
                                            fieldName: 'ReviewSubTypeID',
                                            storeId: 'CaseReviewStore',
                                            fieldValue: undefined
                                        }
                                    ],
                                    predicate: 'ReviewSubTypeID.fieldValue == 17 || ReviewSubTypeID.fieldValue == 19 || ReviewSubTypeID.fieldValue == 21 || ReviewSubTypeID.fieldValue == 22'
                                },
                                {
                                    rType: 'ruleCheck',
                                    fields: [
                                        {
                                            eType: 'lookup',
                                            fieldName: 'EpisodeDischargeDate',
                                            storeId: 'CR_FaceSheet_CollectionStore',
                                            fieldValue: undefined
                                        },
                                        {
                                            eType: 'lookup',
                                            fieldName: 'ReviewStartDate',
                                            storeId: 'CaseReviewStore',
                                            fieldValue: undefined
                                        },
                                        {
                                            eType: 'lookup',
                                            fieldName: 'DateOfBirth',
                                            storeId: 'CR_ChildDemographic_CollectionStore',
                                            fieldValue: undefined
                                        },
                                        {
                                            eType: 'lookup',
                                            fieldName: 'ReviewCompleted',
                                            storeId: 'CaseReviewStore',
                                            fieldValue: undefined
                                        }
                                    ],
                                    predicate: 'EpisodeDischargeDate.fieldValue >= ReviewStartDate.fieldValue && EpisodeDischargeDate.fieldValue >= DateOfBirth.fieldValue && EpisodeDischargeDate.fieldValue < ReviewCompleted.fieldValue'
                                }
                            ],
                            action: [
                                {
                                    type: 'validityCheck',
                                    inHomeCase: true,
                                    other: false
                                },
                                {
                                    type: 'ruleCheck',
                                    enable: true,
                                    disable: false
                                }
                            ]
                        },
                        {
                            ptype: 'crsValidationPlugin',
                            storeId: 'CR_FaceSheet_CollectionStore',
                            pluginId: 'questionK',
                            validationType: 'Facesheet',
                            validationInput: ['EpisodeDischargeDate']
                        }
                    ],
                    maxValue: new Date(),
                    minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30)
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'checkbox',
                    cls: 'facesheet-enable-disable-question-H-M',
                    boxLabel: '<b>NA</b>',
                    itemId: 'dischargeNA',
                    bind: '{isEpisodeDischargeDateNA}',
                    inputValue: 1,
                    uncheckedValue: 2
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'checkbox',
                    cls: 'facesheet-enable-disable-question-H-M',
                    boxLabel: '<b>Not Yet Discharged</b>',
                    itemId: 'notYetDischarged',
                    bind: '{isEpisodeNotYetDischarged}',
                    inputValue: 1,
                    uncheckedValue: 2
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgEpisodeDischargeDate',
                    itemName: 'facesheet'
                }
            ]
        }
    ]
});
//
// Question L
//
Ext.define('app.CaseReview.view.facesheet.QuestionL', {
    extend: 'Ext.container.Container',
    alias: 'widget.questionL',
    margin: '0 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'questionLPanel',
    trackResetOnLoad: true,
    items: [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question L Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'facesheetLins'
                }
            ]
        },
        {
            // SECTION A-1
            xtype: 'component',
            cls: 'panel-background-color facesheet-enable-disable-question-H-M',
            border: false,
            margin: '15 0 0 20',
            html: "<b>L. What is the date of the most recent case closure during the period under review?</b>"
        },
        {
            // SECTION A-1 RADIO BUTTTONS
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '20 20 20 20',
            items: [
                {
                    xtype: 'datefield',
                    cls: 'facesheet-enable-disable-question-H-M',
                    length: 50,
                    itemId: 'caseClosureDate',
                    name: 'CaseClosureDate',
                    bind: '{caseClosureDate}',
                    renderer: Ext.util.Format.dateRenderer('m/d/Y'),
                    enableKeyEvents: true,
                    msgTarget: 'under',
                    plugins: [
                        {
                            ptype: 'crsValidationPlugin',
                            storeId: 'CR_FaceSheet_CollectionStore',
                            pluginId: 'questionL',
                            validationType: 'Facesheet',
                            validationInput: ['CaseClosureDate']
                        }
                    ],
                    maxValue: new Date(),
                    minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30)
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'checkbox',
                    cls: 'facesheet-enable-disable-question-H-M',
                    boxLabel: '<b> Case not closed by time of review</b>',
                    itemId: 'caseClosureClosedInd',
                    name: 'IsCaseClosureNotClosed',
                    bind: '{isCaseClosureNotClosed}',
                    inputValue: 1,
                    uncheckedValue: 2
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgCaseClosureDate',
                    itemName: 'facesheet'
                }
            ]
        }
    ]
});
//
// Question M
//
Ext.define('app.CaseReview.view.facesheet.QuestionM', {
    extend: 'Ext.container.Container',
    alias: 'widget.questionM',
    margin: '0 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'questionMPanel',
    trackResetOnLoad: true,
    items: [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question M Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'facesheetMins'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question M Tip: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'facesheetMtip'
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'vbox',
            margin: '15 0 0 20',
            items: [
                {
                    // SECTION A-1
                    xtype: 'panel',
                    bodyCls: 'panel-background-color facesheet-enable-disable-question-H-M',
                    border: false,
                    html: "<b>M. Why was/were the case(s) opened for services?</b>"
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgQuestionM',
                    orientation: 'wide',
                    itemName: 'facesheet'
                }
            ]
        },
        {
            // SECTION A-1 RADIO BUTTTONS
            xtype: 'container',
            border: false,
            cls: 'panel-background-color',
            margin: '10 20 20 20',
            items: [
                {
                    xtype: 'boundcheckboxgroup',
                    itemId: 'questionM',
                    cls: 'facesheet-enable-disable-question-H-M',
                    columns: 1,
                    vertical: true,
                    multiAnswerGroup: 'CaseReason',
                    store: 'CR_MultiAnswer_CollectionStore',
                    inputField: 'CodeDescriptionID',
                    listeners: {
                        click: {
                            element: 'el',
                            fn: function () {

                                appDataEvent.facesheet.changeByUserAction = true;

                                processQuestionMChange(this.component, appDataEvent.facesheet.questionMprevValue);

                                appDataEvent.facesheet.questionMprevValue = this.component.lastValue;
                                
                                var container = getCRSComponent('facesheetCenterPanel');                                
                                FacesheetFunctions.fireFocusEvent(container);
                            }
                        }
                    },
                    plugins: [
                        {
                            ptype: 'crsValidationPlugin',
                            storeId: 'CR_MultiAnswer_CollectionStore',
                            pluginId: 'questionMPlugin',
                            validationType: 'Facesheet',
                            validationInput: []
                        }
                    ],
                    items: [
                        {
                            boxLabel: 'Physical abuse',
                            itemId: 'caseRsn1',
                            inputValue: 1
                        },
                        {
                            boxLabel: 'Sexual abuse',
                            itemId: 'caseRsn2',
                            inputValue: 2
                        },
                        {
                            boxLabel: 'Emotional maltreatment',
                            itemId: 'caseRsn3',
                            inputValue: 3
                        },
                        {
                            boxLabel: 'Neglect (not including medical neglect)',
                            itemId: 'caseRsn4',
                            inputValue: 4
                        },
                        {
                            boxLabel: 'Medical neglect',
                            itemId: 'caseRsn5',
                            inputValue: 5
                        },
                        {
                            boxLabel: 'Abandonment',
                            itemId: 'caseRsn6',
                            inputValue: 6
                        },
                        {
                            boxLabel: 'Mental/physical health of parent',
                            itemId: 'caseRsn7',
                            inputValue: 7
                        },
                        {
                            boxLabel: 'Mental/physical health of child',
                            itemId: 'caseRsn8',
                            inputValue: 8
                        },
                        {
                            boxLabel: 'Substance abuse by parent(s)',
                            itemId: 'caseRsn9',
                            inputValue: 9
                        },
                        {
                            boxLabel: 'Child\'s behavior',
                            itemId: 'caseRsn10',
                            inputValue: 10
                        },
                        {
                            boxLabel: 'Substance abuse by child',
                            itemId: 'caseRsn11',
                            inputValue: 11
                        },
                        {
                            boxLabel: 'Domestic violence in child\'s home',
                            itemId: 'caseRsn12',
                            inputValue: 12
                        },
                        {
                            boxLabel: 'Child in juvenile justice system',
                            itemId: 'caseRsn13',
                            inputValue: 13
                        },
                        {
                            boxLabel: 'Other (specify)',
                            itemId: 'caseRsn14',
                            inputValue: 14
                        }
                    ]
                },
                {
                    xtype: 'textarea',
                    itemId: 'questionMNarrative',
                    bind: '{otherCaseReason}',
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150                                                        
                }
            ]
        }
    ]
});