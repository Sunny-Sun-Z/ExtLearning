﻿Ext.define('App.CaseReview.view.overview.newCase', {
    extend: 'Ext.form.FieldSet',
    alias: 'widget.newCase',
    baseCls: 'x-fieldset fieldset-padding',
    border: false,
    resizable: true,
    items: [
        {
            xtype: 'panel',
            region: 'west',
            scrollable: true,
            width: '25%',            
            items: [
                {}
            ]
        },
        {
            xtype: 'panel',
            region: 'center',
            scrollable: true,            
            listeners: {
                afterrender: function (obj, eOpts) {
                    
                    // Create window to handle new case creation
                    var createWin = Ext.create('Ext.window.Window', {
                        title: 'Create New Case',
                        layout: 'fit',
                        resizable: false,
                        modal: true,
                        listeners: {
                            close: function (panel, pOpts) {

                                var winContainer = Ext.ComponentQuery.query('newCase')[0].down().nextSibling();

                                if (winContainer.hasListeners.afterrender) {
                                    
                                    window.location.reload();

                                }
                            }
                        },
                        items: {
                            xtype: 'caseSetupUI',
                            border: false
                        }
                    });
                    
                    createWin.show();
                }
            }
        }
    ]
});