﻿Ext.define('App.CaseReview.view.overview.overviewUI', {
    extend: 'Ext.form.Panel',
    alias: 'widget.overviewUI',
    baseCls: 'x-fieldset fieldset-padding',
    border: false,
    resizable: false,
    itemId: 'overviewTab',
    items: [
        //********************************************************************
        // Navigation panel
        //********************************************************************
        {
            xtype: 'panel',
            region: 'west',
            scrollable: 'vertical',
            width: 250,
            bodyCls: 'panel-background-color',
            itemId: 'overviewWest',
            items: [
            {
                xtype: 'panel',
                layout: 'vbox',
                border: 'false',
                bodyCls: 'panel-background-color',
                width: '100%',
                itemId: 'navPanel',
                defaults: {
                    componentCls: 'left-nav-item'
                },
                items: [
                    {
                        xtype: 'component',
                        margin: '20 0 0 0',
                        itemId: 'overviewHdr',
                        autoEl: {
                            tag: 'a',
                            html: "<span class='left-nav-overview-header'>Case Overview</span>"
                        }
                    },
                    {
                        xtype: 'component',
                        margin: '0 0 0 0',
                        width: '100%',
                        html: "<hr />"
                    },
                    {
                        xtype: 'hyperlink',
                        html: "<span class='overview-item'>Face Sheet</span>",
                        refItemId: null,
                        refTabId: 'faceSheet',
                        refPanel: null,
                        selectionCls: null
                    },
                    {
                        xtype: 'component',
                        margin: '0 0 0 0',
                        width: '100%',
                        html: "<hr />"
                    },
                    //***********************************************************
                    // Safety
                    //***********************************************************
                    {
                        xtype: 'container',
                        border: false,
                        width: '100%',
                        itemId: 'safetySectionLeftNav',
                        items: [
                        {
                            xtype: 'container',
                            border: false,
                            defaults: {
                                componentCls: 'overview-item-style',
                                xtype: 'hyperlink',
                                refTabId: 'safety',
                                refPanel: {
                                    parentPanelId: 'centerTabPanel',
                                    tabPanelId: 'safetyPanel'
                                },
                                selectionCls: null
                            },
                            items: [
                                {                                    
                                    html: "<span class='overview-item'>Section I: Safety</span>",
                                    refItemId: null,
                                    refPanel: null                                    
                                },
                                {
                                    html: "<p class='overview-subitem'>Safety Outcome 1</p>",
                                    refItemId: 'safetyOutcome1'
                                },
                                {
                                    html: "<p>Item 1</p>",
                                    refItemId: 'safetyItem1',
                                    clickTarget: {
                                        itemId: 'linkSafetyItem1'
                                    }
                                },
                                {
                                    xtype: 'component',
                                    margin: '0 -10 0 0',
                                    html: "<hr class='hr-style' />",
                                    refTabId: null,
                                    refPanel: null
                                }
                            ]
                        },
                        {
                            xtype: 'container',
                            border: false,
                            layout: 'vbox',
                            defaults: {
                                componentCls: 'overview-item-style'
                            },
                            items: [
                                {
                                    xtype: 'hyperlink',
                                    html: "<p class='overview-subitem'>Safety Outcome 2</p>",
                                    refItemId: 'safetyOutcome2',
                                    refTabId: 'safety',
                                    refPanel: {
                                        parentPanelId: 'centerTabPanel',
                                        tabPanelId: 'safetyPanel'
                                    },
                                    selectionCls: null
                                },
                                {
                                    xtype: 'container',
                                    border: false,
                                    layout: 'hbox',
                                    defaults: {
                                        componentCls: 'overview-item-style',
                                        xtype: 'hyperlink',
                                        refTabId: 'safety',
                                        refPanel: {
                                            parentPanelId: 'centerTabPanel',
                                            tabPanelId: 'safetyPanel'
                                        },
                                        selectionCls: null
                                    },
                                    items: [
                                        {
                                            html: "<span>Item 2</span>",
                                            refItemId: 'safetyItem2',
                                            clickTarget: {
                                                itemId: 'linkSafetyItem2'
                                            }
                                        },
                                        {
                                            xtype: 'component',
                                            html: "<div class='hbox-item-spacer'></div>",
                                            refTabId: null,
                                            refPanel: null
                                        },
                                        {
                                            html: "<span>Item 3</span>",
                                            refItemId: 'safetyItem3',
                                            clickTarget: {
                                                itemId: 'linkSafetyItem3'
                                            }
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            xtype: 'component',
                            margin: '0 -10 0 0',
                            html: "<hr />"
                        }
                        ]
                     },
                    //***********************************************************
                    // Permanency
                    //***********************************************************
                    {
                        xtype: 'container',
                        border: false,
                        width: '100%',
                        itemId : 'permanencySectionLeftNav',
                        defaults: {
                            componentCls: 'overview-item-style',
                            xtype: 'hyperlink',
                            refTabId: 'permanency',
                            refPanel: {
                                parentPanelId: 'centerTabPanel',
                                tabPanelId: 'permanencyPanel'
                            },
                            selectionCls: null
                        },
                        items: [
                            {
                                html: "<span class='overview-item'>Section II: Permanency</span>",
                                refItemId: null,
                                refPanel: null
                            },
                            {
                                html: "<p class='overview-subitem'>Permanency Outcome 1</p>",
                                refItemId: 'permanencyOutcome1'
                            },
                            {
                                xtype: 'container',
                                border: false,
                                layout: 'hbox',
                                defaults: {
                                    componentCls: 'overview-item-style',
                                    xtype: 'hyperlink',
                                    refTabId: 'permanency',
                                    refPanel: {
                                        parentPanelId: 'centerTabPanel',
                                        tabPanelId: 'permanencyPanel'
                                    },
                                    selectionCls: null
                                },
                                items: [
                                    {
                                        html: "<span>Item 4</span>",
                                        refItemId: 'item4',
                                        clickTarget: {
                                            itemId: 'linkItem4'
                                        }
                                    },
                                    {
                                        xtype: 'component',
                                        html: "<div class='hbox-item-spacer'></div>",
                                        refTabId: null,
                                        refPanel: null
                                    },
                                    {
                                        html: "<span>Item 5</span>",
                                        refItemId: 'item5',
                                        clickTarget: {
                                            itemId: 'linkItem5'
                                        }
                                    },
                                    {
                                        xtype: 'component',
                                        html: "<div class='hbox-item-spacer'></div>",
                                        refTabId: null,
                                        refPanel: null
                                    },
                                    {
                                        html: "<span>Item 6</span>",
                                        refItemId: 'item6',
                                        clickTarget: {
                                            itemId: 'linkItem6'
                                        }
                                    }
                                ]
                            },
                            {
                                xtype: 'component',
                                margin: '0 -10 0 0',
                                html: "<hr class='hr-style' />",
                                refTabId: null,
                                refPanel: null
                            },
                            {
                                html: "<p class='overview-subitem'>Permanency Outcome 2</p>",
                                refItemId: 'permanencyOutcome2'
                            },
                            {
                                xtype: 'container',
                                border: false,
                                layout: 'hbox',
                                items: [
                                    {
                                        xtype: 'container',
                                        border: false,
                                        layout: 'vbox',
                                        defaults: {
                                            componentCls: 'overview-item-style',
                                            xtype: 'hyperlink',
                                            refTabId: 'permanency',
                                            refPanel: {
                                                parentPanelId: 'centerTabPanel',
                                                tabPanelId: 'permanencyPanel'
                                            },
                                            selectionCls: null
                                        },
                                        items: [
                                            {
                                                html: "<span>Item 7</span>",
                                                refItemId: 'item7',
                                                clickTarget: {
                                                    itemId: 'linkItem7'
                                                }
                                            },
                                            {
                                                html: "<span>Item 10</span>",
                                                refItemId: 'item10',
                                                clickTarget: {
                                                    itemId: 'linkItem10'
                                                }
                                            }
                                        ]
                                    },                                          
                                    {
                                        xtype: 'component',
                                        html: "<div class='hbox-item-spacer'></div>"
                                    },
                                    {
                                        xtype: 'container',
                                        border: false,
                                        layout: 'vbox',
                                        defaults: {
                                            componentCls: 'overview-item-style',
                                            xtype: 'hyperlink',
                                            refTabId: 'permanency',
                                            refPanel: {
                                                parentPanelId: 'centerTabPanel',
                                                tabPanelId: 'permanencyPanel'
                                            },
                                            selectionCls: null
                                        },
                                        items: [
                                            {
                                                html: "<span>Item 8</span>",
                                                refItemId: 'item8',
                                                clickTarget: {
                                                    itemId: 'linkItem8'
                                                }
                                            },
                                            {
                                                html: "<span>Item 11</span>",
                                                refItemId: 'item11',
                                                clickTarget: {
                                                    itemId: 'linkItem11'
                                                }
                                            }
                                        ]
                                    },
                                    {
                                        xtype: 'component',
                                        html: "<div class='hbox-item-spacer'></div>"
                                    },
                                    {
                                        xtype: 'container',
                                        border: false,
                                        layout: 'vbox',
                                        defaults: {
                                            componentCls: 'overview-item-style',
                                            xtype: 'hyperlink',
                                            refTabId: 'permanency',
                                            refPanel: {
                                                parentPanelId: 'centerTabPanel',
                                                tabPanelId: 'permanencyPanel'
                                            },
                                            selectionCls: null
                                        },
                                        items: [
                                            {
                                                html: "<span>Item 9</span>",
                                                refItemId: 'item9',
                                                clickTarget: {
                                                    itemId: 'linkItem9'
                                                }
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                xtype: 'component',
                                margin: '0 -10 0 0',
                                html: "<hr />",
                                refTabId: null,
                                refPanel: null
                            }
                        ]
                    },
                    //***********************************************************
                    // Child and Family Well-Being
                    //***********************************************************
                    {
                        xtype: 'container',
                        border: false,
                        width: '100%',
                        itemId: 'wellbeingSectionLeftNav',
                        defaults: {
                            componentCls: 'overview-item-style',
                            xtype: 'hyperlink',
                            refTabId: 'wellBeing',
                            refPanel: {
                                parentPanelId: 'centerTabPanel',
                                tabPanelId: 'wellbeingPanel'
                            },
                            selectionCls: null
                        },
                        items: [
                            {
                                html: "<span class='overview-item'>Section III: Child and Family Well-Being</span>",
                                refItemId: null,
                                refPanel: null
                            },
                            {
                                html: "<p class='overview-subitem'>Well-Being Outcome 1</p>",
                                refItemId: 'wellbeingOutcome1'
                            },
                            {
                                xtype: 'container',
                                border: false,
                                layout: 'hbox',
                                items: [
                                    {
                                        xtype: 'container',
                                        border: false,
                                        layout: 'vbox',
                                        defaults: {
                                            componentCls: 'overview-item-style',
                                            xtype: 'hyperlink',
                                            refTabId: 'wellBeing',
                                            refPanel: {
                                                parentPanelId: 'centerTabPanel',
                                                tabPanelId: 'wellbeingPanel'
                                            },
                                            selectionCls: null
                                        },
                                        items: [
                                            {
                                                
                                                html: "<span>Item 12</span>",
                                                refItemId: 'item12',
                                                clickTarget: {
                                                    itemId: 'linkItem12'
                                                }
                                            },
                                            {
                                                html: "<span>Item 12C</span>",
                                                refItemId: 'item12C',
                                                clickTarget: {
                                                    itemId: 'linkItem12C'
                                                }
                                            },
                                            {
                                                html: "<span>Item 15</span>",
                                                refItemId: 'item15',
                                                clickTarget: {
                                                    itemId: 'linkItem15'
                                                }
                                            }
                                        ]
                                    },
                                    {
                                        xtype: 'component',
                                        html: "<div class='hbox-item-spacer'></div>"
                                    },
                                    {
                                        xtype: 'container',
                                        border: false,
                                        layout: 'vbox',
                                        defaults: {
                                            componentCls: 'overview-item-style',
                                            xtype: 'hyperlink',
                                            refTabId: 'wellBeing',
                                            refPanel: {
                                                parentPanelId: 'centerTabPanel',
                                                tabPanelId: 'wellbeingPanel'
                                            },
                                            selectionCls: null
                                        },
                                        items: [
                                            {                                                
                                                html: "<span>Item 12A</span>",
                                                refItemId: 'item12A',
                                                clickTarget: {
                                                    itemId: 'linkItem12A'
                                                }
                                            },
                                            {
                                                html: "<span>Item 13</span>",
                                                refItemId: 'item13',
                                                clickTarget: {
                                                    itemId: 'linkItem13'
                                                }
                                            }
                                        ]
                                    },
                                    {
                                        xtype: 'component',
                                        html: "<div class='hbox-item-spacer'></div>"
                                    },
                                    {
                                        xtype: 'container',
                                        border: false,
                                        layout: 'vbox',
                                        defaults: {
                                            componentCls: 'overview-item-style',
                                            xtype: 'hyperlink',
                                            refTabId: 'wellBeing',
                                            refPanel: {
                                                parentPanelId: 'centerTabPanel',
                                                tabPanelId: 'wellbeingPanel'
                                            },
                                            selectionCls: null
                                        },
                                        items: [
                                            {
                                                html: "<span>Item 12B</span>",
                                                refItemId: 'item12B',
                                                clickTarget: {
                                                    itemId: 'linkItem12B'
                                                }
                                            },
                                            {
                                                html: "<span>Item 14</span>",
                                                refItemId: 'item14',
                                                clickTarget: {
                                                    itemId: 'linkItem14'
                                                }
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                xtype: 'component',
                                margin: '0 -10 0 0',
                                html: "<hr class='hr-style' />",
                                refTabId: null,
                                refPanel: null
                            },
                            {
                                html: "<p class='overview-subitem'>Well-Being Outcome 2</p>",
                                refItemId: 'wellbeingOutcome2'
                            },
                            {
                                html: "<span>Item 16</span>",
                                refItemId: 'item16',
                                clickTarget: {
                                    itemId: 'linkItem16'
                                }
                            },
                            {
                                xtype: 'component',
                                margin: '0 -10 0 0',
                                html: "<hr class='hr-style' />",
                                refTabId: null,
                                refPanel: null
                            },
                            {
                                html: "<p class='overview-subitem'>Well-Being Outcome 3</p>",
                                refItemId: 'wellbeingOutcome3'
                            },
                            {
                                xtype: 'container',
                                border: false,
                                layout: 'hbox',
                                defaults: {
                                    componentCls: 'overview-item-style',
                                    xtype: 'hyperlink',
                                    refTabId: 'wellBeing',
                                    refPanel: {
                                        parentPanelId: 'centerTabPanel',
                                        tabPanelId: 'wellbeingPanel'
                                    },
                                    selectionCls: null
                                },
                                items: [
                                    {
                                        html: "<span>Item 17</span>",
                                        refItemId: 'item17',
                                        clickTarget: {
                                            itemId: 'linkItem17'
                                        }
                                    },
                                    {
                                        xtype: 'component',
                                        html: "<div class='hbox-item-spacer'></div>",
                                        refTabId: null,
                                        refPanel: null
                                    },
                                    {
                                        html: "<span>Item 18</span>",
                                        refItemId: 'item18',
                                        clickTarget: {
                                            itemId: 'linkItem18'
                                        }
                                    }
                                ]
                            },
                            {
                                xtype: 'component',
                                margin: '0 -10 0 0',
                                html: "<hr />",
                                refTabId: null,
                                refPanel: null
                            }
                        ]
                    },
                    //***********************************************************
                    // Case QA Notes
                    //***********************************************************                        
                    {
                        xtype: 'component',
                        autoEl: {
                            tag: 'a',
                            href: '#',
                            html: "<span class='overview-item'>Case QA Notes</span>"
                        },                            
                        config: {
                            notesWinRef: undefined
                        },
                        listeners: {
                            click: {
                                element: 'el',
                                fn: function () {

                                    var minWidth = Ext.getBody().getViewSize().width * 0.3;
                                    var maxHeight = Ext.getBody().getViewSize().height * 0.9;

                                    if (this.getWidth() < minWidth) {

                                        // Create modal window
                                        var notesWin = Ext.create('Ext.window.Window', {
                                            resizable: false,
                                            bodyCls: 'panel-background-color',
                                            modal: true,
                                            width: 750,
                                            closeAction: 'hide',
                                            maxHeight: maxHeight,
                                            dockedItems: [
                                                {
                                                    //*****************************************************
                                                    // Close window button]
                                                    //*****************************************************
                                                    xtype: 'toolbar',
                                                    dock: 'bottom',
                                                    border: false,
                                                    ui: 'footer',
                                                    items: ['->',
                                                        {
                                                            //CLOSE BUTTON                                
                                                            text: 'Close',
                                                            type: 'close',
                                                            itemId: 'caseNotesClose',
                                                            scale: 'medium'
                                                        }
                                                    ]
                                                }
                                            ],
                                            listeners: {
                                                click: {
                                                    element: 'el',
                                                    fn: function (source,eOpts) {

                                                        if (eOpts.innerText == 'Close') {

                                                            this.component.close();

                                                            return;
                                                        }

                                                        var winHeight = this.component.getHeight();

                                                        if (winHeight > maxHeight) {

                                                            this.component.setPosition(this.component.getX(), 0);
                                                            this.component.maxHeight = Ext.getBody().getViewSize().height * 0.8;
                                                        }
                                                    }
                                                }
                                            },
                                            items: [
                                                {
                                                    xtype: 'qaNotes',
                                                    itemId: 'caseNotes',
                                                    notesTitle: 'Case QA Notes',
                                                    margin: '0 20 0 0',
                                                    itemCode: 0,
                                                    noteType: 'case',
                                                    border: false,
                                                    collapsed: false,
                                                    scrollable: true,
                                                    listeners: {
                                                        beforerender: {
                                                            fn: function () {

                                                                qaNotesSummary = undefined;

                                                                buildCaseNotesCollection();
                                                            }
                                                        }
                                                    }
                                                }
                                            ]
                                        }).show();

                                        this.notesWinRef = notesWin;
                                    }                                        
                                }
                            }
                        }
                    }
                    ]
                }
            ]
        },
        {
            xtype: 'panel',
            region: 'center',
            scrollable: true,
            itemId: 'overviewCenter',
            width: 'auto',
            tbar: {
                xtype: 'headerUI',
                margin: 0
            },
            items: [
                {
                    xtype: 'qaStageIndicator'
                },
                {
                    xtype: 'container',
                    margin: '0 20 0 20',
                    border: false,                  
                    layout:
                        {
                            type: 'table',                            
                            columns: 2,
                            tableAttrs: {
                                style: {
                                    margin: '20 20 20 20',
                                    padding: '0px',
                                    border: '0px'
                                }
                            }
                    },
                    items: [                        
                        {
                            xtype: 'component',
                            margin: '10 20 10 0',
                            html: "<span class='overview-header'>Case Overview</span>",
                            width : 500
                        },
                        {
                            xtype: 'container',
                            border: false,
                            cls: 'align-right',
                            itemId: 'caseLinks',
                            defaults: {
                                componentCls: 'overview-item-style'
                            },
                            layout: 'column',
                            items: [
                                {
                                    xtype: 'component',
                                    itemId : 'caseSetUpLink',
                                    autoEl: {
                                        tag: 'a',
                                        href: '#',
                                        html: "Case Setup"
                                    }
                                },
                                {
                                    xtype: 'component',
                                    margin: '0 10 0 10',
                                    html: "|"
                                },
                                {
                                    xtype: 'component',
                                    itemId : 'eliminateCaseLink',
                                    autoEl: {
                                        tag: 'a',
                                        href: '#',
                                        html: "Eliminate Case"
                                    }
                                },
                                {
                                    xtype: 'button',
                                    text: 'Submit to QA',
                                    itemId: 'submitToQA',
                                    margin: '0 10 0 10',
                                    hidden: true
                                },
                                {
                                    xtype: 'button',
                                    text: 'Return to Reviewer',
                                    itemId: 'returnToReviewer',
                                    margin: '0 10 0 10',
                                    hidden: true
                                },
                                {
                                    xtype: 'button',
                                    text: 'Submit to Finalize',
                                    itemId: 'submitToFinalize',
                                    margin: '0 10 0 10',
                                    hidden: true
                                },
                                {
                                    xtype: 'button',
                                    text: 'Return to QA',
                                    itemId: 'returnToQA',
                                    margin: '0 10 0 10',
                                    hidden: true
                                },
                                {
                                    xtype: 'button',
                                    text: 'Approved',
                                    itemId: 'finalizeAndApprove',
                                    margin: '0 10 0 10',
                                    hidden: true
                                },
                                {
                                    xtype: 'button',
                                    text: 'Delete Case Review',
                                    itemId: 'deleteCaseReview',
                                    margin: '0 10 0 10',
                                    hidden : true
                                }
                            ]
                        }
                    ]
                },
                {
                    xtype: 'container',
                    bodyCls: 'panel-background-color',
                    border: false,
                    itemId : 'overviewTabSections',
                    layout:
                        {
                            type: 'table',
                            columns: 1,
                            tableAttrs: {
                                style: {
                                    width: '100%',
                                    margin: '20 20 20 20',
                                    padding: '0px',
                                    border: '0px'
                                }
                            }
                        },
                    items:[
                        //==========================================================================//
                        // Facesheet Section
                        //==========================================================================//
                        {
                            xtype: 'container',
                            bodyCls: 'panel-background-color',
                            border: false,
                            margin: '10 20 0 20',
                            layout:
                                {
                                    type: 'hbox',
                                    align: 'middle'
                                },
                            items: [
                                {
                                    xtype: 'component',
                                    html: "<span class='overview-title-header'>Face Sheet</span>"
                                    //,flex: 2
                                },
                                {
                                    xtype: 'component',
                                    width : 400,
                                    html: ' '
                                    //,flex: 6
                                },
                                {
                                    xtype: 'itemStatus',
                                    itemCode: 23,
                                    itemName: 'facesheet',
                                    outcomeCode: 21
                                    //,flex: 1.5
                                }
                            ]
                        },
                        //==========================================================================//
                        // Safety Section
                        //==========================================================================//
                        {
                            xtype: 'component',
                            margin: '40 0 0 20',
                            html: "<span class='overview-title-header'>Section I: Safety</span>"
                        },
                        {
                            xtype: 'component',
                            margin: '0 20 0 20',
                            html: "<hr class='hr-style' />"
                        },
                        //==========================================================================//
                        // Outcome 1
                        //==========================================================================//
                        {
                            xtype: 'container',
                            margin: '10 20 0 20',
                            border: false,
                            layout: 'vbox',
                            viewModel: {
                                type: 'safetyViewModel'
                            },
                            items: [
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '0 0 10 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            html: "<span class='overview-item-detail'>Safety Outcome 1:</span>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "<strong>Rating:</strong>",
                                            margin: '0 0 0 370',
                                        },
                                        {
                                            xtype: 'component',
                                            margin: '0 0 0 12',
                                            itemId: 'safetyOutcome1RatingDesc',
                                            bind: '{outcome1Rating}',
                                            listeners: {
                                                beforerender: function () {

                                                    this.html = getOutcomeRatingDesc('safetyItem1Rating', appPages.Safety);
                                                }
                                            }
                                        }
                                    ]
                                },                                
                                {
                                    xtype: 'component',
                                    html: "Children are, first and foremost, protected from abuse and neglect."
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '10 20 20 0',
                                    viewModel: {
                                        type: 'safetyViewModel'
                                    },
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Item 1:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Timeliness of Initiating Investigations of Reports of Child Maltreatment",
                                            componentCls: 'line-wrap',
                                            width: 400,
                                            margin: '0 0 0 70'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 2,
                                                    outcomeCode: 1,
                                                    itemId: 'item1Status',
                                                    itemName: 'item1',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 0 12',
                                                            itemId: 'item1RatingDesc',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    this.html = getItemRatingDesc('safetyItem1Rating', appPages.Safety);
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                }
                            ]
                        },
                        //==========================================================================//
                        // Outcome 2
                        //==========================================================================//
                        {
                            xtype: 'container',
                            margin: '10 20 0 20',
                            border: false,
                            layout: 'vbox',
                            viewModel: {
                                type: 'safetyViewModel'
                            },
                            items: [
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '0 0 10 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            html: "<span class='overview-item-detail'>Safety Outcome 2:</span>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "<strong>Rating:</strong>",
                                            margin: '0 0 0 370',
                                        },
                                        {
                                            xtype: 'component',
                                            margin: '0 0 0 12',
                                            itemId: 'safetyOutcome2RatingDesc',
                                            bind: '{outcome2Rating}',
                                            listeners: {
                                                beforerender: function () {

                                                    this.html = getOutcomeRatingDesc('safetyItem2Rating', appPages.Safety);
                                                }
                                            }
                                        }
                                    ]
                                },                                
                                {
                                    xtype: 'component',
                                    html: "Children are safely maintained in their homes whenever possible and appropriate."
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: true,
                                    margin: '10 20 10 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Item 2:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Services to Family to Protect Child(ren) in the Home and Prevent Removal or Re-Entry Into Foster Care",
                                            componentCls: 'line-wrap',
                                            width: 400,
                                            border : true,
                                            margin: '0 0 0 70'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 3,
                                                    itemName: 'item2',
                                                    outcomeCode: 2,
                                                    itemId: 'item2Status',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 10 12',
                                                            itemId: 'item2RatingDesc',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    this.html = getItemRatingDesc('safetyItem2Rating', appPages.Safety);
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '0 20 0 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Item 3:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Risk and Safety Assessment and Management",
                                            componentCls: 'line-wrap',
                                            width: 400,
                                            margin: '0 0 0 70'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 4,
                                                    itemName: 'item3',
                                                    outcomeCode: 2,
                                                    itemId: 'item3Status',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 0 12',
                                                            itemId: 'item3RatingDesc',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    this.html = getItemRatingDesc('safetyItem3Rating', appPages.Safety);
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                }
                            ]
                        },
                        //==========================================================================//
                        // Permanency Section
                        //==========================================================================//
                        {
                            xtype: 'component',
                            margin: '40 0 0 20',
                            html: "<span class='overview-title-header'>Section II: Permanency</span>"
                        },
                        {
                            xtype: 'component',
                            margin: '0 20 0 20',
                            html: "<hr class='hr-style' />"
                        },
                        //==========================================================================//
                        // Permanency Outcome 1
                        //==========================================================================//
                        {
                            xtype: 'container',
                            margin: '10 20 0 20',
                            border: false,
                            layout: 'vbox',
                            viewModel: {
                                type: 'permanencyViewModel'
                            },
                            items: [
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '0 0 10 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            html: "<span class='overview-item-detail'>Permanency Outcome 1:</span>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "<strong>Rating:</strong>",
                                            margin: '0 0 0 313',
                                        },
                                        {
                                            xtype: 'component',
                                            margin: '0 0 0 12',
                                            itemId: 'permanencyOutcome1RatingDesc',
                                            bind: '{outcome1Rating}',
                                            listeners: {
                                                beforerender: function () {

                                                    this.html = getOutcomeRatingDesc('permanencyItem4Rating', appPages.Permanency);
                                                }
                                            }
                                        }
                                    ]
                                },                                
                                {
                                    xtype: 'component',
                                    html: "Children have permanency and stability in their living situations."
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '10 20 0 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Item 4:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Stability of Foster Care Placement",
                                            componentCls: 'line-wrap',
                                            width: 400,
                                            margin: '0 0 0 70'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 5,
                                                    itemName: 'item4',
                                                    outcomeCode: 3,
                                                    itemId: 'item4Status',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 15 12',
                                                            itemId: 'item4RatingDesc',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    this.html = getItemRatingDesc('permanencyItem4Rating', appPages.Permanency);
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '0 20 0 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Item 5:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Permanency Goal for Child",
                                            componentCls: 'line-wrap',
                                            width: 400,
                                            margin: '0 0 0 70'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 6,
                                                    itemName: 'item5',
                                                    outcomeCode: 3,
                                                    itemId: 'item5Status',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 15 12',
                                                            itemId: 'item5RatingDesc',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    this.html = getItemRatingDesc('permanencyItem5Rating', appPages.Permanency);
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '0 20 0 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Item 6:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Achieving Reunification, Guardianship, Adoption, or Other Planned Permanent Living Arrangement",
                                            componentCls: 'line-wrap',
                                            width: 400,
                                            margin: '0 0 0 70'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 7,
                                                    itemName: 'item6',
                                                    outcomeCode: 3,
                                                    itemId: 'item6Status',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 0 12',
                                                            itemId: 'item6RatingDesc',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    this.html = getItemRatingDesc('permanencyItem6Rating', appPages.Permanency);
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                }
                            ]
                        },
                        //==========================================================================//
                        // Permanency Outcome 2
                        //==========================================================================//
                        {
                            xtype: 'container',
                            margin: '20 20 0 20',
                            border: false,
                            layout: 'vbox',
                            viewModel: {
                                type: 'permanencyViewModel'
                            },
                            items: [
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '0 0 10 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            html: "<span class='overview-item-detail'>Permanency Outcome 2:</span>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "<strong>Rating:</strong>",
                                            margin: '0 0 0 313',
                                        },
                                        {
                                            xtype: 'component',
                                            margin: '0 0 0 12',
                                            itemId: 'permanencyOutcome2RatingDesc',
                                            bind: '{outcome2Rating}',
                                            listeners: {
                                                beforerender: function () {

                                                    this.html = getOutcomeRatingDesc('permanencyItem7Rating', appPages.Permanency);
                                                }
                                            }
                                        }
                                    ]
                                },
                                {
                                    xtype: 'component',
                                    html: "The continuity of family relationships and connections is preserved for children."
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '10 20 0 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Item 7:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Placement With Siblings",
                                            componentCls: 'line-wrap',
                                            width: 400,
                                            margin: '0 0 0 70'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 8,
                                                    itemName: 'item7',
                                                    outcomeCode: 4,
                                                    itemId: 'item7Status',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 15 12',
                                                            itemId: 'item7RatingDesc',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    this.html = getItemRatingDesc('permanencyItem7Rating', appPages.Permanency);
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '0 20 0 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Item 8:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Visiting With Parents and Siblings in Foster Care",
                                            componentCls: 'line-wrap',
                                            width: 400,
                                            margin: '0 0 0 70'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 9,
                                                    itemName: 'item8',
                                                    outcomeCode: 4,
                                                    itemId: 'item8Status',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 15 12',
                                                            itemId: 'item8RatingDesc',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    this.html = getItemRatingDesc('permanencyItem8Rating', appPages.Permanency);
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '0 20 0 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Item 9:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Preserving Connections",
                                            componentCls: 'line-wrap',
                                            width: 400,
                                            margin: '0 0 0 70'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 10,
                                                    itemName: 'item9',
                                                    outcomeCode: 4,
                                                    itemId: 'item9Status',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 15 12',
                                                            itemId: 'item9RatingDesc',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    this.html = getItemRatingDesc('permanencyItem9Rating', appPages.Permanency);
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '0 20 0 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Item 10:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Relative Placement",
                                            componentCls: 'line-wrap',
                                            width: 400,
                                            margin: '0 0 0 64'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 11,
                                                    itemName: 'item10',
                                                    outcomeCode: 4,
                                                    itemId: 'item10Status',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 15 12',
                                                            itemId: 'item10RatingDesc',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    this.html = getItemRatingDesc('permanencyItem10Rating', appPages.Permanency);
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '0 20 0 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Item 11:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Relationship of Child in Care With Parents",
                                            componentCls: 'line-wrap',
                                            width: 400,
                                            margin: '0 0 0 64'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 12,
                                                    itemName: 'item11',
                                                    outcomeCode: 4,
                                                    itemId: 'item11Status',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 0 12',
                                                            itemId: 'item11RatingDesc',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    this.html = getItemRatingDesc('permanencyItem11Rating', appPages.Permanency);
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                }                                
                            ]
                        },
                        //==========================================================================//
                        // Child and Family Well-Being
                        //==========================================================================//
                        {
                            xtype: 'component',
                            margin: '40 0 0 20',
                            html: "<span class='overview-title-header'>Section III: Child and Family Well-Being</span>"
                        },
                        {
                            xtype: 'component',
                            margin: '0 20 0 20',
                            html: "<hr class='hr-style' />"
                        },
                        //==========================================================================//
                        // Well-Being Outcome 1
                        //==========================================================================//
                        {
                            xtype: 'container',
                            margin: '10 20 0 20',
                            border: false,
                            layout: 'vbox',
                            viewModel: {
                                type: 'wellbeingViewModel'
                            },
                            items: [
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '0 0 10 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            html: "<span class='overview-item-detail'>Well-Being Outcome 1:</span>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "<strong>Rating:</strong>",
                                            margin: '0 0 0 330',
                                        },
                                        {
                                            xtype: 'component',
                                            margin: '0 0 0 12',
                                            itemId: 'wellbeingOutcome1RatingDesc',
                                            bind: '{outcome1Rating}',
                                            listeners: {
                                                beforerender: function () {

                                                    this.html = getOutcomeRatingDesc('wellbeingItem12Rating', appPages.Wellbeing);
                                                }
                                            }
                                        }
                                    ]
                                },                                
                                {
                                    xtype: 'component',
                                    html: "Families have enhanced capacity to provide for their children's needs."
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '10 20 0 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Item 12:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Needs and Services of Child, Parents, and Foster Parents",
                                            componentCls: 'line-wrap',
                                            width: 395,
                                            margin: '0 0 0 70'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 13,
                                                    itemName: 'item12',
                                                    outcomeCode: 5,
                                                    itemId: 'item12Status',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 15 12',
                                                            itemId: 'item12RatingText',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    var rating = itemRatings.getItem12Rating();

                                                                    this.html = rating;
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '10 20 0 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Sub-Item 12A:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Needs Assessment and Services to Children",
                                            componentCls: 'line-wrap',
                                            width: 395,
                                            margin: '0 0 0 32'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 14,
                                                    itemName: 'item12A',
                                                    outcomeCode: 5,
                                                    itemId: 'item12AStatus',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 15 12',
                                                            itemId: 'item12ARatingDesc',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    this.html = getItemRatingDesc('wellbeingItem12ARating', appPages.Wellbeing);
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '10 20 0 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Sub-Item 12B:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Needs Assessment and Services to Parents",
                                            componentCls: 'line-wrap',
                                            width: 395,
                                            margin: '0 0 0 32'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 15,
                                                    itemName: 'item12B',
                                                    outcomeCode: 5,
                                                    itemId: 'item12BStatus',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 15 12',
                                                            itemId: 'item12BRatingDesc',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    this.html = getItemRatingDesc('wellbeingItem12BRating', appPages.Wellbeing);
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '10 20 0 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Sub-Item 12C:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Needs Assessment and Services to Foster Parents",
                                            componentCls: 'line-wrap',
                                            width: 395,
                                            margin: '0 0 0 32'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 16,
                                                    itemName: 'item12C',
                                                    outcomeCode: 5,
                                                    itemId: 'item12CStatus',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 15 12',
                                                            itemId: 'item12CRatingDesc',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    this.html = getItemRatingDesc('wellbeingItem12CRating', appPages.Wellbeing);
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '10 20 0 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Item 13:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Child and Family Involvement in Case Planning",
                                            componentCls: 'line-wrap',
                                            width: 395,
                                            margin: '0 0 0 70'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 17,
                                                    itemName: 'item13',
                                                    outcomeCode: 5,
                                                    itemId: 'item13Status',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 15 12',
                                                            itemId: 'item13RatingDesc',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    this.html = getItemRatingDesc('wellbeingItem13Rating', appPages.Wellbeing);
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '10 20 0 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Item 14:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Caseworker Visits With Child",
                                            componentCls: 'line-wrap',
                                            width: 395,
                                            margin: '0 0 0 70'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 18,
                                                    itemName: 'item14',
                                                    outcomeCode: 5,
                                                    itemId: 'item14Status',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 15 12',
                                                            itemId: 'item14RatingDesc',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    this.html = getItemRatingDesc('wellbeingItem14Rating', appPages.Wellbeing);
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '10 20 0 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Item 15:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Caseworker Visits With Parents",
                                            componentCls: 'line-wrap',
                                            width: 395,
                                            margin: '0 0 0 70'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 19,
                                                    itemName: 'item15',
                                                    outcomeCode: 5,
                                                    itemId: 'item15Status',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 15 12',
                                                            itemId: 'item15RatingDesc',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    this.html = getItemRatingDesc('wellbeingItem15Rating', appPages.Wellbeing);
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                }
                            ]
                        },
                        //==========================================================================//
                        // Well-Being Outcome 2
                        //==========================================================================//
                        {
                            xtype: 'container',
                            margin: '10 20 0 20',
                            border: false,
                            layout: 'vbox',
                            viewModel: {
                                type: 'wellbeingViewModel'
                            },
                            items: [
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '0 0 10 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            html: "<span class='overview-item-detail'>Well-Being Outcome 2:</span>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "<strong>Rating:</strong>",
                                            margin: '0 0 0 330',
                                        },
                                        {
                                            xtype: 'component',
                                            margin: '0 0 0 12',
                                            itemId: 'wellbeingOutcome2RatingDesc',
                                            bind: '{outcome2Rating}',
                                            listeners: {
                                                beforerender: function () {

                                                    this.html = getOutcomeRatingDesc('wellbeingItem16Rating', appPages.Wellbeing);
                                                }
                                            }
                                        }
                                    ]
                                },
                                {
                                    xtype: 'component',
                                    html: "Children receive appropriate services to meet their educational needs."
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '10 20 0 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Item 16:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Educational Needs of the Child",
                                            componentCls: 'line-wrap',
                                            width: 395,
                                            margin: '0 0 0 70'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 20,
                                                    itemName: 'item16',
                                                    outcomeCode: 6,
                                                    itemId: 'item16Status',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 15 12',
                                                            itemId: 'item16RatingDesc',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    this.html = getItemRatingDesc('wellbeingItem16Rating', appPages.Wellbeing);
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                }
                            ]
                        },
                        //==========================================================================//
                        // Well-Being Outcome 3
                        //==========================================================================//
                        {
                            xtype: 'container',
                            margin: '10 20 0 20',
                            border: false,
                            layout: 'vbox',
                            viewModel: {
                                type: 'wellbeingViewModel'
                            },
                            items: [
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '0 0 10 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            html: "<span class='overview-item-detail'>Well-Being Outcome 3:</span>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "<strong>Rating:</strong>",
                                            margin: '0 0 0 330',
                                        },
                                        {
                                            xtype: 'component',
                                            margin: '0 0 0 12',
                                            itemId: 'wellbeingOutcome3RatingDesc',
                                            bind: '{outcome3Rating}',
                                            listeners: {
                                                beforerender: function () {

                                                    this.html = getOutcomeRatingDesc('wellbeingItem17Rating', appPages.Wellbeing);
                                                }
                                            }
                                        }
                                    ]
                                },
                                {
                                    xtype: 'component',
                                    html: "Children receive adequate services to meet their physical and mental health needs."
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '10 20 0 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Item 17:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Physical Health of the Child",
                                            componentCls: 'line-wrap',
                                            width: 395,
                                            margin: '0 0 0 70'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 21,
                                                    itemName: 'item17',
                                                    outcomeCode: 7,
                                                    itemId: 'item17Status',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 15 12',
                                                            itemId: 'item17RatingDesc',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    this.html = getItemRatingDesc('wellbeingItem17Rating', appPages.Wellbeing);
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                },
                                {
                                    xtype: 'container',
                                    bodyCls: 'panel-background-color',
                                    border: false,
                                    margin: '10 20 0 0',
                                    layout:
                                        {
                                            type: 'hbox',
                                            align: 'begin'
                                        },
                                    items: [
                                        {
                                            xtype: 'component',
                                            margin: '0 30 0 0',
                                            html: "<strong>Item 18:</strong>"
                                        },
                                        {
                                            xtype: 'component',
                                            html: "Mental/Behavioral Health of the Child",
                                            componentCls: 'line-wrap',
                                            width: 395,
                                            margin: '0 0 0 70'
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout:
                                                {
                                                    type: 'vbox',
                                                    align: 'begin'
                                                },
                                            items: [
                                                {
                                                    xtype: 'itemStatus',
                                                    itemCode: 22,
                                                    itemName: 'item18',
                                                    outcomeCode: 7,
                                                    itemId: 'item18Status',
                                                    margin: '-5 0 0 0'
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout:
                                                    {
                                                        type: 'hbox',
                                                        align: 'begin'
                                                    },
                                                    items: [                                                        
                                                        {
                                                            xtype: 'component',
                                                            html: "<strong>Rating:</strong>"
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            margin: '0 0 0 12',
                                                            itemId: 'item18RatingDesc',
                                                            listeners: {
                                                                beforerender: function () {
                                                                    
                                                                    this.html = getItemRatingDesc('wellbeingItem18Rating', appPages.Wellbeing);
                                                                }
                                                            }
                                                        }
                                                    ]
                                                }
                                            ]
                                        }                                        
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ],

        }
    ]
});