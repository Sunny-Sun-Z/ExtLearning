﻿Ext.define('App.CaseReview.view.safety.SafetyViewModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.safetyViewModel',
    stores: {
        safetyPreAppAnswers: {},
        safetyCollection: {},
        itemApplicability: {}
    },
    formulas: {
        //
        // Pre-applicability answers
        //
        answerCode51: {

            get: function () {

                var result;
                var items = this.data.safetyPreAppAnswers.query('CodeDescriptionID', 51);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {

                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem2Question1().lastValue;
                    var newValue = getAppController().getItem2Question1().getValue();

                    this.data.answerCode51 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 51;
                    parms['value'] = value;
                    parms['pageName'] = 'safety';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode52: {

            get: function () {

                var result;
                var items = this.data.safetyPreAppAnswers.query('CodeDescriptionID', 52);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {

                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem2Question2().lastValue;
                    var newValue = getAppController().getItem2Question2().getValue();

                    this.data.answerCode52 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 52;
                    parms['value'] = value;
                    parms['pageName'] = 'safety';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode53: {

            get: function () {

                var result;
                var items = this.data.safetyPreAppAnswers.query('CodeDescriptionID', 53);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {

                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem2Question3().lastValue;
                    var newValue = getAppController().getItem2Question3().getValue();

                    this.data.answerCode53 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 53;
                    parms['value'] = value;
                    parms['pageName'] = 'safety';

                    updatePreApplicabilityAnswers(parms);
                }                
            }
        },
        answerCode54: {

            get: function () {

                var result;
                var items = this.data.safetyPreAppAnswers.query('CodeDescriptionID', 54);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem2Question4().lastValue;
                    var newValue = getAppController().getItem2Question4().getValue();

                    this.data.answerCode54 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 54;
                    parms['value'] = value;
                    parms['pageName'] = 'safety';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode55: {

            get: function () {

                var result;
                var items = this.data.safetyPreAppAnswers.query('CodeDescriptionID', 55);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {

                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem2Question5().lastValue;
                    var newValue = getAppController().getItem2Question5().getValue();

                    this.data.answerCode55 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 55;
                    parms['value'] = value;
                    parms['pageName'] = 'safety';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode56: {

            get: function () {

                var result;
                var items = this.data.safetyPreAppAnswers.query('CodeDescriptionID', 56);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {

                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem2Question6().lastValue;
                    var newValue = getAppController().getItem2Question6().getValue();

                    this.data.answerCode56 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 56;
                    parms['value'] = value;
                    parms['pageName'] = 'safety';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        //
        // Other safety data items
        //
        caseReviewId: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.CaseReviewID;
                }

                return result;
            }
        },
        childRemovedToEnsureSafetyExplained: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.ChildRemovedToEnsureSafetyExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.safetyCollection.count() > 0) {

                    this.data.safetyCollection.getAt(0).data.ChildRemovedToEnsureSafetyExplained = value;

                    this.data.childRemovedToEnsureSafetyExplained = value;
                }
            }
        },
        delayReason: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.DelayReason;
                }

                return result;
            },
            set: function (value) {

                if (this.data.safetyCollection.count() > 0) {

                    this.data.safetyCollection.getAt(0).data.DelayReason = value;

                    this.data.delayReason = value;
                }
            }
        },
        effortToPreventReEntryExplained: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.EffortToPreventReEntryExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.safetyCollection.count() > 0) {

                    this.data.safetyCollection.getAt(0).data.EffortToPreventReEntryExplained = value;

                    this.data.effortToPreventReEntryExplained = value;
                }
            }
        },
        faceToFaceReportsNotInAccordance: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.FaceToFaceReportsNotInAccordance;
                }

                return result;
            },
            set: function (value) {

                var valueTobeSaved = Ext.isEmpty(value) ? null : value;

                if (this.data.safetyCollection.count() > 0) {

                    this.data.safetyCollection.getAt(0).data.FaceToFaceReportsNotInAccordance = valueTobeSaved;

                    this.data.faceToFaceReportsNotInAccordance = valueTobeSaved;
                }
            }
        },
        fosterPlacementConcerOtherExplained: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.FosterPlacementConcerOtherExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.safetyCollection.count() > 0) {

                    this.data.safetyCollection.getAt(0).data.FosterPlacementConcerOtherExplained = value;

                    this.data.fosterPlacementConcerOtherExplained = value;
                }
            }
        },
        fosterSafetyOtherExplained: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.FosterSafetyOtherExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.safetyCollection.count() > 0) {

                    this.data.safetyCollection.getAt(0).data.FosterSafetyOtherExplained = value;

                    this.data.fosterSafetyOtherExplained = value;
                }
            }
        },
        initialAssesmentForAllChildrenInHomeExplained: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.InitialAssesmentForAllChildrenInHomeExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.safetyCollection.count() > 0) {

                    this.data.safetyCollection.getAt(0).data.InitialAssesmentForAllChildrenInHomeExplained = value;

                    this.data.initialAssesmentForAllChildrenInHomeExplained = value;
                }
            }
        },
        isChildRemovedToEnsureSafety: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.IsChildRemovedToEnsureSafety;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.safetyCollection.count() > 0) {

                        this.data.safetyCollection.getAt(0).data.IsChildRemovedToEnsureSafety = value;

                        this.data.isChildRemovedToEnsureSafety = value;
                    }
                }
            }
        },
        isDelayBeyondAgencyControl: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.IsDelayBeyondAgencyControl;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.safetyCollection.count() > 0) {

                        this.data.safetyCollection.getAt(0).data.IsDelayBeyondAgencyControl = value;

                        this.data.isDelayBeyondAgencyControl = value;
                    }
                }
            }
        },
        isEffortToPreventReEntry: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.IsEffortToPreventReEntry;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.safetyCollection.count() > 0) {

                        this.data.safetyCollection.getAt(0).data.IsEffortToPreventReEntry = value;

                        this.data.isEffortToPreventReEntry = value;
                    }
                }
            }
        },
        isFamilyMaltreatmentAllegations: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.IsFamilyMaltreatmentAllegations;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.safetyCollection.count() > 0) {

                        this.data.safetyCollection.getAt(0).data.IsFamilyMaltreatmentAllegations = value;

                        this.data.isFamilyMaltreatmentAllegations = value;
                    }
                }
            }
        },
        isFosterSafetyConcernDuringVisitation: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.IsFosterSafetyConcernDuringVisitation;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.safetyCollection.count() > 0) {

                        this.data.safetyCollection.getAt(0).data.IsFosterSafetyConcernDuringVisitation = value;

                        this.data.isFosterSafetyConcernDuringVisitation = value;
                    }
                }
            }
        },
        isFosterSafetyConcernNotAddressed: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.IsFosterSafetyConcernNotAddressed;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.safetyCollection.count() > 0) {

                        this.data.safetyCollection.getAt(0).data.IsFosterSafetyConcernNotAddressed = value;

                        this.data.isFosterSafetyConcernNotAddressed = value;
                    }                    
                }
            }
        },
        isInitialAssesmentForAllChildrenInHome: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.IsInitialAssesmentForAllChildrenInHome;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.safetyCollection.count() > 0) {

                        this.data.safetyCollection.getAt(0).data.IsInitialAssesmentForAllChildrenInHome = value;

                        this.data.isInitialAssesmentForAllChildrenInHome = value;
                    }                    
                }
            }
        },
        isMaltreatmentNotSubstantiated: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.IsMaltreatmentNotSubstantiated;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.safetyCollection.count() > 0) {

                        this.data.safetyCollection.getAt(0).data.IsMaltreatmentNotSubstantiated = value;

                        this.data.isMaltreatmentNotSubstantiated = value;
                    }                    
                }
            }
        },
        isOngoingAssesementForAllChildrenInHome: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.IsOngoingAssesementForAllChildrenInHome;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.safetyCollection.count() > 0) {

                        this.data.safetyCollection.getAt(0).data.IsOngoingAssesementForAllChildrenInHome = value;

                        this.data.isOngoingAssesementForAllChildrenInHome = value;
                    }                    
                }
            }
        },
        isSafetyConcernForOtherChildren: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.IsSafetyConcernForOtherChildren;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.safetyCollection.count() > 0) {

                        this.data.safetyCollection.getAt(0).data.IsSafetyConcernForOtherChildren = value;

                        this.data.isSafetyConcernForOtherChildren = value;
                    }
                }
            }
        },
        isSafetyPlanDevelopedAndMonitored: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.IsSafetyPlanDevelopedAndMonitored;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.safetyCollection.count() > 0) {

                        this.data.safetyCollection.getAt(0).data.IsSafetyPlanDevelopedAndMonitored = value;

                        this.data.isSafetyPlanDevelopedAndMonitored = value;
                    }                    
                }
            }
        },
        ongoingAssessmentForAllChildrenInHomeExplained: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.OngoingAssessmentForAllChildrenInHomeExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.safetyCollection.count() > 0) {

                    this.data.safetyCollection.getAt(0).data.OngoingAssessmentForAllChildrenInHomeExplained = value;

                    this.data.ongoingAssessmentForAllChildrenInHomeExplained = value;
                }                
            }
        },
        otherSafetyConcernExplained: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.OtherSafetyConcernExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.safetyCollection.count() > 0) {

                    this.data.safetyCollection.getAt(0).data.OtherSafetyConcernExplained = value;

                    this.data.otherSafetyConcernExplained = value;
                }
            }
        },
        reportsNotInAccordance: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.ReportsNotInAccordance;
                }

                return result;
            },
            set: function (value) {

                var valueTobeSaved = Ext.isEmpty(value) ? null : value;

                if (this.data.safetyCollection.count() > 0) {

                    this.data.safetyCollection.getAt(0).data.ReportsNotInAccordance = valueTobeSaved;

                    this.data.reportsNotInAccordance = valueTobeSaved;
                }                
            }
        },
        safetyId: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.SafetyID;
                }

                return result;
            },
            set: function (value) {

                if (this.data.safetyCollection.count() > 0) {

                    this.data.safetyCollection.getAt(0).data.SafetyID = value;

                    this.data.safetyID = value;
                }                
            }
        },
        safetyPlanDevelopedAndMonitoredExplained: {

            get: function () {

                var result;

                if (this.data.safetyCollection.count() > 0) {

                    result = this.data.safetyCollection.getAt(0).data.SafetyPlanDevelopedAndMonitoredExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.safetyCollection.count() > 0) {

                    this.data.safetyCollection.getAt(0).data.SafetyPlanDevelopedAndMonitoredExplained = value;

                    this.data.safetyPlanDevelopedAndMonitoredExplained = value;
                }                
            }
        },
        //
        // Item applicability
        //
        item1Applicable: {

            get: function () {

                var outcome1 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 1;
                });

                if (outcome1.length == 0) {

                    return;
                }

                var result = outcome1[0].data.CR_Item_Collection[0].IsApplicable;

                return result;
            },
            set: function (value) {

                if (!isApplicableValue(value)) {

                    return;
                }

                if (Ext.isNumeric(value)) {

                    var outcome1 = this.data.itemApplicability.data.items.filter(function (outcome) {

                        return outcome.data.OutcomeCode == 1;
                    });

                    if (outcome1.length == 0) {

                        return;
                    }

                    outcome1[0].data.CR_Item_Collection[0].IsApplicable = value;

                    this.data.item1Applicable = value;
                }
            }
        },
        item2Applicable: {

            get: function () {

                var result;
                var outcome2 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 2;
                });

                if (outcome2.length == 0) {

                    return;
                }

                var selectedItem = outcome2[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 3;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].IsApplicable;
                }                

                return result;
            },
            set: function (value) {

                if (!isApplicableValue(value)) {

                    return;
                }

                if (Ext.isNumeric(value)) {

                    var outcome2 = this.data.itemApplicability.data.items.filter(function (outcome) {

                        return outcome.data.OutcomeCode == 2;
                    });

                    if (outcome2.length == 0) {

                        return;
                    }

                    var selectedItem = outcome2[0].data.CR_Item_Collection.filter(function (item) {

                        return item.ItemCode == 3;
                    });

                    if (selectedItem.length > 0) {

                        selectedItem[0].IsApplicable = value;
                    }

                    this.data.item2Applicable = value;
                }
            }
        },
        item3Applicable: {

            get: function () {

                var result;
                var outcome2 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 2;
                });

                if (outcome2.length == 0) {

                    return;
                }

                var selectedItem = outcome2[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 4;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].IsApplicable;
                }

                return result;
            },
            set: function (value) {

                if (!isApplicableValue(value)) {

                    return;
                }

                var outcome2 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 2;
                });

                if (outcome2.length == 0) {

                    return;
                }

                var selectedItem = outcome2[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 4;
                });

                if (selectedItem.length > 0) {

                    selectedItem[0].IsApplicable = value;
                }

                this.data.item2Applicable = value;
            }
        },
        //
        // Item comments
        //
        item1Comments: {

            get: function () {

                var outcome1 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 1;
                });

                if (outcome1.length == 0) {

                    return;
                }

                var result = outcome1[0].data.CR_Item_Collection[0].Comments;

                return result;
            },
            set: function (value) {

                var outcome1 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 1;
                });

                if (outcome1.length == 0) {

                    return;
                }

                outcome1[0].data.CR_Item_Collection[0].Comments = value;

                this.data.item1Comments = value;
            }
        },
        item2Comments: {

            get: function () {

                var result;
                var outcome2 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 2;
                });

                if (outcome2.length == 0) {

                    return;
                }

                var selectedItem = outcome2[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 3;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].Comments;
                }

                return result;
            },
            set: function (value) {

                var outcome2 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 2;
                });

                if (outcome2.length == 0) {

                    return;
                }

                var selectedItem = outcome2[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 3;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].Comments = value;

                this.data.item2Comments = value;
            }
        },
        outcome1Rating: {

            get: function () {

                var result = outcomeRatings.safety.outcome1.ratingDescription;

                return result;
            },
            set: function (value) {

                if (!Ext.isEmpty(value)) {

                    outcomeRatings.safety.outcome1.ratingCode = value.ratingCode;
                    outcomeRatings.safety.outcome1.outcomeCode = value.outcomeCode;
                    outcomeRatings.safety.outcome1.ratingDescription = value.ratingDescription;

                    this.data.outcome1Rating = value.ratingDescription;
                }                
            }
        },
        outcome2Rating: {

            get: function () {

                var result = outcomeRatings.safety.outcome2.ratingDescription;

                return result;
            },
            set: function (value) {

                if (!Ext.isEmpty(value)) {

                    outcomeRatings.safety.outcome2.ratingCode = value.ratingCode;
                    outcomeRatings.safety.outcome2.outcomeCode = value.outcomeCode;
                    outcomeRatings.safety.outcome2.ratingDescription = value.ratingDescription;

                    this.data.outcome2Rating = value.ratingDescription;
                }
            }
        },
        //
        // Rating comments
        //
        item1RatingComments: {

            get: function () {

                var outcome1 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 1;
                });

                if (outcome1.length == 0) {

                    return;
                }

                var result = outcome1[0].data.CR_Item_Collection[0].RatingComments;

                return result;
            },
            set: function (value) {

                var outcome1 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 1;
                });

                if (outcome1.length == 0) {

                    return;
                }

                outcome1[0].data.CR_Item_Collection[0].RatingComments = value;

                this.data.item1RatingComments = value;
            }
        },
        item2RatingComments: {

            get: function () {

                var result;
                var outcome2 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 2;
                });

                if (outcome2.length == 0) {

                    return;
                }

                var selectedItem = outcome2[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 3;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].RatingComments;
                }

                return result;
            },
            set: function (value) {

                var outcome2 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 2;
                });

                if (outcome2.length == 0) {

                    return;
                }

                var selectedItem = outcome2[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 3;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].RatingComments = value;

                this.data.item2RatingComments = value;
            }
        },
        item3RatingComments: {

            get: function () {

                var result;
                var outcome2 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 2;
                });

                if (outcome2.length == 0) {

                    return;
                }

                var selectedItem = outcome2[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 4;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].RatingComments;
                }

                return result;
            },
            set: function (value) {

                var outcome2 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 2;
                });

                if (outcome2.length == 0) {

                    return;
                }

                var selectedItem = outcome2[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 4;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].RatingComments = value;

                this.data.item3RatingComments = value;
            }
        }
    }
});