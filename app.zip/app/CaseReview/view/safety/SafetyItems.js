﻿//
// Item 1
//
Ext.define('app.CaseReview.view.safety.Item1Questions', {
    extend: 'Ext.container.Container',
    alias: 'widget.item1Questions',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    border: true,
    itemId: 'item1Questions',
    trackResetOnLoad: true,
    items:
    [ 
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '20 20 20 20',
            itemId: 'question1AHeader',
            items: [
                {
                    xtype: 'component',
                    cls: 'panel-background-color',
                    border: false,
                    html: '<strong>A.</strong>'
                },
                {
                    xtype: 'component',
                    cls: 'panel-background-color',
                    border: false,
                    margin: '0 0 0 20',
                    width: '100%',
                    html: 'In how many of the reports listed in the table was the investigation or assessment NOT initiated in accordance with the state’s time frames and requirements for a report of that priority?'
                }
            ]
        },                                        
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '10 10 20 50',
            itemId: 'question1AContainer',
            layout: 'hbox',
            items: [
                {
                    xtype: 'numberfield',
                    hideTrigger: true,
                    keyNavEnabled: false,
                    mouseWheelEnabled: false,
                    allowDecimals: false,
                    itemId: 'question1A',
                    enableKeyEvents: true,
                    bind: '{reportsNotInAccordance}'
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgQuestion1A',
                    itemName: 'item1'
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '20 20 20 20',
            itemId: 'question1BHeader',
            items: [
                {
                    xtype: 'component',
                    bodyCls: 'panel-background-color',
                    border: false,
                    html: '<strong>B.</strong>'
                },
                {
                    xtype: 'component',
                    bodyCls: 'panel-background-color',
                    border: false,
                    margin: '0 0 0 20',
                    html: 'In how many of the reports in the table was face-to-face contact with the child(ren) who is (are) the subject of the report NOT made in accordance with the state’s time frames and requirements for a report of that priority?'
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '10 10 20 50',
            itemId: 'question1BContainer',
            layout: 'hbox',
            items: [
                {
                    xtype: 'numberfield',
                    itemId: 'question1B',
                    hideTrigger: true,
                    keyNavEnabled: false,
                    mouseWheelEnabled: false,
                    allowDecimals: false,
                    enableKeyEvents: true,
                    bind: '{faceToFaceReportsNotInAccordance}'
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgQuestion1B',
                    itemName: 'item1'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 0 20',
            itemId: 'question1BDelayHeader',
            html: 'Explain the reason for any delays related to reports identified in A and B in the narrative field below.'
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '10 10 20 20',
            itemId: 'question1BDelaysContainer',
            items: [
                {
                    xtype: 'textarea',                                                   
                    itemId: 'question1BDelayReason',
                    bind: '{delayReason}',
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height:150
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 1C Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            itemId: 'question1CInstructions',
            items: [
                {
                    contentEl: 'safety1CIns'
                }                
                //{
                //    html: "<div class='html-content-item-margins'><ul><li>If the answers to both questions A and B are zero, the answer to question C should be Not Applicable.</li></ul>" +
                //            "<ul><li>Delays in services provided by organizations or agencies under contract with the agency would not be considered to be beyond the control of the agency. However, where services are provided by another public state or local agency, such as law enforcement, the actions of these agencies may be beyond the control of the child welfare agency.</li></ul>" +
                //            "</li></ul></div>"
                //}
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '20 20 20 20',
            itemId: 'question1CHeader',
            items: [
                {
                    xtype: 'component',
                    bodyCls: 'panel-background-color',
                    border: false,
                    html: '<strong>C.</strong>'
                },
                {
                    xtype: 'component',
                    bodyCls: 'panel-background-color',
                    border: false,
                    margin: '0 0 0 20',
                    html: 'For all reports identified in A and B, were the reasons for the delays due to circumstances beyond the control of the agency?'
                }
            ]
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '10 10 20 20',
            itemId: 'question1CContainer',
            layout: 'hbox',                                            
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'item1CYes',
                    bind: '{isDelayBeyondAgencyControl}',
                    inputValue: 1,
                    name: 'item1C'
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    itemId: 'item1CNo',
                    bind: '{isDelayBeyondAgencyControl}',
                    inputValue: 2,
                    name: 'item1C'
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>NA</b>',
                    itemId: 'item1CNA',
                    bind: '{isDelayBeyondAgencyControl}',
                    inputValue: 3,
                    name: 'item1C'
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgQuestion1C',
                    itemName: 'item1'
                }
            ]
        }
    ]
});
//
// Item 2 Preapplicability questions
//
Ext.define('app.CaseReview.view.safety.Item2Preapp', {
    extend: 'Ext.container.Container',
    alias: 'widget.item2Preapp',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    itemId: 'safetyItem2',
    border: true,
    plugins: [
        {
            ptype: 'crsValidationPlugin',
            storeId: 'CR_MultiAnswer_CollectionStore',
            pluginId: 'item2PreApplicabilityPlugin',
            validationType: 'Safety',
            validationInput: ['PreApplicability', 'Applicability']
        }
    ],
    items:
    [
        {
            xtype: 'component',
            html: 'Item 2:	Services to Family to Protect Child(ren) in the Home and Prevent Removal or Re-Entry Into Foster Care',
            margin: '20 20 20 20',
            cls: 'outcome-item-header'
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Purpose of Assessment: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'safety2Assess'
                }
                //{
                //    html: "<div class='html-content-item-margins'><ul><li>To determine whether, during the period under review, the agency made concerted efforts to provide services to the family to prevent children's entry into foster care or re-entry after a reunification.</ul></div>"
                //}
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            itemId: 'item2PreApplicableCases',
            border: false,
            layout: 'hbox',
            items: [
                {
                    xtype: 'panel',
                    html: 'Item 2 Applicable Cases:',
                    margin: '0 0 0 20',
                    bodyCls: 'outcome-item-header'
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem2PreApplicableCases',
                    itemName: 'item2'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<ul> <li>In the list of criteria below, check Yes for any that apply and No for any that do not apply. A case is applicable for an assessment of this item if it meets at least one of the following criteria:</ul>'
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 0 40',
            itemId: 'item2Statement1',
            html: '<ul> <li>It is an in-home services case and the reviewer determines that there are concerns regarding the safety of at least one child in the family during the period under review.:</ul>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '0 0 0 100',
            inputField: 'CodeDescriptionID',
            codeDescValue: 51,
            itemId: 'item2Question1',
            defaults: {
                bind: '{answerCode51}'
            },
            plugins: [
                {
                    ptype: 'businessRulePlugin',
                    pluginId: 'item2ApplicableCases1',
                    rules: [
                        {
                            rType: 'validityCheck',
                            fields: [
                                {
                                    eType: 'lookup',
                                    fieldName: 'ReviewSubTypeID',
                                    storeId: 'CaseReviewStore',
                                    fieldValue: undefined
                                }
                            ],
                            predicate: 'ReviewSubTypeID.fieldValue == 18 || ReviewSubTypeID.fieldValue == 20'
                        }
                    ],
                    action: [
                        {
                            type: 'validityCheck',
                            fosterCareCase: true,
                            other: false
                        }
                    ]
                }
            ],
            items: [
                {
                    boxLabel: '<b>Yes</b>',
                    itemId: 'item2Concern1Yes',
                    inputValue: 1,
                    name: 'item2Concern1'
                },
                {
                    margin: '0 0 0 10',
                    boxLabel: '<b>No</b>',
                    itemId: 'item2Concern1No',
                    inputValue: 2,
                    name: 'item2Concern1',
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 0 40',
            itemId: 'item2Statement2',
            html: '<ul> <li>It is an in-home services case and services were provided for children at risk of foster care placement to remain safely in their homes.</ul>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '0 0 0 100',
            inputField: 'CodeDescriptionID',
            codeDescValue: 52,
            itemId: 'item2Question2',
            defaults: {
                bind: '{answerCode52}'
            },
            plugins: [
                {
                    ptype: 'businessRulePlugin',
                    pluginId: 'item2ApplicableCases2',
                    rules: [
                        {
                            rType: 'validityCheck',
                            fields: [
                                {
                                    eType: 'lookup',
                                    fieldName: 'ReviewSubTypeID',
                                    storeId: 'CaseReviewStore',
                                    fieldValue: undefined
                                }
                            ],
                            predicate: 'ReviewSubTypeID.fieldValue == 18 || ReviewSubTypeID.fieldValue == 20'
                        }
                    ],
                    action: [
                        {
                            type: 'validityCheck',
                            fosterCareCase: true,
                            other: false
                        }
                    ]
                }
            ],
            items: [
                {
                    boxLabel: '<b>Yes</b>',
                    itemId: 'item2Concern2Yes',
                    inputValue: 1,
                    name: 'item2Concern2',
                },
                {
                    margin: '0 0 0 10',
                    boxLabel: '<b>No</b>',
                    itemId: 'item2Concern2No',
                    inputValue: 2,
                    name: 'item2Concern2',
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 0 40',
            itemId: 'item2Statement3',
            html: '<ul> <li>It is a foster care case and the child entered foster care during the period under review due to safety concerns.</ul>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '0 0 0 100',
            inputField: 'CodeDescriptionID',
            codeDescValue: 53,
            itemId: 'item2Question3',
            defaults: {
                bind: '{answerCode53}'
            },
            plugins: [
                {
                    ptype: 'businessRulePlugin',
                    pluginId: 'item2ApplicableCases3',
                    rules: [
                        {
                            rType: 'validityCheck',
                            fields: [
                                {
                                    eType: 'lookup',
                                    fieldName: 'ReviewSubTypeID',
                                    storeId: 'CaseReviewStore',
                                    fieldValue: undefined
                                }
                            ],
                            predicate: 'ReviewSubTypeID.fieldValue == 17 || ReviewSubTypeID.fieldValue == 19'
                        },
                        {
                            rType: 'ruleCheck',
                            fields: [
                                {
                                    eType: 'lookup',
                                    fieldName: 'FosterEntryDate',
                                    storeId: 'CR_FaceSheet_CollectionStore',
                                    fieldValue: undefined
                                },
                                {
                                    eType: 'lookup',
                                    fieldName: 'ReviewStartDate',
                                    storeId: 'CaseReviewStore',
                                    fieldValue: undefined
                                },
                                {
                                    eType: 'lookup',
                                    fieldName: 'ReviewSubTypeID',
                                    storeId: 'CaseReviewStore',
                                    fieldValue: undefined
                                }
                            ],
                            predicate: 'FosterEntryDate.fieldValue < ReviewStartDate.fieldValue && (ReviewSubTypeID.fieldValue == 18 || ReviewSubTypeID.fieldValue == 20)'
                        }
                    ],
                    action: [
                        {
                            type: 'validityCheck',
                            inHomeCase: true,
                            other: false
                        },
                        {
                            type: 'ruleCheck',
                            fosterCareCase: true,
                            other: false
                        }
                    ]
                }
            ],
            items: [
                {
                    boxLabel: '<b>Yes</b>',
                    itemId: 'item2Concern3Yes',
                    inputValue: 1,
                    name: 'item2Concern3',
                },
                {
                    margin: '0 0 0 10',
                    boxLabel: '<b>No</b>',
                    itemId: 'item2Concern3No',
                    inputValue: 2,
                    name: 'item2Concern3',
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 0 40',
            itemId: 'item2Statement4',
            html: '<ul> <li>It is a foster care case and the child was reunified during the period under review ' +
                'or was returned home on a trial basis, and the reviewer determines that there are concerns regarding the safety of that child in the home.</ul>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '0 0 0 100',
            inputField: 'CodeDescriptionID',
            codeDescValue: 54,
            itemId: 'item2Question4',
            defaults: {
                bind: '{answerCode54}'
            },
            plugins: [
                {
                    ptype: 'businessRulePlugin',
                    pluginId: 'item2ApplicableCases4',
                    rules: [
                        {
                            rType: 'validityCheck',
                            fields: [
                                {
                                    eType: 'lookup',
                                    fieldName: 'ReviewSubTypeID',
                                    storeId: 'CaseReviewStore',
                                    fieldValue: undefined
                                }
                            ],
                            predicate: 'ReviewSubTypeID.fieldValue == 17 || ReviewSubTypeID.fieldValue == 19'
                        }
                    ],
                    action: [
                        {
                            type: 'validityCheck',
                            inHomeCase: true,
                            other: false
                        }
                    ]
                }
            ],
            items: [
                {
                    boxLabel: '<b>Yes</b>',
                    itemId: 'item2Concern4Yes',
                    inputValue: 1,
                    name: 'item2Concern4',
                },
                {
                    margin: '0 0 0 10',
                    boxLabel: '<b>No</b>',
                    itemId: 'item2Concern4No',
                    inputValue: 2,
                    name: 'item2Concern4',
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 0 40',
            itemId: 'item2Statement5',
            html: '<ul> <li>It is a foster care case, and although the target child entered foster care before the period under review and remained in care for the entire period under review, ' +
                'there are other children in the home and the reviewer determines that there are concerns regarding the safety of those children during the period under review.</ul>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '0 0 0 100',
            inputField: 'CodeDescriptionID',
            codeDescValue: 55,
            itemId: 'item2Question5',
            defaults: {
                bind: '{answerCode55}'
            },
            plugins: [
                {
                    ptype: 'businessRulePlugin',
                    pluginId: 'item2ApplicableCases5',
                    rules: [
                        {
                            rType: 'validityCheck',
                            fields: [
                                {
                                    eType: 'lookup',
                                    fieldName: 'ReviewSubTypeID',
                                    storeId: 'CaseReviewStore',
                                    fieldValue: undefined
                                }
                            ],
                            predicate: 'ReviewSubTypeID.fieldValue == 17 || ReviewSubTypeID.fieldValue == 19'
                        },
                        {
                            rType: 'ruleCheck',
                            fields: [
                                {
                                    eType: 'lookup',
                                    fieldName: 'FosterEntryDate',
                                    storeId: 'CR_FaceSheet_CollectionStore',
                                    fieldValue: undefined
                                },
                                {
                                    eType: 'lookup',
                                    fieldName: 'ReviewStartDate',
                                    storeId: 'CaseReviewStore',
                                    fieldValue: undefined
                                },
                                {
                                    eType: 'lookup',
                                    fieldName: 'ReviewSubTypeID',
                                    storeId: 'CaseReviewStore',
                                    fieldValue: undefined
                                },
                                {
                                    eType: 'lookup',
                                    fieldName: 'ReviewCompleted',
                                    storeId: 'CaseReviewStore',
                                    fieldValue: undefined
                                },
                                {
                                    eType: 'lookup',
                                    fieldName: 'EpisodeDischargeDate',
                                    storeId: 'CR_FaceSheet_CollectionStore',
                                    fieldValue: undefined
                                }
                            ],
                            predicate: '((FosterEntryDate.fieldValue >= ReviewStartDate.fieldValue && FosterEntryDate.fieldValue <= ReviewCompleted.fieldValue) && (ReviewSubTypeID.fieldValue == 18 || ReviewSubTypeID.fieldValue == 20)) || (EpisodeDischargeDate.fieldValue == null || EpisodeDischargeDate.fieldValue == undefined)'
                        }
                    ],
                    action: [
                        {
                            type: 'validityCheck',
                            inHomeCase: true,
                            other: false
                        },
                        {
                            type: 'ruleCheck',
                            fosterCareCase: true,
                            other: false
                        }
                    ]
                }
            ],
            items: [
                {
                    boxLabel: '<b>Yes</b>',
                    itemId: 'item2Concern5Yes',
                    inputValue: 1,
                    name: 'item2Concern5',
                },
                {
                    margin: '0 0 0 10',
                    boxLabel: '<b>No</b>',
                    itemId: 'item2Concern5No',
                    inputValue: 2,
                    name: 'item2Concern5',
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<ul> <li>However, a case is not applicable for an assessment of this item if it meets the following criterion, even if the case is applicable based on the criteria above: </ul>'
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 0 40',
            html: '<ul> <li>Only a safety plan was needed to ensure the child(ren)\'s safety and no safety-related services were necessary based on the circumstances of the case. (In this situation, item 2 would be Not Applicable and the safety plan would be assessed in item 3.)</ul>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '0 0 0 100',
            itemId: 'item2Question6',
            inputField: 'CodeDescriptionID',
            codeDescValue: 56,
            defaults: {
                bind: '{answerCode56}'
            },
            items: [
                {
                    boxLabel: '<b>Yes</b>',
                    itemId: 'item2Concern6Yes',
                    inputValue: 1,
                    name: 'item2Concern6',
                },
                {
                    margin: '0 0 0 10',
                    boxLabel: '<b>No</b>',
                    itemId: 'item2Concern6No',
                    inputValue: 2,
                    name: 'item2Concern6',
                }
            ]
        },
        {
            xtype: 'component',
            html: 'Is this case applicable?',
            margin: '20 20 20 20',
            cls: 'outcome-item-header'
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 0 20',
            html: 'Select the appropriate response. If the response is No, the case will be rated as Not Applicable in the ratings section for this item.'
        },
        {
            xtype: 'itemApplicable',
            store: 'CR_Outcome_CollectionStore',
            bodyCls: 'panel-background-color',
            itemId: 'item2CaseApplicableContainer',
            border: false,
            OutcomeCode: 2,
            ItemCode: 3,
            items: [
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '10 0 0 40',
                    itemId: 'item2CaseContainer',
                    items: [
                        {
                            xtype: 'radio',
                            boxLabel: '<b>Yes</b>',
                            itemId: 'item2CaseApplicableYes',
                            bind: '{item2Applicable}',
                            inputValue: 1,
                            name: 'applicableItem2'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>No</b>',
                            itemId: 'item2CaseApplicableNo',
                            bind: '{item2Applicable}',
                            inputValue: 2,
                            name: 'applicableItem2'
                        }
                    ]
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem2CaseApplicable',
                    itemName: 'item2'
                },
                {
                    xtype: 'component',
                    cls: 'panel-background-color',
                    border: false,
                    margin: '15 0 0 20',
                    html: '<b>Optional</b>: Provide comments in the narrative field below.'
                },
                {
                    xtype: 'container',
                    cls: 'panel-background-color',
                    itemId: 'item2CommentsContainer',
                    border: false,
                    margin: '10 10 20 20',
                    items: [
                        {
                            xtype: 'textarea',
                            itemId: 'item2Comments',
                            bind: '{item2Comments}',
                            //height: 100,  This does work with grow: true
                            //growMin: 100,
                            //growMax: 350,
                            //grow: true,
                            width: '75%',
                            maxlength: 4100,
                            enforceMaxLength: true,
                            height: 150
                        }
                    ]
                }
            ]
        }
    ]
});
//
// Question 2A
//
Ext.define('app.CaseReview.view.safety.Question2A', {
    extend: 'Ext.container.Container',
    alias: 'widget.question2A',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    scrollable: true,
    itemId: 'question2APanel',
    trackResetOnLoad: true,
    items:
     [
         {
             xtype: 'listPanel',
             bodyCls: 'panel-background-color',
             title: "<div class='html-content-header-margins'>Question 2A Definitions: [SHOW]</div>",
             margin: '20 20 20 20',
             padding: '0 0 0 0',
             items: [
                 {
                     contentEl: 'safety2ADef'
                 }
                 //{
                 //    html: "<div class='html-content-item-margins'>" +
                 //           "<ul><li> 'Appropriate services,' for the purposes of item 2, are those that are provided to, or arranged for, the family with the explicit goal of ensuring the child’s safety. Examples include: (1) if there are safety issues in the home due to environmental hazards, homemaking services could be an appropriate safety-related service; (2) if there are safety concerns related to the parent’s ability to manage specific child needs or child behaviors, intensive in-home services could be an appropriate safety-related service; (3) child care services could be a safety-related service in cases where the child was being cared for in an unsafe setting or by an inappropriate caregiver; and (4) if there are safety concerns related to parental substance abuse, substance abuse treatment could be an appropriate safety-related service. In most cases a child’s need for mental health services, education-related services, or services to address health issues, would not be considered relevant to the child’s safety if the child remained in the home. The agency’s efforts to meet those service needs are assessed in other items." +
                 //           "<li>'Concerted efforts,' for the purposes of item 2, refers to facilitating a family’s access to needed services and working to engage the family in those services.</li>" +
                 //           "</ul></div>"
                 //}
             ]
         },
         {
             xtype: 'listPanel',
             bodyCls: 'panel-background-color',
             title: "<div class='html-content-header-margins'>Question 2A Instructions: [SHOW]</div>",
             margin: '20 20 20 20',
             padding: '0 0 0 0',
             items: [
                 {
                     contentEl: 'safety2AIns'
                 }
                 //{
                 //    html: "<div class='html-content-item-margins'>" +
                 //           "<ul><li> In answering question A, focus only on whether the agency made concerted efforts to provide appropriate and relevant services to the family to address the safety issues in the family so that the child could remain safely in the home or would not re-enter foster care after reunification. Concerns about monitoring service participation and safety planning and assessment of progress made will be captured in item 3." +
                 //           "<li>If the agency removed the child from the home without making concerted efforts to provide services, the answer to question A should be No, even if the agency determined that it was necessary to remove the child for safety reasons. This issue will be addressed in question B.</li>" +
                 //           "</ul></div>"
                 //}
             ]
         },
         {
             xtype: 'component',
             cls: 'panel-background-color',
             border: false,
             margin: '15 0 0 20',
             html: '<strong>A. For the period under review, did the agency make concerted efforts to provide or arrange for appropriate services for the family to protect the children and prevent their entry into foster care or re-entry into foster care after a reunification? (Be sure to assess the entire period under review.)</strong>'
         },
         {
             xtype: 'radiogroup',
             bodyCls: 'panel-background-color',
             border: false,
             layout: 'hbox',
             margin: '10 20 20 40',
             itemId: 'item2Question2A',
             items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'Question2AYes',
                    inputValue: 1,
                    bind: '{isEffortToPreventReEntry}',
                    name: 'question2A'
                },
                {
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    margin: '0 0 0 10',
                    itemId: 'Question2ANo',
                    inputValue: 2,
                    bind: '{isEffortToPreventReEntry}',
                    name: 'question2A'
                }
             ]
         },
         {
             xtype: 'component',
             cls: 'panel-background-color',
             border: false,
             margin: '15 0 0 40',
             html: 'If No, explain any concerns in the narrative field below.'
         },
         {
             xtype: 'container',
             cls: 'panel-background-color',
             border: false,
             margin: '10 10 20 40',
             layout: 'hbox',
             itemId: 'question2ANarrative',
             items: [
                {
                    xtype: 'textarea',
                    itemId: 'agencyEffortConcerns',
                    bind: '{effortToPreventReEntryExplained}',
                    disabled: true,
                    //height: 100,  This does work with grow: true
                    //growMin: 100,
                    //growMax: 350,
                    //grow: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgQuestion2ANarrative',
                    itemName: 'item2'
                }
             ]
         }
     ]
});
//
// Question 2B
//
Ext.define('app.CaseReview.view.safety.Question2B', {
    extend: 'Ext.container.Container',
    alias: 'widget.question2B',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    scrollable: true,
    itemId: 'question2BPanel',
    trackResetOnLoad: true,
    items:
     [
         {
             xtype: 'listPanel',
             bodyCls: 'panel-background-color',
             title: "<div class='html-content-header-margins'>Question 2B Instructions: [SHOW]</div>",
             margin: '20 20 20 20',
             padding: '0 0 0 0',
             items: [
                 {
                     contentEl: 'safety2BIns'
                 }
                 //{
                 //    html: "<div class='html-content-item-margins'>" +
                 //           "<ul><li>If the answer to question A is Yes, but, after making efforts to provide services, the child was removed from the home during the period under review due to unmanageable safety concerns, the answer to question B should be Not Applicable." +
                 //           "<li>If the child was not removed from the home during the period under review, the answer to question B should be Not Applicable.</li>" +
                 //           "<li>Focus on whether the circumstances of the case and of the removal suggest that services would not have been able to ensure the child’s safety if the child remained in the home. If the information indicates that it was necessary to remove the child immediately to ensure the child’s safety, the answer to question B should be Yes. If the information indicates that services could have been provided to prevent removal but the child was removed without providing those services, this question should be answered No.</li>" +
                 //           "<li>If services should have been offered to protect the child but were not, because those services were not available in the community, the answer to question B should be No.</li>" +
                 //           "</ul></div>"
                 //}
             ]
         },
         {
             xtype: 'component',
             cls: 'panel-background-color',
             border: false,
             margin: '15 0 0 20',
             html: '<strong>B. If, during the period under review, any child was removed from the home without providing or arranging for services, was this action necessary to ensure the child’s safety?</strong>'
         },
         {
             xtype: 'radiogroup',
             bodyCls: 'panel-background-color',
             border: false,
             layout: 'hbox',
             margin: '10 20 20 40',
             itemId: 'item2Question2B',
             plugins: [
                 {
                     ptype: 'businessRulePlugin',
                     pluginId: 'item2Quest2B',
                     rules: [
                         {
                             rType: 'validityCheck',
                             fields: [
                                 {
                                     eType: 'lookup',
                                     fieldName: 'ReviewSubTypeID',
                                     storeId: 'CaseReviewStore',
                                     fieldValue: undefined
                                 }
                             ],
                             predicate: 'ReviewSubTypeID.fieldValue == 18 || ReviewSubTypeID.fieldValue == 20'
                         }
                     ],
                     action: [
                         {
                             type: 'validityCheck',
                             fosterCareCase: true,
                             other: false
                         }
                     ]
                 }
             ],
             items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'Question2BYes',
                    inputValue: 1,
                    bind: '{isChildRemovedToEnsureSafety}',
                    name: 'question2B'
                },
                {
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    margin: '0 0 0 10',
                    itemId: 'Question2BNo',
                    inputValue: 2,
                    bind: '{isChildRemovedToEnsureSafety}',
                    name: 'question2B'
                },
                {
                    xtype: 'radio',
                    boxLabel: '<b>NA</b>',
                    margin: '0 0 0 10',
                    itemId: 'Question2BNA',
                    inputValue: 3,
                    bind: '{isChildRemovedToEnsureSafety}',
                    name: 'question2B'
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem2Question2B',
                    itemName: 'item2'
                }
             ]
         },
         {
             xtype: 'component',
             cls: 'panel-background-color',
             border: false,
             margin: '15 0 0 40',
             html: 'If No, explain any concerns in the narrative field below.'
         },
         {
             xtype: 'container',
             cls: 'panel-background-color',
             border: false,
             margin: '10 10 20 40',
             layout: 'hbox',
             itemId: 'question2BNarrative',
             items: [
                {
                    xtype: 'textarea',
                    itemId: 'childRemovalConcerns',
                    bind: '{childRemovedToEnsureSafetyExplained}',
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgQuestion2BNarrative',
                    itemName: 'item2'
                }
             ]
         }
     ]
});
//
// Question 3A1
//
Ext.define('app.CaseReview.view.safety.Question3A1', {
    extend: 'Ext.container.Container',
    alias: 'widget.question3A1',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    itemId: 'section3A1',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>A1. Did any of the following concerns exist during the period under review?</strong>'
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 40',
            html: 'There were maltreatment allegations about the family but they were never formally reported or formally investigated/assessed.'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '10 20 20 40',
            itemId: 'Question3A1A',
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'Question3A1YesA',
                    inputValue: 1,
                    bind: '{isFamilyMaltreatmentAllegations}',
                    name: 'question3A1A'
                },
                {
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    margin: '0 0 0 10',
                    itemId: 'Question3A1NoA',
                    inputValue: 2,
                    bind: '{isFamilyMaltreatmentAllegations}',
                    name: 'question3A1A'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 40',
            html: 'There were maltreatment allegations that were not substantiated despite evidence that would support substantiation.'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '10 20 20 40',
            itemId: 'Question3A1B',
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'Question3A1YesB',
                    inputValue: 1,
                    bind: '{isMaltreatmentNotSubstantiated}',
                    name: 'question3A1B'
                },
                {
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    margin: '0 0 0 10',
                    itemId: 'Question3A1NoB',
                    inputValue: 2,
                    bind: '{isMaltreatmentNotSubstantiated}',
                    name: 'question3A1B'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 3A and 3B Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'safety3Def'
                }
                //{
                //    html: "<div class='html-content-item-margins'><ul><li>" +
                //          "'Risk' is defined as the likelihood that a child will be maltreated in the future.</li>" +
                //          "<li>An assessment of safety is made to determine whether a child is in a safe environment. A safe environment is one in which there are no threats that pose a danger or, if there are threats, there is a responsible adult in a caregiving role who demonstrates sufficient capacity to protect the child.</li>" +
                //          "<li>'Target child' is defined as the child in a foster care case who is the subject of the case.</li></ul></div>"
                //}
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 3A and 3B Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'safety3Ins'
                }
                //{
                //    html: "<div class='html-content-item-margins'><ul>" +
                //          "<li>For foster care cases, questions A and B should be answered for the target child in foster care and any children remaining in the home.</li>" +
                //          "<li>For in-home services cases, questions A and B should be answered for all children in the home.</li>" +
                //          "<li>In responding to questions A and B, consider any concerns selected in 3A1.</li>" +
                //          "<li>Question A should be answered Not Applicable if the case was opened before the period under review.</li></ul></div>"
                //}
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 3A and 3B Tip: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'safety3Tip'
                }
                //{
                //    html: "<div class='html-content-item-margins'>" +
                //          "For questions 3A and 3B, consider whether the frequency and quality of caseworker visits with parents and/or children was adequate to appropriately assess risk and safety concerns during the period under review.</div>"
                //}
            ]
        }
    ]
});
//
// Question 3A
//
Ext.define('app.CaseReview.view.safety.Question3A', {
    extend: 'Ext.container.Container',
    alias: 'widget.question3A',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    itemId: 'section3A',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>A. If the case was opened during the period under review, did the agency conduct an initial assessment that accurately assessed all risk and safety concerns for the target child in foster care and/or any child(ren) in the family remaining in the home?</strong>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '10 20 20 40',
            itemId: 'item3QuestionA',
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'Question3AYes',
                    inputValue: 1,
                    bind: '{isInitialAssesmentForAllChildrenInHome}',
                    name: 'question3A'
                },
                {
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    margin: '0 0 0 10',
                    itemId: 'Question3ANo',
                    inputValue: 2,
                    bind: '{isInitialAssesmentForAllChildrenInHome}',
                    name: 'question3A'
                },
                {
                    xtype: 'radio',
                    boxLabel: '<b>NA</b>',
                    margin: '0 0 0 10',
                    itemId: 'Question3ANA',
                    inputValue: 3,
                    bind: '{isInitialAssesmentForAllChildrenInHome}',
                    name: 'question3A'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 40',
            html: 'If No, explain any concerns in the narrative field below.'
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '10 10 20 40',
            itemId: 'item3QuestionANarrative',
            layout: 'hbox',
            items: [
                {
                    xtype: 'textarea',
                    itemId: 'initialAssessmentExplained',
                    bind: '{initialAssesmentForAllChildrenInHomeExplained}',
                    disabled: true,
                    //height: 100,  This does work with grow: true
                    //growMin: 100,
                    //growMax: 350,
                    //grow: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem3QuestionANarrative',
                    itemName: 'item3'
                }
            ]
        }
    ]
});
//
// Question 3B
//
Ext.define('app.CaseReview.view.safety.Question3B', {
    extend: 'Ext.container.Container',
    alias: 'widget.question3B',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    itemId: 'section3B',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 3B Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'safety3BIns'
                }
                //{
                //    html: "<div class='html-content-item-margins'><ul>" +
                //          "<li>In responding to question B, determine whether ongoing assessments (formal or informal) were conducted during the period under review. If the agency conducted an initial assessment of risk and safety at the onset of the case, but did not assess for risk and safety concerns on an ongoing basis and at critical times in the case (for example, when there were new allegations of abuse or neglect; changing family conditions; new people coming into the family home or having access to the children; changes to visitation, upon reunification, or at case closure) then the answer to question B should be No.</li>" +
                //          "<li>Note that in some cases that were opened during the period under review, the issue of ongoing assessments may not be relevant because the case was opened for a very short period of time (for example, if the case was opened shortly before the end of the period under review and during the initial assessment the agency determined that there were no risk or safety concerns, then it may be reasonable to conclude that the agency would not have conducted a second risk and safety assessment during the period under review). If the case was opened during the period under review and you believe that ongoing assessments were not necessary given the time frame and circumstances of the case, question B may be answered Not Applicable.</li>" +
                //          "<li>If a case was closed during the period under review, determine whether the agency conducted a risk and safety assessment before closing the case. If not, the answer to question B should be No.</li>" +
                //          "</ul></div>"
                //}
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>B. During the period under review, did the agency conduct ongoing assessments that accurately assessed all of the risk and safety concerns for the target child in foster care and/or any child(ren) in the family remaining in the home?</strong>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '10 20 20 40',
            itemId: 'item3QuestionB',
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'Question3BYes',
                    inputValue: 1,
                    bind: '{isOngoingAssesementForAllChildrenInHome}',
                    name: 'questionB'
                },
                {
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    margin: '0 0 0 10',
                    itemId: 'Question3BNo',
                    inputValue: 2,
                    bind: '{isOngoingAssesementForAllChildrenInHome}',
                    name: 'questionB'
                },
                {
                    xtype: 'radio',
                    boxLabel: '<b>NA</b>',
                    margin: '0 0 0 10',
                    itemId: 'Question3BNA',
                    inputValue: 3,
                    bind: '{isOngoingAssesementForAllChildrenInHome}',
                    name: 'questionB'
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem3QuestionB',
                    itemName: 'item3'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 40',
            html: 'If No, explain any concerns in the narrative field below.'
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '10 10 20 40',
            layout: 'hbox',
            itemId: 'item3QuestionBNarrative',
            items: [
                {
                    xtype: 'textarea',
                    itemId: 'ongoingAssessmentExplained',
                    bind: '{ongoingAssessmentForAllChildrenInHomeExplained}',
                    disabled: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem3QuestionBNarrative',
                    itemName: 'item3'
                }
            ]
        }
    ]
});
//
// Question 3C
//
Ext.define('app.CaseReview.view.safety.Question3C', {
    extend: 'Ext.container.Container',
    alias: 'widget.question3C',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    itemId: 'section3C',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 3C Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'safety3CDef'
                }
                //{
                //    html: "<div class='html-content-item-margins'><ul>" +
                //          "<li>'Safety plan' refers to a plan that describes strategies developed by the agency and family to ensure that the child(ren) is (are) safe. Safety plans should address (1) safety threats and how those will be managed and addressed by the caregiver, (2) caregiver capacity to implement the plan and report safety issues to the agency, and (3) family involvement in implementation of the plan. Safety plans may be separate from or integrated into the case plan.</li>" +
                //          "</ul></div>"
                //}
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Questions 3C and 3D Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'safety3CIns'
                }
                //{
                //    html: "<div class='html-content-item-margins'><ul>" +
                //          "<li>Questions C and D are applicable to all in-home services cases and to foster care cases in which there are other children remaining in the family home, and/or the target child in foster care returned home during the period under review.</li>" +
                //          "<li>Questions C and D should be answered Not Applicable if the reviewer determines that during the period under review there were no apparent safety concerns for any child in the family home.</li>" +
                //          "</ul></div>"
                //}
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>C. During the period under review, if safety concerns were present, did the agency: (1) develop an appropriate safety plan with the family and (2) continually monitor and update the safety plan as needed, including monitoring family engagement in any safety-related services?</strong>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '10 20 20 40',
            itemId: 'item3QuestionC',
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'Question3CYes',
                    inputValue: 1,
                    name: 'SafetyPlanDevelopedAndMonitored',
                    bind: '{isSafetyPlanDevelopedAndMonitored}'
                },
                {
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    margin: '0 0 0 10',
                    itemId: 'Question3CNo',
                    inputValue: 2,
                    name: 'SafetyPlanDevelopedAndMonitored',
                    bind: '{isSafetyPlanDevelopedAndMonitored}'
                },
                {
                    xtype: 'radio',
                    boxLabel: '<b>NA</b>',
                    margin: '0 0 0 10',
                    itemId: 'Question3CNA',
                    inputValue: 3,
                    name: 'SafetyPlanDevelopedAndMonitored',
                    bind: '{isSafetyPlanDevelopedAndMonitored}'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 40',
            html: 'If No, explain any concerns in the narrative field below.'
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '10 10 20 40',
            layout: 'hbox',
            itemId: 'item3QuestionCNarrative',
            items: [
                {
                    xtype: 'textarea',
                    itemId: 'safetyPlanExplained',
                    bind: '{safetyPlanDevelopedAndMonitoredExplained}',
                    disabled: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem3QuestionCNarrative',
                    itemName: 'item3'
                }
            ]
        }
    ]
});
//
// Question 3D1
//
Ext.define('app.CaseReview.view.safety.Question3D1', {
    extend: 'Ext.container.Container',
    alias: 'widget.question3D1',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    itemId: 'section3D1',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'vbox',
            itemId: 'item3QuestionD1',
            items: [
                {
                    xtype: 'component',
                    bodyCls: 'panel-background-color',
                    border: false,
                    margin: '15 0 5 20',
                    html: '<strong>D1. Indicate whether any safety-related incidents occurred during the period under review.</strong>'
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem3QuestionD1',
                    orientation: 'wide',
                    itemName: 'item3'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '5 0 0 40',
            html: '<strong>Select all that apply:</strong>'
        },
        {
            xtype: 'container',
            border: false,
            cls: 'panel-background-color',
            margin: '20 20 20 35',
            itemId: 'item3D1',
            plugins: [
                    {
                        ptype: 'businessRulePlugin',
                        pluginId: 'item3D1Plugin',
                        rules: [
                            {
                                rType: 'validityCheck',
                                fields: [
                                    {
                                        eType: 'lookup',
                                        fieldName: 'DispositionCode',
                                        storeId: 'CR_SafetyReport_CollectionStore',
                                        fieldValue: undefined
                                    }
                                ],
                                predicate: 'DispositionCode.fieldValue == 1'
                            },
                            {
                                rType: 'ruleCheck',
                                fields: [
                                    {
                                        eType: 'lookup',
                                        fieldName: 'DispositionCode',
                                        storeId: 'CR_SafetyReport_CollectionStore',
                                        fieldValue: undefined
                                    }
                                ],
                                predicate: 'DispositionCode.fieldValue == 4'
                            }
                        ],
                        action: [
                            {
                                type: 'validityCheck',
                                substantiatedReports: true,
                                noSubstantiatedReports: false
                            },
                            {
                                type: 'ruleCheck',
                                openedForServicesReports: true,
                                noOpenedForServicesReports: false
                            }
                        ]
                    }
            ],
            items: [
            {
                xtype: 'boundcheckboxgroup',
                columns: 1,
                vertical: true,
                store: 'CR_MultiAnswer_CollectionStore',
                inputField: 'CodeDescriptionID',
                itemId: 'safetyRelatedIncidents',
                listeners: {
                    click: {
                        element: 'el',
                        fn: function () {

                            appDataEvent.safety.changeByUserAction = true;
                        }
                    }
                },
                items: [
                    {
                        boxLabel: 'NA (no safety issues were present during the period under review).',
                        itemId: 'incident1',
                        inputValue: 86
                    },
                    {
                        boxLabel: 'No safety-related incidents occurred that were not adequately addressed by the agency.',
                        itemId: 'incident2',
                        inputValue: 87
                    },
                    {
                        boxLabel: 'Recurring maltreatment: There was at least one substantiated or indicated maltreatment report on any child in the family during the period under review AND there was another substantiated report within a 6-month period before or after that report that involved the same or similar circumstances. In determining the similarity of the circumstances, consider the perpetrator of the maltreatment and other individuals involved in the incident.',
                        itemId: 'incident3',
                        inputValue: 88
                    },
                    {
                        boxLabel: 'Recurring safety concerns: There was at least one maltreatment report involving any child in the family during the period under review that was handled by an alternative response and resulted in opening the case for services to address safety concerns (this decision may have been made by the agency or by a private provider under contract with the agency) AND there was at least one additional maltreatment report within a 6-month period before or after that report that was handled by an alternative response and resulted in a decision to open the case for services to address the same or similar safety concerns (the case may have been opened for services by the agency or by a private provider under contract with the agency). In determining the similarity of the concerns, consider the perpetrator of the maltreatment, other individuals involved in the incident, and the type of safety issues that existed.',
                        itemId: 'incident4',
                        inputValue: 89
                    },
                    {
                        boxLabel: 'The case was closed while significant safety concerns that were not adequately addressed still existed in the home.',
                        itemId: 'incident5',
                        inputValue: 90
                    },
                    {
                        boxLabel: 'Other (describe any other safety-related incidents that were not adequately addressed by the agency):',
                        itemId: 'incident6',
                        inputValue: 91
                    }
                ]
            }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '10 10 20 40',
            layout: 'hbox',
            itemId: 'item3QuestionD1Narrative',
            items: [
                {
                    xtype: 'textarea',
                    itemId: 'otherSafetyConcerns',
                    bind: '{otherSafetyConcernExplained}',
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem3QuestionD1Narrative',
                    itemName: 'item3'
                }
            ]
        }
    ]
});
//
// Question 3D
//
Ext.define('app.CaseReview.view.safety.Question3D', {
    extend: 'Ext.container.Container',
    alias: 'widget.question3D',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    itemId: 'section3D',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 3D Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'safety3DIns'
                }
                //{
                //    html: "<div class='html-content-item-margins'><ul>" +
                //          "<li>Answer Yes if any safety-related incidents in D1 are selected.</li>" +
                //          "<li>Answer No if no safety-related incidents occurred that were not adequately addressed by the agency.</li>" +
                //          "<li>Answer NA if no safety issues were present during the period under review.</li>" +
                //          "</ul></div>"
                //}
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>D. During the period under review, were there safety concerns pertaining to the target child in foster care and/or any child(ren) in the family remaining in the home that were not adequately or appropriately addressed by the agency?</strong>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '10 20 20 40',
            itemId: 'item3QuestionD',
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'Question3DYes',
                    inputValue: 1,
                    name: 'SafetyConcernForOtherChildren',
                    bind: '{isSafetyConcernForOtherChildren}'
                },
                {
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    margin: '0 0 0 10',
                    itemId: 'Question3DNo',
                    inputValue: 2,
                    name: 'SafetyConcernForOtherChildren',
                    bind: '{isSafetyConcernForOtherChildren}'
                },
                {
                    xtype: 'radio',
                    boxLabel: '<b>NA</b>',
                    margin: '0 0 0 10',
                    itemId: 'Question3DNA',
                    inputValue: 3,
                    name: 'SafetyConcernForOtherChildren',
                    bind: '{isSafetyConcernForOtherChildren}'
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem3QuestionD',
                    itemName: 'item3'
                }
            ]
        }
    ]
});
//
// Question 3E1
//
Ext.define('app.CaseReview.view.safety.Question3E1', {
    extend: 'Ext.container.Container',
    alias: 'widget.question3E1',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    itemId: 'section3E1',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'vbox',
            itemId: 'item3QuestionE1',
            items: [
                {
                    xtype: 'component',
                    bodyCls: 'panel-background-color',
                    border: false,
                    margin: '15 0 5 20',
                    html: '<strong>E1. For foster care cases only, indicate whether any safety concerns related to visitation were present during the period under review. Select all that apply:</strong>'
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem3QuestionE1',
                    orientation: 'wide',
                    itemName: 'item3'
                }
            ]
        },
        {
            xtype: 'container',
            border: false,
            cls: 'panel-background-color',
            margin: '20 20 20 35',
            items: [
            {
                xtype: 'boundcheckboxgroup',
                columns: 1,
                vertical: true,
                store: 'CR_MultiAnswer_CollectionStore',
                inputField: 'CodeDescriptionID',
                itemId: 'item3E1',
                listeners: {
                    click: {
                        element: 'el',
                        fn: function () {

                            appDataEvent.safety.changeByUserAction = true;
                        }
                    }
                },
                plugins: [
                    {
                        ptype: 'businessRulePlugin',
                        pluginId: 'item3E1Plugin',
                        rules: [
                            {
                                rType: 'validityCheck',
                                fields: [
                                    {
                                        eType: 'lookup',
                                        fieldName: 'ReviewSubTypeID',
                                        storeId: 'CaseReviewStore',
                                        fieldValue: undefined
                                    }
                                ],
                                predicate: 'ReviewSubTypeID.fieldValue == 18 || ReviewSubTypeID.fieldValue == 20'
                            }
                        ],
                        action: [
                            {
                                type: 'validityCheck',
                                fosterCareCase: true,
                                other: false
                            }
                        ]
                    }
                ],
                items: [
                    {
                        boxLabel: 'NA (this is an in-home services case, or the target child did not have any visitation).',
                        itemId: 'safetyConcern1',
                        inputValue: 92
                    },
                    {
                        boxLabel: 'No unmitigated safety concerns related to visitation were present.',
                        itemId: 'safetyConcern2',
                        inputValue: 93
                    },
                    {
                        boxLabel: 'Sufficient monitoring of visitation by parents/caretakers or other family members was not ensured.',
                        itemId: 'safetyConcern3',
                        inputValue: 94
                    },
                    {
                        boxLabel: 'Unsupervised visitation was allowed when it was not appropriate.',
                        itemId: 'safetyConcern4',
                        inputValue: 95
                    },
                    {
                        boxLabel: 'Visitation was court-ordered despite safety concerns that could not be controlled with supervision.',
                        itemId: 'safetyConcern5',
                        inputValue: 96
                    },
                    {
                        boxLabel: 'Other (describe the safety concerns that existed with visitation):',
                        itemId: 'safetyConcern6',
                        inputValue: 97
                    }
                ]
            }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '10 10 20 40',
            layout: 'hbox',
            itemId: 'item3QuestionE1Narrative',
            items: [
                {
                    xtype: 'textarea',
                    itemId: 'fosterSafetyConcerns',
                    bind: '{fosterSafetyOtherExplained}',
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem3QuestionE1Narrative',
                    itemName: 'item3'
                }
            ]
        }
    ]
});
//
// Question 3E
//
Ext.define('app.CaseReview.view.safety.Question3E', {
    extend: 'Ext.container.Container',
    alias: 'widget.question3E',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    itemId: 'section3E',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 3E Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'safety3EIns'
                }
                //{
                //    html: "<div class='html-content-item-margins'><ul>" +
                //          "<li>Select Not Applicable if this is not a foster care case.</li>" +
                //          "<li>Answer Yes if any safety concerns in E1 are selected.</li>" +
                //          "<li>If no safety concerns were identified in E1, answer No.</li>" +
                //          "<li>If the child does not have visits with parents/caretakers or with other family members, select Not Applicable.</li>" +
                //          "</ul></div>"
                //}
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>E. During the period under review, was there a safety concern related to the target child in foster care during visitation with parents/caretakers or other family members?</strong>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '10 20 20 40',
            itemId: 'item3E',
            plugins: [
                    {
                        ptype: 'businessRulePlugin',
                        pluginId: 'item3EPlugin',
                        rules: [
                            {
                                rType: 'validityCheck',
                                fields: [
                                    {
                                        eType: 'lookup',
                                        fieldName: 'ReviewSubTypeID',
                                        storeId: 'CaseReviewStore',
                                        fieldValue: undefined
                                    }
                                ],
                                predicate: 'ReviewSubTypeID.fieldValue == 18 || ReviewSubTypeID.fieldValue == 20'
                            }
                        ],
                        action: [
                            {
                                type: 'validityCheck',
                                fosterCareCase: true,
                                other: false
                            }
                        ]
                    }
            ],
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'Question3EYes',
                    inputValue: 1,
                    name: 'FosterSafetyConcernDuringVisitation',
                    bind: '{isFosterSafetyConcernDuringVisitation}',
                },
                {
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    margin: '0 0 0 10',
                    itemId: 'Question3ENo',
                    inputValue: 2,
                    name: 'FosterSafetyConcernDuringVisitation',
                    bind: '{isFosterSafetyConcernDuringVisitation}'
                },
                {
                    xtype: 'radio',
                    boxLabel: '<b>NA</b>',
                    margin: '0 0 0 10',
                    itemId: 'Question3ENA',
                    inputValue: 3,
                    name: 'FosterSafetyConcernDuringVisitation',
                    bind: '{isFosterSafetyConcernDuringVisitation}'
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem3E',
                    itemName: 'item3'
                }
            ]
        }
    ]
});
//
// Question 3F1
//
Ext.define('app.CaseReview.view.safety.Question3F1', {
    extend: 'Ext.container.Container',
    alias: 'widget.question3F1',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    itemId: 'section3F1',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 3F1 Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'safety3F1Ins'
                }
                //{
                //    html: "<div class='html-content-item-margins'><ul>" +
                //          "<li>Foster parents are defined as related or non-related caregivers who have been given responsibility for care of the child by the agency while the child is under the placement and care responsibility and supervision of the agency. This includes pre-adoptive parents if the adoption has not been finalized.</li>" +
                //          "</ul></div>"
                //}
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'vbox',
            itemId: 'item3QuestionF1',
            items: [
                {
                    xtype: 'component',
                    bodyCls: 'panel-background-color',
                    border: false,
                    margin: '15 0 5 20',
                    html: '<strong>F1. For foster care cases only, indicate whether any concerns existed for the child in at least one foster care placement during the period under review. Select all that apply:</strong>'
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem3QuestionF1',
                    orientation: 'wide',
                    itemName: 'item3'
                }
            ]
        },
        {
            xtype: 'container',
            border: false,
            cls: 'panel-background-color',
            margin: '20 20 20 35',
            items: [
            {
                xtype: 'boundcheckboxgroup',
                columns: 1,
                vertical: true,
                store: 'CR_MultiAnswer_CollectionStore',
                inputField: 'CodeDescriptionID',
                itemId: 'item3F1',
                listeners: {
                    click: {
                        element: 'el',
                        fn: function () {

                            appDataEvent.safety.changeByUserAction = true;
                        }
                    }
                },
                plugins: [
                    {
                        ptype: 'businessRulePlugin',
                        pluginId: 'item3F1Plugin',
                        rules: [
                            {
                                rType: 'validityCheck',
                                fields: [
                                    {
                                        eType: 'lookup',
                                        fieldName: 'ReviewSubTypeID',
                                        storeId: 'CaseReviewStore',
                                        fieldValue: undefined
                                    }
                                ],
                                predicate: 'ReviewSubTypeID.fieldValue == 18 || ReviewSubTypeID.fieldValue == 20'
                            },
                            {
                                rType: 'ruleCheck',
                                fields: [
                                    {
                                        eType: 'lookup',
                                        fieldName: 'DispositionCode',
                                        storeId: 'CR_SafetyReport_CollectionStore',
                                        fieldValue: undefined
                                    }
                                ],
                                predicate: 'DispositionCode.fieldValue == 1'
                            },
                        ],
                        action: [
                            {
                                type: 'validityCheck',
                                fosterCareCase: true,
                                other: false
                            },
                            {
                                type: 'ruleCheck',
                                substantiatedReports: true,
                                noSubstantiatedReports: false
                            }
                        ]
                    }
                ],
                items: [
                    {
                        boxLabel: 'NA (this is an in-home services case).',
                        itemId: 'placementConcern1',
                        inputValue: 98
                    },
                    {
                        boxLabel: 'No safety concerns existed for the target child while in foster care placement that were not adequately addressed.',
                        itemId: 'placementConcern2',
                        inputValue: 99
                    },
                    {
                        boxLabel: 'There was a substantiated allegation of maltreatment of the child by a foster parent (including a relative foster parent) or facility staff member that could have been prevented if the agency had taken appropriate actions.',
                        itemId: 'placementConcern3',
                        inputValue: 100
                    },
                    {
                        boxLabel: 'There was a critical incident report or other major issue relevant to noncompliance by foster parents or facility staff that could potentially make the child unsafe, and the agency could have prevented it or did not provide an adequate response after it occurred.',
                        itemId: 'placementConcern4',
                        inputValue: 101
                    },
                    {
                        boxLabel: 'The child’s placement during the period under review presented other risks to the child that are not being addressed, even though no allegation was made and no critical incident reports were filed.',
                        itemId: 'placementConcern5',
                        inputValue: 102
                    },
                    {
                        boxLabel: 'You discover that there are safety concerns related to the child in the foster home of which the agency is unaware because of inadequate monitoring.',
                        itemId: 'placementConcern6',
                        inputValue: 103
                    },
                    {
                        boxLabel: 'Other (describe any other safety concerns that existed with the child’s foster placement):',
                        itemId: 'placementConcern7',
                        inputValue: 104
                    }
                ]
            }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '10 10 20 40',
            layout: 'hbox',
            itemId: 'item3QuestionF1Narrative',
            items: [
                {
                    xtype: 'textarea',
                    itemId: 'otherPlacementConcerns',
                    bind: '{fosterPlacementConcerOtherExplained}',
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem3QuestionF1Narrative',
                    itemName: 'item3'
                }
            ]
        }
    ]
});
//
// Question 3F
//
Ext.define('app.CaseReview.view.safety.Question3F', {
    extend: 'Ext.container.Container',
    alias: 'widget.question3F',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    itemId: 'section3F',
    border: true,
    trackResetOnLoad: true,
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 3F Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'safety3FIns'
                }
                //{
                //    html: "<div class='html-content-item-margins'><ul>" +
                //          "<li>Answer Not Applicable if this is not a foster care case.</li>" +
                //          "<li>Answer No if no unaddressed concerns were noted in F1.</li>" +
                //          "<li>Answer Yes if you determine that, during the period under review, the child was in at least one foster care placement in which he or she was unsafe, and appropriate action was not taken (such as providing closer monitoring of the placement, placing fewer children in the home, providing services to address potential problems or existing problems, or finding a more appropriate placement). If any concerns are selected in F1, question F should be answered Yes.</li>" +
                //          "</ul></div>"
                //}
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>F. For foster care cases only, during the period under review, was there a concern for the target child’s safety related to the foster parents, members of the foster parents’ family, other children in the foster home or facility, or facility staff members, that was not adequately or appropriately addressed by the agency?</strong>'
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '10 20 20 40',
            itemId: 'item3F',
            plugins: [
                    {
                        ptype: 'businessRulePlugin',
                        pluginId: 'item3FPlugin',
                        rules: [
                            {
                                rType: 'validityCheck',
                                fields: [
                                    {
                                        eType: 'lookup',
                                        fieldName: 'ReviewSubTypeID',
                                        storeId: 'CaseReviewStore',
                                        fieldValue: undefined
                                    }
                                ],
                                predicate: 'ReviewSubTypeID.fieldValue == 18 || ReviewSubTypeID.fieldValue == 20'
                            }
                        ],
                        action: [
                            {
                                type: 'validityCheck',
                                fosterCareCase: true,
                                other: false
                            }
                        ]
                    }
            ],
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'Question3FYes',
                    inputValue: 1,
                    name: 'FosterSafetyConcernNotAddressed',
                    bind: '{isFosterSafetyConcernNotAddressed}'
                },
                {
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    margin: '0 0 0 10',
                    itemId: 'Question3FNo',
                    inputValue: 2,
                    name: 'FosterSafetyConcernNotAddressed',
                    bind: '{isFosterSafetyConcernNotAddressed}'
                },
                {
                    xtype: 'radio',
                    boxLabel: '<b>NA</b>',
                    margin: '0 0 0 10',
                    itemId: 'Question3FNA',
                    inputValue: 3,
                    name: 'FosterSafetyConcernNotAddressed',
                    bind: '{isFosterSafetyConcernNotAddressed}'
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem3F',
                    itemName: 'item3'
                }
            ]
        }
    ]
});