﻿Ext.define('App.CaseReview.view.safety.safetyUI', {
    extend: 'Ext.form.Panel',
    alias: 'widget.safetyUI',
    baseCls: 'x-fieldset fieldset-padding',
    border: false,
    resizable: false,
    itemId: 'safetyTab',
    scrollable: true,
    defaults: {
        focusable: true,
        tabIndex: 2
    },
    items: [
          {
              xtype: 'container',
              region: 'west',
              scrollable: 'vertical',
              width: 200,
              cls: 'panel-background-color',
              items: [
                  {
                      xtype: 'container',
                      layout: 'vbox',
                      border: 'false',
                      cls: 'panel-background-color',
                      defaults: {
                          componentCls: 'left-nav-item'
                      },
                      items: [
                          {
                              xtype: 'hyperlink',
                              html: "<div class='left-nav-header'>Section I: Safety</div>",
                              itemId: 'linkSafety',
                              refItemId: 'section1Safety',
                              refPanel: {
                                  parentPanelId: 'centerTabPanel',
                                  tabPanelId: 'safetyPanel'
                              }
                          },
                          {
                              xtype: 'hyperlink',
                              html: "<div class='left-nav-header'>Outcome 1</div>",
                              itemId: 'linkSafetyOutcome1',
                              refItemId: 'safetyOutcome1',
                              refPanel: {
                                  parentPanelId: 'centerTabPanel',
                                  tabPanelId: 'safetyPanel'
                              }
                          },
                          {
                              xtype: 'hyperlink',
                              html: 'Item 1',
                              refItemId: 'safetyItem1',
                              itemId: 'linkSafetyItem1',
                              refPanel: {
                                  parentPanelId: 'centerTabPanel',
                                  tabPanelId: 'safetyPanel'
                              }
                          },
                          {
                              xtype: 'hyperlink',
                              html: 'Item 1 Rating',
                              itemId: 'linkItem1Rating',
                              refItemId: 'item1Rating',
                              refPanel: {
                                  parentPanelId: 'centerTabPanel',
                                  tabPanelId: 'safetyPanel'
                              }
                          },
                          {
                              xtype: 'hyperlink',
                              html: 'Item 1 Notes',
                              itemId: 'linkSafetyOutcome1Notes',
                              refItemId: 'safetyOutcome1Notes',
                              refPanel: {
                                  parentPanelId: 'centerTabPanel',
                                  tabPanelId: 'safetyPanel'
                              }
                          },
                          {
                              xtype: 'hyperlink',
                              html: "<div class='left-nav-header'>Outcome 2</div>",
                              itemId: 'linkSafetyOutcome2',
                              refItemId: 'safetyOutcome2',
                              refPanel: {
                                  parentPanelId: 'centerTabPanel',
                                  tabPanelId: 'safetyPanel'
                              }
                          },
                          {
                              xtype: 'hyperlink',
                              html: 'Item 2',
                              itemId: 'linkSafetyItem2',
                              refItemId: 'safetyItem2',
                              refPanel: {
                                  parentPanelId: 'centerTabPanel',
                                  tabPanelId: 'safetyPanel'
                              }
                          },
                          {
                              xtype: 'hyperlink',
                              html: 'Item 2 Rating',
                              itemId: 'linkItem2Rating',
                              refItemId: 'item2Rating',
                              refPanel: {
                                  parentPanelId: 'centerTabPanel',
                                  tabPanelId: 'safetyPanel'
                              }
                          },
                          {
                              xtype: 'hyperlink',
                              html: 'Item 2 Notes',
                              itemId: 'linkSafetyOutcome2Notes',
                              refItemId: 'safetyOutcome2Notes',
                              refPanel: {
                                  parentPanelId: 'centerTabPanel',
                                  tabPanelId: 'safetyPanel'
                              }
                          },
                          {
                              xtype: 'hyperlink',
                              html: 'Item 3',
                              itemId: 'linkSafetyItem3',
                              refItemId: 'safetyItem3',
                              refPanel: {
                                  parentPanelId: 'centerTabPanel',
                                  tabPanelId: 'safetyPanel'
                              }
                          },
                          {
                              xtype: 'hyperlink',
                              html: 'Item 3 Rating',
                              itemId: 'linkItem3Rating',
                              refItemId: 'item3Rating',
                              refPanel: {
                                  parentPanelId: 'centerTabPanel',
                                  tabPanelId: 'safetyPanel'
                              }
                          },
                          {
                              xtype: 'hyperlink',
                              html: 'Item 3 Notes',
                              itemId: 'linkSafetyItem3Notes',
                              refItemId: 'safetyItem3Notes',
                              refPanel: {
                                  parentPanelId: 'centerTabPanel',
                                  tabPanelId: 'safetyPanel'
                              }
                          }
                      ]
                  }
              ]
          },
                {
                    xtype: 'panel',
                    region: 'center',
                    scrollable: 'vertical',
                    itemId: 'safetyPanel',
                    viewModel: {
                        type: 'safetyViewModel'
                    },
                    tbar: {
                        xtype: 'headerUI',
                        margin: 0
                    },
                    dockedItems: [
                        {
                            xtype: 'savebuttons'
                        }
                    ],
                    //===========================================================================
                    // Added to solve flickering issue for nested collapsible panels - H Lawrence
                    autoHeight: true,
                    // hideMode: 'offsets',
                    // End of flickering solution
                    //===========================================================================
                    items: [
                                {
                                    xtype: 'component',
                                    margin: '0 20 0 20',
                                    itemId: 'section1Safety',
                                    html: 'Section I: Safety',
                                    cls: 'safety-header',
                                    height: 45,
                                    border: false
                                },
                                //==========================================================================//
                                // Overview Section
                                //==========================================================================//
                                {
                                    xtype: 'container',
                                    margin: '20 20 20 20',
                                    cls: 'panel-background-color',
                                    border: true,
                                    items:
                                    [
                                        {
                                            xtype: 'component',
                                            itemId: 'safetyOverview',
                                            html: 'Outcome 1:',
                                            margin: '20 20 0 20',
                                            cls: 'outcome-header'
                                        },
                                        {
                                            // SECTION A-1
                                            xtype: 'component',
                                            border: false,
                                            margin: '0 0 0 20',
                                            html: 'Children are, first and foremost, protected from abuse and neglect.',
                                            baseCls: 'outcome-header-2'
                                        },
                                        {
                                            // SECTION A-1
                                            xtype: 'component',
                                            itemId: 'overviewItem1',
                                            border: false,
                                            margin: '20 0 0 40',
                                            cls: 'panel-background-color',
                                            html: '<strong>Item 1:</strong> Timeliness of Initiating Investigations of Reports of Child Maltreatment'
                                        },
                                        {
                                            xtype: 'component',
                                            cls: 'panel-background-color outcome-header',
                                            itemId: 'safetyOverview2',
                                            scrollable: true,
                                            html: 'Outcome 2:',
                                            margin: '20 20 0 20'
                                        },
                                        {
                                            // SECTION A-1
                                            xtype: 'component',
                                            border: false,
                                            margin: '0 0 0 20',
                                            html: 'Children are safely maintained in their homes whenever possible and appropriate.',
                                            baseCls: 'outcome-header-2'
                                        },
                                        {
                                            // SECTION A-1
                                            xtype: 'component',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '20 0 0 40',
                                            html: '<strong>Item 2:</strong> Services to Family to Protect Child(ren) in the Home and Prevent Removal or Re-Entry Into Foster Care'
                                        },
                                        {
                                            // SECTION A-1
                                            xtype: 'component',
                                            itemId: 'overviewItem3',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '20 0 0 40',
                                            html: '<strong>Item 3:</strong> Risk and Safety Assessment and Management'
                                        }
                                    ]
                                },
                                //==========================================================================//
                                // Start of Outcome 1 Section
                                //==========================================================================//
                                {
                                    xtype: 'container',
                                    margin: '20 20 20 20',
                                    cls: 'panel-background-color',
                                    itemId: 'safetyItem1Panel',
                                    border: true,
                                    items:
                                    [
                                        {
                                            xtype: 'component',
                                            itemId: 'safetyOutcome1',
                                            html: 'Outcome 1: Children are, first and foremost, protected from abuse and neglect.',
                                            margin: '20 20 20 20',
                                            cls: 'outcome-header'
                                        },
                                        {
                                            xtype: 'component',
                                            itemId: 'item1',
                                            border: false,
                                            margin: '20 0 0 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>Item 1:</strong> Timeliness of Initiating Investigations of Reports of Child Maltreatment'
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 0 20',
                                            cls: 'panel-background-color',
                                            html: 'What is the level of outcome achievement that best describes the extent to which this outcome is being or has been achieved, based on the rating for item 1? '
                                        },
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Instructions: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    html: "<div class='html-content-item-margins'>Safety Outcome 1 should be rated as Substantially Achieved if the following applies: " +
                                                           "<ul><li> Item 1 is rated as a Strength</li></ul>" +
                                                           "Safety Outcome 1 should be rated as Not Achieved if the following applies: " +
                                                           "<ul><li> Item 1 is rated as an Area Needing Improvement.</li></ul>" +
                                                           "Safety Outcome 1 should be rated as Not Applicable if the following applies:  " +
                                                           "<ul><li> Item 1 is rated as Not Applicable.</li></ul></div>"
                                                }
                                            ]

                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 10 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>Level of Outcome Achievement:</strong>'
                                        },
                                        {
                                            xtype: 'itemRating',
                                            itemId: 'safetyOutcome1Rating',
                                            page: 'Safety',
                                            itemType: 'outcome',
                                            outcomeCode: 1
                                        }
                                    ]
                                },
                                {
                                    xtype: 'container',
                                    cls: 'panel-background-color',
                                    margin: '0 20 20 20',
                                    border: true,
                                    itemId: 'safetyItem1',
                                    items:
                                    [
                                        {
                                            xtype: 'component',
                                            html: 'Item 1: Timeliness of Initiating Investigations of Reports of Child Maltreatment',
                                            margin: '20 20 20 20',
                                            cls: 'outcome-item-header'
                                        },
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Purpose of Assessment: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    html: "<div class='html-content-item-margins'><ul><li> To determine whether responses to all accepted child maltreatment reports received during the period under review were initiated, and face-to-face contact with the child(ren) made, within the time frames established by agency policies or state statutes.</li></ul></div>"
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Item 1 Applicable Cases: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    html: "<div class='html-content-item-margins text-justify'>" +
                                                           "<ul><li> Cases are applicable for an assessment of this item if an accepted child maltreatment report on any child in the family was received during the period under review. 'Accepted' means that the report was assigned to the agency to conduct an assessment or investigation. This includes reports assigned for an 'alternative response' assessment. Reports that are screened out are not considered 'accepted.' 'Alternative response' refers to an agency's approach to addressing child maltreatment reports that meet agency criteria for acceptance but at the initial screening do not meet the agency's requirements for a mandated investigation. For example, the agency's policy may be that reports that appear to present low to moderate risk to the child may be referred for a family assessment, rather than an investigation. Under such a response, no determination of child maltreatment is made. The alternative response may include an assessment to determine the safety of the child(ren), the risk of maltreatment, and the family's strengths and needs. The assessment may lead the state agency to provide services to eliminate or lessen the safety concerns and maltreatment risks.</li>" +
                                                           "<li> Cases are Not Applicable for an assessment of this item if, during the period under review, there were no child maltreatment reports on any child in the family, or if a report was received on a child in the family but it was 'screened out'; that is, not referred for an assessment or investigation.</li></ul>" +
                                                           "</div>"
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'itemApplicable',
                                            store: 'CR_Outcome_CollectionStore',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            OutcomeCode: 1,
                                            ItemCode: 2,
                                            items: [
                                                {
                                                    xtype: 'component',
                                                    cls: 'outcome-item-header',
                                                    border: false,
                                                    margin: '15 0 0 20',
                                                    html: '<b>Is this case applicable?</b>'
                                                    //    }
                                                    //]
                                                },
                                        {
                                            xtype: 'component',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '10 20 20 20',
                                            html: 'Select the appropriate response. If the response is No, the case will be rated as Not Applicable in the ratings section for this item.'
                                        },
                                        {
                                            xtype: 'radiogroup',
                                            itemId: 'item1Applicability',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            layout: 'hbox',
                                            margin: '10 20 20 40',
                                            plugins: [
                                                {
                                                    ptype: 'crsValidationPlugin',
                                                    storeId: 'CR_Item_CollectionStore',
                                                    pluginId: 'item1ApplicabilityPlugin',
                                                    validationType: 'Safety',
                                                    validationInput: ['Applicability']
                                                }
                                            ],
                                            items: [
                                                {
                                                    xtype: 'radio',
                                                    boxLabel: '<b>Yes</b>',
                                                    itemId: 'item1Yes',
                                                    inputValue: 1,
                                                    bind: '{item1Applicable}',
                                                    name: 'applicableItem1'
                                                },
                                                {
                                                    margin: '0 0 0 10',
                                                    xtype: 'radio',
                                                    boxLabel: '<b>No:</b>',
                                                    itemId: 'item1No',
                                                    inputValue: 2,
                                                    bind: '{item1Applicable}',
                                                    name: 'applicableItem1'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '15 0 0 20',
                                            html: '<b>Optional</b>: Provide comments in the narrative field below.'
                                        },
                                        {
                                            xtype: 'container',
                                            cls: 'panel-background-color',
                                            itemId: 'item1ApplicableCommentsContainer',
                                            border: false,
                                            margin: '10 10 20 20',
                                            items: [
                                                {
                                                    xtype: 'textarea',
                                                    itemId: 'item1ApplicableComments',
                                                    bind: '{item1Comments}',
                                                    enableKeyEvents: true,
                                                    //height: 100,  This does work with grow: true
                                                    //growMin: 100,
                                                    //growMax: 350,
                                                    //grow: true,
                                                    width: '75%',
                                                    maxlength: 4100,
                                                    enforceMaxLength: true,
                                                    height: 150
                                                }
                                            ]
                                        }]
                                        }

                                    ]
                                },
                                //***********************************************************
                                // Reports Table and Questions 1A - 1C
                                //***********************************************************  
                                {
                                    //RESULTS GRID
                                    xtype: 'gridpanel',
                                    itemId: 'safetyReportGrid',
                                    store: 'CR_SafetyReport_CollectionStore',
                                    border: true,
                                    margin: '20 20 20 20',
                                    title: "<strong>A1.&nbsp&nbspReports Table</strong>",
                                    tools: [
                                   {
                                       xtype: 'button',
                                       text: 'Add',
                                       itemId: 'safetyReportGridAddButton',
                                       icon: addButtonImage
                                   },
                                    {
                                        xtype: 'button',
                                        itemId: 'safetyReportGridEditButton',
                                        text: 'Edit',
                                        icon: editButtonImage
                                    },
                                    {
                                        xtype: 'button',
                                        itemId: 'safetyReportGridDeleteButton',
                                        text: 'Delete',
                                        icon: deleteButtonImage,
                                        plugins: [
                                            {
                                                ptype: 'crsValidationPlugin',
                                                storeId: 'CR_SafetyReport_CollectionStore',
                                                pluginId: 'deleteButtonPlugin',
                                                validationType: 'Safety',
                                                validationInput: ['ValidateItem1'],
                                                itemCode: 2,
                                                columns: [
                                                                'ReportDate', 'ChildDemographicID', 'SafetyReportAllegationCode',
                                                                'PriorityLevel', 'AssessmentCode',
                                                                'DateAssessmentAssigned', 'DateAssessmentInitiated',
                                                                'DateFaceToFaceContact', 'PerpetratorChildRelationshipCode',
                                                                'DispositionCode'
                                                ]
                                            }
                                        ]
                                    }
                                    ],
                                    plugins: [
                                        Ext.create('framework.grid.plugin.RowEditing',
                                        {
                                            pluginId: 'programEditorPlugin',
                                            clicksToEdit: 2,
                                            errorSummary: false
                                        }),
                                        {
                                            ptype: 'businessRulePlugin',
                                            pluginId: 'safetyReport',
                                            rules: [
                                                {
                                                    rType: 'ruleCheck',
                                                    fields: [
                                                        {
                                                            eType: 'function',
                                                            fieldName: 'NoItems',
                                                            functionName: 'count',
                                                            storeId: 'CR_SafetyReport_CollectionStore',
                                                            fieldValue: undefined,
                                                            columns: [
                                                                'ReportDate', 'ChildDemographicID',
                                                                'PriorityLevel', 'AssessmentCode',
                                                                'DateAssessmentAssigned', 'DateAssessmentInitiated',
                                                                'DateFaceToFaceContact', 'PerpetratorChildRelationshipCode',
                                                                'DispositionCode'
                                                            ]
                                                        }
                                                    ],
                                                    predicate: 'NoItems.fieldValue > 0'
                                                }
                                            ],
                                            action: [
                                                {
                                                    type: 'ruleCheck',
                                                    enable: true,
                                                    disable: false
                                                }
                                            ]
                                        }
                                    ],
                                    columns: [
                                        {
                                            xtype: 'datecolumn',
                                            text: 'Report<br>Date',
                                            dataIndex: 'ReportDate',
                                            format: 'm/d/Y',
                                            width: '8%',
                                            align: 'center',
                                            cellWrap: true
                                        },
                                        {
                                            text: 'Name of<br>Child',
                                            dataIndex: 'ChildDemographicID',
                                            width: '10%',
                                            align: 'center',
                                            renderer: function (value) {
                                                var lookupStore = chainedStore('CR_ChildDemographic_CollectionStore');
                                                var results = lookupStore.query('ChildDemographicID', value, false, false, true);
                                                if (results.length > 0) {
                                                    return results.getAt(0).data.Name;
                                                }
                                                return '';
                                            },
                                            cellWrap: true
                                        },
                                        {
                                            text: 'Allegation',
                                            width: '12%',
                                            renderer: function (value, p, record) {
                                                var allegationValue = "";
                                                if (!Ext.isEmpty(record)) {
                                                    if (!Ext.isEmpty(record.data["CR_SafetyReport_Allegation_Collection"])) {
                                                        Ext.Array.forEach(record.data["CR_SafetyReport_Allegation_Collection"], function (crSafetyAllegationRecord) {
                                                            var lookupStore = chainedStore('CaseReasonStore');
                                                            var results = lookupStore.query('GroupID', crSafetyAllegationRecord.SafetyReportAllegationCode, false, false, true);
                                                            if (results.length > 0) {
                                                                allegationValue = allegationValue + results.getAt(0).data.DescriptionLarge + " ,\n";
                                                            }

                                                        }
                                                        );
                                                    }
                                                }

                                                allegationValue = allegationValue.substring(0, allegationValue.lastIndexOf(','));
                                                return allegationValue;
                                            },
                                            cellWrap: true
                                        },
                                        {
                                            text: "Priority<br>Level<br>(if applicable)",
                                            dataIndex: 'PriorityLevel',
                                            width: '10%',
                                            cellWrap: true,
                                            align: 'center',
                                            renderer: function (value) {
                                                var lookupStore = chainedStore('PriorityLevelStore');
                                                var results = lookupStore.query('GroupID', value, false, false, true);
                                                if (results.length > 0) {
                                                    return results.getAt(0).data.DescriptionLarge;
                                                }
                                                return '';
                                            }
                                        },
                                        {
                                            text: 'Assessment <br>or  <br>Investigation',
                                            dataIndex: 'AssessmentCode',
                                            width: '10%',
                                            align: 'center',
                                            renderer: function (value) {
                                                var lookupStore = chainedStore('AssessmentTypeStore');
                                                var results = lookupStore.query('GroupID', value, false, false, true);
                                                if (results.length > 0) {
                                                    return results.getAt(0).data.DescriptionLarge;
                                                }
                                                return '';
                                            },
                                            cellWrap: true
                                        },
                                        {
                                            xtype: 'datecolumn',
                                            text: 'Date Assigned  <br>for an <br>Investigation  <br>or <br>Assessment',
                                            dataIndex: 'DateAssessmentAssigned',
                                            format: 'm/d/Y',
                                            width: '10%',
                                            align: 'center',
                                            renderer: function (value, p, record) {
                                                if (record.data.IsAssigned == 1)
                                                    return "Did not occur";
                                                return Ext.util.Format.date(value, 'm/d/Y');
                                            },
                                            cellWrap: true
                                        },
                                        {
                                            xtype: 'datecolumn',
                                            text: "Date Investigation  <br>or  <br>Assessment Initiated",
                                            dataIndex: 'DateAssessmentInitiated',
                                            width: '10%',
                                            align: 'center',
                                            format: 'm/d/Y',
                                            renderer: function (value, p, record) {
                                                if (record.data.IsInitiated == 1)
                                                    return "Did not occur";
                                                return Ext.util.Format.date(value, 'm/d/Y');
                                            },
                                            cellWrap: true
                                        },
                                        {
                                            xtype: 'datecolumn',
                                            text: 'Date Face-to-Face <br>Contact With Child',
                                            width: '10%',
                                            align: 'center',
                                            dataIndex: 'DateFaceToFaceContact',
                                            format: 'm/d/Y',
                                            renderer: function (value, p, record) {
                                                if (record.data.IsFaceToFaceContact == 1)
                                                    return "Did not occur";
                                                return Ext.util.Format.date(value, 'm/d/Y');
                                            },
                                            cellWrap: true
                                        },
                                        {
                                            text: 'Relationship of <br>Alleged Perpetrator <br>to Child',
                                            dataIndex: 'PerpetratorChildRelationshipCode',
                                            width: '10%',
                                            align: 'center',
                                            renderer: function (value, p, record) {
                                                var lookupStore = chainedStore('PerpetratorChildRelationshipStore');
                                                var results = lookupStore.query('GroupID', value, false, false, true);
                                                if (results.length > 0) {
                                                    if (results.getAt(0).data.DescriptionLarge == "Other") {

                                                        return results.getAt(0).data.DescriptionLarge + " - " + record.data.PerpetratorChildRelationshipOther;
                                                    }

                                                    return results.getAt(0).data.DescriptionLarge;

                                                }
                                                return '';
                                            },
                                            cellWrap: true
                                        },
                                        {
                                            text: 'Disposition Code',
                                            dataIndex: 'DispositionCode',
                                            width: '10%',
                                            align: 'center',
                                            renderer: function (value) {
                                                var lookupStore = chainedStore('DispositionStore');
                                                var results = lookupStore.query('GroupID', value, false, false, true);
                                                if (results.length > 0) {
                                                    return results.getAt(0).data.DescriptionLarge;
                                                }
                                                return '';
                                            },
                                            cellWrap: true
                                        }
                                    ]
                                    //viewConfig: {
                                    //    listeners: {
                                    //        refresh: function (dataview) {
                                    //            Ext.each(dataview.panel.columns, function (column) {
                                    //                column.autoSize();
                                    //            });
                                    //        }
                                    //    }
                                    //}
                                },
                                {
                                    xtype: 'item1Questions'
                                },
                                //***********************************************************
                                // Item 1 Rating
                                //***********************************************************
                                {
                                    xtype: 'container',
                                    cls: 'panel-background-color',
                                    margin: '0 20 20 20',
                                    itemId: 'item1Rating',
                                    border: true,
                                    items:
                                    [
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Item 1 Rating Criteria: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'safety1RatingCriteria'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 10 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>Item Rating:</strong>'
                                        },
                                        {
                                            xtype: 'container',
                                            border: false,
                                            margin: '10 10 20 0',
                                            layout: 'hbox',
                                            itemId: 'item1RatingContainer',
                                            items: [
                                                {
                                                    xtype: 'itemRating',
                                                    itemId: 'safetyItem1Rating',
                                                    itemCode: 2,
                                                    page: 'Safety',
                                                    itemName: 'item1',
                                                    itemType: 'item',
                                                    outcomeCode: 1,
                                                    msgComponentId: 'msgItem1Rating',
                                                    ratingContainerId: 'item1RatingContainer'
                                                },
                                                {
                                                    xtype: 'validationMessage',
                                                    itemId: 'msgItem1Rating',
                                                    itemName: 'item1'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '20 0 0 20',
                                            html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below: '
                                        },
                                        {
                                            xtype: 'container',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '10 10 20 20',
                                            items: [
                                                {
                                                    xtype: 'textarea',
                                                    width: 500,
                                                    maxLength: 10000,
                                                    enforceMaxLength: true,
                                                    enableKeyEvents: true,
                                                    itemId: 'item1RatingComment',
                                                    bind: '{item1RatingComments}',
                                                    //height: 100,  This does work with grow: true
                                                    //growMin: 100,
                                                    //growMax: 350,
                                                    //grow: true,
                                                    width: '75%',
                                                    height: 150
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'ratingOverride',
                                            border: false,
                                            margin: '20 0 10 20',
                                            page: 'safety',
                                            itemNo: '2',
                                            itemCode: 2,
                                            outcomeCode: 1,
                                            itemId: 'safetyItem1RatingOverride',
                                            ratingComponentId: 'safetyItem1Rating',
                                            outcomeRatingComponentId: 'safetyOutcome1Rating'
                                        }
                                    ]
                                },
                                {
                                    xtype: 'qaNotes',
                                    itemId: 'safetyOutcome1Notes',
                                    notesTitle: 'Safety - Outcome 1 - QA Notes',
                                    itemCode: 2,
                                    outcomeCode: 1
                                },
                                //==========================================================================//
                                // End of Outcome 1 Section
                                //==========================================================================//
                                //==========================================================================//
                                // Start of Outcome 2 Section
                                //==========================================================================//
                                {
                                    xtype: 'container',
                                    //cls: 'cb',
                                    cls: 'panel-background-color',
                                    margin: '0 20 20 20',
                                    scrollable: true,
                                    items:
                                     [
                                         {
                                             xtype: 'component',
                                             cls: 'panel-background-color outcome-header',
                                             itemId: 'safetyOutcome2',
                                             scrollable: true,
                                             html: 'Outcome 2: Children are safely maintained in their homes whenever possible and appropriate.',
                                             margin: '20 20 20 20'
                                         },
                                         {
                                             xtype: 'component',
                                             cls: 'panel-background-color',
                                             border: false,
                                             margin: '20 0 0 20',
                                             html: '<strong>Item 2:</strong> Services to Family to Protect Child(ren) in the Home and Prevent Removal or Re-Entry Into Foster Care'
                                         },
                                         {
                                             xtype: 'component',
                                             itemId: 'safetyItem3Overview',
                                             cls: 'panel-background-color',
                                             border: false,
                                             margin: '20 0 0 20',
                                             html: '<strong>Item 3:</strong> Risk and Safety Assessment and Management'
                                         },
                                         {
                                             xtype: 'component',
                                             cls: 'panel-background-color',
                                             border: false,
                                             margin: '20 0 0 20',
                                             html: 'What is the level of outcome achievement that best describes the extent to which this outcome is being or has been achieved, based on the ratings for items 2 and 3?  '
                                         },
                                         {
                                             xtype: 'listPanel',
                                             bodyCls: 'panel-background-color',
                                             title: "<div class='html-content-header-margins'>Instructions: [SHOW]</div>",
                                             margin: '20 20 20 20',
                                             padding: '0 0 0 0',
                                             items: [
                                                 {
                                                     html: "<div class='html-content-item-margins'>Safety Outcome 2 should be rated as Substantially Achieved if either of the following applies: " +
                                                            "<ul><li> Items 2 and 3 are rated as Strengths. " +
                                                            "<li>Item 2 is rated as Not Applicable and Item 3 is rated as a Strength.</ul>" +
                                                            "Safety Outcome 2 should be rated as Partially Achieved if the following applies:" +
                                                            "<ul><li> One of the two items is rated as a Strength and the other as an Area Needing Improvement.</ul>" +
                                                            " Safety Outcome 2 should be rated as Not Achieved if either of the following applies: " +
                                                            "<ul><li>Items 2 and 3 are rated as Areas Needing Improvement." +
                                                            "<li>Item 2 is rated as Not Applicable and Item 3 is rated as an Area Needing Improvement.</ul></div>"
                                                 }
                                             ]
                                         },
                                         {
                                             xtype: 'component',
                                             border: false,
                                             margin: '20 0 10 20',
                                             cls: 'panel-background-color',
                                             html: '<strong>Level of Outcome Achievement:</strong>'
                                         },
                                         {
                                             xtype: 'itemRating',
                                             itemId: 'safetyOutcome2Rating',
                                             page: 'Safety',
                                             itemType: 'outcome',
                                             outcomeCode: 2
                                         }
                                     ]
                                },
                                {
                                    xtype: 'item2Preapp'
                                },
                                //==========================================================================//
                                // Question 2A
                                //==========================================================================//
                                {
                                    xtype: 'question2A'
                                },
                                //==========================================================================//
                                // Question 2B
                                //==========================================================================//
                                {
                                    xtype: 'question2B'
                                },
                                //***********************************************************
                                // Item 2 Rating
                                //***********************************************************
                                {
                                    xtype: 'container',
                                    cls: 'panel-background-color',
                                    margin: '0 20 20 20',
                                    itemId: 'item2Rating',
                                    border: true,
                                    items:
                                    [
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Item 2 Rating Criteria: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'safety2RatingCriteria'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 10 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>Item Rating:</strong>'
                                        },
                                        {
                                            xtype: 'container',
                                            border: false,
                                            margin: '10 10 20 0',
                                            layout: 'hbox',
                                            itemId: 'item2RatingContainer',
                                            items: [
                                                {
                                                    xtype: 'itemRating',
                                                    itemId: 'safetyItem2Rating',
                                                    itemCode: 3,
                                                    page: 'Safety',
                                                    itemName: 'item2',
                                                    itemType: 'item',
                                                    outcomeCode: 2,
                                                    msgComponentId: 'msgItem2Rating',
                                                    ratingContainerId: 'item2RatingContainer'
                                                },
                                                {
                                                    xtype: 'validationMessage',
                                                    itemId: 'msgItem2Rating',
                                                    itemName: 'item2'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '20 0 0 20',
                                            html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below: '
                                        },
                                        {
                                            xtype: 'container',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '10 10 20 20',
                                            items: [
                                                {
                                                    xtype: 'textarea',
                                                    maxLength: 10000,
                                                    enforceMaxLength: true,
                                                    enableKeyEvents: true,
                                                    itemId: 'item2RatingComment',
                                                    bind: '{item2RatingComments}',
                                                    //height: 100,  This does work with grow: true
                                                    //growMin: 100,
                                                    //growMax: 350,
                                                    //grow: true,
                                                    width: '75%',
                                                    height: 150
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'ratingOverride',
                                            border: false,
                                            margin: '20 0 10 20',
                                            page: 'safety',
                                            itemNo: '2',
                                            itemCode: 3,
                                            outcomeCode: 2,
                                            itemId: 'safetyItem2RatingOverride',
                                            ratingComponentId: 'safetyItem2Rating',
                                            outcomeRatingComponentId: 'safetyOutcome2Rating'
                                        }
                                    ]
                                },
                                {
                                    xtype: 'qaNotes',
                                    itemId: 'safetyOutcome2Notes',
                                    notesTitle: 'Safety - Item 2 - QA Notes',
                                    itemCode: 3,
                                    outcomeCode: 2
                                },
                                //==========================================================================//
                                // End of Outcome 2 Section
                                //==========================================================================//
                                //==========================================================================//
                                // Start of Outcome 3 Section
                                //==========================================================================//      
                                //***********************************************************
                                // Item 3 Overview
                                //***********************************************************
                                {
                                    xtype: 'container',
                                    //cls: 'cb',
                                    cls: 'panel-background-color',
                                    margin: '0 20 20 20',
                                    itemId: 'safetyItem3',
                                    border: true,
                                    items:
                                    [
                                        {
                                            xtype: 'component',
                                            html: 'Item 3:	Risk and Safety Assessment and Management',
                                            margin: '20 20 20 20',
                                            cls: 'outcome-item-header'
                                        },
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Purpose of Assessment: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    html: "<div class='html-content-item-margins'><ul><li>To determine whether, during the period under review, the agency made concerted efforts to assess and address the risk and safety concerns relating to the child(ren) in their own homes or while in foster care.</ul></div>"
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            html: 'Item 3 Applicable Cases:',
                                            margin: '20 20 20 20',
                                            cls: 'outcome-item-header'
                                        },
                                        {
                                            xtype: 'component',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '15 0 0 20',
                                            html: '<ul> <li>All cases are applicable for an assessment of this item.</ul>'
                                        }
                                    ]
                                },
                                //***********************************************************
                                // Section 3A1
                                //***********************************************************
                                {
                                    xtype: 'question3A1'
                                },
                                //***********************************************************
                                // Section 3A
                                //***********************************************************
                                {
                                    xtype: 'question3A'
                                },
                                //***********************************************************
                                // Section 3B
                                //***********************************************************
                                {
                                    xtype: 'question3B'
                                },
                                //***********************************************************
                                // Section 3C
                                //***********************************************************
                                {
                                    xtype: 'question3C'
                                },
                                //***********************************************************
                                // Section 3D1
                                //***********************************************************
                                {
                                    xtype: 'question3D1'
                                },
                                //***********************************************************
                                // Section 3D
                                //***********************************************************
                                {
                                    xtype: 'question3D'
                                },
                                //***********************************************************
                                // Section 3E1
                                //***********************************************************
                                {
                                    xtype: 'question3E1'
                                },
                                //***********************************************************
                                // Section 3E
                                //***********************************************************
                                {
                                    xtype: 'question3E'
                                },
                                //***********************************************************
                                // Section 3F1
                                //***********************************************************
                                {
                                    xtype: 'question3F1'
                                },
                                //***********************************************************
                                // Section 3F
                                //***********************************************************
                                {
                                    xtype: 'question3F'
                                },
                                //***********************************************************
                                // Item 3 Rating
                                //***********************************************************
                                {
                                    xtype: 'container',
                                    cls: 'panel-background-color',
                                    margin: '0 20 20 20',
                                    itemId: 'item3Rating',
                                    border: true,
                                    items:
                                    [
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Item 3 Rating Criteria: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'safety3RatingCriteria'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 10 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>Item Rating:</strong>'
                                        },
                                        {
                                            xtype: 'container',
                                            border: false,
                                            margin: '10 10 20 0',
                                            layout: 'hbox',
                                            itemId: 'item3RatingContainer',
                                            items: [
                                                {
                                                    xtype: 'itemRating',
                                                    itemId: 'safetyItem3Rating',
                                                    itemCode: 4,
                                                    page: 'safety',
                                                    itemName: 'item3',
                                                    itemType: 'item',
                                                    outcomeCode: 2,
                                                    msgComponentId: 'msgItem3Rating',
                                                    ratingContainerId: 'item3RatingContainer'
                                                },
                                                {
                                                    xtype: 'validationMessage',
                                                    itemId: 'msgItem3Rating',
                                                    itemName: 'item3'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '20 0 0 20',
                                            html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below: '
                                        },
                                        {
                                            xtype: 'container',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '10 10 20 20',
                                            items: [
                                                {
                                                    xtype: 'textarea',
                                                    maxLength: 10000,
                                                    enforceMaxLength: true,
                                                    enableKeyEvents: true,
                                                    itemId: 'item3RatingComment',
                                                    bind: '{item3RatingComments}',
                                                    //height: 100,  This does work with grow: true
                                                    //growMin: 100,
                                                    //growMax: 350,
                                                    //grow: true,
                                                    width: '75%',
                                                    enforceMaxLength: true,
                                                    height: 150
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'ratingOverride',
                                            border: false,
                                            margin: '20 0 10 20',
                                            page: 'safety',
                                            itemNo: '3',
                                            itemCode: 4,
                                            outcomeCode: 2,
                                            itemId: 'safetyItem3RatingOverride',
                                            ratingComponentId: 'safetyItem3Rating',
                                            outcomeRatingComponentId: 'safetyOutcome2Rating'
                                        }
                                    ]
                                },
                                //***********************************************************
                                // Item 3 QA Notes
                                //***********************************************************
                                {
                                    xtype: 'qaNotes',
                                    itemId: 'safetyItem3Notes',
                                    notesTitle: 'Item 3 QA Notes',
                                    itemCode: 4,
                                    outcomeCode: 2
                                    //reviewNotes: [
                                    //    {
                                    //        xtype: 'reviewNote',
                                    //        border: false,
                                    //        createDate: new Date(),
                                    //        createBy: 'Larry',
                                    //        subject: 'Item 3 Note-1',
                                    //        text: 'This is text for testing the note component',
                                    //        responseItems:
                                    //        {
                                    //            xtype: 'listPanel',
                                    //            border: 'true',
                                    //            baseCls: 'x-panel panel-background-list-note',
                                    //            title: "<div class='html-content-header-margins'>Responses [HIDE]</div>",
                                    //            margin: '20 20 20 10',
                                    //            padding: '0 0 0 0',
                                    //            collapsed: false,
                                    //            items: [
                                    //                {
                                    //                    xtype: 'noteResponse',
                                    //                    createDate: new Date(),
                                    //                    createBy: 'Suzanne',
                                    //                    response: 'Test response 1'
                                    //                },
                                    //                {
                                    //                    xtype: 'noteResponse',
                                    //                    createDate: new Date(),
                                    //                    createBy: 'Gregory',
                                    //                    response: 'Test response 2'
                                    //                },
                                    //                {
                                    //                    xtype: 'noteResponse',
                                    //                    createDate: new Date(),
                                    //                    createBy: 'Valter Borges(Reviewer)',
                                    //                    response: 'Test response 3'
                                    //                }
                                    //            ]
                                    //        }
                                    //    },
                                    //    {
                                    //        xtype: 'reviewNote',
                                    //        border: false,
                                    //        createDate: new Date(),
                                    //        createBy: 'Sandra Cunningham',
                                    //        subject: 'Item 3 Note-2',
                                    //        text: 'This is another text for testing the note component',
                                    //        responseItems:
                                    //        {
                                    //            xtype: 'listPanel',
                                    //            border: 'true',
                                    //            baseCls: 'x-panel panel-background-list-note',
                                    //            title: "<div class='html-content-header-margins'>Responses [HIDE]</div>",
                                    //            margin: '20 20 20 10',
                                    //            padding: '0 0 0 0',
                                    //            collapsed: false,
                                    //            items: [
                                    //                {
                                    //                    xtype: 'noteResponse',
                                    //                    createDate: new Date(),
                                    //                    createBy: 'Ritesh',
                                    //                    response: 'Test response 1'
                                    //                },
                                    //                {
                                    //                    xtype: 'noteResponse',
                                    //                    createDate: new Date(),
                                    //                    createBy: 'Claudiu Dobre',
                                    //                    response: 'Test response 2'
                                    //                },
                                    //                {
                                    //                    xtype: 'noteResponse',
                                    //                    createDate: new Date(),
                                    //                    createBy: 'Horace Lawrence(Reviewer)',
                                    //                    response: 'Test response 3'
                                    //                }
                                    //            ]
                                    //        }
                                    //    }
                                    //]
                                }
                                //==========================================================================//
                                // End of Outcome 3 Section
                                //==========================================================================//
                    ]
                }
    ]
});