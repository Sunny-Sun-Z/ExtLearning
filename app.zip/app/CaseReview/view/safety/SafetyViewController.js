﻿Ext.define('App.CaseReview.view.safety.SafetyViewController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.safetyViewController',
    constructor: function () {
        
        var self = this;
        self.callParent();
                
    },
    init: function (config) {

        'use strict';

        var self = this;

        self.control(
        {
            '#safetyPanel': {
                'beforerender': function () {
                    
                    //Ext.suspendLayouts();
                }
            }
        });
    }
});