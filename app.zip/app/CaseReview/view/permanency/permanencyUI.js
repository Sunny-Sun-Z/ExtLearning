﻿Ext.define('App.CaseReview.view.permanency.permanencyUI', {
    extend: 'Ext.form.Panel', // should be Ext.form.Panel
    alias: 'widget.permanencyUI',
    baseCls: 'x-fieldset fieldset-padding',
    border: false,
    resizable: false,
    itemId: 'permanencyTab',
    defaults: {
        stateful: true,
        focusable: true,
        tabIndex: 3
    },
    initComponent: function () {
        var me = this;
        var sr = App.Common.StringResources;
        // these values keep us from having to type everything out
        // every time we want to put icons on the screen and makes it
        // easy to change their values in one place

        Ext.applyIf(me, {
            items: [
                {
                    xtype: 'container',
                    itemId: 'leftPermNavigation',
                    region: 'west',
                    scrollable: 'vertical',
                    width: 200,
                    cls: 'panel-background-color',
                    items: [
                        {
                            xtype: 'container',
                            layout: 'vbox',
                            border: 'false',
                            cls: 'panel-background-color',
                            defaults: {
                                componentCls: 'left-nav-item',
                                xtype: 'hyperlink',
                                refPanel: {
                                    parentPanelId: 'centerTabPanel',
                                    tabPanelId: 'permanencyPanel'
                                }
                            },
                            items: [
                                {
                                    html: "<div class='left-nav-header'>Outcome 1</div>",
                                    refItemId: 'permanencyOutcome1'
                                },
                                {
                                    html: 'Item 4',
                                    refItemId: 'item4',
                                    itemId: 'linkItem4',
                                },
                                {
                                    html: 'Item 4 Rating',
                                    refItemId: 'item4Rating'
                                },
                                {
                                    html: 'Item 4 Notes',
                                    refItemId: 'permanencyItem4Notes'
                                },
                                {
                                    html: 'Item 5',
                                    itemId: 'linkItem5',
                                    refItemId: 'item5'
                                },
                                {
                                    html: 'Item 5 Rating',
                                    refItemId: 'item5Rating'
                                },
                                {
                                    html: 'Item 5 Notes',
                                    refItemId: 'permanencyItem5Notes'
                                },
                                {
                                    html: 'Item 6',
                                    itemId: 'linkItem6',
                                    refItemId: 'item6'
                                },
                                {
                                    html: 'Item 6 Rating',
                                    refItemId: 'item6Rating'
                                },
                                {
                                    html: 'Item 6 Notes',
                                    refItemId: 'permanencyItem6Notes'
                                },
                                {
                                    html: "<div class='left-nav-header'>Outcome 2</div>",
                                    refItemId: 'permanencyOutcome2'
                                },
                                {
                                    html: 'Item 7',
                                    itemId: 'linkItem7',
                                    refItemId: 'item7'
                                },
                                {
                                    html: 'Item 7 Rating',
                                    refItemId: 'item7Rating'
                                },
                                {
                                    html: 'Item 7 Notes',
                                    refItemId: 'permanencyItem7Notes'
                                },
                                {
                                    html: 'Item 8',
                                    itemId: 'linkItem8',
                                    refItemId: 'item8'
                                },
                                {
                                    html: 'Item 8 Rating',
                                    refItemId: 'item8Rating'
                                },
                                {
                                    html: 'Item 8 Notes',
                                    refItemId: 'permanencyItem8Notes'
                                },
                                {
                                    html: 'Item 9',
                                    itemId: 'linkItem9',
                                    refItemId: 'item9'
                                },
                                {
                                    html: 'Item 9 Rating',
                                    refItemId: 'item9Rating'
                                },
                                {
                                    html: 'Item 9 Notes',
                                    refItemId: 'permanencyItem9Notes'
                                },
                                {
                                    html: 'Item 10',
                                    itemId: 'linkItem10',
                                    refItemId: 'item10'
                                },
                                {
                                    html: 'Item 10 Rating',
                                    refItemId: 'item10Rating'
                                },
                                {
                                    html: 'Item 10 Notes',
                                    refItemId: 'permanencyItem10Notes'
                                },
                                {
                                    html: 'Item 11',
                                    itemId: 'linkItem11',
                                    refItemId: 'item11Panel'
                                },
                                {
                                    html: 'Item 11 Rating',
                                    refItemId: 'item11Rating'
                                },
                                {
                                    html: 'Item 11 Notes',
                                    refItemId: 'permanencyItem11Notes'
                                }
                            ]
                        }
                    ]
                },
                {
                    xtype: 'panel',
                    itemId: 'permanencyPanel',
                    region: 'center',
                    scrollable: 'vertical',
                    viewModel: {
                        type: 'permanencyViewModel'
                    },
                    tbar: {
                        xtype: 'headerUI',
                        margin: 0
                    },
                    dockedItems: [
                        {
                            xtype: 'savebuttons'
                        }
                    ],
                    //===========================================================================
                    // Added to solve flickering issue for nested collapsible panels - H Lawrence
                    autoHeight: true,
                    hideMode: 'offsets',
                    // End of flickering solution
                    //===========================================================================                    
                    items: [
                                {
                                    xtype: 'component',
                                    margin: '0 20 0 20',
                                    html: 'Permanency',
                                    cls: 'safety-header',
                                    height: 45,
                                    border: false
                                },
                                //==========================================================================//
                                // Start of Outcome 1 Section
                                //==========================================================================//
                                //**************************************************************************//
                                // Outcome 1 Overview
                                //**************************************************************************//
                                {
                                    xtype: 'container',
                                    margin: '20 20 20 20',
                                    cls: 'panel-background-color',
                                    border: true,
                                    items:
                                    [
                                        {
                                            xtype: 'component',
                                            itemId: 'permanencyOutcome1',
                                            html: 'Outcome 1: Children have permanency and stability in their living situations.',
                                            margin: '20 20 20 20',
                                            cls: 'outcome-header'
                                        },
                                        {
                                            // SECTION A-1
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 0 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>Item 4:</strong> Stability of Foster Care Placement'
                                        },
                                        {
                                            // SECTION A-1
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 0 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>Item 5:</strong> Permanency Goal for Child'
                                        },
                                        {
                                            // SECTION A-1
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 10 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>Item 6:</strong> Achieving Reunification, Guardianship, Adoption, or Other Planned Permanent Living Arrangement'
                                        }
                                    ]
                                },
                                //***********************************************************************//
                                // Outcome 1 Instructions and Achievement Level
                                //***********************************************************************//
                                {
                                    xtype: 'container',
                                    margin: '20 20 20 20',
                                    cls: 'panel-background-color',
                                    border: true,
                                    items:
                                    [
                                        {
                                            // SECTION A-1
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 0 20',
                                            cls: 'panel-background-color',
                                            html: 'What is the level of outcome achievement that best describes the extent to which this outcome is being or has been achieved, based on the ratings for items 4, 5, and 6? '
                                        },
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Instructions: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanencyOutcome1Ins'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 10 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>Level of Outcome Achievement:</strong>'
                                        },
                                        {
                                            xtype: 'itemRating',
                                            itemId: 'permanencyOutcome1Rating',
                                            page: 'Permanency',
                                            itemType: 'outcome',
                                            outcomeCode: 3
                                        }
                                    ]
                                },
                                //****************************************************
                                // Outcome 1 - Item 4
                                //****************************************************
                                {
                                    xtype: 'item4'
                                },
                                //****************************************************
                                // Outcome 1 - Item 5
                                //****************************************************
                                {
                                    xtype: 'container',
                                    //cls: 'cb',
                                    margin: '20 20 20 20',
                                    cls: 'panel-background-color',
                                    border: true,
                                    itemId: 'item5Panel',
                                    defaults: {
                                        trackResetOnLoad: true
                                    },
                                    items:
                                    [
                                        {
                                            xtype: 'component',
                                            itemId: 'item5',
                                            border: false,
                                            margin: '20 0 0 20',
                                            html: '<strong>Item 5:</strong> Permanency Goal for Child',
                                            cls: 'outcome-item-header'
                                        },
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Purpose of Assessment: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanency5Purpose'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 0 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>Item 5 Applicable Cases:</strong>'
                                        },
                                        {
                                            xtype: 'component',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '0 0 0 20',
                                            html: '<ul> <li>All foster care cases are applicable for assessment of this item, unless the child has not been in foster care long enough (at least 60 days) for the agency to have developed a case plan and established a permanency goal. If the child has been in foster care for less than 60 days, but a permanency goal has been established, the case is applicable for assessment.</li></ul>'
                                        },
                                        {
                                            xtype: 'itemApplicable',
                                            store: 'CR_Outcome_CollectionStore',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            OutcomeCode: 3,
                                            ItemCode: 6,
                                            items: [
                                                {
                                                    xtype: 'component',
                                                    border: false,
                                                    margin: '10 0 0 20',
                                                    cls: 'outcome-item-header',
                                                    html: '<strong>Is this case applicable?</strong>'
                                                },
                                                {
                                                    xtype: 'component',
                                                    border: false,
                                                    margin: '10 0 0 20',
                                                    cls: 'panel-background-color',
                                                    html: 'Select the appropriate response. If the response is No, the case will be rated as Not Applicable in the ratings section for this item.'
                                                },
                                                {
                                                    xtype: 'radiogroup',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout: 'hbox',
                                                    margin: '0 0 20 40',
                                                    itemId: 'item5Applicability',
                                                    items: [
                                                        {
                                                            xtype: 'radio',
                                                            boxLabel: '<b>Yes</b>',
                                                            itemId: 'item5Yes',
                                                            inputValue: 1,
                                                            bind: '{item5Applicable}',
                                                            name: 'applicableItem5'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>No</b>',
                                                            itemId: 'item5No',
                                                            inputValue: 2,
                                                            bind: '{item5Applicable}',
                                                            name: 'applicableItem5'
                                                        },
                                                        {
                                                            xtype: 'validationMessage',
                                                            itemId: 'msgItem5Applicability',
                                                            itemName: 'item5'
                                                        }
                                                    ]

                                                },
                                                {
                                                    xtype: 'component',
                                                    cls: 'panel-background-color',
                                                    border: false,
                                                    margin: '15 0 0 20',
                                                    html: '<b>Optional</b>: Provide comments in the narrative field below.'
                                                },
                                                {
                                                    xtype: 'container',
                                                    cls: 'panel-background-color',
                                                    border: false,
                                                    layout: 'hbox',
                                                    margin: '10 10 20 20',
                                                    items: [
                                                        {
                                                            xtype: 'textarea',
                                                            itemId: 'item5ApplicableComments',
                                                            bind: '{item5Comments}',
                                                            width: '75%',
                                                            enableKeyEvents: true,
                                                            //height: 100,  This does work with grow: true
                                                            //growMin: 100,
                                                            //growMax: 350,
                                                            //grow: true,
                                                            maxlength: 4100,
                                                            enforceMaxLength: true,
                                                            height: 150
                                                        }
                                                    ]
                                                }
                                            ]
                                        },
                                        //****************************************************
                                        // Outcome 1 - Question 5A1 & 5A2
                                        //****************************************************
                                        {
                                            xtype: 'container',
                                            cls: 'panel-background-color',
                                            border: true,
                                            itemId: 'permanencyGoalPanel',
                                            items:
                                            [
                                                {
                                                    xtype: 'validationMessage',
                                                    itemId: 'msgPermanencyGoalPanel',
                                                    itemName: 'item5',
                                                    orientation: 'wide'
                                                },
                                                {
                                                    xtype: 'gridpanel',
                                                    itemId: 'goalGrid',
                                                    store: 'CR_Goal_CollectionStore',
                                                    border: true,
                                                    margin: '20 20 20 20',
                                                    title: "<b>A1.</b> Permanency Goal Table",
                                                    tools: [
                                                    {
                                                        xtype: 'button',
                                                        text: 'Add',
                                                        itemId: 'goalGridAddButton',
                                                        icon: addButtonImage
                                                    },
                                                    {
                                                        xtype: 'button',
                                                        itemId: 'goalGridEditButton',
                                                        text: 'Edit',
                                                        icon: editButtonImage
                                                    },
                                                    {
                                                        xtype: 'button',
                                                        itemId: 'goalGridDeleteButton',
                                                        text: 'Delete',
                                                        icon: deleteButtonImage
                                                    }
                                                    ],
                                                    plugins: [
                                                        Ext.create('framework.grid.plugin.RowEditing',
                                                        {
                                                            pluginId: 'programEditorPlugin',
                                                            clicksToEdit: 2,
                                                            errorSummary: false
                                                        }),
                                                        {
                                                            ptype: 'businessRulePlugin',
                                                            pluginId: 'permanencyGoalTable',
                                                            rules: [
                                                                {
                                                                    rType: 'ruleCheck',
                                                                    fields: [
                                                                        {
                                                                            eType: 'function',
                                                                            fieldName: 'NoItems',
                                                                            functionName: 'count',
                                                                            storeId: 'CR_Goal_CollectionStore',
                                                                            fieldValue: undefined,
                                                                            columns: [
                                                                                'GoalCode', 'DateEstablished',
                                                                                'TimeInFosterCare', 'DateGoalChanged',
                                                                                'ReasonForGoalChange'
                                                                            ]
                                                                        }
                                                                    ],
                                                                    predicate: 'NoItems.fieldValue > 0'
                                                                }
                                                            ],
                                                            action: [
                                                                {
                                                                    type: 'ruleCheck',
                                                                    enable: true,
                                                                    disable: false
                                                                }
                                                            ]
                                                        }
                                                    ],
                                                    columns: [

                                                        {
                                                            text: 'Permanency <br>Goal',
                                                            dataIndex: 'GoalCode',
                                                            cellWrap: true,
                                                            renderer: function (value) {

                                                                if (Ext.isEmpty(value)) {

                                                                    return '';
                                                                }

                                                                var goals = chainedStore('CR_Goal_CollectionStore');

                                                                if (goals.data.length == 0) {

                                                                    return '';
                                                                }

                                                                var lookupStore = chainedStore('PermanencyGoal1Store');

                                                                var getResults = function (value) {

                                                                    return lookupStore.query('GroupID', value, false, false, true);
                                                                };

                                                                var item6A4ComboBox = getAppController().getItem6A4CBGroup();

                                                                var goalStore = Ext.data.ChainedStore.create({
                                                                    source: 'CR_Goal_CollectionStore',
                                                                    filters: [
                                                                        function (record) {
                                                                            return record.data.GoalCode == value;
                                                                        }
                                                                    ]
                                                                });

                                                                var results = getResults(value);
                                                                var goal1Code = goals.data.items[0].data.GoalCode;
                                                                var goal2Code;

                                                                if (goals.data.length > 1) {

                                                                    goal2Code = goals.data.items[1].data.GoalCode;
                                                                }

                                                                if (goal1Code == value) {

                                                                    var goal1Component = getAppController().getPermanencyGoal1Selection();
                                                                    goal1Component.setValue(value);
                                                                }

                                                                if (goal2Code == value) {

                                                                    var goal2Component = getAppController().getPermanencyGoal2Selection();
                                                                    goal2Component.setValue(value);
                                                                }

                                                                // Update Item 6A4
                                                                Ext.each(item6A4ComboBox.items.items, function (item) {

                                                                    item.setValue(false);
                                                                });

                                                                Ext.each(goals.data.items, function (goal) {

                                                                    var codeLookupResult = getResults(goal.data.GoalCode);

                                                                    Ext.each(item6A4ComboBox.items.items, function (item) {

                                                                        if (codeLookupResult.length > 0) {
                                                                            if (item.boxLabel == codeLookupResult.getAt(0).data.DescriptionLarge) {

                                                                                item.setValue(true);
                                                                            }
                                                                        }
                                                                    });
                                                                });

                                                                if (results.length > 0) {

                                                                    return results.getAt(0).data.DescriptionLarge;
                                                                }

                                                                return '';
                                                            }
                                                        },
                                                        {
                                                            text: 'Date Established',
                                                            dataIndex: 'DateEstablished',

                                                            //width: '10%',
                                                            renderer: Ext.util.Format.dateRenderer('m/d/Y')
                                                        },
                                                        {
                                                            text: 'Time in Foster <br> Care Before <br> Goal Established',
                                                            dataIndex: 'TimeInFosterCare',

                                                            renderer: function (value, p, r) {

                                                                var timeUnitCode = "";
                                                                if (!Ext.isEmpty(r.data["TimeUnitCode"])) {
                                                                    var lookupStore = chainedStore('TimeUnitStore');
                                                                    var results = lookupStore.query('GroupID', r.data["TimeUnitCode"], false, false, true);
                                                                    if (results.length > 0) {
                                                                        timeUnitCode = results.getAt(0).data.DescriptionLarge;
                                                                    }
                                                                }

                                                                return r.data["TimeInFosterCare"] + " " + timeUnitCode;
                                                            }
                                                        },
                                                        {
                                                            text: 'Date Goal <br>Changed',
                                                            dataIndex: 'DateGoalChanged',
                                                            //width: '10%',
                                                            format: 'm/d/Y',
                                                            renderer: function (value, p, record) {
                                                                if (record.data.IsCurrentGoal == 1)
                                                                    return "NA. This is/was the current goal.";
                                                                return Ext.util.Format.date(value, 'm/d/Y');
                                                            }
                                                        },
                                                        {
                                                            text: 'Reason for <br> Goal Change',
                                                            dataIndex: 'ReasonForGoalChange',
                                                            cellWrap: true
                                                        }
                                                    ],
                                                    viewConfig: {
                                                        listeners: {
                                                            refresh: function (dataview) {
                                                                Ext.each(dataview.panel.columns, function (column) {
                                                                    column.autoSize();
                                                                });
                                                            }
                                                        }
                                                    }
                                                },
                                                {
                                                    xtype: 'component',
                                                    border: false,
                                                    margin: '20 0 0 20',
                                                    cls: 'panel-background-color',
                                                    html: "<b>A2.</b> What is (are) the child's current permanency goal(s)? (If concurrent permanency goals have been established in the case plan, identify both goals.) Or, if the case was closed during the period under review, what was the permanency goal before the case was closed?"
                                                },
                                                {
                                                    xtype: 'container',
                                                    border: false,
                                                    margin: '20 0 0 20',
                                                    cls: 'panel-background-color',
                                                    items: [
                                                        {
                                                            xtype: 'combobox',
                                                            itemId: 'permanencyGoal1Selection',
                                                            fieldLabel: 'Permanency Goal 1:',
                                                            labelAlign: 'left',
                                                            labelWidth: 150,
                                                            allowBlank: false,
                                                            editable: false,
                                                            store: chainedStore('PermanencyGoal1Store'),
                                                            queryMode: 'local',
                                                            displayField: 'DescriptionMedium',
                                                            valueField: 'GroupID',
                                                            autoSelect: true,
                                                            forceSelection: true,
                                                            //name: 'CR_Permanency_Collection.Goal1Code',
                                                            bind: '{goal1Code}',
                                                            width: 450
                                                            //bind: {
                                                            //    value: '{goal1Code}',
                                                            //    store: '{goal1Store}'
                                                            //}
                                                        }
                                                    ]
                                                },
                                                {
                                                    xtype: 'container',
                                                    border: false,
                                                    margin: '20 0 0 20',
                                                    cls: 'panel-background-color',
                                                    items: [
                                                        {
                                                            xtype: 'combobox',
                                                            itemId: 'permanencyGoal2Selection',
                                                            fieldLabel: 'Permanency Goal 2:',
                                                            labelAlign: 'left',
                                                            labelWidth: 150,
                                                            store: chainedStore('PermanencyGoal2Store'),
                                                            //name: 'CR_Permanency_Collection.Goal2Code',
                                                            bind: '{goal2Code}',
                                                            queryMode: 'local',
                                                            editable: false,
                                                            displayField: 'DescriptionMedium',
                                                            valueField: 'GroupID',
                                                            autoSelect: true,
                                                            forceSelection: true,
                                                            width: 450
                                                            //bind: {
                                                            //    value: '{goal2Code}',
                                                            //    store: '{goal2Store}'
                                                            //}
                                                        }
                                                    ]
                                                },
                                                //****************************************************
                                                // Outcome 1 - Question 5A3
                                                //****************************************************
                                                {
                                                    xtype: 'listPanel',
                                                    title: "<div class='html-content-header-margins'>Question 5A3 Instructions: [SHOW]</div>",
                                                    margin: '20 20 20 20',
                                                    padding: '0 0 0 0',
                                                    items: [
                                                        {
                                                            contenEl: 'permanency5A3Ins'
                                                        }
                                                    ]

                                                },
                                                {
                                                    xtype: 'component',
                                                    border: false,
                                                    margin: '20 0 0 20',
                                                    cls: 'panel-background-color',
                                                    html: "<b>A3.</b> Is (are) the child's permanency goal(s) specified in the case file?"
                                                },
                                                {
                                                    xtype: 'radiogroup',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout: 'hbox',
                                                    margin: '0 0 20 40',
                                                    itemId: 'item5A3',
                                                    items: [
                                                        {
                                                            xtype: 'radio',
                                                            boxLabel: '<b>Yes</b>',
                                                            itemId: 'item5A3Yes',
                                                            inputValue: 1,
                                                            name: 'GoalSpecified',
                                                            bind: '{isGoalSpecified}'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>No</b>',
                                                            itemId: 'item5A3No',
                                                            inputValue: 2,
                                                            name: 'GoalSpecified',
                                                            bind: '{isGoalSpecified}'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>NA</b>',
                                                            itemId: 'item5A3NA',
                                                            inputValue: 3,
                                                            name: 'GoalSpecified',
                                                            bind: '{isGoalSpecified}'
                                                        },
                                                        {
                                                            xtype: 'validationMessage',
                                                            itemId: 'msgItem5A3',
                                                            itemName: 'item5'
                                                        }
                                                    ]

                                                },
                                                //****************************************************
                                                // Outcome 1 - Question 5B
                                                //****************************************************
                                                {
                                                    xtype: 'listPanel',
                                                    title: "<div class='html-content-header-margins'>Question 5B Instructions: [SHOW]</div>",
                                                    margin: '20 20 20 20',
                                                    padding: '0 0 0 0',
                                                    items: [
                                                        {
                                                            contentEl: 'permanency5BIns'
                                                        }
                                                    ]
                                                },
                                                {
                                                    xtype: 'component',
                                                    border: false,
                                                    margin: '20 0 0 20',
                                                    cls: 'panel-background-color',
                                                    html: "<b>B.</b> Were all the permanency goals that were in effect during the period under review established in a timely manner?"
                                                },
                                                {
                                                    xtype: 'radiogroup',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout: 'hbox',
                                                    margin: '0 0 20 40',
                                                    itemId: 'item5B',
                                                    items: [
                                                        {
                                                            xtype: 'radio',
                                                            boxLabel: '<b>Yes</b>',
                                                            itemId: 'item5BYes',
                                                            inputValue: 1,
                                                            name: 'AllGoalsInTimelyManner',
                                                            bind: '{wereAllGoalsInTimelyManner}'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>No</b>',
                                                            itemId: 'item5BNo',
                                                            inputValue: 2,
                                                            name: 'AllGoalsInTimelyManner',
                                                            bind: '{wereAllGoalsInTimelyManner}'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>NA</b>',
                                                            itemId: 'item5BNA',
                                                            inputValue: 3,
                                                            name: 'AllGoalsInTimelyManner',
                                                            bind: '{wereAllGoalsInTimelyManner}'
                                                        },
                                                        {
                                                            xtype: 'validationMessage',
                                                            itemId: 'msgItem5B',
                                                            itemName: 'item5'
                                                        }
                                                    ]

                                                },
                                                {
                                                    xtype: 'component',
                                                    cls: 'panel-background-color',
                                                    border: false,
                                                    margin: '15 0 0 20',
                                                    html: 'If No, explain any concerns in the narrative field below.'
                                                },
                                                {
                                                    xtype: 'container',
                                                    cls: 'panel-background-color',
                                                    border: false,
                                                    layout: 'hbox',
                                                    margin: '10 10 20 20',
                                                    itemId: 'item5BGoalsExplanation',
                                                    items: [
                                                        {
                                                            xtype: 'textarea',
                                                            itemId: 'allGoalsInTimelyMannerExplained',
                                                            width: '75%',
                                                            bind: '{allGoalsInTimelyMannerExplained}',
                                                            maxLength: 4100,
                                                            enableKeyEvents: true,
                                                            enforceMaxLength: true,
                                                            //height: 100,  This does work with grow: true 
                                                            grow: true,
                                                            growMin: 100,
                                                            growMax: 350
                                                        },
                                                        {
                                                            xtype: 'validationMessage',
                                                            itemId: 'msgItem5BGoalsExplanation',
                                                            itemName: 'item5'
                                                        }
                                                    ]
                                                },
                                                //****************************************************
                                                // Outcome 1 - Question 5C
                                                //****************************************************
                                                {
                                                    xtype: 'listPanel',
                                                    title: "<div class='html-content-header-margins'>Question 5C Instructions: [SHOW]</div>",
                                                    margin: '20 20 20 20',
                                                    padding: '0 0 0 0',
                                                    items: [
                                                        {
                                                            contentEl: 'permanency5CIns'
                                                        }
                                                    ]
                                                },
                                                {
                                                    xtype: 'component',
                                                    border: false,
                                                    margin: '20 0 0 20',
                                                    cls: 'panel-background-color',
                                                    html: "<b>C.</b> Were all permanency goals in effect during the period under review appropriate to the child's needs for permanency and to the circumstances of the case?"
                                                },
                                                {
                                                    xtype: 'radiogroup',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout: 'hbox',
                                                    margin: '0 0 20 40',
                                                    itemId: 'item5CGoalsAppropriate',
                                                    items: [
                                                        {
                                                            xtype: 'radio',
                                                            boxLabel: '<b>Yes</b>',
                                                            itemId: 'item5CYes',
                                                            inputValue: 1,
                                                            name: 'AllGoalsAppropriate',
                                                            bind: '{wereAllGoalsAppropriate}'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>No</b>',
                                                            itemId: 'item5CNo',
                                                            inputValue: 2,
                                                            name: 'AllGoalsAppropriate',
                                                            bind: '{wereAllGoalsAppropriate}'
                                                        },
                                                        {
                                                            xtype: 'validationMessage',
                                                            itemId: 'msgItem5CGoalsAppropriate',
                                                            orientation: 'wide',
                                                            itemName: 'item5'
                                                        }
                                                    ]

                                                },
                                                {
                                                    xtype: 'component',
                                                    cls: 'panel-background-color',
                                                    border: false,
                                                    margin: '15 0 0 20',
                                                    html: 'If No, explain any concerns in the narrative field below.'
                                                },
                                                {
                                                    xtype: 'container',
                                                    cls: 'panel-background-color',
                                                    border: false,
                                                    //layout: 'hbox',
                                                    margin: '10 10 20 20',
                                                    items: [
                                                        {
                                                            xtype: 'textarea',
                                                            width: '75%',
                                                            itemId: 'allGoalsAppropriateExplained',
                                                            bind: '{allGoalsAppropriateExplained}',
                                                            maxLength: 4100,
                                                            enableKeyEvents: true,
                                                            enforceMaxLength: true,
                                                            //height: 100,  This does work with grow: true 
                                                            grow: true,
                                                            growMin: 100,
                                                            growMax: 350
                                                        }
                                                    ]
                                                },
                                                //****************************************************
                                                // Outcome 1 - Question 5D
                                                //****************************************************
                                                {
                                                    xtype: 'listPanel',
                                                    title: "<div class='html-content-header-margins'>Question 5D Instructions: [SHOW]</div>",
                                                    margin: '20 20 20 20',
                                                    padding: '0 0 0 0',
                                                    items: [
                                                        {
                                                            contentEl: 'permanency5DIns'
                                                        }
                                                    ]
                                                },
                                                {
                                                    xtype: 'component',
                                                    border: false,
                                                    margin: '20 0 0 20',
                                                    cls: 'panel-background-color',
                                                    html: "<b>D.</b> Has the child been in foster care for at least 15 of the most recent 22 months?"
                                                },
                                                {
                                                    xtype: 'radiogroup',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout: 'hbox',
                                                    margin: '0 0 20 40',
                                                    itemId: 'item5D',
                                                    items: [
                                                        {
                                                            xtype: 'radio',
                                                            boxLabel: '<b>Yes</b>',
                                                            itemId: 'item5DYes',
                                                            inputValue: 1,
                                                            name: 'InFoster15OutOf22',
                                                            bind: '{isInFoster15OutOf22}'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>No</b>',
                                                            itemId: 'item5DNo',
                                                            inputValue: 2,
                                                            name: 'InFoster15OutOf22',
                                                            bind: '{isInFoster15OutOf22}'
                                                        }
                                                    ]

                                                },
                                                //****************************************************
                                                // Outcome 1 - Question 5E
                                                //****************************************************
                                                {
                                                    xtype: 'listPanel',
                                                    title: "<div class='html-content-header-margins'>Question 5E Definitions: [SHOW]</div>",
                                                    margin: '20 20 20 20',
                                                    padding: '0 0 0 0',
                                                    items: [
                                                        {
                                                            contentEl: 'permanency5EDef'
                                                        }
                                                    ]
                                                },
                                                {
                                                    xtype: 'listPanel',
                                                    title: "<div class='html-content-header-margins'>Question 5E Instructions: [SHOW]</div>",
                                                    margin: '20 20 20 20',
                                                    padding: '0 0 0 0',
                                                    items: [
                                                        {
                                                            contentEl: 'permanency5EIns'
                                                        }
                                                    ]
                                                },
                                                {
                                                    xtype: 'component',
                                                    border: false,
                                                    margin: '20 0 0 20',
                                                    cls: 'panel-background-color',
                                                    html: "<b>E.</b> Does the child meet other Adoption and Safe Families Act criteria for termination of parental rights?"
                                                },
                                                {
                                                    xtype: 'radiogroup',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout: 'hbox',
                                                    margin: '0 0 20 40',
                                                    itemId: 'item5EParentalRights',
                                                    items: [
                                                        {
                                                            xtype: 'radio',
                                                            boxLabel: '<b>Yes</b>',
                                                            itemId: 'item5EYes',
                                                            inputValue: 1,
                                                            name: 'TerminationOfParentalRights',
                                                            bind: '{meetsTerminationOfParentalRights}'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>No</b>',
                                                            itemId: 'item5ENo',
                                                            inputValue: 2,
                                                            name: 'TerminationOfParentalRights',
                                                            bind: '{meetsTerminationOfParentalRights}'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>NA</b>',
                                                            itemId: 'item5ENA',
                                                            inputValue: 3,
                                                            name: 'TerminationOfParentalRights',
                                                            bind: '{meetsTerminationOfParentalRights}'
                                                        },
                                                        {
                                                            xtype: 'validationMessage',
                                                            itemId: 'msgItem5EParentalRights',
                                                            itemName: 'item5'
                                                        }
                                                    ]
                                                },
                                                //****************************************************
                                                // Outcome 1 - Question 5F
                                                //****************************************************
                                                {
                                                    xtype: 'listPanel',
                                                    title: "<div class='html-content-header-margins'>Question 5F Instructions: [SHOW]</div>",
                                                    margin: '20 20 20 20',
                                                    padding: '0 0 0 0',
                                                    items: [
                                                        {
                                                            contentEl: 'permanency5FIns'
                                                        }
                                                    ]
                                                },
                                                {
                                                    xtype: 'listPanel',
                                                    title: "<div class='html-content-header-margins'>Question 5F Tip: [SHOW]</div>",
                                                    margin: '20 20 20 20',
                                                    padding: '0 0 0 0',
                                                    items: [
                                                        {
                                                            contentEl: 'permanency5FTip'
                                                        }
                                                    ]
                                                },
                                                {
                                                    xtype: 'component',
                                                    border: false,
                                                    margin: '20 0 0 20',
                                                    cls: 'panel-background-color',
                                                    html: "<b>F.</b> Did the agency file or join a termination of parental rights petition before the period under review or in a timely manner during the period under review?"
                                                },
                                                {
                                                    xtype: 'radiogroup',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout: 'hbox',
                                                    margin: '0 0 20 40',
                                                    itemId: 'item5F',
                                                    items: [
                                                        {
                                                            xtype: 'radio',
                                                            boxLabel: '<b>Yes</b>',
                                                            itemId: 'item5FYes',
                                                            inputValue: 1,
                                                            name: 'AgencyJointTerminationOfParentalRights',
                                                            bind: '{isAgencyJointTerminationOfParentalRights}'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>No</b>',
                                                            itemId: 'item5FNo',
                                                            inputValue: 2,
                                                            name: 'AgencyJointTerminationOfParentalRights',
                                                            bind: '{isAgencyJointTerminationOfParentalRights}'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>NA</b>',
                                                            itemId: 'item5FNA',
                                                            inputValue: 3,
                                                            name: 'AgencyJointTerminationOfParentalRights',
                                                            bind: '{isAgencyJointTerminationOfParentalRights}'
                                                        },
                                                        {
                                                            xtype: 'validationMessage',
                                                            itemId: 'msgItem5F',
                                                            itemName: 'item5'
                                                        }
                                                    ]
                                                },
                                                //****************************************************
                                                // Outcome 1 - Question 5G1
                                                //****************************************************
                                                {
                                                    xtype: 'listPanel',
                                                    title: "<div class='html-content-header-margins'>Question 5G1 Instructions: [SHOW]</div>",
                                                    margin: '20 20 20 20',
                                                    padding: '0 0 0 0',
                                                    items: [
                                                        {
                                                            contentEl: 'permanency5G1Ins'
                                                        }
                                                    ]
                                                },
                                                {
                                                    xtype: 'container',
                                                    cls: 'panel-background-color',
                                                    border: true,
                                                    layout: 'vbox',
                                                    itemId: 'item5G1Question',
                                                    items: [
                                                        {
                                                            xtype: 'component',
                                                            border: false,
                                                            margin: '20 0 5 20',
                                                            bodyCls: 'panel-background-color',
                                                            html: "<b>G1.</b> Indicate whether any of the following exceptions to the termination of parental rights requirement apply."
                                                        },
                                                        {
                                                            xtype: 'validationMessage',
                                                            itemId: 'msgItem5G1Question',
                                                            itemName: 'item5'
                                                        },
                                                    ]
                                                },
                                                {
                                                    xtype: 'boundcheckboxgroup',
                                                    columns: 1,
                                                    vertical: true,
                                                    store: 'CR_MultiAnswer_CollectionStore',
                                                    inputField: 'CodeDescriptionID',
                                                    itemId: 'item5G1Group',
                                                    items: [
                                                        {
                                                            margin: '0 0 0 10',
                                                            boxLabel: 'NA',
                                                            itemId: 'termEx1',
                                                            inputValue: 138
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            boxLabel: "No exceptions apply.",
                                                            itemId: 'termEx2',
                                                            inputValue: 139
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            boxLabel: "(1) At the option of the state, the child is being cared for by a relative at the 15/22-month time frame.",
                                                            itemId: 'termEx3',
                                                            inputValue: 140
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            boxLabel: "(2) The agency documented in the case plan a compelling reason for determining that termination of parental rights would not be in the best interests of the child.",
                                                            itemId: 'termEx4',
                                                            inputValue: 141
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            boxLabel: "(3) The state has not provided to the family the services that the state deemed necessary for the safe return of the child to the child's home.",
                                                            itemId: 'termEx5',
                                                            inputValue: 142
                                                        }
                                                    ]
                                                },
                                                //****************************************************
                                                // Outcome 1 - Question 5G
                                                //****************************************************
                                                {
                                                    xtype: 'listPanel',
                                                    title: "<div class='html-content-header-margins'>Question 5G Instructions: [SHOW]</div>",
                                                    margin: '20 20 20 20',
                                                    padding: '0 0 0 0',
                                                    items: [
                                                        {
                                                            contentEl: 'permanency5GIns'
                                                        }
                                                    ]
                                                },
                                                {
                                                    xtype: 'component',
                                                    border: false,
                                                    margin: '20 0 0 20',
                                                    cls: 'panel-background-color',
                                                    html: "<b>G.</b> Did an exception to the requirement to file or join a termination of parental rights petition exist?"
                                                },
                                                {
                                                    xtype: 'radiogroup',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout: 'hbox',
                                                    margin: '0 0 20 40',
                                                    itemId: 'item5GQuestion',
                                                    items: [
                                                        {
                                                            xtype: 'radio',
                                                            boxLabel: '<b>Yes</b>',
                                                            itemId: 'question5GYes',
                                                            inputValue: 1,
                                                            name: 'ExceptionForTermination',
                                                            bind: '{isExceptionForTermination}'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>No</b>',
                                                            itemId: 'question5GNo',
                                                            inputValue: 2,
                                                            name: 'ExceptionForTermination',
                                                            bind: '{isExceptionForTermination}'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>NA</b>',
                                                            itemId: 'question5GNA',
                                                            inputValue: 3,
                                                            name: 'ExceptionForTermination',
                                                            bind: '{isExceptionForTermination}'
                                                        },
                                                        {
                                                            xtype: 'validationMessage',
                                                            itemId: 'msgItem5GQuestion',
                                                            itemName: 'item5'
                                                        }
                                                    ]
                                                },
                                                //***********************************************************
                                                // Item 5 Rating
                                                //***********************************************************
                                                {
                                                    xtype: 'container',
                                                    cls: 'panel-background-color',
                                                    margin: '0 0 20 0',
                                                    itemId: 'item5Rating',
                                                    border: true,
                                                    items:
                                                    [
                                                        {
                                                            xtype: 'listPanel',
                                                            title: "<div class='html-content-header-margins'>Item 5 Rating Criteria: [SHOW]</div>",
                                                            margin: '20 20 20 20',
                                                            padding: '0 0 0 0',
                                                            items: [
                                                                {
                                                                    contentEl: 'permanency5RatingCriteria'
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            border: false,
                                                            margin: '20 0 10 20',
                                                            cls: 'panel-background-color',
                                                            html: '<strong>Item Rating:</strong>'
                                                        },
                                                        {
                                                            xtype: 'container',
                                                            border: false,
                                                            margin: '10 10 20 0',
                                                            layout: 'hbox',
                                                            itemId: 'item5RatingContainer',
                                                            items: [
                                                                {
                                                                    xtype: 'itemRating',
                                                                    itemId: 'permanencyItem5Rating',
                                                                    itemCode: 6,
                                                                    page: 'Permanency',
                                                                    itemName: 'item5',
                                                                    outcomeCode: 3,
                                                                    msgComponentId: 'msgItem5Rating',
                                                                    ratingContainerId: 'item5RatingContainer'
                                                                },
                                                                {
                                                                    xtype: 'validationMessage',
                                                                    itemId: 'msgItem5Rating',
                                                                    itemName: 'item5'
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            xtype: 'component',
                                                            cls: 'panel-background-color',
                                                            border: false,
                                                            margin: '20 0 0 20',
                                                            html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below: '
                                                        },
                                                        {
                                                            xtype: 'container',
                                                            cls: 'panel-background-color',
                                                            border: false,
                                                            margin: '10 10 20 20',
                                                            items: [
                                                                {
                                                                    xtype: 'textarea',
                                                                    width: '75%',
                                                                    maxLength: 10000,
                                                                    enforceMaxLength: true,
                                                                    enableKeyEvents: true,
                                                                    itemId: 'item5RatingComment',
                                                                    bind: '{item5RatingComments}',
                                                                    grow: true,
                                                                    growMin: 100,
                                                                    growMax: 350
                                                                    //listeners: {
                                                                    //    render: {
                                                                    //        fn: function (component, eOpts) {

                                                                    //            var resizer = Ext.create('App.CaseReview.view.common.CustomResizer', {
                                                                    //                target: this.el,
                                                                    //                originalTarget: this.el,
                                                                    //                handles: 'all',
                                                                    //                minWidth: 500,
                                                                    //                maxWidth: viewportWidth * 0.7,
                                                                    //                minHeight: 100,
                                                                    //                maxHeight: 300,
                                                                    //                pinned: true
                                                                    //            });
                                                                    //        }
                                                                    //    }
                                                                    //}
                                                                }
                                                            ]
                                                        },
                                                        {
                                                            xtype: 'ratingOverride',
                                                            border: false,
                                                            margin: '20 0 10 20',
                                                            page: 'permanency',
                                                            itemNo: '5',
                                                            itemCode: 6,
                                                            outcomeCode: 3,
                                                            itemId: 'permanencyItem5RatingOverride',
                                                            ratingComponentId: 'permanencyItem5Rating',
                                                            outcomeRatingComponentId: 'permanencyOutcome1Rating'
                                                        }
                                                    ]
                                                },
                                                //****************************************************
                                                // Outcome 1 - Item 5 QA Notes
                                                //****************************************************
                                                {
                                                    xtype: 'qaNotes',
                                                    itemId: 'permanencyItem5Notes',
                                                    notesTitle: 'Item 5 - QA Notes',
                                                    margin: '0 20 0 0',
                                                    itemCode: 6,
                                                    outcomeCode: 3
                                                }
                                            ]
                                        }
                                    ]
                                },
                                //****************************************************
                                // Outcome 1 - Item 6
                                //****************************************************
                                //****************************************************
                                // Outcome 1 - Question 6 Overview
                                //****************************************************
                                {
                                    xtype: 'container',
                                    //cls: 'cb',
                                    margin: '20 20 20 20',
                                    cls: 'panel-background-color',
                                    border: true,
                                    itemId: 'item6Panel',
                                    defaults: {
                                        trackResetOnLoad: true
                                    },
                                    items:
                                    [
                                        {
                                            xtype: 'component',
                                            itemId: 'item6',
                                            border: false,
                                            margin: '20 0 0 20',
                                            html: '<strong>Item 6:</strong> Achieving Reunification, Guardianship, Adoption, or Other Planned Permanent Living Arrangement',
                                            cls: 'outcome-item-header'
                                        },
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Purpose of Assessment: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanency6Purpose'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 0 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>Item 6 Applicable Cases:</strong>'
                                        },
                                        {
                                            xtype: 'component',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '0 0 0 20',
                                            html: '<ul> <li> All foster care cases are applicable for an assessment of this item.</li></ul>'
                                        },
                                        //****************************************************
                                        // Outcome 1 - Question 6A1
                                        //****************************************************
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Question 6A1 Definitions: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanency6A1Def'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Question 6A1 Instructions: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanency6A1Ins'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '10 0 0 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>A1.</strong> What is the date of the child’s most recent entry into foster care?'
                                        },
                                        {
                                            xtype: 'container',
                                            cls: 'panel-background-color',
                                            border: true,
                                            layout: 'hbox',
                                            margin: '10 10 20 40',
                                            items: [
                                                {
                                                    xtype: 'datefield',
                                                    id: 'ChildMostRecentFosterEntryDate',
                                                    itemId: 'recentFosterEntryDate',
                                                    bind: '{childMostRecentFosterEntryDate}',
                                                    renderer: Ext.util.Format.dateRenderer('m/d/Y'),
                                                    maxValue: new Date(),
                                                    minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30),
                                                    readOnly: true
                                                }
                                            ]
                                        },
                                        //****************************************************
                                        // Outcome 1 - Question 6A2
                                        //****************************************************
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Question 6A2 Instructions: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanency6A2Ins'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '10 0 0 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>A2.</strong> What is the time in care (in months) at the time of the onsite review?'
                                        },
                                        {
                                            xtype: 'container',
                                            cls: 'panel-background-color',
                                            border: true,
                                            layout: 'hbox',
                                            margin: '10 10 20 40',
                                            items: [
                                                {
                                                    xtype: 'numberfield',
                                                    hideTrigger: true,
                                                    keyNavEnabled: false,
                                                    mouseWheelEnabled: false,
                                                    allowDecimals: false,
                                                    itemId: 'timeInCare',
                                                    enableKeyEvents: true,
                                                    bind: '{timeInCare}'
                                                }
                                            ]
                                        },
                                        //****************************************************
                                        // Outcome 1 - Question 6A3
                                        //****************************************************
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Question 6A3 Definitions: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanency6A3Def'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Question 6A3 Instructions: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanency6A3Ins'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '10 0 0 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>A3.</strong> What is the date the child discharged from foster care?'
                                        },
                                        {
                                            xtype: 'container',
                                            cls: 'panel-background-color',
                                            border: true,
                                            layout: 'hbox',
                                            margin: '10 10 20 40',
                                            items: [
                                                {
                                                    xtype: 'datefield',
                                                    id: 'dischargeDate',
                                                    itemId: 'permanencyDischargeDate',
                                                    bind: '{dischargeDate}',
                                                    renderer: Ext.util.Format.dateRenderer('m/d/Y'),
                                                    maxValue: new Date(),
                                                    minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30),
                                                    readOnly: true
                                                },
                                                {
                                                    margin: '0 0 0 10',
                                                    xtype: 'checkbox',
                                                    boxLabel: 'NA',
                                                    itemId: 'question6A3',
                                                    bind: '{isDischargeDateNA}',
                                                    inputValue: 1,
                                                    uncheckedValue: 0,
                                                    readOnly: true
                                                }
                                            ]
                                        },
                                        //****************************************************
                                        // Outcome 1 - Question 6A4
                                        //****************************************************
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Question 6A4 Instructions: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanency6A4Ins'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '10 0 0 20',
                                            cls: 'panel-background-color',
                                            html: "<strong>A4.</strong> What is (are) the child’s current permanency goal(s)? (If concurrent permanency goals have been established in the case plan, identify both goals.) Or, if the case was closed during the period under review, what was the permanency goal before the case was closed?"
                                        },
                                        {
                                            xtype: 'container',
                                            itemId: 'item6A4',
                                            cls: 'panel-background-color',
                                            border: true,
                                            layout: 'vbox',
                                            margin: '10 10 20 40',
                                            items: [
                                                {
                                                    xtype: 'component',
                                                    border: false,
                                                    margin: '10 0 0 10',
                                                    cls: 'panel-background-color',
                                                    html: 'Question 6A4 is answered using data from item 5, question 5A1.'
                                                },
                                                {
                                                    xtype: 'component',
                                                    border: false,
                                                    margin: '0 0 15 10',
                                                    cls: 'panel-background-color',
                                                    html: 'Please complete item 5 to generate an answer to question 6A4.'
                                                },
                                                {
                                                    xtype: 'checkboxgroup',
                                                    itemId: 'item6A4CBGroup',
                                                    columns: 1,
                                                    vertical: true,
                                                    listeners: {
                                                        click: {
                                                            element: 'el',
                                                            fn: function () {

                                                                appDataEvent.permanency.changeByUserAction = true;
                                                            }
                                                        }
                                                    },
                                                    items: [
                                                        {
                                                            itemId: 'permanencyGoal1',
                                                            boxLabel: 'Reunification',
                                                            inputValue: 127,
                                                            bind: '{permGoal1}'
                                                        },
                                                        {
                                                            itemId: 'permanencyGoal2',
                                                            boxLabel: 'Guardianship',
                                                            inputValue: 128,
                                                            bind: '{permGoal2}'
                                                        },
                                                        {
                                                            itemId: 'permanencyGoal3',
                                                            boxLabel: 'Adoption',
                                                            inputValue: 129,
                                                            bind: '{permGoal3}'
                                                        },
                                                        {
                                                            itemId: 'permanencyGoal4',
                                                            boxLabel: 'Other Planned Permanent Living Arrangement',
                                                            inputValue: 130,
                                                            bind: '{permGoal4}'
                                                        }
                                                    ]
                                                }
                                            ]
                                        },
                                        //****************************************************
                                        // Outcome 1 - Question 6B
                                        //****************************************************
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Question 6B Instructions: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanency6BIns'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '10 0 0 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>B.</strong> During the period under review, did the agency and court make concerted efforts to achieve permanency in a timely manner?'
                                        },
                                        {
                                            xtype: 'container',
                                            cls: 'panel-background-color',
                                            border: true,
                                            margin: '10 10 20 40',
                                            items: [
                                                {
                                                    xtype: 'radiogroup',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout: 'hbox',
                                                    margin: '0 0 20 0',
                                                    itemId: 'item6BQuestion',
                                                    items: [
                                                        {
                                                            xtype: 'radio',
                                                            boxLabel: '<b>Yes</b>',
                                                            itemId: 'question6BYes',
                                                            inputValue: 1,
                                                            bind: '{isAgencyConcertedEfforts}',
                                                            name: 'question6B'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>No</b>',
                                                            itemId: 'question6BNo',
                                                            inputValue: 2,
                                                            bind: '{isAgencyConcertedEfforts}',
                                                            name: 'question6B'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>NA</b>',
                                                            itemId: 'question6BNA',
                                                            inputValue: 3,
                                                            bind: '{isAgencyConcertedEfforts}',
                                                            name: 'question6B'
                                                        }
                                                    ]
                                                },
                                                {
                                                    xtype: 'validationMessage',
                                                    itemId: 'msgItem6BQuestion',
                                                    orientation: 'wide',
                                                    itemName: 'item6'
                                                },
                                                {
                                                    xtype: 'component',
                                                    border: false,
                                                    margin: '10 0 0 0',
                                                    cls: 'panel-background-color',
                                                    html: 'If No, explain any concerns in the narrative field below.'
                                                },
                                                {
                                                    xtype: 'textarea',
                                                    itemId: 'agencyConcertedEffortsExplained',
                                                    bind: '{agencyConcertedEffortsExplained}',
                                                    enableKeyEvents: true,
                                                    disabled: true,
                                                    //height: 100,  This does work with grow: true
                                                    //growMin: 100,
                                                    //growMax: 350,
                                                    //grow: true,
                                                    width: '75%',
                                                    maxlength: 4100,
                                                    enforceMaxLength: true,
                                                    height: 150
                                                }
                                            ]
                                        },
                                        //****************************************************
                                        // Outcome 1 - Question 6C1
                                        //****************************************************
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Question 6C1 Instructions: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanency6C1Ins'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '10 0 0 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>C1.</strong> If the child’s current (or most recent) permanency goal is (was) other planned permanent living arrangement, what is (was) the child’s permanent living arrangement?'
                                        },
                                        {
                                            xtype: 'container',
                                            cls: 'panel-background-color',
                                            border: true,
                                            margin: '10 10 20 40',
                                            items: [
                                                {
                                                    xtype: 'container',
                                                    cls: 'panel-background-color',
                                                    border: false,
                                                    layout: 'hbox',
                                                    margin: '0 0 20 0',
                                                    itemId: 'item6C1Question',
                                                    items: [
                                                        {
                                                            xtype: 'container',
                                                            border: false,
                                                            margin: '20 0 0 20',
                                                            cls: 'panel-background-color',
                                                            items: [
                                                                {
                                                                    xtype: 'combobox',
                                                                    fieldLabel: 'Select One:',
                                                                    itemId: 'livingArragmentCode',
                                                                    labelAlign: 'left',
                                                                    labelWidth: 150,
                                                                    store: chainedStore('LivingArrangementStore'),
                                                                    queryMode: 'local',
                                                                    displayField: 'DescriptionMedium',
                                                                    valueField: 'GroupID',
                                                                    editable: false,
                                                                    autoSelect: true,
                                                                    forceSelection: true,
                                                                    width: 450,
                                                                    //name: 'CR_Permanency_Collection.LivingArrangementCode',
                                                                    bind: '{livingArrangementCode}',
                                                                    renderer: function (value) {
                                                                        var lookupStore = chainedStore('LivingArrangementStore');
                                                                        var results = lookupStore.query('GroupID', value, false, false, true);
                                                                        if (results.length > 0) {
                                                                            return results.getAt(0).data.DescriptionLarge;
                                                                        }
                                                                        return '';
                                                                    }

                                                                }
                                                            ]
                                                        },
                                                        {
                                                            xtype: 'validationMessage',
                                                            itemId: 'msgItem6C1Question',
                                                            itemName: 'item6'
                                                        }
                                                    ]
                                                },
                                                {
                                                    xtype: 'component',
                                                    border: false,
                                                    margin: '10 0 0 0',
                                                    cls: 'panel-background-color',
                                                    html: "If Other is selected, describe the child's permanent living arrangement."
                                                },
                                                {
                                                    xtype: 'textarea',
                                                    itemId: 'livingArragmentExplained',
                                                    bind: '{livingArrangementExplained}',
                                                    enableKeyEvents: true,
                                                    disabled: true,
                                                    //height: 100,  This does work with grow: true
                                                    //growMin: 100,
                                                    //growMax: 350,
                                                    //grow: true,
                                                    width: '75%',
                                                    maxlength: 4100,
                                                    enforceMaxLength: true,
                                                    height: 150
                                                }
                                            ]
                                        },
                                        //****************************************************
                                        // Outcome 1 - Question 6C2
                                        //****************************************************
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Question 6C2 Instructions: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanency6C2Ins'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '10 0 0 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>C2.</strong> For a child with a goal of other planned permanent living arrangement during the period under review, what is the date of documentation regarding “permanency” of the child’s living arrangements?'
                                        },
                                        {
                                            xtype: 'container',
                                            cls: 'panel-background-color',
                                            border: true,
                                            layout: 'hbox',
                                            margin: '10 10 20 40',
                                            itemId: 'item6C2Question',
                                            items: [
                                                {
                                                    xtype: 'datefield',
                                                    itemId: 'question6C2DocumentationDate',
                                                    id: 'otherPlannedArrangementDocumentationDate',
                                                    bind: '{otherPlannedArrangementDocumentationDate}',
                                                    renderer: Ext.util.Format.dateRenderer('m/d/Y'),
                                                    enableKeyEvents: true,
                                                    maxValue: new Date(),
                                                    minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30)
                                                },
                                                {
                                                    xtype: 'radiogroup',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout: 'hbox',
                                                    margin: '0 0 20 0',
                                                    itemId: 'question6C2Grp',
                                                    items: [
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>NA</b>',
                                                            itemId: 'question6C2NA',
                                                            inputValue: 1,
                                                            name: 'OtherPlannedArrangement',
                                                            bind: '{isOtherPlannedArrangementNA}'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>No Date</b>',
                                                            itemId: 'question6C2NoDate',
                                                            inputValue: 1,
                                                            name: 'OtherPlannedArrangement',
                                                            bind: '{isOtherPlannedArrangementNoDate}'
                                                        }
                                                    ]
                                                },
                                                {
                                                    xtype: 'validationMessage',
                                                    itemId: 'msgItem6C2Question',
                                                    itemName: 'item6'
                                                }
                                            ]
                                        },
                                        //****************************************************
                                        // Outcome 1 - Question 6C
                                        //****************************************************
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Question 6C Instructions: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanency6CIns'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '10 0 0 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>C.</strong> For a child with a goal of other planned permanent living arrangement during the period under review, did the agency and court make concerted efforts to place the child in a living arrangement that can be considered permanent until discharge from foster care?'
                                        },
                                        {
                                            xtype: 'container',
                                            cls: 'panel-background-color',
                                            border: true,
                                            layout: 'hbox',
                                            margin: '10 10 0 40',
                                            items: [
                                                {
                                                    xtype: 'radiogroup',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout: 'hbox',
                                                    margin: '0 0 20 0',
                                                    itemId: 'item6CQuestion',
                                                    items: [
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>Yes</b>',
                                                            itemId: 'question6CYes',
                                                            inputValue: 1,
                                                            name: 'OtherPlannedConcertedEffort',
                                                            bind: '{isOtherPlannedConcertedEffort}'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>No</b>',
                                                            itemId: 'question6CNo',
                                                            inputValue: 2,
                                                            name: 'OtherPlannedConcertedEffort',
                                                            bind: '{isOtherPlannedConcertedEffort}'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>NA</b>',
                                                            itemId: 'question6CNA',
                                                            inputValue: 3,
                                                            name: 'OtherPlannedConcertedEffort',
                                                            bind: '{isOtherPlannedConcertedEffort}'
                                                        },
                                                        {
                                                            xtype: 'validationMessage',
                                                            itemId: 'msgItem6CQuestion',
                                                            orientation: 'wide',
                                                            itemName: 'item6'
                                                        }
                                                    ]
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'container',
                                            cls: 'panel-background-color',
                                            border: false,
                                            layout: 'vbox',
                                            margin: '0 0 20 20',
                                            itemId: 'item6CNarrative',
                                            items: [
                                                {
                                                    xtype: 'component',
                                                    border: false,
                                                    margin: '10 0 0 0',
                                                    cls: 'panel-background-color',
                                                    html: 'If No, explain any concerns in the narrative field below.'
                                                },
                                                {
                                                    xtype: 'textarea',
                                                    itemId: 'otherPlannedConcertedEffortExplained',
                                                    bind: '{otherPlannedConcertedEffortExplained}',
                                                    enableKeyEvents: true,
                                                    disabled: true,
                                                    //height: 100,  This does work with grow: true
                                                    //growMin: 100,
                                                    //growMax: 350,
                                                    //grow: true,
                                                    width: '75%',
                                                    maxlength: 4100,
                                                    enforceMaxLength: true,
                                                    height: 150
                                                },
                                                {
                                                    xtype: 'validationMessage',
                                                    itemId: 'msgItem6CNarrative',
                                                    itemName: 'item6'
                                                }
                                            ]
                                        },
                                        //***********************************************************
                                        // Item 6 Rating
                                        //***********************************************************
                                        {
                                            xtype: 'container',
                                            cls: 'panel-background-color',
                                            margin: '0 0 20 0',
                                            itemId: 'item6Rating',
                                            border: true,
                                            items:
                                            [
                                                {
                                                    xtype: 'listPanel',
                                                    title: "<div class='html-content-header-margins'>Item 6 Rating Criteria: [SHOW]</div>",
                                                    margin: '20 20 20 20',
                                                    padding: '0 0 0 0',
                                                    items: [
                                                        {
                                                            contentEl: 'permanency6RatingCriteria'
                                                        }
                                                    ]
                                                },
                                                {
                                                    xtype: 'component',
                                                    border: false,
                                                    margin: '20 0 10 20',
                                                    cls: 'panel-background-color',
                                                    html: '<strong>Item Rating:</strong>'
                                                },
                                                {
                                                    xtype: 'container',
                                                    border: false,
                                                    margin: '10 10 20 0',
                                                    layout: 'hbox',
                                                    itemId: 'item6RatingContainer',
                                                    items: [
                                                        {
                                                            xtype: 'itemRating',
                                                            itemId: 'permanencyItem6Rating',
                                                            itemCode: 7,
                                                            page: 'Permanency',
                                                            itemName: 'item6',
                                                            itemType: 'item',
                                                            outcomeCode: 3,
                                                            msgComponentId: 'msgItem6Rating',
                                                            ratingContainerId: 'item6RatingContainer'
                                                        },
                                                        {
                                                            xtype: 'validationMessage',
                                                            itemId: 'msgItem6Rating',
                                                            itemName: 'item6'
                                                        }
                                                    ]
                                                },
                                                {
                                                    xtype: 'component',
                                                    cls: 'panel-background-color',
                                                    border: false,
                                                    margin: '20 0 0 20',
                                                    html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below: '
                                                },
                                                {
                                                    xtype: 'container',
                                                    cls: 'panel-background-color',
                                                    border: false,
                                                    margin: '10 10 20 20',
                                                    items: [
                                                        {
                                                            xtype: 'textarea',
                                                            maxLength: 10000,
                                                            enableKeyEvents: true,
                                                            itemId: 'item6RatingComment',
                                                            bind: '{item6RatingComments}',
                                                            //height: 100,  This does work with grow: true
                                                            //growMin: 100,
                                                            //growMax: 350,
                                                            //grow: true,
                                                            width: '75%',
                                                            enforceMaxLength: true,
                                                            height: 150
                                                        }
                                                    ]
                                                },
                                                {
                                                    xtype: 'ratingOverride',
                                                    border: false,
                                                    margin: '20 0 10 20',
                                                    page: 'permanency',
                                                    itemNo: '6',
                                                    itemCode: 7,
                                                    outcomeCode: 3,
                                                    itemId: 'permanencyItem6RatingOverride',
                                                    ratingComponentId: 'permanencyItem6Rating',
                                                    outcomeRatingComponentId: 'permanencyOutcome1Rating'
                                                }
                                            ]
                                        },
                                        //****************************************************
                                        // Outcome 1 - Question 6 - QA Notes
                                        //****************************************************
                                        {
                                            xtype: 'qaNotes',
                                            itemId: 'permanencyItem6Notes',
                                            notesTitle: 'Item 6 - QA Notes',
                                            margin: '0 20 0 0',
                                            itemCode: 7,
                                            outcomeCode: 3
                                        }
                                    ]
                                },
                                //==========================================================================//
                                // Start of Outcome 2 Section
                                //==========================================================================//   
                                //======================================================================//
                                // Item 7 Overview
                                //======================================================================//
                                //***********************************************************************//
                                // Outcome 2 Instructions and Achievement Level
                                //***********************************************************************//                                
                                {
                                    xtype: 'container',
                                    //cls: 'cb',
                                    margin: '20 20 20 20',
                                    cls: 'panel-background-color',
                                    border: true,
                                    items:
                                    [
                                        {
                                            xtype: 'component',
                                            itemId: 'permanencyOutcome2',
                                            html: 'Outcome 2: The continuity of family relationships and connections is preserved for children.',
                                            margin: '20 20 20 20',
                                            cls: 'outcome-header'
                                        },
                                        {
                                            // SECTION A-1
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 0 20',
                                            cls: 'panel-background-color',
                                            html: 'What is the level of outcome achievement that best describes the extent to which this outcome is being or has been achieved, based on the ratings for items 7 through 11?'
                                        },
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Instructions: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanencyOutcome2Ins'
                                                }
                                            ]

                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 10 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>Level of Outcome Achievement:</strong>'
                                        },
                                        {
                                            xtype: 'itemRating',
                                            itemId: 'permanencyOutcome2Rating',
                                            page: 'Permanency',
                                            itemType: 'outcome',
                                            outcomeCode: 4
                                        },
                                        {
                                            xtype: 'component',
                                            itemId: 'item7',
                                            border: false,
                                            margin: '20 0 0 20',
                                            html: '<strong>Item 7:</strong> Placement With Siblings',
                                            cls: 'outcome-item-header'
                                        },
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Purpose of Assessment: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanency7Purpose'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 0 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>Item 7 Applicable Cases:</strong>'
                                        },
                                        {
                                            xtype: 'component',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '0 0 0 20',
                                            html: '<ul> <li>Cases applicable for an assessment of this item include all foster care cases in which the child has one or more siblings who are (or were) also in foster care during the period under review. If the child has no siblings in foster care during the period under review, the case is Not Applicable for an assessment of this item. For example, if the child in foster care has an older sibling who was in foster care at one time, but not during the period under review, this case would be Not Applicable.</li></ul>'
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '10 0 0 20',
                                            cls: 'outcome-item-header',
                                            html: '<strong>Is this case applicable?</strong>'
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '10 0 0 20',
                                            cls: 'panel-background-color',
                                            html: 'Select the appropriate response. If the response is No, the case will be rated as Not Applicable in the ratings section for this item.'
                                        },
                                        {
                                            xtype: 'itemApplicable',
                                            store: 'CR_Outcome_CollectionStore',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            OutcomeCode: 4,
                                            ItemCode: 8,
                                            items: [
                                                {
                                                    xtype: 'radiogroup',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout: 'hbox',
                                                    margin: '0 0 20 40',
                                                    itemId: 'item7Applicability',
                                                    items: [
                                                        {
                                                            xtype: 'radio',
                                                            boxLabel: '<b>Yes</b>',
                                                            itemId: 'item7Yes',
                                                            inputValue: 1,
                                                            name: 'applicableItem7',
                                                            bind: '{item7Applicable}'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>No</b>',
                                                            itemId: 'item7No',
                                                            name: 'applicableItem7',
                                                            inputValue: 2,
                                                            bind: '{item7Applicable}'
                                                        }
                                                    ]
                                                },
                                                {
                                                    xtype: 'container',
                                                    cls: 'panel-background-color',
                                                    border: false,
                                                    margin: '0 0 20 20',
                                                    items: [
                                                        {
                                                            xtype: 'component',
                                                            border: false,
                                                            margin: '10 0 0 0',
                                                            bodyCls: 'panel-background-color',
                                                            html: 'Optional: Provide comments in the narrative field below.'
                                                        },
                                                        {
                                                            xtype: 'textarea',
                                                            itemId: 'item7Comments',
                                                            bind: '{item7Comments}',
                                                            enableKeyEvents: true,
                                                            //height: 100,  This does work with grow: true
                                                            //growMin: 100,
                                                            //growMax: 350,
                                                            //grow: true,
                                                            width: '75%',
                                                            maxlength: 4100,
                                                            enforceMaxLength: true,
                                                            height: 150
                                                        }
                                                    ]
                                                }
                                            ]
                                        }
                                    ]
                                },
                                //****************************************************
                                // Outcome 2  -  Question 7A
                                //****************************************************
                                {
                                    xtype: 'question7A'
                                },
                                //****************************************************
                                // Outcome 2  -  Question 7B
                                //****************************************************
                                {
                                    xtype: 'question7B'
                                },
                                //***********************************************************
                                // Item 7 Rating
                                //***********************************************************
                                {
                                    xtype: 'panel',
                                    bodyCls: 'panel-background-color',
                                    margin: '0 0 20 0',
                                    itemId: 'item7Rating',
                                    border: true,
                                    items:
                                    [
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Item 7 Rating Criteria: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanency7RatingCriteria'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 10 20',
                                            bodyCls: 'panel-background-color',
                                            html: '<strong>Item Rating:</strong>'
                                        },
                                        {
                                            xtype: 'container',
                                            border: false,
                                            margin: '10 10 20 0',
                                            layout: 'hbox',
                                            itemId: 'item7RatingContainer',
                                            items: [
                                                {
                                                    xtype: 'itemRating',
                                                    itemId: 'permanencyItem7Rating',
                                                    itemCode: 8,
                                                    page: 'Permanency',
                                                    itemName: 'item7',
                                                    itemType: 'item',
                                                    outcomeCode: 4,
                                                    msgComponentId: 'msgItem7Rating',
                                                    ratingContainerId: 'item7RatingContainer'
                                                },
                                                {
                                                    xtype: 'validationMessage',
                                                    itemId: 'msgItem7Rating',
                                                    itemName: 'item7'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            margin: '20 0 0 20',
                                            html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below: '
                                        },
                                        {
                                            xtype: 'container',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            margin: '10 10 20 20',
                                            items: [
                                                {
                                                    xtype: 'textarea',
                                                    width: '75%',
                                                    maxLength: 10000,
                                                    enforceMaxLength: true,
                                                    itemId: 'item7RatingComment',
                                                    bind: '{item7RatingComments}',
                                                    height: 150
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'ratingOverride',
                                            border: false,
                                            margin: '20 0 10 20',
                                            page: 'permanency',
                                            itemNo: '7',
                                            itemCode: 8,
                                            outcomeCode: 4,
                                            itemId: 'permanencyItem7RatingOverride',
                                            ratingComponentId: 'permanencyItem7Rating',
                                            outcomeRatingComponentId: 'permanencyOutcome2Rating'
                                        }
                                    ]
                                },
                                //======================================================================//
                                // Item 7 QA Notes
                                //======================================================================//
                                {
                                    xtype: 'qaNotes',
                                    itemId: 'permanencyItem7Notes',
                                    notesTitle: 'Item 7 - QA Notes',
                                    margin: '0 20 0 0',
                                    itemCode: 8,
                                    outcomeCode: 4
                                },
                                //****************************************************
                                // Outcome 2 - Item 8
                                //****************************************************    
                                {
                                    xtype: 'item8Preapp'
                                },
                                //****************************************************
                                // Outcome 2 - Question 8A1
                                //**************************************************** 
                                {
                                    xtype: 'question8A1'
                                },
                                //****************************************************
                                // Outcome 2 - Question 8A
                                //**************************************************** 
                                {
                                    xtype: 'question8A'
                                },
                                //****************************************************
                                // Outcome 2 - Question 8C
                                //**************************************************** 
                                {
                                    xtype: 'question8C'
                                },
                                //****************************************************
                                // Outcome 2 - Question 8B1
                                //**************************************************** 
                                {
                                    xtype: 'question8B1'
                                },
                                //****************************************************
                                // Outcome 2 - Question 8B
                                //**************************************************** 
                                {
                                    xtype: 'question8B'
                                },
                                //****************************************************
                                // Outcome 2 - Question 8D
                                //**************************************************** 
                                {
                                    xtype: 'question8D'
                                },
                                //****************************************************
                                // Outcome 2 - Question 8E1
                                //**************************************************** 
                                {
                                    xtype: 'question8E1'
                                },
                                //****************************************************
                                // Outcome 2 - Question 8E
                                //**************************************************** 
                                {
                                    xtype: 'question8E'
                                },
                                //****************************************************
                                // Outcome 2 - Question 8F
                                //**************************************************** 
                                {
                                    xtype: 'question8F'
                                },
                                //***********************************************************
                                // Item 8 Rating
                                //***********************************************************
                                {
                                    xtype: 'container',
                                    cls: 'panel-background-color',
                                    margin: '0 20 20 20',
                                    itemId: 'item8Rating',
                                    border: true,
                                    items:
                                    [
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Item 8 Rating Criteria: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanency8RatingCriteria'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 10 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>Item Rating:</strong>'
                                        },
                                        {
                                            xtype: 'container',
                                            border: false,
                                            margin: '10 10 20 0',
                                            layout: 'hbox',
                                            itemId: 'item8RatingContainer',
                                            items: [
                                                {
                                                    xtype: 'itemRating',
                                                    itemId: 'permanencyItem8Rating',
                                                    itemCode: 9,
                                                    page: 'Permanency',
                                                    itemName: 'item8',
                                                    itemType: 'item',
                                                    outcomeCode: 4,
                                                    msgComponentId: 'msgItem8Rating',
                                                    ratingContainerId: 'item8RatingContainer'
                                                },
                                                {
                                                    xtype: 'validationMessage',
                                                    itemId: 'msgItem8Rating',
                                                    itemName: 'item8'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '20 0 0 20',
                                            html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below: '
                                        },
                                        {
                                            xtype: 'container',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '10 10 20 20',
                                            items: [
                                                {
                                                    xtype: 'textarea',
                                                    maxLength: 10000,
                                                    enableKeyEvents: true,
                                                    itemId: 'item8RatingComment',
                                                    bind: '{item8RatingComments}',
                                                    //height: 100,  This does work with grow: true
                                                    //growMin: 100,
                                                    //growMax: 350,
                                                    //grow: true,
                                                    width: '75%',
                                                    enforceMaxLength: true,
                                                    height: 150
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'ratingOverride',
                                            border: false,
                                            margin: '20 0 10 20',
                                            page: 'permanency',
                                            itemNo: '8',
                                            itemCode: 9,
                                            outcomeCode: 4,
                                            itemId: 'permanencyItem8RatingOverride',
                                            ratingComponentId: 'permanencyItem8Rating',
                                            outcomeRatingComponentId: 'permanencyOutcome2Rating'
                                        },
                                //****************************************************
                                // Outcome 2 - Question 8 QA Notes
                                //****************************************************
                                {
                                    xtype: 'qaNotes',
                                    itemId: 'permanencyItem8Notes',
                                    notesTitle: 'Item 8 - QA Notes',
                                    margin: '0 20 0 0',
                                    itemCode: 9,
                                    outcomeCode: 4
                                }
                                    ]
                                },
                                //****************************************************
                                // Outcome 2 - Item 9
                                //****************************************************
                                {
                                    xtype: 'container',
                                    //cls: 'cb',
                                    margin: '20 20 20 20',
                                    cls: 'panel-background-color',
                                    border: true,
                                    itemId: 'item9Panel',
                                    defaults: {
                                        trackResetOnLoad: true
                                    },
                                    items:
                                    [
                                        {
                                            xtype: 'component',
                                            itemId: 'item9',
                                            border: false,
                                            margin: '20 0 0 20',
                                            html: '<strong>Item 9:</strong> Preserving Connections',
                                            cls: 'outcome-item-header'
                                        },
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Purpose of Assessment: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanency9Purpose'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 0 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>Item 9 Applicable Cases:</strong>'
                                        },
                                        {
                                            xtype: 'component',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '0 0 0 20',
                                            html: '<ul> <li>Almost all foster care cases are applicable for an assessment of this item. A possible exception may be the situation of an abandoned infant where the agency has no information about the child’s extended family or connections.</li></ul>'
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '10 0 0 20',
                                            cls: 'outcome-item-header',
                                            html: '<strong>Is this case applicable?</strong>'
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '10 0 0 20',
                                            cls: 'panel-background-color',
                                            html: 'Select the appropriate response. If the response is No, the case will be rated as Not Applicable in the ratings section for this item.'
                                        },
                                        {
                                            xtype: 'itemApplicable',
                                            store: 'CR_Outcome_CollectionStore',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            OutcomeCode: 4,
                                            ItemCode: 10,
                                            items: [
                                                {
                                                    xtype: 'radiogroup',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout: 'hbox',
                                                    margin: '0 0 20 40',
                                                    itemId: 'applicabilityQuestion9',
                                                    items: [
                                                        {
                                                            xtype: 'radio',
                                                            boxLabel: '<b>Yes</b>',
                                                            inputValue: 1,
                                                            bind: '{item9Applicable}',
                                                            itemId: 'item9ApplicableYes',
                                                            name: 'applicableItem9'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>No</b>',
                                                            inputValue: 2,
                                                            bind: '{item9Applicable}',
                                                            itemId: 'item9ApplicableNo',
                                                            name: 'applicableItem9'
                                                        }
                                                    ]
                                                },
                                                {
                                                    xtype: 'container',
                                                    cls: 'panel-background-color',
                                                    border: false,
                                                    margin: '0 0 20 20',
                                                    items: [
                                                        {
                                                            xtype: 'component',
                                                            border: false,
                                                            margin: '10 0 0 0',
                                                            cls: 'panel-background-color',
                                                            html: 'Optional: Provide comments in the narrative field below.'
                                                        },
                                                        {
                                                            xtype: 'textarea',
                                                            itemId: 'item9ApplicableComments',
                                                            bind: '{item9Comments}',
                                                            enableKeyEvents: true,
                                                            //height: 100,  This does work with grow: true
                                                            //growMin: 100,
                                                            //growMax: 350,
                                                            //grow: true,
                                                            width: '75%',
                                                            maxlength: 4100,
                                                            enforceMaxLength: true,
                                                            height: 150
                                                        }
                                                    ]
                                                }
                                            ]
                                        }
                                    ]
                                },
                                //****************************************************
                                // Outcome 2 - Question 9A
                                //**************************************************** 
                                {
                                    xtype: 'question9A'
                                },
                                //****************************************************
                                // Outcome 2 - Question 9B
                                //**************************************************** 
                                {
                                    xtype: 'question9B'
                                },
                                //****************************************************
                                // Outcome 2 - Question 9C
                                //**************************************************** 
                                {
                                    xtype: 'question9C'
                                },
                                //****************************************************
                                // Outcome 2 - Question 9D
                                //**************************************************** 
                                {
                                    xtype: 'question9D'
                                },
                                //***********************************************************
                                // Item 9 Rating
                                //***********************************************************
                                {
                                    xtype: 'container',
                                    cls: 'panel-background-color',
                                    margin: '0 20 20 20',
                                    itemId: 'item9Rating',
                                    border: true,
                                    items:
                                    [
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Item 9 Rating Criteria: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanency9RatingCriteria'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 10 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>Item Rating:</strong>'
                                        },
                                        {
                                            xtype: 'container',
                                            border: false,
                                            margin: '10 10 20 0',
                                            layout: 'hbox',
                                            itemId: 'item9RatingContainer',
                                            items: [
                                                {
                                                    xtype: 'itemRating',
                                                    itemId: 'permanencyItem9Rating',
                                                    itemCode: 10,
                                                    page: 'Permanency',
                                                    itemName: 'item9',
                                                    itemType: 'item',
                                                    outcomeCode: 4,
                                                    msgComponentId: 'msgItem9Rating',
                                                    ratingContainerId: 'item9RatingContainer'
                                                },
                                                {
                                                    xtype: 'validationMessage',
                                                    itemId: 'msgItem9Rating',
                                                    itemName: 'item9'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '20 0 0 20',
                                            html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below: '
                                        },
                                        {
                                            xtype: 'container',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '10 10 20 20',
                                            items: [
                                                {
                                                    xtype: 'textarea',
                                                    maxLength: 10000,
                                                    enableKeyEvents: true,
                                                    itemId: 'item9RatingComment',
                                                    bind: '{item9RatingComments}',
                                                    //height: 100,  This does work with grow: true
                                                    //growMin: 100,
                                                    //growMax: 350,
                                                    //grow: true,
                                                    width: '75%',
                                                    enforceMaxLength: true,
                                                    height: 150
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'ratingOverride',
                                            border: false,
                                            margin: '20 0 10 20',
                                            page: 'permanency',
                                            itemNo: '9',
                                            itemCode: 10,
                                            outcomeCode: 4,
                                            itemId: 'permanencyItem9RatingOverride',
                                            ratingComponentId: 'permanencyItem9Rating',
                                            outcomeRatingComponentId: 'permanencyOutcome2Rating'
                                        },
                                //****************************************************
                                // Outcome 2 - Question 9 QA Notes
                                //****************************************************  
                                {
                                    xtype: 'qaNotes',
                                    itemId: 'permanencyItem9Notes',
                                    notesTitle: 'Item 9 - QA Notes',
                                    margin: '0 20 0 0',
                                    itemCode: 10,
                                    outcomeCode: 4
                                }
                                    ]
                                },
                                //****************************************************
                                // Outcome 2 - Item 10
                                //****************************************************
                                {
                                    xtype: 'container',
                                    itemId: 'item10Panel',
                                    //cls: 'cb',
                                    margin: '20 20 20 20',
                                    cls: 'panel-background-color',
                                    border: true,
                                    defaults: {
                                        trackResetOnLoad: true
                                    },
                                    items:
                                    [
                                        {
                                            xtype: 'component',
                                            itemId: 'item10',
                                            border: false,
                                            margin: '20 0 0 20',
                                            html: '<strong>Item 10:</strong> Relative Placement',
                                            cls: 'outcome-item-header'
                                        },
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Purpose of Assessment: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanency10Purpose'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 0 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>Item 10 Applicable Cases:</strong>'
                                        },
                                        {
                                            xtype: 'component',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '0 0 0 20',
                                            html: '<ul> <li>All foster care cases are applicable for assessment of this item except those in which (1) the agency determined upon the child’s initial entry into care that his or her needs required a specialized placement (such as residential treatment services) and that they will continue to require such specialized treatment the entire time the child is in care and a relative placement would be inappropriate, or (2) situations such as abandonment in which the identity of both parents and all relatives remains unknown despite documented concerted efforts to identify them.</li></ul>'
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '10 0 0 20',
                                            cls: 'outcome-item-header',
                                            html: '<strong>Is this case applicable?</strong>'
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '10 0 0 20',
                                            cls: 'panel-background-color',
                                            html: 'Select the appropriate response. If the response is No, the case will be rated as Not Applicable in the ratings section for this item.'
                                        },
                                        {
                                            xtype: 'itemApplicable',
                                            store: 'CR_Outcome_CollectionStore',
                                            bodyCls: 'panel-background-color',
                                            border: false,
                                            OutcomeCode: 4,
                                            ItemCode: 11,
                                            items: [
                                                {
                                                    xtype: 'radiogroup',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    layout: 'hbox',
                                                    margin: '0 0 20 40',
                                                    itemId: 'applicabilityQuestion10',
                                                    items: [
                                                        {
                                                            xtype: 'radio',
                                                            boxLabel: '<b>Yes</b>',
                                                            inputValue: 1,
                                                            bind: '{item10Applicable}',
                                                            itemId: 'item10ApplicableYes',
                                                            name: 'applicableItem10'
                                                        },
                                                        {
                                                            margin: '0 0 0 10',
                                                            xtype: 'radio',
                                                            boxLabel: '<b>No</b>',
                                                            inputValue: 2,
                                                            bind: '{item10Applicable}',
                                                            itemId: 'item10ApplicableNo',
                                                            name: 'applicableItem10'
                                                        }
                                                    ]
                                                },
                                                {
                                                    xtype: 'container',
                                                    bodyCls: 'panel-background-color',
                                                    border: false,
                                                    //layout: 'vbox',
                                                    margin: '0 0 20 20',
                                                    items: [
                                                        {
                                                            xtype: 'component',
                                                            border: false,
                                                            margin: '10 0 0 0',
                                                            cls: 'panel-background-color',
                                                            html: 'Optional: Provide comments in the narrative field below.'
                                                        },
                                                        {
                                                            xtype: 'textarea',
                                                            itemId: 'item10ApplicableComments',
                                                            bind: '{item10Comments}',
                                                            enableKeyEvents: true,
                                                            //height: 100,  This does work with grow: true
                                                            //growMin: 100,
                                                            //growMax: 350,
                                                            //grow: true,
                                                            width: '75%',
                                                            maxlength: 4100,
                                                            enforceMaxLength: true,
                                                            height: 150
                                                        }
                                                    ]
                                                }
                                            ]
                                        }
                                    ]
                                },
                                //****************************************************
                                // Outcome 2  -  Question 10A1
                                //****************************************************
                                {
                                    xtype: 'question10A1'
                                },
                                //****************************************************
                                // Outcome 2  -  Question 10A2
                                //****************************************************
                                {
                                    xtype: 'question10A2'
                                },
                                //****************************************************
                                // Outcome 2  -  Question 10B
                                //****************************************************
                                {
                                    xtype: 'question10B'
                                },
                                //****************************************************
                                // Outcome 2  -  Question 10C
                                //****************************************************
                                {
                                    xtype: 'question10C'
                                },
                                //***********************************************************
                                // Item 10 Rating
                                //***********************************************************
                                {
                                    xtype: 'container',
                                    cls: 'panel-background-color',
                                    margin: '0 20 20 20',
                                    itemId: 'item10Rating',
                                    border: true,
                                    items:
                                    [
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Item 10 Rating Criteria: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanency10RatingCriteria'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 10 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>Item Rating:</strong>'
                                        },
                                        {
                                            xtype: 'container',
                                            border: false,
                                            margin: '10 10 20 0',
                                            layout: 'hbox',
                                            itemId: 'item10RatingContainer',
                                            items: [
                                                {
                                                    xtype: 'itemRating',
                                                    itemId: 'permanencyItem10Rating',
                                                    itemCode: 11,
                                                    page: 'Permanency',
                                                    itemName: 'item10',
                                                    itemType: 'item',
                                                    outcomeCode: 4,
                                                    msgComponentId: 'msgItem10Rating',
                                                    ratingContainerId: 'item10RatingContainer'
                                                },
                                                {
                                                    xtype: 'validationMessage',
                                                    itemId: 'msgItem10Rating',
                                                    itemName: 'item10'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '20 0 0 20',
                                            html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below: '
                                        },
                                        {
                                            xtype: 'container',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '10 10 20 20',
                                            items: [
                                                {
                                                    xtype: 'textarea',
                                                    maxLength: 10000,
                                                    enableKeyEvents: true,
                                                    itemId: 'item10RatingComment',
                                                    bind: '{item10RatingComments}',
                                                    //height: 100,  This does work with grow: true
                                                    //growMin: 100,
                                                    //growMax: 350,
                                                    //grow: true,
                                                    width: '75%',
                                                    enforceMaxLength: true,
                                                    height: 150
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'ratingOverride',
                                            border: false,
                                            margin: '20 0 10 20',
                                            page: 'permanency',
                                            itemNo: '10',
                                            itemCode: 11,
                                            outcomeCode: 4,
                                            itemId: 'permanencyItem10RatingOverride',
                                            ratingComponentId: 'permanencyItem10Rating',
                                            outcomeRatingComponentId: 'permanencyOutcome2Rating'
                                        },
                                        //***********************************************************
                                        // Question 10 QA Notes
                                        //***********************************************************                                              
                                        {
                                            xtype: 'qaNotes',
                                            itemId: 'permanencyItem10Notes',
                                            notesTitle: 'Item 10 - QA Notes',
                                            margin: '0 20 0 0',
                                            itemCode: 11,
                                            outcomeCode: 4
                                        }
                                    ]
                                },
                                //****************************************************
                                // Outcome 2 - Item 11
                                //****************************************************
                                {
                                    xtype: 'item11Preapp'
                                },
                                //****************************************************
                                // Outcome 2  -  Question 11A
                                //****************************************************
                                {
                                    xtype: 'question11A'
                                },
                                //****************************************************
                                // Outcome 2  -  Question 11A1
                                //****************************************************
                                {
                                    xtype: 'question11A1'
                                },
                                //****************************************************
                                // Outcome 2  -  Question 11B
                                //****************************************************
                                {
                                    xtype: 'question11B'
                                },
                                //****************************************************
                                // Outcome 2  -  Question 11B1
                                //****************************************************
                                {
                                    xtype: 'question11B1'
                                },
                                //***********************************************************
                                // Item 11 Rating
                                //***********************************************************
                                {
                                    xtype: 'container',
                                    cls: 'panel-background-color',
                                    margin: '0 20 20 20',
                                    itemId: 'item11Rating',
                                    border: true,
                                    items:
                                    [
                                        {
                                            xtype: 'listPanel',
                                            title: "<div class='html-content-header-margins'>Item 11 Rating Criteria: [SHOW]</div>",
                                            margin: '20 20 20 20',
                                            padding: '0 0 0 0',
                                            items: [
                                                {
                                                    contentEl: 'permanency11RatingCriteria'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            border: false,
                                            margin: '20 0 10 20',
                                            cls: 'panel-background-color',
                                            html: '<strong>Item Rating:</strong>'
                                        },
                                        {
                                            xtype: 'container',
                                            border: false,
                                            margin: '10 10 20 0',
                                            layout: 'hbox',
                                            itemId: 'item11RatingContainer',
                                            items: [
                                                {
                                                    xtype: 'itemRating',
                                                    itemId: 'permanencyItem11Rating',
                                                    itemCode: 12,
                                                    page: 'Permanency',
                                                    itemName: 'item11',
                                                    itemType: 'item',
                                                    outcomeCode: 4,
                                                    msgComponentId: 'msgItem11Rating',
                                                    ratingContainerId: 'item11RatingContainer'
                                                },
                                                {
                                                    xtype: 'validationMessage',
                                                    itemId: 'msgItem11Rating',
                                                    itemName: 'item11'
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'component',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '20 0 0 20',
                                            html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below: '
                                        },
                                        {
                                            xtype: 'container',
                                            cls: 'panel-background-color',
                                            border: false,
                                            margin: '10 10 20 20',
                                            items: [
                                                {
                                                    xtype: 'textarea',
                                                    width: '75%',
                                                    maxLength: 10000,
                                                    enforceMaxLength: true,
                                                    enableKeyEvents: true,
                                                    itemId: 'item11RatingComment',
                                                    bind: '{item11RatingComments}',
                                                    height: 150
                                                    //grow: true,
                                                    //growMin: 100,
                                                    //growMax: 350
                                                }
                                            ]
                                        },
                                        {
                                            xtype: 'ratingOverride',
                                            border: false,
                                            margin: '20 0 10 20',
                                            page: 'permanency',
                                            itemNo: '11',
                                            itemCode: 12,
                                            outcomeCode: 4,
                                            itemId: 'permanencyItem11RatingOverride',
                                            ratingComponentId: 'permanencyItem11Rating',
                                            outcomeRatingComponentId: 'permanencyOutcome2Rating'
                                        },
                                //****************************************************
                                // Outcome 2 - Question 11 QA Notes
                                //****************************************************  
                                {
                                    xtype: 'qaNotes',
                                    itemId: 'permanencyItem11Notes',
                                    notesTitle: 'Item 11 - QA Notes',
                                    margin: '0 20 0 0',
                                    itemCode: 12,
                                    outcomeCode: 4
                                }
                                    ]
                                }
                                //==========================================================================//
                                // End of Outcome 2 Section
                                //==========================================================================//
                    ]
                }
            ]
        });
        me.callParent(arguments);
    }
});