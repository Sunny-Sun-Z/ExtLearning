﻿Ext.define('App.CaseReview.view.permanency.PermanencyViewModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.permanencyViewModel',
    stores: {
        permanencyPreAppAnswers: {},
        permanencyCollection: {},
        itemApplicability: {}
    },
    formulas: {
        //
        // Pre-applicability answers
        //
        answerCode57: {

            get: function () {

                var result;
                var items = this.data.permanencyPreAppAnswers.query('CodeDescriptionID', 57);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem8Question1().lastValue;
                    var newValue = getAppController().getItem8Question1().getValue();

                    this.data.answerCode57 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 57;
                    parms['value'] = value;
                    parms['pageName'] = 'permanency';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode58: {

            get: function () {

                var result;
                var items = this.data.permanencyPreAppAnswers.query('CodeDescriptionID', 58);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem8Question2().lastValue;
                    var newValue = getAppController().getItem8Question2().getValue();

                    this.data.answerCode58 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 58;
                    parms['value'] = value;
                    parms['pageName'] = 'permanency';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode59: {

            get: function () {

                var result;
                var items = this.data.permanencyPreAppAnswers.query('CodeDescriptionID', 59);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem8Question3().lastValue;
                    var newValue = getAppController().getItem8Question3().getValue();

                    this.data.answerCode59 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 59;
                    parms['value'] = value;
                    parms['pageName'] = 'permanency';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode60: {

            get: function () {

                var result;
                var items = this.data.permanencyPreAppAnswers.query('CodeDescriptionID', 60);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem8Question4().lastValue;
                    var newValue = getAppController().getItem8Question4().getValue();

                    this.data.answerCode60 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 60;
                    parms['value'] = value;
                    parms['pageName'] = 'permanency';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode61: {

            get: function () {

                var result;
                var items = this.data.permanencyPreAppAnswers.query('CodeDescriptionID', 61);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem8Question5().lastValue;
                    var newValue = getAppController().getItem8Question5().getValue();

                    this.data.answerCode61 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 61;
                    parms['value'] = value;
                    parms['pageName'] = 'permanency';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode62: {

            get: function () {

                var result;
                var items = this.data.permanencyPreAppAnswers.query('CodeDescriptionID', 62);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem8Question6().lastValue;
                    var newValue = getAppController().getItem8Question6().getValue();

                    this.data.answerCode62 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 62;
                    parms['value'] = value;
                    parms['pageName'] = 'permanency';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode63: {

            get: function () {

                var result;
                var items = this.data.permanencyPreAppAnswers.query('CodeDescriptionID', 63);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem11Question1().lastValue;
                    var newValue = getAppController().getItem11Question1().getValue();

                    this.data.answerCode63 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 63;
                    parms['value'] = value;
                    parms['pageName'] = 'permanency';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode64: {

            get: function () {

                var result;
                var items = this.data.permanencyPreAppAnswers.query('CodeDescriptionID', 64);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem11Question2().lastValue;
                    var newValue = getAppController().getItem11Question2().getValue();

                    this.data.answerCode64 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 64;
                    parms['value'] = value;
                    parms['pageName'] = 'permanency';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode65: {

            get: function () {

                var result;
                var items = this.data.permanencyPreAppAnswers.query('CodeDescriptionID', 65);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem11Question3().lastValue;
                    var newValue = getAppController().getItem11Question3().getValue();

                    this.data.answerCode65 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 65;
                    parms['value'] = value;
                    parms['pageName'] = 'permanency';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode66: {

            get: function () {

                var result;
                var items = this.data.permanencyPreAppAnswers.query('CodeDescriptionID', 66);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem11Question4().lastValue;
                    var newValue = getAppController().getItem11Question4().getValue();

                    this.data.answerCode66 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 66;
                    parms['value'] = value;
                    parms['pageName'] = 'permanency';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode67: {

            get: function () {

                var result;
                var items = this.data.permanencyPreAppAnswers.query('CodeDescriptionID', 67);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem11Question5().lastValue;
                    var newValue = getAppController().getItem11Question5().getValue();

                    this.data.answerCode67 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 67;
                    parms['value'] = value;
                    parms['pageName'] = 'permanency';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        answerCode261: {

            get: function () {

                var result;
                var items = this.data.permanencyPreAppAnswers.query('CodeDescriptionID', 261);

                if (items.count() > 0) {

                    result = items.items[0].data.AnswerCode;
                }

                return result;
            },
            set: function (value) {
                
                if (value) {

                    var parms = {};
                    var oldValue = getAppController().getItem11Question6().lastValue;
                    var newValue = getAppController().getItem11Question6().getValue();

                    this.data.answerCode261 = getSelectedGroupValue(newValue, oldValue);

                    parms['oldValue'] = oldValue;
                    parms['newValue'] = newValue;
                    parms['codeDescriptionId'] = 261;
                    parms['value'] = value;
                    parms['pageName'] = 'permanency';

                    updatePreApplicabilityAnswers(parms);
                }
            }
        },
        //
        // Other permanency data items
        //
        agencyConcertedEffortsExplained: {

            get: function () {

                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.AgencyConcertedEffortsExplained;
                }
                
                return result;
            },
            set: function (value) {
                
                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.AgencyConcertedEffortsExplained = value;

                this.data.agencyConcertedEffortsExplained = value;
            }
        },
        allGoalsAppropriateExplained: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.AllGoalsAppropriateExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.AllGoalsAppropriateExplained = value;

                this.data.allGoalsAppropriateExplained = value;
            }
        },
        allGoalsInTimelyMannerExplained: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.AllGoalsInTimelyMannerExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.AllGoalsInTimelyMannerExplained = value;

                this.data.allGoalsInTimelyMannerExplained = value;
            }
        },
        caseReviewID: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.CaseReviewID;
                }

                return result;
            }            
        },
        childMostRecentFosterEntryDate: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.ChildMostRecentFosterEntryDate;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.ChildMostRecentFosterEntryDate = value;

                this.data.childMostRecentFosterEntryDate = value;
            }
        },
        currentGoals: {

            get: function () {

                var result = getCurrentGoals();

                return result;
            }
        },
        dischargeDate: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.DischargeDate;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.DischargeDate = value;

                this.data.dischargeDate = value;
            }
        },
        effortFatherFosterRelationshipOther: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.EffortFatherFosterRelationshipOther;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.EffortFatherFosterRelationshipOther = value;

                this.data.effortFatherFosterRelationshipOther = value;
            }
        },
        effortsMotherFosterOther: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.EffortsMotherFosterOther;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.EffortsMotherFosterOther = value;

                this.data.effortsMotherFosterOther = value;
            }
        },
        fatherVisitationFrequencyCode: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.FatherVisitationFrequencyCode;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.FatherVisitationFrequencyCode = value;

                this.data.fatherVisitationFrequencyCode = value;
            }
        },
        goal1Code: {

            get: function () {

                var result;

                var goalColl = getCurrentGoals();

                if (goalColl.length > 0) {

                    result = goalColl[0] == 127 ? 1 :
                             goalColl[0] == 128 ? 2 :
                             goalColl[0] == 129 ? 3 :
                             goalColl[0] == 130 ? 4 : undefined;
                }
                
                if (this.data.permanencyCollection.count() > 0) {

                    this.data.permanencyCollection.getAt(0).data.Goal1Code = result;
                }

                return result;
            }
        },
        goal1Store: {

            get: function () {

                return chainedStore('PermanencyGoal1Store');
            }
        },
        goal2Code: {

            get: function () {

                var result = 5;

                var goalColl = getCurrentGoals();

                if (goalColl.length > 1) {

                    result = goalColl[1] == 127 ? 1 :
                             goalColl[1] == 128 ? 2 :
                             goalColl[1] == 129 ? 3 :
                             goalColl[1] == 130 ? 4 : 5;
                }

                if (this.data.permanencyCollection.count() > 0) {

                    this.data.permanencyCollection.getAt(0).data.Goal2Code = result;
                }

                return result;
            }
        },
        goal2Store: {

            get: function () {

                return chainedStore('PermanencyGoal2Store');
            }
        },
        isAccordanceWithIndianChildWelfareAct: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsAccordanceWithIndianChildWelfareAct;
                }

                return result;
            },
            set: function (value) {
                
                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsAccordanceWithIndianChildWelfareAct = value;

                    this.data.isAccordanceWithIndianChildWelfareAct = value;
                }
            }
        },
        isAgencyConcertedEfforts: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsAgencyConcertedEfforts;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsAgencyConcertedEfforts = value;

                    this.data.isAgencyConcertedEfforts = value;
                }
            }
        },
        isAgencyJointTerminationOfParentalRights: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsAgencyJointTerminationOfParentalRights;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsAgencyJointTerminationOfParentalRights = value;

                    this.data.isAgencyJointTerminationOfParentalRights = value;
                }
            }
        },
        isConcertedEffortFatherFosterRelationship: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsConcertedEffortFatherFosterRelationship;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsConcertedEffortFatherFosterRelationship = value;

                    this.data.isConcertedEffortFatherFosterRelationship = value;
                }
            }
        },
        isConcertedEffortMotherFosterRelationship: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsConcertedEffortMotherFosterRelationship;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsConcertedEffortMotherFosterRelationship = value;
                    
                    this.data.isConcertedEffortMotherFosterRelationship = value;
                }
            }
        },
        isConcertedEffortToLocateMaternalRelatives: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsConcertedEffortToLocateMaternalRelatives;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsConcertedEffortToLocateMaternalRelatives = value;

                    this.data.isConcertedEffortToLocateMaternalRelatives = value;
                }
            }
        },
        isConcertedEffortToLocatePaternalRelatives: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsConcertedEffortToLocatePaternalRelatives;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsConcertedEffortToLocatePaternalRelatives = value;

                    this.data.isConcertedEffortToLocatePaternalRelatives = value;
                }
            }
        },
        isConcertedEffortsForImportantConnections: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsConcertedEffortsForImportantConnections;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsConcertedEffortsForImportantConnections = value;

                    this.data.isConcertedEffortsForImportantConnections = value;
                }
            }
        },
        isCurrentPlacementSettingStable: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsCurrentPlacementSettingStable;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsCurrentPlacementSettingStable = value;

                    this.data.isCurrentPlacementSettingStable = value;
                }
            }
        },
        isDischargeDateNA: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsDischargeDateNA;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsDischargeDateNA = value;

                    this.data.isDischargeDateNA = value;
                }
            }
        },
        isExceptionForTermination: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsExceptionForTermination;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsExceptionForTermination = value;

                    this.data.isExceptionForTermination = value;
                }
            }
        },
        isGoalSpecified: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsGoalSpecified;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsGoalSpecified = value;

                    this.data.isGoalSpecified = value;
                }
            }
        },
        isInFoster15OutOf22: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsInFoster15OutOf22;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsInFoster15OutOf22 = value;

                    this.data.isInFoster15OutOf22 = value;
                }
            }
        },
        isOtherPlannedArrangementNA: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsOtherPlannedArrangementNA;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsOtherPlannedArrangementNA = value;

                    this.data.isOtherPlannedArrangementNA = value;
                }
            }
        },
        isOtherPlannedArrangementNoDate: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsOtherPlannedArrangementNoDate;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsOtherPlannedArrangementNoDate = value;

                    this.data.isOtherPlannedArrangementNoDate = value;
                }
            }
        },
        isOtherPlannedConcertedEffort: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsOtherPlannedConcertedEffort;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsOtherPlannedConcertedEffort = value;

                    this.data.isOtherPlannedConcertedEffort = value;
                }
            }
        },
        isPlacedWithAllSiblings: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsPlacedWithAllSiblings;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsPlacedWithAllSiblings = value;

                    this.data.isPlacedWithAllSiblings = value;
                }
            }
        },
        isPlacementWithRelativeStable: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsPlacementWithRelativeStable;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsPlacementWithRelativeStable = value;

                    this.data.isPlacementWithRelativeStable = value;
                }
            }
        },
        isRecentPlacementWithRelative: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsRecentPlacementWithRelative;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsRecentPlacementWithRelative = value;

                    this.data.isRecentPlacementWithRelative = value;
                }
            }
        },
        isSufficentQualityForFatherVisitation: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsSufficentQualityForFatherVisitation;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsSufficentQualityForFatherVisitation = value;

                    this.data.isSufficentQualityForFatherVisitation = value;
                }
            }
        },
        isSufficentQualityForSiblingVisitation: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsSufficentQualityForSiblingVisitation;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsSufficentQualityForSiblingVisitation = value;

                    this.data.isSufficentQualityForSiblingVisitation = value;
                }
            }
        },
        isSufficientFrequencyForFatherVisitation: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsSufficientFrequencyForFatherVisitation;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsSufficientFrequencyForFatherVisitation = value;

                    this.data.isSufficientFrequencyForFatherVisitation = value;
                }
            }
        },
        isSufficientFrequencyForMotherVisitation: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsSufficientFrequencyForMotherVisitation;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsSufficientFrequencyForMotherVisitation = value;

                    this.data.isSufficientFrequencyForMotherVisitation = value;
                }
            }
        },
        isSufficientFrequencyForSiblingVisitation: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsSufficientFrequencyForSiblingVisitation;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsSufficientFrequencyForSiblingVisitation = value;

                    this.data.isSufficientFrequencyForSiblingVisitation = value;
                }
            }
        },
        isSufficientInquiryForIndianTribe: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsSufficientInquiryForIndianTribe;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsSufficientInquiryForIndianTribe = value;

                    this.data.isSufficientInquiryForIndianTribe = value;
                }
            }
        },
        isSufficientQualityForMotherVisitation: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsSufficientQualityForMotherVisitation;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsSufficientQualityForMotherVisitation = value;

                    this.data.isSufficientQualityForMotherVisitation = value;
                }
            }
        },
        isTribeProvidedTimelyNotification: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsTribeProvidedTimelyNotification;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsTribeProvidedTimelyNotification = value;

                    this.data.isTribeProvidedTimelyNotification = value;
                }
            }
        },
        isValidReasonForSeparation: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsValidReasonForSeparation;
                }

                return result;
            },
            set: function (value) {

                if (Ext.isNumeric(value)) {

                    if (this.data.permanencyCollection.count() == 0) {

                        return;
                    }

                    this.data.permanencyCollection.getAt(0).data.IsValidReasonForSeparation = value;

                    this.data.isValidReasonForSeparation = value;
                }
            }
        },
        livingArrangementCode: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.LivingArrangementCode;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.LivingArrangementCode = value;

                this.data.livingArrangementCode = value;
            }
        },
        livingArrangementExplained: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.LivingArrangementExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.LivingArrangementExplained = value;

                this.data.livingArrangementExplained = value;
            }
        },
        motherVisitationFrequencyCode: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.MotherVisitationFrequencyCode;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.MotherVisitationFrequencyCode = value;

                this.data.motherVisitationFrequencyCode = value;
            }
        },
        numberOfPlacementSettings: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.NumberOfPlacementSettings;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.NumberOfPlacementSettings = value;

                this.data.numberOfPlacementSettings = value;
            }
        },
        otherPlannedArrangementDocumentationDate: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.OtherPlannedArrangementDocumentationDate;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.OtherPlannedArrangementDocumentationDate = value;

                this.data.otherPlannedArrangementDocumentationDate = value;
            }
        },
        otherPlannedConcertedEffortExplained: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.OtherPlannedConcertedEffortExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.OtherPlannedConcertedEffortExplained = value;

                this.data.otherPlannedConcertedEffortExplained = value;
            }
        },
        permGoal1: {

            get: function () {

                return getPermGoalValue(127);
            }
        },
        permGoal2: {

            get: function () {

                return getPermGoalValue(128);
            }
        },
        permGoal3: {

            get: function () {

                return getPermGoalValue(129);
            }
        },
        permGoal4: {

            get: function () {

                return getPermGoalValue(130);
            }
        },
        permanencyId: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.PermanencyID;
                }

                return result;
            }
        },
        placementApplicableCircumstancesOther: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.PlacementApplicableCircumstancesOther;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.PlacementApplicableCircumstancesOther = value;

                this.data.placementApplicableCircumstancesOther = value;
            }
        },
        siblingVisitationFrequencyCode: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.SiblingVisitationFrequencyCode;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.SiblingVisitationFrequencyCode = value;

                this.data.siblingVisitationFrequencyCode = value;
            }
        },
        timeInCare: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.TimeInCare;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.TimeInCare = value;

                this.data.timeInCare = value;
            }
        },
        validReasonForSeparationExplained: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.ValidReasonForSeparationExplained;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.ValidReasonForSeparationExplained = value;

                this.data.validReasonForSeparationExplained = value;
            }
        },
        isOtherPlannedArrangement: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.IsOtherPlannedArrangement;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                if (Ext.isNumeric(value)) {

                    this.data.permanencyCollection.getAt(0).data.IsOtherPlannedArrangement = value;

                    this.data.isOtherPlannedArrangement = value;
                }
            }
        },
        meetsTerminationOfParentalRights: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.meetsTerminationOfParentalRights;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.meetsTerminationOfParentalRights = value;

                this.data.meetsTerminationOfParentalRights = value;
            }
        },
        wereAllGoalsAppropriate: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.wereAllGoalsAppropriate;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.wereAllGoalsAppropriate = value;

                this.data.wereAllGoalsAppropriate = value;
            }
        },
        wereAllGoalsInTimelyManner: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.wereAllGoalsInTimelyManner;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.wereAllGoalsInTimelyManner = value;

                this.data.wereAllGoalsInTimelyManner = value;
            }
        },
        wereAllPlacementChangesPlanned: {

            get: function () {
                
                var result;

                if (this.data.permanencyCollection.data.length > 0) {

                    result = this.data.permanencyCollection.getAt(0).data.wereAllPlacementChangesPlanned;
                }

                return result;
            },
            set: function (value) {

                if (this.data.permanencyCollection.count() == 0) {

                    return;
                }

                this.data.permanencyCollection.getAt(0).data.wereAllPlacementChangesPlanned = value;

                this.data.wereAllPlacementChangesPlanned = value;
            }
        },
        //
        // Item applicability
        //
        item4Applicable: {

            get: function () {

                var result;
                var outcome3 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 3;
                });

                if (outcome3.length > 0) {

                    var selectedItem = outcome3[0].data.CR_Item_Collection.filter(function (item) {

                        return item.ItemCode == 5;
                    });

                    if (selectedItem.length > 0) {

                        result = selectedItem[0].IsApplicable;
                    }
                }
                
                return result;
            },
            set: function (value) {

                if (!isApplicableValue(value)) {

                    return;
                }

                var outcome3 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 3;
                });

                if (outcome3.length > 0) {

                    var selectedItem = outcome3[0].data.CR_Item_Collection.filter(function (item) {

                        return item.ItemCode == 5;
                    });

                    if (selectedItem.length == 0) {

                        return;
                    }

                    selectedItem[0].IsApplicable = value;

                    this.data.item4Applicable = value;
                }
            }
        },
        item5Applicable: {

            get: function () {

                var result;
                var outcome3 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 3;
                });
                
                if (outcome3.length > 0) {

                    var selectedItem = outcome3[0].data.CR_Item_Collection.filter(function (item) {

                        return item.ItemCode == 6;
                    });

                    if (selectedItem.length > 0) {

                        result = selectedItem[0].IsApplicable;
                    }
                }

                return result;
            },
            set: function (value) {
                
                if (!isApplicableValue(value)) {

                    return;
                }
                
                var outcome3 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 3;
                });

                if (outcome3.length > 0) {

                    var selectedItem = outcome3[0].data.CR_Item_Collection.filter(function (item) {

                        return item.ItemCode == 6;
                    });

                    if (selectedItem.length == 0) {

                        return;
                    }

                    selectedItem[0].IsApplicable = value;

                    this.data.item5Applicable = value;
                }
            }
        },
        item5Comments: {

            get: function () {

                var result;
                var outcome3 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 3;
                });

                if (outcome3.length == 0) {

                    return;
                }

                var selectedItem = outcome3[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 6;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].Comments;
                }

                return result;
            },
            set: function (value) {

                var outcome3 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 3;
                });

                if (outcome3.length == 0) {

                    return;
                }

                var selectedItem = outcome3[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 6;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].Comments = value;

                this.data.item5Comments = value;
            }
        },
        item6Applicable: {

            get: function () {

                var result;
                var outcome3 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 3;
                });
                
                if (outcome3.length > 0) {

                    var selectedItem = outcome3[0].data.CR_Item_Collection.filter(function (item) {

                        return item.ItemCode == 7;
                    });

                    if (selectedItem.length > 0) {

                        result = selectedItem[0].IsApplicable;
                    }
                }

                return result;
            },
            set: function (value) {

                if (!isApplicableValue(value)) {

                    return;
                }

                var outcome3 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 3;
                });

                if (outcome3.length > 0) {

                    var selectedItem = outcome3[0].data.CR_Item_Collection.filter(function (item) {

                        return item.ItemCode == 7;
                    });

                    if (selectedItem.length == 0) {

                        return;
                    }

                    selectedItem[0].IsApplicable = value;

                    this.data.item6Applicable = value;
                }
            }
        },
        item7Applicable: {

            get: function () {

                var result;
                var outcome4 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });
                
                if (outcome4.length > 0) {

                    var selectedItem = outcome4[0].data.CR_Item_Collection.filter(function (item) {

                        return item.ItemCode == 8;
                    });

                    if (selectedItem.length > 0) {

                        result = selectedItem[0].IsApplicable;
                    }
                }

                return result;
            },
            set: function (value) {

                if (!isApplicableValue(value)) {

                    return;
                }

                var outcome4 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome4.length > 0) {

                    var selectedItem = outcome4[0].data.CR_Item_Collection.filter(function (item) {

                        return item.ItemCode == 8;
                    });
                    
                    if (selectedItem.length == 0) {

                        return;
                    }

                    selectedItem[0].IsApplicable = value;

                    this.data.item7Applicable = value;
                }
            }
        },
        item7Comments: {

            get: function () {

                var result;
                var outcome4 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome4.length == 0) {

                    return;
                }

                var selectedItem = outcome4[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 8;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].Comments;
                }

                return result;
            },
            set: function (value) {

                var outcome4 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome4.length == 0) {

                    return;
                }

                var selectedItem = outcome4[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 8;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].Comments = value;

                this.data.item7Comments = value;
            }
        },
        item8Applicable: {

            get: function () {

                var result;
                var outcome4 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });
                
                if (outcome4.length > 0) {

                    var selectedItem = outcome4[0].data.CR_Item_Collection.filter(function (item) {

                        return item.ItemCode == 9;
                    });

                    if (selectedItem.length > 0) {

                        result = selectedItem[0].IsApplicable;
                    }
                }

                return result;
            },
            set: function (value) {

                if (!isApplicableValue(value)) {

                    return;
                }

                var outcome4 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome4.length > 0) {

                    var selectedItem = outcome4[0].data.CR_Item_Collection.filter(function (item) {

                        return item.ItemCode == 9;
                    });

                    if (selectedItem.length == 0) {

                        return;
                    }

                    selectedItem[0].IsApplicable = value;

                    this.data.item8Applicable = value;
                }
            }
        },
        item8Comments: {

            get: function () {

                var result;
                var outcome4 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome4.length == 0) {

                    return;
                }

                var selectedItem = outcome4[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 9;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].Comments;
                }

                return result;
            },
            set: function (value) {

                var outcome4 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome4.length == 0) {

                    return;
                }

                var selectedItem = outcome4[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 9;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].Comments = value;

                this.data.item8Comments = value;
            }
        },
        item9Applicable: {

            get: function () {

                var result;
                var outcome4 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });
                
                if (outcome4.length > 0) {

                    var selectedItem = outcome4[0].data.CR_Item_Collection.filter(function (item) {

                        return item.ItemCode == 10;
                    });

                    if (selectedItem.length > 0) {

                        result = selectedItem[0].IsApplicable;
                    }
                }

                return result;
            },
            set: function (value) {

                if (!isApplicableValue(value)) {

                    return;
                }

                var outcome4 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome4.length > 0) {

                    var selectedItem = outcome4[0].data.CR_Item_Collection.filter(function (item) {

                        return item.ItemCode == 10;
                    });

                    if (selectedItem.length == 0) {

                        return;
                    }

                    selectedItem[0].IsApplicable = value;

                    this.data.item9Applicable = value;
                }
            }
        },
        item9Comments: {

            get: function () {

                var result;
                var outcome4 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome4.length == 0) {

                    return;
                }

                var selectedItem = outcome4[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 10;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].Comments;
                }

                return result;
            },
            set: function (value) {

                var outcome4 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome4.length == 0) {

                    return;
                }

                var selectedItem = outcome4[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 10;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].Comments = value;

                this.data.item9Comments = value;
            }
        },
        item10Applicable: {

            get: function () {

                var result;
                var outcome4 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });
                
                if (outcome4.length > 0) {

                    var selectedItem = outcome4[0].data.CR_Item_Collection.filter(function (item) {

                        return item.ItemCode == 11;
                    });

                    if (selectedItem.length > 0) {

                        result = selectedItem[0].IsApplicable;
                    }
                }

                return result;
            },
            set: function (value) {

                if (!isApplicableValue(value)) {

                    return;
                }

                var outcome4 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome4.length > 0) {

                    var selectedItem = outcome4[0].data.CR_Item_Collection.filter(function (item) {

                        return item.ItemCode == 11;
                    });

                    if (selectedItem.length == 0) {

                        return;
                    }

                    selectedItem[0].IsApplicable = value;

                    this.data.item10Applicable = value;
                }
            }
        },
        item10Comments: {

            get: function () {

                var result;
                var outcome4 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome4.length == 0) {

                    return;
                }

                var selectedItem = outcome4[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 11;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].Comments;
                }

                return result;
            },
            set: function (value) {

                var outcome4 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome4.length == 0) {

                    return;
                }

                var selectedItem = outcome4[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 11;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].Comments = value;

                this.data.item10Comments = value;
            }
        },
        item11Applicable: {

            get: function () {

                var result;
                var outcome4 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });
                
                if (outcome4.length > 0) {

                    var selectedItem = outcome4[0].data.CR_Item_Collection.filter(function (item) {

                        return item.ItemCode == 12;
                    });

                    if (selectedItem.length > 0) {

                        result = selectedItem[0].IsApplicable;
                    }
                }

                return result;
            },
            set: function (value) {

                if (!isApplicableValue(value)) {

                    return;
                }

                var outcome4 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome4.length > 0) {

                    var selectedItem = outcome4[0].data.CR_Item_Collection.filter(function (item) {

                        return item.ItemCode == 12;
                    });

                    if (selectedItem.length == 0) {

                        return;
                    }

                    selectedItem[0].IsApplicable = value;

                    this.data.item11Applicable = value;
                }
            }
        },
        item11Comments: {

            get: function () {

                var result;
                var outcome4 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome4.length == 0) {

                    return;
                }

                var selectedItem = outcome4[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 12;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].Comments;
                }

                return result;
            },
            set: function (value) {

                var outcome4 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome4.length == 0) {

                    return;
                }

                var selectedItem = outcome4[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 12;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].Comments = value;

                this.data.item11Comments = value;
            }
        },
        outcome1Rating: {

            get: function () {

                var result = outcomeRatings.permanency.outcome1.ratingDescription;

                return result;
            },
            set: function (value) {

                if (!Ext.isEmpty(value)) {

                    outcomeRatings.permanency.outcome1.ratingCode = value.ratingCode;
                    outcomeRatings.permanency.outcome1.outcomeCode = value.outcomeCode;
                    outcomeRatings.permanency.outcome1.ratingDescription = value.ratingDescription;

                    this.data.outcome1Rating = value.ratingDescription;
                }
            }
        },
        outcome2Rating: {

            get: function () {

                var result = outcomeRatings.permanency.outcome2.ratingDescription;

                return result;
            },
            set: function (value) {

                if (!Ext.isEmpty(value)) {

                    outcomeRatings.permanency.outcome2.ratingCode = value.ratingCode;
                    outcomeRatings.permanency.outcome2.outcomeCode = value.outcomeCode;
                    outcomeRatings.permanency.outcome2.ratingDescription = value.ratingDescription;

                    this.data.outcome2Rating = value.ratingDescription;
                }
            }
        },
        // Rating comments
        //
        item4RatingComments: {

            get: function () {

                var result;
                var outcome1 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 3;
                });

                if (outcome1.length == 0) {

                    return;
                }

                var selectedItem = outcome1[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 5;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].RatingComments;
                }

                return result;
            },
            set: function (value) {

                var outcome1 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 3;
                });

                if (outcome1.length == 0) {

                    return;
                }

                var selectedItem = outcome1[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 5;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].RatingComments = value;

                this.data.item4RatingComments = value;
            }
        },
        item5RatingComments: {

            get: function () {

                var result;
                var outcome1 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 3;
                });

                if (outcome1.length == 0) {

                    return;
                }

                var selectedItem = outcome1[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 6;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].RatingComments;
                }

                return result;
            },
            set: function (value) {

                var outcome1 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 3;
                });

                if (outcome1.length == 0) {

                    return;
                }

                var selectedItem = outcome1[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 6;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].RatingComments = value;

                this.data.item5RatingComments = value;
            }
        },
        item6RatingComments: {

            get: function () {

                var result;
                var outcome1 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 3;
                });

                if (outcome1.length == 0) {

                    return;
                }

                var selectedItem = outcome1[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 7;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].RatingComments;
                }

                return result;
            },
            set: function (value) {

                var outcome1 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 3;
                });

                if (outcome1.length == 0) {

                    return;
                }

                var selectedItem = outcome1[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 7;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].RatingComments = value;

                this.data.item6RatingComments = value;
            }
        },
        item7RatingComments: {

            get: function () {

                var result;
                var outcome2 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome2.length == 0) {

                    return;
                }

                var selectedItem = outcome2[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 8;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].RatingComments;
                }

                return result;
            },
            set: function (value) {

                var outcome2 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome2.length == 0) {

                    return;
                }

                var selectedItem = outcome2[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 8;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].RatingComments = value;

                this.data.item7RatingComments = value;
            }
        },
        item8RatingComments: {

            get: function () {

                var result;
                var outcome2 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome2.length == 0) {

                    return;
                }

                var selectedItem = outcome2[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 9;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].RatingComments;
                }

                return result;
            },
            set: function (value) {

                var outcome2 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome2.length == 0) {

                    return;
                }

                var selectedItem = outcome2[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 9;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].RatingComments = value;

                this.data.item8RatingComments = value;
            }
        },
        item9RatingComments: {

            get: function () {

                var result;
                var outcome2 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome2.length == 0) {

                    return;
                }

                var selectedItem = outcome2[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 10;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].RatingComments;
                }

                return result;
            },
            set: function (value) {

                var outcome2 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome2.length == 0) {

                    return;
                }

                var selectedItem = outcome2[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 10;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].RatingComments = value;

                this.data.item9RatingComments = value;
            }
        },
        item10RatingComments: {

            get: function () {

                var result;
                var outcome2 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome2.length == 0) {

                    return;
                }

                var selectedItem = outcome2[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 11;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].RatingComments;
                }

                return result;
            },
            set: function (value) {

                var outcome2 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome2.length == 0) {

                    return;
                }

                var selectedItem = outcome2[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 11;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].RatingComments = value;

                this.data.item10RatingComments = value;
            }
        },
        item11RatingComments: {

            get: function () {

                var result;
                var outcome2 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome2.length == 0) {

                    return;
                }

                var selectedItem = outcome2[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 12;
                });

                if (selectedItem.length > 0) {

                    result = selectedItem[0].RatingComments;
                }

                return result;
            },
            set: function (value) {

                var outcome2 = this.data.itemApplicability.data.items.filter(function (outcome) {

                    return outcome.data.OutcomeCode == 4;
                });

                if (outcome2.length == 0) {

                    return;
                }

                var selectedItem = outcome2[0].data.CR_Item_Collection.filter(function (item) {

                    return item.ItemCode == 12;
                });

                if (selectedItem.length == 0) {

                    return;
                }

                selectedItem[0].RatingComments = value;

                this.data.item11RatingComments = value;
            }
        }
    }
});