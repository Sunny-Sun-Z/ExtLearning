﻿//
// Item 4
//
Ext.define('app.CaseReview.view.permanency.Item4', {
    extend: 'Ext.container.Container',
    alias: 'widget.item4',
    itemId: 'item4Panel',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    border: true,
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'component',
            itemId: 'item4',
            html: 'Item 4: Stability of Foster Care Placement',
            margin: '20 20 20 20',
            cls: 'outcome-item-header'
        },
        {
            xtype: 'validationMessage',
            itemId: 'msgItem4Panel',
            itemName: 'item4'
        },
        //***********************************************************
        // Placement Table
        //***********************************************************  
        {
            xtype: 'gridpanel',
            itemId: 'placementGrid',
            store: 'CR_Placement_CollectionStore',
            border: true,
            margin: '20 20 20 20',
            title: "<strong>A1.&nbsp&nbspPlacement Table</strong>",
            tools: [
            {
                xtype: 'button',
                text: 'Add',
                itemId: 'placementGridAddButton',
                icon: addButtonImage
            },
            {
                xtype: 'button',
                itemId: 'placementGridEditButton',
                text: 'Edit',
                icon: editButtonImage
            },
            {
                xtype: 'button',
                itemId: 'placementGridDeleteButton',
                text: 'Delete',
                icon: deleteButtonImage
            }
            ],
            plugins: [
                Ext.create('framework.grid.plugin.RowEditing',
                {
                    pluginId: 'programEditorPlugin',
                    clicksToEdit: 2,
                    errorSummary: false
                }),
                {
                    ptype: 'businessRulePlugin',
                    pluginId: 'placementTable',
                    rules: [
                        {
                            rType: 'ruleCheck',
                            fields: [
                                {
                                    eType: 'function',
                                    fieldName: 'NoItems',
                                    functionName: 'count',
                                    storeId: 'CR_Placement_CollectionStore',
                                    fieldValue: undefined,
                                    columns: [
                                        'Date', 'TypeCode', 'ChangeReasonCode'
                                    ]
                                }
                            ],
                            predicate: 'NoItems.fieldValue > 0'
                        }
                    ],
                    action: [
                        {
                            type: 'ruleCheck',
                            enable: true,
                            disable: false
                        }
                    ]
                }
            ],
            columns: [
                {
                    xtype: 'datecolumn',
                    text: 'Placement Date',
                    dataIndex: 'Date',
                    width: '20%',
                    renderer: Ext.util.Format.dateRenderer('m/d/Y')


                },
                {
                    text: 'Placement Type',
                    dataIndex: 'TypeCode',
                    width: '20%',
                    cellWrap: true,
                    renderer: function (value, p, record) {
                        var lookupStore = chainedStore('PlacementTypeStore');
                        var results = lookupStore.query('GroupID', value, false, false, true);
                        if (results.length > 0) {
                            if (results.getAt(0).data.DescriptionLarge == "Other") {

                                return results.getAt(0).data.DescriptionLarge + " - " + record.data.TypeOther;
                            }
                            return results.getAt(0).data.DescriptionLarge;
                        }
                        return '';
                    }
                },
                {
                    text: 'Reason for Change in Placement Setting',
                    dataIndex: 'ChangeReasonCode',
                    width: '60%',
                    cellWrap: true,
                    renderer: function (value, p, record) {
                        var lookupStore = chainedStore('PlacementChangeReasonStore');
                        var results = lookupStore.query('GroupID', value, false, false, true);
                        if (results.length > 0) {
                            if (results.getAt(0).data.DescriptionLarge == "Other (describe)") {

                                return results.getAt(0).data.DescriptionLarge + " - " + record.data.ChangeReasonOther;
                            }
                            return results.getAt(0).data.DescriptionLarge;
                        }
                        return '';
                    }

                }
            ],
            viewConfig: {
                listeners: {
                    refresh: function (dataview) {
                        Ext.each(dataview.panel.columns, function (column) {
                            column.autoSize();
                        });
                    }
                }
            }
        },
        //***********************************************************
        // Question 4A
        //***********************************************************                                              
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 4A Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency4ADef'
                }
            ]

        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 4A Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency4AIns'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>A. How many placement settings did the child experience during the period under review?</strong>'
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: true,
            layout: 'hbox',
            margin: '10 10 20 40',
            itemId: 'item4QuestionA',
            items: [
                {
                    xtype: 'numberfield',
                    hideTrigger: true,
                    keyNavEnabled: false,
                    mouseWheelEnabled: false,
                    allowDecimals: false,
                    itemId: 'question4A',
                    enableKeyEvents: true,
                    bind: '{numberOfPlacementSettings}'
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem4QuestionA',
                    itemName: 'item4'
                }
            ]
        },
        //***********************************************************
        // Question 4B
        //***********************************************************  
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 4B Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency4BIns'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: "<strong>B. Were all placement changes during the period under review planned by the agency in an effort to achieve the child's case goals or to meet the needs of the child?</strong>"
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '20 20 20 40',
            itemId: 'item4QuestionB',
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'item4BYes',
                    inputValue: 1,
                    name: 'AllPlacementChangesPlanned',
                    bind: '{wereAllPlacementChangesPlanned}'
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    itemId: 'item4BNo',
                    inputValue: 2,
                    name: 'AllPlacementChangesPlanned',
                    bind: '{wereAllPlacementChangesPlanned}'
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>NA</b>',
                    itemId: 'item4BNA',
                    inputValue: 3,
                    name: 'AllPlacementChangesPlanned',
                    bind: '{wereAllPlacementChangesPlanned}'
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem4QuestionB',
                    itemName: 'item4'
                }
            ]
        },
        //***********************************************************
        // Question 4C1
        //***********************************************************  
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: true,
            layout: 'vbox',
            itemId: 'item4C1Question',
            items: [
                {
                    xtype: 'component',
                    bodyCls: 'panel-background-color',
                    border: false,
                    margin: '15 0 5 15',
                    html: "<strong>C1. Indicate whether any of the circumstances below apply to the child's current placement. Select all that apply:</strong>"
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem4C1Question'
                },
            ]
        },
        {
            xtype: 'boundcheckboxgroup',
            columns: 1,
            vertical: true,
            multiAnswerGroup: 'PlacementApplicableCircumstances',
            store: 'CR_MultiAnswer_CollectionStore',
            inputField: 'CodeDescriptionID',
            itemId: 'item4C1Group',
            items: [
                {
                    margin: '0 0 0 10',
                    boxLabel: 'None apply, placement is stable',
                    itemId: 'item4C11',
                    inputValue: 121
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'checkbox',
                    boxLabel: "The child's current placement is in a temporary shelter or other temporary setting.",
                    itemId: 'item4C12',
                    inputValue: 122
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'checkbox',
                    boxLabel: "There is information indicating that the child's current substitute care provider may not be able to continue to care for the child.",
                    itemId: 'item4C13',
                    inputValue: 123
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'checkbox',
                    boxLabel: "There are problems in the current placement threatening its stability that the agency is not addressing.",
                    itemId: 'item4C14',
                    inputValue: 124
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'checkbox',
                    boxLabel: "The child has run away from this placement more than once in the past, or is in runaway status at the time of the review.",
                    itemId: 'item4C15',
                    inputValue: 125
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'checkbox',
                    boxLabel: "Other (describe reasons why the current placement is not stable):",
                    itemId: 'item4C16',
                    inputValue: 126
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '0 10 0 20',
            itemId: 'item4C1Placement',
            items: [
                {
                    xtype: 'textarea',
                    bind: '{placementApplicableCircumstancesOther}',
                    enableKeyEvents: true,
                    itemId: 'item4C1placeApplicableCircumstancesOther',
                    disabled: true,
                    //height: 100,  This does work with grow: true
                    //growMin: 100,
                    //growMax: 350,
                    //grow: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem4C1Placement',
                    itemName: 'item4'
                }
            ]
        },
        //***********************************************************
        // Question 4C
        //***********************************************************  
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 4C Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency4CIns'
                }
            ]

        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: "<strong>C. Is the child's current placement setting (or most recent placement if the child is no longer in foster care) stable?</strong>"
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            layout: 'hbox',
            margin: '0 0 0 40',
            itemId: 'item4CPlacementSetting',
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'item4CYes',
                    inputValue: 1,
                    name: 'CurrentPlacementSettingStable',
                    bind: '{isCurrentPlacementSettingStable}'
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    itemId: 'item4CNo',
                    inputValue: 2,
                    name: 'CurrentPlacementSettingStable',
                    bind: '{isCurrentPlacementSettingStable}'
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem4CPlacementSetting',
                    itemName: 'item4'
                }
            ]

        },
        //***********************************************************
        // Item 4 Rating
        //***********************************************************
        {
            xtype: 'container',
            cls: 'panel-background-color',
            margin: '0 0 20 0',
            itemId: 'item4Rating',
            border: true,
            items:
            [
                {
                    xtype: 'listPanel',
                    title: "<div class='html-content-header-margins'>Item 4 Rating Criteria: [SHOW]</div>",
                    margin: '20 20 20 20',
                    padding: '0 0 0 0',
                    items: [
                        {
                            contentEl: 'permanency4RatingCriteria'
                        }
                    ]
                },
                {
                    xtype: 'component',
                    border: false,
                    margin: '20 0 10 20',
                    cls: 'panel-background-color',
                    html: '<strong>Item Rating:</strong>'
                },
                {
                    xtype: 'container',
                    border: false,
                    margin: '10 10 20 0',
                    layout: 'hbox',
                    itemId: 'item4RatingContainer',
                    items: [
                        {
                            xtype: 'itemRating',
                            itemId: 'permanencyItem4Rating',
                            itemCode: 5,
                            page: 'Permanency',
                            itemName: 'item4',
                            itemType: 'item',
                            outcomeCode: 3,
                            msgComponentId: 'msgItem4Rating',
                            ratingContainerId: 'item4RatingContainer'
                        },
                        {
                            xtype: 'validationMessage',
                            itemId: 'msgItem4Rating',
                            itemName: 'item4'
                        }
                    ]
                },
                {
                    xtype: 'component',
                    cls: 'panel-background-color',
                    border: false,
                    margin: '20 0 0 20',
                    html: 'Provide any additional comments that highlight strengths or challenges related to specific practices, systemic issues, or resources that affected this item in the narrative field below: '
                },
                {
                    xtype: 'container',
                    cls: 'panel-background-color',
                    border: false,
                    margin: '10 10 20 20',
                    items: [
                        {
                            xtype: 'textarea',
                            maxLength: 10000,
                            enforceMaxLength: true,
                            enableKeyEvents: true,
                            itemId: 'item4RatingComment',
                            bind: '{item4RatingComments}',
                            //height: 100,  This does work with grow: true
                            //growMin: 100,
                            //growMax: 350,
                            //grow: true,
                            width: '75%',
                            enforceMaxLength: true,
                            height: 150
                        }
                    ]
                },
                {
                    xtype: 'ratingOverride',
                    border: false,
                    margin: '20 0 10 20',
                    page: 'permanency',
                    itemNo: '4',
                    itemCode: 5,
                    outcomeCode: 3,
                    itemId: 'permanencyItem4RatingOverride',
                    ratingComponentId: 'permanencyItem4Rating',
                    outcomeRatingComponentId: 'permanencyOutcome1Rating'
                }
            ]
        },
        //***********************************************************
        // Question 4 QA Notes
        //***********************************************************                                              
        {
            xtype: 'qaNotes',
            itemId: 'permanencyItem4Notes',
            notesTitle: 'Item 4 - QA Notes',
            margin: '0 20 0 0',
            itemCode: 5,
            outcomeCode: 3
        }
    ]
});
//
// Question 7A
//
Ext.define('app.CaseReview.view.permanency.Question7A', {
    extend: 'Ext.container.Container',
    alias: 'widget.question7A',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'item7APanel',
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 7A Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency7ADef'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 7A Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency7AIns'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: "<strong>A.  During the entire period under review, was the child placed with all siblings who also were in foster care?</strong>"
        },
        {
            xtype: 'container',
            itemId: 'item7A',
            cls: 'panel-background-color',
            border: true,
            layout: 'vbox',
            margin: '10 10 20 40',
            items: [
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 20 0',
                    itemId: 'item7AGrp',
                    items: [
                        {
                            xtype: 'radio',
                            boxLabel: '<b>Yes</b>',
                            itemId: 'question7AYes',
                            inputValue: 1,
                            name: 'PlacedWithAllSiblings',
                            bind: '{isPlacedWithAllSiblings}'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>No</b>',
                            itemId: 'question7ANo',
                            inputValue: 2,
                            name: 'PlacedWithAllSiblings',
                            bind: '{isPlacedWithAllSiblings}'
                        }
                    ]
                }
            ]
        }
    ]
});
//
// Question 7B
//
Ext.define('app.CaseReview.view.permanency.Question7B', {
    extend: 'Ext.container.Container',
    alias: 'widget.question7B',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'item7BPanel',
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 7B Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency7BIns'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: "<strong>B.  If the answer to question A is No, was there a valid reason for the child’s separation from the siblings?</strong>"
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: true,
            layout: 'vbox',
            margin: '10 10 20 40',
            items: [
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 20 0',
                    itemId: 'item7BQuestion',
                    items: [
                        {
                            xtype: 'radio',
                            boxLabel: '<b>Yes</b>',
                            itemId: 'question7BYes',
                            inputValue: 1,
                            name: 'IsValidReasonSeparation',
                            bind: '{isValidReasonForSeparation}'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>No</b>',
                            itemId: 'question7BNo',
                            inputValue: 2,
                            name: 'IsValidReasonSeparation',
                            bind: '{isValidReasonForSeparation}'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>NA</b>',
                            itemId: 'question7BNA',
                            inputValue: 3,
                            name: 'IsValidReasonSeparation',
                            bind: '{isValidReasonForSeparation}'
                        },
                        {
                            xtype: 'validationMessage',
                            itemId: 'msgItem7BQuestion',
                            itemName: 'item7'
                        }
                    ]
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '-30 0 20 40',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 0',
                    cls: 'panel-background-color',
                    html: 'If No, explain any concerns in the narrative field below.'
                },
                {
                    xtype: 'textarea',
                    itemId: 'item7BConcerns',
                    bind: '{validReasonForSeparationExplained}',
                    enableKeyEvents: true,
                    disabled: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                }
            ]
        }
    ]
});
//
// Item 8 Preapplicability questions
//
Ext.define('app.CaseReview.view.permanency.Item8Preapp', {
    extend: 'Ext.container.Container',
    alias: 'widget.item8Preapp',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'item8Panel',
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
    {
        xtype: 'component',
        itemId: 'item8',
        border: false,
        margin: '20 0 0 20',
        html: '<strong>Item 8:</strong> Visiting With Parents and Siblings in Foster Care',
        cls: 'outcome-item-header'
    },
    {
        xtype: 'listPanel',
        title: "<div class='html-content-header-margins'>Purpose of Assessment: [SHOW]</div>",
        margin: '20 20 20 20',
        padding: '0 0 0 0',
        items: [
            {
                contentEl: 'permanency8Purpose'
            }
        ]
    },
    {
        xtype: 'listPanel',
        title: "<div class='html-content-header-margins'>Item 8 Definitions: [SHOW]</div>",
        margin: '20 20 20 20',
        padding: '0 0 0 0',
        items: [
            {
                contentEl: 'permanency8Def'
            }
        ]
    },
    {
        xtype: 'container',
        cls: 'panel-background-color',
        border: false,
        margin: '0 0 20 20',
        items: [
            {
                xtype: 'container',
                cls: 'panel-background-color',
                itemId: 'item8PreApplicableCases',
                border: false,
                layout: 'hbox',
                items: [
                    {
                        xtype: 'component',
                        border: false,
                        margin: '20 0 0 20',
                        cls: 'panel-background-color',
                        html: '<strong>Item 8 Applicable Cases:</strong>'
                    },
                    {
                        xtype: 'validationMessage',
                        itemId: 'msgItem8PreApplicableCases',
                        itemName: 'item8'
                    }
                ]
            },
            {
                xtype: 'component',
                padding: 0,
                border: false,
                html: "<ul><li> The child has at least one sibling in foster care who is in a different placement setting.</li>" +
                        "</ul>"
            },
            {
                xtype: 'radiogroup',
                bodyCls: 'panel-background-color',
                border: false,
                layout: 'hbox',
                margin: '0 0 0 100',
                inputField: 'CodeDescriptionID',
                codeDescValue: 57,
                itemId: 'item8Question1',
                defaults: {
                    bind: '{answerCode57}'
                },
                items: [
                    {
                        name: 'item8Applicability1',
                        itemId: 'item8Applicability1Yes',
                        boxLabel: '<b>Yes</b>',
                        inputValue: 1

                    },
                    {
                        margin: '0 0 0 10',
                        name: 'item8Applicability1',
                        itemId: 'item8Applicability1No',
                        boxLabel: '<b>No</b>',
                        inputValue: 2
                    }
                ]
            },
            {
                xtype: 'container',
                cls: 'panel-background-color',
                border: false,
                items: [
                    {
                        xtype: 'component',
                        margin: '0 0 0 0',
                        padding: 0,
                        border: false,
                        html: "<ul><li> Cases are Not Applicable for assessment if the child has no siblings placed separately in foster care, AND any of the following apply (check Yes for any that apply and No for any that do not apply):</li>" +
                                "</ul>"
                    },
                    {
                        xtype: 'component',
                        margin: '0 0 0 20',
                        padding: 0,
                        border: false,
                        html: "<ul><li> There is documentation in the case file indicating that contact between the child and both of his or her parents is not in the child’s best interests.</li>" +
                                "</ul>"
                    },
                    {
                        xtype: 'radiogroup',
                        bodyCls: 'panel-background-color',
                        border: false,
                        layout: 'hbox',
                        margin: '0 0 0 100',
                        inputField: 'CodeDescriptionID',
                        codeDescValue: 58,
                        itemId: 'item8Question2',
                        defaults: {
                            bind: '{answerCode58}'
                        },
                        items: [
                            {
                                name: 'item8Applicability2',
                                itemId: 'item8Applicability2Yes',
                                boxLabel: '<b>Yes</b>',
                                inputValue: 1
                            },
                            {
                                margin: '0 0 0 10',
                                name: 'item8Applicability2',
                                itemId: 'item8Applicability2No',
                                boxLabel: '<b>No</b>',
                                inputValue: 2
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        margin: '0 0 0 20',
                        padding: 0,
                        border: false,
                        html: "<ul><li> The whereabouts of both parents are unknown despite documented concerted agency efforts to locate the parents.</li>" +
                                "</ul>"
                    },
                    {
                        xtype: 'radiogroup',
                        bodyCls: 'panel-background-color',
                        border: false,
                        layout: 'hbox',
                        margin: '0 0 0 100',
                        inputField: 'CodeDescriptionID',
                        codeDescValue: 59,
                        itemId: 'item8Question3',
                        defaults: {
                            bind: '{answerCode59}'
                        },
                        items: [
                            {
                                name: 'item8Applicability3',
                                itemId: 'item8Applicability3Yes',
                                boxLabel: '<b>Yes</b>',
                                inputValue: 1

                            },
                            {
                                margin: '0 0 0 10',
                                name: 'item8Applicability3',
                                itemId: 'item8Applicability3No',
                                boxLabel: '<b>No</b>',
                                inputValue: 2
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        margin: '0 0 0 20',
                        padding: 0,
                        border: false,
                        html: "<ul><li> Both parents were deceased during the entire period under review.</li>" +
                                "</ul>"
                    },
                    {
                        xtype: 'radiogroup',
                        bodyCls: 'panel-background-color',
                        border: false,
                        layout: 'hbox',
                        margin: '0 0 0 100',
                        inputField: 'CodeDescriptionID',
                        codeDescValue: 60,
                        itemId: 'item8Question4',
                        defaults: {
                            bind: '{answerCode60}'
                        },
                        items: [
                            {
                                name: 'item8Applicability4',
                                itemId: 'item8Applicability4Yes',
                                boxLabel: '<b>Yes</b>',
                                inputValue: 1

                            },
                            {
                                margin: '0 0 0 10',
                                name: 'item8Applicability4',
                                itemId: 'item8Applicability4No',
                                boxLabel: '<b>No</b>',
                                inputValue: 2
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        margin: '0 0 0 20',
                        padding: 0,
                        border: false,
                        html: "<ul><li> The parental rights of both parents remained terminated during the entire period under review.</li>" +
                                "</ul>"
                    },
                    {
                        xtype: 'radiogroup',
                        bodyCls: 'panel-background-color',
                        border: false,
                        layout: 'hbox',
                        margin: '0 0 0 100',
                        inputField: 'CodeDescriptionID',
                        codeDescValue: 61,
                        itemId: 'item8Question5',
                        defaults: {
                            bind: '{answerCode61}'
                        },
                        items: [
                            {
                                name: 'item8Applicability5',
                                itemId: 'item8Applicability5Yes',
                                boxLabel: '<b>Yes</b>',
                                inputValue: 1
                            },
                            {
                                margin: '0 0 0 10',
                                name: 'item8Applicability5',
                                itemId: 'item8Applicability5No',
                                boxLabel: '<b>No</b>',
                                inputValue: 2
                            }
                        ]
                    },
                    {
                        xtype: 'component',
                        margin: '0 0 0 20',
                        padding: 0,
                        border: false,
                        html: "<ul><li> The only parent(s) being assessed in this item do not meet the definition of Mother/Father for this item.</li>" +
                                "</ul>"
                    },
                    {
                        xtype: 'radiogroup',
                        bodyCls: 'panel-background-color',
                        border: false,
                        layout: 'hbox',
                        margin: '0 0 0 100',
                        inputField: 'CodeDescriptionID',
                        codeDescValue: 62,
                        itemId: 'item8Question6',
                        defaults: {
                            bind: '{answerCode62}'
                        },
                        items: [
                            {
                                name: 'item8Applicability6',
                                itemId: 'item8Applicability6Yes',
                                boxLabel: '<b>Yes</b>',
                                inputValue: 1

                            },
                            {
                                margin: '0 0 0 10',
                                name: 'item8Applicability6',
                                itemId: 'item8Applicability6No',
                                boxLabel: '<b>No</b>',
                                inputValue: 2
                            }
                        ]
                    }
                ]
            }
        ]
    },
    {
        xtype: 'component',
        border: false,
        margin: '10 0 0 20',
        cls: 'outcome-item-header',
        html: '<strong>Is this case applicable?</strong>'
    },
    {
        xtype: 'component',
        border: false,
        margin: '10 0 0 20',
        cls: 'panel-background-color',
        html: 'Select the appropriate response. If the response is No, the case will be rated as Not Applicable in the ratings section for this item.'
    },
       {
           xtype: 'itemApplicable',
           store: 'CR_Outcome_CollectionStore',
           bodyCls: 'panel-background-color',
           border: false,
           OutcomeCode: 4,
           ItemCode: 9,
           items: [
               {
                   xtype: 'radiogroup',
                   itemId: 'applicabilityQuestion8',
                   bodyCls: 'panel-background-color',
                   border: false,
                   layout: 'hbox',
                   margin: '0 0 20 40',
                   items: [
                       {
                           xtype: 'radio',
                           itemId: 'applicabilityQuestion8Yes',
                           boxLabel: '<b>Yes</b>',
                           inputValue: 1,
                           name: 'applicableItem8',
                           bind: '{item8Applicable}'
                       },
                       {
                           margin: '0 0 0 10',
                           xtype: 'radio',
                           boxLabel: '<b>No</b>',
                           itemId: 'applicabilityQuestion8No',
                           inputValue: 2,
                           name: 'applicableItem8',
                           bind: '{item8Applicable}'
                       },
                       {
                           xtype: 'validationMessage',
                           itemId: 'msgItem8Applicability',
                           orientation: 'wide',
                           itemName: 'item8'
                       }
                   ]
               },
               {
                   xtype: 'component',
                   border: false,
                   margin: '10 0 0 20',
                   bodyCls: 'panel-background-color',
                   html: 'Indicate the case participants who are included in this item as Mother and Father:'
               },
               {
                   xtype: 'container',
                   bodyCls: 'panel-background-color',
                   border: false,
                   layout: 'vbox',
                   margin: '0 0 20 40',
                   itemId: 'item8ParentCaseParticipant',
                   items: [
                       {
                           xtype: 'component',
                           border: false,
                           margin: '10 0 0 10',
                           bodyCls: 'panel-background-color',
                           html: 'Mother:'
                       },
                       {
                           xtype: 'checkboxgroup',
                           columns: 1,
                           vertical: true,
                           itemId: 'item8ParticipantCheckboxGroupMother',
                           listeners: {
                               'afterrender': function () {

                                   var checkboxgroup = this;
                                   var checkboxgroupStore = GetItemParticipant(1);
                                   var checkbox = null;
                                   var participantId, participantName;
                                   var dataParms = { itemCode: 9, outcomeCode: 4 };

                                   for (var iCheckboxCount = 0; iCheckboxCount < checkboxgroupStore.count() ; iCheckboxCount++) {

                                       //participantId = checkboxgroupStore.getAt(iCheckboxCount).data.CaseParticipantID;
                                       participantName = checkboxgroupStore.getAt(iCheckboxCount).data.Name;
                                       participantId = participants[participantName].ParticipantID;

                                       dataParms['participantId'] = participantId;
                                       dataParms['participantName'] = participantName;
                                       dataParms['codeDescriptionId'] = 269;

                                       checkbox = new Ext.form.Checkbox({
                                           boxLabel: checkboxgroupStore.getAt(iCheckboxCount).data.Name,
                                           //inputValue: checkboxgroupStore.getAt(iCheckboxCount).data.CaseParticipantID,
                                           inputValue: participantId,
                                           itemId: 'checkbox8Mother' + participantId,
                                           //checked: isParticipantSelected(participantId),
                                           checked: isItemParticipantSelected(dataParms),
                                           listeners: {
                                               'change': function (cmp, newValue, oldValue, eOpts) {

                                                   var selectedItem = getSelectedItem(newValue, oldValue);

                                                   if (Ext.isObject(selectedItem)) {

                                                       var newKeys = getObjectKeys(selectedItem);

                                                       if (newKeys.length > 0) {

                                                           var parms = { currentVal: newValue };
                                                           var selection = (newValue) ? cmp.inputValue : 0;

                                                           var fields = [];
                                                           var field = { 'ParticipantID': selection };
                                                           fields.push(field);

                                                           field = { 'CodeDescriptionID': 269 };

                                                           field = { 'DataState': 0 };
                                                           fields.push(field);

                                                           parms['storeId'] = 'CR_ItemParticipant_CollectionStore';
                                                           parms['fields'] = fields;

                                                           parms = getStatusParms(parms, 'permanencyItem8Rating');
                                                           parms['runValidations'] = true;
                                                           parms['dataChanged'] = true;

                                                           initValidations('Item8');

                                                           runPermanencyRules(getAppController(), 'item8ParticipantCheckboxGroupMother', parms);
                                                       }
                                                   }
                                               }
                                           }
                                       });
                                       checkboxgroup.items.add(checkbox);
                                   }
                               }
                           }
                       },
                         {
                             xtype: 'validationMessage',
                             itemId: 'msgItem8MotherCaseParticipant',
                             itemName: 'item8'
                         },
                       {
                           xtype: 'component',
                           border: false,
                           margin: '10 0 0 10',
                           bodyCls: 'panel-background-color',
                           html: 'Father:'
                       },
                       {
                           xtype: 'checkboxgroup',
                           columns: 1,
                           vertical: true,
                           itemId: 'item8ParticipantCheckboxGroupFather',
                           listeners: {
                               'afterrender': function () {

                                   var checkboxgroup = this;
                                   var checkboxgroupStore = GetItemParticipant(2);
                                   var checkbox = null;
                                   var participantId, participantName;
                                   var dataParms = { itemCode: 9, outcomeCode: 4 };

                                   for (var iCheckboxCount = 0; iCheckboxCount < checkboxgroupStore.count() ; iCheckboxCount++) {

                                       //participantId = checkboxgroupStore.getAt(iCheckboxCount).data.CaseParticipantID;
                                       participantName = checkboxgroupStore.getAt(iCheckboxCount).data.Name;
                                       participantId = participants[participantName].ParticipantID;

                                       dataParms['participantId'] = participantId;
                                       dataParms['participantName'] = participantName;
                                       dataParms['codeDescriptionId'] = 270;

                                       checkbox = new Ext.form.Checkbox({
                                           boxLabel: checkboxgroupStore.getAt(iCheckboxCount).data.Name,
                                           //inputValue: checkboxgroupStore.getAt(iCheckboxCount).data.CaseParticipantID,
                                           inputValue: participantId,
                                           itemId: 'checkbox8Father' + participantId,
                                           width: 200,
                                           //checked: isParticipantSelected(participantId),
                                           checked: isItemParticipantSelected(dataParms),
                                           listeners: {
                                               'change': function (cmp, newValue, oldValue, eOpts) {

                                                   var selectedItem = getSelectedItem(newValue, oldValue);
                                                   var newKeys = getObjectKeys(selectedItem);

                                                   if (newKeys.length > 0) {

                                                       var parms = { currentVal: newValue };
                                                       var selection = (newValue) ? cmp.inputValue : 0;

                                                       var fields = [];
                                                       var field = { 'ParticipantID': selection };
                                                       fields.push(field);

                                                       field = { 'CodeDescriptionID': 270 };
                                                       fields.push(field);

                                                       field = { 'DataState': 0 };
                                                       fields.push(field);

                                                       parms['storeId'] = 'CR_ItemParticipant_CollectionStore';
                                                       parms['fields'] = fields;

                                                       parms = getStatusParms(parms, 'permanencyItem8Rating');
                                                       parms['runValidations'] = true;
                                                       parms['dataChanged'] = true;

                                                       initValidations('Item8');

                                                       runPermanencyRules(getAppController(), 'item8ParticipantCheckboxGroupFather', parms);
                                                   }
                                               }
                                           }
                                       });
                                       checkboxgroup.items.add(checkbox);
                                   }
                               }
                           }
                       },
                         {
                             xtype: 'validationMessage',
                             itemId: 'msgItem8FatherCaseParticipant',
                             itemName: 'item8'
                         }
                   ]
               },
               {
                   xtype: 'container',
                   bodyCls: 'panel-background-color',
                   border: false,
                   //layout: 'vbox',
                   margin: '0 0 20 20',
                   items: [
                       {
                           xtype: 'component',
                           border: false,
                           margin: '10 0 0 0',
                           bodyCls: 'panel-background-color',
                           html: 'Optional: Provide comments in the narrative field below.'
                       },
                       {
                           xtype: 'textarea',
                           itemId: 'item8ApplicabilityComments',
                           bind: '{item8Comments}',
                           enableKeyEvents: true,
                           //height: 100,  This does work with grow: true
                           //growMin: 100,
                           //growMax: 350,
                           //grow: true,
                           width: '75%',
                           maxlength: 4100,
                           enforceMaxLength: true,
                           height: 150
                       }
                   ]
               }
           ]
       }
    ]
});
//
// Question 8A1
//
Ext.define('app.CaseReview.view.permanency.Question8A1', {
    extend: 'Ext.container.Container',
    alias: 'widget.question8A1',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    border: true,
    itemId: 'item8A1Panel',
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 8A1 Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency8A1Ins'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>A1. What was the usual frequency of visits between the mother and the child during the period under review? Select the box next to the statement that best describes the typical frequency of visits during the period under review.</strong>'
        },
        {
            xtype: 'container',
            border: false,
            cls: 'panel-background-color',
            margin: '20 20 20 35',
            itemId: 'item8A1',
            items: [
                    {
                        xtype: 'radio',
                        boxLabel: 'NA',
                        itemId: 'motherVisitFrequency1',
                        inputValue: 1,
                        bind: '{motherVisitationFrequencyCode}',
                        name: 'motherVisitationFrequency'
                    },
                    {
                        xtype: 'radio',
                        boxLabel: 'More than once a week',
                        itemId: 'motherVisitFrequency2',
                        inputValue: 2,
                        bind: '{motherVisitationFrequencyCode}',
                        name: 'motherVisitationFrequency'
                    },
                    {
                        xtype: 'radio',
                        boxLabel: 'Once a week',
                        itemId: 'motherVisitFrequency3',
                        inputValue: 3,
                        bind: '{motherVisitationFrequencyCode}',
                        name: 'motherVisitationFrequency'
                    },
                    {
                        xtype: 'radio',
                        boxLabel: 'Less than once a week, but at least twice a month',
                        itemId: 'motherVisitFrequency4',
                        inputValue: 4,
                        bind: '{motherVisitationFrequencyCode}',
                        name: 'motherVisitationFrequency'
                    },
                    {
                        xtype: 'radio',
                        boxLabel: 'Less than twice a month, but at least once a month',
                        itemId: 'motherVisitFrequency5',
                        inputValue: 5,
                        bind: '{motherVisitationFrequencyCode}',
                        name: 'motherVisitationFrequency'
                    },
                    {
                        xtype: 'radio',
                        boxLabel: 'Less than once a month',
                        itemId: 'motherVisitFrequency6',
                        inputValue: 6,
                        bind: '{motherVisitationFrequencyCode}',
                        name: 'motherVisitationFrequency'
                    },
                    {
                        xtype: 'radio',
                        boxLabel: 'Never',
                        itemId: 'motherVisitFrequency7',
                        inputValue: 7,
                        bind: '{motherVisitationFrequencyCode}',
                        name: 'motherVisitationFrequency'
                    }
            ]
        }
    ]
});
//
// Question 8A
//
Ext.define('app.CaseReview.view.permanency.Question8A', {
    extend: 'Ext.container.Container',
    alias: 'widget.question8A',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    border: true,
    itemId: 'item8APanel',
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 8A Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency8AIns'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>A. During the period under review, were concerted efforts made to ensure that visitation (or other forms of contact if visitation was not possible) between the child and his or her mother was of sufficient frequency to maintain or promote the continuity of the relationship?</strong>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '10 10 20 20',
            layout: 'hbox',
            itemId: 'item8AQuestion',
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'question8AYes',
                    name: 'IsSufficientFrequencyMotherVisitation',
                    bind: '{isSufficientFrequencyForMotherVisitation}',
                    inputValue: 1
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    itemId: 'question8ANo',
                    name: 'IsSufficientFrequencyMotherVisitation',
                    bind: '{isSufficientFrequencyForMotherVisitation}',
                    inputValue: 2
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>NA</b>',
                    itemId: 'question8ANA',
                    name: 'IsSufficientFrequencyMotherVisitation',
                    bind: '{isSufficientFrequencyForMotherVisitation}',
                    inputValue: 3
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem8AQuestion',
                    itemName: 'item8'
                }
            ]
        }
    ]
});
//
// Question 8C
//
Ext.define('app.CaseReview.view.permanency.Question8C', {
    extend: 'Ext.container.Container',
    alias: 'widget.question8C',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    border: true,
    itemId: 'item8CPanel',
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 8C Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency8CIns'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>C. During the period under review, were concerted efforts made to ensure that the quality of visitation between the child and the mother was sufficient to maintain or promote the continuity of the relationship?</strong>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '10 10 20 20',
            layout: 'hbox',
            itemId: 'item8CQuestion',
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'question8CYes',
                    name: 'IsSufficientQualityMotherVisitation',
                    bind: '{isSufficientQualityForMotherVisitation}',
                    inputValue: 1
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    itemId: 'question8CNo',
                    name: 'IsSufficientQualityMotherVisitation',
                    bind: '{isSufficientQualityForMotherVisitation}',
                    inputValue: 2
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>NA</b>',
                    itemId: 'question8CNA',
                    name: 'IsSufficientQualityMotherVisitation',
                    bind: '{isSufficientQualityForMotherVisitation}',
                    inputValue: 3
                }
            ]
        },
        {
            xtype: 'validationMessage',
            itemId: 'msgItem8CQuestion',
            itemName: 'item8'
        }
    ]
});
//
// Question 8B1
//
Ext.define('app.CaseReview.view.permanency.Question8B1', {
    extend: 'Ext.container.Container',
    alias: 'widget.question8B1',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    border: true,
    itemId: 'item8B1Panel',
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 8B1 Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency8B1Ins'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>B1. What was the usual frequency of visits between the father and the child during the period under review? Select the box next to the statement that best describes the typical frequency of visits during the period under review.</strong>'
        },
        {
            xtype: 'container',
            itemId: 'item8B1',
            border: false,
            cls: 'panel-background-color',
            margin: '20 20 20 35',
            items: [

                    {
                        xtype: 'radio',
                        bind: '{fatherVisitationFrequencyCode}',
                        name: 'fatherVisitationFrequency',
                        boxLabel: 'NA',
                        itemId: 'fatherVisitFrequency1',
                        inputValue: 1
                    },
                    {
                        xtype: 'radio',
                        bind: '{fatherVisitationFrequencyCode}',
                        name: 'fatherVisitationFrequency',
                        boxLabel: 'More than once a week',
                        itemId: 'fatherVisitFrequency2',
                        inputValue: 2
                    },
                    {
                        xtype: 'radio',
                        bind: '{fatherVisitationFrequencyCode}',
                        name: 'fatherVisitationFrequency',
                        boxLabel: 'Once a week',
                        itemId: 'fatherVisitFrequency3',
                        inputValue: 3
                    },
                    {
                        xtype: 'radio',
                        bind: '{fatherVisitationFrequencyCode}',
                        name: 'fatherVisitationFrequency',
                        boxLabel: 'Less than once a week, but at least twice a month',
                        itemId: 'fatherVisitFrequency4',
                        inputValue: 4
                    },
                    {
                        xtype: 'radio',
                        bind: '{fatherVisitationFrequencyCode}',
                        name: 'fatherVisitationFrequency',
                        boxLabel: 'Less than twice a month, but at least once a month',
                        itemId: 'fatherVisitFrequency5',
                        inputValue: 5
                    },
                    {
                        xtype: 'radio',
                        bind: '{fatherVisitationFrequencyCode}',
                        name: 'fatherVisitationFrequency',
                        boxLabel: 'Less than once a month',
                        itemId: 'fatherVisitFrequency6',
                        inputValue: 6
                    },
                    {
                        xtype: 'radio',
                        bind: '{fatherVisitationFrequencyCode}',
                        name: 'fatherVisitationFrequency',
                        boxLabel: 'Never',
                        itemId: 'fatherVisitFrequency7',
                        inputValue: 7
                    }

            ]
        }
    ]
});
//
// Question 8B
//
Ext.define('app.CaseReview.view.permanency.Question8B', {
    extend: 'Ext.container.Container',
    alias: 'widget.question8B',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    border: true,
    itemId: 'item8BPanel',
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 8B Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency8BIns'
                }
                //{
                //    html: "<div class='html-content-item-margins'><ul>" +
                //          "<li>If B1 is NA, question B is answered Not Applicable.</li>" +
                //          "<li>Determine whether the frequency of visitation during the period under review was sufficient to maintain the continuity of the relationship between the child and the mother or father, depending on the circumstances of the case. For example, frequency may need to be greater for infants and young children who are still forming attachments. Frequency also may need to be greater if reunification is imminent. Visitation should be as frequent as possible, unless safety concerns cannot be appropriately managed with supervision. The opportunity for visitation should not be used as a consequence or reward for parents or for children.</li>" +
                //          "<li>If, during the period under review, frequent visitation with the mother or father was not possible (for example, due to incarceration in a facility where visitation is not feasible, or if the parent lives in another state), determine whether there are documented concerted efforts to promote other forms of contact between the child and the mother or father, such as telephone calls or letters, in addition to facilitating visits when possible and appropriate.</li>" +
                //          "<li>Address the question of appropriate frequency based on the circumstances of the child and the family, rather than on state policy.</li>" +
                //          "</ul></div>"
                //}
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>B. During the period under review, were concerted efforts made to ensure that visitation (or other forms of contact if visitation was not possible) between the child and his or her father was of sufficient frequency to maintain or promote the continuity of the relationship?</strong>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '10 10 20 20',
            layout: 'hbox',
            itemId: 'item8BQuestion',
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'question8BYes',
                    name: 'IsSufficientFrequencyFatherVisit',
                    bind: '{isSufficientFrequencyForFatherVisitation}',
                    inputValue: 1
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    itemId: 'question8BNo',
                    name: 'IsSufficientFrequencyFatherVisit',
                    bind: '{isSufficientFrequencyForFatherVisitation}',
                    inputValue: 2
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>NA</b>',
                    itemId: 'question8BNA',
                    name: 'IsSufficientFrequencyFatherVisit',
                    bind: '{isSufficientFrequencyForFatherVisitation}',
                    inputValue: 3
                }
            ]
        },
        {
            xtype: 'validationMessage',
            itemId: 'msgItem8BQuestion',
            itemName: 'item8'
        }
    ]
});
//
// Question 8D
//
Ext.define('app.CaseReview.view.permanency.Question8D', {
    extend: 'Ext.container.Container',
    alias: 'widget.question8D',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    border: true,
    itemId: 'item8DPanel',
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 8D Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency8DIns'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>D. During the period under review, were concerted efforts made to ensure that the quality of visitation between the child and the father was sufficient to maintain or promote the continuity of the relationship?</strong>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '10 10 20 20',
            layout: 'hbox',
            itemId: 'item8DQuestion',
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'question8DYes',
                    name: 'IsSufficentQualityFatherVisitation',
                    bind: '{isSufficentQualityForFatherVisitation}',
                    inputValue: 1
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    itemId: 'question8DNo',
                    name: 'IsSufficentQualityFatherVisitation',
                    bind: '{isSufficentQualityForFatherVisitation}',
                    inputValue: 2
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>NA</b>',
                    itemId: 'question8DNA',
                    name: 'IsSufficentQualityFatherVisitation',
                    bind: '{isSufficentQualityForFatherVisitation}',
                    inputValue: 3
                }
            ]
        },
        {
            xtype: 'validationMessage',
            itemId: 'msgItem8DQuestion',
            itemName: 'item8'
        }
    ]
});
//
// Question 8E1
//
Ext.define('app.CaseReview.view.permanency.Question8E1', {
    extend: 'Ext.container.Container',
    alias: 'widget.question8E1',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    border: true,
    itemId: 'item8E1Panel',
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 8E1 Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency8E1Ins'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>E1. What was the usual frequency of visits between the child and his or her siblings during the period under review? Select the box next to the statement that best describes the usual frequency of visits between the siblings and the child during the period under review.</strong>'
        },
        {
            xtype: 'container',
            border: false,
            bodyCls: 'panel-background-color',
            margin: '20 20 20 35',
            itemId: 'item8E1',
            items: [

                    {
                        xtype: 'radio',
                        bind: '{siblingVisitationFrequencyCode}',
                        name: 'siblingVisitationFrequency',
                        boxLabel: 'NA',
                        itemId: 'siblingVisitFrequency1',
                        inputValue: 1,
                        listeners: {
                            click: {
                                element: 'el',
                                fn: function () {

                                    appDataEvent.permanency.changeByUserAction = true;

                                    deselectPrevChoices(this.component);

                                    var input = {};

                                    input['Component'] = this.component;
                                    input['FieldName'] = 'SiblingVisitationFrequencyCode';
                                    input['ItemId'] = 'siblingVisitFrequency1';
                                    input['ItemName'] = 'Item8';
                                    input['RatingItemId'] = 'permanencyItem8Rating';

                                    processPermanencyClick(input);
                                }
                            }
                        }
                    },
                    {
                        xtype: 'radio',
                        bind: '{siblingVisitationFrequencyCode}',
                        name: 'siblingVisitationFrequency',
                        boxLabel: 'More than once a week',
                        itemId: 'siblingVisitFrequency2',
                        inputValue: 2
                    },
                    {
                        xtype: 'radio',
                        bind: '{siblingVisitationFrequencyCode}',
                        name: 'siblingVisitationFrequency',
                        boxLabel: 'Once a week',
                        itemId: 'siblingVisitFrequency3',
                        inputValue: 3
                    },
                    {
                        xtype: 'radio',
                        bind: '{siblingVisitationFrequencyCode}',
                        name: 'siblingVisitationFrequency',
                        boxLabel: 'Less than once a week, but at least twice a month',
                        itemId: 'siblingVisitFrequency4',
                        inputValue: 4
                    },
                    {
                        xtype: 'radio',
                        bind: '{siblingVisitationFrequencyCode}',
                        name: 'siblingVisitationFrequency',
                        boxLabel: 'Less than twice a month, but at least once a month',
                        itemId: 'siblingVisitFrequency5',
                        inputValue: 5
                    },
                    {
                        xtype: 'radio',
                        bind: '{siblingVisitationFrequencyCode}',
                        name: 'siblingVisitationFrequency',
                        boxLabel: 'Less than once a month',
                        itemId: 'siblingVisitFrequency6',
                        inputValue: 6
                    },
                    {
                        xtype: 'radio',
                        bind: '{siblingVisitationFrequencyCode}',
                        name: 'siblingVisitationFrequency',
                        boxLabel: 'Never',
                        itemId: 'siblingVisitFrequency7',
                        inputValue: 7
                    }
            ]
        }
    ]
});
//
// Question 8E
//
Ext.define('app.CaseReview.view.permanency.Question8E', {
    extend: 'Ext.container.Container',
    alias: 'widget.question8E',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    border: true,
    itemId: 'item8EPanel',
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 8E Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency8EIns'
                }                
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>E. During the period under review, were concerted efforts made to ensure that visitation between the child and his or her sibling(s) was of sufficient frequency to maintain or promote the continuity of the relationship?</strong>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '10 10 20 20',
            layout: 'hbox',
            itemId: 'item8EQuestion',
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'question8EYes',
                    name: 'IsSufficientFrequencySiblingVisitation',
                    bind: '{isSufficientFrequencyForSiblingVisitation}',
                    inputValue: 1
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    itemId: 'question8ENo',
                    name: 'IsSufficientFrequencySiblingVisitation',
                    bind: '{isSufficientFrequencyForSiblingVisitation}',
                    inputValue: 2
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>NA</b>',
                    itemId: 'question8ENA',
                    name: 'IsSufficientFrequencySiblingVisitation',
                    bind: '{isSufficientFrequencyForSiblingVisitation}',
                    inputValue: 3
                }
            ]
        },
        {
            xtype: 'validationMessage',
            itemId: 'msgItem8EQuestion',
            itemName: 'item8'
        }
    ]
});
//
// Question 8F
//
Ext.define('app.CaseReview.view.permanency.Question8F', {
    extend: 'Ext.container.Container',
    alias: 'widget.question8F',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    border: true,
    itemId: 'item8FPanel',
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 8F Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency8FIns'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>F. During the period under review, were concerted efforts made to ensure that the quality of visitation between the child and his or her sibling(s) was sufficient to promote the continuity of their relationships?</strong>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '10 10 20 20',
            layout: 'hbox',
            itemId: 'item8FQuestion',
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'question8FYes',
                    name: 'IsSufficentQualitySiblingVisitation',
                    bind: '{isSufficentQualityForSiblingVisitation}',
                    inputValue: 1
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    itemId: 'question8FNo',
                    name: 'IsSufficentQualitySiblingVisitation',
                    bind: '{isSufficentQualityForSiblingVisitation}',
                    inputValue: 2
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>NA</b>',
                    itemId: 'question8FNA',
                    name: 'IsSufficentQualitySiblingVisitation',
                    bind: '{isSufficentQualityForSiblingVisitation}',
                    inputValue: 3
                }
            ]
        },
        {
            xtype: 'validationMessage',
            itemId: 'msgItem8FQuestion',
            itemName: 'item8'
        }
    ]
});
//
// Question 9A
//
Ext.define('app.CaseReview.view.permanency.Question9A', {
    extend: 'Ext.container.Container',
    alias: 'widget.question9A',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    border: true,
    itemId: 'item9APanel',
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 9A Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency9AIns'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>A. During the period under review, were concerted efforts made to maintain the child’s important connections (for example, neighborhood, community, faith, language, extended family members including siblings who are not in foster care, Tribe, school, and/or friends)?</strong>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '10 10 20 20',
            layout: 'hbox',
            itemId: 'question9A',
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'question9AYes',
                    name: 'IsConcertedEffortsForConnections',
                    bind: '{isConcertedEffortsForImportantConnections}',
                    inputValue: 1
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    itemId: 'question9ANo',
                    name: 'IsConcertedEffortsForConnections',
                    bind: '{isConcertedEffortsForImportantConnections}',
                    inputValue: 2
                }
            ]
        }
    ]
});
//
// Question 9B
//
Ext.define('app.CaseReview.view.permanency.Question9B', {
    extend: 'Ext.container.Container',
    alias: 'widget.question9B',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    border: true,
    itemId: 'item9BPanel',
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 9B Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency9BIns'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>B. Was a sufficient inquiry conducted with the parent, child, custodian, or other interested party to determine whether the child may be a member of, or eligible for membership in, a federally recognized Indian Tribe?</strong>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '10 10 20 20',
            layout: 'hbox',
            itemId: 'question9B',
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'question9BYes',
                    name: 'IsSufficientInquiryForTribe',
                    bind: '{isSufficientInquiryForIndianTribe}',
                    inputValue: 1
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    itemId: 'question9BNo',
                    name: 'IsSufficientInquiryForTribe',
                    bind: '{isSufficientInquiryForIndianTribe}',
                    inputValue: 2
                }
            ]
        }
    ]
});
//
// Question 9C
//
Ext.define('app.CaseReview.view.permanency.Question9C', {
    extend: 'Ext.container.Container',
    alias: 'widget.question9C',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    border: true,
    itemId: 'item9CPanel',
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 9C Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency9CIns'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>C. If the child may be a member of, or eligible for membership in, a federally recognized Indian Tribe, during the period under review, was the Tribe provided timely notification of its right to intervene in any state court proceedings seeking an involuntary foster care placement or termination of parental rights?</strong>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '10 10 20 20',
            layout: 'hbox',
            itemId: 'question9C',
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'question9CYes',
                    name: 'IsTribeProvidedNotification',
                    bind: '{isTribeProvidedTimelyNotification}',
                    inputValue: 1
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    itemId: 'question9CNo',
                    name: 'IsTribeProvidedNotification',
                    bind: '{isTribeProvidedTimelyNotification}',
                    inputValue: 2
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>NA</b>',
                    itemId: 'question9CNA',
                    name: 'IsTribeProvidedNotification',
                    bind: '{isTribeProvidedTimelyNotification}',
                    inputValue: 3
                }
            ]
        }
    ]
});
//
// Question 9D
//
Ext.define('app.CaseReview.view.permanency.Question9D', {
    extend: 'Ext.container.Container',
    alias: 'widget.question9D',
    cls: 'panel-background-color',
    margin: '0 20 20 20',
    border: true,
    itemId: 'item9DPanel',
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 9D Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency9DIns'
                }
            ]
        },
        {
            xtype: 'component',
            cls: 'panel-background-color',
            border: false,
            margin: '15 0 0 20',
            html: '<strong>D. If the child is a member of, or eligible for membership in, a federally recognized Indian Tribe, was the child placed in foster care in accordance with Indian Child Welfare Act placement preferences or were concerted efforts made to place the child in accordance with the Act’s placement preferences?</strong>'
        },
        {
            xtype: 'radiogroup',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '10 10 20 20',
            layout: 'hbox',
            itemId: 'item9DQuestion',
            items: [
                {
                    xtype: 'radio',
                    boxLabel: '<b>Yes</b>',
                    itemId: 'question9DYes',
                    name: 'IsAccordanceWithChildWelfareAct',
                    bind: '{isAccordanceWithIndianChildWelfareAct}',
                    inputValue: 1
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>No</b>',
                    itemId: 'question9DNo',
                    name: 'IsAccordanceWithChildWelfareAct',
                    bind: '{isAccordanceWithIndianChildWelfareAct}',
                    inputValue: 2
                },
                {
                    margin: '0 0 0 10',
                    xtype: 'radio',
                    boxLabel: '<b>NA</b>',
                    itemId: 'question9DNA',
                    name: 'IsAccordanceWithChildWelfareAct',
                    bind: '{isAccordanceWithIndianChildWelfareAct}',
                    inputValue: 3
                }
            ]
        },
        {
            xtype: 'validationMessage',
            itemId: 'msgItem9DQuestion',
            itemName: 'item9'
        }
    ]
});
//
// Question 10A1
//
Ext.define('app.CaseReview.view.permanency.Question10A1', {
    extend: 'Ext.container.Container',
    alias: 'widget.question10A1',
    itemId: 'item10A1',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 10A1 Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency10A1Def'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 10A1 Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency10A1Ins'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: "<strong>A1.  During the period under review, was the child’s current or most recent placement with a relative?</strong>"
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: true,
            layout: 'vbox',
            margin: '10 10 20 40',
            items: [
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 20 0',
                    itemId: 'item10A1Question',
                    items: [
                        {
                            xtype: 'radio',
                            boxLabel: '<b>Yes</b>',
                            itemId: 'question10A1Yes',
                            inputValue: 1,
                            name: 'IsRecentPlacementRelative',
                            bind: '{isRecentPlacementWithRelative}'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>No</b>',
                            itemId: 'question10A1No',
                            inputValue: 2,
                            bind: '{isRecentPlacementWithRelative}',
                            name: 'IsRecentPlacementRelative'
                        }
                    ]
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem10A1Question',
                    itemName: 'item10'
                }
            ]
        }
    ]
});
//
// Question 10A2
//
Ext.define('app.CaseReview.view.permanency.Question10A2', {
    extend: 'Ext.container.Container',
    alias: 'widget.question10A2',
    itemId: 'item10A2',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 10A2 Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency10A2Def'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 10A2 Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency10A2Ins'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: "<strong>A2.  If the child’s current or most recent placement is with a relative, is (or was) this placement stable and appropriate to the child’s needs?</strong>"
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: true,
            layout: 'vbox',
            margin: '10 10 20 40',
            items: [
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 20 0',
                    itemId: 'item10A2Question',
                    items: [
                        {
                            xtype: 'radio',
                            boxLabel: '<b>Yes</b>',
                            itemId: 'question10A2Yes',
                            inputValue: 1,
                            name: 'IsPlacementStable',
                            bind: '{isPlacementWithRelativeStable}'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>No</b>',
                            itemId: 'question10A2No',
                            inputValue: 2,
                            name: 'IsPlacementStable',
                            bind: '{isPlacementWithRelativeStable}'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>NA</b>',
                            itemId: 'question10A2NA',
                            inputValue: 3,
                            name: 'IsPlacementStable',
                            bind: '{isPlacementWithRelativeStable}'
                        }
                    ]
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem10A2Question',
                    itemName: 'item10'
                }
            ]
        }
    ]
});
//
// Question 10B
//
Ext.define('app.CaseReview.view.permanency.Question10B', {
    extend: 'Ext.container.Container',
    alias: 'widget.question10B',
    itemId: 'item10B',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 10B Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency10BIns'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: "<strong>B.  Did the agency, during the period under review, make concerted efforts to identify, locate, inform, and evaluate maternal relatives as potential placements for the child, with the result that maternal relatives were ruled out as placement resources (due to fit, relative’s unwillingness, or child's best interests) during the period under review?</strong>"
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: true,
            layout: 'vbox',
            margin: '10 10 20 40',
            items: [
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 0 0',
                    itemId: 'item10BQuestion',
                    items: [
                        {
                            xtype: 'radio',
                            boxLabel: '<b>Yes</b>',
                            itemId: 'question10BYes',
                            inputValue: 1,
                            bind: '{isConcertedEffortToLocateMaternalRelatives}',
                            name: 'IsConcertedEffortLocateMaternalRelatives'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>No</b>',
                            itemId: 'question10BNo',
                            inputValue: 2,
                            bind: '{isConcertedEffortToLocateMaternalRelatives}',
                            name: 'IsConcertedEffortLocateMaternalRelatives'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>NA</b>',
                            itemId: 'question10BNA',
                            inputValue: 3,
                            bind: '{isConcertedEffortToLocateMaternalRelatives}',
                            name: 'IsConcertedEffortLocateMaternalRelatives'
                        }
                    ]
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem10BQuestion',
                    itemName: 'item10'
                },
                {
                    xtype: 'container',
                    cls: 'panel-background-color',
                    border: true,
                    layout: 'vbox',
                    margin: '00 10 20 0',
                    items: [
                        {
                            xtype: 'component',
                            border: false,
                            margin: '20 0 0 10',
                            cls: 'panel-background-color',
                            html: 'If No, specify the area in which concerns existed:'
                        },
                        {
                            xtype: 'container',
                            border: false,
                            cls: 'panel-background-color',
                            margin: '20 20 20 35',
                            items: [
                                {
                                    xtype: 'boundcheckboxgroup',
                                    columns: 1,
                                    vertical: true,
                                    store: 'CR_MultiAnswer_CollectionStore',
                                    inputField: 'CodeDescriptionID',
                                    itemId: 'motherEfforts',
                                    listeners: {
                                        click: {
                                            element: 'el',
                                            fn: function () {

                                                appDataEvent.permanency.changeByUserAction = true;
                                            }
                                        }
                                    },
                                    items: [
                                        {
                                            itemId: 'placementEffortConcernsMother1',
                                            boxLabel: 'Identify',
                                            inputValue: 156,
                                            disabled: true
                                        },
                                        {
                                            itemId: 'placementEffortConcernsMother2',
                                            boxLabel: 'Locate',
                                            inputValue: 157,
                                            disabled: true
                                        },
                                        {
                                            itemId: 'placementEffortConcernsMother3',
                                            boxLabel: 'Inform',
                                            inputValue: 158,
                                            disabled: true
                                        },
                                        {
                                            itemId: 'placementEffortConcernsMother4',
                                            boxLabel: 'Evaluate',
                                            inputValue: 159,
                                            disabled: true
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    ]
});
//
// Question 10C
//
Ext.define('app.CaseReview.view.permanency.Question10C', {
    extend: 'Ext.container.Container',
    alias: 'widget.question10C',
    itemId: 'item10C',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 10C Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency10CIns'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: "<strong>C.  Did the agency, during the period under review, make concerted efforts to identify, locate, inform, and evaluate paternal relatives as potential placements for the child, with the result that paternal relatives were ruled out as placement resources (due to fit, relative’s unwillingness, or child's best interests) during the period under review?</strong>"
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: true,
            layout: 'vbox',
            margin: '10 10 20 40',
            items: [
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    itemId: 'item10CQuestion',
                    margin: '0 0 0 0',
                    items: [
                        {
                            xtype: 'radio',
                            boxLabel: '<b>Yes</b>',
                            itemId: 'question10CYes',
                            inputValue: 1,
                            name: 'IsConcertedEffortLocatePaternalRelatives',
                            bind: '{isConcertedEffortToLocatePaternalRelatives}'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>No</b>',
                            itemId: 'question10CNo',
                            inputValue: 2,
                            name: 'IsConcertedEffortLocatePaternalRelatives',
                            bind: '{isConcertedEffortToLocatePaternalRelatives}'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>NA</b>',
                            itemId: 'question10CNA',
                            inputValue: 3,
                            name: 'IsConcertedEffortLocatePaternalRelatives',
                            bind: '{isConcertedEffortToLocatePaternalRelatives}'
                        }
                    ]
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem10CQuestion',
                    itemName: 'item10'
                },
                {
                    xtype: 'container',
                    cls: 'panel-background-color',
                    border: true,
                    layout: 'vbox',
                    margin: '0 10 20 0',
                    items: [
                        {
                            xtype: 'component',
                            border: false,
                            margin: '20 0 0 10',
                            cls: 'panel-background-color',
                            html: 'If No, specify the area in which concerns existed:'
                        },
                        {
                            xtype: 'container',
                            border: false,
                            cls: 'panel-background-color',
                            margin: '20 20 20 35',
                            items: [
                                {
                                    xtype: 'boundcheckboxgroup',
                                    columns: 1,
                                    vertical: true,
                                    store: 'CR_MultiAnswer_CollectionStore',
                                    inputField: 'CodeDescriptionID',
                                    itemId: 'fatherEfforts',
                                    items: [
                                        {
                                            itemId: 'placementEffortConcernsFather1',
                                            boxLabel: 'Identify',
                                            inputValue: 160,
                                            disabled: true
                                        },
                                        {
                                            itemId: 'placementEffortConcernsFather2',
                                            boxLabel: 'Locate',
                                            inputValue: 161,
                                            disabled: true
                                        },
                                        {
                                            itemId: 'placementEffortConcernsFather3',
                                            boxLabel: 'Inform',
                                            inputValue: 162,
                                            disabled: true
                                        },
                                        {
                                            itemId: 'placementEffortConcernsFather4',
                                            boxLabel: 'Evaluate',
                                            inputValue: 163,
                                            disabled: true
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    ]
});
//
// Item 11 Preapplicability questions
//
Ext.define('app.CaseReview.view.permanency.Item11Preapp', {
    extend: 'Ext.container.Container',
    alias: 'widget.item11Preapp',
    itemId: 'item11Panel',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'component',
            itemId: 'item11',
            border: false,
            margin: '20 0 0 20',
            html: '<strong>Item 11:</strong> Relationship of Child in Care With Parents',
            cls: 'outcome-item-header'
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Purpose of Assessment: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency11Purpose'
                }
            ]
        },
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Item 11 Definitions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency11Def'
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 20 20',
            items: [
                {
                    xtype: 'container',
                    cls: 'panel-background-color',
                    itemId: 'item11PreApplicableCases',
                    border: false,
                    layout: 'hbox',
                    items: [
                        {
                            xtype: 'component',
                            border: false,
                            margin: '20 0 0 20',
                            cls: 'panel-background-color',
                            html: '<strong>Item 11 Applicable Cases:</strong>'
                        },
                        {
                            xtype: 'validationMessage',
                            itemId: 'msgItem11PreApplicableCases',
                            itemName: 'item11'
                        }
                    ]
                },
                {
                    xtype: 'component',
                    padding: 0,
                    border: false,
                    html: "<ul><li> All foster care cases are applicable for assessment of this item unless any of the following apply (check Yes for any that apply and No for any that do not apply):</li>" +
                            "</ul>"
                },
                {
                    xtype: 'container',
                    cls: 'panel-background-color',
                    border: false,
                    items: [
                        {
                            xtype: 'component',
                            margin: '0 0 0 20',
                            padding: 0,
                            border: false,
                            html: "<ul><li> The parental rights for both parents remained terminated during the entire period under review.</li>" +
                                    "</ul>"
                        },
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 0 100',
                            inputField: 'CodeDescriptionID',
                            codeDescValue: 63,
                            itemId: 'item11Question1',
                            defaults: {
                                bind: '{answerCode63}'
                            },
                            items: [
                                {
                                    itemId: 'item11Applicability1Yes',
                                    inputValue: 1,
                                    name: 'item11Applicability1',
                                    boxLabel: '<b>Yes</b>'

                                },
                                {
                                    margin: '0 0 0 10',
                                    itemId: 'item11Applicability1No',
                                    inputValue: 2,
                                    name: 'item11Applicability1',
                                    boxLabel: '<b>No</b>'
                                }
                            ]
                        },
                        {
                            xtype: 'component',
                            margin: '0 0 0 20',
                            padding: 0,
                            border: false,
                            html: "<ul><li> The child was abandoned and neither parent could be located.</li>" +
                                    "</ul>"
                        },
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 0 100',
                            inputField: 'CodeDescriptionID',
                            codeDescValue: 64,
                            itemId: 'item11Question2',
                            defaults: {
                                bind: '{answerCode64}'
                            },
                            items: [
                                {
                                    itemId: 'item11Applicability2Yes',
                                    inputValue: 1,
                                    name: 'item11Applicability2',
                                    boxLabel: '<b>Yes</b>'
                                },
                                {
                                    margin: '0 0 0 10',
                                    itemId: 'item11Applicability2No',
                                    inputValue: 2,
                                    name: 'item11Applicability2',
                                    boxLabel: '<b>No</b>'
                                }
                            ]
                        },
                        {
                            xtype: 'component',
                            margin: '0 0 0 20',
                            padding: 0,
                            border: false,
                            html: "<ul><li> The whereabouts of both parents were not known during the entire period under review despite documented concerted agency efforts to locate both parents.</li>" +
                                    "</ul>"
                        },
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 0 100',
                            inputField: 'CodeDescriptionID',
                            codeDescValue: 65,
                            itemId: 'item11Question3',
                            defaults: {
                                bind: '{answerCode65}'
                            },
                            items: [
                                {
                                    itemId: 'item11Applicability3Yes',
                                    inputValue: 1,
                                    name: 'item11Applicability3',
                                    boxLabel: '<b>Yes</b>'
                                },
                                {
                                    margin: '0 0 0 10',
                                    itemId: 'item11Applicability3No',
                                    inputValue: 2,
                                    name: 'item11Applicability3',
                                    boxLabel: '<b>No</b>'
                                }
                            ]
                        },
                        {
                            xtype: 'component',
                            margin: '0 0 0 20',
                            padding: 0,
                            border: false,
                            html: "<ul><li> Contact with both parents was considered to be not in the child’s best interests and this is documented in the case record.</li>" +
                                    "</ul>"
                        },
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 0 100',
                            inputField: 'CodeDescriptionID',
                            codeDescValue: 66,
                            itemId: 'item11Question4',
                            defaults: {
                                bind: '{answerCode66}'
                            },
                            items: [
                                {
                                    itemId: 'item11Applicability4Yes',
                                    inputValue: 1,
                                    name: 'item11Applicability4',
                                    boxLabel: '<b>Yes</b>'
                                },
                                {
                                    margin: '0 0 0 10',
                                    itemId: 'item11Applicability4No',
                                    inputValue: 2,
                                    name: 'item11Applicability4',
                                    boxLabel: '<b>No</b>'
                                }
                            ]
                        },
                        {
                            xtype: 'component',
                            margin: '0 0 0 20',
                            padding: 0,
                            border: false,
                            html: "<ul><li> During the entire period under review, both parents were deceased.</li>" +
                                    "</ul>"
                        },
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 0 100',
                            inputField: 'CodeDescriptionID',
                            codeDescValue: 67,
                            itemId: 'item11Question5',
                            defaults: {
                                bind: '{answerCode67}'
                            },
                            items: [
                                {
                                    itemId: 'item11Applicability5Yes',
                                    inputValue: 1,
                                    name: 'item11Applicability5',
                                    boxLabel: '<b>Yes</b>'
                                },
                                {
                                    margin: '0 0 0 10',
                                    itemId: 'item11Applicability5No',
                                    inputValue: 2,
                                    name: 'item11Applicability5',
                                    boxLabel: '<b>No</b>'
                                }
                            ]
                        },
                        {
                            xtype: 'component',
                            margin: '0 0 0 20',
                            padding: 0,
                            border: false,
                            html: "<ul><li> The only parent(s) being assessed in this item do not meet the definition of Mother/Father for this item.</li>" +
                                    "</ul>"
                        },
                        {
                            xtype: 'radiogroup',
                            bodyCls: 'panel-background-color',
                            border: false,
                            layout: 'hbox',
                            margin: '0 0 0 100',
                            inputField: 'CodeDescriptionID',
                            codeDescValue: 261,
                            itemId: 'item11Question6',
                            defaults: {
                                bind: '{answerCode261}'
                            },
                            items: [
                                {
                                    xtype: 'radio',
                                    inputValue: 1,
                                    boxLabel: '<b>Yes</b>',
                                    itemId: 'item11Applicability6Yes',
                                    name: 'item11Applicability6'
                                },
                                {
                                    margin: '0 0 0 10',
                                    xtype: 'radio',
                                    boxLabel: '<b>No</b>',
                                    inputValue: 2,
                                    itemId: 'item11Applicability6No',
                                    name: 'item11Applicability6'
                                }
                            ]
                        }
                    ]
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'outcome-item-header',
            html: '<strong>Is this case applicable?</strong>'
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: 'Select the appropriate response. If the response is No, the case will be rated as Not Applicable in the ratings section for this item.'
        },
        {
            xtype: 'itemApplicable',
            store: 'CR_Outcome_CollectionStore',
            bodyCls: 'panel-background-color',
            border: false,
            OutcomeCode: 4,
            ItemCode: 12,
            items: [
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 20 40',
                    itemId: 'item11Applicability',
                    defaults: {
                        trackResetOnLoad: true
                    },
                    items: [
                        {
                            xtype: 'radio',
                            boxLabel: '<b>Yes</b>',
                            inputValue: 1,
                            itemId: 'itemApplicable11Yes',
                            bind: '{item11Applicable}',
                            name: 'applicableItem11'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>No</b>',
                            inputValue: 2,
                            itemId: 'itemApplicable11No',
                            bind: '{item11Applicable}',
                            name: 'applicableItem11'
                        }
                    ]
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem11Applicability',
                    orientation: 'wide',
                    itemName: 'item11'
                },
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 20',
                    cls: 'panel-background-color',
                    html: 'Indicate the case participants who are included in this item as Mother and Father:'
                },
                {
                    xtype: 'container',
                    cls: 'panel-background-color',
                    border: false,
                    layout: 'vbox',
                    margin: '0 0 20 40',
                    itemId: 'item11ParentCaseParticipant',
                    items: [
                        {
                            xtype: 'component',
                            border: false,
                            margin: '10 0 0 10',
                            cls: 'panel-background-color',
                            html: 'Mother:'
                        },
                        {
                            xtype: 'checkboxgroup',
                            columns: 1,
                            vertical: true,
                            itemId: 'item11ParticipantCheckboxGroupMother',
                            listeners: {
                                'afterrender': function () {

                                    var checkboxgroup = this;
                                    var checkboxgroupStore = GetItemParticipant(1);
                                    var checkbox = null;
                                    var participantId, participantName;
                                    var dataParms = { itemCode: 12, outcomeCode: 4 };

                                    for (var iCheckboxCount = 0; iCheckboxCount < checkboxgroupStore.count() ; iCheckboxCount++) {

                                        //participantId = checkboxgroupStore.getAt(iCheckboxCount).data.CaseParticipantID;
                                        participantName = checkboxgroupStore.getAt(iCheckboxCount).data.Name;
                                        participantId = participants[participantName].ParticipantID;

                                        dataParms['participantId'] = participantId;
                                        dataParms['participantName'] = participantName;
                                        dataParms['codeDescriptionId'] = 269;

                                        checkbox = new Ext.form.Checkbox({
                                            boxLabel: checkboxgroupStore.getAt(iCheckboxCount).data.Name,
                                            //inputValue: checkboxgroupStore.getAt(iCheckboxCount).data.CaseParticipantID,
                                            inputValue: participantId,
                                            itemId: 'checkbox11Mother' + participantId,
                                            //checked: isParticipantSelected(participantId),
                                            checked: isItemParticipantSelected(dataParms),
                                            listeners: {
                                                'change': function (cmp, newValue, oldValue, eOpts) {

                                                    var selectedItem = getSelectedItem(newValue, oldValue);
                                                    var newKeys = getObjectKeys(selectedItem);

                                                    if (newKeys.length > 0) {

                                                        var parms = { currentVal: newValue };
                                                        var selection = (newValue) ? cmp.inputValue : 0;

                                                        var fields = [];
                                                        var field = { 'ParticipantID': selection };
                                                        fields.push(field);

                                                        field = { 'CodeDescriptionID': 269 };
                                                        fields.push(field);

                                                        field = { 'DataState': 0 };
                                                        fields.push(field);

                                                        parms['storeId'] = 'CR_ItemParticipant_CollectionStore';
                                                        parms['fields'] = fields;

                                                        parms = getStatusParms(parms, 'permanencyItem11Rating');
                                                        parms['runValidations'] = true;
                                                        parms['dataChanged'] = true;

                                                        initValidations('Item11');

                                                        runPermanencyRules(getAppController(), 'item11ParticipantCheckboxGroupMother', parms);
                                                    }
                                                }
                                            }
                                        });
                                        checkboxgroup.items.add(checkbox);
                                    }
                                }
                            }
                        },
                        {
                            xtype: 'validationMessage',
                            itemId: 'msgItem11MotherCaseParticipant',
                            itemName: 'item11'
                        },
                        {
                            xtype: 'component',
                            border: false,
                            margin: '10 0 0 10',
                            cls: 'panel-background-color',
                            html: 'Father:'
                        },
                        {
                            xtype: 'checkboxgroup',
                            columns: 1,
                            vertical: true,
                            itemId: 'item11ParticipantCheckboxGroupFather',
                            listeners: {
                                'afterrender': function () {

                                    var checkboxgroup = this;
                                    var checkboxgroupStore = GetItemParticipant(2);
                                    var checkbox = null;
                                    var participantId, participantName;
                                    var dataParms = { itemCode: 12, outcomeCode: 4 };

                                    for (var iCheckboxCount = 0; iCheckboxCount < checkboxgroupStore.count() ; iCheckboxCount++) {

                                        //participantId = checkboxgroupStore.getAt(iCheckboxCount).data.CaseParticipantID;
                                        participantName = checkboxgroupStore.getAt(iCheckboxCount).data.Name;
                                        participantId = participants[participantName].ParticipantID;

                                        dataParms['participantId'] = participantId;
                                        dataParms['participantName'] = participantName;
                                        dataParms['codeDescriptionId'] = 270;

                                        checkbox = new Ext.form.Checkbox({
                                            boxLabel: checkboxgroupStore.getAt(iCheckboxCount).data.Name,
                                            //inputValue: checkboxgroupStore.getAt(iCheckboxCount).data.CaseParticipantID,
                                            inputValue: participantId,
                                            itemId: 'checkbox11Father' + participantId,
                                            //checked: isParticipantSelected(participantId),
                                            checked: isItemParticipantSelected(dataParms),
                                            width: 200,
                                            listeners: {
                                                'change': function (cmp, newValue, oldValue, eOpts) {

                                                    var selectedItem = getSelectedItem(newValue, oldValue);
                                                    var newKeys = getObjectKeys(selectedItem);

                                                    if (newKeys.length > 0) {

                                                        var parms = { currentVal: newValue };
                                                        var selection = (newValue) ? cmp.inputValue : 0;

                                                        var fields = [];
                                                        var field = { 'ParticipantID': selection };
                                                        fields.push(field);

                                                        field = { 'CodeDescriptionID': 270 };
                                                        fields.push(field);

                                                        field = { 'DataState': 0 };
                                                        fields.push(field);

                                                        parms['storeId'] = 'CR_ItemParticipant_CollectionStore';
                                                        parms['fields'] = fields;

                                                        parms = getStatusParms(parms, 'permanencyItem11Rating');
                                                        parms['runValidations'] = true;
                                                        parms['dataChanged'] = true;

                                                        initValidations('Item11');

                                                        runPermanencyRules(getAppController(), 'item11ParticipantCheckboxGroupFather', parms);
                                                    }
                                                }
                                            }
                                        });
                                        checkboxgroup.items.add(checkbox);
                                    }
                                }
                            }
                        },
                        {
                            xtype: 'validationMessage',
                            itemId: 'msgItem11FatherCaseParticipant',
                            itemName: 'item11'
                        }
                    ]
                },
                {
                    xtype: 'container',
                    cls: 'panel-background-color',
                    border: false,
                    margin: '0 0 20 20',
                    items: [
                        {
                            xtype: 'component',
                            border: false,
                            margin: '10 0 0 0',
                            cls: 'panel-background-color',
                            html: 'Optional: Provide comments in the narrative field below.'
                        },
                        {
                            xtype: 'textarea',
                            itemId: 'item11ApplicableComments',
                            bind: '{item11Comments}',
                            enableKeyEvents: true,
                            height: 150,
                            width: '75%',
                            maxlength: 4100,
                            enforceMaxLength: true
                        }
                    ]
                }
            ]
        }
    ]
});
//
// Question 11A
//
Ext.define('app.CaseReview.view.permanency.Question11A', {
    extend: 'Ext.container.Container',
    alias: 'widget.question11A',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'item11APanel',
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 11A Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency11AIns'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: "<strong>A.  During the period under review, were concerted efforts made to promote, support, and otherwise maintain a positive and nurturing relationship between the child in foster care and his or her mother?</strong>"
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: true,
            layout: 'vbox',
            margin: '10 10 20 40',
            items: [
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 20 0',
                    itemId: 'item11AQuestion',
                    items: [
                        {
                            xtype: 'radio',
                            boxLabel: '<b>Yes</b>',
                            itemId: 'question11AYes',
                            inputValue: 1,
                            name: 'IsConcertedEffortMotherRelationship',
                            bind: '{isConcertedEffortMotherFosterRelationship}'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>No</b>',
                            itemId: 'question11ANo',
                            inputValue: 2,
                            name: 'IsConcertedEffortMotherRelationship',
                            bind: '{isConcertedEffortMotherFosterRelationship}'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>NA</b>',
                            itemId: 'question11ANA',
                            inputValue: 3,
                            name: 'IsConcertedEffortMotherRelationship',
                            bind: '{isConcertedEffortMotherFosterRelationship}'
                        }
                    ]
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem11AQuestion',
                    itemName: 'item11'
                }
            ]
        }
    ]
});
//
// Question 11A1
//
Ext.define('app.CaseReview.view.permanency.Question11A1', {
    extend: 'Ext.container.Container',
    alias: 'widget.question11A1',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'item11A1Panel',
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 11A1 Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency11A1Ins'
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            itemId: 'item11A1ConcertedEfforts',
            border: false,
            layout: 'hbox',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 20',
                    cls: 'panel-background-color',
                    html: "<strong>A1.  What concerted efforts were made to support or strengthen the mother-child relationship? Select all that apply, if question A is Yes.</strong>"
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem11A1ConcertedEfforts',
                    itemName: 'item11'
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: true,
            margin: '20 10 20 10',
            items: [
                {
                    xtype: 'boundcheckboxgroup',
                    itemId: 'question11A1',
                    columns: 1,
                    vertical: true,
                    store: 'CR_MultiAnswer_CollectionStore',
                    inputField: 'CodeDescriptionID',
                    items: [
                    {
                        itemId: 'effortsToSupportMotherFosterRelationship1',
                        boxLabel: 'NA',
                        inputValue: 164,

                    },
                    {
                        itemId: 'effortsToSupportMotherFosterRelationship2',
                        boxLabel: 'Encouraged the mother’s participation in school activities and case conferences, attendance at doctors’ appointments with the child, or engagement in the child’s after-school or sports activities?',
                        inputValue: 165

                    },
                    {
                        itemId: 'effortsToSupportMotherFosterRelationship3',
                        boxLabel: 'Provided or arranged for transportation or provided funds for transportation so that the mother could attend the child’s special activities and doctors’ appointments?',
                        inputValue: 166

                    },
                    {
                        itemId: 'effortsToSupportMotherFosterRelationship4',
                        boxLabel: 'Provided opportunities for therapeutic situations to help the mother and child strengthen their relationship?',
                        inputValue: 167,

                    },
                    {
                        itemId: 'effortsToSupportMotherFosterRelationship5',
                        boxLabel: 'Encouraged the foster parents to provide mentoring or serve as role models to the mother to assist her in appropriate parenting?',
                        inputValue: 168,
                    },
                    {
                        itemId: 'effortsToSupportMotherFosterRelationship6',
                        boxLabel: 'Encouraged and facilitated contact with a mother not living in close proximity to the child?',
                        inputValue: 169
                    },
                    {
                        itemId: 'effortsToSupportMotherFosterRelationship7',
                        boxLabel: 'Other (describe other concerted efforts made)',
                        inputValue: 170
                    }
                    ]
                }
            ]
        },
        {
            xtype: 'container',
            bodyCls: 'panel-background-color',
            border: false,
            margin: '0 0 20 20',
            items: [
                {
                    xtype: 'textarea',
                    itemId: 'efforts11A1Comments',
                    disabled: true,
                    bind: '{effortsMotherFosterOther}',
                    enableKeyEvents: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                }
            ]
        }
    ]
});
//
// Question 11B
//
Ext.define('app.CaseReview.view.permanency.Question11B', {
    extend: 'Ext.container.Container',
    alias: 'widget.question11B',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'item11BPanel',
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 11B Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency11BIns'
                }
            ]
        },
        {
            xtype: 'component',
            border: false,
            margin: '10 0 0 20',
            cls: 'panel-background-color',
            html: "<strong>B.  During the period under review, were concerted efforts made to promote, support, and otherwise maintain a positive and nurturing relationship between the child in foster care and his or her father?</strong>"
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: true,
            layout: 'vbox',
            margin: '10 10 20 40',
            items: [
                {
                    xtype: 'radiogroup',
                    bodyCls: 'panel-background-color',
                    border: false,
                    layout: 'hbox',
                    margin: '0 0 20 0',
                    itemId: 'item11BQuestion',
                    items: [
                        {
                            xtype: 'radio',
                            boxLabel: '<b>Yes</b>',
                            itemId: 'question11BYes',
                            inputValue: 1,
                            name: 'IsConcertedEffortFatherRelationship',
                            bind: '{isConcertedEffortFatherFosterRelationship}'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>No</b>',
                            itemId: 'question11BNo',
                            inputValue: 2,
                            name: 'IsConcertedEffortFatherRelationship',
                            bind: '{isConcertedEffortFatherFosterRelationship}'
                        },
                        {
                            margin: '0 0 0 10',
                            xtype: 'radio',
                            boxLabel: '<b>NA</b>',
                            itemId: 'question11BNA',
                            inputValue: 3,
                            name: 'IsConcertedEffortFatherRelationship',
                            bind: '{isConcertedEffortFatherFosterRelationship}'
                        }
                    ]
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem11BQuestion',
                    itemName: 'item11'
                }
            ]
        }
    ]
});
//
// Question 11B1
//
Ext.define('app.CaseReview.view.permanency.Question11B1', {
    extend: 'Ext.container.Container',
    alias: 'widget.question11B1',
    margin: '20 20 20 20',
    cls: 'panel-background-color',
    border: true,
    itemId: 'item11B1Panel',
    defaults: {
        trackResetOnLoad: true
    },
    items:
    [
        {
            xtype: 'listPanel',
            title: "<div class='html-content-header-margins'>Question 11B1 Instructions: [SHOW]</div>",
            margin: '20 20 20 20',
            padding: '0 0 0 0',
            items: [
                {
                    contentEl: 'permanency11B1Ins'
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            itemId: 'item11B1ConcertedEfforts',
            border: false,
            layout: 'hbox',
            items: [
                {
                    xtype: 'component',
                    border: false,
                    margin: '10 0 0 20',
                    cls: 'panel-background-color',
                    html: "<strong>B1.  What concerted efforts were made to support or strengthen the father-child relationship? Select all that apply, if question B is Yes.</strong>"
                },
                {
                    xtype: 'validationMessage',
                    itemId: 'msgItem11B1ConcertedEfforts',
                    itemName: 'item11'
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: true,
            margin: '20 10 20 10',
            items: [
                {
                    xtype: 'boundcheckboxgroup',
                    itemId: 'question11B1',
                    columns: 1,
                    vertical: true,
                    store: 'CR_MultiAnswer_CollectionStore',
                    inputField: 'CodeDescriptionID',
                    items: [
                        {
                            itemId: 'effortsToSupportFatherFosterRelationship1',
                            boxLabel: 'NA',
                            inputValue: 171
                        },
                        {
                            itemId: 'effortsToSupportFatherFosterRelationship2',
                            boxLabel: 'Encouraged the father’s participation in school activities and case conferences, attendance at doctors’ appointments with the child, or engagement in the child’s after-school or sports activities?',
                            inputValue: 172

                        },
                        {
                            itemId: 'effortsToSupportFatherFosterRelationship3',
                            boxLabel: 'Provided or arranged for transportation or provided funds for transportation so that the father could attend the child’s special activities and doctors’ appointments?',
                            inputValue: 173

                        },
                        {
                            itemId: 'effortsToSupportFatherFosterRelationship4',
                            boxLabel: 'Provided opportunities for therapeutic situations to help the father and child strengthen their relationship?',
                            inputValue: 174

                        },
                        {
                            itemId: 'effortsToSupportFatherFosterRelationship5',
                            boxLabel: 'Encouraged the foster parents to provide mentoring or serve as role models to the father to assist him in appropriate parenting?',
                            inputValue: 175
                        },
                        {
                            itemId: 'effortsToSupportFatherFosterRelationship6',
                            boxLabel: 'Encouraged and facilitated contact with a father not living in close proximity to the child?',
                            inputValue: 176
                        },
                        {
                            itemId: 'effortsToSupportFatherFosterRelationship7',
                            boxLabel: 'Other (describe other concerted efforts made)',
                            inputValue: 177
                        }
                    ]
                }
            ]
        },
        {
            xtype: 'container',
            cls: 'panel-background-color',
            border: false,
            margin: '0 0 20 20',
            items: [
                {
                    xtype: 'textarea',
                    disabled: true,
                    itemId: 'efforts11B1Comments',
                    bind: '{effortFatherFosterRelationshipOther}',
                    enableKeyEvents: true,
                    //height: 100,  This does work with grow: true
                    //growMin: 100,
                    //growMax: 350,
                    //grow: true,
                    width: '75%',
                    maxlength: 4100,
                    enforceMaxLength: true,
                    height: 150
                }
            ]
        }
    ]
});