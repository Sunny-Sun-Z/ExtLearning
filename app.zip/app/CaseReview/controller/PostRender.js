﻿Ext.define('App.CaseReview.controller.PostRender',
{
    extend: 'Ext.Base',
    constructor: function(ctrl) {

        var self = ctrl;
        /* istanbul ignore next - all gui, impractical to test  */
        var onWindowUnloading = function(e) {
            var msg = "ALERT: Any unsaved work will be lost, press cancel if you need to save, otherwise press ok to proceed without saving?";
            e.browserEvent.returnValue = msg;            
        };
        var items = Ext.ComponentQuery.query('#AppForm [itemId]');
        var i, itemId, ref;
        var itemsLength = items.length;
        for (i = 0; i < itemsLength; i++) {
            itemId = items[i].itemId;
            ref = itemId.replace(/-/g, "_").replace(/\./g, "_");
            ctrl.addRef([{ ref: ref, selector: '#' + itemId }]);
        }
        Ext.dom.Element.get(window).addListener('beforeunload', onWindowUnloading, ctrl);
        
        window.CaseStatusNRoleSecurity.setUpSecurity(ctrl);

        //if (VerifyPermission.checkforPermissionInCase(sr.Permissions.EditCaseData)) {
        //    self.getFacesheetSave1().hidden = true;
        //    self.getPermanencyItem4Save().hidden = true;
        //    self.getPermanencyItem5Save().hidden = true;
        //    self.getPermanencyItem6Save().hidden = true;
        //    self.getPermanencyItem7Save().hidden = true;
        //    self.getPermanencyItem8Save().hidden = true;
        //    self.getPermanencyItem9Save().hidden = true;
        //    self.getPermanencyItem10Save().hidden = true;
        //    self.getPermanencyItem11Save().hidden = true;
        //    self.getSafetySave1().hidden = true;
        //    self.getSafetySave2().hidden = true;
        //    self.getSafetySave3().hidden = true;
        //    self.getWellbeingItem12ASave().hidden = true;
        //    self.getWellbeingItem12BSave().hidden = true;
        //    self.getWellbeingItem12CSave().hidden = true;
        //    self.getWellbeingItem12Save().hidden = true;
        //    self.getWellbeingItem13Save().hidden = true;
        //    self.getWellbeingItem14Save().hidden = true;
        //    self.getWellbeingItem14RatingSave().hidden = true;
        //    self.getWellbeingItem15Save().hidden = true;
        //    self.getWellbeingItem16Save().hidden = true;
        //    self.getWellbeingItem17Save().hidden = true;
        //    self.getWellbeingItem17RatingSave().hidden = true;
        //    self.getWellbeingItem18Save().hidden = true;
        //    //self.getEliminateCaseReview().hidden = true;
        //    //self.getEliminateBack().hidden = true;
        //    //self.getEliminateCaseApproved().hidden = true;
        //    self.getSubmitToQA().hidden = true;
        //    self.getReturnToQA().hidden = true;
        //    self.getReturnToReviewer().hidden = true;
        //    self.getSubmitToFinalize().hidden = true;
        //    self.getFinalizeAndApprove().hidden = true;

        //    var items = Ext.ComponentQuery.query('#AppForm [itemId]');
        //    for (i = 0; i < itemsLength; i++) {
        //        items[i].readOnly = true;
        //    }


        //}

        //var caseReviewStatus = Ext.StoreMgr.get('CaseReviewStore').getAt(0).data.CaseStatusCode;

        //switch (caseReviewStatus) {
        //    case 8:


        //}


//Ext.dom.Element.get(window).addListener('beforeunload', onWindowUnloading, ctrl);

        //var commonValidations = Ext.create('IVE.controller.common.Validations');
        //ctrl.validations = Ext.create('IVE.controller.spm.eligibility.spminitial.SpmInitialValidation', ctrl);
        //var determination = Ext.create('IVE.service.spm.eligibility.spminitial.Determination');
        //ctrl.determination = Ext.create('IVE.controller.spm.eligibility.spminitial.Determination', ctrl.viewModel, determination);
        //ctrl.fieldCalculations = Ext.create('IVE.controller.spm.eligibility.spminitial.FieldCalculations', ctrl.viewModel, ctrl.validations, ctrl.determination);
        //ctrl.enableDisable = Ext.create('IVE.controller.spm.eligibility.spminitial.SpmInitialEnableDisable', ctrl);
        //Ext.create('IVE.controller.spm.eligibility.common.ProgramExclusionGrid', ctrl, commonValidations);
        //Ext.create('IVE.controller.spm.eligibility.common.AssetGrid', ctrl);
        //Ext.create('IVE.controller.spm.eligibility.common.IncomeGrid', ctrl);
        //Ext.create('IVE.controller.spm.eligibility.common.SsiGrid', ctrl, commonValidations);
        //Ext.create('IVE.controller.spm.eligibility.common.PlacementGrid', ctrl);
        //var licensePlacementController = Ext.create('IVE.controller.spm.eligibility.common.SpmLicensedPlacement');
        //Ext.create('IVE.controller.spm.eligibility.common.LicensedPlacementGrid', ctrl, licensePlacementController, commonValidations);
        //Ext.create('IVE.controller.spm.eligibility.common.DeterminationGrid', ctrl, commonValidations);
        //Ext.create('IVE.controller.spm.eligibility.common.EductionGrid', ctrl, commonValidations);
        //Ext.create('IVE.controller.spm.eligibility.common.ProgramsGrid', ctrl, commonValidations);
        //Ext.create('App.CaseReview.controller.common.ChildDemographicGrid', ctrl);
        //Ext.create('IVE.controller.spm.eligibility.common.SpmQuickTips', ctrl);

        //var hideChildren = function (childComponents) {
        //    for (var componentIndex = 0; componentIndex < childComponents.length; componentIndex++) {

        //        ctrl.viewModel.hide(childComponents[componentIndex].itemId);
        //        if (!childComponents[componentIndex].down) {
        //            continue;
        //        }
        //        var childrn = childComponents[componentIndex].down('[itemId]');
        //        if (!childrn) {
        //            continue;
        //        }
        //        if (childrn.length) {
        //            hideChildren(childrn);
        //        } else {
        //            hideChildren([childrn]);
        //        }
        //    }
        //};

        //var hiddenComponents = Ext.ComponentQuery.query('[itemId]{isHidden()}');

        //hideChildren(hiddenComponents);


        //setTimeout Because there is stuff that happens after this event handler
        //that I don't know how to trap with an event
        //ctrl.screenController.bind(
        //    /* istanbul ignore next - all gui, impractical to test  */
        //    function () {
        //        Ext.log("-> Ext.resumeLayouts() SpmInitialScreen 167 <-");
        //        Ext.resumeLayouts(true);
        //        setTimeout(function () {
        //            Ext.getBody().unmask();
        //        }, 0);
        //    });

    }

});
