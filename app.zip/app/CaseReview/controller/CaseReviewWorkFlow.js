﻿Ext.define('App.CaseReview.controller.CaseReviewWorkFlow', {
    extend: 'Ext.Base',
    singleton: true,
    alternateClassName: 'CaseReviewWorkFlow',
    tabPanel: null,
    reviewSteps: {
        actions:{
            load: {
                caseoverviewnew: {
                    name: 'caseoverviewnew',
                    tabId: 'caseOverview',
                    nextStep: 'facesheet',
                    caseStatus: 'Not Started',
                    stepStatus: 'Not Started',
                    prevStep: null
                },
                caseoverview: {
                    name: 'caseoverview',
                    tabId: 'caseOverview',
                    nextStep: 'safety',
                    caseStatus: 'In Progress',
                    stepStatus: 'Not Started',
                    prevStep: null
                },
                facesheet: {
                    name: 'facesheet',
                    tabId: 'faceSheet',
                    nextStep: null,
                    caseStatus: 'Not Started',
                    stepStatus: 'Not Started',
                    prevStep: 'caseoverview'
                },
                safety: {
                    name: 'safety',
                    tabId: 'safety',
                    nextStep: null,
                    caseStatus: 'In Progress',
                    stepStatus: ['Not Started','In Progress'],
                    prevStep: 'facesheet'
                }
            },
            save: {
                facesheet: {
                    name: 'facesheet',
                    tabId: 'faceSheet',
                    nextStep: 'safety',
                    caseStatus: 'In Progress',
                    stepStatus: 'Completed',
                    prevStep: 'caseoverview'
                },
                safety: {
                    name: 'safety',
                    tabId: 'safety',
                    nextStep: 'permanency',
                    caseStatus: 'In Progress',
                    stepStatus: 'Completed',
                    prevStep: 'facesheet'
                },
                permanency: {
                    name: 'permanency',
                    tabId: 'permanency',
                    nextStep: 'wellbeing',
                    caseStatus: 'In Progress',
                    stepStatus: 'Completed',
                    prevStep: 'safety'
                },
                wellbeing: {
                    name: 'wellbeing',
                    tabId: 'wellBeing',
                    nextStep: 'caseoverview',
                    caseStatus: 'In Progress',
                    stepStatus: 'Completed',
                    prevStep: 'permanency'
                },
                caseoverview: {
                    name: 'caseoverview',
                    tabId: 'caseOverview',
                    caseStatus: 'In Progress',
                    nextStep: null,
                    prevStep: 'wellbeing'
                }
            }
        }
    },
    getCurrentStep: function (stepName, action) {

        var self = this;

        if (Ext.isEmpty(action)) {

            return;
        }

        return self.reviewSteps.actions[action][stepName];
    },
    getNextStep: function (currentStep, action) {

        var self = this,
            stepId = currentStep.nextStep;
                
        return self.reviewSteps.actions[action][stepId];
    },
    visitNextStep: function (step, caseStatus, action) {
        
        var self = this;

        if (Ext.isEmpty(step)) {

            return;
        }

        if (Ext.isEmpty(step.nextStep) || Ext.isEmpty(step.tabId) || Ext.isEmpty(caseStatus)) {

            return;
        }
        //
        // Navigate to next page if current page is complete
        //
        if (isCurrentPageCompleted(step)) {            
            //
            // Go to next page
            //
            if (step.caseStatus == caseStatus) {
            
                var nextStep = self.getNextStep(step, action),
                    tab = getCRSComponent(nextStep.tabId),
                    result = self.tabPanel.setActiveTab(tab);
            }

            return;
        }
        //
        // Navigate to Facesheet if a new case was created
        //
        if (isNewCase()) {
            //
            // Go to next page
            //
            if (step.caseStatus == caseStatus) {

                var nextStep = self.getNextStep(step, action),
                    tab = getCRSComponent(nextStep.tabId),
                    result = self.tabPanel.setActiveTab(tab);
            }

            return;
        }
        //
        // Navigate to Safety if Facesheet is completed and Safety is not complete
        //
        if (step.caseStatus == caseStatus) {

            var nextStep = self.getNextStep(step, action),
                tab = getCRSComponent(nextStep.tabId);

            if (nextStep.name == 'safety') {

                if (!isSafetyCompleted()) {

                    var result = self.tabPanel.setActiveTab(tab);
                }                
            }            
        }
    }
});