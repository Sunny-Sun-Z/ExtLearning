﻿Ext.define('App.CaseReview.controller.common.EducationGrid',
{
    extend: 'Ext.Base',
    constructor: function (controller) {
        var self = this;
        var grid = controller.getEducationGrid(); 
        var gridAdd = sr.ItemIds.educationGridAddButton;
        var gridEdit = sr.ItemIds.educationGridEditButton;
        var gridDelete = sr.ItemIds.educationGridDeleteButton;

        var enableDisableHandler = function () {
            //var selections = grid.getSelectionModel().getSelection();
            //if (selections.length > 0) {
            //    var record = selections[0];
            //    if (record.get('ID_ASSTNCE_GRP_MBRS_SEQ') === 0 || grid.getStore().getCount() === 1)// the one we get sent starts with 0 but if another is added, we make it zero.
            //    {
            //        setTimeout(function () {
            //            gridDelete.disable();
            //            gridEdit.disable();
            //        }, 0);
            //    }
            //}
            //if (grid.getStore().getCount() > 9) {
            //    setTimeout(function () {
            //        gridAdd.disable();
            //    }, 0);
            //}

        };

        /* istanbul ignore next: can only be tested with a gui  */
        var addEdit = function (record) {

            var edit = Ext.create('App.CaseReview.view.common.EducationHelper');
            Ext.create('App.CaseReview.controller.common.Education')
                                .init(grid, record, edit);
        };

        var deleteRecord = function () {

            grid.plugins[0].fireEvent('recorddelete');

            var parms = {};
            parms['recordType'] = 'Grid';
            parms['storeId'] = grid.store.storeId;
            parms['runValidations'] = true;

            runWellbeingRules(getAppController(), 'educationGrid', parms);
        };

        controller.educationGridEventHandler = Ext.create('framework.controller.GridAddEditDeleteEventHandlers', controller.viewModel,
        {
            'grid': grid,
            'add': gridAdd,
            'edit': gridEdit,
            'del': gridDelete,
            'insertRecord': {}, // blank record
            addAction: addEdit,
            editAction: addEdit,
            deleteAction: deleteRecord
        });

        controller.control({
            '#educationGridAdd': {
                'enable': enableDisableHandler
            },
            '#educationGrid': {
                'selectionchange': enableDisableHandler
            }
        });

        /* istanbul ignore else  */
        if (window.jasmine) {
            self.enableDisableHandler = enableDisableHandler;
            self.addEdit = addEdit;
        }
    }
});