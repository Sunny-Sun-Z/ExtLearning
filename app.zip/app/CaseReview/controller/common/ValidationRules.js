﻿/* global framework */
var runFacesheetValidationRules = function (compObj, section) {

    switch (section) {

        case sr.Constants.AllFields:
        case 'hYes':
        case 'hNo':
        case 'firstCaseOpeningDate':
        case 'fosterEntryDate':
        case 'questionM':
        case 'questionMNarrative':
        case 'childDemographicGrid':
        case 'caseParticipantGrid':

            var validationPlugin = new App.CaseReview.view.common.CRSValidationPlugin();
            var input = ['All'];

            validationPlugin.setValidationType('Facesheet');            
            validationPlugin.setValidationInput(input);
            validationPlugin.setStoreId('CR_FaceSheet_CollectionStore');

            validationPlugin.init(compObj);

            validations['Facesheet'] = Ext.isEmpty(validations['Facesheet']) ? 1 : validations['Facesheet'] + 1;

            break;

        default:

            break;
    }
}

var runItemValidation = function (parms) {

    var validationPlugin = new App.CaseReview.view.common.CRSValidationPlugin();

    validationPlugin.setValidationType(parms.validationType);
    validationPlugin.setValidationInput(parms.input);
    validationPlugin.setStoreId(parms.storeId);
    validationPlugin.setValidationRoutine(parms.validationRoutine);

    validationPlugin.init(getAppController());
};

var runSafetyValidationRules = function (compObj, section) {
        
    switch (section) {
        
        case 'item3F1':

            var parms = {
                'input': ['All'],
                'itemName': 'item3',
                'validationRoutine': 'ValidateItem3',
                'validationType': 'Safety',
                'storeId': 'CR_SafetyReport_CollectionStore'
            };

            runItemValidation(parms);

            break;

        case 'ValidateItem1':

            var parms = {
                'input': ['All'],
                'itemName': 'item1',
                'validationRoutine': 'ValidateItem1',
                'validationType': 'Safety',
                'storeId': 'CR_SafetyReport_CollectionStore'
            };

            runItemValidation(parms);

            break;
                    
        case 'ValidateItem2':

            var parms = {
                'input': ['All'],
                'itemName': 'item2',
                'validationRoutine': 'ValidateItem2',
                'validationType': 'Safety',
                'storeId': 'CR_SafetyReport_CollectionStore'
            };

            runItemValidation(parms);

            break;

        case 'ValidateItem3':

            var parms = {
                'input': ['All'],
                'itemName': 'item3',
                'validationRoutine': 'ValidateItem3',
                'validationType': 'Safety',
                'storeId': 'CR_SafetyReport_CollectionStore'
            };

            runItemValidation(parms);

            break;

        default:

            break;
    }
}
var runPermanencyValidationRules = function (compObj, section) {

    switch (section) {

        case 'recentFosterEntryDate':

            //var fosterEntryDate = compObj.getRecentFosterEntryDate();
            //var comp = compObj.getFosterEntryDate();

            //var result = comp.plugins[0].getRulesEvalResult();

            //if (result.validityResult == 'inHomeCase') {

            //    fosterEntryDate.setValue(null);
            //}

            //fosterEntryDate.disable();

            break;

        case 'permanencyDischargeDate':

            //var comp = compObj.getEpisodeDischargeDate();
            //var dischargeDate = compObj.getPermanencyDischargeDate();

            //var result = comp.plugins[0].getRulesEvalResult();

            //if (result.validityResult == 'inHomeCase') {
            //    var checkBox = compObj.getQuestion6A3();
            //    checkBox = checkBox.setValue('3');

            //    // Disable datefield                
            //    dischargeDate.setValue(null);
            //}

            //dischargeDate.disable();

            break;

        case 'item6A4':

            var comp = compObj.getItem5Rating();

            if (comp.value == 'NA') {

                var checkBox1 = compObj.getPermanencyGoal1();
                var checkBox2 = compObj.getPermanencyGoal2();
                var checkBox3 = compObj.getPermanencyGoal3();
                var checkBox4 = compObj.getPermanencyGoal4();

                checkBox1.setValue(127);
                checkBox2.setValue(false);
                checkBox3.setValue(false);
                checkBox4.setValue(false);
            }

            break;

        case 'item7RatingText':

            var comp = compObj.getItem7RatingText();

            var noSiblings = getNoOfSiblings();

            if (noSiblings == 0) {

                comp.setValue('NA');
            }

            break;

        case 'question7AYes':

            var comp7A = compObj.getQuestion7AYes();
            var noChildren = getNoOfChildren();
            var item8E1 = compObj.getItem8E1();
            var item8E = compObj.getItem8EQuestion();
            var item8F = compObj.getItem8FQuestion();

            if (noChildren == 1 || comp7A.getValue() == '1') {
                Ext.each(item8E1.items.items, function (item) {

                    if (item.xtype == 'radio') {

                        item.setValue(false);

                        if (item.itemId == 'siblingVisitFrequency1') {
                            item.setValue(true);
                        }
                    }                    
                });
            }

            if (noChildren == 1 || comp7A.getValue() == '1') {
                Ext.each(item8E.items.items, function (item) {

                    if (item.xtype == 'radio') {

                        item.setValue(false);

                        if (item.itemId == 'question8ENA') {
                            item.setValue(3);
                        }
                    }
                });
            }

            if (noChildren == 1 || comp7A.getValue() == '1') {
                Ext.each(item8F.items.items, function (item) {

                    if (item.xtype == 'radio') {

                        item.setValue(false);

                        if (item.itemId == 'question8FNA') {
                            item.setValue(3);
                        }
                    }
                });
            }

            break;

        case 'item8Applicability1No':

            var compNo = compObj.getItem8Applicability1No();
            var compYes = compObj.getItem8Applicability1Yes();

            var noSiblings = getNoOfSiblings();

            if (noSiblings == 0) {

                compNo.setValue(2);
                compYes.setValue(false);
            }

            var parms = {
                'input': ['All'],
                'itemName': 'item8',
                'validationRoutine': 'ValidateItem8',
                'validationType': 'Permanency',
                'storeId': 'CR_Permanency_CollectionStore'
            };

            runItemValidation(parms);

            break;

        case 'applicabilityQuestion8Yes':

            var comp = compObj.getApplicabilityQuestion8Yes();
            var yesAnswer = comp.getValue();
            var motherSpecified = isRelationshipSpecified('Mother');
            var fatherSpecified = isRelationshipSpecified('Father');

            if ((yesAnswer) && !(motherSpecified)) {

                var comp8A1 = compObj.getItem8A1();
                var comp8A = compObj.getItem8AQuestion();
                var comp8C = compObj.getItem8CQuestion();

                //Ext.each(comp8A1.items.items, function (item) {

                //    if (!(item.xtype == 'validationMessage')) {

                //        item.setValue(false);
                //    }

                //    if (item.itemId == 'motherVisitFrequency1') {
                //        item.setValue(true);
                //    }
                //});

                //Ext.each(comp8A.items.items, function (item) {

                //    if (!(item.xtype == 'validationMessage')) {

                //        item.setValue(false);
                //    }

                //    if (item.itemId == 'question8ANA') {
                //        item.setValue(true);
                //    }
                //});

                //Ext.each(comp8C.items.items, function (item) {

                //    if (!(item.xtype == 'validationMessage')) {

                //        item.setValue(false);
                //    }

                //    if (item.itemId == 'question8CNA') {
                //        item.setValue(true);
                //    }
                //});
            }

            if ((yesAnswer) && !(fatherSpecified)) {

                var comp8B1 = compObj.getItem8B1();
                var comp8B = compObj.getItem8BQuestion();
                var comp8D = compObj.getItem8DQuestion();

                //Ext.each(comp8B1.items.items, function (item) {

                //    if (!(item.xtype == 'validationMessage')) {

                //        item.setValue(false);
                //    }

                //    if (item.itemId == 'fatherVisitFrequency1') {
                //        item.setValue(true);
                //    }
                //});

                //Ext.each(comp8B.items.items, function (item) {

                //    if (!(item.xtype == 'validationMessage')) {

                //        item.setValue(false);
                //    }

                //    if (item.itemId == 'question8BNA') {
                //        item.setValue(true);
                //    }
                //});

                //Ext.each(comp8D.items.items, function (item) {

                //    if (!(item.xtype == 'validationMessage')) {

                //        item.setValue(false);
                //    }

                //    if (item.itemId == 'question8DNA') {
                //        item.setValue(true);
                //    }
                //});
            }

            var parms = {
                'input': ['All'],
                'itemName': 'item8',
                'validationRoutine': 'ValidateItem8',
                'validationType': 'Permanency',
                'storeId': 'CR_Permanency_CollectionStore'
            };

            runItemValidation(parms);

            break;

        case 'item4QuestionA':
        case 'item4QuestionB':
        case 'item4QuestionC1':
        case 'item4C1Placement':
        case 'item4CPlacementSetting':
        case 'ValidateItem4':

            var parms = {
                'input': ['All'],
                'itemName': 'item4',
                'validationRoutine': 'ValidateItem4',
                'validationType': 'Permanency',
                'storeId': 'CR_Permanency_CollectionStore'
            };

            runItemValidation(parms);

            break;

        case 'item5Applicable':
        case 'item5Yes':
        case 'item5No':
        case 'item5A3Yes':
        case 'item5A3No':
        case 'item5A3NA':
        case 'item5BYes':
        case 'item5BNo':
        case 'item5BNA':
        case 'item5CYes':
        case 'item5CNo':
        case 'item5DYes':
        case 'item5DNo':
        case 'item5EYes':
        case 'item5ENo':
        case 'item5ENA':
        case 'item5FYes':
        case 'item5FNo':
        case 'item5FNA':
        case 'question5GYes':
        case 'question5GNo':
        case 'question5GNA':
        case 'termEx1_change':
        case 'termEx2_change':
        case 'ValidateItem5':

            var parms = {
                'input': ['All'],
                'itemName': 'item5',
                'validationRoutine': 'ValidateItem5',
                'validationType': 'Permanency',
                'storeId': 'CR_Permanency_CollectionStore'
            };

            runItemValidation(parms);

            break;

        case 'item6A4CBGroup':
        case 'question6A3':
        case 'question6BYes':
        case 'question6BNo':
        case 'question6BNA':
        case 'question6CYes':
        case 'question6CNo':
        case 'question6CNA':
        case 'livingArragmentCode':
        case 'question6C2DocumentationDate':
        case 'question6C2NA':
        case 'question6C2NoDate':
        case 'ValidateItem6':

            var parms = {
                'input': ['All'],
                'itemName': 'item6',
                'validationRoutine': 'ValidateItem6',
                'validationType': 'Permanency',
                'storeId': 'CR_Permanency_CollectionStore'
            };

            runItemValidation(parms);

            break;

        case 'item7Yes':
        case 'item7No':
        case 'question7AYes':
        case 'question7ANo':
        case 'question7BYes':
        case 'question7BNo':
        case 'question7BNA':
        case 'ValidateItem7':

            var parms = {
                'input': ['All'],
                'itemName': 'item7',
                'validationRoutine': 'ValidateItem7',
                'validationType': 'Permanency',
                'storeId': 'CR_Permanency_CollectionStore'
            };

            runItemValidation(parms);

            break;

        case 'item8Question1':
        case 'motherVisitFrequency1':
        case 'motherVisitFrequency2':
        case 'motherVisitFrequency3':
        case 'motherVisitFrequency4':
        case 'motherVisitFrequency5':
        case 'motherVisitFrequency6':
        case 'motherVisitFrequency7':
        case 'fatherVisitFrequency1':
        case 'fatherVisitFrequency2':
        case 'fatherVisitFrequency3':
        case 'fatherVisitFrequency4':
        case 'fatherVisitFrequency5':
        case 'fatherVisitFrequency6':
        case 'fatherVisitFrequency7':
        case 'siblingVisitFrequency1':
        case 'siblingVisitFrequency2':
        case 'siblingVisitFrequency3':
        case 'siblingVisitFrequency4':
        case 'siblingVisitFrequency5':
        case 'siblingVisitFrequency6':
        case 'siblingVisitFrequency7':
        case 'question8AYes':
        case 'question8ANo':
        case 'question8ANA':
        case 'question8BYes':
        case 'question8BNo':
        case 'question8BNA':
        case 'question8CYes':
        case 'question8CNo':
        case 'question8CNA':
        case 'question8DYes':
        case 'question8DNo':
        case 'question8DNA':
        case 'question8EYes':
        case 'question8ENo':
        case 'question8ENA':
        case 'question8FYes':
        case 'question8FNo':
        case 'question8FNA':
        case 'ValidateItem8':
        case 'item8ParticipantCheckboxGroupMother':
        case 'item8ParticipantCheckboxGroupFather':

            var parms = {
                'input': ['All'],
                'itemName': 'item8',
                'validationRoutine': 'ValidateItem8',
                'validationType': 'Permanency',
                'storeId': 'CR_Permanency_CollectionStore'
            };

            runItemValidation(parms);

            break;

        case 'ValidateItem9':
        case 'question9AYes':
        case 'question9ANo':
        case 'question9BYes':
        case 'question9BNo':
        case 'question9CYes':
        case 'question9CNo':
        case 'question9CNA':
        case 'question9DYes':
        case 'question9DNo':
        case 'question9DNA':
        case 'item9ApplicableYes':
        case 'item9ApplicableNo':

            var parms = {
                'input': ['All'],
                'itemName': 'item9',
                'validationRoutine': 'ValidateItem9',
                'validationType': 'Permanency',
                'storeId': 'CR_Permanency_CollectionStore'
            };

            runItemValidation(parms);

            break;

        case 'question10A1Yes':
        case 'question10A1No':
        case 'question10A2Yes':
        case 'question10A2No':
        case 'question10A2NA':
        case 'question10BYes':
        case 'question10BNo':
        case 'question10BNA':
        case 'question10CYes':
        case 'question10CNo':
        case 'question10CNA':
        case 'ValidateItem10':
        case 'placementConcernsMother':
        case 'placementConcernsFather':

            var parms = {
                'input': ['All'],
                'itemName': 'item10',
                'validationRoutine': 'ValidateItem10',
                'validationType': 'Permanency',
                'storeId': 'CR_Permanency_CollectionStore'
            };

            runItemValidation(parms);

            break;

        case 'item11Applicability1Yes':
        case 'ValidateItem11':

            var comp = compObj.getItem11Applicability1Yes();
            var yesAnswer = comp.getValue();
            var motherSpecified = isRelationshipSpecified('Mother');
            var fatherSpecified = isRelationshipSpecified('Father');

            if ((yesAnswer) && !(motherSpecified)) {

                var comp11A1 = compObj.getQuestion11A1();

                Ext.each(comp11A1.items.items, function (item) {

                    item.setValue(false);

                    if (item.boxLabel == 'NA') {
                        item.setValue(true);
                    }
                });
            }

            if ((yesAnswer) && !(fatherSpecified)) {

                var comp11B1 = compObj.getQuestion11B1();

                Ext.each(comp11B1.items.items, function (item) {

                    item.setValue(false);

                    if (item.boxLabel == 'NA') {
                        item.setValue(true);
                    }
                });
            }

            var parms = {
                'input': ['All'],
                'itemName': 'item11',
                'validationRoutine': 'ValidateItem11',
                'validationType': 'Permanency',
                'storeId': 'CR_Permanency_CollectionStore'
            };

            runItemValidation(parms);

            break;

        case 'item11Question1':
        case 'item11Question2':
        case 'item11Question3':
        case 'item11Question4':
        case 'item11Question5':
        case 'item11Question6':
        case 'itemApplicable11Yes':
        case 'itemApplicable11No':
        case 'question11AYes':
        case 'question11ANo':
        case 'question11ANA':
        case 'question11A1':
        case 'question11BYes':
        case 'question11BNo':
        case 'question11BNA':
        case 'question11B1':
        case 'item11ParticipantCheckboxGroupMother':
        case 'item11ParticipantCheckboxGroupFather':
        case 'effortsToSupportMotherFosterRelationship7_change':
        case 'effortsToSupportFatherFosterRelationship7_change':

            var parms = {
                'input': ['All'],
                'itemName': 'item11',
                'validationRoutine': 'ValidateItem11',
                'validationType': 'Permanency',
                'storeId': 'CR_Permanency_CollectionStore'
            };

            runItemValidation(parms);

            break;

        default:

            var validationPlugin = new App.CaseReview.view.common.CRSValidationPlugin();
            var input = [section];
            
            validationPlugin.setValidationType('Permanency');
            validationPlugin.setValidationInput(input);
            validationPlugin.setStoreId('CR_Permanency_CollectionStore');

            validationPlugin.init(getAppController());

            break;
    }
}
var runWellbeingValidationRules = function (compObj, section) {

    switch (section) {

        case 'item12BApplicableMotherYes':
        case 'item12BApplicableMotherNo':
        case 'item12BApplicableFatherYes':
        case 'item12BApplicableFatherNo':
        case 'item12BParticipantCheckboxGroupMother':
        case 'item12BParticipantCheckboxGroupFather':
        case 'item12BQuestion1':
        case 'item12BQuestion2':
        case 'item12BQuestion3':
        case 'item12BQuestion4':
        case 'item12BQuestion5':
        case 'question12A1Yes':
        case 'question12A1No':
        case 'question12A2Yes':
        case 'question12A2No':
        case 'question12A2NA':
        case 'question12B1Yes':
        case 'question12B1No':
        case 'question12B1NA':
        case 'question12B2Yes':
        case 'question12B2No':
        case 'question12B2NA':
        case 'question12B3Yes':
        case 'question12B3No':
        case 'question12B3NA':
        case 'question12B4Yes':
        case 'question12B4No':
        case 'question12B4NA':
        case 'question12C1Yes':
        case 'question12C1No':
        case 'question12C2Yes':
        case 'question12C2No':
        case 'question12C2NA':
        case 'item12CYes':
        case 'item12CNo':
        case 'item12APanel':
        case 'ValidateItem12A':
        case 'ValidateItem12B':
        case 'ValidateItem12C':
            
            var parms = {
                'input': ['All'],
                'itemName': 'item12',
                'validationRoutine': 'ValidateItem12',
                'validationType': 'Wellbeing',
                'storeId': 'CR_WellBeing_CollectionStore'
            };

            runItemValidation(parms);

            break;

        case 'question13AYes':
        case 'question13ANo':
        case 'question13ANA':
        case 'question13BYes':
        case 'question13BNo':
        case 'question13BNA':
        case 'question13CYes':
        case 'question13CNo':
        case 'question13CNA':
        case 'item13Question1':
        case 'item13Question2':
        case 'item13Question3':
        case 'item13Question4':
        case 'item13Question5':
        case 'item13Question6':
        case 'item13Question7':
        case 'item13ApplicableCases':
        case 'item13AConcerns':
        case 'item13AAnswers':
        case 'applicabilityQuestion13Yes':
        case 'applicabilityQuestion13No':
        case 'item13ParticipantCheckboxGroupMother':
        case 'item13ParticipantCheckboxGroupFather':
        case 'ValidateItem13':

            var parms = {
                'input': ['All'],
                'itemName': 'item13',
                'validationRoutine': 'ValidateItem13',
                'validationType': 'Wellbeing',
                'storeId': 'CR_WellBeing_CollectionStore'
            };

            runItemValidation(parms);

            break;

        case 'question14AYes':
        case 'question14ANo':
        case 'question14BYes':
        case 'question14BNo':
        case 'question14BNA':
        case 'visitationFrequency1':
        case 'visitationFrequency2':
        case 'visitationFrequency3':
        case 'visitationFrequency4':
        case 'visitationFrequency5':
        case 'visitationFrequency6':
        case 'ValidateItem14':
            
            var parms = {
                'input': ['All'],
                'itemName': 'item14',
                'validationRoutine': 'ValidateItem14',
                'validationType': 'Wellbeing',
                'storeId': 'CR_WellBeing_CollectionStore'
            };

            runItemValidation(parms);

            break;

        case 'applicabilityQuestion15Yes':
        case 'applicabilityQuestion15No':
        case 'question15A2Yes':
        case 'question15A2No':
        case 'question15A2NA':
        case 'question15B2Yes':
        case 'question15B2No':
        case 'question15B2NA':
        case 'question15CYes':
        case 'question15CNo':
        case 'question15CNA':
        case 'question15DYes':
        case 'question15DNo':
        case 'question15DNA':
        case 'item15Question1':
        case 'item15Question2':
        case 'item15Question3':
        case 'item15Question4':
        case 'item15Question5':
        case 'item15Question6':
        case 'motherVisitationFrequency1':
        case 'motherVisitationFrequency2':
        case 'motherVisitationFrequency3':
        case 'motherVisitationFrequency4':
        case 'motherVisitationFrequency5':
        case 'motherVisitationFrequency6':
        case 'motherVisitationFrequency7':
        case 'fatherVisitationFrequency1':
        case 'fatherVisitationFrequency2':
        case 'fatherVisitationFrequency3':
        case 'fatherVisitationFrequency4':
        case 'fatherVisitationFrequency5':
        case 'fatherVisitationFrequency6':
        case 'fatherVisitationFrequency7':
        case 'item15ParticipantCheckboxGroupMother':
        case 'item15ParticipantCheckboxGroupFather':
        case 'ValidateItem15':

            var parms = {
                'input': ['All'],
                'itemName': 'item15',
                'validationRoutine': 'ValidateItem15',
                'validationType': 'Wellbeing',
                'storeId': 'CR_WellBeing_CollectionStore'
            };

            runItemValidation(parms);

            break;

        case 'item16ApplicableYes':
        case 'item16ApplicableNo':
        case 'question16AYes':
        case 'question16ANo':
        case 'question16BYes':
        case 'question16BNo':
        case 'question16BNA':
        case 'ValidateItem16':

            var parms = {
                'input': ['All'],
                'itemName': 'item16',
                'validationRoutine': 'ValidateItem16',
                'validationType': 'Wellbeing',
                'storeId': 'CR_WellBeing_CollectionStore'
            };

            runItemValidation(parms);

            break;

        case 'item17Yes':
        case 'item17No':
        case 'item17A1Yes':
        case 'item17A1No':
        case 'item17A1NA':
        case 'item17A2Yes':
        case 'item17A2No':
        case 'item17A2NA':
        case 'medicalNeedsCriteria':
        case 'item17B1Yes':
        case 'item17B1No':
        case 'item17B1NA':
        case 'item17B2Yes':
        case 'item17B2No':
        case 'item17B2NA':
        case 'item17B3Yes':
        case 'item17B3No':
        case 'item17B3NA':
        case 'ValidateItem17':

            var parms = {
                'input': ['All'],
                'itemName': 'item17',
                'validationRoutine': 'ValidateItem17',
                'validationType': 'Wellbeing',
                'storeId': 'CR_WellBeing_CollectionStore'
            };

            runItemValidation(parms);

            break;

        case 'item18ApplicableYes':
        case 'item18ApplicableNo':
        case 'item18AYes':
        case 'item18ANo':
        case 'item18BYes':
        case 'item18BNo':
        case 'item18BNA':
        case 'item18CYes':
        case 'item18CNo':
        case 'item18CNA':
        case 'ValidateItem18':

            var parms = {
                'input': ['All'],
                'itemName': 'item18',
                'validationRoutine': 'ValidateItem18',
                'validationType': 'Wellbeing',
                'storeId': 'CR_WellBeing_CollectionStore'
            };

            runItemValidation(parms);

            break;

        default:

            var validationPlugin = new App.CaseReview.view.common.CRSValidationPlugin();
            var input = [section];
            
            if (Ext.isEmpty(validations[section])) {

                validationPlugin.setValidationType('Wellbeing');
                validationPlugin.setValidationInput(input);
                validationPlugin.setStoreId('CR_WellBeing_CollectionStore');

                validations[section] = Ext.isEmpty(validations[section]) ? 1 : validations[section] + 1;

                validationPlugin.init(getAppController());
            }

            break;
    }
}