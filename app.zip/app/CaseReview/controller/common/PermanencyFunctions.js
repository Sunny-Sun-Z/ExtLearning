﻿Ext.define('App.casereview.controller.common.PermanencyFunctions', {
    extend: 'Ext.Base',
    singleton: true,
    alternateClassName: 'PermanencyFunctions',
    permanencyPanel: undefined,
    saveEnabled: false,
    fireFocusEvent: function (container) {

        if (this.saveEnabled) {
            return;
        }

        container.ownerCt.fireEvent('focus', container.ownerCt, null);
    },
    applyOverrideForItems: function (parms,cmp, newValue, oldValue) {

        Ext.apply(parms, {
            control: cmp,
            newValue: newValue,
            oldValue: oldValue
        });

        return parms;
    },
    applyOverrideGeneric: function (parms, parms2) {

        Ext.apply(parms, parms2);

        return parms;
    },
    handlePermanencyPanelBeforerender: function () {

        //this.checkController();

        // 
        // Create viewModel
        //        
        var vModel = createViewModel('permanency');

        window.permanencyViewModel = vModel;
    },
    handlePermanencyPanelAfterrender: function () {

        //this.checkController();

        pageLoadStatus['Permanency'] = 'rendered';
        //
        // Run validations for page for all items once on load
        //  
        var parms = {
            runValidations: true,
            dataChanged: false
        };

        runPermanencyRules(getAppController(), sr.Constants.AllFields, parms);

        Ext.resumeLayouts(true);
    },
    handlePermanencyPanelBoxready: function () {

        //this.checkController();

        layoutRuns['Permanency'] = true;
        appDataEvent.permanency.initialLoad = false;
        isTabChange = false;
        
        getAppController().resumeEvents(true);
    },
    handlePermanencyOutcomeRatingAfterrender: function (outcomeCode) {

        //this.checkController();

        if (outcomeCode == 3) {

            getAppController().getPermanencyOutcome1Rating().getOutcomeRating(outcomeCode);
        }
        
        if (outcomeCode == 4) {

            getAppController().getPermanencyOutcome2Rating().getOutcomeRating(outcomeCode);
        }
    },
    handlePermanencyRatingAfterrender: function (parmsIn) {

        parmsIn.ratingComponent.getItemRating();
    },
    handlePermanencyBlur: function (parmsIn) {

        //this.checkController();

        var dataParms = {
            collectionName: parmsIn.collectionName,
            propertyName: parmsIn.propertyName,
            itemCode: parmsIn.itemCode
        },
        savedValue = getSavedPropertyValue(dataParms),
        newValue = parmsIn.control.getValue();

        appDataEvent.permanency.changeByUserAction = isDataChangedByUser(parmsIn.control, parmsIn.control.getValue(), savedValue);

        if (!appDataEvent.permanency.changeByUserAction) {

            return;
        }

        if (pageLoadStatus['Permanency'] == 'rendered') {

            if (newValue) {

                var fields = [],
                    vmFields = [],
                    vmField = {},
                    field = {};

                vmField[parmsIn.vmFieldName] = newValue;
                field[parmsIn.propertyName] = newValue;

                fields.push(field);
                fields.push({ 'DataState': 0 });

                vmFields.push(vmField);

                var parms = {
                    currentVal: newValue,
                    storeId: parmsIn.storeId,
                    fields: fields,
                    vmFields: vmFields,
                    control: parmsIn.control,
                    runValidations: parmsIn.runValidations,
                    itemCode: parmsIn.control.ownerCt.ownerCt.ItemCode,
                    outcomeCode: parmsIn.control.ownerCt.ownerCt.OutcomeCode,
                    dataChanged: parmsIn.dataChanged
                };

                parms = getStatusParms(parms, parmsIn.ratingItemId);

                initValidations(parmsIn.itemName);

                //this.checkController();

                runPermanencyRules(getAppController(), parmsIn.methodName, parms);
            }
        }
    },
    handlePermanencyChange: function (parmsIn) {

        var dataParms = {
            collectionName: parmsIn.collectionName,
            propertyName: parmsIn.propertyName,
            itemCode: parmsIn.itemCode
        };

        var savedValue = getSavedPropertyValue(dataParms);

        appDataEvent.permanency.changeByUserAction = isDataChangedByUser(parmsIn.control, parmsIn.newValue, savedValue);

        if (!appDataEvent.permanency.changeByUserAction) {

            return;
        }

        if (pageLoadStatus['Permanency'] == 'rendered') {

            if (!Ext.isEmpty(parmsIn.newValue)) {

                if (parmsIn.newValue == 6) {

                    getAppController().getLivingArragmentExplained().enable();
                }

                var fields = [],
                    vmFields = [],
                    vmField = {},
                    field = {};

                vmField[parmsIn.vmFieldName] = parmsIn.newValue;
                field[parmsIn.propertyName] = parmsIn.newValue;

                fields.push(field);

                field = { 'DataState': 0 };
                fields.push(field);

                vmFields.push(vmField);

                var parms = {
                    currentVal: parmsIn.newValue,
                    storeId: parmsIn.storeId,
                    fields: fields,
                    vmFields: vmFields,
                    control: parmsIn.control,
                    runValidations: parmsIn.runValidations,
                    dataChanged: parmsIn.dataChanged
                };

                parms = getStatusParms(parms, parmsIn.ratingItemId);

                initValidations(parmsIn.itemName);

                runPermanencyRules(getAppController(), parmsIn.methodName, parms);

                if (!Ext.isEmpty(parmsIn.parentForm)) {
                    parmsIn.parentForm.fireEvent('focus', parmsIn.parentForm, null);
                }
            }
        }        
    },
    handleRadioGroupChange: function (parmsIn) {

        var keys = getObjectKeys(parmsIn.newValue),
            inputValue = parmsIn.newValue[keys[0]];

        if (inputValue == 126) {

            return;
        }

        appDataEvent.permanency.changeByUserAction = isDataChangedByUser(parmsIn.control, parmsIn.newValue);

        if (!appDataEvent.permanency.changeByUserAction) {

            return;
        }

        if (pageLoadStatus['Permanency'] == 'rendered') {

            var parms = getCheckboxSelections(parmsIn.newValue, parmsIn.groupName, 'MultiAnswer');

            parms = getStatusParms(parms, parmsIn.ratingItemId);

            var parms2 = {
                control: parmsIn.control,
                runValidations: parmsIn.runValidations,
                dataChanged: parmsIn.dataChanged,
                groupMembers: getCodeDescriptionGroup(parmsIn.groupName)
            };

            parms = concatJsonObjects(parms, [parms2]);

            initValidations(parmsIn.itemName);
            
            if (parms.fields.length > 0) {

                var otherCheck = parms.fields.filter(function (item) {

                    return item.CodeDescriptionID == 170;
                }),
                comments = getAppController().getEfforts11A1Comments();

                if (otherCheck && otherCheck.length > 0) {

                    comments.enable();

                    runPermanencyRules(getAppController(), parmsIn.code170Method, parms);

                    return;
                }
            }

            runPermanencyRules(getAppController(), parmsIn.methodName, parms);
        }
    },
    handleRadioGroupItemChange: function (parmsIn) {

        if (parmsIn.contol.checked) {

            parmsIn.componentToEnable.enable();
        }

        if (pageLoadStatus['Permanency'] == 'rendered') {

            var fields = [],
                field = {
                    CodeDescriptionID: parmsIn.control.inputValue,
                    AnswerCode: 1,
                    KeyField: 'CodeDescriptionID',
                    GroupName: parmsIn.groupName
                };

            if (parmsIn.newValue) {

                fields.push(field);

                var parms = {
                    currentVal: newValue,
                    storeId: parmsIn.storeId,
                    fields: fields,
                    fieldType: parmsIn.fieldType,
                    control: parmsIn.control,
                    runValidations: parmsIn.runValidations,
                    dataChanged: parmsIn.dataChanged
                };

            } else {

                field.AnswerCode = 0;

                fields.push(field);

                var parms = {
                    currentVal: newValue,
                    storeId: parmsIn.storeId,
                    fields: fields,
                    fieldType: parmsIn.fieldType,
                    control: parmsIn.control,
                    runValidations: parmsIn.runValidations,
                    dataChanged: parmsIn.dataChanged
                };
            }

            parms = getStatusParms(parms, parmsIn.ratingItemId);

            initValidations(parmsIn.itemName);

            runPermanencyRules(getAppController(), parmsIn.methodName, parms);
        }
    },
    handlePermanencyComponentChange: function (parmsIn) {

        if (parmsIn.control.checked) {

            parmsIn.component.enable();
        }
    },
    handleQuestion7AYesAfterrender: function (parmsIn) {

        //this.checkController();
        
        var parms = {
            runValidations: true,
            dataChanged: false
        };

        parms = getStatusParms(parms, 'permanencyItem7Rating');

        runPermanencyRules(getAppController(), 'question7AYes', parms);
    },
    handleGridAfterrender: function (parmsIn) {

        //this.checkController();

        var parms = {
            runValidations: parmsIn.runValidations,
            dataChanged: parmsIn.dataChanged
        };

        parms = getStatusParms(parms, parmsIn.ratingItemId);

        runPermanencyRules(getAppController(), parmsIn.methodName, parms);
    },
    handleGridEdit: function (parmsIn) {

        var parms = {
            runValidations: parmsIn.runValidations,
            dataChanged: parmsIn.dataChanged,
            ratingItemId: parmsIn.ratingItemId,
            data: parmsIn.data,
            storeId: parmsIn.storeId,
            recordType: parmsIn.recordType
        };

        parms = getStatusParms(parms, parmsIn.ratingItemId);

        runPermanencyRules(getAppController(), parmsIn.methodName, parms);
    },
    handlePreapplicabilityChange: function (parmsIn) {

        var dataParms = {
            control: parmsIn.control,
            newValue: parmsIn.newValue,
            oldValue: parmsIn.oldValue,
            groupName: parmsIn.groupName
        },
        result = checkIfMultiAnswerChangedByUser(dataParms);

        appDataEvent.permanency.changeByUserAction = result.isUserAction;

        if (!appDataEvent.permanency.changeByUserAction) {

            return;
        }

        var newKeys = getObjectKeys(result.selectedItem);

        if (newKeys.length > 0) {

            var cmp = parmsIn.control.queryBy(function (radio) {

                return radio.inputId == newKeys[0];
            });

            deselectPrevChoices(cmp[0]);

            var parms = {
                currentVal: parmsIn.newValue,
                itemName: parmsIn.itemName,
                pageName: parmsIn.pageName,
                ratingId: parmsIn.ratingItemId,
                groupName: parmsIn.groupName,
                groupMembers: parmsIn.groupMembers,
                dataChanged: parmsIn.dataChanged,
                section: parmsIn.sectionName,
                validationMethod: parmsIn.validationMethod,
                groupItemName: parmsIn.groupItemName,
                newValue: parmsIn.newValue,
                oldValue: parmsIn.oldValue
            };

            processPermanencyPreApplicability(parmsIn.control, parms);

        } else {

            return;
        }
    },
    handleRelativeLocationChange: function (parmsIn) {

        if (pageLoadStatus['Permanency'] == 'rendered') {

            var fields = [];

            if (parmsIn.newValue) {

                var field = { 'CodeDescriptionID': parmsIn.control.inputValue, 'AnswerCode': 1, 'KeyField': 'CodeDescriptionID' };

                fields.push(field);

            } else {

                var field = { 'CodeDescriptionID': parmsIn.control.inputValue, 'AnswerCode': 0, 'KeyField': 'CodeDescriptionID' };

                fields.push(field);
            }

            var parms = {
                currentVal: parmsIn.newValue,
                storeId: parmsIn.storeId,
                fields: fields,
                fieldType: parmsIn.fieldType,
                groupName: parmsIn.groupName,
                codeDescriptionIds: parmsIn.codeDescriptionIds,
                runValidations: parmsIn.runValidations,
                dataChanged: parmsIn.dataChanged
            };

            parms = getStatusParms(parms, parmsIn.ratingItemId);

            initValidations(parmsIn.itemName);

            runPermanencyRules(getAppController(), parmsIn.methodName, parms);
        }
    },
    handleRelativeLocationAfterrender: function (parmsIn) {

        if (parmsIn.value == 2) {

            parmsIn.control.setDisabled(false);
        }
    },
    handleQuestion11B1Change: function (parmsIn) {

        //this.checkController();

        if (pageLoadStatus['Permanency'] == 'rendered') {

            var parms = getCheckboxSelections(parmsIn.newValue, parmsIn.groupName, 'MultiAnswer');

            parms = getStatusParms(parms, parmsIn.ratingItemId);

            var parms2 = {
                control: parmsIn.control,
                runValidations: parmsIn.runValidations,
                dataChanged: parmsIn.dataChanged,
                groupMembers: parmsIn.groupName
            };

            parms = Ext.apply(parms, parms2);

            initValidations(parmsIn.itemName);

            if (parms.fields.length > 0) {

                var otherCheck = parms.fields.filter(function (item) {

                    return item.CodeDescriptionID == 177;
                }),
                comments = getAppController().getEfforts11B1Comments();
                
                if (otherCheck && otherCheck.length > 0) {

                    comments.enable();

                    runPermanencyRules(getAppController(), parmsIn.code177MethodName, parms);

                    return;
                }
            }

            runPermanencyRules(getAppController(), parmsIn.methodName, parms);
        }
    },
    handlePermanencyDischargeDateAfterrender: function () {

        //this.checkController();
        
        var fields = [],
            vmFields = [],
            vmField = { dischargeDate: getFosterDischargeDate() },
            field = { DischargeDate: getFosterDischargeDate() };

        fields.push(field);
        vmFields.push(vmField);


        var parms = {
            storeId: 'CR_Permanency_CollectionStore',
            fields: fields,
            vmFields: vmFields,
            runValidations: true,
            dataChanged: false
        };

        parms = getStatusParms(parms, 'permanencyItem6Rating');

        initValidations('Item6');

        runPermanencyRules(getAppController(), 'permanencyDischargeDate', parms);
    },
    handlePermanencyRecentFosterEntryDateAfterrender: function () {

        //this.checkController();

        var fields = [],
            field = { ChildMostRecentFosterEntryDate: getFosterEntryDate() };

        fields.push(field);

        var parms = {
            storeId: 'CR_Permanency_CollectionStore',
            fields: fields,
            runValidations: true,
            dataChanged: false
        };

        parms = getStatusParms(parms, 'permanencyItem6Rating');

        initValidations('Item6');

        runPermanencyRules(getAppController(), 'recentFosterEntryDate', parms);
    },
    handlePermanencyItem5G1GroupChange: function (parmsIn) {

        var isNoTermAndNAChecked = function () {

            var result = [],
                retVal = false,
                keys = getObjectKeys(parmsIn.newValue);

            Ext.each(keys, function (key) {

                result.push(parmsIn.newValue[key]);
            });

            var filteredResult = result.filter(function (val) {

                return val == 138 || val == 139;
            });

            if (filteredResult.length == 2) {

                retVal = true;
            }

            return retVal;
        }

        if (pageLoadStatus['Permanency'] == 'rendered') {

            if (isNoTermAndNAChecked()) {

                var lastSelection = getLastRadioSelection(parmsIn.newValue, parmsIn.oldValue),
                    lastSelectionKey = getObjectKeys(lastSelection)[0],
                    keys = getObjectKeys(parmsIn.newValue),
                    updatedValue = {},
                    compCollection, checkBox;

                Ext.each(keys, function (key) {

                    if (!(parmsIn.newValue[key] == 138 || parmsIn.newValue[key] == 139)) {

                        updatedValue[key] = parmsIn.newValue[key];
                    } else {

                        compCollection = parmsIn.control.items.items.filter(function (comp) {

                            return comp.inputId == key && comp.inputId != lastSelectionKey;
                        });

                        if (compCollection.length > 0) {

                            compCollection[0].setValue(false);
                        }
                    }
                });

                keys = getObjectKeys(lastSelection);

                Ext.each(keys, function (key) {

                    updatedValue[key] = lastSelection[key];
                });
            }

            var parms = getCheckboxSelections(updatedValue, 'TerminationExceptions', 'MultiAnswer');

            parms = getStatusParms(parms, 'permanencyItem5Rating');

            var parms2 = {
                control: parmsIn.control,
                runValidations: true,
                dataChanged: true,
                groupMembers: getCodeDescriptionGroup('TerminationExceptions')
            };

            parms = concatJsonObjects(parms, [parms2]);

            initValidations('Item5');

            runPermanencyRules(getAppController(), 'item5G1Group', parms);
        }
    },
    updatePermanencyDischargeDate: function (dateIn) {

        var permanencyColl = Ext.StoreManager.get('CaseReviewStore').getAt(0).data.CR_Permanency_Collection[0];

        permanencyColl.DischargeDate = dateIn;

        if (!Ext.isEmpty(dateIn)) {

            permanencyColl.IsDischargeDateNA = null;
            //
            // Update ViewModel
            //
            if (!Ext.isEmpty(window.permanencyViewModel)) {

                getAppController().getPermanencyDischargeDate().setValue(dateIn);

                window.permanencyViewModel.set('dischargeDate', dateIn);
                window.permanencyViewModel.set('isDischargeDateNA', 0);
            }
        }        
    },
    addChangeEventListeners: function (container) {

        var self = this;

        self.addPreApplicabilityChangeListeners(container);

        self.addItem4ChangeListeners(container);

        self.addItem5ChangeListeners(container);

        self.addItem6ChangeListeners(container);

        self.addItem7ChangeListeners(container);

        self.addItem8ChangeListeners(container);

        self.addItem9ChangeListeners(container);

        self.addItem10ChangeListeners(container);

        self.addItem11ChangeListeners(container);
        //
        // Determine if the form has focus. If it is, enable the save buttons.
        //
        container.ownerCt.on('focus', function (cmp, event, eOpts) {

            var buttons = cmp.query('savebuttons')[0].query('button');

            if (appDataEvent.permanency.initialLoad) {
                appDataEvent.permanency.initialLoad = false;
            }

            enableButtons(buttons);
        });
    },
    addPreApplicabilityChangeListeners: function (container) {

        var self = this;

        var parms8 = {
            control: null,
            dataChanged: true,
            ratingItemId: 'permanencyItem8Rating',
            itemName: 'Item8',
            pageName: 'Permanency',
            groupName: 'Applicability',
            sectionName: 'item8Question1',
            newValue: null,
            oldValue: null,
            groupItemName: 'Item 8',
            validationMethod: 'ValidateItem8',
            groupMembers: [57, 58, 59, 60, 61, 62]
        },
        parms11 = {
            control: null,
            dataChanged: true,
            ratingItemId: 'permanencyItem11Rating',
            itemName: 'Item11',
            pageName: 'Permanency',
            groupName: 'Applicability',
            sectionName: 'item11Question1',
            newValue: null,
            oldValue: null,
            groupItemName: 'Item 11',
            validationMethod: 'ValidateItem11',
            groupMembers: [63, 64, 65, 66, 67, 261]
        },
        addItemPreApplicabilityListeners = function (parmsIn,radio, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parms = {
                control: radio,
                newValue: newValue,
                oldValue: oldValue
            };

            parmsIn = Ext.apply(parmsIn, parms);

            self.handlePreapplicabilityChange(parmsIn);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        }
        //***************************************************************************
        // Item 8 - Pre-Applicability
        //***************************************************************************  
        container.queryById('item8Question1').on('change', function (radio, newValue, oldValue) {

            addItemPreApplicabilityListeners(parms8,radio, newValue, oldValue);
        });

        container.queryById('item8Question2').on('change', function (radio, newValue, oldValue) {

            addItemPreApplicabilityListeners(parms8, radio, newValue, oldValue);
        });

        container.queryById('item8Question3').on('change', function (radio, newValue, oldValue) {

            addItemPreApplicabilityListeners(parms8, radio, newValue, oldValue);
        });

        container.queryById('item8Question4').on('change', function (radio, newValue, oldValue) {

            addItemPreApplicabilityListeners(parms8, radio, newValue, oldValue);
        });

        container.queryById('item8Question5').on('change', function (radio, newValue, oldValue) {

            addItemPreApplicabilityListeners(parms8, radio, newValue, oldValue);
        });

        container.queryById('item8Question6').on('change', function (radio, newValue, oldValue) {

            addItemPreApplicabilityListeners(parms8, radio, newValue, oldValue);
        });

        //***************************************************************************
        // Item 11 - Pre-Applicability
        //***************************************************************************  
        container.queryById('item11Question1').on('change', function (radio, newValue, oldValue) {

            addItemPreApplicabilityListeners(parms11, radio, newValue, oldValue);
        });

        container.queryById('item11Question2').on('change', function (radio, newValue, oldValue) {

            addItemPreApplicabilityListeners(parms11, radio, newValue, oldValue);
        });

        container.queryById('item11Question3').on('change', function (radio, newValue, oldValue) {

            addItemPreApplicabilityListeners(parms11, radio, newValue, oldValue);
        });

        container.queryById('item11Question4').on('change', function (radio, newValue, oldValue) {

            addItemPreApplicabilityListeners(parms11, radio, newValue, oldValue);
        });

        container.queryById('item11Question5').on('change', function (radio, newValue, oldValue) {

            addItemPreApplicabilityListeners(parms11, radio, newValue, oldValue);
        });

        container.queryById('item11Question6').on('change', function (radio, newValue, oldValue) {

            addItemPreApplicabilityListeners(parms11, radio, newValue, oldValue);
        });
    },
    addItem4ChangeListeners: function (container) {

        var self = this;

        var parms4C1 = {
            control: null,
            groupName: 'PlacementApplicableCircumstances',
            itemCode: 5,
            runValidations: true,
            dataChanged: true,
            ratingItemId: 'permanencyItem4Rating',
            itemName: 'Item4',
            methodName: null,
            questionId: null,
            newValue: null,
            oldValue: null,
            componentToEnable: null,
            storeId: 'CR_MultiAnswer_CollectionStore'
        };

        // Question 4A
        container.queryById('question4A').on('change', function (cmp, newValue, oldValue) {

            var parms = {
                control: cmp,
                collectionName: 'permanency',
                propertyName: 'NumberOfPlacementSettings',
                itemCode: 5,
                vmFieldName: 'numberOfPlacementSettings',
                storeId: 'CR_Permanency_CollectionStore',
                runValidations: true,
                dataChanged: true,
                ratingItemId: 'permanencyItem4Rating',
                itemName: 'Item4',
                methodName: 'ValidateItem4',
                newValue: newValue,
                oldValue: oldValue,
                parentForm: container.ownerCt
            };

            self.handlePermanencyChange(parms);
        });

        // Question 4B
        container.queryById('item4QuestionB').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            input = {
                Component: parms2.control,
                FieldName: 'IsAgencyConcertedEffortsToInvolveTheChild',
                itemId: 'ValidateItem4',
                itemName: 'Item4',
                RatingItemId: 'permanencyItem4Rating'
            };

            processPermanencyClick(input);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // Question 4C
        container.queryById('item4CPlacementSetting').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            input = {
                Component: parms2.control,
                FieldName: 'IsCurrentPlacementSettingStable',
                itemId: 'ValidateItem4',
                itemName: 'Item4',
                RatingItemId: 'permanencyItem4Rating'
            };

            processPermanencyClick(input);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // Item4C1Group
        container.queryById('item4C1Group').on('change', function (cmp, newValue, oldValue) {

            var parms = {
                control: cmp,
                methodName: 'item4QuestionC1',
                questionId: 'item4QuestionC1',
                newValue: newValue,
                oldValue: oldValue
            };

            parms4C1 = Ext.apply(parms4C1, parms);

            self.handleRadioGroupChange(parms4C1);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // Item4C16
        container.queryById('item4C16').on('change', function (cmp, newValue, oldValue) {

            var parms = {
                control: cmp,
                methodName: 'item4C16',
                questionId: 'item4C16',
                newValue: newValue,
                oldValue: oldValue,
                componentToEnable: getAppController().getItem4C1placeApplicableCircumstancesOther()
            };

            parms4C1 = Ext.apply(parms4C1, parms);

            self.handleRadioGroupItemChange(parms4C1);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });
    },
    addItem5ChangeListeners: function (container) {

        var self = this;
        
        // Item 5 Applicable
        container.queryById('item5Applicability').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            input = {
                Component: parms2.control,
                FieldName: 'item5Applicable',
                ItemId: undefined,
                ItemName: 'Item5',
                RatingItemId: 'permanencyItem5Rating',
                ItemCode: 6,
                OutcomeCode: 3
            };

            processPermanencyItemApplicable(input);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // Question 5A3
        container.queryById('item5A3').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            input = {
                Component: parms2.control,
                FieldName: 'IsGoalSpecified',
                itemId: parms2.control.itemId,
                itemName: 'Item5',
                RatingItemId: 'permanencyItem5Rating'
            };

            processPermanencyClick(input);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // Question 5B
        container.queryById('item5B').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            comments = getAppController().getAllGoalsInTimelyMannerExplained(),
            otherField = {},
            input = {
                Component: parms2.control,
                FieldName: 'wereAllGoalsInTimelyManner',
                itemId: parms2.control.itemId,
                itemName: 'Item5',
                RatingItemId: 'permanencyItem5Rating'
            };

            if (parms2.control.inputValue == 2) {

                processPermanencyClick(input);
                comments.enable();
            } else {

                otherField['AllGoalsInTimelyMannerExplained'] = '';
                processPermanencyClick(input, otherField);
                comments.disable();
            }

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // Question 5C
        container.queryById('item5CGoalsAppropriate').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            comments = getAppController().getAllGoalsInTimelyMannerExplained(),
            otherField = {},
            input = {
                Component: parms2.control,
                FieldName: 'wereAllGoalsAppropriate',
                itemId: parms2.control.itemId,
                itemName: 'Item5',
                RatingItemId: 'permanencyItem5Rating'
            };

            if (parms2.control.inputValue == 2) {

                processPermanencyClick(input);
                comments.enable();
            } else {

                otherField['AllGoalsAppropriateExplained'] = '';
                processPermanencyClick(input, otherField);
                comments.disable();
            }

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // Question 5D
        container.queryById('item5D').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            input = {
                Component: parms2.control,
                FieldName: 'IsInFoster15OutOf22',
                itemId: parms2.control.itemId,
                itemName: 'Item5',
                RatingItemId: 'permanencyItem5Rating'
            };

            processPermanencyClick(input);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // Question 5E
        container.queryById('item5EParentalRights').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            input = {
                Component: parms2.control,
                FieldName: 'meetsTerminationOfParentalRights',
                itemId: parms2.control.itemId,
                itemName: 'Item5',
                RatingItemId: 'permanencyItem5Rating'
            };

            processPermanencyClick(input);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // Question 5F
        container.queryById('item5F').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            input = {
                Component: parms2.control,
                FieldName: 'meetsTerminationOfParentalRights',
                itemId: parms2.control.itemId,
                itemName: 'Item5',
                RatingItemId: 'permanencyItem5Rating'
            };

            processPermanencyClick(input);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // Question 5G
        container.queryById('item5GQuestion').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            input = {
                Component: parms2.control,
                FieldName: 'IsExceptionForTermination',
                itemId: parms2.control.itemId,
                itemName: 'Item5',
                RatingItemId: 'permanencyItem5Rating'
            };

            processPermanencyClick(input);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // Item5G1Group
        container.queryById('item5G1Group').on('change', function (cmp, newValue, oldValue) {

            var parms = {
                control: cmp,
                newValue: newValue,
                oldValue: oldValue
            };

            self.handlePermanencyItem5G1GroupChange(parms);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });
    },
    addItem6ChangeListeners: function (container) {

        var self = this;

        var parms6 = {
            control: null,
            collectionName: 'permanency',
            propertyName: null,
            itemCode: 7,
            vmFieldName: null,
            storeId: 'CR_Permanency_CollectionStore',
            runValidations: true,
            dataChanged: true,
            ratingItemId: 'permanencyItem6Rating',
            itemName: 'Item6',
            methodName: null,
            newValue: null,
            oldValue: null
        };
        // Item6A4CBGroup
        container.queryById('item6A4CBGroup').on('change', function (cmp, newValue, oldValue) {

            var parms = {
                control: cmp,
                groupName: 'PermanencyGoal1',
                itemCode: 7,
                runValidations: true,
                dataChanged: true,
                ratingItemId: 'permanencyItem6Rating',
                itemName: 'Item6',
                methodName: 'item6A4CBGroup',
                questionId: 'item6A4CBGroup',
                newValue: newValue,
                oldValue: oldValue
            };

            self.handleRadioGroupChange(parms);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // timeInCare
        container.queryById('timeInCare').on('change', function (cmp, newValue, oldValue) {

            var parms = {
                control: cmp,
                propertyName: 'TimeInCare',
                vmFieldName: 'timeInCare',
                methodName: 'timeInCare',
                newValue: newValue,
                oldValue: oldValue,
                parentForm: container.ownerCt
            };

            parms6 = Ext.apply(parms6, parms);

            self.handlePermanencyChange(parms6);
        });

        // question6A3
        container.queryById('question6A3').on('change', function (cmp, newValue, oldValue) {

            var selection = (newValue) ? cmp.inputValue : 0,
                parms = {
                    control: cmp,
                    propertyName: 'IsDischargeDateNA',
                    vmFieldName: 'isDischargeDateNA',
                    methodName: 'question6A3',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms6 = Ext.apply(parms6, parms);

            self.handlePermanencyChange(parms6);
        });

        // Question 6B
        container.queryById('item6BQuestion').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            comments = getAppController().getAgencyConcertedEffortsExplained(),
            otherField = {},
            input = {
                Component: parms2.control,
                FieldName: 'IsAgencyConcertedEfforts',
                itemId: undefined,
                itemName: 'Item6',
                RatingItemId: 'permanencyItem6Rating'
            };

            if (parms2.control.inputValue == 2) {

                processPermanencyClick(input);
                comments.enable();
            } else {

                otherField['AgencyConcertedEffortsExplained'] = '';
                processPermanencyClick(input, otherField);
                comments.disable();
            }

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // Question 6C
        container.queryById('item6CQuestion').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            comments = getAppController().getOtherPlannedConcertedEffortExplained(),
            otherField = {},
            input = {
                Component: parms2.control,
                FieldName: 'IsOtherPlannedConcertedEffort',
                itemId: undefined,
                itemName: 'Item6',
                RatingItemId: 'permanencyItem6Rating'
            };

            if (parms2.control.inputValue == 2) {

                processPermanencyClick(input);
                comments.enable();
            } else {

                otherField['OtherPlannedConcertedEffortExplained'] = '';
                processPermanencyClick(input, otherField);
                comments.disable();
            }

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // Question 6C2 Radio Group
        container.queryById('question6C2Grp').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            input = {
                Component: parms2.control,
                FieldName: null,
                itemId: parms2.control.itemId,
                itemName: 'Item6',
                RatingItemId: 'permanencyItem6Rating',
                OtherFields: []
            },
            permanencyStore = Ext.data.ChainedStore.create({
                source: 'CR_Permanency_CollectionStore'
            });

            getAppController().getQuestion6C2DocumentationDate().setValue(null);
            permanencyStore.getAt(0).data.OtherPlannedArrangementDocumentationDate = null;

            if (parms2.control.itemId == 'question6C2NA') {
                            
                permanencyStore.getAt(0).data.IsOtherPlannedArrangementNoDate = null;

                input.FieldName = 'IsOtherPlannedArrangementNA';
                processPermanencyClick(input);

                return;
            }

            if (parms2.control.itemId == 'question6C2NoDate') {

                permanencyStore.getAt(0).data.IsOtherPlannedArrangementNA = null;
                input.OtherFields = null;

                input.FieldName = 'IsOtherPlannedArrangementNoDate';
                processPermanencyClick(input);
            }

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // livingArragmentCode
        container.queryById('livingArragmentCode').on('change', function (cmp, newValue, oldValue) {

            var parms = {
                control: cmp,
                propertyName: 'LivingArrangementCode',
                vmFieldName: 'livingArrangementCode',
                methodName: 'livingArragmentCode',
                newValue: newValue,
                oldValue: oldValue,
                parentForm: container.ownerCt
            };

            parms6 = Ext.apply(parms6, parms);

            self.handlePermanencyChange(parms6);
        });
    },
    addItem7ChangeListeners: function (container) {

        var self = this;

        // Item 7 Applicable
        container.queryById('item7Applicability').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            input = {
                Component: parms2.control,
                FieldName: 'item7Applicable',
                ItemId: undefined,
                ItemName: 'Item7',
                RatingItemId: 'permanencyItem7Rating',
                ItemCode: 8,
                OutcomeCode: 4
            };

            processPermanencyItemApplicable(input);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // Question 7A
        container.queryById('item7AGrp').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            input = {
                Component: parms2.control,
                FieldName: 'IsPlacedWithAllSiblings',
                itemId: parms2.control.itemId,
                itemName: 'Item7',
                RatingItemId: 'permanencyItem7Rating'
            };

            processPermanencyClick(input);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // Question 7B
        container.queryById('item7BQuestion').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            input = {
                Component: parms2.control,
                FieldName: 'IsValidReasonForSeparation',
                itemId: parms2.control.itemId,
                itemName: 'Item7',
                RatingItemId: 'permanencyItem7Rating'
            };

            processPermanencyClick(input);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });
    },
    addItem8ChangeListeners: function (container) {

        var self = this,
            parms8 = {
                control: null,
                collectionName: 'permanency',
                propertyName: null,
                itemCode: 9,
                vmFieldName: null,
                storeId: 'CR_Permanency_CollectionStore',
                runValidations: true,
                dataChanged: true,
                ratingItemId: 'permanencyItem8Rating',
                itemName: 'Item8',
                methodName: null,
                newValue: null,
                oldValue: null
            };

        // Item 8 Applicable
        container.queryById('applicabilityQuestion8').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            input = {
                Component: parms2.control,
                FieldName: 'item8Applicable',
                ItemId: undefined,
                ItemName: 'Item8',
                RatingItemId: 'permanencyItem8Rating',
                ItemCode: 9,
                OutcomeCode: 4
            };

            processPermanencyItemApplicable(input);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // motherVisitFrequency1
        container.queryById('motherVisitFrequency1').on('change', function (radio, newValue, oldValue, eOpts) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms = {
                    control: radio,
                    propertyName: 'MotherVisitationFrequencyCode',
                    vmFieldName: 'motherVisitationFrequencyCode',
                    methodName: 'motherVisitFrequency1',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // motherVisitFrequency2
        container.queryById('motherVisitFrequency2').on('change', function (radio, newValue, oldValue, eOpts) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms = {
                    control: radio,
                    propertyName: 'MotherVisitationFrequencyCode',
                    vmFieldName: 'motherVisitationFrequencyCode',
                    methodName: 'motherVisitFrequency2',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // motherVisitFrequency3
        container.queryById('motherVisitFrequency3').on('change', function (radio, newValue, oldValue, eOpts) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms = {
                    control: radio,
                    propertyName: 'MotherVisitationFrequencyCode',
                    vmFieldName: 'motherVisitationFrequencyCode',
                    methodName: 'motherVisitFrequency3',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // motherVisitFrequency4
        container.queryById('motherVisitFrequency4').on('change', function (radio, newValue, oldValue, eOpts) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms = {
                    control: radio,
                    propertyName: 'MotherVisitationFrequencyCode',
                    vmFieldName: 'motherVisitationFrequencyCode',
                    methodName: 'motherVisitFrequency4',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // motherVisitFrequency5
        container.queryById('motherVisitFrequency5').on('change', function (radio, newValue, oldValue, eOpts) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms = {
                    control: radio,
                    propertyName: 'MotherVisitationFrequencyCode',
                    vmFieldName: 'motherVisitationFrequencyCode',
                    methodName: 'motherVisitFrequency5',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // motherVisitFrequency6
        container.queryById('motherVisitFrequency6').on('change', function (radio, newValue, oldValue, eOpts) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms = {
                    control: radio,
                    propertyName: 'MotherVisitationFrequencyCode',
                    vmFieldName: 'motherVisitationFrequencyCode',
                    methodName: 'motherVisitFrequency6',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // motherVisitFrequency7
        container.queryById('motherVisitFrequency7').on('change', function (radio, newValue, oldValue, eOpts) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms = {
                    control: radio,
                    propertyName: 'MotherVisitationFrequencyCode',
                    vmFieldName: 'motherVisitationFrequencyCode',
                    methodName: 'motherVisitFrequency7',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // Question 8A
        container.queryById('item8AQuestion').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            parms = {
                control: parms2.control,
                propertyName: 'IsSufficientFrequencyForMotherVisitation',
                vmFieldName: 'isSufficientFrequencyForMotherVisitation',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                parentForm: container.ownerCt
            };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // Question 8B
        container.queryById('item8BQuestion').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            parms = {
                control: parms2.control,
                propertyName: 'IsSufficientFrequencyForFatherVisitation',
                vmFieldName: 'isSufficientFrequencyForFatherVisitation',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                parentForm: container.ownerCt
            };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // Question 8C
        container.queryById('item8CQuestion').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            parms = {
                control: parms2.control,
                propertyName: 'IsSufficientQualityForMotherVisitation',
                vmFieldName: 'isSufficientQualityForMotherVisitation',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                parentForm: container.ownerCt
            };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // fatherVisitFrequency1
        container.queryById('fatherVisitFrequency1').on('change', function (radio, newValue, oldValue, eOpts) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms = {
                    control: radio,
                    propertyName: 'FatherVisitationFrequencyCode',
                    vmFieldName: 'fatherVisitationFrequencyCode',
                    methodName: 'fatherVisitFrequency1',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // fatherVisitFrequency2
        container.queryById('fatherVisitFrequency2').on('change', function (radio, newValue, oldValue, eOpts) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms = {
                    control: radio,
                    propertyName: 'FatherVisitationFrequencyCode',
                    vmFieldName: 'fatherVisitationFrequencyCode',
                    methodName: 'fatherVisitFrequency2',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // fatherVisitFrequency3
        container.queryById('fatherVisitFrequency3').on('change', function (radio, newValue, oldValue, eOpts) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms = {
                    control: radio,
                    propertyName: 'FatherVisitationFrequencyCode',
                    vmFieldName: 'fatherVisitationFrequencyCode',
                    methodName: 'fatherVisitFrequency3',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // fatherVisitFrequency4
        container.queryById('fatherVisitFrequency4').on('change', function (radio, newValue, oldValue, eOpts) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms = {
                    control: radio,
                    propertyName: 'FatherVisitationFrequencyCode',
                    vmFieldName: 'fatherVisitationFrequencyCode',
                    methodName: 'fatherVisitFrequency4',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // fatherVisitFrequency5
        container.queryById('fatherVisitFrequency5').on('change', function (radio, newValue, oldValue, eOpts) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms = {
                    control: radio,
                    propertyName: 'FatherVisitationFrequencyCode',
                    vmFieldName: 'fatherVisitationFrequencyCode',
                    methodName: 'fatherVisitFrequency5',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // fatherVisitFrequency6
        container.queryById('fatherVisitFrequency6').on('change', function (radio, newValue, oldValue, eOpts) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms = {
                    control: radio,
                    propertyName: 'FatherVisitationFrequencyCode',
                    vmFieldName: 'fatherVisitationFrequencyCode',
                    methodName: 'fatherVisitFrequency6',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // fatherVisitFrequency7
        container.queryById('fatherVisitFrequency7').on('change', function (radio, newValue, oldValue, eOpts) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms = {
                    control: radio,
                    propertyName: 'FatherVisitationFrequencyCode',
                    vmFieldName: 'fatherVisitationFrequencyCode',
                    methodName: 'fatherVisitFrequency7',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // Question 8D
        container.queryById('item8DQuestion').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            parms = {
                control: parms2.control,
                propertyName: 'IsSufficentQualityForFatherVisitation',
                vmFieldName: 'isSufficentQualityForFatherVisitation',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                parentForm: container.ownerCt
            };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // siblingVisitFrequency2
        container.queryById('siblingVisitFrequency2').on('change', function (radio, newValue, oldValue, eOpts) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms = {
                    control: radio,
                    propertyName: 'SiblingVisitationFrequencyCode',
                    vmFieldName: 'siblingVisitationFrequencyCode',
                    methodName: 'siblingVisitFrequency2',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // siblingVisitFrequency3
        container.queryById('siblingVisitFrequency3').on('change', function (radio, newValue, oldValue, eOpts) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms = {
                    control: radio,
                    propertyName: 'SiblingVisitationFrequencyCode',
                    vmFieldName: 'siblingVisitationFrequencyCode',
                    methodName: 'siblingVisitFrequency3',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // siblingVisitFrequency4
        container.queryById('siblingVisitFrequency4').on('change', function (radio, newValue, oldValue, eOpts) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms = {
                    control: radio,
                    propertyName: 'SiblingVisitationFrequencyCode',
                    vmFieldName: 'siblingVisitationFrequencyCode',
                    methodName: 'siblingVisitFrequency4',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // siblingVisitFrequency5
        container.queryById('siblingVisitFrequency5').on('change', function (radio, newValue, oldValue, eOpts) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms = {
                    control: radio,
                    propertyName: 'SiblingVisitationFrequencyCode',
                    vmFieldName: 'siblingVisitationFrequencyCode',
                    methodName: 'siblingVisitFrequency5',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // siblingVisitFrequency6
        container.queryById('siblingVisitFrequency6').on('change', function (radio, newValue, oldValue, eOpts) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms = {
                    control: radio,
                    propertyName: 'SiblingVisitationFrequencyCode',
                    vmFieldName: 'siblingVisitationFrequencyCode',
                    methodName: 'siblingVisitFrequency6',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // siblingVisitFrequency7
        container.queryById('siblingVisitFrequency7').on('change', function (radio, newValue, oldValue, eOpts) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms = {
                    control: radio,
                    propertyName: 'SiblingVisitationFrequencyCode',
                    vmFieldName: 'siblingVisitationFrequencyCode',
                    methodName: 'siblingVisitFrequency7',
                    newValue: selection,
                    oldValue: oldValue,
                    parentForm: container.ownerCt
                };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // Question 8E
        container.queryById('item8EQuestion').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            parms = {
                control: parms2.control,
                propertyName: 'IsSufficientFrequencyForSiblingVisitation',
                vmFieldName: 'isSufficientFrequencyForSiblingVisitation',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                parentForm: container.ownerCt
            };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });

        // Question 8F
        container.queryById('item8FQuestion').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            parms = {
                control: parms2.control,
                propertyName: 'IsSufficentQualityForSiblingVisitation',
                vmFieldName: 'isSufficentQualityForSiblingVisitation',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                parentForm: container.ownerCt
            };

            parms8 = Ext.apply(parms8, parms);

            self.handlePermanencyChange(parms8);
        });
    },
    addItem9ChangeListeners: function (container) {

        var self = this,
            parms9 = {
                control: null,
                collectionName: 'permanency',
                propertyName: null,
                itemCode: 10,
                vmFieldName: null,
                storeId: 'CR_Permanency_CollectionStore',
                runValidations: true,
                dataChanged: true,
                ratingItemId: 'permanencyItem9Rating',
                itemName: 'Item9',
                methodName: null,
                newValue: null,
                oldValue: null
            };

        // Item 9 Applicable
        container.queryById('applicabilityQuestion9').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            input = {
                Component: parms2.control,
                FieldName: 'item9Applicable',
                ItemId: undefined,
                ItemName: 'Item9',
                RatingItemId: 'permanencyItem9Rating',
                ItemCode: 10,
                OutcomeCode: 4
            };

            processPermanencyItemApplicable(input);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // Question 9A
        container.queryById('question9A').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            parms = {
                control: parms2.control,
                propertyName: 'IsConcertedEffortsForImportantConnections',
                vmFieldName: 'isConcertedEffortsForImportantConnections',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                parentForm: container.ownerCt
            };

            parms9 = Ext.apply(parms9, parms);

            self.handlePermanencyChange(parms9);
        });

        // Question 9B
        container.queryById('question9B').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            parms = {
                control: parms2.control,
                propertyName: 'IsSufficientInquiryForIndianTribe',
                vmFieldName: 'isSufficientInquiryForIndianTribe',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                parentForm: container.ownerCt
            };

            parms9 = Ext.apply(parms9, parms);

            self.handlePermanencyChange(parms9);
        });

        // Question 9C
        container.queryById('question9C').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            parms = {
                control: parms2.control,
                propertyName: 'IsTribeProvidedTimelyNotification',
                vmFieldName: 'isTribeProvidedTimelyNotification',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                parentForm: container.ownerCt
            };

            parms9 = Ext.apply(parms9, parms);

            self.handlePermanencyChange(parms9);
        });

        // Question 9D
        container.queryById('item9DQuestion').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            parms = {
                control: parms2.control,
                propertyName: 'IsAccordanceWithIndianChildWelfareAct',
                vmFieldName: 'isAccordanceWithIndianChildWelfareAct',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                parentForm: container.ownerCt
            };

            parms9 = Ext.apply(parms9, parms);

            self.handlePermanencyChange(parms9);
        });
    },
    addItem10ChangeListeners: function (container) {

        var self = this,
            parmsParent = {
                control: null,
                newValue: null,
                oldValue: null,
                storeId: 'CR_MultiAnswer_CollectionStore',
                fieldType: 'MultiAnswer',
                groupName: 'PlacementEffortConcernsMother',
                codeDescriptionIds: [156, 157, 158, 159],
                runValidations: true,
                dataChanged: false,
                itemName: 'Item10',
                methodName: null,
                ratingItemId: 'permanencyItem10Rating'
            },
            parmsItem10 = {
                control: null,
                collectionName: 'permanency',
                propertyName: null,
                itemCode: 11,
                vmFieldName: null,
                storeId: 'CR_Permanency_CollectionStore',
                runValidations: true,
                dataChanged: true,
                ratingItemId: 'permanencyItem10Rating',
                itemName: 'Item10',
                methodName: null,
                newValue: null,
                oldValue: null
            };

        // Item 10 Applicable
        container.queryById('applicabilityQuestion10').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            input = {
                Component: parms2.control,
                FieldName: 'item10Applicable',
                ItemId: undefined,
                ItemName: 'Item10',
                RatingItemId: 'permanencyItem10Rating',
                ItemCode: 11,
                OutcomeCode: 4
            };

            processPermanencyItemApplicable(input);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // placementEffortConcernsMother1
        container.queryById('placementEffortConcernsMother1').on('change', function (cmp, newValue, oldValue, eOpts) {

            var parms = {
                control: cmp,
                newValue: newValue,
                oldValue: oldValue,
                methodName: 'placementConcernsMother'
            };

            parmsParent = self.applyOverrideGeneric(parmsParent, parms);

            self.handleRelativeLocationChange(parmsParent);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // placementEffortConcernsMother2
        container.queryById('placementEffortConcernsMother2').on('change', function (cmp, newValue, oldValue, eOpts) {

            var parms = {
                control: cmp,
                newValue: newValue,
                oldValue: oldValue
            };

            parmsParent = self.applyOverrideGeneric(parmsParent, parms);

            self.handleRelativeLocationChange(parmsParent);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // placementEffortConcernsMother3
        container.queryById('placementEffortConcernsMother3').on('change', function (cmp, newValue, oldValue, eOpts) {

            var parms = {
                control: cmp,
                newValue: newValue,
                oldValue: oldValue
            };

            parmsParent = self.applyOverrideGeneric(parmsParent, parms);

            self.handleRelativeLocationChange(parmsParent);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // placementEffortConcernsMother4
        container.queryById('placementEffortConcernsMother4').on('change', function (cmp, newValue, oldValue, eOpts) {

            var parms = {
                control: cmp,
                newValue: newValue,
                oldValue: oldValue
            };

            parmsParent = self.applyOverrideGeneric(parmsParent, parms);

            self.handleRelativeLocationChange(parmsParent);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // placementEffortConcernsFather1
        container.queryById('placementEffortConcernsFather1').on('change', function (cmp, newValue, oldValue, eOpts) {

            var parms = {
                control: cmp,
                newValue: newValue,
                oldValue: oldValue,
                methodName: 'placementConcernsFather'
            };

            parmsParent = self.applyOverrideGeneric(parmsParent, parms);

            self.handleRelativeLocationChange(parmsParent);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // placementEffortConcernsFather2
        container.queryById('placementEffortConcernsFather2').on('change', function (cmp, newValue, oldValue, eOpts) {

            var parms = {
                control: cmp,
                newValue: newValue,
                oldValue: oldValue
            };

            parmsParent = self.applyOverrideGeneric(parmsParent, parms);

            self.handleRelativeLocationChange(parmsParent);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // placementEffortConcernsFather3
        container.queryById('placementEffortConcernsFather3').on('change', function (cmp, newValue, oldValue, eOpts) {

            var parms = {
                control: cmp,
                newValue: newValue,
                oldValue: oldValue
            };

            parmsParent = self.applyOverrideGeneric(parmsParent, parms);

            self.handleRelativeLocationChange(parmsParent);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // placementEffortConcernsFather4
        container.queryById('placementEffortConcernsFather4').on('change', function (cmp, newValue, oldValue, eOpts) {

            var parms = {
                control: cmp,
                newValue: newValue,
                oldValue: oldValue
            };

            parmsParent = self.applyOverrideGeneric(parmsParent, parms);

            self.handleRelativeLocationChange(parmsParent);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // Question 10A1
        container.queryById('item10A1Question').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            parms = {
                control: parms2.control,
                propertyName: 'IsRecentPlacementWithRelative',
                vmFieldName: 'isRecentPlacementWithRelative',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                parentForm: container.ownerCt
            };

            parmsItem10 = Ext.apply(parmsItem10, parms);

            self.handlePermanencyChange(parmsItem10);
        });

        // Question 10A2
        container.queryById('item10A2Question').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            parms = {
                control: parms2.control,
                propertyName: 'IsPlacementWithRelativeStable',
                vmFieldName: 'isPlacementWithRelativeStable',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                parentForm: container.ownerCt
            };

            parmsItem10 = Ext.apply(parmsItem10, parms);

            self.handlePermanencyChange(parmsItem10);
        });

        // Question 10B
        container.queryById('item10BQuestion').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            parms = {
                control: parms2.control,
                propertyName: 'IsConcertedEffortToLocateMaternalRelatives',
                vmFieldName: 'isConcertedEffortToLocateMaternalRelatives',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue
            };

            parmsItem10 = self.applyOverrideGeneric(parmsItem10, parms);

            if (parms2.control.inputValue == 1) {

                self.handleRelativeLocationChange(parmsItem10);

                var chkboxGroup = getAppController().getMotherEfforts();

                Ext.each(chkboxGroup.getBoxes(), function (checkbox) {

                    checkbox.setValue(null);
                });

                chkboxGroup.setDisabled(true);

                if (!Ext.isEmpty(container.ownerCt)) {
                    container.ownerCt.fireEvent('focus', container.ownerCt, null);
                }

                return;
            }

            if (parms2.control.inputValue == 2) {

                self.handlePermanencyChange(parmsItem10);

                var chkboxGroup = getAppController().getMotherEfforts();

                chkboxGroup.setDisabled(false);

                if (!Ext.isEmpty(container.ownerCt)) {
                    container.ownerCt.fireEvent('focus', container.ownerCt, null);
                }

                return;
            }

            if (parms2.control.inputValue == 3) {

                self.handlePermanencyChange(parmsItem10);

                var chkboxGroup = getAppController().getMotherEfforts();

                Ext.each(chkboxGroup.getBoxes(), function (checkbox) {

                    checkbox.setValue(null);
                });

                chkboxGroup.setDisabled(true);

                if (!Ext.isEmpty(container.ownerCt)) {
                    container.ownerCt.fireEvent('focus', container.ownerCt, null);
                }
            }
        });

        // Question 10C
        container.queryById('item10CQuestion').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            parms = {
                control: parms2.control,
                propertyName: 'IsConcertedEffortToLocatePaternalRelatives',
                vmFieldName: 'isConcertedEffortToLocatePaternalRelatives',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue
            };

            parmsItem10 = self.applyOverrideGeneric(parmsItem10, parms);

            if (parms2.control.inputValue == 1) {

                self.handlePermanencyChange(parmsItem10);

                var chkboxGroup = getAppController().getFatherEfforts();

                Ext.each(chkboxGroup.getBoxes(), function (checkbox) {

                    checkbox.setValue(null);
                });

                chkboxGroup.setDisabled(true);

                if (!Ext.isEmpty(container.ownerCt)) {
                    container.ownerCt.fireEvent('focus', container.ownerCt, null);
                }

                return;
            }

            if (parms2.control.inputValue == 2) {

                self.handlePermanencyChange(parmsItem10);

                var chkboxGroup = getAppController().getFatherEfforts();

                chkboxGroup.setDisabled(false);

                if (!Ext.isEmpty(container.ownerCt)) {
                    container.ownerCt.fireEvent('focus', container.ownerCt, null);
                }

                return;
            }

            if (parms2.control.inputValue == 3) {

                self.handlePermanencyChange(parmsItem10);

                var chkboxGroup = getAppController().getFatherEfforts();

                Ext.each(chkboxGroup.getBoxes(), function (checkbox) {

                    checkbox.setValue(null);
                });

                chkboxGroup.setDisabled(true);

                if (!Ext.isEmpty(container.ownerCt)) {
                    container.ownerCt.fireEvent('focus', container.ownerCt, null);
                }

                return;
            }
        });
    },
    addItem11ChangeListeners: function (container) {

        var self = this,
            parms = {
                control: null,
                collectionName: 'permanency',
                propertyName: null,
                itemCode: 12,
                vmFieldName: null,
                storeId: 'CR_Permanency_CollectionStore',
                runValidations: true,
                dataChanged: true,
                ratingItemId: 'permanencyItem11Rating',
                itemName: 'Item11',
                methodName: null,
                newValue: null,
                oldValue: null
            }

        // Item 11 Applicable
        container.queryById('item11Applicability').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            input = {
                Component: parms2.control,
                FieldName: 'item11Applicable',
                ItemId: undefined,
                ItemName: 'Item11',
                RatingItemId: 'permanencyItem11Rating',
                ItemCode: 12,
                OutcomeCode: 4
            };

            processPermanencyItemApplicable(input);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // Question 11A
        container.queryById('item11AQuestion').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            input = {
                control: parms2.control,
                propertyName: 'IsConcertedEffortMotherFosterRelationship',
                vmFieldName: 'isConcertedEffortMotherFosterRelationship',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                parentForm: container.ownerCt
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handlePermanencyChange(parms);
        });

        // question11A1
        container.queryById('question11A1').on('change', function (cmp, newValue, oldValue, eOpts) {

            if (!newValue) {

                return;
            }

            var parms3 = {
                    control: cmp,
                    groupName: 'EffortsToSupportMotherFosterRelationship',
                    itemCode: 12,
                    runValidations: true,
                    dataChanged: true,
                    ratingItemId: 'permanencyItem11Rating',
                    itemName: 'Item11',
                    methodName: 'item11Question1',
                    questionId: 'item11Question1',
                    newValue: newValue,
                    oldValue: oldValue,
                    code170Method: 'effortsToSupportMotherFosterRelationship7_change'
                };

            PermanencyFunctions.handleRadioGroupChange(parms3);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });

        // Question 11B
        container.queryById('item11BQuestion').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.permanency.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            input = {
                control: parms2.control,
                propertyName: 'IsConcertedEffortFatherFosterRelationship',
                vmFieldName: 'isConcertedEffortFatherFosterRelationship',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                parentForm: container.ownerCt
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handlePermanencyChange(parms);
        });

        // question11B1
        container.queryById('question11B1').on('change', function (cmp, newValue, oldValue, eOpts) {

            if (!newValue) {

                return;
            }

            var parms3 = {
                    control: cmp,
                    groupName: 'EffortsToSupportFatherFosterRelationship',
                    itemCode: 12,
                    runValidations: true,
                    dataChanged: true,
                    ratingItemId: 'permanencyItem11Rating',
                    itemName: 'Item11',
                    methodName: 'question11B1',
                    code177MethodName: 'effortsToSupportFatherFosterRelationship7_change',
                    newValue: newValue,
                    oldValue: oldValue
                };
        
            self.handleQuestion11B1Change(parms3);

            if (!Ext.isEmpty(container.ownerCt)) {
                container.ownerCt.fireEvent('focus', container.ownerCt, null);
            }
        });
    }
});