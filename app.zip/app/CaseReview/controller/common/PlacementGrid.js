﻿Ext.define('App.CaseReview.controller.common.PlacementGrid',
{
    extend: 'Ext.Base',
    constructor: function (controller) {
        var self = this;
        var grid = controller.getPlacementGrid(); 
        var gridAdd = sr.ItemIds.placementGridAddButton;
        var gridEdit = sr.ItemIds.placementGridEditButton;
        var gridDelete = sr.ItemIds.placementGridDeleteButton;

        var enableDisableHandler = function () {
            //var selections = grid.getSelectionModel().getSelection();
            //if (selections.length > 0) {
            //    var record = selections[0];
            //    if (record.get('ID_ASSTNCE_GRP_MBRS_SEQ') === 0 || grid.getStore().getCount() === 1)// the one we get sent starts with 0 but if another is added, we make it zero.
            //    {
            //        setTimeout(function () {
            //            gridDelete.disable();
            //            gridEdit.disable();
            //        }, 0);
            //    }
            //}
            //if (grid.getStore().getCount() > 9) {
            //    setTimeout(function () {
            //        gridAdd.disable();
            //    }, 0);
            //}

        };

        /* istanbul ignore next: can only be tested with a gui  */
        var addEdit = function (record) {

            var edit = Ext.create('App.CaseReview.view.common.PlacementHelper');
            Ext.create('App.CaseReview.controller.common.Placement')
                                .init(grid, record, edit);
        };

        var deleteRecord = function () {

            grid.plugins[0].fireEvent('recorddelete');

            var parms = {};
            parms['recordType'] = 'Grid';
            parms['storeId'] = grid.store.storeId;
            parms['runValidations'] = true;

            runPermanencyRules(getAppController(), 'placementGrid', parms);
        };

        controller.placementGridEventHandler = Ext.create('framework.controller.GridAddEditDeleteEventHandlers', controller.viewModel,
        {
            'grid': grid,
            'add': gridAdd,
            'edit': gridEdit,
            'del': gridDelete,
            'insertRecord': {}, // blank record
            addAction: addEdit,
            editAction: addEdit,
            deleteAction: deleteRecord
        });

        controller.control({
            '#placementGridAdd': {
                'enable': enableDisableHandler
            },
            '#placementGrid': {
                'selectionchange': enableDisableHandler
            }
        });

        /* istanbul ignore else  */
        if (window.jasmine) {
            self.enableDisableHandler = enableDisableHandler;
            self.addEdit = addEdit;
        }
    }
});