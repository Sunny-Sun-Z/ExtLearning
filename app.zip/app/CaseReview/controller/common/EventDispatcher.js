﻿Ext.define('App.casereview.controller.common.EventDispatcher', {
    extend: 'Ext.Base',
    singleton: true,
    alternateClassName: 'EventDispatcher',
    doHyperlinkClick: function (hLink) {

        var clickTarget = hLink.getClickTarget();

        if (Ext.isEmpty(clickTarget)) {

            return;
        }

        var targetLink = getCRSComponent(clickTarget.itemId);

        targetLink.el.fireEvent('click', targetLink);
    }
});