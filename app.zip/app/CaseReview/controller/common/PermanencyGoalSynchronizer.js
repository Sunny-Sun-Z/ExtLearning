﻿var syncGoalMultiAnswerStores = function (storeColl) {

    var syncedStore = [];

    var isPermanencyGoal = function (value) {

        if (value == 127 ||
           value == 128 ||
           value == 129 ||
           value == 130) {

            return true;
        }

        return false;
    };

    var currentGoals = getCurrentGoals();

    var filteredRec;
    var recordsToBeDeleted = [];

    Ext.each(storeColl.data.items, function (record) {

        if (isPermanencyGoal(record.data.CodeDescriptionID)) {

            if (currentGoals.length > 0) {

                filteredRec = currentGoals.filter(function (goal) {

                    return goal == record.data.CodeDescriptionID;
                });

                if (filteredRec.length > 0) {

                    syncedStore.push(record);
                } else {

                    recordsToBeDeleted.push(record);
                }
            }

        } else {

            syncedStore.push(record);
        }
    });
    //
    // Synchronize Ext Multi-Answer store
    //
    var extMultiAnswerStore = Ext.StoreMgr.get('CR_MultiAnswer_CollectionStore');

    if (!Ext.isEmpty(syncedStore)) {

        var index;

        Ext.each(recordsToBeDeleted, function (record) {

            index = extMultiAnswerStore.data.items.indexOf(record);

            if (index > -1) {

                extMultiAnswerStore.remove(record);
            }
        });
    }
    //
    // Synchronize Casereview Multi-Answer store
    //
    var casereviewMultiAnswerStore = Ext.StoreMgr.get('CaseReviewStore');

    if (!Ext.isEmpty(syncedStore)) {

        var index;

        Ext.each(recordsToBeDeleted, function (record) {

            index = casereviewMultiAnswerStore.getAt(0).data.CR_MultiAnswer_Collection.indexOf(record.data);

            if (index > -1) {

                casereviewMultiAnswerStore.getAt(0).data.CR_MultiAnswer_Collection.splice(index, 1);
            }
        });
    }

    return Ext.isEmpty(syncedStore) ? storeColl.data.items : syncedStore;
};
var availableForSelection = function (checkbox) {

    var filteredGoal;

    if (checkbox.ownerCt.itemId == "item6A4CBGroup") {

        var permanencyGoals = Ext.data.StoreManager.lookup('CR_Goal_CollectionStore').data.items;
        var currentGoals = [];

        Ext.each(permanencyGoals, function (goal) {

            if (goal.data.IsCurrentGoal == 1) {

                currentGoals.push(goal.data.GoalCode);
            }
        });

        if (checkbox.inputValue == 127) {

            filteredGoal = currentGoals.filter(function (goal) {

                return goal == 1;
            });

            return filteredGoal.length > 0 ? true : false;
        }

        if (checkbox.inputValue == 128) {

            filteredGoal = currentGoals.filter(function (goal) {

                return goal == 2;
            });

            return filteredGoal.length > 0 ? true : false;
        }

        if (checkbox.inputValue == 129) {

            filteredGoal = currentGoals.filter(function (goal) {

                return goal == 3;
            });

            return filteredGoal.length > 0 ? true : false;
        }

        if (checkbox.inputValue == 130) {

            filteredGoal = currentGoals.filter(function (goal) {

                return goal == 4;
            });

            return filteredGoal.length > 0 ? true : false;
        }

        return false;
    }

    return true;
};
var getCurrentGoals = function () {

    var permanencyGoals = Ext.data.StoreManager.lookup('CR_Goal_CollectionStore').data.items;
    var currentGoals = [];

    Ext.each(permanencyGoals, function (goal) {

        if (goal.data.IsCurrentGoal == 1) {

            if (goal.data.GoalCode == 1) {

                currentGoals.push(127);
            }

            if (goal.data.GoalCode == 2) {

                currentGoals.push(128);
            }

            if (goal.data.GoalCode == 3) {

                currentGoals.push(129);
            }

            if (goal.data.GoalCode == 4) {

                currentGoals.push(130);
            }
        }
    });

    return currentGoals;
}
var synchronizeGoalChanges = function () {

    var controller = getAppController();

    //
    // At this point, the Goal store is already updated. Now we need to save and update
    // the PermanencyViewModel.
    //
    var vModel = window.permanencyViewModel;

    vModel.data.goal1Code = getGoalCode();
    vModel.data.goal2Code = getGoal2Code();

    //
    // Refresh Item 5 Panel
    //
    var goal1Combo = controller.getPermanencyGoal1Selection();

    goal1Combo.setValue(vModel.data.goal1Code);

    var goal2Combo = controller.getPermanencyGoal2Selection();

    goal2Combo.setValue(vModel.data.goal2Code);

    //
    // Update viewModel and refresh Item 6 Panel
    //  
    vModel.data.permGoal1 = getPermGoalValue(127);
    vModel.data.permGoal2 = getPermGoalValue(128);
    vModel.data.permGoal3 = getPermGoalValue(129);
    vModel.data.permGoal4 = getPermGoalValue(130);

    var val;
    var checkboxGroup = controller.getItem6A4CBGroup();

    Ext.each(checkboxGroup.items.items, function (item) {

        val = getPermGoalValue(item.inputValue);

        item.setValue(val);
    });
}
var getPermGoalValue = function (val) {

    var result;
    var currentGoals = getCurrentGoals();

    var goals = currentGoals.filter(function (goal) {

        return goal == val;
    });

    if (goals.length > 0) {

        result = val;
    }

    return result == val ? true : false;
}
var getGoalCode = function () {

    var result;
    var vModel = window.permanencyViewModel;

    var goalColl = getCurrentGoals();

    if (goalColl.length > 0) {

        result = goalColl[0] == 127 ? 1 :
                 goalColl[0] == 128 ? 2 :
                 goalColl[0] == 129 ? 3 :
                 goalColl[0] == 130 ? 4 : undefined;
    }

    vModel.data.permanencyCollection.getAt(0).data.Goal1Code = result;

    return result;
}
var getGoal2Code = function () {

    var result = 5;
    var vModel = window.permanencyViewModel;

    var goalColl = getCurrentGoals();

    if (goalColl.length > 1) {

        result = goalColl[1] == 127 ? 1 :
                 goalColl[1] == 128 ? 2 :
                 goalColl[1] == 129 ? 3 :
                 goalColl[1] == 130 ? 4 : undefined;
    }

    vModel.data.permanencyCollection.getAt(0).data.Goal2Code = result;

    return result;
}