﻿Ext.define('App.CaseReview.controller.common.CreateOutcomeItem',
{
    extend: 'Ext.Base',
    singleton : true,
    alias : 'CreateOutcomeItem',
    addItem : function (item) {

        var tempOutcomeStore = null;

        if (Ext.isEmpty(item.OutcomeCode)) return;

        if (!Ext.isEmpty(Ext.data.StoreManager.get('CR_Outcome_CollectionStore'))) {

            tempOutcomeStore = Ext.data.ChainedStore.create({
                source: 'CR_Outcome_CollectionStore',
                filters: [
                    function(record) {
                        return record.get('OutcomeCode') == item.OutcomeCode;
                    }
                ]
            });
        }

        if (tempOutcomeStore.count() == 0) {

            var model = Ext.data.StoreManager.get('CR_Outcome_CollectionStore').add({});

            model[0].set("OutcomeCode", item.OutcomeCode);
            model[0].set("DataState", 0);
            model[0].set("CR_Item_Collection", [item]);

        } else {

            var tempItemCollection = tempOutcomeStore.getAt(0).data.CR_Item_Collection;

            if (!Ext.isEmpty(tempItemCollection)) {

                var tempItem = null;

                Ext.Array.forEach(tempItemCollection, function(record) {
                    if (record.ItemCode == item.ItemCode) {
                        tempItem = record;
                        Ext.Array.remove(tempItemCollection, record);
                    }
                });


                if (!Ext.isEmpty(tempItem)) {
                    for (var property in item) {
                        tempItem[property] = item[property];
                    }
                } else {
                    tempItem = item;
                }

                tempItemCollection.push(tempItem);

                //var tempOutcome = tempOutcomeStore.getAt(0);
                //var index = Ext.data.StoreManager.get('CR_Outcome_CollectionStore').findExact("ExtId", tempOutcome.data.ExtId);

                //Ext.data.StoreManager.get('CR_Outcome_CollectionStore').removeAt(index);

                //var model = Ext.data.StoreManager.get('CR_Outcome_CollectionStore').add({});

                //model[0].data = tempOutcome.data;
                //model[0].set("CR_Item_Collection", tempItemCollection);
            }
        }
    },

    addItemParticipant: function (outcomeCode, itemCode, itemParticipant) {

        var tempItem = getItem(itemCode, outcomeCode);

        if (Ext.isEmpty(tempItem)) {

            tempItem = { OutcomeCode: outcomeCode, DataState: 0, ItemCode: itemCode, CR_ItemParticipant_Collection: [itemParticipant] };

            this.addItem(tempItem);

            return;
        }

        if (!Ext.isEmpty(tempItem.CR_ItemParticipant_Collection)) {

            tempItem.CR_ItemParticipant_Collection.push(itemParticipant);

        } else {

            tempItem["CR_ItemParticipant_Collection"] = [itemParticipant];
        }

        //var tempItem = null;

        //var tempOutcomeStore = Ext.data.ChainedStore.create({
        //    source: 'CR_Outcome_CollectionStore',
        //    filters: [
        //        function (record) {
        //            return record.get('OutcomeCode') == outcomeCode;
        //        }
        //    ]
        //});

        //if (tempOutcomeStore.count() == 0) {
        //    tempItem = { OutcomeCode: outcomeCode, DataState: 0, ItemCode: itemCode, CR_ItemParticipant_Collection: [itemParticipant] };
        //} else {
            
        //    // If there is an outcome but no item available, adding item is not reflected in the final graph due to association issues.
        //    // So a workaround ( which works when there is no outcome and no item) has been provided below.
        //    // Transfer the outcome and its underlying data in a variable
        //    // Add the item to the item collection of the outcome 
        //    // and then drop the outcome from outcome store and add it back again.

        //    var tempOutcome = tempOutcomeStore.getAt(0);
        //    //var index = Ext.data.StoreManager.get('CR_Outcome_CollectionStore').findExact("ExtId", tempOutcome.id);
        //    //Ext.data.StoreManager.get('CR_Outcome_CollectionStore').removeAt(index);
            
        //    var tempItemCollection = tempOutcome.data.CR_Item_Collection;

        //    Ext.Array.forEach(tempItemCollection, function (record) {
        //        if (record.ItemCode == itemCode) {
        //            tempItem = record;
        //        }
        //    });

        //    if (!Ext.isEmpty(tempItem)) {
                
        //        if (!Ext.isEmpty(tempItem.CR_ItemParticipant_Collection)) {
        //            tempItem.CR_ItemParticipant_Collection.push(itemParticipant);
        //        } else {
        //            tempItem["CR_ItemParticipant_Collection"] = [itemParticipant];
        //        }
        //    } else {
                
        //        tempItem = { OutcomeCode: outcomeCode, DataState: 0, ItemCode: itemCode, CR_ItemParticipant_Collection: [itemParticipant] };
        //    }         
        //}

        //this.addItem(tempItem);
    },


    addNote: function (outcomeCode, itemCode, Note) {
                
        var tempItem = getItem(itemCode, outcomeCode);

        if (Ext.isEmpty(tempItem)) {

            tempItem = { OutcomeCode: outcomeCode, DataState: 0, ItemCode: itemCode, CR_Note_Collection: [Note] };

            this.addItem(tempItem);

            return;
        }

        if (!Ext.isEmpty(tempItem.CR_Note_Collection)) {

            tempItem.CR_Note_Collection.push(Note);

        } else {

            tempItem["CR_Note_Collection"] = [Note];
        }

    //    var tempItem = null;

    //    var tempOutcomeStore = Ext.data.ChainedStore.create({
    //        source: 'CR_Outcome_CollectionStore',
    //        filters: [
    //            function (record) {
    //                return record.get('OutcomeCode') == outcomeCode;
    //            }
    //        ]
    //    });

    //    if (tempOutcomeStore.count() == 0) {
    //        tempItem = { OutcomeCode: outcomeCode, DataState: 0, ItemCode: itemCode, CR_Note_Collection: [Note] };
    //    } else {


    //        // If there is an outcome but no item available, adding item is not reflected in the final graph due to association issues.
    //        // So a workaround ( which works when there is no outcome and no item) has been provided below.
    //        // Transfer the outcome and its underlying data in a variable
    //        // Add the item to the item collection of the outcome 
    //        // and then drop the outcome from outcome store and add it back again.

    //        var tempOutcome = tempOutcomeStore.getAt(0);
    //        //var index = Ext.data.StoreManager.get('CR_Outcome_CollectionStore').findExact("ExtId", tempOutcome.id);
    //        //Ext.data.StoreManager.get('CR_Outcome_CollectionStore').removeAt(index);


    //        var tempItemCollection = tempOutcome.data.CR_Item_Collection;

    //        Ext.Array.forEach(tempItemCollection, function (record) {
    //            if (record.ItemCode == itemCode) {
    //                tempItem = record;
    //            }
    //        });

    //        if (!Ext.isEmpty(tempItem)) {
                
    //            if (!Ext.isEmpty(tempItem.CR_Note_Collection)) {
    //                tempItem.CR_Note_Collection.push(Note);
    //            } else {
    //                tempItem["CR_Note_Collection"] = [Note];
    //            }
    //        } else {
                
    //            tempItem = { OutcomeCode: outcomeCode, DataState: 0, ItemCode: itemCode, CR_Note_Collection: [Note] };
    //        }
         
    //    }

        //    this.addItem(tempItem);

    }    
});