﻿Ext.define('App.casereview.controller.common.FacesheetFunctions', {
    extend: 'Ext.Base',
    singleton: true,
    saveEnabled: false,
    alternateClassName: 'FacesheetFunctions',
    handleFirstCaseOpeningDateChange: function (cmp) {

        var dataParms = {
            collectionName: 'facesheet',
            propertyName: 'FirstCaseOpeningDate'
        },
        savedValue = getSavedPropertyValue(dataParms),
        controller = getAppController(),
        newValue = cmp.getValue();

        appDataEvent.facesheet.changeByUserAction = isDataChangedByUser(cmp, newValue, savedValue);

        if (!appDataEvent.facesheet.changeByUserAction) {

            return;
        }

        if (Ext.isEmpty(Ext.Date.parse(cmp.getRawValue(), "m/d/Y", true))) {
            //
            // This is mandatory if the case is a Foster Care case
            //
            var caseType = getCaseType();

            if (!(caseType == 'Foster Case')) {

                return;
            }
        }

        if (pageLoadStatus['Facesheet'] == 'rendered') {

            var fields = [],
                vmFields = [],
                vmField = { firstCaseOpeningDate: cmp.getValue() },
                field = { FirstCaseOpeningDate: cmp.getValue() }
            ;

            fields.push(field);

            field = { DataState: 0 };
            fields.push(field);

            vmFields.push(vmField);

            var parms = {
                currentVal: cmp.getValue(),
                storeId: 'CR_FaceSheet_CollectionStore',
                fields: fields,
                vmFields: vmFields,
                itemName: 'facesheet',
                itemCode: 23,
                runValidations: true,
                dataChanged: true
            };

            if (!(layoutRuns.Facesheet)) {

                parms['allowLayout'] = true;
            }

            initValidations('Facesheet');

            runFacesheetRules(controller, 'firstCaseOpeningDate', parms);
        }
    },
    handleFosterEntryDateChange: function (cmp) {
        
        var dataParms = {
            collectionName: 'facesheet',
            propertyName: 'FosterEntryDate'
        };

        var savedValue = getSavedPropertyValue(dataParms),
            caseType = getCaseType(),
            controller = getAppController(),
            newValue = cmp.getValue();

        appDataEvent.facesheet.changeByUserAction = isDataChangedByUser(cmp, newValue, savedValue);

        if (!appDataEvent.facesheet.changeByUserAction) {

            return;

        }

        if (Ext.isEmpty(Ext.Date.parse(cmp.getRawValue(), "m/d/Y", true))) {
            //
            // This is mandatory if the case is a Foster Care case
            //
            if (!(caseType == 'Foster Case')) {

                return;
            }
        }

        if (pageLoadStatus['Facesheet'] == 'rendered') {

            var fields = [],
                vmFields = [],
                vmField = { fosterEntryDate: cmp.getValue() },
                field = { FosterEntryDate: cmp.getValue() }
            ;

            fields.push(field);

            field = { 'isFosterEntryDateNA': null };
            fields.push(field);

            field = { 'DataState': 0 };
            fields.push(field);

            vmFields.push(vmField);

            vmField = { 'isFosterEntryDateNA': null };
            vmFields.push(vmField);

            var parms = {
                currentVal: cmp.getValue(),
                storeId: 'CR_FaceSheet_CollectionStore',
                fields: fields,
                vmFields: vmFields,
                itemName: 'facesheet',
                itemCode: 23,
                runValidations: true,
                dataChanged: true
            };
            
            if (!(layoutRuns.Facesheet)) {

                parms['allowLayout'] = true;
            }

            initValidations('Facesheet');
            
            runFacesheetRules(controller, 'fosterEntryDate', parms);
        }

        if (caseType == 'Foster Case') {

            controller.getRecentFosterEntryDate().setValue(controller.getFosterEntryDate().getValue());
        }
    },
    handleIsFosterCareDateNAAfterrender: function (checkBox) {
        
        var caseType = getCaseType();

        if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

            var viewModel = window.facesheetViewModel;

            if (Ext.isEmpty(viewModel)) {

                viewModel = createViewModel('facesheet');

                window.facesheetViewModel = viewModel;
            }

            viewModel.set('isFosterEntryDateNA', checkBox.inputValue);

            checkBox.setReadOnly(true);
        }
    },
    handleEpisodeDischargeDateChange: function (cmp) {

        var dataParms = {
            collectionName: 'facesheet',
            propertyName: 'EpisodeDischargeDate'
        };

        var savedValue = getSavedPropertyValue(dataParms),
            caseType = getCaseType(),
            controller = getAppController(),
            newValue = cmp.getValue();

        appDataEvent.facesheet.changeByUserAction = isDataChangedByUser(cmp, newValue, savedValue);

        if (!appDataEvent.facesheet.changeByUserAction) {

            return;
        }

        if (Ext.isEmpty(Ext.Date.parse(cmp.getRawValue(), "m/d/Y", true))) {
            //
            // This is mandatory if the case is a Foster Care case
            //
            if (!(caseType == 'Foster Case')) {

                return;
            }
        }
        
        if (pageLoadStatus['Facesheet'] == 'rendered') {

            var fields = [],
                vmFields = [],
                vmField = { 'episodeDischargeDate': cmp.getValue() }
                field = { 'EpisodeDischargeDate': cmp.getValue() }
            ;

            fields.push(field);

            field = { 'IsEpisodeDischargeDateNA': null };
            fields.push(field);

            field = { 'IsEpisodeNotYetDischarged': null };
            fields.push(field);

            field = { 'DataState': 0 };
            fields.push(field);

            vmFields.push(vmField);

            vmField = { 'isEpisodeDischargeDateNA': null };
            vmFields.push(vmField);

            vmField = { 'isEpisodeNotYetDischarged': null };
            vmFields.push(vmField);

            var parms = {
                currentVal: cmp.getValue(),
                storeId: 'CR_FaceSheet_CollectionStore',
                fields: fields,
                vmFields: vmFields,
                itemName: 'facesheet',
                itemCode: 23,
                runValidations: true,
                dataChanged: true
            };

            if (!(layoutRuns.Facesheet)) {

                parms['allowLayout'] = true;
            }

            initValidations('Facesheet');

            runFacesheetRules(controller, 'episodeDischargeDate_change', parms);
        }

        if (caseType == 'Foster Case') {

            var dischargeDate = controller.getEpisodeDischargeDate().getValue();

            PermanencyFunctions.updatePermanencyDischargeDate(dischargeDate);
        }
    },
    handleDischargeNAAfterrender: function (checkBox) {

        var caseType = getCaseType();

        if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

            var viewModel = window.facesheetViewModel;

            if (Ext.isEmpty(viewModel)) {

                viewModel = createViewModel('facesheet');

                window.facesheetViewModel = viewModel;
            }

            viewModel.set('isEpisodeDischargeDateNA', checkBox.inputValue);

            checkBox.setReadOnly(true);
        }
    },
    handleCaseClosureDateChange: function (cmp) {

        var dataParms = {
            collectionName: 'facesheet',
            propertyName: 'CaseClosureDate'
        };

        var savedValue = getSavedPropertyValue(dataParms),
            caseType = getCaseType(),
            controller = getAppController(),
            newValue = cmp.getValue();

        appDataEvent.facesheet.changeByUserAction = isDataChangedByUser(cmp, newValue, savedValue);

        if (!appDataEvent.facesheet.changeByUserAction) {

            return;
        }

        if (Ext.isEmpty(Ext.Date.parse(cmp.getRawValue(), "m/d/Y", true))) {

            //
            // This is mandatory if the case is a Foster Care case
            //
            if (!(caseType == 'Foster Case')) {

                return;
            }
        }

        if (pageLoadStatus['Facesheet'] == 'rendered') {

            var fields = [],
                vmFields = [],
                vmField = { 'caseClosureDate': cmp.getValue() },
                field = { 'CaseClosureDate': cmp.getValue() };

            fields.push(field);

            field = { 'IsCaseClosureNotClosed': null };
            fields.push(field);

            field = { 'DataState': 0 };
            fields.push(field);

            vmFields.push(vmField);

            var parms = {
                currentVal: cmp.getValue(),
                storeId: 'CR_FaceSheet_CollectionStore',
                fields: fields,
                vmFields: vmFields,
                itemName: 'facesheet',
                itemCode: 23,
                runValidations: true,
                dataChanged: true
            };

            if (!(layoutRuns.Facesheet)) {

                parms['allowLayout'] = true;
            }

            initValidations('Facesheet');

            runFacesheetRules(controller, 'caseClosureDate_change', parms);
        }
    },
    handleQuestionMNarrativeBlur: function (cmp) {

        var dataParms = {
            collectionName: 'facesheet',
            propertyName: 'OtherCaseReason'
        };

        var savedValue = getSavedPropertyValue(dataParms),
            controller = getAppController(),
            newValue = cmp.getValue();

        appDataEvent.facesheet.changeByUserAction = isDataChangedByUser(cmp, cmp.getValue(), savedValue);

        if (!appDataEvent.facesheet.changeByUserAction) {

            return;
        }

        if (pageLoadStatus['Facesheet'] == 'rendered') {

            var fields = [],
                vmFields = [],
                vmField = { 'otherCaseReason': newValue },
                field = { 'OtherCaseReason': newValue };

            fields.push(field);

            field = { 'DataState': 0 };
            fields.push(field);

            vmFields.push(vmField);

            var parms = {
                currentVal: newValue,
                storeId: 'CR_FaceSheet_CollectionStore',
                fields: fields,
                vmFields: vmFields,
                itemName: 'facesheet',
                itemCode: 23,
                runValidations: true,
                dataChanged: true
            };

            initValidations('Facesheet');

            runFacesheetRules(controller, 'questionMNarrative', parms);
        }
    },
    handleCaseRsn14Afterrender: function () {

        var multiAnswerStore = getMultiAnswerStore('CaseReason'),
            isOptionSelected = false,
            comments = getAppController().getQuestionMNarrative(),
            rsn14Record = multiAnswerStore.data.items.filter(function (record) {

                return record.data['CodeDescriptionID'] == 14;
            });

        if (rsn14Record.length > 0) {

            isOptionSelected = true;
        }

        if (isOptionSelected) {

            comments.enable();
            comments.setReadOnly(false);

        } else {

            comments.disable();
        }
    },
    handleChildRaceChange: function (cmp) {

        if (cmp.checked) {
            //
            // Uncheck option 6
            //
            var option6 = cmp.ownerCt.items.items.filter(function (checkbox) {

                return checkbox.itemId == 'childRace6';
            });

            option6[0].setValue(null);
        }
    },
    handleChildRace6Change: function (cmp) {

        if (cmp.checked) {
            //
            // Uncheck all other boxes
            //
            Ext.each(cmp.ownerCt.items.items, function (checkbox) {

                if (!(checkbox.itemId == 'childRace6')) {

                    checkbox.setValue(null);
                }
            });
        }
    },
    handleGridEdit: function (itemId,storeId,record) {

        var parms = {
            itemName: 'facesheet',
            itemCode: 23,
            allowLayout: true,
            runValidations: true,
            data: record,
            dataChanged: true,
            storeId: storeId,
            recordType: 'Grid'            
        },
        controller = getAppController();

        runFacesheetRules(controller, itemId, parms);
    },
    handleFacesheetCenterPanelBeforerender: function () {

        Ext.suspendLayouts();
        // 
        // Create viewModel
        //
        var vModel = createViewModel('facesheet');

        window.facesheetViewModel = vModel;
    },
    handleFacesheetCenterPanelAfterrender: function () {
        
        pageLoadStatus['Facesheet'] = 'rendered';

        var controller = getAppController(),
            comp = controller.getFacesheetCenterPanel();
        
        setDisableFieldValues(comp);
        //
        // Run validations for page once on load
        //    
        var parms = {
            itemName: 'facesheet',
            itemCode: 23,
            runValidations: true,
            dataChanged: false
        };

        runFacesheetRules(controller, sr.Constants.AllFields, parms);

        Ext.resumeLayouts(true);
        controller.resumeEvents(true);
    },
    fireFocusEvent: function(){

        if (this.saveEnabled) {
            return;
        }

        var container = getCRSComponent('facesheetCenterPanel');
        container.ownerCt.fireEvent('focus', container.ownerCt, null);
    },
    addChangeEventListeners: function (container) {
        var self = this;

        // Question H
        container.queryById('questionHGrp').on('change', function (radioGroup, newValue, oldValue) {
            
            if (appDataEvent.facesheet.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            vmFields = [],
            vmField = { 'isCaseOpenReasonOtherAbuseNeglect': parms2.control.inputValue };

            vmFields.push(vmField);

            var input = {
                Component: parms2.control,
                FieldName: 'IsCaseOpenReasonOtherAbuseNeglect',
                ItemId: parms2.control.itemId,
                vmFields: vmFields,
                ParentForm: container.ownerCt
            };
            
            processFacesheetClick(input);
        });

        // Question I
        container.queryById('firstCaseOpeningDate').on('change', function (cmp, newValue, oldValue) {
            
            if (appDataEvent.facesheet.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            FacesheetFunctions.handleFirstCaseOpeningDateChange(cmp);

            self.fireFocusEvent();
        });

        // Question J
        container.queryById('fosterEntryDate').on('change', function (cmp, newValue, oldValue) {

            if (appDataEvent.facesheet.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            FacesheetFunctions.handleFosterEntryDateChange(cmp);

            self.fireFocusEvent();
        });
        
        container.queryById('isFosterCareDateNA').on('change', function (cmp, newValue, oldValue) {

            if (appDataEvent.facesheet.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            var caseType = getCaseType();

            if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

                cmp.setValue(true);
            }

            var vmFields = [],
                vmField = { 'isFosterEntryDateNA': cmp.inputValue },
                input = {
                    Component: cmp,
                    FieldName: 'IsFosterEntryDateNA',
                    ItemId: 'isFosterCareDateNA_change',
                    ParentForm: container.ownerCt
                };
            
            vmFields.push(vmField);

            vmField = { 'fosterEntryDate': null };
            vmFields.push(vmField);

            input['vmFields'] = vmFields;

            processFacesheetClick(input);
        });
        // Question K
        container.queryById('episodeDischargeDate').on('change', function (cmp, newValue, oldValue) {
            
            var savedVal = getCRSComponent('facesheetCenterPanel').viewModel.data.episodeDischargeDate,
                dateDiff = getDateDiff(newValue, savedVal, 'day');
            
            if (appDataEvent.facesheet.initialLoad && !Ext.isEmpty(savedVal) && dateDiff == 0) {
                return;
            }

            FacesheetFunctions.handleEpisodeDischargeDateChange(cmp);

            self.fireFocusEvent();
        });

        container.queryById('dischargeNA').on('change', function (cmp, newValue, oldValue) {

            if (appDataEvent.facesheet.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            var vmFields = [],
                vmField = { 'isEpisodeDischargeDateNA': cmp.inputValue },
                input = {
                    Component: cmp,
                    FieldName: 'IsEpisodeDischargeDateNA',
                    ItemId: 'dischargeNA_change',
                    ParentForm: container.ownerCt
                };

            vmFields.push(vmField);

            vmField = { 'isEpisodeNotYetDischarged': null };
            vmFields.push(vmField);

            vmField = { 'episodeDischargeDate': null };
            vmFields.push(vmField);

            input['vmFields'] = vmFields;

            processFacesheetClick(input);
        });

        container.queryById('notYetDischarged').on('change', function (cmp, newValue, oldValue) {
            
            if (appDataEvent.facesheet.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            var vmFields = [],
                vmField = { 'isEpisodeNotYetDischarged': cmp.inputValue },
                input = {
                    Component: cmp,
                    FieldName: 'IsEpisodeNotYetDischarged',
                    ItemId: 'notYetDischarged_change',
                    ParentForm: container.ownerCt
                };

            vmFields.push(vmField);

            vmField = { 'isEpisodeDischargeDateNA': null };
            vmFields.push(vmField);

            vmField = { 'episodeDischargeDate': null };
            vmFields.push(vmField);

            input['vmFields'] = vmFields;

            processFacesheetClick(input);
        });
        // Question L
        container.queryById('caseClosureDate').on('change', function (cmp, newValue, oldValue) {

            var savedVal = getCRSComponent('facesheetCenterPanel').viewModel.data.caseClosureDate,
                dateDiff = getDateDiff(newValue, savedVal, 'day');

            if (appDataEvent.facesheet.initialLoad && !Ext.isEmpty(savedVal) && dateDiff == 0) {
                return;
            }

            FacesheetFunctions.handleCaseClosureDateChange(cmp);

            self.fireFocusEvent();
        });

        container.queryById('caseClosureClosedInd').on('change', function (cmp, newValue, oldValue) {

            if (appDataEvent.facesheet.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            var vmFields = [],
                vmField = { 'isCaseClosureNotClosed': cmp.inputValue },
                input = {
                    Component: cmp,
                    FieldName: 'IsCaseClosureNotClosed',
                    ItemId: 'caseClosureClosedInd_change',
                    ParentForm: container.ownerCt
                };

            vmFields.push(vmField);

            vmField = { 'caseClosureDate': null };
            vmFields.push(vmField);

            input['vmFields'] = vmFields;

            processFacesheetClick(input);
        });
        //
        // Determine if the form has focus. If it is, enable the save buttons.
        //
        container.ownerCt.on('focus', function (cmp, event, eOpts) {
            
            if (self.saveEnabled) {
                return;
            }

            var buttons = cmp.query('savebuttons')[0].query('button');
            
            if (appDataEvent.facesheet.initialLoad) {
                appDataEvent.facesheet.initialLoad = false;
            }

            self.saveEnabled = enableButtons(buttons);
        });
    }
});