﻿Ext.define('App.CaseReview.controller.common.ChildDemographic', {
    extend: 'Ext.app.Controller',
    requires: [
        'framework.MessageBox',
        'framework.Store',
        'framework.view.Form',
        'framework.form.CheckboxGroup'
    ],
    refs: [],
    init: function (childDemographicGrid, record, edit) {
        var self = this;
        var form;
        var newChildRaceStoreId = null;
        var isTargetChildState = null;
        var isInterviewedState = null;
        var close = function () {
            /* istanbul ignore else  -- can't get to this other than by using GUI */
            if (!formSaved) {
                childDemographicGrid.plugins[0].fireEvent('canceledit');
            }

            childDemographicGrid.updateLayout();
        };

        var cancel = function () {
            edit.close();
        };
        var formSaved = false;

        var save = function () {
            if (!form.isValid()) { return; }
            var prop;
            var dirtyFields = form.getForm().getFieldValues();
            for (prop in dirtyFields) {
                /* istanbul ignore else  -- only for completeness */
                if (dirtyFields.hasOwnProperty(prop)) {
                    record.data[prop] = dirtyFields[prop]; //== true ? 1 : dirtyFields[prop] == false ? 2 : dirtyFields[prop];
                    if (prop == "IsTargetChild") {
                        record.data[prop] = isTargetChildState;
                    }
                    if (prop == "IsInterviewed") {
                        record.data[prop] = dirtyFields['IsInterviewed'] ? 1 : 2;
                    }
                }
            }

            var data = [];
            Ext.data.StoreManager.get(newChildRaceStoreId).each(function (rec) {
                    rec.data["ChildDemographicID"] = record.data["ChildDemographicID"];
                    data.push(rec.data);
            });

            if (!Ext.isEmpty(record.data["DateOfBirth"])) {

                var caseReviewStore = Ext.data.StoreManager.get("CaseReviewStore");

                var reviewCompletedDate = caseReviewStore.getAt(0).data.ReviewCompleted;

                if (!Ext.isEmpty(reviewCompletedDate)) {

                    var Age = window.framework.Date.getAgeInYMD(record.data["DateOfBirth"], reviewCompletedDate);
                    if (Ext.isEmpty(Age)) {
                        record.data["Age"] = "0 years 0 months";
                    } else {
                        record.data["Age"] = Age.Year + "y " + Age.Month + "m " + Age.Day + "d ";
                    }
                }
            }

            //Needs to be done for the first record only
            if (!Ext.isEmpty(Ext.data.StoreManager.get("CR_ChildRace_CollectionStore"))) {
                var dataStore = null;
                if (Ext.data.StoreManager.get("CR_ChildRace_CollectionStore").count() > 0) {
                    dataStore = Ext.data.StoreManager.get("CR_ChildRace_CollectionStore").first();
                    if (!Ext.isEmpty(record.data["ChildDemographicID"])) {
                        if (dataStore.data["ChildDemographicID"] == record.data["ChildDemographicID"]) {
                            Ext.data.StoreManager.get("CR_ChildRace_CollectionStore").removeAll(true);
                            Ext.data.StoreManager.get("CR_ChildRace_CollectionStore").setData(Ext.data.StoreManager.get(newChildRaceStoreId).getData());
                        }
                    }
                } else {
                    Ext.data.StoreManager.get("CR_ChildRace_CollectionStore").removeAll(true);
                    Ext.data.StoreManager.get("CR_ChildRace_CollectionStore").setData(Ext.data.StoreManager.get(newChildRaceStoreId).getData());
                }
            }


            record.data["CR_ChildRace_Collection"] = null;
            record.data["CR_ChildRace_Collection"] = data;
            record.commit();
             
            formSaved = true;
            edit.close();
            // enables the buttons
            childDemographicGrid.plugins[0].fireEvent('edit', childDemographicGrid, { record: record });

            var container = getCRSComponent('facesheetCenterPanel');
            FacesheetFunctions.fireFocusEvent(container);
        };

        var onAfterRender = function (e) {
            var items = Ext.ComponentQuery.query('#childDemographicHelperEdit [itemId]');
            var i, itemId;
            var itemsLength = items.length;
            for (i = 0; i < itemsLength; i++) {
                itemId = items[i].itemId;
                self.addRef([{ ref: itemId, selector: '#' + itemId }]);
            }
            e.updateLayout({ defer: false, isRoot: true });
            form = Ext.ComponentQuery.query('#childDemographicHelperEdit')[0];
            var shadowRecord = {};
            var prop;
            for (prop in record.data) {
                /* istanbul ignore else  -- only for completeness */
                if (record.data.hasOwnProperty(prop)) {
                    shadowRecord[prop] = record.data[prop];
                    if (prop == "IsTargetChild") {
                        if (record.data[prop] == 2) {
                            isTargetChildState = sr.CheckboxState.Unchecked;
                        }

                    }
                    if (prop == "IsInterviewed") {
                        if (record.data[prop] == 2) {
                            isInterviewedState = sr.CheckboxState.Unchecked;
                        }

                    }
                }
            }

            form.getForm().setValues(shadowRecord);

            self.getIsTargetChild().on('change', function (checkbox, newValue, oldValue) {
                if (newValue) {
                    isTargetChildState = sr.CheckboxState.Checked;
                } else {
                    isTargetChildState = sr.CheckboxState.Unchecked;
                }
            });

            self.getIsInterviewed().on('change', function (checkbox, newValue, oldValue) {
                if (newValue) {
                    isInterviewedState = sr.CheckboxState.Checked;
                } else {
                    isInterviewedState = sr.CheckboxState.Unchecked;
                }
            });

            var childRaceRecords = {};

            if (!Ext.isEmpty(shadowRecord['CR_ChildRace_Collection'])) {
                if (shadowRecord['CR_ChildRace_Collection'].length > 0) {
                    for (var iCount = 0; iCount < shadowRecord['CR_ChildRace_Collection'].length; iCount++) {
                        shadowRecord['CR_ChildRace_Collection'][iCount]["ExtId"] = null;
                    }
                }
                childRaceRecords = shadowRecord['CR_ChildRace_Collection'];
            }

            newChildRaceStoreId = record.data["ExtId"];


            var newStore = new Ext.data.Store({
                model: 'App.model.CR_ChildRace'
                , data: childRaceRecords
                , storeId: newChildRaceStoreId
            });

            self.getCR_ChildRace_Collection().bindStore(newStore);
            
            registerEvents();
        };

        var registerEvents = function () {
            edit.mon(self.getUnitCancel(), 'click', cancel);
            edit.mon(self.getUnitSave(), 'click', save);
            edit.mon(edit, 'close', close);
        };

        edit.mon(edit, 'afterrender', onAfterRender);
        edit.show({});

        /* istanbul ignore else  */
        if (window.jasmine) {
            self.close = close;
            self.cancel = cancel;
            self.save = save;
            self.onAfterRender = onAfterRender;
        }
    }
});