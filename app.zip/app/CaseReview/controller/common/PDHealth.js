﻿Ext.define('App.CaseReview.controller.common.PDHealth', {
    extend: 'Ext.app.Controller',
    requires: [
        'framework.MessageBox',
        'framework.Store',
        'framework.view.Form',
        'framework.form.CheckboxGroup'
    ],
    refs: [],
    init: function (healthGrid, record, edit) {
        var self = this;
        var form;
        var newChildRaceStoreId = null;
        var close = function () {
            /* istanbul ignore else  -- can't get to this other than by using GUI */
            if (!formSaved) {
                healthGrid.plugins[0].fireEvent('canceledit');
            }
        };

        var cancel = function () {
            edit.close();
        };
        var formSaved = false;

        var save = function () {
            if (!form.isValid()) { return; }
            var prop;
            var dirtyFields = form.getForm().getFieldValues();
            for (prop in dirtyFields) {
                /* istanbul ignore else  -- only for completeness */
                if (dirtyFields.hasOwnProperty(prop)) {
                    record.data[prop] = dirtyFields[prop];
                }
            }

            //var data = [];
            //Ext.data.StoreManager.get(newChildRaceStoreId).each(function (rec) {
            //        rec.data["ChildParticipantID"] = record.data["ChildParticipantID"];
            //        data.push(rec.data);
            //});



            ////Needs to be done for the first record only
            //if (!Ext.isEmpty(Ext.data.StoreManager.get("CR_ChildRace_CollectionStore"))) {
            //    var dataStore = null;
            //    if (Ext.data.StoreManager.get("CR_ChildRace_CollectionStore").count() > 0) {
            //        dataStore = Ext.data.StoreManager.get("CR_ChildRace_CollectionStore").first();
            //        if (!Ext.isEmpty(record.data["ChildParticipantID"])) {
            //            if (dataStore.data["ChildParticipantID"] == record.data["ChildParticipantID"]) {
            //                Ext.data.StoreManager.get("CR_ChildRace_CollectionStore").removeAll(true);
            //                Ext.data.StoreManager.get("CR_ChildRace_CollectionStore").setData(Ext.data.StoreManager.get(newChildRaceStoreId).getData());
            //            }
            //        }
            //    } else {
            //        Ext.data.StoreManager.get("CR_ChildRace_CollectionStore").removeAll(true);
            //        Ext.data.StoreManager.get("CR_ChildRace_CollectionStore").setData(Ext.data.StoreManager.get(newChildRaceStoreId).getData());
            //    }
            //}


            record.data["HealthNeedCode"] = 1;
            //record.data["CR_ChildRace_Collection"] = data;
            record.commit();



            formSaved = true;
            edit.close();
            // enables the buttons
            healthGrid.plugins[0].fireEvent('edit', healthGrid, { record: record });
        };

        var onAfterRender = function (e) {
            var items = Ext.ComponentQuery.query('#pdHealthHelperEdit [itemId]');
            var i, itemId;
            var itemsLength = items.length;
            for (i = 0; i < itemsLength; i++) {
                itemId = items[i].itemId;
                self.addRef([{ ref: itemId, selector: '#' + itemId }]);
            }
            e.updateLayout({ defer: false, isRoot: true });
            form = Ext.ComponentQuery.query('#pdHealthHelperEdit')[0];
            var shadowRecord = {};
            var prop;
            for (prop in record.data) {
                /* istanbul ignore else  -- only for completeness */
                if (record.data.hasOwnProperty(prop)) {
                    shadowRecord[prop] = record.data[prop];
                }
            }
            form.getForm().setValues(shadowRecord);


            //var childRaceRecords = {};

            //if (!Ext.isEmpty(shadowRecord['CR_ChildRace_Collection'])) {
            //    if (shadowRecord['CR_ChildRace_Collection'].length > 0) {
            //        for (var iCount = 0; iCount < shadowRecord['CR_ChildRace_Collection'].length; iCount++) {
            //            shadowRecord['CR_ChildRace_Collection'][iCount]["ExtId"] = null;
            //        }
            //    }
            //    childRaceRecords = shadowRecord['CR_ChildRace_Collection'];
            //}

            //newChildRaceStoreId = record.data["ExtId"];


            //var newStore = new Ext.data.Store({
            //    model: 'App.model.CR_ChildRace'
            //    , data: childRaceRecords
            //    , storeId: newChildRaceStoreId
            //});

            //self.getCR_ChildRace_Collection().bindStore(newStore);

            registerEvents();
        };

        var registerEvents = function () {
            edit.mon(self.getUnitCancel(), 'click', cancel);
            edit.mon(self.getUnitSave(), 'click', save);
            edit.mon(edit, 'close', close);
        };

        edit.mon(edit, 'afterrender', onAfterRender);
        edit.show({});

        /* istanbul ignore else  */
        if (window.jasmine) {
            self.close = close;
            self.cancel = cancel;
            self.save = save;
            self.onAfterRender = onAfterRender;
        }
    }
});