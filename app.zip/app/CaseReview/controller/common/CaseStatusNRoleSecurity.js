﻿Ext.define('App.CaseReview.controller.common.CaseStatusNRoleSecurity',
{
    extend: 'Ext.Base',
    singleton: true,
    alternateClassName: 'CaseStatusNRoleSecurity',



    setUpSecurity: function (cntrlr)
    {


        if (window.overrideSecurity == "true") {
           return false;
        }

        var caseStatus = this.getCaseStatus();
        var userRoleinCaseReview = this.getUserRoleinCaseReview(window.userID);

        if (Ext.isEmpty(userRoleinCaseReview)) {

            Ext.MessageBox.alert("Important", "You are not associated with this case, all the information displayed will be in read-only mode");
            this.makeFieldsNGridsReadOnly();
            this.disableItemNotesSection();
            this.hideSaveButtons();
            this.hideCaseLinks();
            return false;
        }

        switch (caseStatus) {

            case sr.CaseStatus.NotStarted:


                if (!this.checkforPermissionInCase(sr.Permissions.EditCaseData)) {
                    this.makeFieldsNGridsReadOnly();
                    this.hideSaveButtons();
                }
                if (this.checkforPermissionInCase(sr.Permissions.AddEditCaseNotes)) {
                    this.enableItemNotesSection();
                    this.showSaveButtons();
                }


                break;

            case sr.CaseStatus.InProgress:
                if (!this.checkforPermissionInCase(sr.Permissions.EditCaseData)) {
                    this.makeFieldsNGridsReadOnly();
                    this.hideSaveButtons();
                }
                if (this.checkforPermissionInCase(sr.Permissions.AddEditCaseNotes)) {
                    this.enableItemNotesSection();
                    this.showSaveButtons();
                }
                break;


            case sr.CaseStatus.DataEntryComplete:
                if (!this.checkforPermissionInCase(sr.Permissions.EditCaseData)) {
                    this.makeFieldsNGridsReadOnly();
                    this.hideSaveButtons();
                }
                if (this.checkforPermissionInCase(sr.Permissions.AddEditCaseNotes)) {
                    this.enableItemNotesSection();
                    this.showSaveButtons();
                }

                this.SubmitToQAPermission(cntrlr);
                break;



            case sr.CaseStatus.QAinProgress:
                // Only allow the overriding of items 
                // Allow the QA notes.
                // Save buttons display
                // Show the Return to review
                // Show the Finalize  (Only by Feds).
                // Disable everything


                this.makeFieldsNGridsReadOnly();
                if (this.checkforPermissionInCase(sr.Permissions.OverrideRating)) {
                    this.enableOverrideRatingsSection();
                    this.showSaveButtons();
                }

                if (this.checkforPermissionInCase(sr.Permissions.AddEditCaseNotes)) {
                    this.enableItemNotesSection();
                    this.showSaveButtons();
                }

                this.ReturnToReviewerPermission(cntrlr);
                this.SubmitToFinalizePermission(cntrlr); 

                break;

            case sr.CaseStatus.FinalizedPendingApproval:


                this.makeFieldsNGridsReadOnly();
                if (this.checkforPermissionInCase(sr.Permissions.AddEditCaseNotes)) {
                    this.enableItemNotesSection();
                    this.showSaveButtons();
                }
                this.FinalizeAndApprovePermission(cntrlr);
                this.ReturnToQAPermission(cntrlr);
                break;
                
                // Approved and Final
            case sr.CaseStatus.ApprovedandFinal:
                this.makeFieldsNGridsReadOnly();
                this.disableItemNotesSection();
                this.hideSaveButtons();
                break;
                // Case Eliminated Pending Approval
            case sr.CaseStatus.CaseEliminatedPendingApproval:
                this.makeTabsDisable(cntrlr);
                this.makeLeftNavigationDisabled();
                this.makeOverviewTabSectionsHidden();
                this.makeFieldsNGridsReadOnly();
                this.disableItemNotesSection();
                this.hideSaveButtons();
                
                break;

            // Case Eliminated
            case sr.CaseStatus.CaseEliminated:
                this.makeTabsDisable(cntrlr);
                this.makeLeftNavigationDisabled();
                this.makeOverviewTabSectionsHidden();
                this.makeFieldsNGridsReadOnly();
                this.disableItemNotesSection();
                this.hideSaveButtons();
                break;

            default:
                break;
        }
    },

    emptyFunction: function() {
        alert('nothing');
    },

    EliminateCaseReviewPermission: function(control) {


    },

    CheckCaseAndUserPermission: function(tabId) {

        var caseStatus = this.getCaseStatus();
        if (Ext.isEmpty(VerifyPermission.getCaseRole(window.userID))) {
            this.makeEverythingReadOnly(tabId);
        }

        if (caseStatus == sr.CaseStatus.CaseEliminated || caseStatus == sr.CaseStatus.ApprovedandFinal) {
            this.makeEverythingReadOnly(tabId);
        }


    },

    EliminateCaseApprovedPermission: function(control) {

        var caseStatus = this.getCaseStatus();

        var buttonControl = Ext.ComponentQuery.query('#' + control)[0];

        if (caseStatus == sr.CaseStatus.CaseEliminatedPendingApproval) {
            buttonControl.hidden = false;
        }

        if (!VerifyPermission.checkforPermissionInCase(sr.Permissions.ApproveEliminateCases)) {
            buttonControl.disabled = true;
            buttonControl.tooltip = "You do not have the persmission to Approve Case Elimination";
        }

    },

    SubmitToQAPermission: function (control) {

        control.getSubmitToQA().setHidden(false);

        if (!this.checkforPermissionInCase(sr.Permissions.SubmitToQA)) {

            //control.getSubmitToQA().on('click', function () {

            //    Ext.Msg.alert("Access Denied", "You do not have sufficient permission to perform the desired operation");

            //    return false;
            //});
        } else {

            control.getSubmitToQA().on('click', function () {

                window.submitToQA = true;
            });
        }
    },

    ReturnToQAPermission: function (cntrlr) {

        cntrlr.getReturnToQA().setHidden(false);

        if (!this.checkforPermissionInCase(sr.Permissions.SubmitBackToQA)) {

            //cntrlr.getReturnToQA().on('click', function () {

            //    Ext.Msg.alert("Access Denied", "You do not have sufficient permission to perform the desired operation");

            //    return false;
            //});
        } else {

            cntrlr.getReturnToQA().on('click', function () {

                window.returnToQA = true;
            });
        }
    },

    ReturnToReviewerPermission: function (cntrlr) {

        cntrlr.getReturnToReviewer().setHidden(false);

        if (!this.checkforPermissionInCase(sr.Permissions.TransferToReviewer))
        {
            //cntrlr.getReturnToReviewer().on('click', function () {

            //    Ext.Msg.alert("Access Denied", "You do not have sufficient permission to perform the desired operation");

            //    return false;
            //});
        } else {

            cntrlr.getReturnToReviewer().on('click', function () {

                window.submitToReviewer = true;
            });
        }
    },

    SubmitToFinalizePermission: function (cntrlr) {

        cntrlr.getSubmitToFinalize().setHidden(false);

        if (!this.checkforPermissionInCase(sr.Permissions.SubmitToFinalize)) {

            //cntrlr.getSubmitToFinalize().on('click', function () {

            //    Ext.Msg.alert("Access Denied", "You do not have sufficient permission to perform the desired operation");

            //    return false;
            //});
        } else {

            cntrlr.getSubmitToFinalize().on('click', function () {

                window.submitToFinalize = true;
            });
        }
    },

    FinalizeAndApprovePermission: function (cntrlr) {

        cntrlr.getFinalizeAndApprove().setHidden(false);

        if (!this.checkforPermissionInCase(sr.Permissions.FinalizeAndApproveCase)) {

            //cntrlr.getFinalizeAndApprove().on('click', function () {

            //    Ext.Msg.alert("Access Denied", "You do not have sufficient permission to perform the desired operation");

            //    return false;
            //});
        } else {

            // Check for all the notes of the items are resolved.
            var outcomeStore = Ext.StoreManager.get('CR_Outcome_CollectionStore');
            var tempOutcomeStore;

            

            cntrlr.getFinalizeAndApprove().on('click', function () {

                var areAllNotesResolved = true;
                 
                for (var iOutcomeCount = 0; iOutcomeCount < outcomeStore.count(); iOutcomeCount++) {
                    tempOutcomeStore = outcomeStore.getAt(iOutcomeCount);
                    var itemCollection = tempOutcomeStore.data.CR_Item_Collection;
                    for (var iItemCount = 0; iItemCount < itemCollection.length; iItemCount++) {
                    var tempItem = itemCollection[iItemCount];
                    if (!Ext.isEmpty(tempItem) && tempItem.CR_Note_Collection.length > 0) {
                        var tempNoteCollection = tempItem.CR_Note_Collection;
                        if (!Ext.isEmpty(tempNoteCollection) && tempNoteCollection.length > 0) {
                            for (var iNoteCount = 0; iNoteCount < tempNoteCollection.length; iNoteCount++) {
                                var tempNote = tempNoteCollection[iNoteCount];
                                if (!Ext.isEmpty(tempNote.TS_CR) && tempNote.IsResolved != 1) // Not Resolved
                                {
                                    areAllNotesResolved = false;
                                    Ext.Msg.alert("Notes not resolved", "Please check Case QA Notes and resolve all QA Notes before approving the case");
                                    return false;
                                }
                            }
                        }
                    }
                }
                    
                }

                if (areAllNotesResolved == true) {

                    window.submitToApprove = true;
                }
            });
        }
    },

    makeLeftNavigationDisabled : function() {
        Ext.ComponentQuery.query('#overviewWest')[0].disable();
    },
    makeOverviewTabSectionsHidden: function () {
        Ext.ComponentQuery.query('#overviewTabSections')[0].getEl().mask();
    },
    makeTabsDisable: function (cntrlr) {
        cntrlr.getPermanency().setDisabled(true);
        cntrlr.getFaceSheet().setDisabled(true);
        cntrlr.getSafety().setDisabled(true);
        cntrlr.getWellBeing().setDisabled(true);
    },
    makeFieldsNGridsReadOnly: function (tabId) {

        if (Ext.isEmpty(tabId)) {

            tabId = Ext.ComponentQuery.query('#centerTabPanel')[0].getActiveTab().itemId;
        }

        var itemsTextBoxes = Ext.ComponentQuery.query('#' + tabId + ' textfield');
        for (var i = 0; i < itemsTextBoxes.length; i++) {
            itemsTextBoxes[i].setReadOnly(true);
            //items[i].tooltip = "Case is in read only mode";
        }

        var itemsTextAreaBoxes = Ext.ComponentQuery.query('#' + tabId + ' textarea');
        for (var i = 0; i < itemsTextAreaBoxes.length; i++) {
            itemsTextAreaBoxes[i].setReadOnly(true);
            //items[i].tooltip = "Case is in read only mode";
        }

        var itemsCombo = Ext.ComponentQuery.query('#' + tabId + ' combo');
        for (var i = 0; i < itemsCombo.length; i++) {
            itemsCombo[i].setReadOnly(true);
            //items[i].tooltip = "Case is in read only mode";
        }

        var itemscheckboxes = Ext.ComponentQuery.query('#' + tabId + ' checkbox');
        for (var i = 0; i < itemscheckboxes.length; i++) {
            itemscheckboxes[i].setReadOnly(true);
        }

        var itemsradios = Ext.ComponentQuery.query('#' + tabId + ' radio');
        for (var i = 0; i < itemsradios.length; i++) {
            itemsradios[i].setReadOnly(true);
        }

        var grids = Ext.ComponentQuery.query('#' + tabId + ' gridpanel');
        for (var i = 0; i < grids.length; i++) {

            //grids[i].clearListeners();
            var gridbuttons = grids[i].query('button');
            for (var j = 0; j < gridbuttons.length; j++) {
                gridbuttons[j].setHidden(true);
            }

            var gridPlugins = grids[i].plugins;
            for (var j = 0; j < gridPlugins.length; j++) {
                if (!Ext.isEmpty(gridPlugins[j].pluginId) && gridPlugins[j].pluginId == "programEditorPlugin")
                    gridPlugins[j].disable();
            }

        }



    },

    enableOverrideRatingsSection: function() {
        var tabId = Ext.ComponentQuery.query('#centerTabPanel')[0].getActiveTab().itemId;
        
        var itemRatingOverrides = Ext.ComponentQuery.query('#' + tabId + ' ratingOverride');
        

        for (var i = 0; i < itemRatingOverrides.length; i++) {

            var itemsTextBoxes = Ext.ComponentQuery.query('#' + itemRatingOverrides[i].itemId + ' textfield');
            for (var j = 0; j < itemsTextBoxes.length; j++) {
                itemsTextBoxes[j].setDisabled(false);
                itemsTextBoxes[j].setReadOnly(false);
                //items[i].tooltip = "Case is in read only mode";
            }

            var itemscheckboxes = Ext.ComponentQuery.query('#' + itemRatingOverrides[i].itemId + ' checkbox');
            for (var j = 0; j < itemscheckboxes.length; j++) {
                itemscheckboxes[j].setDisabled(false);
                itemscheckboxes[j].setReadOnly(false);
            }

            var itemsradios = Ext.ComponentQuery.query('#' + itemRatingOverrides[i].itemId + ' radio');
            for (var j = 0; j < itemsradios.length; j++) {
                itemsradios[j].setDisabled(false);
                itemsradios[j].setReadOnly(false);
            }

            var itemContainers = Ext.ComponentQuery.query('#' + itemRatingOverrides[i].itemId + ' component');
            for (var j = 0; j < itemContainers.length; j++) {
                itemContainers[j].setDisabled(false);
            }
        }
    },

    enableItemNotesSection: function() {
        
        var tabId = Ext.ComponentQuery.query('#centerTabPanel')[0].getActiveTab().itemId;
        var qaNotes = Ext.ComponentQuery.query('#' + tabId + ' qaNotes');
        for (var i = 0; i < qaNotes.length; i++) {
            var notesbuttons = qaNotes[i].query('button');
            for (var j = 0; j < notesbuttons.length; j++) {
                notesbuttons[j].setHidden(false);
            }

            var textfields = qaNotes[i].query('textfield');
            for (var j = 0; j < textfields.length; j++) {
                textfields[j].setReadOnly(false);
            }

        }
    },

    disableItemNotesSection: function() {
        
        var tabId = Ext.ComponentQuery.query('#centerTabPanel')[0].getActiveTab().itemId;
        var qaNotes = Ext.ComponentQuery.query('#' + tabId + ' qaNotes');
        for (var i = 0; i < qaNotes.length; i++) {
            var notesbuttons = qaNotes[i].query('button');
            for (var j = 0; j < notesbuttons.length; j++) {
                notesbuttons[j].setHidden(true);
            }

            var textfields = qaNotes[i].query('textfield');
            for (var j = 0; j < textfields.length; j++) {
                textfields[j].setReadOnly(true);
            }

        }
    },

    showSaveButtons: function() {
        var tabId = Ext.ComponentQuery.query('#centerTabPanel')[0].getActiveTab().itemId;
        var items = Ext.ComponentQuery.query('#' + tabId + ' button');
        for (var i = 0; i < items.length; i++) {
            if (!Ext.isEmpty(items[i].itemId) && items[i].itemId.indexOf('Save') > -1) {
                items[i].setHidden(false);
            }
        }
    },

    hideSaveButtons: function() {
        var tabId = Ext.ComponentQuery.query('#centerTabPanel')[0].getActiveTab().itemId;
        var items = Ext.ComponentQuery.query('#' + tabId + ' button');
        for (var i = 0; i < items.length; i++) {
            if (!Ext.isEmpty(items[i].itemId) && items[i].itemId.indexOf('Save') > -1) {
                items[i].setHidden(true);
            }
        }
        //
        // Hide floating save Case buttons
        //
        var saveCaseBut = Ext.ComponentQuery.query('#saveCaseButton')[0],
            saveCaseContinueBut = Ext.ComponentQuery.query('#saveCaseContinueButton')[0];

        saveCaseBut.setHidden(true);
        saveCaseContinueBut.setHidden(true);
    },
    hideCaseLinks: function () {
        
        var caseLinks = Ext.ComponentQuery.query('#caseLinks')[0];

        //if (window.location.hostname != 'localhost') {
        //    Ext.each(caseLinks.items.items, function (link) {
        //        link.setHidden(true);
        //    });
        //}        
    },

    getCaseStatus: function () {
        return Ext.StoreMgr.get('CaseReviewStore').getAt(0).data.CaseStatusCode;
    },

    getUserRoleinCaseReview : function(userId) {
        var caseReviewStore = chainedStore('CaseReviewStore');
        
        // Check QA and Oversight roles first
        if (caseReviewStore.count() > 0 && !Ext.isEmpty(caseReviewStore.getAt(0)))
        {
            var caseReview = caseReviewStore.getAt(0).data;
            if (caseReview.InitialQAUserID == userId || caseReview.SecondQAUserID == userId) {
                return sr.UserRoles.StateSideLeader;
            }
            if (caseReview.SecondaryOversightUserID == userId || caseReview.CtSecondaryOversightUserID == userId) {
                return sr.UserRoles.FederalReviewer;
            }
        }
        
        // Check reviewers
        var reviewerStore = Ext.data.ChainedStore.create({
            source: 'CR_Reviewer_CollectionStore',
            filters: [
                function (record) {
                    return record.data.UserID == userId;
                }
            ]
        });

        if (reviewerStore.data.length > 0) {
            return sr.UserRoles.StateReviewer;

        }

        return "";
    },
    
    checkforPermissionInCase: function (persmission) {

        
        var userId = window.userID;
        if (Ext.isEmpty(userId)) {
            return false;
        }

        var caseRole = this.getUserRoleinCaseReview(userId);
        if (Ext.isEmpty(caseRole)) {
            return false;
        }

        var rolePermissionStore = chainedStore('CrSecurityRolePermissionStore');
        var hasCaseRoleGotPermission = false;
        if (!Ext.isEmpty(rolePermissionStore)) {
            rolePermissionStore.each(function (record) {
                if (record.data.PermissionID == persmission && record.data.RoleID == caseRole) {
                    hasCaseRoleGotPermission = true;
                    return ;
                }
            });
        }

        //if (hasCaseRoleGotPermission) {
        //    hasCaseRoleGotPermission = false;
        //    var userRolePermissionStore = chainedStore('CrUserRolePermissionMappingsStore');
        //    if (!Ext.isEmpty(userRolePermissionStore)) {
        //        userRolePermissionStore.each(function(record) {
        //            if (record.data.PermissionID == persmission) {
        //                hasCaseRoleGotPermission = true;
        //                return;
        //            }
        //        });

        //    }
        //}

        
        return hasCaseRoleGotPermission;
    },
});