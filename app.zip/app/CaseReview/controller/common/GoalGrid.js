﻿Ext.define('App.CaseReview.controller.common.GoalGrid',
{
    extend: 'Ext.Base',
    constructor: function (controller) {
        var self = this;
        var grid = controller.getGoalGrid(); 
        var gridAdd = sr.ItemIds.goalGridAddButton;
        var gridEdit = sr.ItemIds.goalGridEditButton;
        var gridDelete = sr.ItemIds.goalGridDeleteButton;

        var enableDisableHandler = function () {
            //var selections = grid.getSelectionModel().getSelection();
            //if (selections.length > 0) {
            //    var record = selections[0];
            //    if (record.get('ID_ASSTNCE_GRP_MBRS_SEQ') === 0 || grid.getStore().getCount() === 1)// the one we get sent starts with 0 but if another is added, we make it zero.
            //    {
            //        setTimeout(function () {
            //            gridDelete.disable();
            //            gridEdit.disable();
            //        }, 0);
            //    }
            //}
            //if (grid.getStore().getCount() > 9) {
            //    setTimeout(function () {
            //        gridAdd.disable();
            //    }, 0);
            //}

        };

        /* istanbul ignore next: can only be tested with a gui  */
        var addEdit = function (record) {

            var edit = Ext.create('App.CaseReview.view.common.GoalHelper');
            Ext.create('App.CaseReview.controller.common.Goal')
                                .init(grid, record, edit);

        };

        var deleteRecord = function () {

            var controller = getAppController();

            grid.plugins[0].fireEvent('recorddelete');

            var parms = {};
            parms['recordType'] = 'Grid';
            parms['storeId'] = grid.store.storeId;
            parms['runValidations'] = true;

            runPermanencyRules(controller, 'goalGrid', parms);

            synchronizeGoalChanges();
        };

        controller.goalGridEventHandler = Ext.create('framework.controller.GridAddEditDeleteEventHandlers', controller.viewModel,
        {
            'grid': grid,
            'add': gridAdd,
            'edit': gridEdit,
            'del': gridDelete,
            'insertRecord': {}, // blank record
            addAction: addEdit,
            editAction: addEdit,
            deleteAction: deleteRecord
        });

        controller.control({
            '#goalGridAdd': {
                'enable': enableDisableHandler
            },
            '#goalGrid': {
                'selectionchange': enableDisableHandler
            }
        });

        /* istanbul ignore else  */
        if (window.jasmine) {
            self.enableDisableHandler = enableDisableHandler;
            self.addEdit = addEdit;
        }
    }
});