﻿Ext.define('App.CaseReview.controller.common.CaseSetUpPopUp',
{
    extend: 'Ext.Base',
    requires: [
    'framework.MessageBox',
    'framework.Store',
    'framework.view.Form',
    'framework.form.CheckboxGroup'
    ],
    constructor: function (controller) {
        var self = this;
        var edit;

        var createSetupWindow = function () {

            var result = Ext.create('Ext.window.Window', {
                title: 'Case Setup: Face Sheet questions A - F',
                layout: 'auto',
                itemId: 'caseSetUpUIWindow',
                resizable: true,
                modal: true,
                height: 600,
                width: 950,
                closeAction: 'hide',
                scrollable: true,
                bodyCls: 'panel-background-color',
                isCancelled: false,
                items: {
                    xtype: 'caseSetupUI',
                    border: false
                },
                defaults: {
                    margin: 20
                },
                dockedItems: [
                    {
                        //*****************************************************
                        // Case Setup [Save and Cancel buttons]
                        //*****************************************************
                        xtype: 'toolbar',
                        dock: 'bottom',
                        border: false,
                        ui: 'footer',
                        items: ['->',
                            {
                                //CANCEL BUTTON                                
                                text: 'Cancel',
                                type: 'close',
                                itemId: 'caseSetupCancel',
                                scale: 'medium'
                            },
                            {
                                //SAVE BUTTON
                                type: 'save',
                                itemId: 'caseSetupSave',
                                text: "Save",
                                scale: 'medium',
                                handler: function () {
                                    // Enable all tabs
                                    var parentPanel = Ext.ComponentQuery.query('#overviewTab')[0].up('#centerTabPanel');
                                    var children = parentPanel.query()[0];

                                    Ext.each(children, function (tab) {

                                        tab.setDisabled(false);

                                    });

                                    return false;

                                }
                            }
                        ]
                    }
                ]
            });

            return result;
        }
        
        edit = createSetupWindow();

        var show = function () {

            edit.show();
        }

        var onAfterRender = function () {
            var form = Ext.ComponentQuery.query('#caseSetupForm')[0];

            if (window.CaseStatusNRoleSecurity.getCaseStatus() == sr.CaseStatus.ApprovedandFinal
                || window.CaseStatusNRoleSecurity.getCaseStatus() == sr.CaseStatus.CaseEliminated
                || window.CaseStatusNRoleSecurity.getCaseStatus() == sr.CaseStatus.CaseEliminatedPendingApproval) {

                var itemsTextBoxes = form.query('textfield');
                for (var i = 0; i < itemsTextBoxes.length; i++) {
                    itemsTextBoxes[i].setReadOnly(true);
                    //items[i].tooltip = "Case is in read only mode";
                }

                var itemscheckboxes = Ext.ComponentQuery.query('checkbox');
                for (var i = 0; i < itemscheckboxes.length; i++) {
                    itemscheckboxes[i].setReadOnly(true);
                }

                var itemsradios = Ext.ComponentQuery.query('radio');
                for (var i = 0; i < itemsradios.length; i++) {
                    itemsradios[i].setReadOnly(true);
                }

                var items = Ext.ComponentQuery.query('button');
                for (var i = 0; i < items.length; i++) {
                    if (!Ext.isEmpty(items[i].itemId) && items[i].itemId.indexOf('Save') > -1) {
                        items[i].setHidden(true);
                    }
                }
            }

            //registerEvents();
        }

        var onSave = function () {
            
            var self = this;

            if (!checkforMandatoryFields()) {

                return;
            }

            if (checkForDuplicates()) {
                //
                // Alert message to indicate that certain fields cannot be changed after saving.
                //
                Ext.Msg.show({
                    title: 'Save Case?',
                    message: 'You are about to save a case. Be aware that the fields - <strong>Case ID, Name of state and county, Review Start Date, Type of Case and PIP Monitored </strong> - cannot be modified after saving! <br><br>Would you still like to save your changes?',
                    buttons: Ext.Msg.YESNOCANCEL,
                    icon: Ext.Msg.QUESTION,
                    fn: function (btn) {

                        if (btn === 'yes') {

                            Ext.ComponentQuery.query('#caseSetUpUIWindow')[0].close();

                            initializeResultsContainer();

                            self.saveData();
                        }
                    }
                });
                // End of alert
                //                
            }
        }

        var onCancel = function () {

            edit.isCancelled = true;

            edit.close();
        }

        var resetFields = function () {

            var filteredField;
            var form = Ext.ComponentQuery.query('#caseSetupForm')[0];
            var formFields = form.getForm().getFields().items;
            var filteredReviewer;
            var viewModel = getApplicationViewModel().data;

            var fields = [
                {
                    itemId: 'caseID',
                    value: viewModel.caseId
                },
                {
                    itemId: 'state',
                    value: viewModel.siteName
                },
                {
                    itemId: 'CaseName',
                    value: viewModel.caseName
                },
                {
                    itemId: 'reviewBeginDate',
                    value: viewModel.reviewStartDate
                },
                {
                    itemId: 'reviewCompleted',
                    value: viewModel.reviewCompletedDate
                },
                {
                    itemId: 'intitalQA',
                    value: viewModel.intialQAId
                },
                {
                    itemId: 'secondQA',
                    value: viewModel.secondLevelQAId
                },
                {
                    itemId: 'secondOversight',
                    value: viewModel.secondaryOversightId
                },
                {
                    itemId: 'secondCTOversight',
                    value: viewModel.ctSecondaryOversightId
                },
                {
                    itemId: 'reviewSubType1',
                    value: viewModel.reviewSubTypeId
                },
                {
                    itemId: 'reviewSubType2',
                    value: viewModel.reviewSubTypeId
                },
                {
                    itemId: 'reviewSubType3',
                    value: viewModel.reviewSubTypeId
                },
                {
                    itemId: 'pipMonitoredYes',
                    value: viewModel.pipMonitored
                },
                {
                    itemId: 'pipMonitoredNo',
                    value: viewModel.pipMonitored
                },
                {
                    itemId: 'reviewerCheckboxGroup',
                    value: viewModel.reviewers
                }
            ]

            Ext.each(fields, function (field) {

                filteredField = formFields.filter(function (formField) {

                    return formField.itemId == field.itemId;
                });

                if (filteredField.length > 0) {

                    if (field.itemId == 'reviewerCheckboxGroup') {

                        Ext.each(field.value, function (reviewer) {

                            filteredReviewer = formFields.filter(function (rev) {

                                return rev.boxLabel == reviewer.data.FullName;
                            });

                            if (filteredReviewer.length > 0) {

                                filteredReviewer[0].setValue(true);
                            }
                        });

                    } else {

                        filteredField[0].setValue(field.value);
                    }
                }
            });
        }

        var checkforMandatoryFields = function () {

            if (edit.isCancelled) {
                
                resetFields();

                return true;
            }

            var caseId = Ext.ComponentQuery.query('#caseID')[0];
            var reviewCompleted = Ext.ComponentQuery.query('#reviewCompleted')[0];
            var reviewStartDate = Ext.ComponentQuery.query('#reviewBeginDate')[0];
            
            var caseReviewStore = Ext.StoreMgr.get('CaseReviewStore');
            var siteName = Ext.ComponentQuery.query('#state')[0];
            var caseName = Ext.ComponentQuery.query('#CaseName')[0];
            var reviewers = Ext.ComponentQuery.query('#reviewerCheckboxGroup')[0];
            var initialQA = Ext.ComponentQuery.query('#intitalQA')[0];
            var secondaryQA = Ext.ComponentQuery.query('#secondQA')[0];
            var secondaryOversight = Ext.ComponentQuery.query('#secondOversight')[0];
            var pipCheckedYes = Ext.ComponentQuery.query('#pipMonitoredYes')[0];
            var pipCheckedNo = Ext.ComponentQuery.query('#pipMonitoredNo')[0];

            if (Ext.isEmpty(caseId.getValue())) {

                Ext.Msg.alert("Error", "Case ID is a mandatory field");

                return false;
            }

            if (Ext.isEmpty(siteName.getValue())) {

                Ext.Msg.alert("Error", "Name of state and county is a mandatory field");

                return false;
            }

            if (Ext.isEmpty(caseName.getValue())) {

                Ext.Msg.alert("Error", "Case Name is a mandatory field");

                return false;
            }

            if (reviewers.store.data.length == 0) {

                Ext.Msg.alert("Error", "Review Participants are mandatory");

                return false;
            }

            if (Ext.isEmpty(initialQA.getValue())) {

                Ext.Msg.alert("Error", "Initial QA is a mandatory field");

                return false;
            }

            if (Ext.isEmpty(secondaryQA.getValue())) {

                Ext.Msg.alert("Error", "Second Level QA is a mandatory field");

                return false;
            }

            if (Ext.isEmpty(secondaryOversight.getValue())) {

                Ext.Msg.alert("Error", "Secondary Oversight is a mandatory field");

                return false;
            }

            if (Ext.isEmpty(reviewStartDate.getValue())) {

                Ext.Msg.alert("Error", "Date case review was started is a mandatory field");

                return false;
            }

            if (Ext.isEmpty(reviewCompleted.getValue())) {

                Ext.Msg.alert("Error", "Date case review was completed is a mandatory field");

                return false;
            }

            if (!pipCheckedYes.checked && !pipCheckedNo.checked) {

                Ext.Msg.alert("Error", "PIP Monitored status is a mandatory field");

                return false;
            }

            return true;
        }

        var checkForDuplicates = function() {
            var form = Ext.ComponentQuery.query('#caseSetupForm')[0];

            if (Ext.isEmpty(form)) {

                return true;
            }

            var checkboxGroup = form.down('#reviewerCheckboxGroup').getChecked();
            var initialQA = form.down('#intitalQA');
            var secondaryQA = form.down('#secondQA');
            var secondOversight = form.down('#secondOversight');
            var secondCTOversight = form.down('#secondCTOversight');

            var reviewers, initialQA, secondLevelQA, secondaryOversight, ctSecondaryOversight, reviewer, nameId, userId, displayName;

            if (checkboxGroup.length > 0) {

                reviewers = [];

                for (var iCount = 0; iCount < checkboxGroup.length ; iCount++) {

                    var data = checkboxGroup[iCount].inputValue;

                    nameId = "Reviewer" + (iCount + 1);
                    userId = data;
                    displayName = 'Reviewer';

                    reviewer = { 'NameId': nameId, 'UserId': userId, 'DisplayName': displayName };
                    reviewers.push(reviewer);
                }

            }

            nameId = 'initialQA';
            userId = initialQA.value;

            if (!Ext.isEmpty(userId) && userId != 0) {

                displayName = 'Initial QA';
                reviewer = { 'NameId': nameId, 'UserId': userId, 'DisplayName': displayName };
                reviewers.push(reviewer);
            }

            userId = secondaryQA.value;
            nameId = 'secondLevelQA';

            if (!Ext.isEmpty(userId) && userId != 0) {

                displayName = 'Second Level QA';
                reviewer = { 'NameId': nameId, 'UserId': userId, 'DisplayName': displayName };
                reviewers.push(reviewer);
            }

            userId = secondOversight.value;
            nameId = 'secondaryOversight';

            if (!Ext.isEmpty(userId) && userId != 0) {

                displayName = 'Secondary Oversight';
                reviewer = { 'NameId': nameId, 'UserId': userId, 'DisplayName': displayName };
                reviewers.push(reviewer);
            }

            userId = secondCTOversight.value;
            nameId = 'ctSecondaryOversight';

            if (!Ext.isEmpty(userId) && userId != 0) {

                displayName = 'CT Secondary Oversight';
                reviewer = { 'NameId': nameId, 'UserId': userId, 'DisplayName': displayName };
                reviewers.push(reviewer);
            }
            //
            // Search for duplicates
            //
            var duplicates = [];                            
            
            Ext.each(reviewers, function (caseReviewer) {

                duplicates = reviewers.filter(function (rev) {

                    return rev.UserId == caseReviewer.UserId;
                });

                if (duplicates.length > 1) {

                    Ext.Msg.alert("Error", "Same person cannot be selected as " + duplicates[0].DisplayName + " and " + duplicates[1].DisplayName);

                    return false;
                }
            });

            if (duplicates.length > 1) {

                duplicates = [];

                return false;
            }

            return true;
        }

        var onBeforeClose = function () {

            if (!checkforMandatoryFields()) {
                return false;
            }

            return checkForDuplicates();
        }

        controller.control({
            '#caseSetUpLink': {
                click: Ext.ComponentQuery.query('#caseSetUpLink')[0].getEl().on('click', show)
            },
            '#caseSetupUI': {
                afterRender: onAfterRender
                //beforeclose: onBeforeClose

            },
            '#caseSetupSave': {
                click : onSave
            },
            '#caseSetupCancel': {
                click: onCancel
            },
            '#caseSetUpUIWindow': {
                beforeclose: onBeforeClose
            }
        });

        var registerEvents = function () {
            //edit.mon(self.getUnitCancel(), 'click', cancel);
            //edit.mon(self.getUnitSave(), 'click', save);
            edit.mon(edit, 'close', close);
        };


        ///* istanbul ignore else  */
        //if (window.jasmine) {
        //    self.enableDisableHandler = enableDisableHandler;
        //    self.addEdit = addEdit;
        //}
    }
});