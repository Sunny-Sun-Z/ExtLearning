﻿Ext.define('App.CaseReview.controller.common.Goal', {
    extend: 'Ext.app.Controller',
    requires: [
        'framework.MessageBox',
        'framework.Store',
        'framework.view.Form',
        'framework.form.CheckboxGroup'
    ],
    refs: [],
    init: function (goalGrid, record, edit) {
        var self = this;
        var form;
        var newChildRaceStoreId = null;
        var checkboxState = null;
        var close = function () {
            /* istanbul ignore else  -- can't get to this other than by using GUI */
            if (!formSaved) {
                goalGrid.plugins[0].fireEvent('canceledit');
            }
        };

        var cancel = function () {
            edit.close();
        };
        var formSaved = false;

        var save = function () {
            if (!form.isValid()) { return; }
            var prop;
            var dirtyFields = form.getForm().getFieldValues();
            for (prop in dirtyFields) {
                /* istanbul ignore else  -- only for completeness */
                if (dirtyFields.hasOwnProperty(prop)) {
                    record.data[prop] = dirtyFields[prop];
                }
                if (prop == "IsCurrentGoal") {
                    record.data[prop] = checkboxState;
                    if (checkboxState == sr.CheckboxState.Checked) {

                        // Since the fields are disabled , getFieldValues() dont return disabled fields.
                        record.data["ReasonForGoalChange"] = "";
                        record.data["DateGoalChanged"] = null;
                    }
                }
            }

            record.commit();
           
            
             
            formSaved = true;
            edit.close();
            // enables the buttons
            goalGrid.plugins[0].fireEvent('edit', goalGrid, { record: record });

            synchronizeGoalChanges();
        };

 

        var onAfterRender = function (e) {
            var items = Ext.ComponentQuery.query('#goalHelperEdit [itemId]');
            var i, itemId;
            var itemsLength = items.length;
            for (i = 0; i < itemsLength; i++) {
                itemId = items[i].itemId;
                self.addRef([{ ref: itemId, selector: '#' + itemId }]);
            }
            e.updateLayout({ defer: false, isRoot: true });
            form = Ext.ComponentQuery.query('#goalHelperEdit')[0];
            var shadowRecord = {};
            var prop;
            for (prop in record.data) {
                /* istanbul ignore else  -- only for completeness */
                if (record.data.hasOwnProperty(prop)) {
                    shadowRecord[prop] = record.data[prop];
                }
                if (prop == "IsCurrentGoal") {
                    if (record.data[prop] == 2) {
                        checkboxState = sr.CheckboxState.Unchecked;
                    }

                }
            }
            form.getForm().setValues(shadowRecord);

            
            self.getIsCurrentGoal().on('change', function (checkbox, newValue, oldValue) {
                if (newValue) {

                    self.getDateGoalChanged().allowBlank = true;
                    self.getReasonForGoalChange().allowBlank = true;
                    self.getDateGoalChanged().setDisabled(true);
                    self.getReasonForGoalChange().setDisabled(true);
                    self.getDateGoalChanged().setValue(null);
                    self.getReasonForGoalChange().setValue(null);

                    checkboxState = sr.CheckboxState.Checked;
                } else {


                    self.getDateGoalChanged().allowBlank = false;
                    self.getReasonForGoalChange().allowBlank = false;
                    self.getDateGoalChanged().setDisabled(false);
                    self.getReasonForGoalChange().setDisabled(false);


                    checkboxState = sr.CheckboxState.Unchecked;
                }


            });

            registerEvents();


        };

        var registerEvents = function () {
            edit.mon(self.getUnitCancel(), 'click', cancel);
            edit.mon(self.getUnitSave(), 'click', save);
            edit.mon(edit, 'close', close);
        };

        edit.mon(edit, 'afterrender', onAfterRender);
        edit.show({});

        /* istanbul ignore else  */
        if (window.jasmine) {
            self.close = close;
            self.cancel = cancel;
            self.save = save;
            self.onAfterRender = onAfterRender;
        }
    }
});