﻿Ext.define('App.CaseReview.controller.common.CaseParticipantGrid',
{
    extend: 'Ext.Base',
    constructor: function (controller) {
        var self = this;
        var grid = controller.getCaseParticipantGrid(); 
        var gridAdd = sr.ItemIds.caseParticipantGridAddButton;
        var gridEdit = sr.ItemIds.caseParticipantGridEditButton;
        var gridDelete = sr.ItemIds.caseParticipantGridDeleteButton;
        var businessRuleResult = grid.plugins[1].getRulesEvalResult().ruleResult;

        var enableDisableQuestions = function () {

            var items = grid.ownerCt.items.items;

            if (businessRuleResult == 'disable') {
                Ext.each(items, function (item) {
                    if (!(item.xtype == 'headerUI'  ||
                          item.xtype == 'gridpanel' ||
                          item.xtype == 'container' ||
                          item.xtype == 'qaNotes')) {
                        
                        item.cascade(function () { item.disable(true)});                        
                    }
                });
            }
        };

        var enableDisableHandler = function () {
            
        };

        /* istanbul ignore next: can only be tested with a gui  */
        var addEdit = function (record) {

            var edit = Ext.create('App.CaseReview.view.common.CaseParticipantHelper');
            Ext.create('App.CaseReview.controller.common.CaseParticipant')
                                .init(grid, record, edit);
        };

        var deleteRecord = function (record) {

            if (grid.getStore().getCount() == 1) {
                Ext.Msg.alert("Warning","This row cannot be deleted from table G2. Please click on the participant's name to edit. ");
            } else {
                if (isRecordAssociated(record)) {
                } else {
                    grid.plugins[0].fireEvent('recorddelete', grid, { record: record });

                    var parms = {};
                    parms['recordType'] = 'Grid';
                    parms['storeId'] = grid.store.storeId;

                    runFacesheetRules(getAppController(), 'caseParticipantGrid', parms);

                    FacesheetFunctions.fireFocusEvent();
                }
            }
        }

        var isRecordAssociated = function (participantRecord) {
            var participantId = participantRecord.data.CaseParticipantID;
            var recordAssociated = false;
            
            var caseType = getCaseType();

            if (caseType == 'Foster Case') {

                var tempOutcome4Store = Ext.data.ChainedStore.create({
                    source: 'CR_Outcome_CollectionStore',
                    filters: [
                        function (record) {
                            return record.get('OutcomeCode') == 4;
                        }
                    ]
                });

                if (tempOutcome4Store.count() > 0) {

                    var outCome4ItemCollection = tempOutcome4Store.getAt(0).data.CR_Item_Collection;
                    Ext.Array.forEach(outCome4ItemCollection, function (record) {
                        if (record.ItemCode == 9 || record.ItemCode == 12) {
                            if (!Ext.isEmpty(record.CR_ItemParticipant_Collection)) {
                                var itemParticipantCollection = record.CR_ItemParticipant_Collection;
                                Ext.Array.forEach(itemParticipantCollection, function (recordItemParticipant) {
                                    if (recordItemParticipant.ParticipantID == participantId) {
                                        Ext.Msg.alert("Warning", "Participant cannot be deleted because this participant is referenced in case applicability for other items.");
                                        return recordAssociated = true;

                                    }
                                });

                            }

                        }
                    });

                } 
            }
            if (recordAssociated) {
                return recordAssociated;
            }


            // Well being Outcome 1
            var tempOutcome5Store = Ext.data.ChainedStore.create({
                source: 'CR_Outcome_CollectionStore',
                filters: [
                    function (record) {
                        return record.get('OutcomeCode') == 5;
                    }
                ]
            });

            if (tempOutcome5Store.count() > 0) {

                var outCome5ItemCollection = tempOutcome5Store.getAt(0).data.CR_Item_Collection;
                Ext.Array.forEach(outCome5ItemCollection, function (record) {
                    if (record.ItemCode == 15 || record.ItemCode == 17 || record.ItemCode == 19) {
                        if (!Ext.isEmpty(record.CR_ItemParticipant_Collection)) {
                            var itemParticipantCollection = record.CR_ItemParticipant_Collection;
                            Ext.Array.forEach(itemParticipantCollection, function(recordItemParticipant) {
                                if (recordItemParticipant.ParticipantID == participantId) {
                                    Ext.Msg.alert("Warning", "Participant cannot be deleted because this participant is referenced in case applicability for other items.");
                                    return recordAssociated = true;
                                  
                                }
                            });

                        }
                        
                    }
                });

            }




            return recordAssociated;


        }

        controller.caseParticipantGridEventHandler = Ext.create('framework.controller.GridAddEditDeleteEventHandlers', controller.viewModel,
        {
            'grid': grid,
            'add': gridAdd,
            'edit': gridEdit,
            'del': gridDelete,
            'insertRecord': {}, // blank record
            addAction: addEdit,
            editAction: addEdit,
            deleteAction: deleteRecord
        });

        controller.control({
            '#caseParticipantGridAdd': {
                'enable': enableDisableHandler
            },
            '#caseParticipantGrid': {
                'selectionchange': enableDisableHandler
            }
        });

        /* istanbul ignore else  */
        if (window.jasmine) {
            self.enableDisableHandler = enableDisableHandler;
            self.addEdit = addEdit;
        }

        enableDisableQuestions();

    }
});