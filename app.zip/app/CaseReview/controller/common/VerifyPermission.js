﻿Ext.define('App.CaseReview.controller.common.VerifyPermission',
{
    extend: 'Ext.Base',
    singleton: true,
    alternateClassName: 'VerifyPermission',
    checkforPermissionInCase: function (persmission) {
        var userId = window.userID;
        if (Ext.isEmpty(userId)) {
            return false;
        }

        var caseRole = this.getCaseRole(userId);
        if (Ext.isEmpty(caseRole)) {
            return false;
        }

        var rolePermissionStore = chainedStore('CrSecurityRolePermissionStore');
        var hasCaseRoleGotPermission = false;
        if (!Ext.isEmpty(rolePermissionStore)) {
            rolePermissionStore.each(function (record) {
                if (record.data.PermissionID == persmission && record.data.RoleID == caseRole) {
                    hasCaseRoleGotPermission = true;
                }
            });
        }

        if (hasCaseRoleGotPermission) {
            var userRolePermissionStore = chainedStore('CrUserRolePermissionMappingsStore');
            if (!Ext.isEmpty(userRolePermissionStore)) {
                userRolePermissionStore.each(function(record) {
                    if (record.data.PermissionID == persmission) {
                        return true;
                    }
                });

            }
        }
        return false;
    },
    getCaseRole: function (userId) {
        var caseReviewStore = chainedStore('CaseReviewStore');
        
        // Check QA and Oversight roles first
        if (caseReviewStore.count() > 0 && !Ext.isEmpty(caseReviewStore.getAt(0)))
        {
            var caseReview = caseReviewStore.getAt(0).data;
            if (caseReview.InitialQAUserID == userId || caseReview.SecondQAUserID == userId) {
                return sr.UserRoles.StateSideLeader;
            }
            if (caseReview.SecondaryOversightUserID == userId || caseReview.CtSecondaryOversightUserID == userId) {
                return sr.UserRoles.FederalReviewer;
            }
        }
        
        // Check reviewers
        var reviewerStore = Ext.data.ChainedStore.create({
            source: 'CR_Reviewer_CollectionStore',
            filters: [
                function (record) {
                    return record.data.UserID == userId;
                }
            ]
        });

        if (reviewerStore.data.length > 0) {
            return sr.UserRoles.StateReviewer;

        }

        return "";
    },
});