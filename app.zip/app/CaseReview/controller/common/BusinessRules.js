﻿/* global framework */
// Enable questions. itemIdList should be passed as an array of itemId's.
var validations = {};
var initValidations = function (itemName) {

    validations[itemName] = undefined;
}
var enableItem = function (itemIdList) {
    var item;

    Ext.each(itemIdList, function (itemId) {
        item = getCRSComponent(itemId);

        if (!(Ext.isEmpty(item))) {

            item.enable();
        }
    });
}
// Disable questions. itemIdList should be passed as an array of itemId's.
var disableItem = function (itemIdList) {
    var item;

    Ext.each(itemIdList, function (itemId) {
        item = getCRSComponent(itemId);

        if (!(Ext.isEmpty(item))) {

            item.disable();
        }
    });
}
var updateItemStatus = function (compObj,parms) {
    
    var itemStatus;

    if (Ext.isEmpty(parms)) {

        return;
    }

    var validationResult = validationResults[parms.itemName];
    var item = getItemFromGraph(parms.itemCode, parms.outcomeCode);

    if (!Ext.isEmpty(item) && !Ext.isEmpty(parms.itemCode)) {

        var currentRating = item.ItemRatingCode;

        if (currentRating == 3) {

            itemStatus = 'Completed';

            itemStatuses[parms.itemName] = itemStatus;

            var inputObj = { ItemCode: parms.itemCode, OutcomeCode: parms.outcomeCode, StatusDesc: itemStatus };

            updateItemStatusCode(inputObj);

            var caseStatus = calculateCaseStatus();

            updateAllOutcomeRatings();

            return;
        }
    }

    if (compObj.rendered) {
        //
        // Calculate status
        //
        if (!Ext.isEmpty(validationResult)) {

            validationResult['ItemName'] = parms.itemName;

            itemStatus = determineItemStatus(parms.itemName);
        }
    } else {
        //
        // Get saved status
        //
        itemStatus = getItemStatus(parms.itemCode);
    }

    itemStatuses[parms.itemName] = itemStatus;

    var caseStatus = calculateCaseStatus();

    updateAllOutcomeRatings();
}
var runFacesheetRules = function (comp, section, parms) {

    try{

        validateFacesheetItems(comp, section, parms);

    } catch (ex) {

        appErrors.push(ex);

        Rollbar.error("Application Error", ex);
    }    
}
var runSafetyRules = function (comp, section, validationMethod, parms, saveDataOnly) {

    try{

        validateSafetyItems(comp, section, validationMethod, parms, saveDataOnly);

    } catch (ex) {

        appErrors.push(ex);

        Rollbar.error("Application Error", ex);
    }
}
var runPermanencyRules = function (comp, section, parms, saveDataOnly) {

    try{

        validatePermanencyItems(comp, section, parms, saveDataOnly);

    } catch (ex) {

        appErrors.push(ex);

        Rollbar.error("Application Error", ex);
    }    
}
var runWellbeingRules = function (comp, section, parms) {

    try{

        validateWellbeingItems(comp, section, parms);

    }catch(ex){

        appErrors.push(ex);

        Rollbar.error("Application Error", ex);
    }    
}
var saveChanges = function (parms) {

    if (Ext.isEmpty(parms)) {

        return;
    }

    if (Ext.isEmpty(parms.storeId)) {

        return;
    }
    
    updateStore(parms);
}
var runFacesheetBusinessRules = function (compObj, section) {

    var updateFosterEntryDate = function () {

        var comp = compObj.getFosterEntryDate();
        var result = comp.plugins[0].getRulesEvalResult();
        var caseType = getCaseType();

        if (result.ruleResult == 'disable') {

            comp.setValue(null);
            comp.disable();
        } else {
            comp.enable();
        }

        if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

            var checkBoxNA = compObj.getIsFosterCareDateNA();

            var parms = { currentVal: checkBoxNA.inputValue };
            var selection = checkBoxNA.inputValue;

            var fields = [];
            var field = { 'IsFosterEntryDateNA': selection };

            fields.push(field);

            parms['storeId'] = 'CR_FaceSheet_CollectionStore';
            parms['fields'] = fields;
            
            checkBoxNA.setValue(selection);

            saveChanges(parms);
        }
    };

    var updateEpisodeDischargeDate = function () {


        appController = compObj;

        var comp = compObj.getEpisodeDischargeDate();
        var result = comp.plugins[0].getRulesEvalResult();
        var caseType = getCaseType();

        if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {
            var checkBoxNA = compObj.getDischargeNA();

            var parms = { currentVal: checkBoxNA.inputValue };
            var selection = checkBoxNA.inputValue;

            var fields = [];
            var field = { 'IsEpisodeDischargeDateNA': selection };

            fields.push(field);

            parms['storeId'] = 'CR_FaceSheet_CollectionStore';
            parms['fields'] = fields;

            checkBoxNA.setValue(selection);

            saveChanges(parms);

            checkBoxNA.setReadOnly(true);

            var checkBoxNotDischarged = compObj.getNotYetDischarged();
            checkBoxNotDischarged = checkBoxNotDischarged.setValue(null);

            // Disable datefield
            comp.setValue(null);
            comp.disable();
        }
    };

    var updateCaseClosureDate = function () {

        var caseClosureDate = compObj.getCaseClosureDate();
        var reviewEndDate;
        var store = Ext.data.StoreManager.lookup('CaseReviewStore');

        if (store.data.count() > 0) {

            reviewEndDate = store.getAt(0).data.ReviewCompleted;
        }

        if (caseClosureDate.value > reviewEndDate) {
            var closureInd = compObj.getCaseClosureClosedInd();

            closureInd.setValue('3');
            caseClosureDate.setValue('');
        }
    };

    switch (section) {

        case sr.Constants.AllFields:

            updateFosterEntryDate();
            updateEpisodeDischargeDate();
            updateCaseClosureDate();

            break;

        case 'isFosterCareDateNA_change':

            var entryDateNA = compObj.getIsFosterCareDateNA();
            var entryDate = compObj.getFosterEntryDate();

            if (entryDateNA.checked == true) {

                entryDate.setValue(null);
                entryDate.disable();
            } else {

                entryDate.enable();
            }

            break;
  
        case 'dischargeNA_change':

            if (compObj.getDischargeNA().checked == true) {
                compObj.getEpisodeDischargeDate().setValue(null);
                compObj.getEpisodeDischargeDate().disable();
                compObj.getNotYetDischarged().disable();

                if (compObj.getNotYetDischarged().getValue() == 1)
                    compObj.getNotYetDischarged().setValue(0);
                else
                    compObj.getNotYetDischarged().setValue(null);
            } else {
                compObj.getEpisodeDischargeDate().enable();
                compObj.getNotYetDischarged().enable();
            }

            break;

        case 'notYetDischarged_change':

            if (compObj.getNotYetDischarged().checked == true) {

                compObj.getEpisodeDischargeDate().setValue(null);
                //
                // Update store
                //

                compObj.getEpisodeDischargeDate().disable();
                compObj.getDischargeNA().disable();

                if (compObj.getDischargeNA().getValue() == 1)
                    compObj.getDischargeNA().setValue(0);
                else
                    compObj.getDischargeNA().setValue(null);
            } else {
                compObj.getEpisodeDischargeDate().enable();
                compObj.getDischargeNA().enable();
            }

            break;

        case 'caseClosureClosedInd_change':

            if (compObj.getCaseClosureClosedInd().checked == true) {
                compObj.getCaseClosureDate().setValue(null);
                
            } else {
                compObj.getCaseClosureDate().enable();
            }

            break;

        case 'caseRsn14_change':

            if (compObj.getCaseRsn14().checked == true) {
                compObj.getQuestionMNarrative().setDisabled(false);
            } else {
                compObj.getQuestionMNarrative().setDisabled(true);
                compObj.getQuestionMNarrative().setValue(null);
            }

            break;

        case 'episodeDischargeDate_change':

            appController = compObj;

            var checkBoxNotDischarged = compObj.getNotYetDischarged();
            checkBoxNotDischarged = checkBoxNotDischarged.setValue(null);
            
            compObj.getQuestion6A3().setValue(null);

            break;

        case 'caseClosureDate_change':

            var closureInd = compObj.getCaseClosureClosedInd();

            closureInd.setValue(null);

            break;

        default:

            break;
    }
    //
    // Instructions should be enabled at all times
    //
    compObj.getG1Instructions().enable();
    compObj.getG2Instructions().enable();
    //---------------------------------------------
    //---------------------------------------------
    var childDemographicGrid = compObj.getChildDemographicGrid();
    var participantGrid = compObj.getCaseParticipantGrid();

    childDemographicGrid.plugins[1].evaluateFields();
    childDemographicGrid.plugins[1].runBusinessRules();

    participantGrid.plugins[1].evaluateFields();
    participantGrid.plugins[1].runBusinessRules();

    var childGridResult = childDemographicGrid.plugins[1].getRulesEvalResult();
    var participantGridResult = participantGrid.plugins[1].getRulesEvalResult();
    var action = (childGridResult.ruleResult == 'enable' && participantGridResult.ruleResult == 'enable') ? 'enable' : 'disable';
    var items = childDemographicGrid.ownerCt.items.items;

    Ext.each(items, function (item) {
        if (!(item.xtype == 'headerUI' ||
                item.xtype == 'gridpanel' ||
                item.xtype == 'container' ||
                item.xtype == 'qaNotes' ||
                item.xtype == 'listPanel')) {

            if (action == 'disable') {
                item.cascade(function () { item.disable(true) });
            }

            if (action == 'enable') {
                item.cascade(function () { item.enable(true) });
            }
        }
    });
    //
    // Disable date in question J,K and check the NA box for In-Home cases.
    //
    var model = getAppController();

    if (!Ext.isEmpty(model)) {

        var comp = model.getEpisodeDischargeDate();
        var result = comp.plugins[0].getRulesEvalResult();
        var fosterEntryDate = model.getFosterEntryDate();

        if (result.validityResult == 'inHomeCase') {
            //
            // Question J
            //            
            fosterEntryDate.setValue(null);
            fosterEntryDate.disable();

            //
            // Question K
            //
            var checkBoxNA = model.getDischargeNA();
            checkBoxNA = checkBoxNA.setValue(1);

            var checkBoxNotDischarged = model.getNotYetDischarged();
            checkBoxNotDischarged = checkBoxNotDischarged.setValue(null);
            checkBoxNotDischarged.disable();

            // Disable datefield
            comp.setValue(null);
            comp.disable();
        } else {

            fosterEntryDate.enable();
            comp.enable();
        }
    }
    //
    // Disable the NA box for questions J,K for Foster care cases.
    //
    if (!Ext.isEmpty(model)) {

        var caseType = getCaseType();

        if (caseType == 'Foster Case') {

            var entryDateNA = model.getIsFosterCareDateNA();
            var dischargeDateNA = model.getDischargeNA();

            entryDateNA.setValue(false);
            entryDateNA.disable();

            dischargeDateNA.setValue(false);
            dischargeDateNA.disable();
        }
    }
}
var runSafetyBusinessRules = function (compObj,section, parms) {

    var run3D1Rules = function (compObj) {

        var comp = compObj.getItem3D1();
        var result = comp.plugins[0].getRulesEvalResult();

        //if (result.validityResult == 'noSubstantiatedReports') {

        //    var incident = compObj.getIncident3();

        //    incident.setValue(false);
        //    incident.disable();
        //}

        //if (result.ruleResult == 'noOpenedForServicesReports') {

        //    var incident = compObj.getIncident4();

        //    incident.setValue(false);
        //    incident.disable();
        //}

        var incident1 = compObj.getIncident1();

        if (incident1.getValue()) {
            var incident3 = compObj.getIncident3();
            var incident4 = compObj.getIncident4();

            incident3.setValue(false);
            incident3.disable();

            incident4.setValue(false);
            incident4.disable();
        }
    }

    var updateItem2Question1 = function () {

        var comp = compObj.getItem2Question1();
        var result = comp.plugins[0].getRulesEvalResult();

        if (result.validityResult == 'fosterCareCase') {

            var yesComp = compObj.getItem2Concern1Yes();
            var noComp = compObj.getItem2Concern1No();

            yesComp.setValue(false);
            yesComp.setReadOnly(true);

            noComp.setValue(true);
            noComp.setReadOnly(true);

            var parms = {};
            var newVal = {};
            var oldVal = {};

            newVal[noComp.inputId] = noComp.inputValue;
            oldVal[yesComp.inputId] = yesComp.inputValue;

            parms['radio'] = noComp;
            parms['oldRadio'] = yesComp;
            parms['newValue'] = newVal;
            parms['oldValue'] = oldVal;

            processItem2PreAppResponse(parms);
        }
    }

    var updateItem2Question2 = function () {

        var comp = compObj.getItem2Question2();
        var result = comp.plugins[0].getRulesEvalResult();

        if (result.validityResult == 'fosterCareCase') {

            var yesComp = compObj.getItem2Concern2Yes();
            var noComp = compObj.getItem2Concern2No();

            yesComp.setValue(false);
            yesComp.setReadOnly(true);

            noComp.setValue(true);
            noComp.setReadOnly(true);

            var parms = {};
            var newVal = {};
            var oldVal = {};

            newVal[noComp.inputId] = noComp.inputValue;
            oldVal[yesComp.inputId] = yesComp.inputValue;

            parms['radio'] = noComp;
            parms['oldRadio'] = yesComp;
            parms['newValue'] = newVal;
            parms['oldValue'] = oldVal;

            processItem2PreAppResponse(parms);
        }
    }

    var updateItem2Question2B = function () {

        var comp = compObj.getItem2Question2B();
        var result = comp.plugins[0].getRulesEvalResult();

        if (result.validityResult == 'other') {

            var yesComp = compObj.getQuestion2BYes();
            var noComp = compObj.getQuestion2BNo();
            var naComp = compObj.getQuestion2BNA();
            var questions = getItemQuestions('item2');
            var itemCode = 3;
            var outcomeCode = 2;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'safety' };

            yesComp.setValue(false);
            noComp.setValue(false);
            naComp.setValue(3);

            parms['ItemName'] = 'item2';
            parms['Question'] = 'Question2B';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);

            //
            // Update store
            //
            var fields = [];
            var field = { 'IsChildRemovedToEnsureSafety': 3 };
            fields.push(field);

            field = { 'ChildRemovedToEnsureSafetyExplained': '' };
            fields.push(field);

            var parms = { currentVal: true };
            parms['storeId'] = 'CR_Safety_CollectionStore';
            parms['fields'] = fields;

            parms = getStatusParms(parms, 'safetyItem2Rating');
            parms['runValidations'] = false;
            initValidations('Item2');
            parms['dataChanged'] = true;
            
            runSafetyRules(getAppController(), 'ValidateItem2', null, parms, true);

            var concerns2BNA = getAppController().getChildRemovalConcerns();
            var retObj = concerns2BNA.setValue('');
            concerns2BNA.disable();
        }
    }

    var updateItem2Question3 = function () {

        var comp = compObj.getItem2Question3();
        var result = comp.plugins[0].getRulesEvalResult();

        if (result.validityResult == 'inHomeCase') {

            //var yesComp = compObj.getItem2Concern3Yes();
            //var noComp = compObj.getItem2Concern3No();

            //yesComp = setComponentValue(yesComp, false);
            //yesComp.setReadOnly(true);

            //noComp = setComponentValue(noComp, true);
            //noComp.setReadOnly(true);

            return;
        }

        var index = comp.plugins.length - 1;

        result = comp.plugins[index].getRulesEvalResult();
        if (result.ruleResult == 'fosterCareCase') {

            //var yesComp = compObj.getItem2Concern3Yes();
            //var noComp = compObj.getItem2Concern3No();

            //yesComp = setComponentValue(yesComp, true);
            //yesComp.setReadOnly(true);

            //noComp = setComponentValue(noComp, false);
            //noComp.setReadOnly(true);

            return;
        }
    }

    var updateItem2Question4 = function () {

        var comp = compObj.getItem2Question4();
        var result = comp.plugins[0].getRulesEvalResult();

        if (result.validityResult == 'inHomeCase') {

            var yesComp = compObj.getItem2Concern4Yes();
            var noComp = compObj.getItem2Concern4No();

            yesComp = setComponentValue(yesComp, false);
            yesComp.setReadOnly(true);

            noComp = setComponentValue(noComp, true);
            noComp.setReadOnly(true);

        }
    }

    var updateItem2Question5 = function () {

        var comp = compObj.getItem2Question5();
        var result = comp.plugins[0].getRulesEvalResult();

        if (result.validityResult == 'inHomeCase') {

            var yesComp = compObj.getItem2Concern5Yes();
            var noComp = compObj.getItem2Concern5No();

            yesComp = setComponentValue(yesComp, false);
            yesComp.setReadOnly(true);

            noComp = setComponentValue(noComp, true);
            noComp.setReadOnly(true);

            return;
        }

        var index = comp.plugins.length - 1;

        result = comp.plugins[index].getRulesEvalResult();
    }

    var updateSection3A1 = function () {

        var item = getItem(4, 2);

        if (!(item == undefined)) {

            item.IsApplicable = 1;

            updateItem(item);
        }
    }

    var updateItem3E = function () {

        var comp = compObj.getItem3E();
        var result = comp.plugins[0].getRulesEvalResult();

        if (result.validityResult == 'other') {

            var yesComp = compObj.getQuestion3EYes();
            var noComp = compObj.getQuestion3ENo();
            var naComp = compObj.getQuestion3ENA();
            var questions = getItemQuestions('item3');
            var itemCode = 4;
            var outcomeCode = 2;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'safety' };

            yesComp.setValue(false);
            noComp.setValue(false);
            naComp.setValue(3);
            
            parms['ItemName'] = 'item3';
            parms['Question'] = 'Question3E';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
            //
            // Update store
            //
            processQuestion3Change(naComp, 'IsFosterSafetyConcernDuringVisitation');
        }
    }

    var updateItem3E1 = function () {

        var comp = compObj.getItem3E1();
        var result = comp.plugins[0].getRulesEvalResult();

        var concern1 = compObj.getSafetyConcern1();
        var concern2 = compObj.getSafetyConcern2();
        var concern3 = compObj.getSafetyConcern3();
        var concern4 = compObj.getSafetyConcern4();
        var concern5 = compObj.getSafetyConcern5();
        var concern6 = compObj.getSafetyConcern6();
        var placementConcern1 = compObj.getPlacementConcern1();

        var caseType = getCaseType();

        if (caseType == 'Foster Case') {

            //concern1.setValue(false);
            //concern1.setDisabled(true);

            placementConcern1.setValue(false);
            placementConcern1.setDisabled(true);
        }

        if (result.validityResult == 'other') {

            concern1.setValue(92);

            concern2.setValue(false);
            concern3.setValue(false);
            concern4.setValue(false);
            concern5.setValue(false);
            concern6.setValue(false);

            concern1.setReadOnly(true);
            concern2.setDisabled(true);
            concern3.setDisabled(true);
            concern4.setDisabled(true);
            concern5.setDisabled(true);
            concern6.setDisabled(true);
        }
    }

    var updateItem3F = function () {

        var comp = compObj.getItem3F();
        var result = comp.plugins[0].getRulesEvalResult();

        var yesComp = compObj.getQuestion3FYes();
        var noComp = compObj.getQuestion3FNo();
        var naComp = compObj.getQuestion3FNA();

        var caseType = getCaseType();

        yesComp.enable();
        noComp.enable();
        naComp.enable();

        if (caseType == 'Foster Case') {

            naComp.setValue(false);
            naComp.disable();
        }

        if (result.validityResult == 'other') {

            yesComp.setValue(false);
            noComp.setValue(false);
            naComp.setValue(3);
            var questions = getItemQuestions('item3');
            var itemCode = 4;
            var outcomeCode = 2;
            var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'safety' };
            
            parms['ItemName'] = 'item3';
            parms['Question'] = 'Question3F';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
            //
            // Update store
            //
            processQuestion3Change(naComp, 'IsFosterSafetyConcernNotAddressed');
        }
    }

    var updateItem3F1 = function () {

        var comp = compObj.getItem3F1();
        var result = comp.plugins[0].getRulesEvalResult();

        if (result.validityResult == 'other') {

            var concern1 = compObj.getPlacementConcern1();
            var concern2 = compObj.getPlacementConcern2();
            var concern3 = compObj.getPlacementConcern3();
            var concern4 = compObj.getPlacementConcern4();
            var concern5 = compObj.getPlacementConcern5();
            var concern6 = compObj.getPlacementConcern6();
            var concern7 = compObj.getPlacementConcern7();

            concern1.setValue(98);
            concern1.setReadOnly(true);

            concern2.setValue(false);
            concern3.setValue(false);
            concern4.setValue(false);
            concern5.setValue(false);
            concern6.setValue(false);
            concern7.setValue(false);

            concern2.setDisabled(true);
            concern3.setDisabled(true);
            concern4.setDisabled(true);
            concern5.setDisabled(true);
            concern6.setDisabled(true);
            concern7.setDisabled(true);
        }

        if (result.ruleResult == 'noSubstantiatedReports') {

            var concern3 = compObj.getPlacementConcern3();

            concern3.setValue(false);
            concern3.disable();
        }

        var concern1 = compObj.getPlacementConcern1();

        if (concern1.getValue()) {
            var concern3 = compObj.getPlacementConcern3();

            concern3.setValue(false);
            concern3.disable();
        }
    }

    switch (section) {

        case sr.Constants.AllFields:

            if (!(isCaseApplicable(2, 1))) {

                // Disable section for Item 1
                disableContainerItems(['safetyReportGrid', 'item1Questions']);
                setDisabledFieldValuesInContainer(['safetyReportGrid', 'item1Questions']);
            }

            if (!(isCaseApplicable(3, 2))) {

                // Disable section for Item 2
                disableContainerItems(['question2APanel', 'question2BPanel']);
                setDisabledFieldValuesInContainer(['question2APanel', 'question2BPanel']);
                //deleteFieldValues(['item2Comments']);
            }

            updateItem2Question1();
            updateItem2Question2();
            updateItem2Question2B();
            updateItem2Question3();
            updateItem2Question4();
            updateItem2Question5();
            updateSection3A1();

            var modelData = window.safetyViewModel.data.safetyCollection.getAt(0).data;
            var answer3ANo = modelData.IsInitialAssesmentForAllChildrenInHome;

            if (answer3ANo == 2) {

                getAppController().getInitialAssessmentExplained().enable();
            }

            var answer3BNo = modelData.IsOngoingAssesementForAllChildrenInHome;

            if (answer3BNo == 2) {

                getAppController().getOngoingAssessmentExplained().enable();
            }

            var answer3CNo = modelData.IsSafetyPlanDevelopedAndMonitored;

            if (answer3CNo == 2) {

                getAppController().getSafetyPlanExplained().enable();
            }

            run3D1Rules(getAppController());
            updateItem3E();
            updateItem3E1();
            updateItem3F();
            updateItem3F1();

            break;

        case 'item2CaseApplicableNo':
            
            var item = getItem(3, 2);

            if (!(item == undefined)) {

                item.IsApplicable = 2;
                updateItem(item);
            }

            // Disable section for Item 2
            disableContainerItems(['question2APanel', 'question2BPanel']);

            setDisabledFieldValuesInContainer(['question2APanel', 'question2BPanel']);
            //deleteFieldValues(['item2Comments']);

            break;

        case 'item2CaseApplicableYes':
            
            var item = getItem(3, 2);

            if (!(item == undefined)) {

                item.IsApplicable = 1;
                updateItem(item);
            }

            // Enable section for Item 2
            enableContainerItems(['question2APanel', 'question2BPanel', 'item2CommentsContainer']);

            break;

        case 'item3F1':

            updateItem3F1();

            break;

        case 'safetyReportGrid':
        case 'ValidateItem1':

            var comp = compObj.getSafetyReportGrid();
            var qaNotes = compObj.getSafetyOutcome1Notes();

            qaNotes.cascade(function () { qaNotes.enable(true) });

            comp.plugins[1].evaluateFields();
            comp.plugins[1].runBusinessRules();

            var result = comp.plugins[1].getRulesEvalResult();
            var item1Questions = compObj.getItem1Questions();
            var ratingPanel = compObj.getItem1Rating();
            var caseApplicable = isCaseApplicable(2, 1);

            if (caseApplicable) {
                if (result.ruleResult == 'enable') {

                    enableContainerItems(['item1Questions']);

                    ratingPanel.cascade(function () { ratingPanel.enable(true) });
                }
            }
            
            if (result.ruleResult == 'disable') {

                disableContainerItems(['item1Questions']);

                setDisabledFieldValuesInContainer(['safetyReportGrid', 'question1AContainer', 'question1BContainer', 'question1CContainer', 'question1BDelaysContainer']);
            }

            break;

        case 'question1A':

            var cmp = getAppController().getQuestion1A();
            var safetyStore = chainedStore('CR_SafetyReport_CollectionStore');
            var noTableRows = safetyStore.count();
            var inputVal = cmp.value < 0 ? 0 :
                           cmp.value > noTableRows ? noTableRows : cmp.value;

            cmp.setValue(inputVal);

            // Disable appropriate buttons in question 1C
            var item1CNA = getAppController().getItem1CNA();
            var question1B = getAppController().getQuestion1B();

            var item1CYes = getAppController().getItem1CYes();
            var item1CNo = getAppController().getItem1CNo();

            if (inputVal > 0) {

                item1CNA.setValue(false);
                item1CNA.disable();

                item1CYes.enable();
                item1CNo.enable();
            } else {
                if (inputVal == 0 && question1B.getValue() == 0) {

                    item1CNA.enable();

                    item1CYes.setValue(false);
                    item1CNo.setValue(false);

                    item1CYes.disable();
                    item1CNo.disable();
                }
            }
            
            break;

        case 'question1B':

            var cmp = getAppController().getQuestion1B();
            var safetyStore = chainedStore('CR_SafetyReport_CollectionStore');
            var noTableRows = safetyStore.count();
            var inputVal = cmp.value < 0 ? 0 :
                           cmp.value > noTableRows ? noTableRows : cmp.value;

            cmp.setValue(inputVal);

            // Disable appropriate buttons in question 1C
            var item1CNA = getAppController().getItem1CNA();
            var question1A = getAppController().getQuestion1A();

            var item1CYes = getAppController().getItem1CYes();
            var item1CNo = getAppController().getItem1CNo();

            if (inputVal > 0) {

                item1CNA.setValue(false);
                item1CNA.disable();

                item1CYes.enable();
                item1CNo.enable();
            } else {
                if (inputVal == 0 && question1A.getValue() == 0) {

                    item1CNA.enable();

                    item1CYes.setValue(false);
                    item1CNo.setValue(false);

                    item1CYes.disable();
                    item1CNo.disable();
                }
            }

            break;

        case 'Question2ANo_change':

            if (parms.currentVal) {
                compObj.getAgencyEffortConcerns().setDisabled(false);
            } else {
                compObj.getAgencyEffortConcerns().setDisabled(true);
                compObj.getAgencyEffortConcerns().setValue(null);
            }

            break;

        case 'Question2BNo_change':
            
            if (parms.currentVal) {
                compObj.getChildRemovalConcerns().setDisabled(false);
            } else {
                compObj.getChildRemovalConcerns().setDisabled(true);
                compObj.getChildRemovalConcerns().setValue(null);
            }

            break;

        case 'Question3ANo_change':

            if (parms.currentVal) {
                compObj.getInitialAssessmentExplained().setDisabled(false);
            } else {
                compObj.getInitialAssessmentExplained().setDisabled(true);
                compObj.getInitialAssessmentExplained().setValue(null);
            }

            break;

        case 'Question3BNo_change':

            if (parms.currentVal) {
                compObj.getOngoingAssessmentExplained().setDisabled(false);
            } else {
                compObj.getOngoingAssessmentExplained().setDisabled(true);
                compObj.getOngoingAssessmentExplained().setValue(null);
            }

            break;

        case 'Question3CNo_change':

            if (parms.currentVal) {
                compObj.getSafetyPlanExplained().setDisabled(false);
            } else {
                compObj.getSafetyPlanExplained().setDisabled(true);
                compObj.getSafetyPlanExplained().setValue(null);
            }

            break;

        case 'incident1_change':

            if (compObj.getIncident1().checked == true) {

                if (!compObj.getIncident2().isDisabled()) {
                    compObj.getIncident2().setDisabled(true);
                    compObj.getIncident2().setValue(false);
                }

                if (!compObj.getIncident3().isDisabled()) {
                    compObj.getIncident3().setDisabled(true);
                    compObj.getIncident3().setValue(false);
                }

                if (!compObj.getIncident4().isDisabled()) {
                    compObj.getIncident4().setDisabled(true);
                    compObj.getIncident4().setValue(false);
                }

                if (!compObj.getIncident5().isDisabled()) {
                    compObj.getIncident5().setDisabled(true);
                    compObj.getIncident5().setValue(false);
                }

                if (!compObj.getIncident6().isDisabled()) {
                    compObj.getIncident6().setDisabled(true);
                    compObj.getIncident6().setValue(false);
                }

                if (compObj.getIncident6().isDisabled()) {
                    compObj.getOtherSafetyConcerns().setValue(null);
                    compObj.getOtherSafetyConcerns().disable();
                }
            } else {
                compObj.getIncident2().setDisabled(false);
                compObj.getIncident3().setDisabled(false);
                compObj.getIncident4().setDisabled(false);
                compObj.getIncident5().setDisabled(false);
                compObj.getIncident6().setDisabled(false);
            }

            run3D1Rules(compObj, section);

            break;

        case 'incident2_change':
            
            if (compObj.getIncident2().checked == true) {

                if (!compObj.getIncident1().isDisabled()) {
                    compObj.getIncident1().setDisabled(true);
                    compObj.getIncident1().setValue(false);
                }

                if (!compObj.getIncident3().isDisabled()) {
                    compObj.getIncident3().setDisabled(true);
                    compObj.getIncident3().setValue(false);
                }

                if (!compObj.getIncident4().isDisabled()) {
                    compObj.getIncident4().setDisabled(true);
                    compObj.getIncident4().setValue(false);
                }

                if (!compObj.getIncident5().isDisabled()) {
                    compObj.getIncident5().setDisabled(true);
                    compObj.getIncident5().setValue(false);
                }

                if (!compObj.getIncident6().isDisabled()) {
                    compObj.getIncident6().setDisabled(true);
                    compObj.getIncident6().setValue(false);
                }

                if (compObj.getIncident6().isDisabled()) {
                    compObj.getOtherSafetyConcerns().setValue(null);
                    compObj.getOtherSafetyConcerns().disable();
                }
            } else {

                compObj.getIncident1().setDisabled(false);
                compObj.getIncident3().setDisabled(false);
                compObj.getIncident4().setDisabled(false);
                compObj.getIncident5().setDisabled(false);
                compObj.getIncident6().setDisabled(false);
            }

            run3D1Rules(compObj, section);

            break;

        case 'incident6_change':

            if (compObj.getIncident6().checked == true) {
                compObj.getOtherSafetyConcerns().enable();
            } else {
                compObj.getOtherSafetyConcerns().disable();
                compObj.getOtherSafetyConcerns().setValue(null);
            }

            run3D1Rules(compObj, section);

            break;

        case 'safetyConcern2_change':

            var caseType = getCaseType();
                        
            if (compObj.getSafetyConcern2().checked == true) {

                if (!compObj.getSafetyConcern1().isDisabled()) {
                    compObj.getSafetyConcern1().setDisabled(true);
                    compObj.getSafetyConcern1().setValue(false);
                }

                if (!compObj.getSafetyConcern3().isDisabled()) {
                    compObj.getSafetyConcern3().setDisabled(true);
                    compObj.getSafetyConcern3().setValue(false);
                }

                if (!compObj.getSafetyConcern4().isDisabled()) {
                    compObj.getSafetyConcern4().setDisabled(true);
                    compObj.getSafetyConcern4().setValue(false);
                }

                if (!compObj.getSafetyConcern5().isDisabled()) {
                    compObj.getSafetyConcern5().setDisabled(true);
                    compObj.getSafetyConcern5().setValue(false);
                }

                if (!compObj.getSafetyConcern6().isDisabled()) {
                    compObj.getSafetyConcern6().setDisabled(true);
                    compObj.getSafetyConcern6().setValue(false);
                }

                if (compObj.getSafetyConcern6().isDisabled()) {
                    compObj.getFosterSafetyConcerns().setValue(null);
                    compObj.getFosterSafetyConcerns().disable();
                }
            } else {

                if (!(caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health')) {

                    compObj.getSafetyConcern1().setDisabled(true);
                    compObj.getSafetyConcern1().setValue(false);
                }

                compObj.getSafetyConcern3().setDisabled(false);
                compObj.getSafetyConcern4().setDisabled(false);
                compObj.getSafetyConcern5().setDisabled(false);
                compObj.getSafetyConcern6().setDisabled(false);
            }

            break;

        case 'safetyConcern6_change':

            if (compObj.getSafetyConcern6().checked == true) {
                compObj.getFosterSafetyConcerns().enable();
            } else {
                compObj.getFosterSafetyConcerns().disable();
                compObj.getFosterSafetyConcerns().setValue(null);
            }

            break;

        case 'placementConcern2_change':

            var caseType = getCaseType();

            if (compObj.getPlacementConcern2().checked == true) {

                if (!compObj.getPlacementConcern1().isDisabled()) {
                    compObj.getPlacementConcern1().setDisabled(true);
                    compObj.getPlacementConcern1().setValue(false);
                }

                if (!compObj.getPlacementConcern3().isDisabled()) {
                    compObj.getPlacementConcern3().setDisabled(true);
                    compObj.getPlacementConcern3().setValue(false);
                }

                if (!compObj.getPlacementConcern4().isDisabled()) {
                    compObj.getPlacementConcern4().setDisabled(true);
                    compObj.getPlacementConcern4().setValue(false);
                }

                if (!compObj.getPlacementConcern5().isDisabled()) {
                    compObj.getPlacementConcern5().setDisabled(true);
                    compObj.getPlacementConcern5().setValue(false);
                }

                if (!compObj.getPlacementConcern6().isDisabled()) {
                    compObj.getPlacementConcern6().setDisabled(true);
                    compObj.getPlacementConcern6().setValue(false);
                }


                if (!compObj.getPlacementConcern7().isDisabled()) {
                    compObj.getPlacementConcern7().setDisabled(true);
                    compObj.getPlacementConcern7().setValue(false);
                }

                if (compObj.getPlacementConcern7().isDisabled()) {
                    compObj.getOtherPlacementConcerns().setValue(null);
                    compObj.getOtherPlacementConcerns().disable();
                }
            } else {

                if (!(caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health')) {

                    compObj.getPlacementConcern1().setDisabled(true);
                    compObj.getPlacementConcern1().setValue(false);
                }

                compObj.getPlacementConcern3().setDisabled(false);
                compObj.getPlacementConcern4().setDisabled(false);
                compObj.getPlacementConcern5().setDisabled(false);
                compObj.getPlacementConcern6().setDisabled(false);
                compObj.getPlacementConcern7().setDisabled(false);
            }

            break;

        case 'placementConcern7_change':

            if (compObj.getPlacementConcern7().checked == true) {
                compObj.getOtherPlacementConcerns().enable();
            } else {
                compObj.getOtherPlacementConcerns().disable();
                compObj.getOtherPlacementConcerns().setValue(null);
            }

            break;

        default:

            break;
    }
}
var runPermanencyBusinessRules = function (compObj, section, parms) {

    var item5Container = compObj.getPermanencyGoalPanel();

    var selectGoal1 = function () {
        
        var nonOPPLAGoals = isNonOPPLAGoalsSelected();

        if (nonOPPLAGoals) {

            var comp6CNA = compObj.getQuestion6CNA();
            comp6CNA.setValue(true);

            var comp6C2NA = compObj.getQuestion6C2NA();
            comp6C2NA.setValue(true);
        }
    };

    var getPermanencyQuestions = function () {

        var caseType = getCaseType();
        
        if (caseType == 'Foster Case') {

            var comp = compObj.getGoalGrid();

            comp.plugins[1].evaluateFields();
            comp.plugins[1].runBusinessRules();

            var result = comp.plugins[1].getRulesEvalResult();

            Ext.each(item5Container.items.items, function (item) {
                if (!(item.itemId == 'permanencyGoalHeader' ||
                    item.itemId == 'goalGrid' ||
                    item.itemId == 'permanencyItem5Notes' ||
                    item.itemId == 'item5Rating')) {

                    if (result.ruleResult == 'disable') {

                        item.disable();
                    } else {

                        item.enable();
                    }
                } else {
                    item.enable();
                }
            });

            if (result.ruleResult == 'disable') {

                setDisableFieldValues(item5Container);
            }

            // Process Goal1 and Goal2
            var goal1Component = compObj.getPermanencyGoal1Selection();
            var goal2Component = compObj.getPermanencyGoal2Selection();

            if (result.ruleResult == 'disable') {

                goal1Component.disable();
                goal2Component.disable();

                setDisableFieldValues(item5Container);
            } else {

                goal1Component.enable();
                goal2Component.enable();
            }
        } else {

            disableContainerItems('permanencyPanel');

            setDisableFieldValues(item5Container);
        }
    };

    var processTerminalExceptionsNA = function () {

        if (compObj.getTermEx2().checked == true) {

            return;
        }

        //if (compObj.getTermEx1().checked == true) {

        //    if (!compObj.getTermEx2().isDisabled()) {
        //        compObj.getTermEx2().setDisabled(true);
        //        compObj.getTermEx2().setValue(false);
        //    }

        //    if (!compObj.getTermEx3().isDisabled()) {
        //        compObj.getTermEx3().setDisabled(true);
        //        compObj.getTermEx3().setValue(false);
        //    }

        //    if (!compObj.getTermEx4().isDisabled()) {
        //        compObj.getTermEx4().setDisabled(true);
        //        compObj.getTermEx4().setValue(false);
        //    }

        //    if (!compObj.getTermEx5().isDisabled()) {
        //        compObj.getTermEx5().setDisabled(true);
        //        compObj.getTermEx5().setValue(false);
        //    }
        //} else {

        //    compObj.getTermEx2().setDisabled(false);
        //    compObj.getTermEx3().setDisabled(false);
        //    compObj.getTermEx4().setDisabled(false);
        //    compObj.getTermEx5().setDisabled(false);
        //}
    }

    var processNoTerminalExceptions = function () {

        if (compObj.getTermEx1().checked == true) {

            return;
        }

        //if (compObj.getTermEx2().checked == true) {

        //    if (!compObj.getTermEx1().isDisabled()) {
        //        compObj.getTermEx1().setDisabled(true);
        //        compObj.getTermEx1().setValue(false);
        //    }

        //    if (!compObj.getTermEx3().isDisabled()) {
        //        compObj.getTermEx3().setDisabled(true);
        //        compObj.getTermEx3().setValue(false);
        //    }

        //    if (!compObj.getTermEx4().isDisabled()) {
        //        compObj.getTermEx4().setDisabled(true);
        //        compObj.getTermEx4().setValue(false);
        //    }

        //    if (!compObj.getTermEx5().isDisabled()) {
        //        compObj.getTermEx5().setDisabled(true);
        //        compObj.getTermEx5().setValue(false);
        //    }
        //} else {
        //    compObj.getTermEx1().setDisabled(false);
        //    compObj.getTermEx3().setDisabled(false);
        //    compObj.getTermEx4().setDisabled(false);
        //    compObj.getTermEx5().setDisabled(false);

        //}
    }

    parms = Ext.isEmpty(parms.currentVal) ? { currentVal: false } : parms;

    switch (section) {

        case sr.Constants.AllFields:

            if (!(isCaseApplicable(6, 3))) {

                // Disable section for Item 5
                disableContainerItems(['permanencyGoalPanel'], ['item5Rating', 'permanencyItem5Notes']);
                setDisabledFieldValuesInContainer(['permanencyGoalPanel']);
                //deleteFieldValues(['item5ApplicableComments']);
            }

            if (!(isCaseApplicable(8, 4))) {

                // Disable section for Item 7
                disableContainerItems(['item7APanel', 'item7BPanel'], ['item7Rating', 'permanencyItem7Notes']);
                setDisabledFieldValuesInContainer(['item7APanel', 'item7BPanel']);
            }
            
            if (!(isCaseApplicable(9, 4))) {

                // Disable section for Item 8
                disableContainerItems(['item8A1Panel', 'item8APanel', 'item8CPanel', 'item8B1Panel', 'item8BPanel', 'item8DPanel', 'item8E1Panel', 'item8EPanel', 'item8FPanel']);
                setDisabledFieldValuesInContainer(['item8A1Panel', 'item8APanel', 'item8CPanel', 'item8B1Panel', 'item8BPanel', 'item8DPanel', 'item8E1Panel', 'item8EPanel', 'item8FPanel']);
            }

            if (!(isCaseApplicable(10, 4))) {

                // Disable section for Item 9
                disableContainerItems(['item9APanel', 'item9BPanel', 'item9CPanel', 'item9DPanel']);
                setDisabledFieldValuesInContainer(['item9APanel', 'item9BPanel', 'item9CPanel', 'item9DPanel']);
            }

            if (!(isCaseApplicable(11, 4))) {

                // Disable section for Item 10
                disableContainerItems(['item10A1', 'item10A2', 'item10B', 'item10C']);
                setDisabledFieldValuesInContainer(['item10A1', 'item10A2', 'item10B', 'item10C']);
            }

            if (!(isCaseApplicable(12, 4))) {

                // Disable section for Item 11
                disableContainerItems(['item11APanel', 'item11A1Panel', 'item11BPanel', 'item11B1Panel']);
                setDisabledFieldValuesInContainer(['item11APanel', 'item11A1Panel', 'item11BPanel', 'item11B1Panel']);
            }

            var modelData = window.permanencyViewModel.data.permanencyCollection.getAt(0).data;
            var answer5BNo = modelData.wereAllGoalsInTimelyManner;
            var answer5CNo = modelData.wereAllGoalsAppropriate;
            var answer6BNo = modelData.IsAgencyConcertedEfforts;
            var answer6CNo = modelData.IsOtherPlannedConcertedEffort;
            var answer7BNo = modelData.IsValidReasonForSeparation;

            getAppController().getAllGoalsInTimelyMannerExplained().disable();

            if (answer5BNo == 2) {

                getAppController().getAllGoalsInTimelyMannerExplained().enable();
            }
            
            getAppController().getAllGoalsAppropriateExplained().disable();

            if (answer5CNo == 2) {

                getAppController().getAllGoalsAppropriateExplained().enable();
            }

            getAppController().getAgencyConcertedEffortsExplained().disable();

            if (answer6BNo == 2) {

                getAppController().getAgencyConcertedEffortsExplained().enable();
            }

            getAppController().getOtherPlannedConcertedEffortExplained().disable();

            if (answer6CNo == 2) {

                getAppController().getOtherPlannedConcertedEffortExplained().enable();
            }

            getAppController().getItem7BConcerns().disable();

            if (answer7BNo == 2) {

                getAppController().getItem7BConcerns().enable();
            }

            break;

        case 'effortsToSupportFatherFosterRelationship7_change':

            if (compObj.getEffortsToSupportFatherFosterRelationship7().checked == true) {

                compObj.getEfforts11B1Comments().enable();
            } else {

                compObj.getEfforts11B1Comments().disable();
                compObj.getEfforts11B1Comments().setValue(null);
            }

            break;

        case 'effortsToSupportMotherFosterRelationship7_change':

            if (compObj.getEffortsToSupportMotherFosterRelationship7().checked == true) {

                compObj.getEfforts11A1Comments().enable();
            } else {

                compObj.getEfforts11A1Comments().disable();
                compObj.getEfforts11A1Comments().setValue(null);
            }

            break;

        case 'item4C16':

            if (compObj.getItem4C16().checked == true) {

                compObj.getItem4C1placeApplicableCircumstancesOther().enable();
            } else {

                compObj.getItem4C1placeApplicableCircumstancesOther().disable();
                compObj.getItem4C1placeApplicableCircumstancesOther().setValue(null);
            }

            break;

        case 'item5Yes':

            var item = getItem(6, 3);

            if (!(item == undefined)) {

                item.IsApplicable = 1;
                updateItem(item);

                initializeAnswers('item5');
            }
            
            // Enable section for Item 5
            enableContainerItems(['permanencyGoalPanel']);

            break;

        case 'item5No':

            var item = getItem(6, 3);

            if (!(item == undefined)) {

                item.IsApplicable = 2;
                item.ItemRatingCode = 3;

                updateItem(item);
            }

            disableContainerItems(['permanencyGoalPanel'], ['item5Rating', 'permanencyItem5Notes']);

            setDisabledFieldValuesInContainer(['permanencyGoalPanel']);
            deleteFieldValues(['item5ApplicableComments']);

            // Update Grid Layout
            var reportGrid = compObj.getGoalGrid();

            reportGrid.getView().refresh();
            
            resetItem5StoreValues();

            break;

        case 'item5BNo':

            if (parms.currentVal) {
                compObj.getAllGoalsInTimelyMannerExplained().setDisabled(false);
            } else {
                compObj.getAllGoalsInTimelyMannerExplained().setDisabled(true);
                compObj.getAllGoalsInTimelyMannerExplained().setValue(null);
            }

            break;

        case 'item5CNo':

            if (parms.currentVal) {

                compObj.getAllGoalsAppropriateExplained().setDisabled(false);
            } else {

                compObj.getAllGoalsAppropriateExplained().setDisabled(true);
                compObj.getAllGoalsAppropriateExplained().setValue(null);
            }

            break;

        case 'question6BNo':

            if (parms.currentVal) {

                compObj.getAgencyConcertedEffortsExplained().setDisabled(false);
            } else {

                compObj.getAgencyConcertedEffortsExplained().setDisabled(true);
                compObj.getAgencyConcertedEffortsExplained().setValue(null);
            }

            break;

        case 'question6CNo':

            if (parms.currentVal) {

                compObj.getOtherPlannedConcertedEffortExplained().setDisabled(false);
            } else {

                compObj.getOtherPlannedConcertedEffortExplained().setDisabled(true);
                compObj.getOtherPlannedConcertedEffortExplained().setValue(null);
            }

            break;

        case 'item7Yes':

            var item = getItem(8, 4);

            if (!(item == undefined)) {

                item.IsApplicable = 1;
                updateItem(item);

                initializeAnswers('item7');
            }

            // Enable section for Item 7
            enableContainerItems(['item7APanel', 'item7BPanel']);

            break;

        case 'item7No':

            var item = getItem(8, 4);

            if (!(item == undefined)) {

                item.IsApplicable = 2;
                item.ItemRatingCode = 3;

                updateItem(item);
            }

            // Disable section for Item 7
            disableContainerItems(['item7APanel', 'item7BPanel'], ['item7Rating', 'permanencyItem7Notes']);
            setDisabledFieldValuesInContainer(['item7APanel', 'item7BPanel']);

            resetItem7StoreValues();

            break;

        case 'question7BNo':

            if (parms.currentVal) {

                compObj.getItem7BConcerns().setDisabled(false);
            } else {

                compObj.getItem7BConcerns().setDisabled(true);
                compObj.getItem7BConcerns().setValue(null);
            }

            break;

        case 'question7AYes':

            var answerComp = compObj.getQuestion7AYes();

            if (answerComp.getValue()) {

                var comp7BYes = compObj.getQuestion7BYes();
                var comp7BNo = compObj.getQuestion7BNo();
                var comp7BNA = compObj.getQuestion7BNA();

                comp7BYes.enable();
                comp7BNo.enable();

                comp7BNA.setValue(false);
                comp7BNA.enable();
            }

            break;

        case 'question7ANo':

            var answerComp = compObj.getQuestion7ANo();

            if (answerComp.getValue()) {

                var comp7BYes = compObj.getQuestion7BYes();
                var comp7BNo = compObj.getQuestion7BNo();
                var comp7BNA = compObj.getQuestion7BNA();

                comp7BYes.enable();
                comp7BNo.enable();

                comp7BNA.setValue(false);
                comp7BNA.disable();
            }

            break;

        case 'item8ParticipantCheckboxGroupMother':

            var question8ANA = getAppController().getQuestion8ANA();
            var question8CNA = getAppController().getQuestion8CNA();
            var motherFrequencyNA = getAppController().getMotherVisitFrequency1();

            if (parms.currentVal) {

                // Clear values
                question8ANA.setValue(false);
                question8CNA.setValue(false);
                motherFrequencyNA.setValue(false);

                // Disable components
                question8ANA.disable();
                question8CNA.disable();
                motherFrequencyNA.disable();
            } else {

                // Enable components
                question8ANA.enable();
                question8CNA.enable();
                motherFrequencyNA.enable();
            }

            break;

        case 'item8ParticipantCheckboxGroupFather':

            var question8BNA = getAppController().getQuestion8BNA();
            var question8DNA = getAppController().getQuestion8DNA();
            var fatherFrequencyNA = getAppController().getFatherVisitFrequency1();

            if (parms.currentVal) {

                // Clear values
                question8BNA.setValue(false);
                question8DNA.setValue(false);
                fatherFrequencyNA.setValue(false);

                // Disable components
                question8BNA.disable();
                question8DNA.disable();
                fatherFrequencyNA.disable();
            } else {

                // Enable components
                question8BNA.enable();
                question8DNA.enable();
                fatherFrequencyNA.enable();
            }

            break;

        case 'applicabilityQuestion8Yes':

            var item = getItem(9, 4);

            if (!(item == undefined)) {

                item.IsApplicable = 1;
                updateItem(item);

                initializeAnswers('item8');
            }

            // Enable section for Item 8
            enableContainerItems(['item8A1Panel', 'item8APanel', 'item8CPanel', 'item8B1Panel', 'item8BPanel', 'item8DPanel', 'item8E1Panel', 'item8EPanel', 'item8FPanel']);

            break;

        case 'applicabilityQuestion8No':

            var item = getItem(9, 4);

            if (!(item == undefined)) {

                item.IsApplicable = 2;
                item.ItemRatingCode = 3;

                updateItem(item);
            }

            // Disable section for Item 8
            disableContainerItems(['item8A1Panel', 'item8APanel', 'item8CPanel', 'item8B1Panel', 'item8BPanel', 'item8DPanel', 'item8E1Panel', 'item8EPanel', 'item8FPanel']);
            setDisabledFieldValuesInContainer(['item8A1Panel', 'item8APanel', 'item8CPanel', 'item8B1Panel', 'item8BPanel', 'item8DPanel', 'item8E1Panel', 'item8EPanel', 'item8FPanel']);

            resetItem8StoreValues();

            break;

        case 'item9ApplicableYes':

            var item = getItem(10, 4);

            if (!(item == undefined)) {

                item.IsApplicable = 1;
                updateItem(item);

                initializeAnswers('item9');
            }

            // Enable section for Item 9
            enableContainerItems(['item9APanel', 'item9BPanel', 'item9CPanel', 'item9DPanel']);

            break;

        case 'item9ApplicableNo':

            var item = getItem(10, 4);

            if (!(item == undefined)) {

                item.IsApplicable = 2;
                item.ItemRatingCode = 3;

                updateItem(item);
            }

            // Disable section for Item 9
            disableContainerItems(['item9APanel', 'item9BPanel', 'item9CPanel', 'item9DPanel']);
            setDisabledFieldValuesInContainer(['item9APanel', 'item9BPanel', 'item9CPanel', 'item9DPanel']);

            resetItem9StoreValues();

            break;

        case 'item10ApplicableYes':

            var item = getItem(11, 4);

            if (!(item == undefined)) {

                item.IsApplicable = 1;
                updateItem(item);

                initializeAnswers('item10');
            }

            // Enable section for Item 10
            enableContainerItems(['item10A1', 'item10A2', 'item10B', 'item10C']);

            break;

        case 'item10ApplicableNo':

            var item = getItem(11, 4);

            if (!(item == undefined)) {

                item.IsApplicable = 2;
                item.ItemRatingCode = 3;

                updateItem(item);
            }

            // Disable section for Item 10
            disableContainerItems(['item10A1', 'item10A2', 'item10B', 'item10C']);
            setDisabledFieldValuesInContainer(['item10A1', 'item10A2', 'item10B', 'item10C']);

            resetItem10StoreValues();

            break;

        case 'question10BNo':

            if (parms.currentVal) {

                compObj.getPlacementEffortConcernsMother1().setDisabled(false);
                compObj.getPlacementEffortConcernsMother2().setDisabled(false);
                compObj.getPlacementEffortConcernsMother3().setDisabled(false);
                compObj.getPlacementEffortConcernsMother4().setDisabled(false);
            } else {

                compObj.getPlacementEffortConcernsMother1().setDisabled(true);
                compObj.getPlacementEffortConcernsMother2().setDisabled(true);
                compObj.getPlacementEffortConcernsMother3().setDisabled(true);
                compObj.getPlacementEffortConcernsMother4().setDisabled(true);

                compObj.getPlacementEffortConcernsMother4().setValue(null);
                compObj.getPlacementEffortConcernsMother4().setValue(null);
                compObj.getPlacementEffortConcernsMother4().setValue(null);
                compObj.getPlacementEffortConcernsMother4().setValue(null);
            }

            break;

        case 'question10CNo':

            if (parms.currentVal) {

                compObj.getPlacementEffortConcernsFather1().setDisabled(false);
                compObj.getPlacementEffortConcernsFather2().setDisabled(false);
                compObj.getPlacementEffortConcernsFather3().setDisabled(false);
                compObj.getPlacementEffortConcernsFather4().setDisabled(false);
            } else {

                compObj.getPlacementEffortConcernsFather1().setDisabled(true);
                compObj.getPlacementEffortConcernsFather2().setDisabled(true);
                compObj.getPlacementEffortConcernsFather3().setDisabled(true);
                compObj.getPlacementEffortConcernsFather4().setDisabled(true);

                compObj.getPlacementEffortConcernsFather1().setValue(null);
                compObj.getPlacementEffortConcernsFather2().setValue(null);
                compObj.getPlacementEffortConcernsFather3().setValue(null);
                compObj.getPlacementEffortConcernsFather4().setValue(null);
            }

            break;

        case 'itemApplicable11Yes':

            var item = getItem(12, 4);

            if (!(item == undefined)) {

                item.IsApplicable = 1;
                updateItem(item);

                initializeAnswers('item11');
            }

            // Enable section for Item 11
            enableContainerItems(['item11APanel', 'item11A1Panel', 'item11BPanel', 'item11B1Panel']);

            break;

        case 'itemApplicable11No':

            var item = getItem(12, 4);

            if (!(item == undefined)) {

                item.IsApplicable = 2;
                item.ItemRatingCode = 3;

                updateItem(item);
            }

            // Disable section for Item 11
            disableContainerItems(['item11APanel', 'item11A1Panel', 'item11BPanel', 'item11B1Panel']);
            setDisabledFieldValuesInContainer(['item11APanel', 'item11A1Panel', 'item11BPanel', 'item11B1Panel']);

            resetItem11StoreValues();

            break;

        case 'item11ParticipantCheckboxGroupMother':

            var question11ANA = getAppController().getQuestion11ANA();
            var motherRelationship1 = getAppController().getEffortsToSupportMotherFosterRelationship1();

            if (parms.currentVal) {

                // Clear values
                question11ANA.setValue(false);
                motherRelationship1.setValue(false);

                // Disable components
                question11ANA.disable();
                motherRelationship1.disable();
            } else {

                // Enable components
                question11ANA.enable();
                motherRelationship1.enable();
            }
            

            break;

        case 'item11ParticipantCheckboxGroupFather':

            var question11BNA = getAppController().getQuestion11BNA();
            var fatherRelationship1 = getAppController().getEffortsToSupportFatherFosterRelationship1();

            if (parms.currentVal) {

                // Clear values
                question11BNA.setValue(false);
                fatherRelationship1.setValue(false);

                // Disable components
                question11BNA.disable();
                fatherRelationship1.disable();
            } else {

                // Enable components
                question11BNA.enable();
                fatherRelationship1.enable();
            }
            
            break;

        case 'item11Question1':

            var comments = getAppController().getEfforts11A1Comments();

            comments.setValue(null);
            comments.setDisabled(true);

            break;

        case 'question11B1':

            var comments = getAppController().getEfforts11B1Comments();;

            comments.setValue(null);
            comments.setDisabled(true);

            break;

        case 'goalGrid':

            updateCurrentGoals();

            updateQuestion6A4();

            getPermanencyQuestions();

            break;

        case 'livingArragmentCode':

            if (parms.currentVal == 6) {

                compObj.getLivingArragmentExplained().setDisabled(false);
            } else {

                compObj.getLivingArragmentExplained().setDisabled(true);
                compObj.getLivingArragmentExplained().setValue(null);
            }

            break;

        case 'permanencyGoal1Selection_beforerender':

            updateCurrentGoals();

            updateQuestion6A4();

            selectGoal1();

            break;

        case 'placementGrid':

            var caseType = getCaseType();
            var item4Container = compObj.getItem4Panel();

            if (caseType == 'Foster Case') {

                var comp = compObj.getPlacementGrid();

                comp.plugins[1].evaluateFields();
                comp.plugins[1].runBusinessRules();

                var result = comp.plugins[1].getRulesEvalResult();

                if (result.ruleResult == 'disable') {

                    // Disable all Item 4 questions                
                    Ext.each(item4Container.items.items, function (item) {
                        if (!(item.itemId == 'item4' ||
                            item.itemId == 'placementGrid' ||
                            item.itemId == 'item4Buttons' ||
                            item.itemId == 'permanencyItem4Notes' ||
                            item.itemId == 'item4Rating')) {

                            item.disable();
                        } else {
                            item.enable();
                        }
                    });

                    setDisableFieldValues(item4Container);

                    // Disable all item 10 questions
                    var item10Container = compObj.getItem10Panel();
                    item10Container.disable();
                    setDisableFieldValues(item10Container);

                    var item10A1Container = compObj.getItem10A1();
                    item10A1Container.disable();
                    setDisableFieldValues(item10A1Container);

                    var item10A2Container = compObj.getItem10A2();
                    item10A2Container.disable();
                    setDisableFieldValues(item10A2Container);

                    var item10BContainer = compObj.getItem10B();
                    item10BContainer.disable();
                    setDisableFieldValues(item10BContainer);

                    var item10CContainer = compObj.getItem10C();
                    item10CContainer.disable();
                    setDisableFieldValues(item10CContainer);

                    var item10Rating = compObj.getItem10Rating();
                    item10Rating.disable();
                    setDisableFieldValues(item10Rating);
                } else {
                    // Enable all Item 4 questions                
                    Ext.each(item4Container.items.items, function (item) {
                        if (!(item.itemId == 'item4' ||
                            item.itemId == 'placementGrid' ||
                            item.itemId == 'item4Buttons' ||
                            item.itemId == 'permanencyItem4Notes' ||
                            item.itemId == 'item4Rating')) {

                            item.enable();
                        }
                    });

                    // Enable all item 10 questions
                    var item10Container = compObj.getItem10Panel();
                    item10Container.enable();

                    var item10A1Container = compObj.getItem10A1();
                    item10A1Container.enable();

                    var item10A2Container = compObj.getItem10A2();
                    item10A2Container.enable();

                    var item10BContainer = compObj.getItem10B();
                    item10BContainer.enable();

                    var item10CContainer = compObj.getItem10C();
                    item10CContainer.enable();

                    var item10Rating = compObj.getItem10Rating();
                    item10Rating.enable();
                }
            } else {
                
                disableContainerItems('permanencyPanel');
            }

            break;

        case 'item5G1Group':

            processTerminalExceptionsNA();
            processNoTerminalExceptions();

            break;
        
        default:

            break;
    }
}
var runWellbeingBusinessRules = function (compObj, section, parms) {

    parms = Ext.isEmpty(parms) ? { currentVal: false } : parms;

    var updateItem12C = function (itemCode, outcomeCode) {

        var item = getItem(itemCode, outcomeCode);

        if (!(item == undefined)) {

            item.IsApplicable = 2;
            updateItem(item);
        }

        // Disable section for Item 12C
        disableContainerItems(['item12C1', 'item12C2']);
        setDisabledFieldValuesInContainer(['item12C1', 'item12C2']);

        // Reset store values
        var fields = [];
        var vmFields = [];
        var field;
        var vmField
        var parms = {};
        
        field = { 'IsNeedsOfFosterParentsAdequatelyAssessed': null };
        fields.push(field);

        field = { 'IsFosterParentsProvidedAppropriateServices': null };
        fields.push(field);

        parms['fields'] = fields;

        vmField = { 'isNeedsOfFosterParentsAdequatelyAssessed': null };
        vmField = { 'isFosterParentsProvidedAppropriateServices': null };

        parms['vmFields'] = vmFields;

        parms['storeId'] = 'CR_WellBeing_CollectionStore';

        saveChanges(parms);
    }

    switch (section) {

        case sr.Constants.AllFields:

            if (!(isCaseApplicable(15, 5))) {

                // Disable section for Item 12B
                disableContainerItems(['item12B1', 'item12B2', 'item12B3', 'item12B4']);
                setDisabledFieldValuesInContainer(['item12B1', 'item12B2', 'item12B3', 'item12B4']);
            }

            if (!(isCaseApplicable(16, 5))) {

                // Disable section for Item 12C
                disableContainerItems(['item12C1', 'item12C2']);
                setDisabledFieldValuesInContainer(['item12C1', 'item12C2']);
            }

            if(!(isCaseApplicable(17,5))){

                // Disable section for Item 13
                disableContainerItems(['item13A', 'item13B', 'item13C']);
                setDisabledFieldValuesInContainer(['item13A', 'item13B', 'item13C']);
            }

            if (!(isCaseApplicable(19, 5))) {

                // Disable section for Item 15
                disableContainerItems(['item15A1', 'item15A2', 'item15B1', 'item15B2', 'item15C', 'item15D']);
                setDisabledFieldValuesInContainer(['item15A1', 'item15A2', 'item15B1', 'item15B2', 'item15C', 'item15D']);
            }

            if (!(isCaseApplicable(20, 6))) {

                // Disable section for Item 16
                disableContainerItems(['item16A', 'item16B', 'educationGrid', 'item16ParticipantCheckboxGroupChildren', 'item16ParticipantCheckboxGroupChildren']);
                setDisabledFieldValuesInContainer(['item16A', 'item16B', 'educationGrid','item16ParticipantCheckboxGroupChildren']);
            }

            if (!(isCaseApplicable(21, 7))) {
                
                // Disable section for Item 17
                disableContainerItems(['item17A1', 'pdHealthGrid', 'item17A4', 'item17B1', 'item17B2', 'item17B3']);
                setDisabledFieldValuesInContainer(['item17A1', 'pdHealthGrid', 'item17A4', 'item17B1', 'item17B2', 'item17B3']);
            }

            if (!(isCaseApplicable(22, 7))) {

                // Disable section for Item 18
                disableContainerItems(['item18A', 'mbHealthGrid', 'item18B', 'item18C']);
                setDisabledFieldValuesInContainer(['item18A', 'mbHealthGrid', 'item18B', 'item18C']);
            }

            break;

        case 'item12B':

            var comp = compObj.getItem2Question1();
            var result = comp.plugins[0].getRulesEvalResult();

            if (result.validityResult == 'other') {
                // Set Item 12B parent question to No
                var item12BPreAppNo1 = compObj.getItem12BApplicability1No();
                var item12BPreAppYes1 = compObj.getItem12BApplicability1Yes();
                var item12BPreAppNo2 = compObj.getItem12BApplicability2No();
                var item12BPreAppYes2 = compObj.getItem12BApplicability2Yes();
                var item12BPreAppNo3 = compObj.getItem12BApplicability3No();
                var item12BPreAppYes3 = compObj.getItem12BApplicability3Yes();
                var item12BPreAppNo4 = compObj.getItem12BApplicability4No();
                var item12BPreAppYes4 = compObj.getItem12BApplicability4Yes();
                var item12BPreAppNo5 = compObj.getItem12BApplicability5No();
                var item12BPreAppYes5 = compObj.getItem12BApplicability5Yes();

                item12BPreAppYes1.setValue(false);
                item12BPreAppYes2.setValue(false);
                item12BPreAppYes3.setValue(false);
                item12BPreAppYes4.setValue(false);
                item12BPreAppYes5.setValue(false);

                item12BPreAppNo1.setValue(false);
                item12BPreAppNo2.setValue(false);
                item12BPreAppNo3.setValue(false);
                item12BPreAppNo4.setValue(false);
                item12BPreAppNo5.setValue(false);
            }

            break;

        case 'item12BApplicableMotherYes':

            var item = getItem(15, 5);
            var fatherPart = compObj.getItem12BApplicableFatherYes();

            if (!(item == undefined)) {

                item.IsApplicable = 1;
                updateItem(item);

                if (!fatherPart.checked) {

                    initializeAnswers('item12B');
                }                
            }
                        
            // Enable section for Item 12B
            enableContainerItems(['item12B1', 'item12B2', 'item12B3', 'item12B4']);

            break;

        case 'item12BApplicableMotherNo':

            if (parms.ratingDefault == 'NA') {

                var item = getItem(15, 5);

                if (!(item == undefined)) {

                    item.IsApplicable = 2;
                    updateItem(item);
                }

                // Disable section for Item 12B
                disableContainerItems(['item12B1', 'item12B2', 'item12B3', 'item12B4']);
                setDisabledFieldValuesInContainer(['item12B1', 'item12B2', 'item12B3', 'item12B4']);

                resetItem12BStoreValues();
            }

            break;

        case 'item12BApplicableFatherYes':

            var item = getItem(15, 5);
            var motherPart = compObj.getItem12BApplicableMotherYes();

            if (!(item == undefined)) {

                item.IsApplicable = 1;
                updateItem(item);

                if (!motherPart.checked) {

                    initializeAnswers('item12B');
                }
            }

            // Enable section for Item 12B
            enableContainerItems(['item12B1', 'item12B2', 'item12B3', 'item12B4']);

            break;

        case 'item12BApplicableFatherNo':

            if (parms.ratingDefault == 'NA') {

                var item = getItem(15, 5);

                if (!(item == undefined)) {

                    item.IsApplicable = 2;
                    updateItem(item);
                }

                // Disable section for Item 12B
                disableContainerItems(['item12B1', 'item12B2', 'item12B3', 'item12B4']);
                setDisabledFieldValuesInContainer(['item12B1', 'item12B2', 'item12B3', 'item12B4']);

                resetItem12BStoreValues();
            }

            break;

        case 'item12BParticipantCheckboxGroupMother':

            var question12B1NA = getAppController().getQuestion12B1NA();
            var question12B3NA = getAppController().getQuestion12B3NA();

            if (parms.currentVal) {

                // Clear values
                question12B1NA.setValue(false);
                question12B3NA.setValue(false);

                // Disable components
                question12B1NA.disable();
                question12B3NA.disable();
            } else {

                // Enable components
                question12B1NA.enable();
                question12B3NA.enable();
            }

            break;

        case 'item12BParticipantCheckboxGroupFather':

            var question12B2NA = getAppController().getQuestion12B2NA();
            var question12B4NA = getAppController().getQuestion12B4NA();

            if (parms.currentVal) {

                // Clear values
                question12B2NA.setValue(false);
                question12B4NA.setValue(false);

                // Disable components
                question12B2NA.disable();
                question12B4NA.disable();
            } else {

                // Enable components
                question12B2NA.enable();
                question12B4NA.enable();
            }

            break;

        case 'item12C':

            var comp = compObj.getItem2Question1();
            var result = comp.plugins[0].getRulesEvalResult();
            var isInHomeCase = comp.plugins[0].isInHomeCase();

            if (result.validityResult == 'other') {

                var yesComp = compObj.getItem12CYes();
                var noComp = compObj.getItem12CNo();

                yesComp.setValue(false);
                noComp.setValue(false);
            }

            if (isInHomeCase) {

                var yesComp = compObj.getItem12CYes();
                var noComp = compObj.getItem12CNo();

                yesComp.setValue(false);
                yesComp.disable();

                noComp.setValue(true);

                updateItem12C(16, 5);
            }

            break;

        case 'mbHealthGrid':

            var comp = compObj.getMbHealthGrid();
            var item18B = compObj.getItem18B();
            var item18C = compObj.getItem18C();

            comp.plugins[1].evaluateFields();
            comp.plugins[1].runBusinessRules();

            var result = comp.plugins[1].getRulesEvalResult();
                 
            if (result.ruleResult == 'disable') {

                item18B.disable();
                item18C.disable();
            } else {

                item18B.enable();
                item18C.enable();
            }

            break;

        case 'mbHealthGrid_beforerender':

            var comp = compObj.getMbHealthGrid();
            var result = comp.plugins[1].getRulesEvalResult();
            var item18BQuestions = compObj.getItem18B();
            var item18CQuestions = compObj.getItem18C();

            if (result.ruleResult == 'disable') {
                // Disable all Item 18 questions except QA notes

                item18BQuestions.disable();
                setDisableFieldValues(item18BQuestions);

                item18CQuestions.disable();
                setDisableFieldValues(item18CQuestions);

            } else {
                item18BQuestions.enable();
                item18CQuestions.enable();
            }

            break;

        case 'question12A1No':

            if (parms.currentVal) {

                compObj.getNeedConcerns().setDisabled(false);
            } else {

                compObj.getNeedConcerns().setDisabled(true);
                compObj.getNeedConcerns().setValue(null);
            }

            break;

        case 'question12A2No':

            if (parms.currentVal) {

                compObj.getServiceConcerns().setDisabled(false);
            } else {

                compObj.getServiceConcerns().setDisabled(true);
                compObj.getServiceConcerns().setValue(null);
            }

            break;

        case 'question12B1No':

            if (parms.currentVal) {

                compObj.getItem12B1Concerns().setDisabled(false);
            } else {

                compObj.getItem12B1Concerns().setDisabled(true);
                compObj.getItem12B1Concerns().setValue(null);
            }

            break;

        case 'question12B2No':

            if (parms.currentVal) {

                compObj.getItem12B2Concerns().setDisabled(false);
            } else {

                compObj.getItem12B2Concerns().setDisabled(true);
                compObj.getItem12B2Concerns().setValue(null);
            }

            break;

        case 'question12B3No':

            if (parms.currentVal) {

                compObj.getItem12B3Concerns().setDisabled(false);
            } else {

                compObj.getItem12B3Concerns().setDisabled(true);
                compObj.getItem12B3Concerns().setValue(null);
            }

            break;

        case 'question12B4No':

            if (parms.currentVal) {

                compObj.getItem12B4Concerns().setDisabled(false);
            } else {

                compObj.getItem12B4Concerns().setDisabled(true);
                compObj.getItem12B4Concerns().setValue(null);
            }

            break;

        case 'item12CYes':

            var item = getItem(parms.itemCode, parms.outcomeCode);

            if (!(item == undefined)) {

                if (item.IsApplicable == 1) {

                    enableContainerItems(['item12C1', 'item12C2']);

                    initializeAnswers('item12C');
                }
            }

            break;

        case 'item12CNo':

            updateItem12C(parms.itemCode, parms.outcomeCode);

            break;

        case 'question12C1No':

            if (parms.currentVal) {

                compObj.getItem12C1Concerns().setDisabled(false);
            } else {

                compObj.getItem12C1Concerns().setDisabled(true);
                compObj.getItem12C1Concerns().setValue(null);
            }

            break;

        case 'question12C2No':

            if (parms.currentVal) {

                compObj.getItem12C2Concerns().setDisabled(false);
            } else {

                compObj.getItem12C2Concerns().setDisabled(true);
                compObj.getItem12C2Concerns().setValue(null);
            }

            break;

        case 'item13ParticipantCheckboxGroupMother':

            var question13BNA = getAppController().getQuestion13BNA();

            if (parms.currentVal) {

                // Clear values
                question13BNA.setValue(false);

                // Disable components
                question13BNA.disable();
            } else {

                // Enable components
                question13BNA.enable();
            }

            break;

        case 'item13ParticipantCheckboxGroupFather':

            var question13CNA = getAppController().getQuestion13CNA();

            if (parms.currentVal) {

                // Clear values
                question13CNA.setValue(false);

                // Disable components
                question13CNA.disable();
            } else {

                // Enable components
                question13CNA.enable();
            }

            break;

        case 'applicabilityQuestion13Yes':

            var item = getItem(17, 5);

            if (!(item == undefined)) {

                item.IsApplicable = 1;
                updateItem(item);
                
                initializeAnswers('item13');
            }

            // Enable section for Item 13
            enableContainerItems(['item13A', 'item13B', 'item13C']);

            break;

        case 'applicabilityQuestion13No':

            var item = getItem(17, 5);

            if (!(item == undefined)) {

                item.IsApplicable = 2;
                updateItem(item);
            }

            // Disable section for Item 13
            disableContainerItems(['item13A', 'item13B', 'item13C']);
            setDisabledFieldValuesInContainer(['item13A', 'item13B', 'item13C']);

            // Reset store values
            var fields = [];
            var vmFields = [];
            var field;
            var vmField
            var parms = {};

            field = { 'IsAgencyConcertedEffortsToInvolveTheChild': null };
            fields.push(field);

            field = { 'IsAgencyConcertedEffortsToInvolveTheMother': null };
            fields.push(field);

            field = { 'IsAgencyConcertedEffortsToInvolveTheFather': null };
            fields.push(field);

            parms['fields'] = fields;

            vmField = { 'isAgencyConcertedEffortsToInvolveTheMother': null };
            vmFields.push(vmField);

            vmField = { 'isAgencyConcertedEffortsToInvolveTheFather': null };
            vmFields.push(vmField);

            vmField = { 'isAgencyConcertedEffortsToInvolveTheChild': null };
            vmFields.push(vmField);

            parms['vmFields'] = vmFields;

            parms['storeId'] = 'CR_WellBeing_CollectionStore';

            saveChanges(parms);

            break;

        case 'question13ANo':

            if (parms.currentVal) {

                compObj.getItem13AConcerns().setDisabled(false);
            } else {

                compObj.getItem13AConcerns().setDisabled(true);
                compObj.getItem13AConcerns().setValue(null);
            }

            break;

        case 'question13AAnswers':
            
            var caseType = getCaseType();
            var item13AComponent = getCRSComponent(section,appPages.Wellbeing);

            if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {
                // Force to NA
                Ext.each(item13AComponent.items.items, function (item) {
                    if (item.inputValue == 3) {

                        item.setValue(true);
                    } else {

                        if (!(item.xtype == 'validationMessage')) {

                            item.setValue(false);
                        }                        
                    }
                });

                //disableContainerItems(section);

            } else {

            }

            break;

        case 'question13BNo':

            if (parms.currentVal) {

                compObj.getItem13BConcerns().setDisabled(false);
            } else {

                compObj.getItem13BConcerns().setDisabled(true);
                compObj.getItem13BConcerns().setValue(null);
            }

            break;

        case 'question13CNo':

            if (parms.currentVal) {

                compObj.getItem13CConcerns().setDisabled(false);
            } else {

                compObj.getItem13CConcerns().setDisabled(true);
                compObj.getItem13CConcerns().setValue(null);
            }

            break;

        case 'item13AConcerns':

            var caseType = getCaseType();
            var item13AComponent = getCRSComponent(section, appPages.Wellbeing);

            if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {
                
                item13AComponent.disable();
            }

            break;

        case 'item13ApplicableMotherYes':

            var comp = compObj.getItem13ApplicableMotherYes();
            var yesAnswer = comp.getValue();
            var motherSpecified = isRelationshipSpecified('Mother');

            if ((yesAnswer) && !(motherSpecified)) {

                var comp13BAnswers = compObj.getItem13BAnswers();

                Ext.each(comp13BAnswers.items.items, function (item) {

                    item.setValue(false);

                    if (item.itemId == 'question13BNA') {
                        item.setValue(true);

                        var concerns = compObj.getItem13BConcerns();
                        concerns.setValue('');
                    }
                });
            }

            var noChildren = getNoOfChildren();

            if ((yesAnswer) && noChildren == 0) {

                var comp13AAnswers = compObj.getQuestion13AAnswers();

                Ext.each(comp13AAnswers.items.items, function (item) {

                    item.setValue(false);

                    if (item.itemId == 'question13ANA') {
                        item.setValue(true);

                        var concerns = compObj.getItem13AConcerns();
                        concerns.setValue('');
                    }
                });
            }

            break;

        case 'item13ApplicableFatherYes':

            var comp = compObj.getItem13ApplicableFatherYes();
            var yesAnswer = comp.getValue();
            var fatherSpecified = isRelationshipSpecified('Father');

            if ((yesAnswer) && !(fatherSpecified)) {

                var comp13CAnswers = compObj.getItem13CAnswers();

                Ext.each(comp13CAnswers.items.items, function (item) {

                    item.setValue(false);

                    if (item.itemId == 'question13CNA') {
                        item.setValue(true);

                        var concerns = compObj.getItem13CConcerns();
                        concerns.setValue('');
                    }
                });
            }

            var noChildren = getNoOfChildren();

            if ((yesAnswer) && noChildren == 0) {

                var comp13AAnswers = compObj.getQuestion13AAnswers();

                Ext.each(comp13AAnswers.items.items, function (item) {

                    item.setValue(false);

                    if (item.itemId == 'question13ANA') {
                        item.setValue(true);

                        var concerns = compObj.getItem13AConcerns();
                        concerns.setValue('');
                    }
                });
            }

            break;

        case 'item13ApplicableCases':

            var comp = compObj.getItem2Question1();
            var result = comp.plugins[0].getRulesEvalResult();

            if (result.validityResult == 'other') {

                var item13PreAppNo2 = compObj.getItem13Applicability2No();
                var item13PreAppYes2 = compObj.getItem13Applicability2Yes();
                var item13PreAppNo3 = compObj.getItem13Applicability3No();
                var item13PreAppYes3 = compObj.getItem13Applicability3Yes();
                var item13PreAppNo4 = compObj.getItem13Applicability4No();
                var item13PreAppYes4 = compObj.getItem13Applicability4Yes();
                var item13PreAppNo5 = compObj.getItem13Applicability5No();
                var item13PreAppYes5 = compObj.getItem13Applicability5Yes();
                var item13PreAppNo6 = compObj.getItem13Applicability6No();
                var item13PreAppYes6 = compObj.getItem13Applicability6Yes();
                var item13PreAppNo7 = compObj.getItem13Applicability7No();
                var item13PreAppYes7 = compObj.getItem13Applicability7Yes();

                item13PreAppYes2.setValue(false);
                item13PreAppYes3.setValue(false);
                item13PreAppYes4.setValue(false);
                item13PreAppYes5.setValue(false);
                item13PreAppYes6.setValue(false);
                item13PreAppYes7.setValue(false);

                item13PreAppNo2.setValue(false);
                item13PreAppNo3.setValue(false);
                item13PreAppNo4.setValue(false);
                item13PreAppNo5.setValue(false);
                item13PreAppNo6.setValue(false);
                item13PreAppNo7.setValue(false);
            }

            break;

        case 'question14BNo':

            if (parms.currentVal) {

                compObj.getResponsiblePartyVisitationQualityExplained().setDisabled(false);
            } else {

                compObj.getResponsiblePartyVisitationQualityExplained().setDisabled(true);
                compObj.getResponsiblePartyVisitationQualityExplained().setValue(null);
            }

            break;

        case 'item15ParticipantCheckboxGroupMother':

            var question15A2NA = getAppController().getItem15A2NA();
            var question15CNA = getAppController().getItem15CNA();
            var motherFrequencyNA = getAppController().getMotherVisitationFrequency1();

            if (parms.currentVal) {

                // Clear values
                question15A2NA.setValue(false);
                question15CNA.setValue(false);
                motherFrequencyNA.setValue(false);

                // Disable components
                question15A2NA.disable();
                question15CNA.disable();
                motherFrequencyNA.disable();
            } else {

                // Enable components
                question15A2NA.enable();
                question15CNA.enable();
                motherFrequencyNA.enable();
            }

            break;

        case 'item15ParticipantCheckboxGroupFather':

            var question15B2NA = getAppController().getItem15B2NA();
            var question15DNA = getAppController().getItem15DNA();
            var fatherFrequencyNA = getAppController().getFatherVisitationFrequency1();

            if (parms.currentVal) {

                // Clear values
                question15B2NA.setValue(false);
                question15DNA.setValue(false);
                fatherFrequencyNA.setValue(false);

                // Disable components
                question15B2NA.disable();
                question15DNA.disable();
                fatherFrequencyNA.disable();
            } else {

                // Enable components
                question15B2NA.enable();
                question15DNA.enable();
                fatherFrequencyNA.enable();
            }

            break;

        case 'item15ApplicableCases':

            var comp = compObj.getItem2Question1();
            var result = comp.plugins[0].getRulesEvalResult();

            if (result.validityResult == 'other') {

                var item15PreAppNo1 = compObj.getItem15Applicability1No();
                var item15PreAppYes1 = compObj.getItem15Applicability1Yes();
                var item15PreAppNo2 = compObj.getItem15Applicability2No();
                var item15PreAppYes2 = compObj.getItem15Applicability2Yes();
                var item15PreAppNo3 = compObj.getItem15Applicability3No();
                var item15PreAppYes3 = compObj.getItem15Applicability3Yes();
                var item15PreAppNo4 = compObj.getItem15Applicability4No();
                var item15PreAppYes4 = compObj.getItem15Applicability4Yes();
                var item15PreAppNo5 = compObj.getItem15Applicability5No();
                var item15PreAppYes5 = compObj.getItem15Applicability5Yes();
                var item15PreAppNo6 = compObj.getItem15Applicability6No();
                var item15PreAppYes6 = compObj.getItem15Applicability6Yes();

                item15PreAppYes1.setValue(false);
                item15PreAppYes2.setValue(false);
                item15PreAppYes3.setValue(false);
                item15PreAppYes4.setValue(false);
                item15PreAppYes5.setValue(false);
                item15PreAppYes6.setValue(false);

                item15PreAppNo1.setValue(false);
                item15PreAppNo2.setValue(false);
                item15PreAppNo3.setValue(false);
                item15PreAppNo4.setValue(false);
                item15PreAppNo5.setValue(false);
                item15PreAppNo6.setValue(false);
            }

            break;

        case 'item15ApplicableCaseYes':

            var comp = compObj.getItem15ApplicableCaseYes();
            var yesAnswer = comp.getValue();
            var motherSpecified = isRelationshipSpecified('Mother');
            var fatherSpecified = isRelationshipSpecified('Father');

            if ((yesAnswer) && !(motherSpecified)) {

                var comp15A1Answers = compObj.getItem15A1Answers();

                Ext.each(comp15A1Answers.items.items, function (item) {

                    item.setValue(false);

                    if (item.itemId == 'item15A1Never') {
                        item.setValue(true);
                    }
                });

                var comp15A2Answers = compObj.getItem15A2Answers();

                Ext.each(comp15A2Answers.items.items, function (item) {

                    item.setValue(false);

                    if (item.itemId == 'item15A2NA') {
                        item.setValue(true);
                    }
                });

                var comp15CAnswers = compObj.getItem15CAnswers();

                Ext.each(comp15CAnswers.items.items, function (item) {

                    item.setValue(false);

                    if (item.itemId == 'item15CNA') {
                        item.setValue(true);
                    }
                });
            }

            if ((yesAnswer) && !(fatherSpecified)) {

                var comp15B1Answers = compObj.getItem15B1Answers();

                Ext.each(comp15B1Answers.items.items, function (item) {

                    item.setValue(false);

                    if (item.itemId == 'item15B1Never') {
                        item.setValue(true);
                    }
                });

                var comp15B2Answers = compObj.getItem15B2Answers();

                Ext.each(comp15B2Answers.items.items, function (item) {

                    item.setValue(false);

                    if (item.itemId == 'item15B2NA') {
                        item.setValue(true);
                    }
                });

                var comp15DAnswers = compObj.getItem15DAnswers();

                Ext.each(comp15DAnswers.items.items, function (item) {

                    item.setValue(false);

                    if (item.itemId == 'item15DNA') {
                        item.setValue(true);
                    }
                });
            }

            break;

        case 'applicabilityQuestion15Yes':
            
            var item = getItem(19, 5);

            if (!(item == undefined)) {

                item.IsApplicable = 1;
                updateItem(item);

                initializeAnswers('item15');
            }

            // Enable section for Item 15
            enableContainerItems(['item15A1', 'item15A2', 'item15B1', 'item15B2', 'item15C', 'item15D']);
            
            break;

        case 'applicabilityQuestion15No':

            var item = getItem(19, 5);

            if (!(item == undefined)) {

                item.IsApplicable = 2;
                updateItem(item);
            }
            
            // Disable section for Item 15
            disableContainerItems(['item15A1', 'item15A2', 'item15B1', 'item15B2', 'item15C', 'item15D']);
            setDisabledFieldValuesInContainer(['item15A1', 'item15A2', 'item15B1', 'item15B2', 'item15C', 'item15D']);

            // Reset store values
            var fields = [];
            var vmFields = [];
            var field;
            var vmField
            var parms = {};

            field = { 'ResponsiblePartyVisitationFrequencyWithMotherCode': null };
            fields.push(field);

            field = { 'IsResponsiblePartyVisitationFrequencyWithMotherSufficient': null };
            fields.push(field);

            field = { 'ResponsiblePartyVisitationFrequencyWithFatherCode': null };
            fields.push(field);

            field = { 'IsResponsiblePartyVisitationFrequencyWithFatherSufficient': null };
            fields.push(field);

            field = { 'IsResponsiblePartyVisitationQualityWithMotherSufficient': null };
            fields.push(field);

            field = { 'IsResponsiblePartyVisitationQualityWithFatherSufficient': null };
            fields.push(field);

            parms['fields'] = fields;

            vmField = { 'responsiblePartyVisitationFrequencyWithMotherCode': null };
            vmFields.push(vmField);

            vmField = { 'isResponsiblePartyVisitationFrequencyWithMotherSufficient': null };
            vmFields.push(vmField);

            vmField = { 'responsiblePartyVisitationFrequencyWithFatherCode': null };
            vmFields.push(vmField);

            vmField = { 'isResponsiblePartyVisitationFrequencyWithFatherSufficient': null };
            vmFields.push(vmField);

            vmField = { 'isResponsiblePartyVisitationQualityWithMotherSufficient': null };
            vmFields.push(vmField);

            vmField = { 'isResponsiblePartyVisitationQualityWithFatherSufficient': null };
            vmFields.push(vmField);

            parms['vmFields'] = vmFields;

            parms['storeId'] = 'CR_WellBeing_CollectionStore';

            saveChanges(parms);

            break;

        case 'question15CNo':

            if (parms.currentVal) {

                compObj.getResponsiblePartyVisitationQualityWithMotherExplained().setDisabled(false);
            } else {

                compObj.getResponsiblePartyVisitationQualityWithMotherExplained().setDisabled(true);
                compObj.getResponsiblePartyVisitationQualityWithMotherExplained().setValue(null);
            }

            break;

        case 'question15DNo':

            if (parms.currentVal) {

                compObj.getResponsiblePartyVisitationQualityWithFatherExplained().setDisabled(false);
            } else {

                compObj.getResponsiblePartyVisitationQualityWithFatherExplained().setDisabled(true);
                compObj.getResponsiblePartyVisitationQualityWithFatherExplained().setValue(null);
            }

            break;

        case 'item16ApplicableYes':

            var item = getItem(20, 6);

            if (!(item == undefined)) {

                item.IsApplicable = 1;
                updateItem(item);

                initializeAnswers('item16');
            }

            // Enable section for Item 16
            enableContainerItems(['item16A', 'item16B', 'educationGrid', 'item16ParticipantCheckboxGroupChildren']);

            break;

        case 'item16ApplicableNo':

            var item = getItem(20, 6);

            if (!(item == undefined)) {

                item.IsApplicable = 2;
                updateItem(item);
            }

            // Disable section for Item 16
            disableContainerItems(['item16A', 'item16B', 'educationGrid', 'item16ParticipantCheckboxGroupChildren']);
            setDisabledFieldValuesInContainer(['item16A', 'item16B', 'educationGrid', 'item16ParticipantCheckboxGroupChildren']);

            // Reset store values
            var fields = [];
            var vmFields = [];
            var field;
            var vmField
            var parms = {};

            field = { 'IsAgencyAssessEducationNeeds': null };
            fields.push(field);

            field = { 'IsAgencyAddressEducationNeeds': null };
            fields.push(field);

            parms['fields'] = fields;

            vmField = { 'isAgencyAssessEducationNeeds': null };
            vmFields.push(vmField);

            vmField = { 'isAgencyAddressEducationNeeds': null };
            vmFields.push(vmField);

            parms['vmFields'] = vmFields;

            parms['storeId'] = 'CR_WellBeing_CollectionStore';

            saveChanges(parms);

            break;

        case 'item17Yes':

            var item = getItem(21, 7);

            if (!(item == undefined)) {

                item.IsApplicable = 1;
                updateItem(item);

                initializeAnswers('item17');
            }

            // Enable section for Item 17
            enableContainerItems(['item17A1']);

            break;

        case 'item17No':

            var item = getItem(21, 7);

            if (!(item == undefined)) {

                item.IsApplicable = 2;
                updateItem(item);
            }

            // Disable section for Item 17
            disableContainerItems(['item17A1', 'pdHealthGrid', 'item17A4', 'item17B1', 'item17B2', 'item17B3']);
            setDisabledFieldValuesInContainer(['item17A1', 'pdHealthGrid', 'item17A4', 'item17B1', 'item17B2', 'item17B3']);

            // Reset store values
            var fields = [];
            var vmFields = [];
            var field;
            var vmField
            var parms = {};

            field = { 'IsAgencyAssessPhysicalHealthNeeds': null };
            fields.push(field);

            field = { 'IsAgencyAssessDentalHealthNeeds': null };
            fields.push(field);

            field = { 'IsFosterOversightMedicationForPhysicalHealtyAppropriate': null };
            fields.push(field);

            field = { 'IsAppropriateSerivcesForAllPhysicalHealthNeeds': null };
            fields.push(field);

            field = { 'IsAppropriateServicesForAllDentalNeeds': null };
            fields.push(field);

            parms['fields'] = fields;

            vmField = { 'isAgencyAssessPhysicalHealthNeeds': null };
            vmFields.push(vmField);

            vmField = { 'isAgencyAssessDentalHealthNeeds': null };
            vmFields.push(vmField);

            vmField = { 'isFosterOversightMedicationForPhysicalHealtyAppropriate': null };
            vmFields.push(vmField);

            vmField = { 'isAppropriateServicesForAllPhysicalHealthNeeds': null };
            vmFields.push(vmField);

            vmField = { 'isAppropriateServicesForAllDentalNeeds': null };
            vmFields.push(vmField);

            parms['vmFields'] = vmFields;

            parms['storeId'] = 'CR_WellBeing_CollectionStore';

            saveChanges(parms);

            break;

        case 'item17A4':

            var comp = compObj.getItem2Question1();
            var result = comp.plugins[0].getRulesEvalResult();

            if (result.validityResult == 'other') {

                var criteria1 = compObj.getFosterFederalCaseManagamentCriteria1();
                var criteria2 = compObj.getFosterFederalCaseManagamentCriteria2();
                var criteria3 = compObj.getFosterFederalCaseManagamentCriteria3();
                var criteria4 = compObj.getFosterFederalCaseManagamentCriteria4();
                var criteria5 = compObj.getFosterFederalCaseManagamentCriteria5();

                criteria1.setValue(178);
                criteria1.setReadOnly(true);


                criteria2.setValue(false);
                criteria3.setValue(false);
                criteria4.setValue(false);
                criteria5.setValue(false);


                criteria2.setDisabled(true);
                criteria3.setDisabled(true);
                criteria4.setDisabled(true);
                criteria5.setDisabled(true);
            }

            break;

        case 'item17ApplicableCases':

            var comp = compObj.getItem2Question1();
            var result = comp.plugins[0].getRulesEvalResult();

            if (result.validityResult == 'fosterCareCase') {

                var item17No = compObj.getItem17No();
                var item17Yes = compObj.getItem17Yes();

                item17Yes.setValue(1);
                item17No.setValue(false);
            }

            break;

        case 'item17B1':

            var comp = compObj.getItem2Question1();
            var result = comp.plugins[0].getRulesEvalResult();
            var item17B1No = compObj.getItem17B1No();
            var item17B1Yes = compObj.getItem17B1Yes();
            var item17B1NA = compObj.getItem17B1NA();

            if (result.validityResult == 'other') {

                item17B1Yes.setValue(false);
                item17B1No.setValue(false);
                item17B1NA.setValue(false);
            }

            if (result.validityResult == 'fosterCareCase') {

                item17B1Yes.enable();
                item17B1No.enable();

                item17B1NA.setValue(false);
                item17B1NA.disable();
            } else {

                item17B1Yes.setValue(false);
                item17B1Yes.disable();
                item17B1No.setValue(false);
                item17B1No.disable();

                item17B1NA.enable();
                item17B1NA.setValue(3);
            }

            break;

        case 'item18ApplicableYes':

            var item = getItem(22, 7);

            if (!(item == undefined)) {

                item.IsApplicable = 1;
                updateItem(item);

                initializeAnswers('item18');
            }

            // Enable section for Item 18
            enableContainerItems(['item18A', 'mbHealthGrid', 'item18B', 'item18C']);

            break;

        case 'item18ApplicableNo':

            var item = getItem(22, 7);

            if (!(item == undefined)) {

                item.IsApplicable = 2;
                updateItem(item);
            }

            // Disable section for Item 18
            disableContainerItems(['item18A', 'mbHealthGrid', 'item18B', 'item18C']);
            setDisabledFieldValuesInContainer(['item18A', 'mbHealthGrid', 'item18B', 'item18C']);

            // Reset store values
            var fields = [];
            var vmFields = [];
            var field;
            var vmField
            var parms = {};

            field = { 'IsAgencyAssessMentalHealthNeeds': null };
            fields.push(field);

            field = { 'IsFosterOversightMedicationForMentalHealtyAppropriate': null };
            fields.push(field);

            field = { 'isAppropriateServicesForMentalHealthNeeds': null };
            fields.push(field);

            parms['fields'] = fields;

            vmField = { 'isAgencyAssessMentalHealthNeeds': null };
            vmFields.push(vmField);

            vmField = { 'isFosterOversightMedicationForMentalHealtyAppropriate': null };
            vmFields.push(vmField);

            vmField = { 'isAppropriateServicesForMentalHealthNeeds': null };
            vmFields.push(vmField);

            parms['vmFields'] = vmFields;

            parms['storeId'] = 'CR_WellBeing_CollectionStore';

            saveChanges(parms);

            break;

        case 'item18B':

            if (Ext.isEmpty(compObj.getItem2Question1)) {

                break;
            }

            var comp = compObj.getItem2Question1();
            var result = comp.plugins[0].getRulesEvalResult();

            if (result.validityResult == 'other') {

                var item18BNo = compObj.getItem18BNo();
                var item18BYes = compObj.getItem18BYes();
                var item18BNA = compObj.getItem18BNA();

                item18BYes.setValue(false);
                item18BNo.setValue(false);
                item18BNA.setValue(false);
            }

            break;

        default:

            break;
    }
}
var validateFacesheetItems = function (comp, section, parms) {

    if (!(pageLoadStatus['Facesheet'] == 'rendered')) {

        return;
    }

    if (parms.dataChanged) {

        saveChanges(parms);
        
        if (!Ext.isEmpty(parms.vmFields)) {

            var keys;

            Ext.each(parms.vmFields, function (vmField) {

                keys = Object.keys(vmField);

                window.facesheetViewModel.set(keys[0], vmField[keys[0]]);
            });
        }
    }

    Ext.suspendLayouts();

    runFacesheetBusinessRules(comp, section);

    if (parms.runValidations) {

        runFacesheetValidationRules(comp, sr.Constants.AllFields);
    }

    if (Ext.isEmpty(parms)) {

        parms = {};
        parms['itemName'] = 'facesheet';
        parms['itemCode'] = 23;
    }

    if (parms.dataChanged) {

        updateItemStatus(comp.getFacesheetCenterPanel(), parms);
    }

    synchronizeRatings();

    var caseStatusCode = calculateCaseStatus(),
        caseStatusCmp = getCRSComponent('caseStatus'),
        status = getSavedCaseStatus();

    caseStatusCmp.setValue(status);

    Ext.resumeLayouts(true);
}
var validateSafetyItems = function (comp, section, validationMethod, parms, saveDataOnly) {

    if (!(pageLoadStatus['Safety'] == 'rendered')) {

        return;
    }

    if (parms.dataChanged) {

        saveChanges(parms);

        if (!Ext.isEmpty(parms.vmFields)) {

            var keys;

            Ext.each(parms.vmFields, function (vmField) {

                keys = Object.keys(vmField);

                window.safetyViewModel.set(keys[0], vmField[keys[0]]);
            });
        }
    }

    if (saveDataOnly) {

        return;
    }

    if (!Ext.isEmpty(parms)) {

        if (!Ext.isEmpty(parms.control)) {

            parms.control.suspendEvents();
        }
    }

    Ext.suspendLayouts();

    runSafetyBusinessRules(comp, section, parms);

    if (parms.runValidations) {

        var vMethod = Ext.isEmpty(validationMethod) ? section : validationMethod;

        runSafetyValidationRules(comp, vMethod);
    }

    var itemComp = comp.getSafetyPanel();
    //
    // If safety panel is rendered, calculate the rating and status. Otherwise use the stored values.
    //
    if (!Ext.isEmpty(itemComp) && pageLoadStatus['Safety'] == 'rendered') {
        //
        // Calculate Rating
        //
        var ratingParms = {
            'RatingItemId': parms.ratingId,
            'RatingOverrideItemId': parms.ratingOverrideId,
            'RatingDefault': parms.ratingDefault,
            'RatingItemName': parms.itemName
        };

        calculateItemRating(ratingParms);

        //
        // Calculate Status
        //
        if (!Ext.isEmpty(parms.itemName)) {

            if (parms.itemName.toLowerCase() == 'item2') {

                verifyPreApplicabilityAnswers(parms.itemName);
            }
        }
        
        if (parms.dataChanged) {

            updateItemStatus(comp.getSafetyPanel(), parms);
        }

        ////
        //// Saved completed items to database in the background
        ////
        //if (!appDataEvent.safety.initialLoad) {

        //    if (!Ext.isEmpty(itemStatuses)) {

        //        if (parms.dataChanged) {

        //            appDataEvent.safety.dataChanged = true;
        //        }

        //        if (itemStatuses[parms.itemName] == 'Completed' &&
        //            appDataEvent.safety.dataChanged &&
        //            appDataEvent.safety.changeByUserAction) {

        //            silentSaveTrigger.push(parms);

        //            silentSave = true;

        //            saveCompleted = false;

        //            synchronizeRatings();

        //            initializeResultsContainer();

        //            comp.saveData();
        //        }
        //    }
        //}

        if (itemStatuses[parms.itemName] == 'Completed' &&
            appDataEvent.safety.changeByUserAction) {

            synchronizeRatings();

            var caseStatusCode = calculateCaseStatus(),
                caseStatusCmp = getCRSComponent('caseStatus'),
                status = getSavedCaseStatus();

            caseStatusCmp.setValue(status);

            updateAllOutcomeRatings();
        }

    } else {
        //
        // Get stored Rating
        //
        if (!Ext.isEmpty(parms.ratingId)) {

            var ratingCmp = getCRSComponent(parms.ratingId);

            ratingCmp.itemCode = parms.itemCode;
            ratingCmp.outcomeCode = parms.outcomeCode;

            ratingCmp.getItemRating();
        }
    }

    if (!Ext.isEmpty(parms)) {

        if (!Ext.isEmpty(parms.control)) {

            parms.control.resumeEvents(true);
        }
    }

    Ext.resumeLayouts(true);
}
var validatePermanencyItems = function (comp, section, parms, saveDataOnly) {

    if (!(pageLoadStatus['Permanency'] == 'rendered')) {

        return;
    }

    if (parms.dataChanged) {

        saveChanges(parms);

        if (!Ext.isEmpty(parms.vmFields)) {

            var keys;

            Ext.each(parms.vmFields, function (vmField) {

                keys = Object.keys(vmField);

                window.permanencyViewModel.set(keys[0], vmField[keys[0]]);
            });
        }
    }

    if (saveDataOnly) {

        return;
    }

    if (!Ext.isEmpty(parms)) {

        if (!Ext.isEmpty(parms.control)) {

            parms.control.suspendEvents();
        }
    }

    Ext.suspendLayouts();

    runPermanencyBusinessRules(comp, section, parms);

    if (parms.runValidations) {

        runPermanencyValidationRules(comp, section);
    }

    var caseType = getCaseType();
    var itemStatus;

    if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

        itemStatus = 'Not Applicable';
        var statusObj = { ItemCode: parms.itemCode, StatusDesc: itemStatus, OutcomeCode: parms.outcomeCode };

        updateItemStatusCode(statusObj);

        return;
    }

    var itemComp = comp.getPermanencyPanel();
    //
    // If permanency panel is rendered, calculate the rating and status. Otherwise use the stored values.
    //
    if (!Ext.isEmpty(itemComp) && pageLoadStatus['Permanency'] == 'rendered') {
        //
        // Calculate Rating
        //
        if (!Ext.isEmpty(parms.ratingId)) {

            var ratingParms = {
                'RatingItemId': parms.ratingId,
                'RatingOverrideItemId': parms.ratingOverrideId,
                'RatingDefault': parms.ratingDefault,
                'RatingItemName': parms.itemName
            };

            calculateItemRating(ratingParms);
            //
            // Calculate Status
            //
            if (!Ext.isEmpty(parms.itemName)) {

                if (parms.itemName.toLowerCase() == 'item8' || parms.itemName.toLowerCase() == 'item11') {

                    verifyPreApplicabilityAnswers(parms.itemName);
                }
            }

            if (parms.dataChanged) {

                updateItemStatus(comp.getPermanencyPanel(), parms);
            }

            ////
            //// Saved completed items to database in the background
            ////
            //if (!appDataEvent.permanency.initialLoad) {

            //    if (!Ext.isEmpty(itemStatuses)) {

            //        if (parms.dataChanged) {

            //            appDataEvent.permanency.dataChanged = true;
            //        }

            //        if (itemStatuses[parms.itemName] == 'Completed' &&
            //            appDataEvent.permanency.dataChanged &&
            //            appDataEvent.permanency.changeByUserAction) {

            //            if (silentSaveTrigger.length == 0) {

            //                silentSaveTrigger.push(parms);

            //                silentSave = true;

            //                saveCompleted = false;

            //                synchronizeRatings();

            //                initializeResultsContainer();

            //                comp.saveData();
            //            }                        
            //        }
            //    }
            //}

            if (itemStatuses[parms.itemName] == 'Completed' &&
                        appDataEvent.permanency.changeByUserAction) {

                synchronizeRatings();

                var caseStatusCode = calculateCaseStatus(),
                    caseStatusCmp = getCRSComponent('caseStatus'),
                    status = getSavedCaseStatus();

                caseStatusCmp.setValue(status);

                updateAllOutcomeRatings();
            }
        }
    } else {
        //
        // Get stored Rating
        //
        if (!Ext.isEmpty(parms.ratingId)) {

            var ratingCmp = getCRSComponent(parms.ratingId);

            ratingCmp.itemCode = parms.itemCode;
            ratingCmp.outcomeCode = parms.outcomeCode;

            ratingCmp.getItemRating();
        }
    }

    if (!Ext.isEmpty(parms)) {

        if (!Ext.isEmpty(parms.control)) {

            parms.control.resumeEvents(true);
        }
    }

    Ext.resumeLayouts(true);
}
var validateWellbeingItems = function (comp, section, parms) {

    if (!(pageLoadStatus['Wellbeing'] == 'rendered')) {
        return;
    }

    if (parms.dataChanged) {

        saveChanges(parms);

        if (!Ext.isEmpty(parms.vmFields)) {

            var keys;

            Ext.each(parms.vmFields, function (vmField) {

                keys = Object.keys(vmField);
                
                window.wellbeingViewModel.set(keys[0], vmField[keys[0]]);
            });
        }
    }

    if (!Ext.isEmpty(parms)) {

        if (!Ext.isEmpty(parms.control)) {

            parms.control.suspendEvents();
        }
    }

    Ext.suspendLayouts();

    runWellbeingBusinessRules(comp, section, parms);

    if (parms.runValidations) {

        runWellbeingValidationRules(comp, section);
    }

    var itemComp = comp.getWellbeingPanel();

    //
    // If wellbeing panel is rendered, calculate the rating and status. Otherwise use the stored values.
    //
    if (!Ext.isEmpty(itemComp) && pageLoadStatus['Wellbeing'] == 'rendered') {
        //
        // Calculate Rating
        //
        if (!Ext.isEmpty(parms.ratingId)) {

            var ratingParms = {
                'RatingItemId': parms.ratingId,
                'RatingOverrideItemId': parms.ratingOverrideId,
                'RatingDefault': parms.ratingDefault,
                'RatingItemName': parms.itemName
            };

            calculateItemRating(ratingParms);

            var updParms = parms;
            updParms.itemName = parms.itemName.charAt(0).toLowerCase() + parms.itemName.slice(1);

            if (updParms.itemName == 'item12A' || updParms.itemName == 'item12B' || updParms.itemName == 'item12C') {

                itemRatings.updateItem12Rating();

                var outcomeRating = updateOutcomeRating('#wellbeingItem12Rating', '#wellbeingItem12RatingOverride', null);
            }

            //
            // Calculate Status
            //            
            if (!Ext.isEmpty(parms.itemName)) {

                var itemName = updParms.itemName == 'item12' ? 'item12B' : updParms.itemName;

                if (updParms.itemName == 'item12B' || updParms.itemName == 'item13' || updParms.itemName == 'item15') {

                    verifyPreApplicabilityAnswers(itemName);
                }
            }

            if (updParms.dataChanged) {

                updateItemStatus(comp.getWellbeingPanel(), updParms);
            }

            //
            // Update Item12 Status
            //            
            if (updParms.itemName == 'item12A' || updParms.itemName == 'item12B' || updParms.itemName == 'item12C') {

                itemStatuses.updateItem12Status();
            }
            ////
            //// Saved completed items to database in the background
            ////
            //if (!appDataEvent.wellbeing.initialLoad) {

            //    if (!Ext.isEmpty(itemStatuses)) {

            //        if (parms.dataChanged) {

            //            appDataEvent.wellbeing.dataChanged = true;
            //        }

            //        if (!(updParms.itemName == 'item17' || updParms.itemName == 'item18')) {

            //            if (itemStatuses[updParms.itemName] == 'Completed' &&
            //                appDataEvent.wellbeing.dataChanged &&
            //                appDataEvent.wellbeing.changeByUserAction) {

            //                silentSaveTrigger.push(updParms);

            //                silentSave = true;

            //                saveCompleted = false;

            //                synchronizeRatings();

            //                initializeResultsContainer();

            //                comp.saveData();
            //            }
            //        }                    
            //    }
            //}

            if (itemStatuses[updParms.itemName] == 'Completed' &&
                appDataEvent.wellbeing.changeByUserAction) {
                                
                synchronizeRatings();

                var caseStatusCode = calculateCaseStatus();
                //
                // Update Case Status Display
                //
                var caseStatusCode = calculateCaseStatus(),
                    caseStatusCmp = getCRSComponent('caseStatus'),
                    status = getSavedCaseStatus();

                caseStatusCmp.setValue(status);

                updateAllOutcomeRatings();
            }
        }
    } else {
        //
        // Get stored Rating
        //
        if (!Ext.isEmpty(parms.ratingId)) {

            var ratingCmp = getCRSComponent(parms.ratingId);

            ratingCmp.itemCode = parms.itemCode;
            ratingCmp.outcomeCode = parms.outcomeCode;

            ratingCmp.getItemRating();
        }
    }

    if (!Ext.isEmpty(parms)) {

        if (!Ext.isEmpty(parms.control)) {

            parms.control.resumeEvents(true);
        }
    }

    Ext.resumeLayouts(true);
}