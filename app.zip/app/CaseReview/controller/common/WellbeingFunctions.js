﻿Ext.define('App.casereview.controller.common.WellbeingFunctions', {
    extend: 'Ext.Base',
    singleton: true,
    saveEnabled: false,
    fireFocusEvent: function (container) {

        if (this.saveEnabled) {
            return;
        }

        container.ownerCt.fireEvent('focus', container.ownerCt, null);
    },
    alternateClassName: 'WellbeingFunctions',
    applyOverrideGeneric: function (parms, parms2) {

        Ext.apply(parms, parms2);

        return parms;
    },
    handleWellbeingPanelBeforerender: function () {

        // 
        // Create viewModel
        //
        var vModel = createViewModel('wellbeing');

        window.wellbeingViewModel = vModel;
    },
    handleWellbeingPanelAfterrender: function () {

        var self = this;

        pageLoadStatus['Wellbeing'] = 'rendered';
        //
        // Run validations for page for all items once on load
        //        
        var parms = {
            runValidations: true,
            dataChanged: false
        };

        runWellbeingRules(getAppController(), sr.Constants.AllFields, parms);
    },
    handleWellbeingBlur: function (parmsIn) {

        var self = this;

        var dataParms = {
            collectionName: parmsIn.collectionName,
            propertyName: parmsIn.propertyName,
            itemCode: parmsIn.itemCode
        },
        savedValue = getSavedPropertyValue(dataParms),
        newValue = parmsIn.control.getValue();

        appDataEvent.wellbeing.changeByUserAction = isDataChangedByUser(parmsIn.control, parmsIn.control.getValue(), savedValue);

        if (!appDataEvent.wellbeing.changeByUserAction) {

            return;
        }

        if (pageLoadStatus['Wellbeing'] == 'rendered') {

            if (newValue) {

                var fields = [],
                    vmFields = [],
                    vmField = {},
                    field = {};

                vmField[parmsIn.vmFieldName] = newValue;
                field[parmsIn.propertyName] = newValue;

                fields.push(field);
                fields.push({ 'DataState': 0 });

                vmFields.push(vmField);

                var parms = {
                    currentVal: newValue,
                    storeId: parmsIn.storeId,
                    fields: fields,
                    vmFields: vmFields,
                    control: parmsIn.control,
                    runValidations: parmsIn.runValidations,
                    itemCode: parmsIn.control.ownerCt.ownerCt.ItemCode,
                    outcomeCode: parmsIn.control.ownerCt.ownerCt.OutcomeCode,
                    dataChanged: parmsIn.dataChanged
                };

                parms = getStatusParms(parms, parmsIn.ratingItemId);

                initValidations(parmsIn.itemName);

                //this.checkController();

                runWellbeingRules(getAppController(), parmsIn.methodName, parms);
            }
        }
    },
    handleWellbeingRatingAfterrender: function (parmsIn) {

        parmsIn.ratingComponent.getItemRating();
    },
    handleWellbeingOutcomeRatingAfterrender: function (outcomeCode) {

        var self = this;

        if (outcomeCode == 5) {

            getAppController().getWellbeingOutcome1Rating().getOutcomeRating(outcomeCode);
        }

        if (outcomeCode == 6) {

            getAppController().getWellbeingOutcome2Rating().getOutcomeRating(outcomeCode);
        }
        
        if (outcomeCode == 7) {

            getAppController().getWellbeingOutcome3Rating().getOutcomeRating(outcomeCode);
        }
    },
    handleWellbeingChange: function (parmsIn) {

        var self = this;

        var dataParms = {
            collectionName: parmsIn.collectionName,
            propertyName: parmsIn.propertyName,
            itemCode: parmsIn.itemCode
        };

        var savedValue = getSavedPropertyValue(dataParms);

        appDataEvent.permanency.changeByUserAction = isDataChangedByUser(parmsIn.control, parmsIn.newValue, savedValue);

        if (!appDataEvent.permanency.changeByUserAction) {

            return;
        }

        if (pageLoadStatus['Wellbeing'] == 'rendered') {

            //self.checkController();

            if (!Ext.isEmpty(parmsIn.newValue)) {

                if (parmsIn.newValue == 6) {

                    getAppController().getLivingArragmentExplained().enable();
                }

                var fields = [],
                    vmFields = [],
                    vmField = {},
                    field = {};

                vmField[parmsIn.vmFieldName] = parmsIn.newValue;
                field[parmsIn.propertyName] = parmsIn.newValue;

                fields.push(field);

                field = { 'DataState': 0 };
                fields.push(field);

                vmFields.push(vmField);

                var parms = {
                    currentVal: parmsIn.newValue,
                    storeId: parmsIn.storeId,
                    fields: fields,
                    vmFields: vmFields,
                    control: parmsIn.control,
                    runValidations: parmsIn.runValidations,
                    dataChanged: parmsIn.dataChanged
                };

                parms = getStatusParms(parms, parmsIn.ratingItemId);

                initValidations(parmsIn.itemName);

                runWellbeingRules(getAppController(), parmsIn.methodName, parms);
            }
        }
    },
    handlePreapplicabilityChange: function (parmsIn) {

        var dataParms = {
            control: parmsIn.control,
            newValue: parmsIn.newValue,
            oldValue: parmsIn.oldValue,
            groupName: parmsIn.groupName
        },
        result = checkIfMultiAnswerChangedByUser(dataParms);

        appDataEvent.permanency.changeByUserAction = result.isUserAction;

        if (!appDataEvent.permanency.changeByUserAction) {

            return;
        }

        var newKeys = getObjectKeys(result.selectedItem);

        if (newKeys.length > 0) {

            var cmp = parmsIn.control.queryBy(function (radio) {

                return radio.inputId == newKeys[0];
            });

            //deselectPrevChoices(cmp[0]);

            var parms = {
                currentVal: parmsIn.newValue,
                itemName: parmsIn.itemName,
                pageName: parmsIn.pageName,
                ratingId: parmsIn.ratingItemId,
                groupName: parmsIn.groupName,
                groupMembers: parmsIn.groupMembers,
                dataChanged: parmsIn.dataChanged,
                section: parmsIn.sectionName,
                validationMethod: parmsIn.validationMethod,
                groupItemName: parmsIn.groupItemName,
                newValue: parmsIn.newValue,
                oldValue: parmsIn.oldValue
            };

            processWellbeingPreApplicability(parmsIn.control, parms);

        } else {

            return;
        }
    },
    handleWellbeingAfterrender: function (parmsIn) {

        var self = this;

        var parms = {
            runValidations: parmsIn.runValidations,
            dataChanged: parmsIn.dataChanged
        };

        parms = getStatusParms(parms, parmsIn.ratingItemId);

        initValidations(parmsIn.itemName);

        runWellbeingRules(getAppController(), parmsIn.methodName, parms);
    },
    handleItem12BApplicableChange: function (parmsIn) {

        var self = this;

        if (parmsIn.newValue) {

            if (pageLoadStatus['Wellbeing'] == 'rendered') {

                deselectPrevChoices(parmsIn.control);

                var selection = (parmsIn.newValue) ? parmsIn.control.inputValue : 0,
                    fields = [],
                    vmFields = [],
                    vmField = {},
                    field = {};

                field[parmsIn.propertyName] = selection;
                fields.push(field);

                field = { 'DataState': 0 };
                fields.push(field);

                vmField[parmsIn.vmFieldName] = selection;
                vmFields.push(vmField);

                var parms = {
                    currentVal: selection,
                    storeId: parmsIn.storeId,
                    fields: fields,
                    vmFields: vmFields,
                    control: parmsIn.control,
                    runValidations: parmsIn.runValidations,
                    dataChanged: parmsIn.dataChanged,
                    ratingDefault: parmsIn.ratingDefault
                };

                parms = getStatusParms(parms, parmsIn.ratingItemId);

                initValidations(parmsIn.itemName);

                runWellbeingRules(getAppController(), parmsIn.methodName, parms);
            }
        }
    },
    handleItemApplicableChange: function (parmsIn) {

        var self = this;

        var dataParms = {
            collectionName: parmsIn.collectionName,
            itemCode: parmsIn.itemCode,
            propertyName: parmsIn.propertyName,
            newValue: parmsIn.newValue,
            oldValue: parmsIn.oldValue,
            control: parmsIn.control,
            isPageRendered: parmsIn.isPageRendered
        };

        var result = isChangedByUser(dataParms);

        appDataEvent.wellbeing.changeByUserAction = result.isUserAction;

        if (!appDataEvent.wellbeing.changeByUserAction) {

            return;
        }

        if (pageLoadStatus['Wellbeing'] == 'rendered') {

            if (parmsIn.newValue) {

                var vmFields = [],
                    vmField = {};

                vmField[parmsIn.vmField] = parmsIn.control.inputValue;

                vmFields.push(vmField);

                var parms = {
                    control: parmsIn.control,
                    runValidations: parmsIn.runValidations,
                    dataChanged: parmsIn.dataChanged,
                    vmFields: vmFields,
                    ratingDefault: parmsIn.ratingDefault
                };

                parms = getStatusParms(parms, parmsIn.ratingItemId);

                initValidations(parmsIn.itemName);

                runWellbeingRules(getAppController(), parmsIn.methodName, parms);
            }
        }
    },
    handleMedicalNeedsChange: function (parmsIn) {

        var self = this;

        appDataEvent.permanency.changeByUserAction = isDataChangedByUser(parmsIn.control, parmsIn.newValue);

        if (!appDataEvent.permanency.changeByUserAction) {

            return;
        }

        if (pageLoadStatus['Wellbeing'] == 'rendered') {

            var parms = getCheckboxSelections(parmsIn.newValue, parmsIn.groupName, 'MultiAnswer');

            parms = getStatusParms(parms, parmsIn.ratingItemId);

            var parms2 = {
                control: parmsIn.control,
                runValidations: parmsIn.runValidations,
                dataChanged: parmsIn.dataChanged,
                groupMembers: getCodeDescriptionGroup(parmsIn.groupName)
            };

            parms = concatJsonObjects(parms, [parms2]);

            initValidations(parmsIn.itemName);

            
            runWellbeingRules(getAppController(), parmsIn.methodName, parms);
        }
    },
    handleHealthGridAfterrender: function (parmsIn) {

        var self = this;

        var healthStore = GetHealthStore(parmsIn.healthCode),
            parms = {
                runValidations: parmsIn.runValidations,
                dataChanged: parmsIn.dataChanged
            };

        parmsIn.healthGrid.setStore(healthStore);

        parms = getStatusParms(parms, parmsIn.ratingItemId);

        runWellbeingRules(getAppController(), parmsIn.methodName, parms);
    },
    handleHealthGridEdit: function (parmsIn) {

        var self = this;

        var parms = {
            runValidations: parmsIn.runValidations,
            dataChanged: parmsIn.dataChanged,
            ratingItemId: parmsIn.ratingItemId,
            data: parmsIn.data,
            storeId: parmsIn.storeId,
            recordType: parmsIn.recordType
        };

        parms = getStatusParms(parms, parmsIn.ratingItemId);

        runWellbeingRules(getAppController(), parmsIn.methodName, parms);
    },
    addChangeEventListeners: function (container) {

        var self = this;

        self.addPreApplicabilityChangeListeners(container);

        self.addItem12AChangeListeners(container);

        self.addItem12BChangeListeners(container);

        self.addItem12CChangeListeners(container);

        self.addItem13ChangeListeners(container);

        self.addItem14ChangeListeners(container);

        self.addItem15ChangeListeners(container);

        self.addItem16ChangeListeners(container);

        self.addItem17ChangeListeners(container);

        self.addItem18ChangeListeners(container);
    },
    addPreApplicabilityChangeListeners: function (container) {

        var self = this,
            parms = {
                control: null,
                dataChanged: true,
                ratingItemId: null,
                itemName: null,
                pageName: 'Wellbeing',
                groupName: 'Applicability',
                sectionName: null,
                newValue: null,
                oldValue: null,
                groupItemName: null,
                validationMethod: null,
                groupMembers: null
            };

        //***************************************************************************
        // Item 12B - Pre-Applicability
        //***************************************************************************  
        container.queryById('item12BQuestion1').on('change', function (radioGroup, newValue, oldValue) {
            
            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (parms2.newValue) ? parms2.control.inputValue : 0,
            parms3 = {
                control: parms2.control,
                ratingItemId: 'wellbeingItem12BRating',
                itemName: 'Item12',
                sectionName: 'item12BQuestion1',
                newValue: selection,
                oldValue: parms2.oldValue,
                groupItemName: 'Sub-Item 12B',
                validationMethod: 'ValidateItem12B',
                groupMembers: [68, 69, 70, 71, 72]
            };
            
            parms = self.applyOverrideGeneric(parms, parms3);

            self.handlePreapplicabilityChange(parms);
        });

        container.queryById('item12BQuestion2').on('change', function (radioGroup, newValue, oldValue) {
            
            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (parms2.newValue) ? parms2.control.inputValue : 0,
            parms3 = {
                control: parms2.control,
                sectionName: 'item12BQuestion2',
                newValue: selection,
                oldValue: parms2.oldValue,
            };

            parms = self.applyOverrideGeneric(parms, parms3);

            self.handlePreapplicabilityChange(parms);
        });

        container.queryById('item12BQuestion3').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (parms2.newValue) ? parms2.control.inputValue : 0,
            parms3 = {
                control: parms2.control,
                sectionName: 'item12BQuestion3',
                newValue: selection,
                oldValue: parms2.oldValue
            };

            parms = self.applyOverrideGeneric(parms, parms3);

            self.handlePreapplicabilityChange(parms);
        });

        container.queryById('item12BQuestion4').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (parms2.newValue) ? parms2.control.inputValue : 0,
            parms3 = {
                control: parms2.control,
                sectionName: 'item12BQuestion4',
                newValue: selection,
                oldValue: parms2.oldValue
            };

            parms = self.applyOverrideGeneric(parms, parms3);

            self.handlePreapplicabilityChange(parms);
        });

        container.queryById('item12BQuestion5').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (parms2.newValue) ? parms2.control.inputValue : 0,
            parms3 = {
                control: parms2.control,
                sectionName: 'item12BQuestion5',
                newValue: selection,
                oldValue: parms2.oldValue
            };

            parms = self.applyOverrideGeneric(parms, parms3);

            self.handlePreapplicabilityChange(parms);
        });
        //***************************************************************************
        // Item 13 - Pre-Applicability
        //***************************************************************************  
        container.queryById('item13Question1').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (parms2.newValue) ? parms2.control.inputValue : 0,
            parms3 = {
                control: parms2.control,
                dataChanged: true,
                ratingItemId: 'wellbeingItem13Rating',
                itemName: 'Item13',
                pageName: 'Wellbeing',
                groupName: 'Applicability',
                sectionName: 'item13Question1',
                newValue: selection,
                oldValue: parms2.oldValue,
                groupItemName: 'Item 13',
                validationMethod: 'ValidateItem13',
                groupMembers: [73, 74, 75, 292, 76, 77, 78]
            };

            parms = self.applyOverrideGeneric(parms, parms3);

            self.handlePreapplicabilityChange(parms);
        });

        container.queryById('item13Question2').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (parms2.newValue) ? parms2.control.inputValue : 0,
            parms3 = {
                control: parms2.control,
                sectionName: 'item13Question2',
                newValue: selection,
                oldValue: parms2.oldValue
            };

            parms = self.applyOverrideGeneric(parms, parms3);

            self.handlePreapplicabilityChange(parms);
        });

        container.queryById('item13Question3').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (parms2.newValue) ? parms2.control.inputValue : 0,
            parms3 = {
                control: parms2.control,
                sectionName: 'item13Question3',
                newValue: selection,
                oldValue: parms2.oldValue
            };

            parms = self.applyOverrideGeneric(parms, parms3);

            self.handlePreapplicabilityChange(parms);
        });

        container.queryById('item13Question4').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (parms2.newValue) ? parms2.control.inputValue : 0,
            parms3 = {
                control: parms2.control,
                sectionName: 'item13Question4',
                newValue: selection,
                oldValue: parms2.oldValue
            };

            parms = self.applyOverrideGeneric(parms, parms3);

            self.handlePreapplicabilityChange(parms);
        });

        container.queryById('item13Question5').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (parms2.newValue) ? parms2.control.inputValue : 0,
            parms3 = {
                control: parms2.control,
                sectionName: 'item13Question5',
                newValue: selection,
                oldValue: parms2.oldValue
            };

            parms = self.applyOverrideGeneric(parms, parms3);

            self.handlePreapplicabilityChange(parms);
        });

        container.queryById('item13Question6').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (parms2.newValue) ? parms2.control.inputValue : 0,
            parms3 = {
                control: parms2.control,
                sectionName: 'item13Question6',
                newValue: selection,
                oldValue: parms2.oldValue
            };

            parms = self.applyOverrideGeneric(parms, parms3);

            self.handlePreapplicabilityChange(parms);
        });

        container.queryById('item13Question7').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (parms2.newValue) ? parms2.control.inputValue : 0,
            parms3 = {
                control: parms2.control,
                sectionName: 'item13Question7',
                newValue: selection,
                oldValue: parms2.oldValue
            };

            parms = self.applyOverrideGeneric(parms, parms3);

            self.handlePreapplicabilityChange(parms);
        });

        //***************************************************************************
        // Item 15 - Pre-Applicability
        //***************************************************************************  
        container.queryById('item15Question1').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (parms2.newValue) ? parms2.control.inputValue : 0,
            parms3 = {
                control: parms2.control,
                dataChanged: true,
                ratingItemId: 'wellbeingItem15Rating',
                itemName: 'Item15',
                pageName: 'Wellbeing',
                groupName: 'Applicability',
                sectionName: 'item15Question1',
                newValue: selection,
                oldValue: parms2.oldValue,
                groupItemName: 'Item 15',
                validationMethod: 'ValidateItem15',
                groupMembers: [79, 80, 293, 81, 82, 83]
            };

            parms = self.applyOverrideGeneric(parms, parms3);

            self.handlePreapplicabilityChange(parms);
        });
        
        container.queryById('item15Question2').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (parms2.newValue) ? parms2.control.inputValue : 0,
            parms3 = {
                control: parms2.control,
                sectionName: 'item15Question2',
                newValue: selection,
                oldValue: parms2.oldValue
            };

            parms = self.applyOverrideGeneric(parms, parms3);

            self.handlePreapplicabilityChange(parms);
        });

        container.queryById('item15Question3').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (parms2.newValue) ? parms2.control.inputValue : 0,
            parms3 = {
                control: parms2.control,
                sectionName: 'item15Question3',
                newValue: selection,
                oldValue: parms2.oldValue
            };

            parms = self.applyOverrideGeneric(parms, parms3);

            self.handlePreapplicabilityChange(parms);
        });

        container.queryById('item15Question4').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (parms2.newValue) ? parms2.control.inputValue : 0,
            parms3 = {
                control: parms2.control,
                sectionName: 'item15Question4',
                newValue: selection,
                oldValue: parms2.oldValue
            };

            parms = self.applyOverrideGeneric(parms, parms3);

            self.handlePreapplicabilityChange(parms);
        });

        container.queryById('item15Question5').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (parms2.newValue) ? parms2.control.inputValue : 0,
            parms3 = {
                control: parms2.control,
                sectionName: 'item15Question5',
                newValue: selection,
                oldValue: parms2.oldValue
            };

            parms = self.applyOverrideGeneric(parms, parms3);

            self.handlePreapplicabilityChange(parms);
        });

        container.queryById('item15Question6').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (parms2.newValue) ? parms2.control.inputValue : 0,
            parms3 = {
                control: parms2.control,
                sectionName: 'item15Question6',
                newValue: selection,
                oldValue: parms2.oldValue
            };

            parms = self.applyOverrideGeneric(parms, parms3);

            self.handlePreapplicabilityChange(parms);
        });
    },
    addItem12AChangeListeners: function (container) {

        var self = this;

        var parms = {
                control: null,
                collectionName: 'wellbeing',
                propertyName: null,
                itemCode: 14,
                vmFieldName: null,
                storeId: 'CR_WellBeing_CollectionStore',
                runValidations: true,
                dataChanged: true,
                ratingItemId: 'wellbeingItem12ARating',
                itemName: 'Item12',
                methodName: null,
                newValue: null,
                oldValue: null
        };

        // Question 12A1
        container.queryById('question12A1').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getNeedConcerns(),
            input = {
                control: parms2.control,
                propertyName: 'IsComprehensiveAssessementConducted',
                vmFieldName: 'isComprehensiveAssessementConducted',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);

            if (parms2.control.itemId == 'question12A1No') {
                comments.enable();
            } else {
                var retObj = comments.setValue('');
                comments.disable();
            }
        });

        // Question 12A2
        container.queryById('question12A2').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getServiceConcerns(),
            input = {
                control: parms2.control,
                propertyName: 'IsAppropriateServicesProvided',
                vmFieldName: 'isAppropriateServicesProvided',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);

            if (parms2.control.itemId == 'question12A2No') {
                comments.enable();
            } else {
                var retObj = comments.setValue('');
                comments.disable();
            }
        });
    },
    addItem12BChangeListeners: function (container) {

        var self = this;

        var parms = {
            control: null,
            collectionName: 'wellbeing',
            propertyName: null,
            itemCode: 15,
            vmFieldName: null,
            storeId: 'CR_WellBeing_CollectionStore',
            runValidations: true,
            dataChanged: true,
            ratingItemId: 'wellbeingItem12BRating',
            itemName: 'Item12',
            methodName: null,
            newValue: null,
            oldValue: null
        };
        // item12BApplicableMother
        container.queryById('item12BApplicableMother').on('change', function (radioGroup, newVal, oldVal) {

            var filteredRadio = radioGroup.items.items.filter(function (radio) {

                return radio.checked == true;
            }),
            oldKeys = Object.keys(oldVal),
            prevSelection = radioGroup.items.items.filter(function (radio) {

                return radio.inputValue == oldVal[oldKeys[0]];
            }),
            fatherApplicableNoCmp = getAppController().getItem12BApplicableFatherNo(),
            isFatherApplicable = fatherApplicableNoCmp.getValue(),
            parms2 = {
                control: filteredRadio[0],
                propertyName: 'IsNeedsServicesApplicableForMother',
                vmFieldName: 'isNeedsServicesApplicableForMother',
                methodName: filteredRadio[0].itemId,
                newValue: filteredRadio[0].inputValue,
                oldValue: oldKeys.length == 0 ? null : oldVal[oldKeys[0]],
                ratingDefault: filteredRadio[0].inputValue == 2 && isFatherApplicable ? 'NA' : undefined
            };

            parms = self.applyOverrideGeneric(parms, parms2);
            
            self.handleItem12BApplicableChange(parms);
        });
        
        // item12BApplicableFather
        container.queryById('item12BApplicableFather').on('change', function (radioGroup, newVal, oldVal) {

            var filteredRadio = radioGroup.items.items.filter(function (radio) {

                return radio.checked == true;
            }),
            oldKeys = Object.keys(oldVal),
            prevSelection = radioGroup.items.items.filter(function (radio) {

                return radio.inputValue == oldVal[oldKeys[0]];
            }),
            motherApplicableNoCmp = getAppController().getItem12BApplicableMotherNo(),
            isMotherApplicable = motherApplicableNoCmp.getValue(),
            parms2 = {
                control: filteredRadio[0],
                propertyName: 'IsNeedsServicesApplicableForFather',
                vmFieldName: 'isNeedsServicesApplicableForFather',
                methodName: filteredRadio[0].itemId,
                newValue: filteredRadio[0].inputValue,
                oldValue: oldKeys.length == 0 ? null : oldVal[oldKeys[0]],
                ratingDefault: filteredRadio[0].inputValue == 2 && isMotherApplicable ? 'NA' : undefined
            };

            parms = self.applyOverrideGeneric(parms, parms2);
            
            self.handleItem12BApplicableChange(parms);
        });

        // Question 12B1
        container.queryById('item12B1Answers').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getItem12B1Concerns(),
            input = {
                control: parms2.control,
                propertyName: 'IsComprehensiveAssessementForMotherConducted',
                vmFieldName: 'isComprehensiveAssessementForMotherConducted',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);

            if (parms2.control.itemId == 'question12B1No') {
                comments.enable();
            } else {
                var retObj = comments.setValue('');
                comments.disable();
            }
        });

        // Question 12B2
        container.queryById('item12B2Answers').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getItem12B2Concerns(),
            input = {
                control: parms2.control,
                propertyName: 'IsComprehensiveAssessementForFatherConducted',
                vmFieldName: 'isComprehensiveAssessementForFatherConducted',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);

            if (parms2.control.itemId == 'question12B2No') {
                comments.enable();
            } else {
                var retObj = comments.setValue('');
                comments.disable();
            }
        });

        // Question 12B3
        container.queryById('item12B3Answers').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getItem12B3Concerns(),
            input = {
                control: parms2.control,
                propertyName: 'IsAppropriateServicesForMotherProvided',
                vmFieldName: 'isAppropriateServicesForMotherProvided',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);

            if (parms2.control.itemId == 'question12B3No') {
                comments.enable();
            } else {
                var retObj = comments.setValue('');
                comments.disable();
            }
        });

        // Question 12B4
        container.queryById('item12B4Answers').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getItem12B4Concerns(),
            input = {
                control: parms2.control,
                propertyName: 'IsAppropriateServicesForFatherProvided',
                vmFieldName: 'isAppropriateServicesForFatherProvided',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);

            if (parms2.control.itemId == 'question12B4No') {
                comments.enable();
            } else {
                var retObj = comments.setValue('');
                comments.disable();
            }
        });
    },
    addItem12CChangeListeners: function (container) {

        var self = this;

        var parms = {
            collectionName: 'item',
            itemCode: 16,
            propertyName: null,
            newValue: null,
            oldValue: null,
            control: null,
            isPageRendered: (pageLoadStatus['Wellbeing'] == 'rendered') ? true : false,
            vmField: null,
            ratingItemId: 'wellbeingItem12CRating',
            runValidations: true,
            dataChanged: true,
            itemName: 'Item12',
            methodName: null,
            ratingDefault: null
        };

        // Question 12C
        container.queryById('item12C').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getItem12B4Concerns(),
            input = {
                control: parms2.control,
                propertyName: 'IsApplicable',
                vmFieldName: 'item12CApplicable',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue
            };

            if (parms2.control.itemId == 'item12CNo') {
                input['ratingDefault'] = 'NA';
            }

            parms = self.applyOverrideGeneric(parms, input);

            self.handleItemApplicableChange(parms);
        });

        // Question 12C1
        container.queryById('question12C1').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getItem12C1Concerns(),
            input = {
                control: parms2.control,
                propertyName: 'IsNeedsOfFosterParentsAdequatelyAssessed',
                vmFieldName: 'isNeedsOfFosterParentsAdequatelyAssessed',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);

            if (parms2.control.itemId == 'question12C1No') {
                comments.enable();
            } else {
                var retObj = comments.setValue('');
                comments.disable();
            }
        });

        // Question 12C2
        container.queryById('question12C2').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getItem12C2Concerns(),
            input = {
                control: parms2.control,
                propertyName: 'IsFosterParentsProvidedAppropriateServices',
                vmFieldName: 'isFosterParentsProvidedAppropriateServices',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);

            if (parms2.control.itemId == 'question12C2No') {
                comments.enable();
            } else {
                var retObj = comments.setValue('');
                comments.disable();
            }
        });
    },
    addItem13ChangeListeners: function (container) {

        var self = this;

        var parms = {
            collectionName: 'item',
            itemCode: 17,
            propertyName: null,
            newValue: null,
            oldValue: null,
            control: null,
            isPageRendered: (pageLoadStatus['Wellbeing'] == 'rendered') ? true : false,
            vmField: null,
            ratingItemId: 'wellbeingItem13Rating',
            runValidations: true,
            dataChanged: true,
            itemName: 'Item13',
            methodName: null,
            ratingDefault: null
        };

        // Question 13
        container.queryById('Question13Applicable').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getItem12B4Concerns(),
            input = {
                control: parms2.control,
                propertyName: 'IsApplicable',
                vmFieldName: 'item13Applicable',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue
            };

            if (parms2.control.itemId == 'applicabilityQuestion13No') {
                input['ratingDefault'] = 'NA';
            }

            parms = self.applyOverrideGeneric(parms, input);

            self.handleItemApplicableChange(parms);
        });

        // Question 13A
        container.queryById('question13A').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getItem13AConcerns(),
            input = {
                control: parms2.control,
                propertyName: 'IsAgencyConcertedEffortsToInvolveTheChild',
                vmFieldName: 'isAgencyConcertedEffortsToInvolveTheChild',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);

            if (parms2.control.itemId == 'question13ANo') {
                comments.enable();
            } else {
                var retObj = comments.setValue('');
                comments.disable();
            }
        });

        // Question 13B
        container.queryById('question13B').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getItem13BConcerns(),
            input = {
                control: parms2.control,
                propertyName: 'IsAgencyConcertedEffortsToInvolveTheMother',
                vmFieldName: 'isAgencyConcertedEffortsToInvolveTheMother',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);

            if (parms2.control.itemId == 'question13BNo') {
                comments.enable();
            } else {
                var retObj = comments.setValue('');
                comments.disable();
            }
        });

        // Question 13C
        container.queryById('question13C').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getItem13CConcerns(),
            input = {
                control: parms2.control,
                propertyName: 'IsAgencyConcertedEffortsToInvolveTheFather',
                vmFieldName: 'isAgencyConcertedEffortsToInvolveTheFather',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);

            if (parms2.control.itemId == 'question13CNo') {
                comments.enable();
            } else {
                var retObj = comments.setValue('');
                comments.disable();
            }
        });
    },
    addItem14ChangeListeners: function (container) {

        var self = this;

        //self.checkController();

        var parms = {
                control: null,
                collectionName: 'wellbeing',
                propertyName: null,
                itemCode: 18,
                vmFieldName: null,
                storeId: 'CR_WellBeing_CollectionStore',
                runValidations: true,
                dataChanged: true,
                ratingItemId: 'wellbeingItem14Rating',
                itemName: 'Item14',
                methodName: null,
                newValue: null,
                oldValue: null
            };

        // Question 14A
        container.queryById('question14A').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            input = {
                control: parms2.control,
                propertyName: 'IsResponsiblePartyVisitationFrequencySufficient',
                vmFieldName: 'isResponsiblePartyVisitationFrequencySufficient',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);
        });

        // Question 14B
        container.queryById('question14B').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getResponsiblePartyVisitationQualityExplained(),
            input = {
                control: parms2.control,
                propertyName: 'IsResponsiblePartyVisitationQualitySufficient',
                vmFieldName: 'isResponsiblePartyVisitationQualitySufficient',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);

            if (parms2.control.itemId == 'question14BNo') {
                comments.enable();
            } else {
                var retObj = comments.setValue('');
                comments.disable();
            }
        });

        // visitationFrequency1
        container.queryById('visitationFrequency1').on('change', function (radio, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms2 = {
                    control: radio,
                    propertyName: 'ResponsiblePartyVisitationFrequencyCode',
                    vmFieldName: 'responsiblePartyVisitationFrequencyCode',
                    methodName: 'visitationFrequency1',
                    newValue: selection,
                    oldValue: oldValue
                };

            parms = self.applyOverrideGeneric(parms, parms2);

            self.handleWellbeingChange(parms);
        });

        // visitationFrequency2
        container.queryById('visitationFrequency2').on('change', function (radio, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms2 = {
                    control: radio,
                    propertyName: 'ResponsiblePartyVisitationFrequencyCode',
                    vmFieldName: 'responsiblePartyVisitationFrequencyCode',
                    methodName: 'visitationFrequency2',
                    newValue: selection,
                    oldValue: oldValue
                };

            parms = self.applyOverrideGeneric(parms, parms2);

            self.handleWellbeingChange(parms);
        });

        // visitationFrequency3
        container.queryById('visitationFrequency3').on('change', function (radio, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms2 = {
                    control: radio,
                    propertyName: 'ResponsiblePartyVisitationFrequencyCode',
                    vmFieldName: 'responsiblePartyVisitationFrequencyCode',
                    methodName: 'visitationFrequency3',
                    newValue: selection,
                    oldValue: oldValue
                };

            parms = self.applyOverrideGeneric(parms, parms2);

            self.handleWellbeingChange(parms);
        });

        // visitationFrequency4
        container.queryById('visitationFrequency4').on('change', function (radio, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms2 = {
                    control: radio,
                    propertyName: 'ResponsiblePartyVisitationFrequencyCode',
                    vmFieldName: 'responsiblePartyVisitationFrequencyCode',
                    methodName: 'visitationFrequency4',
                    newValue: selection,
                    oldValue: oldValue
                };

            parms = self.applyOverrideGeneric(parms, parms2);

            self.handleWellbeingChange(parms);
        });

        // visitationFrequency5
        container.queryById('visitationFrequency5').on('change', function (radio, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms2 = {
                    control: radio,
                    propertyName: 'ResponsiblePartyVisitationFrequencyCode',
                    vmFieldName: 'responsiblePartyVisitationFrequencyCode',
                    methodName: 'visitationFrequency5',
                    newValue: selection,
                    oldValue: oldValue
                };

            parms = self.applyOverrideGeneric(parms, parms2);

            self.handleWellbeingChange(parms);
        });

        // visitationFrequency6
        container.queryById('visitationFrequency6').on('change', function (radio, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms2 = {
                    control: radio,
                    propertyName: 'ResponsiblePartyVisitationFrequencyCode',
                    vmFieldName: 'responsiblePartyVisitationFrequencyCode',
                    methodName: 'visitationFrequency6',
                    newValue: selection,
                    oldValue: oldValue
                };

            parms = self.applyOverrideGeneric(parms, parms2);

            self.handleWellbeingChange(parms);
        });
    },
    addItem15ChangeListeners: function (container) {

        var self = this;

        //self.checkController();

        var parms = {
            collectionName: 'item',
            itemCode: 19,
            propertyName: null,
            newValue: null,
            oldValue: null,
            control: null,
            isPageRendered: (pageLoadStatus['Wellbeing'] == 'rendered') ? true : false,
            vmField: null,
            ratingItemId: 'wellbeingItem15Rating',
            runValidations: true,
            dataChanged: true,
            itemName: 'Item15',
            methodName: null,
            ratingDefault: null
        };

        // Question 15
        container.queryById('Question15Applicable').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getItem12B4Concerns(),
            input = {
                control: parms2.control,
                propertyName: 'IsApplicable',
                vmFieldName: 'item15Applicable',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue
            };

            if (parms2.control.itemId == 'applicabilityQuestion15No') {
                input['ratingDefault'] = 'NA';
            }

            parms = self.applyOverrideGeneric(parms, input);

            self.handleItemApplicableChange(parms);
        });

        // motherVisitationFrequency1
        container.queryById('motherVisitationFrequency1').on('change', function (radio, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms2 = {
                    control: radio,
                    collectionName: 'wellbeing',
                    propertyName: 'ResponsiblePartyVisitationFrequencyWithMotherCode',
                    vmFieldName: 'responsiblePartyVisitationFrequencyWithMotherCode',
                    storeId: 'CR_WellBeing_CollectionStore',
                    methodName: 'motherVisitationFrequency1',
                    newValue: selection,
                    oldValue: oldValue
                };

            parms = self.applyOverrideGeneric(parms, parms2);

            self.handleWellbeingChange(parms);
        });

        // motherVisitationFrequency2
        container.queryById('motherVisitationFrequency2').on('change', function (radio, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms2 = {
                    control: radio,
                    collectionName: 'wellbeing',
                    propertyName: 'ResponsiblePartyVisitationFrequencyWithMotherCode',
                    vmFieldName: 'responsiblePartyVisitationFrequencyWithMotherCode',
                    storeId: 'CR_WellBeing_CollectionStore',
                    methodName: 'motherVisitationFrequency2',
                    newValue: selection,
                    oldValue: oldValue
                };

            parms = self.applyOverrideGeneric(parms, parms2);

            self.handleWellbeingChange(parms);
        });

        // motherVisitationFrequency3
        container.queryById('motherVisitationFrequency3').on('change', function (radio, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms2 = {
                    control: radio,
                    collectionName: 'wellbeing',
                    propertyName: 'ResponsiblePartyVisitationFrequencyWithMotherCode',
                    vmFieldName: 'responsiblePartyVisitationFrequencyWithMotherCode',
                    storeId: 'CR_WellBeing_CollectionStore',
                    methodName: 'motherVisitationFrequency3',
                    newValue: selection,
                    oldValue: oldValue
                };

            parms = self.applyOverrideGeneric(parms, parms2);

            self.handleWellbeingChange(parms);
        });

        // motherVisitationFrequency4
        container.queryById('motherVisitationFrequency4').on('change', function (radio, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms2 = {
                    control: radio,
                    collectionName: 'wellbeing',
                    propertyName: 'ResponsiblePartyVisitationFrequencyWithMotherCode',
                    vmFieldName: 'responsiblePartyVisitationFrequencyWithMotherCode',
                    storeId: 'CR_WellBeing_CollectionStore',
                    methodName: 'motherVisitationFrequency4',
                    newValue: selection,
                    oldValue: oldValue
                };

            parms = self.applyOverrideGeneric(parms, parms2);

            self.handleWellbeingChange(parms);
        });

        // motherVisitationFrequency5
        container.queryById('motherVisitationFrequency5').on('change', function (radio, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms2 = {
                    control: radio,
                    collectionName: 'wellbeing',
                    propertyName: 'ResponsiblePartyVisitationFrequencyWithMotherCode',
                    vmFieldName: 'responsiblePartyVisitationFrequencyWithMotherCode',
                    storeId: 'CR_WellBeing_CollectionStore',
                    methodName: 'motherVisitationFrequency5',
                    newValue: selection,
                    oldValue: oldValue
                };

            parms = self.applyOverrideGeneric(parms, parms2);

            self.handleWellbeingChange(parms);
        });

        // motherVisitationFrequency6
        container.queryById('motherVisitationFrequency6').on('change', function (radio, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms2 = {
                    control: radio,
                    collectionName: 'wellbeing',
                    propertyName: 'ResponsiblePartyVisitationFrequencyWithMotherCode',
                    vmFieldName: 'responsiblePartyVisitationFrequencyWithMotherCode',
                    storeId: 'CR_WellBeing_CollectionStore',
                    methodName: 'motherVisitationFrequency6',
                    newValue: selection,
                    oldValue: oldValue
                };

            parms = self.applyOverrideGeneric(parms, parms2);

            self.handleWellbeingChange(parms);
        });

        // motherVisitationFrequency7
        container.queryById('motherVisitationFrequency7').on('change', function (radio, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms2 = {
                    control: radio,
                    collectionName: 'wellbeing',
                    propertyName: 'ResponsiblePartyVisitationFrequencyWithMotherCode',
                    vmFieldName: 'responsiblePartyVisitationFrequencyWithMotherCode',
                    storeId: 'CR_WellBeing_CollectionStore',
                    methodName: 'motherVisitationFrequency7',
                    newValue: selection,
                    oldValue: oldValue
                };

            parms = self.applyOverrideGeneric(parms, parms2);

            self.handleWellbeingChange(parms);
        });

        // fatherVisitationFrequency1
        container.queryById('fatherVisitationFrequency1').on('change', function (radio, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms2 = {
                    control: radio,
                    collectionName: 'wellbeing',
                    propertyName: 'ResponsiblePartyVisitationFrequencyWithFatherCode',
                    vmFieldName: 'responsiblePartyVisitationFrequencyWithFatherCode',
                    storeId: 'CR_WellBeing_CollectionStore',
                    methodName: 'fatherVisitationFrequency1',
                    newValue: selection,
                    oldValue: oldValue
                };

            parms = self.applyOverrideGeneric(parms, parms2);

            self.handleWellbeingChange(parms);
        });

        // fatherVisitationFrequency2
        container.queryById('fatherVisitationFrequency2').on('change', function (radio, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms2 = {
                    control: radio,
                    collectionName: 'wellbeing',
                    propertyName: 'ResponsiblePartyVisitationFrequencyWithFatherCode',
                    vmFieldName: 'responsiblePartyVisitationFrequencyWithFatherCode',
                    storeId: 'CR_WellBeing_CollectionStore',
                    methodName: 'fatherVisitationFrequency2',
                    newValue: selection,
                    oldValue: oldValue
                };

            parms = self.applyOverrideGeneric(parms, parms2);

            self.handleWellbeingChange(parms);
        });

        // fatherVisitationFrequency3
        container.queryById('fatherVisitationFrequency3').on('change', function (radio, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms2 = {
                    control: radio,
                    collectionName: 'wellbeing',
                    propertyName: 'ResponsiblePartyVisitationFrequencyWithFatherCode',
                    vmFieldName: 'responsiblePartyVisitationFrequencyWithFatherCode',
                    storeId: 'CR_WellBeing_CollectionStore',
                    methodName: 'fatherVisitationFrequency3',
                    newValue: selection,
                    oldValue: oldValue
                };

            parms = self.applyOverrideGeneric(parms, parms2);

            self.handleWellbeingChange(parms);
        });

        // fatherVisitationFrequency4
        container.queryById('fatherVisitationFrequency4').on('change', function (radio, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms2 = {
                    control: radio,
                    collectionName: 'wellbeing',
                    propertyName: 'ResponsiblePartyVisitationFrequencyWithFatherCode',
                    vmFieldName: 'responsiblePartyVisitationFrequencyWithFatherCode',
                    storeId: 'CR_WellBeing_CollectionStore',
                    methodName: 'fatherVisitationFrequency4',
                    newValue: selection,
                    oldValue: oldValue
                };

            parms = self.applyOverrideGeneric(parms, parms2);

            self.handleWellbeingChange(parms);
        });

        // fatherVisitationFrequency5
        container.queryById('fatherVisitationFrequency5').on('change', function (radio, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms2 = {
                    control: radio,
                    collectionName: 'wellbeing',
                    propertyName: 'ResponsiblePartyVisitationFrequencyWithFatherCode',
                    vmFieldName: 'responsiblePartyVisitationFrequencyWithFatherCode',
                    storeId: 'CR_WellBeing_CollectionStore',
                    methodName: 'fatherVisitationFrequency5',
                    newValue: selection,
                    oldValue: oldValue
                };

            parms = self.applyOverrideGeneric(parms, parms2);

            self.handleWellbeingChange(parms);
        });

        // fatherVisitationFrequency6
        container.queryById('fatherVisitationFrequency6').on('change', function (radio, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms2 = {
                    control: radio,
                    collectionName: 'wellbeing',
                    propertyName: 'ResponsiblePartyVisitationFrequencyWithFatherCode',
                    vmFieldName: 'responsiblePartyVisitationFrequencyWithFatherCode',
                    storeId: 'CR_WellBeing_CollectionStore',
                    methodName: 'fatherVisitationFrequency6',
                    newValue: selection,
                    oldValue: oldValue
                };

            parms = self.applyOverrideGeneric(parms, parms2);

            self.handleWellbeingChange(parms);
        });

        // fatherVisitationFrequency7
        container.queryById('fatherVisitationFrequency7').on('change', function (radio, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var selection = (newValue) ? radio.inputValue : 0,
                parms2 = {
                    control: radio,
                    collectionName: 'wellbeing',
                    propertyName: 'ResponsiblePartyVisitationFrequencyWithFatherCode',
                    vmFieldName: 'responsiblePartyVisitationFrequencyWithFatherCode',
                    storeId: 'CR_WellBeing_CollectionStore',
                    methodName: 'fatherVisitationFrequency7',
                    newValue: selection,
                    oldValue: oldValue
                };

            parms = self.applyOverrideGeneric(parms, parms2);

            self.handleWellbeingChange(parms);
        });

        // Question 15A2
        container.queryById('question15A2').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            input = {
                control: parms2.control,
                propertyName: 'IsResponsiblePartyVisitationFrequencyWithMotherSufficient',
                vmFieldName: 'isResponsiblePartyVisitationFrequencyWithMotherSufficient',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);
        });

        // Question 15B2
        container.queryById('question15B2').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            input = {
                control: parms2.control,
                propertyName: 'IsResponsiblePartyVisitationFrequencyWithFatherSufficient',
                vmFieldName: 'isResponsiblePartyVisitationFrequencyWithFatherSufficient',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);
        });

        // Question 15C
        container.queryById('question15C').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getResponsiblePartyVisitationQualityWithMotherExplained(),
            input = {
                control: parms2.control,
                propertyName: 'IsResponsiblePartyVisitationQualityWithMotherSufficient',
                vmFieldName: 'isResponsiblePartyVisitationQualityWithMotherSufficient',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);

            if (parms2.control.itemId == 'question15CNo') {
                comments.enable();
            } else {
                var retObj = comments.setValue('');
                comments.disable();
            }
        });

        // Question 15D
        container.queryById('question15D').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getResponsiblePartyVisitationQualityWithFatherExplained(),
            input = {
                control: parms2.control,
                propertyName: 'IsResponsiblePartyVisitationQualityWithFatherSufficient',
                vmFieldName: 'isResponsiblePartyVisitationQualityWithFatherSufficient',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);

            if (parms2.control.itemId == 'question15DNo') {
                comments.enable();
            } else {
                var retObj = comments.setValue('');
                comments.disable();
            }
        });
    },
    addItem16ChangeListeners: function (container) {

        var self = this;

        var parms = {
            collectionName: 'item',
            itemCode: 20,
            propertyName: null,
            newValue: null,
            oldValue: null,
            control: null,
            isPageRendered: (pageLoadStatus['Wellbeing'] == 'rendered') ? true : false,
            vmField: null,
            ratingItemId: 'wellbeingItem16Rating',
            runValidations: true,
            dataChanged: true,
            itemName: 'Item16',
            methodName: null,
            ratingDefault: null
        };

        // Question 16
        container.queryById('Question16Applicable').on('change', function (radioGroup, newValue, oldValue) {

            if (!newValue) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getItem12B4Concerns(),
            input = {
                control: parms2.control,
                propertyName: 'IsApplicable',
                vmFieldName: 'item16Applicable',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue
            };

            if (parms2.control.itemId == 'item16ApplicableNo') {
                input['ratingDefault'] = 'NA';
            }

            parms = self.applyOverrideGeneric(parms, input);

            self.handleItemApplicableChange(parms);
        });

        // Question 16A
        container.queryById('question16A').on('change', function (radioGroup, newValue, oldValue) {
            
            if (isEmptyOrFalse(newValue)){
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            input = {
                control: parms2.control,
                propertyName: 'IsAgencyAssessEducationNeeds',
                vmFieldName: 'isAgencyAssessEducationNeeds',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);
        });

        // Question 16B
        container.queryById('question16B').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            input = {
                control: parms2.control,
                propertyName: 'IsAgencyAddressEducationNeeds',
                vmFieldName: 'isAgencyAddressEducationNeeds',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);
        });
    },
    addItem17ChangeListeners: function (container) {

        var self = this;

        var parms = {
            collectionName: 'item',
            itemCode: 21,
            propertyName: null,
            newValue: null,
            oldValue: null,
            control: null,
            isPageRendered: (pageLoadStatus['Wellbeing'] == 'rendered') ? true : false,
            vmField: null,
            ratingItemId: 'wellbeingItem17Rating',
            runValidations: true,
            dataChanged: true,
            itemName: 'Item17',
            methodName: null,
            ratingDefault: null
        };

        // Question 17
        container.queryById('Question17Applicable').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getItem12B4Concerns(),
            input = {
                control: parms2.control,
                propertyName: 'IsApplicable',
                vmFieldName: 'item17Applicable',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue
            };

            if (parms2.control.itemId == 'item17No') {
                input['ratingDefault'] = 'NA';
            }

            parms = self.applyOverrideGeneric(parms, input);

            self.handleItemApplicableChange(parms);
        });

        // Question 17A1
        container.queryById('question17A1').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            input = {
                control: parms2.control,
                propertyName: 'IsAgencyAssessPhysicalHealthNeeds',
                vmFieldName: 'isAgencyAssessPhysicalHealthNeeds',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);
        });

        // Question 17A2
        container.queryById('item17A2').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            input = {
                control: parms2.control,
                propertyName: 'IsAgencyAssessDentalHealthNeeds',
                vmFieldName: 'isAgencyAssessDentalHealthNeeds',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);
        });

        // Question 17B1
        container.queryById('question17B1').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            input = {
                control: parms2.control,
                propertyName: 'IsFosterOversightMedicationForPhysicalHealtyAppropriate',
                vmFieldName: 'isFosterOversightMedicationForPhysicalHealtyAppropriate',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);
        });

        // Question 17B2
        container.queryById('question17B2').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            input = {
                control: parms2.control,
                propertyName: 'IsAppropriateSerivcesForAllPhysicalHealthNeeds',
                vmFieldName: 'isAppropriateServicesForAllPhysicalHealthNeeds',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);
        });

        // Question 17B3
        container.queryById('question17B3').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            input = {
                control: parms2.control,
                propertyName: 'IsAppropriateServicesForAllDentalNeeds',
                vmFieldName: 'isAppropriateServicesForAllDentalNeeds',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);
        });

        // medicalNeedsCriteria
        container.queryById('medicalNeedsCriteria').on('change', function (cmp, newValue, oldValue, eOpts) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parms = {
                control: cmp,
                dataChanged: true,
                runValidations: true,
                ratingItemId: 'wellbeingItem17Rating',
                itemName: 'Item17',
                pageName: 'Wellbeing',
                groupName: 'FosterFederalCaseManagamentCriteria',
                methodName: 'medicalNeedsCriteria',
                newValue: newValue,
                oldValue: oldValue
            };

            self.handleMedicalNeedsChange(parms);
        });
    },
    addItem18ChangeListeners: function (container) {

        var self = this;

        var parms = {
            collectionName: 'item',
            itemCode: 22,
            propertyName: null,
            newValue: null,
            oldValue: null,
            control: null,
            isPageRendered: (pageLoadStatus['Wellbeing'] == 'rendered') ? true : false,
            vmField: null,
            ratingItemId: 'wellbeingItem18Rating',
            runValidations: true,
            dataChanged: true,
            itemName: 'Item18',
            methodName: null,
            ratingDefault: null
        };

        // Question 18
        container.queryById('Question18Applicable').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getItem12B4Concerns(),
            input = {
                control: parms2.control,
                propertyName: 'IsApplicable',
                vmFieldName: 'item18Applicable',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue
            };

            if (parms2.control.itemId == 'item18ApplicableNo') {
                input['ratingDefault'] = 'NA';
            }

            parms = self.applyOverrideGeneric(parms, input);

            self.handleItemApplicableChange(parms);
        });

        // Question 18A
        container.queryById('question18A').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            input = {
                control: parms2.control,
                propertyName: 'IsAgencyAssessMentalHealthNeeds',
                vmFieldName: 'isAgencyAssessMentalHealthNeeds',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);
        });

        // Question 18B
        container.queryById('question18B').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            input = {
                control: parms2.control,
                propertyName: 'IsFosterOversightMedicationForMentalHealtyAppropriate',
                vmFieldName: 'isFosterOversightMedicationForMentalHealtyAppropriate',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);
        });

        // Question 18C
        container.queryById('question18C').on('change', function (radioGroup, newValue, oldValue) {

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            input = {
                control: parms2.control,
                propertyName: 'IsAppropriateSerivcesForMentalHealthNeeds',
                vmFieldName: 'isAppropriateServicesForMentalHealthNeeds',
                methodName: parms2.control.itemId,
                newValue: selection,
                oldValue: oldValue,
                ratingDefault: null
            };

            parms = self.applyOverrideGeneric(parms, input);

            self.handleWellbeingChange(parms);
        });
    }
});