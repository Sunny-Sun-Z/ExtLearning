﻿Ext.define('App.CaseReview.controller.common.EliminateCasePopUp',
{
    extend: 'Ext.Base',
    requires: [
    'framework.MessageBox',
    'framework.Store',
    'framework.view.Form',
    'framework.form.CheckboxGroup'
    ],
    constructor: function (controller) {
        var self = this;

        var edit = Ext.create('Ext.window.Window', {
            title: 'Eliminate Case',
            layout: 'auto',
            itemId: 'eliminateCaseWindow',
            closeAction : 'hide',
            resizable: true,
            modal: true,
            height: 500,
            scrollable: true,

            items: {
                xtype: 'eliminateCaseUI',
                border: false
            }
        });
        
        var show = function() {
            edit.show();
        }

        var onAfterRender = function () {

            var form = Ext.ComponentQuery.query('#eliminateCaseForm')[0];
            
            var caseStatusCode = getApplicationViewModel().data.caseStatusCode;

            var user = GetLoggedInUser();
            
            //if (window.CaseStatusNRoleSecurity.getCaseStatus() == sr.CaseStatus.ApprovedandFinal || window.CaseStatusNRoleSecurity.getCaseStatus() == sr.CaseStatus.CaseEliminated) {
            if (caseStatusCode == sr.CaseStatus.ApprovedandFinal || caseStatusCode == sr.CaseStatus.CaseEliminated) {

                var itemsTextBoxes = form.query('textfield');

                for (var i = 0; i < itemsTextBoxes.length; i++) {

                    itemsTextBoxes[i].setReadOnly(true);
                }

                var itemscheckboxes = Ext.ComponentQuery.query('checkbox');

                for (var i = 0; i < itemscheckboxes.length; i++) {

                    itemscheckboxes[i].setReadOnly(true);
                }

                var itemsradios = Ext.ComponentQuery.query('radio');
                for (var i = 0; i < itemsradios.length; i++) {
                    itemsradios[i].setReadOnly(true);
                }

                var items = Ext.ComponentQuery.query('button');
                for (var i = 0; i < items.length; i++) {
                    items[i].setHidden(true);
                }
            } else {
                //if(window.CaseStatusNRoleSecurity.getUserRoleinCaseReview(window.userID) == sr.UserRoles.StateSideLeader ||
                //    window.CaseStatusNRoleSecurity.getUserRoleinCaseReview(window.userID) == sr.UserRoles.FederalReviewer)
                if (user.getIsStateAdmin() || user.getIsFedTeamMember())
                {
                    form.query('#eliminateToApproveSave')[0].setHidden(true);
                    form.query('#userReviewContainer')[0].setHidden(false);
                    form.query('#approveNEliminateSave')[0].setHidden(false);
                } else
                {
                    form.query('#eliminateToApproveSave')[0].setHidden(false);
                    form.query('#userReviewContainer')[0].setHidden(true);
                    form.query('#approveNEliminateSave')[0].setHidden(true);
                }
            }
        }

        var onEliminateToApproveSave = function () {
            
            var form = Ext.ComponentQuery.query('#eliminateCaseForm')[0],
                self = this;
            
            if (form.query('#eliminationReason')[0].getValue() == null || Ext.isEmpty(form.query('#eliminationReasonExplained')[0].getValue())) {

                Ext.Msg.alert("Error", "Please enter all fields before saving case elimination");
                window.submitEliminateToApprove = false;

                return false;
            } else {

                //
                // Alert message to indicate that certain fields cannot be changed after saving.
                //
                Ext.Msg.show({
                    title: 'Eliminate Case?',
                    message: 'You are about to eliminate a case. Are you sure you want to continue?',
                    buttons: Ext.Msg.YESNOCANCEL,
                    icon: Ext.Msg.QUESTION,
                    fn: function (btn) {

                        if (btn === 'yes') {

                            edit.close();

                            initializeResultsContainer();

                            self.saveData();
                        }
                    }
                });
                // End of alert
                //
            }
        }

        var onApproveNEliminateSave = function () {
            
            var self = this,
                form = Ext.ComponentQuery.query('#eliminateCaseForm')[0];

            if (form.query('#eliminationReason')[0].getValue() == null || Ext.isEmpty(form.query('#eliminationReasonExplained')[0].getValue())|| form.query('#reviewCheckbox')[0].getValue() == false) {
                Ext.Msg.alert("Error", "Please enter all fields before approving and eliminating the case");
                window.submitToEliminate = false;
                return false;
            } else {

                var parms = ['eliminateCaseRequest', 'eliminateCase'],
                    result = executeQARequest(parms);                

                if (result.ActionAllowed && result.Message == 'Success') {

                    initializeResultsContainer();

                    saveItemId = 'approveNEliminateSave';
                    self.saveData();
                }
                //initializeResultsContainer();

                //this.saveData();
            }
        }

        controller.control({
            '#eliminateCaseLink': {
                click: Ext.ComponentQuery.query('#eliminateCaseLink')[0].getEl().on('click', show)
            },
            '#eliminateCaseUI': {
                afterRender: onAfterRender
            },
            '#reviewCheckbox': {
                change: function (checkbox, newValue, oldValue) {
                    if (newValue) {
                        Ext.ComponentQuery.query('#approveNEliminateSave')[0].setHidden(false);
                    }
                    else {
                        Ext.ComponentQuery.query('#approveNEliminateSave')[0].setHidden(true);
                    }
                }
            },
            '#eliminateToApproveSave': {
                click: onEliminateToApproveSave
            },
            '#approveNEliminateSave': {
                click: onApproveNEliminateSave
            }

        });

        var registerEvents = function () {
            //edit.mon(self.getUnitCancel(), 'click', cancel);
            //edit.mon(self.getUnitSave(), 'click', save);
            edit.mon(edit, 'close', close);
        };

        ///* istanbul ignore else  */
        //if (window.jasmine) {
        //    self.enableDisableHandler = enableDisableHandler;
        //    self.addEdit = addEdit;
        //}
    }
});