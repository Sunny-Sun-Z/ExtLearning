﻿Ext.define('App.CaseReview.controller.common.ChildDemographicGrid',
{
    extend: 'Ext.Base',
    constructor: function (controller) {
        var self = this;
        var grid = controller.getChildDemographicGrid(); 
        var gridAdd = sr.ItemIds.childDemographicGridAddButton;
        var gridEdit = sr.ItemIds.childDemographicGridEditButton;
        var gridDelete = sr.ItemIds.childDemographicGridDeleteButton;
        
        var enableDisableHandler = function () {
            //var selections = grid.getSelectionModel().getSelection();
            //if (selections.length > 0) {
            //    var record = selections[0];
            //    if (record.get('ID_ASSTNCE_GRP_MBRS_SEQ') === 0 || grid.getStore().getCount() === 1)// the one we get sent starts with 0 but if another is added, we make it zero.
            //    {
            //        setTimeout(function () {
            //            gridDelete.disable();
            //            gridEdit.disable();
            //        }, 0);
            //    }
            //}
            //if (grid.getStore().getCount() > 9) {
            //    setTimeout(function () {
            //        gridAdd.disable();
            //    }, 0);
            //}

        };

        /* istanbul ignore next: can only be tested with a gui  */
        var addEdit = function (record) {

            var edit = Ext.create('App.CaseReview.view.common.ChildDemographicHelper');
            Ext.create('App.CaseReview.controller.common.ChildDemographic')
                                .init(grid, record, edit);
        };

        var deleteRecord = function (record) {

            if (grid.getStore().getCount() == 1) {
                Ext.Msg.alert("Warning", "This row cannot be deleted from table G1. Please click on the child's name to edit. ");
            } else {
                if (isRecordAssociated(record)) {
                } else {

                    grid.plugins[0].fireEvent('recorddelete', grid, { record: record });

                    var parms = {};
                    parms['recordType'] = 'Grid';
                    parms['storeId'] = grid.store.storeId;

                    runFacesheetRules(getAppController(), 'childDemographicGrid', parms);

                    var container = getCRSComponent('facesheetCenterPanel');
                    FacesheetFunctions.fireFocusEvent(container);
                }
            }
        }

        var isRecordAssociated = function (childRecord) {
            var childId = childRecord.data.ChildDemographicID;
            var recordAssociated = false;


            // Safety Reports.

            var safetyReportsStore = Ext.StoreMgr.get('CR_SafetyReport_CollectionStore');

            if (safetyReportsStore.count() > 0) {
                safetyReportsStore.each(function(record) {
                    if (record.data.ChildDemographicID == childId) {
                        Ext.Msg.alert("Warning", "Child cannot be deleted because this child is referenced in item 1 table 1A1.");
                        return recordAssociated = true;
                    }
                });
            }

            if (recordAssociated) {
                return recordAssociated;
            }

            // Well being Outcome 1
            var tempOutcome5Store = Ext.data.ChainedStore.create({
                source: 'CR_Outcome_CollectionStore',
                filters: [
                    function (record) {
                        return record.get('OutcomeCode') == 5;
                    }
                ]
            });

            if (tempOutcome5Store.count() > 0) {

                var outCome5ItemCollection = tempOutcome5Store.getAt(0).data.CR_Item_Collection;
                Ext.Array.forEach(outCome5ItemCollection, function (record) {
                    if (record.ItemCode == 14 || record.ItemCode == 17) {
                        if (!Ext.isEmpty(record.CR_ItemParticipant_Collection)) {
                            var itemParticipantCollection = record.CR_ItemParticipant_Collection;
                            Ext.Array.forEach(itemParticipantCollection, function (recordItemParticipant) {
                                if (recordItemParticipant.ParticipantID == childId) {
                                    Ext.Msg.alert("Warning", "Child cannot be deleted because this child is referenced in other items.");
                                    return recordAssociated = true;

                                }
                            });

                        }

                    }
                });

            }
            
            if (recordAssociated) {
                return recordAssociated;
            }


            // Well being Outcome 1
            var tempOutcome6Store = Ext.data.ChainedStore.create({
                source: 'CR_Outcome_CollectionStore',
                filters: [
                    function (record) {
                        return record.get('OutcomeCode') == 6;
                    }
                ]
            });

            if (tempOutcome6Store.count() > 0) {

                var outCome6ItemCollection = tempOutcome6Store.getAt(0).data.CR_Item_Collection;
                Ext.Array.forEach(outCome6ItemCollection, function (record) {
                    if (!Ext.isEmpty(record.CR_ItemParticipant_Collection)) {
                    var itemParticipantCollection = record.CR_ItemParticipant_Collection;
                    Ext.Array.forEach(itemParticipantCollection, function (recordItemParticipant) {
                        if (recordItemParticipant.ParticipantID == childId) {
                            Ext.Msg.alert("Warning", "Participant cannot be deleted because this participant is referenced in case applicability for other items.");
                            return recordAssociated = true;

                        }
                    });

                }
                    
                });

            }




            return recordAssociated;


        }

        controller.assistanceUnitGridEventHandler = Ext.create('framework.controller.GridAddEditDeleteEventHandlers', controller.viewModel,
        {
            'grid': grid,
            'add': gridAdd,
            'edit': gridEdit,
            'del': gridDelete,
            'insertRecord': {}, // blank record
            addAction: addEdit,
            editAction: addEdit,
            deleteAction: deleteRecord
        });

        controller.control({
            '#childDemographicGridAdd': {
                'enable': enableDisableHandler
            },
            '#childDemographicGrid': {
                'selectionchange': enableDisableHandler
            }
        });

        /* istanbul ignore else  */
        if (window.jasmine) {
            self.enableDisableHandler = enableDisableHandler;
            self.addEdit = addEdit;
        }

        var parms = {};
        parms['runValidations'] = true;

        runFacesheetRules(controller, sr.Constants.AllFields, parms);
    }
});