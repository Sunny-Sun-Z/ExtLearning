﻿Ext.define('App.CaseReview.controller.common.ItemApplicable', {
    extend: "Ext.panel.Panel",
    alias: 'widget.itemApplicable',
    store: null,
    getRadios: function (query) {
        return this.query('[isRadio]' + (query || ''));
    },
    getTextArea: function (query) {
        return this.down('[textarea]');
    },
    getCheckboxes: function (query) {
        return this.query('[isCheckbox]' + (query || ''));
    },
    init: function () {
        var self = this;
        self.callParent(arguments);
    },
    constructor: function (configs) {
        var self = this;
        self.callParent(arguments);
        self.store = configs.store;
        self.OutcomeCode = configs.OutcomeCode,
            self.ItemCode = configs.ItemCode,
            self.inputField = configs.inputField;
        self.bindStore = function (store) {
            self.store.un('add', bindAdd);
            self.store.un('remove', bindRemove);
            self.store.un('load', bind);
            self.store.un('clear', bindClear);
            self.store = store;
            self.store.on('add', bindAdd);
            self.store.on('remove', bindRemove);
            self.store.on('load', bind);
            self.store.on('clear', bindClear);
            bind(store);
        };
        var bind = function (store) {
        };

        var bindAdd = function (store, rows) {
            Ext.Array.forEach(rows, function (row) {
                Ext.Array.forEach(self.getRadios(), function (radio) {
                    if (row.get(self.inputField) === radio.inputValue) {
                        radio.setValue(radio.inputValue);
                    }
                });
            });
        };
        var bindRemove = function (store, rows) {
            Ext.Array.forEach(self.getRadios(), function (radio) {
                if (rows[0].get(self.inputField) === radio.inputValue) {
                    radio.setValue(null);
                }
            });
        };
        var bindClear = function () {
            Ext.Array.forEach(self.getRadios(), function (radio) {
                radio.setValue(null);
            });
        };

        self.on('afterrender', function () {
            if (typeof self.store === 'string') {
                self.store = Ext.data.StoreManager.get(self.store);
            }
            if (self.store !== undefined && self.store !== null) {
                self.store.on('add', bindAdd);
                self.store.on('remove', bindRemove);
                self.store.on('load', bind);
                self.store.on('clear', bindClear);
                var tempOutcomeStore = null;
                var tempItemStore = null;
                if (Ext.data.StoreManager.get('CR_Outcome_CollectionStore') != null) {

                    tempOutcomeStore = Ext.data.ChainedStore.create({
                        source: 'CR_Outcome_CollectionStore',
                        filters: [
                            function (record) {
                                return record.get('OutcomeCode') == self.OutcomeCode;
                            }
                        ]
                    });

                    if (tempOutcomeStore.count() != 0) {
                        var tempItemCollection = tempOutcomeStore.getAt(0).data.CR_Item_Collection;
                        var tempItem = null;
                        Ext.Array.forEach(tempItemCollection, function (record) {
                            if (record.ItemCode == self.ItemCode) {
                                tempItem = record;
                            }

                        });
                    }
                }

                if (tempItem != null) {
                    Ext.Array.forEach(self.getRadios(), function (radio) {
                        if (radio.inputValue == tempItem.IsApplicable) {
                            radio.setValue(tempItem.IsApplicable);
                        }

                    });

                    this.down('textarea').setValue(tempItem.Comments);

                    if (!Ext.isEmpty(self.getCheckboxes())) {

                        if (!Ext.isEmpty(tempItem.CR_ItemParticipant_Collection)) {
                            Ext.Array.forEach(self.getCheckboxes(), function (checkbox) {
                                Ext.Array.forEach(tempItem.CR_ItemParticipant_Collection, function (record) {
                                    if (checkbox.inputValue == record.ParticipantID) {
                                        if (record.CodeDescriptionID == 269 && checkbox.itemId.indexOf("Mother") != -1) {
                                            checkbox.setValue(checkbox.inputValue);
                                        } else if (record.CodeDescriptionID == 270 && checkbox.itemId.indexOf("Father") != -1) {
                                            checkbox.setValue(checkbox.inputValue);
                                        }
                                        else if (record.CodeDescriptionID == 271 && checkbox.itemId.indexOf("Child") != -1) {
                                            checkbox.setValue(checkbox.inputValue);
                                        }

                                    }
                                });
                            });
                        }
                    }
                }

                Ext.Array.forEach(self.getRadios(), function (radio) {
                    radio.on('change', function (radioBox, newValue) {

                        if (newValue) {
                            //tempOutcomeStore = Ext.data.ChainedStore.create({
                            //    source: 'CR_Outcome_CollectionStore',
                            //    filters: [
                            //        function (record) {
                            //            return record.get('OutcomeCode') == self.OutcomeCode;
                            //        }
                            //    ]
                            //});

                            //if (tempOutcomeStore.count() == 0) {

                            //    var model = Ext.data.StoreManager.get('CR_Outcome_CollectionStore').add({});
                            //    model[0].set("OutcomeCode", self.OutcomeCode);
                            //    model[0].set("DataState", 0);
                            //    model[0].set("CR_Item_Collection", [{ ItemCode: self.ItemCode, IsApplicable: radio.getSubmitValue(), OutcomeCode: self.OutcomeCode, DataState: 0 }]);
                            //} else {

                            //    var tempItemCollection = tempOutcomeStore.getAt(0).data.CR_Item_Collection;
                            //    if (!Ext.isEmpty(tempItemCollection)) {
                            //        var tempItem = null;
                            //        Ext.Array.forEach(tempItemCollection, function (record) {
                            //            if (record.ItemCode == self.ItemCode) {
                            //                tempItem = record;
                            //            }
                            //            if (!Ext.isEmpty(record.data)) {
                            //                if (record.data.ItemCode == self.ItemCode) {
                            //                    tempItem = record.data;
                            //                }
                            //            }

                            //        });

                            //        if (tempItem != null) {
                            //            tempItem.IsApplicable = radio.getSubmitValue();
                            //        } else {


                            //            // If there is an outcome but no item available, adding item is not reflected in the final graph due to association issues.
                            //            // So a workaround ( which works when there is no outcome and no item) has been provided below.
                            //            // Transfer the outcome and its underlying data in a variable
                            //            // Add the item to the item collection of the outcome 
                            //            // and then drop the outcome from outcome store and add it back again.

                            //            var tempOutcome = tempOutcomeStore.getAt(0);
                            //            tempItemCollection.push({ ItemCode: self.ItemCode, IsApplicable: radio.getSubmitValue(), OutcomeCode: self.OutcomeCode, DataState: 0 });
                            //            var index = Ext.data.StoreManager.get('CR_Outcome_CollectionStore').findExact("ExtId", tempOutcome.id);

                            //            Ext.data.StoreManager.get('CR_Outcome_CollectionStore').removeAt(index);
                            //            var model = Ext.data.StoreManager.get('CR_Outcome_CollectionStore').add({});
                            //            model[0].data = tempOutcome.data;
                            //            model[0].set("CR_Item_Collection", tempItemCollection);
                            //        }
                            //    }
                            //}

                            var item = { ItemCode: self.ItemCode, IsApplicable: radio.getSubmitValue(), OutcomeCode: self.OutcomeCode, DataState: 0 };
                            App.CaseReview.controller.common.CreateOutcomeItem.addItem(item);

                        }

                    });
                });

                this.down('textarea').on('blur', function (item, newValue) {

                    //tempOutcomeStore = Ext.data.ChainedStore.create({
                    //    source: 'CR_Outcome_CollectionStore',
                    //    filters: [
                    //        function (record) {
                    //            return record.get('OutcomeCode') == self.OutcomeCode;
                    //        }
                    //    ]
                    //});

                    //if (tempOutcomeStore.count() == 0) {
                    //    var model = Ext.data.StoreManager.get('CR_Outcome_CollectionStore').add({});
                    //    model[0].set("OutcomeCode", self.OutcomeCode);
                    //    model[0].set("DataState", 0);
                    //    model[0].set("CR_Item_Collection", [{ ItemCode: self.ItemCode, Comments: this.getValue(), OutcomeCode: self.OutcomeCode, DataState: 0 }]);
                    //} else {

                    //    var tempItemCollection = tempOutcomeStore.getAt(0).data.CR_Item_Collection;
                    //    if (!Ext.isEmpty(tempItemCollection)) {
                    //        var tempItem = null;
                    //        Ext.Array.forEach(tempItemCollection, function (record) {
                    //            if (record.ItemCode == self.ItemCode) {
                    //                tempItem = record;
                    //            }
                    //            if (!Ext.isEmpty(record.data)) {
                    //                if (record.data.ItemCode == self.ItemCode) {
                    //                    tempItem = record.data;
                    //                }
                    //            }
                    //        });

                    //        if (tempItem != null) {
                    //            tempItem.Comments = this.getValue();
                    //        } else {
                    //            var tempOutcome = tempOutcomeStore.getAt(0);
                    //            tempItemCollection.push({ ItemCode: self.ItemCode, Comments: this.getValue(), OutcomeCode: self.OutcomeCode, DataState: 0 });
                    //            var index = Ext.data.StoreManager.get('CR_Outcome_CollectionStore').findExact("ExtId", tempOutcome.id);

                    //            Ext.data.StoreManager.get('CR_Outcome_CollectionStore').removeAt(index);
                    //            var model = Ext.data.StoreManager.get('CR_Outcome_CollectionStore').add({});
                    //            model[0].data = tempOutcome.data;
                    //            model[0].set("CR_Item_Collection", tempItemCollection);

                    //        }
                    //    }
                    //}
                    var item = { ItemCode: self.ItemCode, Comments: this.getValue(), OutcomeCode: self.OutcomeCode, DataState: 0 };
                    App.CaseReview.controller.common.CreateOutcomeItem.addItem(item);
                });

                Ext.Array.forEach(self.getCheckboxes(), function (checkbox) {

                    checkbox.on('change', function (item, newValue) {

                        if (!Ext.isEmpty(item.xtype)) {

                            if (item.xtype == "radio")

                                return;
                        }

                        //var codeDescriptionId = 0;

                        //if (item.itemId.indexOf("Mother") != -1) {
                        //    codeDescriptionId = 269;
                        //} else if (item.itemId.indexOf("Father") != -1) {
                        //    codeDescriptionId = 270;
                        //} else if (item.itemId.indexOf("Child") != -1) {
                        //    codeDescriptionId = 271;
                        //}

                        var codeDescriptionId = item.itemId.indexOf("Mother") > -1 ? 269 :
                                                item.itemId.indexOf("Father") > -1 ? 270 :
                                                item.itemId.indexOf("Child") > -1 ? 271 : 0;

                        if (newValue) {

                            var tempItemParticipant = { CodeDescriptionID: codeDescriptionId, ParticipantID: checkbox.inputValue, DataState: 0 };
                            var outcomeCode = getOutcomeCode(self.ItemCode);

                            App.CaseReview.controller.common.CreateOutcomeItem.addItemParticipant(outcomeCode, self.ItemCode,tempItemParticipant);

                            //tempOutcomeStore = Ext.data.ChainedStore.create({
                            //    source: 'CR_Outcome_CollectionStore',
                            //    filters: [
                            //        function (record) {
                            //            return record.get('OutcomeCode') == self.OutcomeCode;
                            //        }
                            //    ]
                            //});

                            //if (tempOutcomeStore.count() == 0) {


                            //    var model = Ext.data.StoreManager.get('CR_Outcome_CollectionStore').add({});
                            //    model[0].set("OutcomeCode", self.OutcomeCode);
                            //    model[0].set("DataState", 0);

                            //    var tempItemParticipant = { CodeDescriptionID: codeDescriptionId, ParticipantID: checkbox.inputValue, DataState: 0 };
                            //    var tempItem = { OutcomeCode: self.OutcomeCode, DataState: 0, ItemCode: self.ItemCode, CR_ItemParticipant_Collection: [tempItemParticipant] };
                            //    model[0].set("CR_Item_Collection", [tempItem]);

                            //} else {


                            //    // If there is an outcome but no item available, adding item is not reflected in the final graph due to association issues.
                            //    // So a workaround ( which works when there is no outcome and no item) has been provided below.
                            //    // Transfer the outcome and its underlying data in a variable
                            //    // Add the item to the item collection of the outcome 
                            //    // and then drop the outcome from outcome store and add it back again.

                            //    var tempOutcome = tempOutcomeStore.getAt(0);
                            //    var index = Ext.data.StoreManager.get('CR_Outcome_CollectionStore').findExact("ExtId", tempOutcome.id);
                            //    Ext.data.StoreManager.get('CR_Outcome_CollectionStore').removeAt(index);


                            //    var tempItemCollection = tempOutcome.data.CR_Item_Collection;

                            //    Ext.Array.forEach(tempItemCollection, function (record) {
                            //        if (record.ItemCode == self.ItemCode) {
                            //            tempItem = record;
                            //            Ext.Array.remove(tempItemCollection, record);
                            //        }
                            //    });

                            //    if (!Ext.isEmpty(tempItem)) {
                            //        var tempItemParticipant = { CodeDescriptionID: codeDescriptionId, ParticipantID: checkbox.inputValue, DataState: 0 };
                            //        if (!Ext.isEmpty(tempItem.CR_ItemParticipant_Collection)) {
                            //            tempItem.CR_ItemParticipant_Collection.push(tempItemParticipant);
                            //        } else {
                            //            tempItem["CR_ItemParticipant_Collection"] = [tempItemParticipant];
                            //        }
                            //    } else {
                            //        var tempItemParticipant = { CodeDescriptionID: codeDescriptionId, ParticipantID: checkbox.inputValue, DataState: 0 };
                            //        tempItem = { OutcomeCode: self.OutcomeCode, DataState: 0, ItemCode: self.ItemCode, CR_ItemParticipant_Collection: [tempItemParticipant] };
                            //    }

                            //    tempItemCollection.push(tempItem);

                            //    var model = Ext.data.StoreManager.get('CR_Outcome_CollectionStore').add({});
                            //    model[0].set("OutcomeCode", self.OutcomeCode);
                            //    model[0].set("DataState", 0);

                            //    model[0].set("CR_Item_Collection", tempItemCollection);

                            //}
                        } else {

                            tempOutcomeStore = Ext.data.ChainedStore.create({
                                source: 'CR_Outcome_CollectionStore',
                                filters: [
                                    function (record) {
                                        return record.get('OutcomeCode') == self.OutcomeCode;
                                    }
                                ]
                            });
                            var tempOutcome = tempOutcomeStore.getAt(0);
                           var tempItemCollection = tempOutcome.data.CR_Item_Collection;

                            Ext.Array.forEach(tempItemCollection, function (record) {
                                if (record.ItemCode == self.ItemCode) {
                                    tempItem = record;
                                }
                            });

                            Ext.Array.forEach(tempItem.CR_ItemParticipant_Collection, function (record) {
                                if (record.ParticipantID == checkbox.inputValue && record.CodeDescriptionID == codeDescriptionId) {
                                    Ext.Array.remove(tempItem.CR_ItemParticipant_Collection, record);
                                }
                            });
                            App.CaseReview.controller.common.CreateOutcomeItem.addItem(tempItem);

                            //tempItemCollection.push(tempItem);

                            //var model = Ext.data.StoreManager.get('CR_Outcome_CollectionStore').add({});
                            //model[0].set("OutcomeCode", self.OutcomeCode);
                            //model[0].set("DataState", 0);

                            //model[0].set("CR_Item_Collection", tempItemCollection);
                        }
                    });
                });


            }
        });
    }
});