﻿Ext.define('App.CaseReview.controller.common.SafetyReport', {
    extend: 'Ext.app.Controller',
    requires: [
        'framework.MessageBox',
        'framework.Store',
        'framework.view.Form',
        'framework.form.CheckboxGroup'
    ],
    refs: [],
    init: function (safetyReportGrid, record, edit) {
        var self = this;
        var form;
        var newSafetyReport_AllegationStoreId = null;
        var isAssignedState = null;
        var isInitiatedState = null;
        var isFaceToFaceContactState = null;
        var close = function () {
            /* istanbul ignore else  -- can't get to this other than by using GUI */
            if (!formSaved) {
                safetyReportGrid.plugins[0].fireEvent('canceledit');
            }
        };

        var cancel = function () {
            edit.close();
        };
        var formSaved = false;

        var save = function () {

            Ext.getBody().mask('<b>Please wait!! Updating Reports Table.... </b>');

            if (!form.isValid()) { return; }
            var prop;
            var dirtyFields = form.getForm().getFieldValues();
            for (prop in dirtyFields) {
                /* istanbul ignore else  -- only for completeness */
                if (dirtyFields.hasOwnProperty(prop)) {
                    record.data[prop] = dirtyFields[prop];
                    if (prop == "IsAssigned") {
                        record.data[prop] = isAssignedState;
                    }
                    if (prop == "IsInitiated") {
                        record.data[prop] = isInitiatedState;
                    }
                    if (prop == "IsFaceToFaceContact") {
                        record.data[prop] = isFaceToFaceContactState;
                    }
                }
            }

            var data = [];
            Ext.data.StoreManager.get(newSafetyReport_AllegationStoreId).each(function (rec) {
                    rec.data["SafetyReportID"] = record.data["SafetyReportID"];
                    data.push(rec.data);
            });

            //Needs to be done for the first record only
            if (!Ext.isEmpty(Ext.data.StoreManager.get("CR_SafetyReport_Allegation_CollectionStore"))) {
                var dataStore = null;
                if (Ext.data.StoreManager.get("CR_SafetyReport_Allegation_CollectionStore").count() > 0) {
                    dataStore = Ext.data.StoreManager.get("CR_SafetyReport_Allegation_CollectionStore").first();
                    if (!Ext.isEmpty(record.data["SafetyReportID"])) {
                        if (dataStore.data["SafetyReportID"] == record.data["SafetyReportID"]) {
                            Ext.data.StoreManager.get("CR_SafetyReport_Allegation_CollectionStore").removeAll(true);
                            Ext.data.StoreManager.get("CR_SafetyReport_Allegation_CollectionStore").setData(Ext.data.StoreManager.get(newSafetyReport_AllegationStoreId).getData());
                        }
                    }
                } else {
                    Ext.data.StoreManager.get("CR_SafetyReport_Allegation_CollectionStore").removeAll(true);
                    Ext.data.StoreManager.get("CR_SafetyReport_Allegation_CollectionStore").setData(Ext.data.StoreManager.get(newSafetyReport_AllegationStoreId).getData());
                }
            }

            record.data["CR_SafetyReport_Allegation_Collection"] = null;
            record.data["CR_SafetyReport_Allegation_Collection"] = data;
            record.commit();
             
            formSaved = true;
            edit.close();
            // enables the buttons
            safetyReportGrid.plugins[0].fireEvent('edit', safetyReportGrid, { record: record });

            var container = getCRSComponent('safetyPanel');
            SafetyFunctions.fireFocusEvent(container);

            Ext.getBody().unmask();
        };

        var onAfterRender = function (e) {
            var items = Ext.ComponentQuery.query('#safetyReportHelperEdit [itemId]');
            var i, itemId;
            var itemsLength = items.length;
            for (i = 0; i < itemsLength; i++) {
                itemId = items[i].itemId;
                self.addRef([{ ref: itemId, selector: '#' + itemId }]);
            }

            var reviewStartDate = Ext.StoreManager.get('CaseReviewStore').getAt(0).data.ReviewStartDate;
            var reviewCompleteDate = Ext.StoreManager.get('CaseReviewStore').getAt(0).data.ReviewCompleted;

            self.getReportDate().setMinValue(reviewStartDate);
            self.getReportDate().setMaxValue(reviewCompleteDate);

            self.getReportDate().on('change', function (datefield, newValue, oldValue, eOpts) {
                if (Ext.isDate(newValue)) {
                    self.getDateAssignedforInvestigationOrAssessment().setMinValue(newValue);
                }
            });

            self.getDateAssignedforInvestigationOrAssessment().on('change', function (datefield, newValue, oldValue, eOpts) {
                if (Ext.isDate(newValue)) {
                    self.getDateInvestigationOrAssessmentInitiated().setMinValue(newValue);
                    self.getDateFaceToFace().setMinValue(newValue);
                }
            });
            
            self.getIsAssigned().on('change',function (checkbox, newValue, oldValue) {
                if (newValue) {
                    self.getDateAssignedforInvestigationOrAssessment().allowBlank = true;
                    self.getDateAssignedforInvestigationOrAssessment().setDisabled(true);
                    self.getDateAssignedforInvestigationOrAssessment().setValue(null);
                    isAssignedState= sr.CheckboxState.Checked;
                } else {
                    self.getDateAssignedforInvestigationOrAssessment().allowBlank = false;
                    self.getDateAssignedforInvestigationOrAssessment().setDisabled(false);
                    isAssignedState = sr.CheckboxState.Unchecked;
                }

                
            });

            //self.getDateInvestigationOrAssessmentInitiated();
            self.getIsInitiated().on('change',function (checkbox, newValue, oldValue) {
                if (newValue) {
                    self.getDateInvestigationOrAssessmentInitiated().allowBlank = true;
                    self.getDateInvestigationOrAssessmentInitiated().setDisabled(true);
                    self.getDateInvestigationOrAssessmentInitiated().setValue(null);
                    isInitiatedState= sr.CheckboxState.Checked;
                } else {
                    self.getDateInvestigationOrAssessmentInitiated().allowBlank = false;
                    self.getDateInvestigationOrAssessmentInitiated().setDisabled(false);
                    isInitiatedState = sr.CheckboxState.Unchecked;
                }
            });

            //self.getDateFaceToFace();
            self.getIsFaceToFaceContact().on('change', function (checkbox, newValue, oldValue) {
                if (newValue) {
                    self.getDateFaceToFace().allowBlank = true;
                    self.getDateFaceToFace().setDisabled(true);
                    self.getDateFaceToFace().setValue(null);
                    isFaceToFaceContactState = sr.CheckboxState.Checked;
                } else {
                    self.getDateFaceToFace().allowBlank = false;
                    self.getDateFaceToFace().setDisabled(false);
                    isFaceToFaceContactState = sr.CheckboxState.Unchecked;
                }
            });


            e.updateLayout({ defer: false, isRoot: true });
            form = Ext.ComponentQuery.query('#safetyReportHelperEdit')[0];
            var shadowRecord = {};
            var prop;
            for (prop in record.data) {
                /* istanbul ignore else  -- only for completeness */
                if (record.data.hasOwnProperty(prop)) {
                    shadowRecord[prop] = record.data[prop];
                }
                if (prop == "IsAssigned") {
                    if (record.data[prop] == 2) {
                        isAssignedState = sr.CheckboxState.Unchecked;
                    }

                }
                if (prop == "IsInitiated") {
                    if (record.data[prop] == 2) {
                        isInitiatedState = sr.CheckboxState.Unchecked;
                    }

                }
                if (prop == "IsFaceToFaceContact") {
                    if (record.data[prop] == 2) {
                        isFaceToFaceContactState = sr.CheckboxState.Unchecked;
                    }
                }
            }
            form.getForm().setValues(shadowRecord);

            var safetyReport_AllegationRecords = {};

            if (!Ext.isEmpty(shadowRecord['CR_SafetyReport_Allegation_Collection'])) {
                if (shadowRecord['CR_SafetyReport_Allegation_Collection'].length > 0) {
                    for (var iCount = 0; iCount < shadowRecord['CR_SafetyReport_Allegation_Collection'].length; iCount++) {
                        shadowRecord['CR_SafetyReport_Allegation_Collection'][iCount]["ExtId"] = null;
                    }
                }
                safetyReport_AllegationRecords = shadowRecord['CR_SafetyReport_Allegation_Collection'];
            }

            newSafetyReport_AllegationStoreId = record.data["ExtId"];


            var newStore = new Ext.data.Store({
                model: 'App.model.CR_SafetyReport_Allegation'
                , data: safetyReport_AllegationRecords
                , storeId: newSafetyReport_AllegationStoreId
            });

            self.getCR_SafetyReport_Allegation_Collection().bindStore(newStore);
            
            registerEvents();
        };

        var registerEvents = function () {
            edit.mon(self.getUnitCancel(), 'click', cancel);
            edit.mon(self.getUnitSave(), 'click', save);
            edit.mon(edit, 'close', close);
        };

        edit.mon(edit, 'afterrender', onAfterRender);
        edit.show({});

        /* istanbul ignore else  */
        if (window.jasmine) {
            self.close = close;
            self.cancel = cancel;
            self.save = save;
            self.onAfterRender = onAfterRender;
        }
    }
});