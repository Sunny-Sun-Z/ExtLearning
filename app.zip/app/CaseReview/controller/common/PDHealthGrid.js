﻿Ext.define('App.CaseReview.controller.common.PDHealthGrid',
{
    extend: 'Ext.Base',
    constructor: function (controller) {
        var self = this;
        var grid = controller.getPdHealthGrid();
        var gridAdd = sr.ItemIds.pdHealthGridAddButton;
        var gridEdit = sr.ItemIds.pdHealthGridEditButton;
        var gridDelete = sr.ItemIds.pdHealthGridDeleteButton;

        var enableDisableHandler = function () {
            //var selections = grid.getSelectionModel().getSelection();
            //if (selections.length > 0) {
            //    var record = selections[0];
            //    if (record.get('ID_ASSTNCE_GRP_MBRS_SEQ') === 0 || grid.getStore().getCount() === 1)// the one we get sent starts with 0 but if another is added, we make it zero.
            //    {
            //        setTimeout(function () {
            //            gridDelete.disable();
            //            gridEdit.disable();
            //        }, 0);
            //    }
            //}
            //if (grid.getStore().getCount() > 9) {
            //    setTimeout(function () {
            //        gridAdd.disable();
            //    }, 0);
            //}

        };

        /* istanbul ignore next: can only be tested with a gui  */
        var addEdit = function (record) {

            var edit = Ext.create('App.CaseReview.view.common.PDHealthHelper');
            Ext.create('App.CaseReview.controller.common.PDHealth')
                                .init(grid, record, edit);
        };

        var deleteRecord = function () {

            grid.plugins[0].fireEvent('recorddelete');

            var parms = {};
            parms['recordType'] = 'Grid';
            parms['storeId'] = grid.store.storeId;
            parms['runValidations'] = true;

            runWellbeingRules(getAppController(), 'pdHealthGrid', parms);
        };

        controller.healthGridEventHandler = Ext.create('framework.controller.GridAddEditDeleteEventHandlers', controller.viewModel,
        {
            'grid': grid,
            'add': gridAdd,
            'edit': gridEdit,
            'del': gridDelete,
            'insertRecord': {}, // blank record
            addAction: addEdit,
            editAction: addEdit,
            deleteAction: deleteRecord
        });

        controller.control({
            '#pdHealthGridAddButton': {
                'enable': enableDisableHandler
            },
            '#pdHealthGrid': {
                'selectionchange': enableDisableHandler
            }
        });

        /* istanbul ignore else  */
        if (window.jasmine) {
            self.enableDisableHandler = enableDisableHandler;
            self.addEdit = addEdit;
        }
    }
});