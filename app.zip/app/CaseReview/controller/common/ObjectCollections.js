﻿var addCRSObject = function (obj) {

    var outcomeObj, item;

    var itemCode = Ext.isEmpty(obj.objValue.itemCode) ? obj.objValue.ItemCode : obj.objValue.itemCode;
    var outcomeCode = getOutcomeCode(itemCode);
    var caseReview = chainedStore('CaseReviewStore');

    var getGraphObjects = function () {

        caseReview = chainedStore('CaseReviewStore');

        outcomeObj = getReviewOutcome();

        item = getReviewItem();
    };

    var getReviewOutcome = function () {

        var result;

        if (caseReview.count() > 0) {

            result = caseReview.getAt(0).data.CR_Outcome_Collection.filter(function (outcome) {

                return outcome.OutcomeCode == outcomeCode;
            });
            //
            // Create new outcome if needed
            //
            if (result.length == 0) {

                result = addReviewOutcome();
            }
        }

        return result;
    }

    var addReviewOutcome = function () {

        var result = [];

        var newOutcome = Ext.data.StoreManager.get('CR_Outcome_CollectionStore').add({});
        var reviewItem = { ItemCode: itemCode, OutcomeCode: outcomeCode, DataState: 0, CR_Note_Collection: [obj.objValue] };

        newOutcome[0].set("OutcomeCode", outcomeCode);
        newOutcome[0].set("DataState", 0);
        newOutcome[0].set("CR_Item_Collection", [reviewItem]);

        result[0] = newOutcome[0].data;

        return result;
    }

    var getReviewItem = function () {

        var result;

        if (Ext.isEmpty(outcomeObj)) {

            outcomeObj = getReviewOutcome();
        }

        result = outcomeObj[0].CR_Item_Collection.filter(function (itemObj) {

            return (itemObj.ItemCode == itemCode &&
                    (itemObj.ItemID == obj.objValue.ItemID || (Ext.isEmpty(itemObj.ItemID) && obj.objValue.ItemID == 0)));
        });
        //
        // Create new item if needed
        //
        if (result.length == 0) {

            result = addReviewItem();
        }

        return result;
    }

    var addReviewItem = function () {


        var outcomeId = Ext.isEmpty(outcomeObj[0].OutcomeID) ? outcomeObj[0].data.OutcomeID : outcomeObj[0].OutcomeID;

        var newItem = { ItemCode: itemCode, ItemID: obj.objValue.ItemID, OutcomeID: outcomeId, OutcomeCode: outcomeCode, DataState: 0, CR_Note_Collection: [obj.objValue] };

        updateItem(newItem);

        getGraphObjects();

        return item;
    }

    var addNoteCollection = function () {

        var result = [];

        var newItem = Ext.data.StoreManager.get('CR_Item_CollectionStore').add({});
        
        newItem[0].set("OutcomeCode", item[0].OutcomeCode);
        newItem[0].set("ItemCode", item[0].ItemCode);
        newItem[0].set("DataState", 0);
        newItem[0].set("StatusCode", item[0].StatusCode);
        newItem[0].set("IsApplicable", Ext.isEmpty(item[0].IsApplicable) ? 0 : item[0].IsApplicable);
        newItem[0].set("CR_Note_Collection", [obj.objValue]);

        updateItem(newItem[0].data);

        getGraphObjects();

        result[0] = newItem[0].data;

        return result;
    }

    switch (obj.objectType) {

        case 'note':

            if (!(Ext.isEmpty(outcomeCode))) {

                getGraphObjects();

                if (outcomeObj.length > 0) {

                    // Create item if needed                     
                    if (item.length == 0) {

                        item = addReviewItem();

                    } else {
                        // Update DataState of Outcome and CaseReview if item has changed.

                        if (item[0].DataState == 0) {

                            outcomeObj[0].DataState = 0;

                            caseReview.getAt(0).data.DataState = 0;
                        }
                    }

                    if (item.length > 0) {

                        var noteColl = item[0].CR_Note_Collection;
                        var newItem;

                        if (Ext.isEmpty(noteColl)) {

                            // Create Note Collection
                            newItem = addNoteCollection();

                            noteColl = newItem[0].CR_Note_Collection;
                        }

                        var filteredColl = noteColl.filter(function (noteObj) {

                            return (noteObj.NoteID == obj.objValue.NoteID && noteObj.NoteID > 0) ||
                                   noteObj.ExtId == obj.objValue.ExtId;
                        });

                        if (filteredColl.length == 0) {

                            obj.objValue.ItemID = noteColl.length == 0 ? 0 : noteColl[0].ItemID;

                            noteColl.push(obj.objValue);

                            item[0].CR_Note_Collection = noteColl;
                        } else {

                            if (Ext.isEmpty(item[0].CR_Note_Collection)) {

                                if (!Ext.isEmpty(newItem)) {

                                    item[0].CR_Note_Collection = newItem[0].CR_Note_Collection;
                                }
                            }
                        }
                    }

                } else {
                    // Create new Outcome, Item Collection and Note Collection

                    var newOutcome = addReviewOutcome();
                }
            }

            break;

        case 'item':

            var outcomeCode = Ext.isEmpty(obj.outcomeCode) ? obj.OutcomeCode : obj.outcomeCode;
            var itemCode = Ext.isEmpty(obj.objValue.itemCode) ? obj.objValue.ItemCode : obj.objValue.itemCode;

            if (!(Ext.isEmpty(outcomeCode))) {
                var inputObj = { storeId: 'CR_Outcome_CollectionStore', alternateId: 'OutcomeCode', alternateIdValue: outcomeCode };

                var store = getObjectStore(inputObj);

                if (store.count() > 0) {
                    // Create item if needed    
                    item = store.getAt(0).data.CR_Item_Collection.filter(function (itemObj) {
                        return (itemObj.ItemCode == itemCode);
                    });

                    if (item.length == 0) {

                        var outcomeId = store.getAt(0).data.OutcomeID;
                        var newItem = { ItemCode: itemCode, ItemID: 0, OutcomeID: outcomeId, OutcomeCode: outcomeCode, DataState: 0, CR_Note_Collection: [] };

                        updateItem(newItem);

                        store = getObjectStore(inputObj);

                        item = store.getAt(0).data.CR_Item_Collection.filter(function (itemObj) {
                            return (itemObj.ItemCode == itemCode && itemObj.ItemID == newItem.ItemID);
                        });
                    } else {
                        // Update item with rating info
                        if (!Ext.isEmpty(obj.objValue.ratingOverride)) {

                            item[0].isRatingOverride = obj.objValue.ratingOverride.overrideInd;
                            item[0].OverriddenRatingCode = obj.objValue.ratingOverride.overrideRating;

                            updateItem(item[0]);
                        }
                    }

                } else {

                    // Create new Outcome, Item Collection

                    var newOutcome = addReviewOutcome();
                }
            }

            break;

        case 'itemParticipant':

            var tempItem;

            if (!(Ext.isEmpty(obj.outcomeCode))) {
                var inputObj = { storeId: 'CR_Outcome_CollectionStore', alternateId: 'OutcomeCode', alternateIdValue: obj.outcomeCode };

                var store = getObjectStore(inputObj);

                if (store.count() > 0) {

                    // Update item participant                   
                    var tempItemColl = store.getAt(0).data.CR_Item_Collection;

                    var tempItem = tempItemColl.filter(function (item) {
                        return item.ItemCode == obj.itemCode;
                    });

                    if (!Ext.isEmpty(tempItem)) {

                        if (!Ext.isEmpty(tempItem.CR_ItemParticipant_Collection)) {
                            tempItem.CR_ItemParticipant_Collection.push(obj.objValue);
                        } else {
                            tempItem["CR_ItemParticipant_Collection"] = [obj.objValue];
                        }
                    } else {

                        tempItem = { OutcomeCode: obj.outcomeCode, DataState: 0, ItemCode: obj.itemCode, CR_ItemParticipant_Collection: [obj.objValue] };
                    }

                } else {

                    // Add new participant
                    tempItem = { OutcomeCode: obj.outcomeCode, DataState: 0, ItemCode: obj.itemCode, CR_ItemParticipant_Collection: [obj.objValue] };
                }

                updateItem(tempItem);
            }

            break;

        default:

            break;
    }
}
var getObjectStore = function (obj) {

    var store;

    if (obj.containerType == 'graph') {

        store = Ext.data.StoreManager.lookup('CaseReviewStore');

        return store;
    }

    store = Ext.data.ChainedStore.create({
        source: obj.storeId,
        filters: [
            function (record) {
                return record.get(obj.alternateId) == obj.alternateIdValue;
            }
        ]
    });

    return store;
}