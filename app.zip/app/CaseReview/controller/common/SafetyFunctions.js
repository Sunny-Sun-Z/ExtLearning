﻿Ext.define('App.casereview.controller.common.SafetyFunctions', {
    extend: 'Ext.Base',
    singleton: true,
    saveEnabled: false,
    fireFocusEvent: function (container) {
        
        if (this.saveEnabled) {
            return;
        }

        container.ownerCt.fireEvent('focus', container.ownerCt, null);
    },
    alternateClassName: 'SafetyFunctions',
    handleItemApplicableChange: function (parmsIn) {

        var item = getItem(parmsIn.itemCode, parmsIn.outcomeCode);
                    
        if (!(item == undefined)) {

            item.IsApplicable = parmsIn.control.inputValue;
            updateItem(item);

            if (parmsIn.outcomeCode == 1) {
                if (parmsIn.control.inputValue == 1) {
                    processItem1YesChange(parmsIn.control);
                } else {
                    processItem1NoChange(parmsIn.control);
                }                
            }

            if (parmsIn.outcomeCode == 2) {

                var parms = {
                    itemName: 'Item2',
                    pageName: 'Safety',
                    ratingId: 'safetyItem2Rating',
                    dataChanged: true,
                    section: null,
                    validationMethod: 'ValidateItem2',
                    ratingDefault: null,
                    preProcessMethod: null
                };

                if (parmsIn.control.inputValue == 1) {

                    parms.section = 'item2CaseApplicableYes';
                    processApplicabilityChange(parmsIn.control, parms);
                }

                if (parmsIn.control.inputValue == 2) {

                    parms.section = 'item2CaseApplicableNo';
                    parms.ratingDefault = 'NA';
                    parms.preProcessMethod = 'processSafetyNotApplicable';

                    processApplicabilityChange(parmsIn.control, parms);
                }
            }
        }
    },
    handleItem3D1Afterrender: function (cmp) {

        var self = this;

        //self.checkController();

        var checkedItem = cmp.items.items.filter(function (checkBox) {

            return checkBox.checked;
        });

        if (checkedItem && checkedItem.length > 0) {

            if (checkedItem[0].inputValue == 86) {

                self.item3D1Incident1Disable();
            }

            if (checkedItem[0].inputValue == 87) {

                self.item3D1Incident2Disable();
            }
        }
    },
    item3D1Incident1Disable: function(){

        var self = this;

        //self.checkController();

        if (getAppController().getIncident1().checked == true) {

            if (!getAppController().getIncident2().isDisabled()) {
                getAppController().getIncident2().setDisabled(true);
                getAppController().getIncident2().setValue(false);
            }

            if (!getAppController().getIncident3().isDisabled()) {
                getAppController().getIncident3().setDisabled(true);
                getAppController().getIncident3().setValue(false);
            }

            if (!getAppController().getIncident4().isDisabled()) {
                getAppController().getIncident4().setDisabled(true);
                getAppController().getIncident4().setValue(false);
            }

            if (!getAppController().getIncident5().isDisabled()) {
                getAppController().getIncident5().setDisabled(true);
                getAppController().getIncident5().setValue(false);
            }

            if (!getAppController().getIncident6().isDisabled()) {
                getAppController().getIncident6().setDisabled(true);
                getAppController().getIncident6().setValue(false);
            }

            if (getAppController().getIncident6().isDisabled()) {
                getAppController().getOtherSafetyConcerns().setValue(null);
                getAppController().getOtherSafetyConcerns().disable();
            }
        } else {
            getAppController().getIncident2().setDisabled(false);
            getAppController().getIncident3().setDisabled(false);
            getAppController().getIncident4().setDisabled(false);
            getAppController().getIncident5().setDisabled(false);
            getAppController().getIncident6().setDisabled(false);
        }
    },
    item3D1Incident2Disable: function () {

        var self = this;

        //self.checkController();

        if (getAppController().getIncident2().checked == true) {

            if (!getAppController().getIncident1().isDisabled()) {
                getAppController().getIncident1().setDisabled(true);
                getAppController().getIncident1().setValue(false);
            }

            if (!getAppController().getIncident3().isDisabled()) {
                getAppController().getIncident3().setDisabled(true);
                getAppController().getIncident3().setValue(false);
            }

            if (!getAppController().getIncident4().isDisabled()) {
                getAppController().getIncident4().setDisabled(true);
                getAppController().getIncident4().setValue(false);
            }

            if (!getAppController().getIncident5().isDisabled()) {
                getAppController().getIncident5().setDisabled(true);
                getAppController().getIncident5().setValue(false);
            }

            if (!getAppController().getIncident6().isDisabled()) {
                getAppController().getIncident6().setDisabled(true);
                getAppController().getIncident6().setValue(false);
            }

            if (getAppController().getIncident6().isDisabled()) {
                getAppController().getOtherSafetyConcerns().setValue(null);
                getAppController().getOtherSafetyConcerns().disable();
            }
        } else {
            getAppController().getIncident1().setDisabled(false);
            getAppController().getIncident3().setDisabled(false);
            getAppController().getIncident4().setDisabled(false);
            getAppController().getIncident5().setDisabled(false);
            getAppController().getIncident6().setDisabled(false);
        }
    },
    handleItem3E1Afterrender: function (cmp) {

        var self = this;

        //self.checkController();

        var checkedItem = cmp.items.items.filter(function (checkBox) {

            return checkBox.checked;
        });

        if (checkedItem && checkedItem.length > 0) {

            if (checkedItem[0].inputValue == 92) {

                self.item3E1SafetyConcern1Disable();
            }

            if (checkedItem[0].inputValue == 93) {

                self.item3E1SafetyConcern2Disable();
            }
        }
    },
    item3E1SafetyConcern1Disable: function(){

        var self = this,
            compObj;

        //self.checkController();

        compObj = getAppController();

        if (compObj.getSafetyConcern1().checked == true) {

            if (!compObj.getSafetyConcern2().isDisabled()) {
                compObj.getSafetyConcern2().setDisabled(true);
                compObj.getSafetyConcern2().setValue(false);
            }

            if (!compObj.getSafetyConcern3().isDisabled()) {
                compObj.getSafetyConcern3().setDisabled(true);
                compObj.getSafetyConcern3().setValue(false);
            }

            if (!compObj.getSafetyConcern4().isDisabled()) {
                compObj.getSafetyConcern4().setDisabled(true);
                compObj.getSafetyConcern4().setValue(false);
            }

            if (!compObj.getSafetyConcern5().isDisabled()) {
                compObj.getSafetyConcern5().setDisabled(true);
                compObj.getSafetyConcern5().setValue(false);
            }

            if (!compObj.getSafetyConcern6().isDisabled()) {
                compObj.getSafetyConcern6().setDisabled(true);
                compObj.getSafetyConcern6().setValue(false);
            }

            if (compObj.getSafetyConcern6().isDisabled()) {
                compObj.getFosterSafetyConcerns().setValue(null);
                compObj.getFosterSafetyConcerns().disable();
            }
        } else {

            var caseType = getCaseType();

            if (!(caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health')) {

                compObj.getSafetyConcern1().setDisabled(true);
                compObj.getSafetyConcern1().setValue(false);
            }

            compObj.getSafetyConcern3().setDisabled(false);
            compObj.getSafetyConcern4().setDisabled(false);
            compObj.getSafetyConcern5().setDisabled(false);
            compObj.getSafetyConcern6().setDisabled(false);
        }
    },
    item3E1SafetyConcern2Disable: function () {

        var self = this,
            compObj;

        //self.checkController();

        compObj = getAppController();

        if (compObj.getSafetyConcern2().checked == true) {

            if (!compObj.getSafetyConcern1().isDisabled()) {
                compObj.getSafetyConcern1().setDisabled(true);
                compObj.getSafetyConcern1().setValue(false);
            }

            if (!compObj.getSafetyConcern3().isDisabled()) {
                compObj.getSafetyConcern3().setDisabled(true);
                compObj.getSafetyConcern3().setValue(false);
            }

            if (!compObj.getSafetyConcern4().isDisabled()) {
                compObj.getSafetyConcern4().setDisabled(true);
                compObj.getSafetyConcern4().setValue(false);
            }

            if (!compObj.getSafetyConcern5().isDisabled()) {
                compObj.getSafetyConcern5().setDisabled(true);
                compObj.getSafetyConcern5().setValue(false);
            }

            if (!compObj.getSafetyConcern6().isDisabled()) {
                compObj.getSafetyConcern6().setDisabled(true);
                compObj.getSafetyConcern6().setValue(false);
            }

            if (compObj.getSafetyConcern6().isDisabled()) {
                compObj.getFosterSafetyConcerns().setValue(null);
                compObj.getFosterSafetyConcerns().disable();
            }
        } else {
            var caseType = getCaseType();

            if (!(caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health')) {

                compObj.getSafetyConcern1().setDisabled(true);
                compObj.getSafetyConcern1().setValue(false);
            }

            compObj.getSafetyConcern3().setDisabled(false);
            compObj.getSafetyConcern4().setDisabled(false);
            compObj.getSafetyConcern5().setDisabled(false);
            compObj.getSafetyConcern6().setDisabled(false);
        }
    },
    handleItem3F1Afterrender: function (cmp) {

        var self = this;

        //self.checkController();

        var checkedItem = cmp.items.items.filter(function (checkBox) {

            return checkBox.checked;
        });

        if (checkedItem && checkedItem.length > 0) {

            if (checkedItem[0].inputValue == 98) {

                self.item3F1PlacementConcern1Disable();
            }

            if (checkedItem[0].inputValue == 99) {

                self.item3F1PlacementConcern2Disable();
            }
        }
    },
    item3F1PlacementConcern1Disable: function () {

        var self = this,
            compObj;

        //self.checkController();

        compObj = getAppController();

        if (compObj.getPlacementConcern1().checked == true) {

            if (!compObj.getPlacementConcern2().isDisabled()) {
                compObj.getPlacementConcern2().setDisabled(true);
                compObj.getPlacementConcern2().setValue(false);
            }

            if (!compObj.getPlacementConcern3().isDisabled()) {
                compObj.getPlacementConcern3().setDisabled(true);
                compObj.getPlacementConcern3().setValue(false);
            }

            if (!compObj.getPlacementConcern4().isDisabled()) {
                compObj.getPlacementConcern4().setDisabled(true);
                compObj.getPlacementConcern4().setValue(false);
            }

            if (!compObj.getPlacementConcern5().isDisabled()) {
                compObj.getPlacementConcern5().setDisabled(true);
                compObj.getPlacementConcern5().setValue(false);
            }

            if (!compObj.getPlacementConcern6().isDisabled()) {
                compObj.getPlacementConcern6().setDisabled(true);
                compObj.getPlacementConcern6().setValue(false);
            }


            if (!compObj.getPlacementConcern7().isDisabled()) {
                compObj.getPlacementConcern7().setDisabled(true);
                compObj.getPlacementConcern7().setValue(false);
            }

            if (compObj.getPlacementConcern7().isDisabled()) {
                compObj.getOtherPlacementConcerns().setValue(null);
                compObj.getOtherPlacementConcerns().disable();
            }
        } else {
            var caseType = getCaseType();

            if (!(caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health')) {

                compObj.getPlacementConcern1().setDisabled(true);
                compObj.getPlacementConcern1().setValue(false);
            }

            compObj.getPlacementConcern3().setDisabled(false);
            compObj.getPlacementConcern4().setDisabled(false);
            compObj.getPlacementConcern5().setDisabled(false);
            compObj.getPlacementConcern6().setDisabled(false);
            compObj.getPlacementConcern7().setDisabled(false);
        }
    },
    item3F1PlacementConcern2Disable: function () {

        var self = this,
            compObj;

        //self.checkController();

        compObj = getAppController();

        if (compObj.getPlacementConcern2().checked == true) {

            if (!compObj.getPlacementConcern1().isDisabled()) {
                compObj.getPlacementConcern1().setDisabled(true);
                compObj.getPlacementConcern1().setValue(false);
            }

            if (!compObj.getPlacementConcern3().isDisabled()) {
                compObj.getPlacementConcern3().setDisabled(true);
                compObj.getPlacementConcern3().setValue(false);
            }

            if (!compObj.getPlacementConcern4().isDisabled()) {
                compObj.getPlacementConcern4().setDisabled(true);
                compObj.getPlacementConcern4().setValue(false);
            }

            if (!compObj.getPlacementConcern5().isDisabled()) {
                compObj.getPlacementConcern5().setDisabled(true);
                compObj.getPlacementConcern5().setValue(false);
            }

            if (!compObj.getPlacementConcern6().isDisabled()) {
                compObj.getPlacementConcern6().setDisabled(true);
                compObj.getPlacementConcern6().setValue(false);
            }


            if (!compObj.getPlacementConcern7().isDisabled()) {
                compObj.getPlacementConcern7().setDisabled(true);
                compObj.getPlacementConcern7().setValue(false);
            }

            if (compObj.getPlacementConcern7().isDisabled()) {
                compObj.getOtherPlacementConcerns().setValue(null);
                compObj.getOtherPlacementConcerns().disable();
            }
        } else {
            var caseType = getCaseType();

            if (!(caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health')) {

                compObj.getPlacementConcern1().setDisabled(true);
                compObj.getPlacementConcern1().setValue(false);
            }

            compObj.getPlacementConcern3().setDisabled(false);
            compObj.getPlacementConcern4().setDisabled(false);
            compObj.getPlacementConcern5().setDisabled(false);
            compObj.getPlacementConcern6().setDisabled(false);
            compObj.getPlacementConcern7().setDisabled(false);
        }
    },
    handleSafetyPanelBeforerender: function () {
        
        //this.checkController();

        // 
        // Create viewModel
        //
        var vModel = createViewModel('safety');

        window.safetyViewModel = vModel;
    },
    handleSafetyPanelAfterrender: function () {

        //this.checkController();

        pageLoadStatus['Safety'] = 'rendered';
        //
        // Run validations for page for all items once on load
        //  
        var parms = {
            runValidations: true,
            dataChanged: false
        };

        runSafetyRules(getAppController(), sr.Constants.AllFields, sr.Constants.AllFields, parms);

        Ext.resumeLayouts(true);
    },
    handleSafetyOutcome1RatingAfterrender: function () {

        //this.checkController();

        getAppController().getSafetyOutcome1Rating().getOutcomeRating(1);
    },
    handleSafetyOutcome2RatingAfterrender: function () {

        //this.checkController();

        getAppController().getSafetyOutcome2Rating().getOutcomeRating(2);
    },
    handleSafetyItem1RatingAfterrender: function () {

        //this.checkController();

        getAppController().getSafetyItem1Rating().getItemRating();
    },
    handleSafetyItem2RatingAfterrender: function () {

        //this.checkController();

        getAppController().getSafetyItem2Rating().getItemRating();
    },
    handleSafetyItem3RatingAfterrender: function () {

        //this.checkController();

        getAppController().getSafetyItem3Rating().getItemRating();
    },
    handleItem1NoAfterrender: function () {

        if (!(isCaseApplicable(2, 1))) {

            // Disable section for Item 1
            disableContainerItems(['safetyReportGrid', 'item1Questions']);

            setDisabledFieldValuesInContainer(['safetyReportGrid', 'item1Questions']);
        }
    },
    handleSafetyBlur: function (parmsIn) {

        var dataParms = {
            collectionName: parmsIn.collectionName,
            propertyName: parmsIn.propertyName,
            itemCode: parmsIn.itemCode
        },
        savedValue = getSavedPropertyValue(dataParms),
        newValue = parmsIn.control.getValue();

        appDataEvent.safety.changeByUserAction = isDataChangedByUser(parmsIn.control, parmsIn.control.getValue(), savedValue);

        if (!appDataEvent.safety.changeByUserAction) {

            return;
        }

        if (pageLoadStatus['Safety'] == 'rendered') {

            if (newValue) {

                var fields = [],
                    vmFields = [],
                    vmField = {},
                    field = {};

                vmField[parmsIn.vmFieldName] = newValue;
                field[parmsIn.propertyName] = newValue;

                fields.push(field);
                fields.push({ 'DataState': 0 });

                vmFields.push(vmField);

                var parms = {
                    currentVal: newValue,
                    storeId: parmsIn.storeId,
                    fields: fields,
                    vmFields: vmFields,
                    control: parmsIn.control,
                    runValidations: parmsIn.runValidations,
                    itemCode: parmsIn.control.ownerCt.ownerCt.ItemCode,
                    outcomeCode: parmsIn.control.ownerCt.ownerCt.OutcomeCode,
                    dataChanged: parmsIn.dataChanged
                };

                parms = getStatusParms(parms, parmsIn.ratingItemId);

                initValidations(parmsIn.itemName);

                //this.checkController();

                runSafetyRules(getAppController(), parmsIn.methodName, null, parms);
            }
        }
    },
    handleQuestion1Change: function (parmsIn) {
        
        var dataParms = {
            collectionName: parmsIn.collectionName,
            propertyName: parmsIn.propertyName,
            value: parmsIn.newValue,
            dataType: parmsIn.dataType
        },
        self = this;

        var savedValue = getSavedPropertyValue(dataParms);

        var safetyParms = {
            newValue: parmsIn.newValue,
            oldValue: parmsIn.oldValue,
            savedValue: savedValue
        };

        appDataEvent.safety.changeByUserAction = true;

        if (pageLoadStatus['Safety'] == 'rendered') {

            //this.checkController();

            var safetyStore = chainedStore(parmsIn.reportStoreId),
                noTableRows = safetyStore.count(),
                inputVal = parmsIn.newValue < 0 ? 0 :
                           parmsIn.newValue > noTableRows ? noTableRows : parmsIn.newValue,
                fields = [],
                vmFields = [],
                vmField = {},
                field = {};

            vmField[parmsIn.vmFieldName] = inputVal;
            field[parmsIn.propertyName] = inputVal;

            fields.push(field);
            fields.push({ 'DataState': 0 });

            vmFields.push(vmField);

            var parms = {
                currentVal: parmsIn.newValue,
                storeId: parmsIn.storeId,
                fields: fields,
                vmFields: vmFields,
                control: parmsIn.control,
                runValidations: parmsIn.runValidations,
                dataChanged: parmsIn.dataChanged
            };

            var parms = getStatusParms(parms, parmsIn.ratingItemId);

            initValidations(parmsIn.itemName);

            runSafetyRules(getAppController(), parmsIn.questionId, parmsIn.methodName, parms);

            if (self.saveEnabled) {
                return;
            }

            if (!Ext.isEmpty(parmsIn.parentForm)) {
                parmsIn.parentForm.fireEvent('focus', parmsIn.parentForm, null);
            }
        }
    },
    handleQuestion1AAfterrender: function (parmsIn) {

        var safetyStore = chainedStore('CR_Safety_CollectionStore');
        var safetyReportStore = chainedStore('CR_SafetyReport_CollectionStore');
        var question1A = safetyStore.getAt(0).data.ReportsNotInAccordance;
        var question1B = safetyStore.getAt(0).data.FaceToFaceReportsNotInAccordance;

        var item1CYes = getAppController().getItem1CYes();
        var item1CNo = getAppController().getItem1CNo();
        var item1CNA = getAppController().getItem1CNA();

        if (question1A == 0 && question1B == 0 && safetyReportStore.count() > 0) {

            item1CNA.enable();

            item1CYes.setValue(false);
            item1CNo.setValue(false);

            item1CYes.disable();
            item1CNo.disable();
        } else {

            item1CNA.setValue(false);
            item1CNA.disable();

            item1CYes.enable();
            item1CNo.enable();
        }
    },
    handleItem2PreAppChange: function (parmsIn) {

        var parms = {},
            newVal = {},
            oldVal = {},
            self = this;

        newVal[parmsIn.control.inputId] = parmsIn.control.inputValue;

        oldVal[parmsIn.oldSelection.inputId] = parmsIn.oldSelection.inputValue;

        var dataParms = {
                control: parmsIn.control,
                newValue: newVal,
                oldValue: oldVal
            },
            result = checkIfMultiAnswerChangedByUser(dataParms);

        appDataEvent.safety.changeByUserAction = result.isUserAction;

        if (!appDataEvent.safety.changeByUserAction) {

            return;
        }

        var parms = {
            radio: parmsIn.control,
            oldRadio: parmsIn.oldSelection,
            newValue: newVal,
            oldValue: oldVal
        };

        processItem2PreAppResponse(parms);
        
        if (self.saveEnabled) {
            return;
        }

        if (!Ext.isEmpty(parmsIn.parentForm)) {
            parmsIn.parentForm.fireEvent('focus', parmsIn.parentForm, null);
        }
    },
    handleItem3Change: function (parmsIn) {

        if (pageLoadStatus['Safety'] == 'rendered') {

            //this.checkController();

            if (parmsIn.newValue) {

                var selection = parmsIn.control.inputValue,
                    fields = [],
                    field = { 'CodeDescriptionID': selection, 'AnswerCode': 1, 'KeyField': 'CodeDescriptionID' };

                fields.push(field);

                var parms = {
                    currentVal: parmsIn.newValue,
                    storeId: parmsIn.storeId,
                    fields: fields,
                    fieldType: parmsIn.fieldType,
                    groupName: parmsIn.groupName,
                    groupMembers: getCodeDescriptionGroup(parmsIn.groupName),
                    runValidations: parmsIn.runValidations,
                    dataChanged: parmsIn.dataChanged
                };

                parms = getStatusParms(parms, parmsIn.ratingItemId);

                initValidations(parmsIn.itemName);

                runSafetyRules(getAppController(), parmsIn.questionId, parmsIn.methodName, parms);
            } else {

                var parms = {
                    runValidations: parmsIn.runValidations,
                    dataChanged: parmsIn.dataChanged
                };

                parms = getStatusParms(null, parmsIn.ratingItemId);

                initValidations(parmsIn.itemName);

                runSafetyRules(getAppController(), parmsIn.questionId, parmsIn.methodName, parms);
            }
        }
    },
    handleSafetyReportGridAfterrender: function (parmsIn) {

        //this.checkController();

        Ext.create('App.CaseReview.controller.common.SafetyReportGrid', parmsIn.control);

        var parms = {
            runValidations: parmsIn.runValidations,
            dataChanged: parmsIn.dataChanged
        };

        parms = getStatusParms(parms, parmsIn.ratingItemId);

        runSafetyRules(getAppController(), parmsIn.controlId, null, parms);
    },
    handleSafetyReportGridEdit: function (parmsIn) {

        //this.checkController();

        var item1CYes = getAppController().getItem1CYes();
        var item1CNo = getAppController().getItem1CNo();
        var item1CNA = getAppController().getItem1CNA();

        var question1A = getAppController().getQuestion1A();
        var question1AVal = question1A.getValue();

        var question1B = getAppController().getQuestion1B();
        var question1BVal = question1B.getValue();

        if (question1AVal == 0 && question1BVal == 0) {

            item1CNA.enable();
        } else {

            item1CYes.disable();
            item1CNo.disable();
        }

        var parms = {
            runValidations: parmsIn.runValidations,
            dataChanged: parmsIn.dataChanged,
            recordType: parmsIn.recordType,
            storeId: parmsIn.storeId,
            data: parmsIn.data
        };

        parms = getStatusParms(parms, parmsIn.ratingItemId);

        runSafetyRules(getAppController(), parmsIn.controlId, null, parms);
    },
    handleQuestion2Afterrender: function (parmsIn) {

        parmsIn.control.enable();
    },
    handleQuestion2AChange: function (parmsIn) {

        //this.checkController();

        if (parmsIn.control.checked) {

            getAppController().getAgencyEffortConcerns().setDisabled(false);
        }
    },
    handleQuestion2BNoChange: function (parmsIn) {

        if (parmsIn.control.checked) {

            getAppController().getChildRemovalConcerns().setDisabled(false);
        }
    },
    handleQuestion2BNAAfterrender: function (parmsIn) {

        //this.checkController();
        
        var concerns2BA = getAppController().getChildRemovalConcerns(),
            retObj = concerns2BA.setValue('');

        concerns2BA.disable();
    },
    handleSafetyRelatedIncidentsChange: function (parmsIn) {
        
        //this.checkController();

        var keys = getObjectKeys(parmsIn.newValue);

        var inputValue = parmsIn.newValue[keys[0]];

        if (inputValue == 86 || inputValue == 87 || inputValue == 91) {

            return;
        }

        if (pageLoadStatus['Safety'] == 'rendered') {

            var parms = {
                control: parmsIn.control,
                groupMembers: getCodeDescriptionGroup(parmsIn.groupName),
                runValidations: parmsIn.runValidations,
                dataChanged: parmsIn.dataChanged
            };

            parms = getStatusParms(parms, parmsIn.ratingItemId);

            initValidations(parmsIn.itemName);

            var parms2 = getCheckboxSelections(parmsIn.newValue, parmsIn.groupName, 'MultiAnswer');

            parms = concatJsonObjects(parms, [parms2]);

            runSafetyRules(getAppController(), parmsIn.methodName, null, parms);
        }
    },
    handleItem3E1Change: function (parmsIn) {

        //this.checkController();

        var oldKeys = getObjectKeys(parmsIn.oldValue);

        appDataEvent.safety.changeByUserAction = false;

        if (oldKeys.length > 0) {

            appDataEvent.safety.changeByUserAction = true;
        }

        if (!appDataEvent.safety.changeByUserAction) {

            return;
        }

        var keys = getObjectKeys(parmsIn.newValue),
            inputValue = parmsIn.newValue[keys[0]];

        if (inputValue == 93 || inputValue == 97) {

            return;
        }

        if (pageLoadStatus['Safety'] == 'rendered') {

            var parms = {
                control: parmsIn.control,
                groupMembers: getCodeDescriptionGroup(parmsIn.groupName),
                runValidations: parmsIn.runValidations,
                dataChanged: parmsIn.dataChanged
            };

            parms = getStatusParms(parms, parmsIn.ratingItemId);

            initValidations(parmsIn.itemName);

            var parms2 = getCheckboxSelections(parmsIn.newValue, parmsIn.groupName, 'MultiAnswer');

            parms = concatJsonObjects(parms, [parms2]);

            runSafetyRules(getAppController(), parmsIn.methodName, null, parms);
        }
    },
    handleItem3F1Change: function (parmsIn) {

        //this.checkController();

        var oldKeys = getObjectKeys(parmsIn.oldValue);

        appDataEvent.safety.changeByUserAction = false;

        if (oldKeys.length > 0) {

            appDataEvent.safety.changeByUserAction = true;
        }

        if (!appDataEvent.safety.changeByUserAction) {

            return;
        }

        var keys = getObjectKeys(parmsIn.newValue),
            inputValue = parmsIn.newValue[keys[0]];

        if (inputValue == 99 || inputValue == 104) {

            return;
        }

        if (pageLoadStatus['Safety'] == 'rendered') {

            var parms = {
                control: parmsIn.control,
                groupMembers: getCodeDescriptionGroup(parmsIn.groupName),
                runValidations: parmsIn.runValidations,
                dataChanged: parmsIn.dataChanged
            };

            parms = getStatusParms(parms, parmsIn.ratingItemId);

            initValidations(parmsIn.itemName);

            var parms2 = getCheckboxSelections(parmsIn.newValue, parmsIn.groupName, 'MultiAnswer');

            parms = concatJsonObjects(parms, [parms2]);

            runSafetyRules(getAppController(), parmsIn.questionId,parmsIn.methodName, parms);
        }
    },
    addChangeEventListeners: function (container) {

        var self = this;
        
        self.addPreApplicabilityChangeListeners(container);

        self.addItem1ChangeListeners(container);

        self.addItem2ChangeListeners(container);

        self.addItem3ChangeListeners(container);
        //
        // Determine if the form has focus. If it is, enable the save buttons.
        //
        container.ownerCt.on('focus', function (cmp, event, eOpts) {

            if (self.saveEnabled) {
                return;
            }
            
            var buttons = cmp.query('savebuttons')[0].query('button');
            
            if (appDataEvent.safety.initialLoad) {
                appDataEvent.safety.initialLoad = false;
            }
            
            self.saveEnabled = enableButtons(buttons);
        });
    },
    addPreApplicabilityChangeListeners: function (container) {
        var self = this;

        //***************************************************************************
        // Item 2 - Pre-Applicability
        //***************************************************************************  
        container.queryById('item2Question1').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var filteredRadio = radioGroup.items.items.filter(function (radio) {

                return radio.checked == true;
            }),
            oldKeys = Object.keys(oldValue),
            prevSelection = radioGroup.items.items.filter(function (radio) {

                return radio.inputValue == oldValue[oldKeys[0]];
            });

            var parms = {
                control: filteredRadio[0],
                newValue: filteredRadio[0].inputValue,
                oldValue: oldKeys.length == 0 ? null : oldValue[oldKeys[0]],
                oldSelection: prevSelection,
                parentForm: container.ownerCt
            };

            self.handleItem2PreAppChange(parms);
        });

        container.queryById('item2Question2').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var filteredRadio = radioGroup.items.items.filter(function (radio) {

                return radio.checked == true;
            }),
            oldKeys = Object.keys(oldValue),
            prevSelection = radioGroup.items.items.filter(function (radio) {

                return radio.inputValue == oldValue[oldKeys[0]];
            });

            var parms = {
                control: filteredRadio[0],
                newValue: filteredRadio[0].inputValue,
                oldValue: oldKeys.length == 0 ? null : oldValue[oldKeys[0]],
                oldSelection: prevSelection,
                parentForm: container.ownerCt
            };

            self.handleItem2PreAppChange(parms);
        });

        container.queryById('item2Question3').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var filteredRadio = radioGroup.items.items.filter(function (radio) {

                return radio.checked == true;
            }),
            oldKeys = Object.keys(oldValue),
            prevSelection = radioGroup.items.items.filter(function (radio) {

                return radio.inputValue == oldValue[oldKeys[0]];
            });

            var parms = {
                control: filteredRadio[0],
                newValue: filteredRadio[0].inputValue,
                oldValue: oldKeys.length == 0 ? null : oldValue[oldKeys[0]],
                oldSelection: prevSelection,
                parentForm: container.ownerCt
            };

            self.handleItem2PreAppChange(parms);
        });

        container.queryById('item2Question4').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var filteredRadio = radioGroup.items.items.filter(function (radio) {

                return radio.checked == true;
            }),
            oldKeys = Object.keys(oldValue),
            prevSelection = radioGroup.items.items.filter(function (radio) {

                return radio.inputValue == oldValue[oldKeys[0]];
            });

            var parms = {
                control: filteredRadio[0],
                newValue: filteredRadio[0].inputValue,
                oldValue: oldKeys.length == 0 ? null : oldValue[oldKeys[0]],
                oldSelection: prevSelection,
                parentForm: container.ownerCt
            };

            self.handleItem2PreAppChange(parms);
        });

        container.queryById('item2Question5').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var filteredRadio = radioGroup.items.items.filter(function (radio) {

                return radio.checked == true;
            }),
            oldKeys = Object.keys(oldValue),
            prevSelection = radioGroup.items.items.filter(function (radio) {

                return radio.inputValue == oldValue[oldKeys[0]];
            });

            var parms = {
                control: filteredRadio[0],
                newValue: filteredRadio[0].inputValue,
                oldValue: oldKeys.length == 0 ? null : oldValue[oldKeys[0]],
                oldSelection: prevSelection,
                parentForm: container.ownerCt
            };

            self.handleItem2PreAppChange(parms);
        });

        container.queryById('item2Question6').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var filteredRadio = radioGroup.items.items.filter(function (radio) {

                return radio.checked == true;
            }),
            oldKeys = Object.keys(oldValue),
            prevSelection = radioGroup.items.items.filter(function (radio) {

                return radio.inputValue == oldValue[oldKeys[0]];
            });

            var parms = {
                control: filteredRadio[0],
                newValue: filteredRadio[0].inputValue,
                oldValue: oldKeys.length == 0 ? null : oldValue[oldKeys[0]],
                oldSelection: prevSelection,
                parentForm: container.ownerCt
            };

            self.handleItem2PreAppChange(parms);
        });
    },
    addItem1ChangeListeners: function (container) {

        var self = this;

        // Item 1 Applicable
        container.queryById('item1Applicability').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            parms = {
                control: parms2.control,
                itemCode: 2,
                outcomeCode: 1
            };
            
            self.handleItemApplicableChange(parms);

            self.fireFocusEvent(container);
        });

        // Question 1A
        container.queryById('question1A').on('change', function (cmp, newValue, oldValue) {
            
            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }
            
            var parms = {
                control: cmp,
                collectionName: 'safety',
                propertyName: 'ReportsNotInAccordance',
                itemCode: 2,
                vmFieldName: 'reportsNotInAccordance',
                storeId: 'CR_Safety_CollectionStore',
                runValidations: true,
                dataChanged: true,
                ratingItemId: 'safetyItem1Rating',
                itemName: 'Item1',
                methodName: 'ValidateItem1',
                questionId: 'question1A',
                newValue: Ext.isEmpty(newValue) ? null : newValue,
                oldValue: oldValue,
                reportStoreId: 'CR_SafetyReport_CollectionStore',
                dataType: 'number',
                parentForm: container.ownerCt
            };

            self.handleQuestion1Change(parms);
        });

        // Question 1B
        container.queryById('question1B').on('change', function (cmp, newValue, oldValue) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }
            
            var parms = {
                control: cmp,
                collectionName: 'safety',
                propertyName: 'FaceToFaceReportsNotInAccordance',
                itemCode: 2,
                vmFieldName: 'faceToFaceReportsNotInAccordance',
                storeId: 'CR_Safety_CollectionStore',
                runValidations: true,
                dataChanged: true,
                ratingItemId: 'safetyItem1Rating',
                itemName: 'Item1',
                methodName: 'ValidateItem1',
                questionId: 'question1B',
                newValue: Ext.isEmpty(newValue) ? null : newValue,
                oldValue: oldValue,
                reportStoreId: 'CR_SafetyReport_CollectionStore',
                dataType: 'number',
                parentForm: container.ownerCt
            };

            self.handleQuestion1Change(parms);
        });

        // Question 1C
        container.queryById('question1CContainer').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            inputVal = parms2.control.inputValue;
            
            if (inputVal == 1) {
                processItem1CYesChange(parms2.control);
            }

            if (inputVal == 2) {
                processItem1CNoChange(parms2.control);
            }

            if (inputVal == 3) {
                processItem1CNAChange(parms2.control);
            }
            
            self.fireFocusEvent(container);
        });
    },
    addItem2ChangeListeners: function (container) {

        var self = this;
        
        // Item 2 Applicable
        container.queryById('item2CaseContainer').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }
            
            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            parms = {
                control: parms2.control,
                itemCode: 3,
                outcomeCode: 2
            };

            self.handleItemApplicableChange(parms);

            self.fireFocusEvent(container);
        });

        // Question 2A
        container.queryById('item2Question2A').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }
            
            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            parms = {
                control: parms2.control
            };

            if (parms.control.inputValue == 1) {

                processItem2Question2AYesChange(parms.control);
            }

            if (parms.control.inputValue == 2) {

                self.handleQuestion2AChange(parms);
            }

            self.fireFocusEvent(container);
        });

        // Question 2B
        container.queryById('item2Question2B').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn);

            processQuestion2BChange(parms2.control);

            if (parms2.control.inputValue == 2) {
                var parms = {
                    control: parms2.control
                };

                self.handleQuestion2BNoChange(parms);
            }

            self.fireFocusEvent(container);
        });
    },
    addItem3ChangeListeners: function (container) {
        var self = this;

        // Question 3A1A
        container.queryById('Question3A1A').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn);

            processQuestion3Change(parms2.control, 'IsFamilyMaltreatmentAllegations');

            self.fireFocusEvent(container);
        });

        // Question 3A1B
        container.queryById('Question3A1B').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn);

            processQuestion3Change(parms2.control, 'IsMaltreatmentNotSubstantiated');

            self.fireFocusEvent(container);
        });

        // Question 3A
        container.queryById('item3QuestionA').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getInitialAssessmentExplained(),            
            otherField = {},
            propertyName = 'IsInitialAssesmentForAllChildrenInHome';

            if (parms2.control.inputValue == 2) {

                processQuestion3Change(parms2.control, propertyName);
                comments.enable();
            } else {

                otherField['InitialAssesmentForAllChildrenInHomeExplained'] = '';
                processQuestion3Change(parms2.control, propertyName, otherField);
                comments.disable();
            }

            self.fireFocusEvent(container);
        });

        // Question 3B
        container.queryById('item3QuestionB').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getOngoingAssessmentExplained(),
            otherField = {},
            propertyName = 'IsOngoingAssesementForAllChildrenInHome';

            if (parms2.control.inputValue == 2) {

                processQuestion3Change(parms2.control, propertyName);
                comments.enable();
            } else {

                otherField['OngoingAssessmentForAllChildrenInHomeExplained'] = '';
                processQuestion3Change(parms2.control, propertyName, otherField);
                comments.disable();
            }

            self.fireFocusEvent(container);
        });

        // Question 3C
        container.queryById('item3QuestionC').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            selection = (newValue) ? parms2.control.inputValue : 0,
            comments = getAppController().getSafetyPlanExplained(),
            otherField = {},
            propertyName = 'IsSafetyPlanDevelopedAndMonitored';

            if (parms2.control.inputValue == 2) {

                processQuestion3Change(parms2.control, propertyName);
                comments.enable();
            } else {

                otherField['SafetyPlanDevelopedAndMonitoredExplained'] = '';
                processQuestion3Change(parms2.control, propertyName, otherField);
                comments.disable();
            }

            self.fireFocusEvent(container);
        });

        // Question 3D
        container.queryById('item3QuestionD').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            propertyName = 'IsSafetyConcernForOtherChildren';

            processQuestion3Change(parms2.control, propertyName);

            self.fireFocusEvent(container);
        });

        // Question 3E
        container.queryById('item3E').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            propertyName = 'IsFosterSafetyConcernDuringVisitation';

            processQuestion3Change(parms2.control, propertyName);

            self.fireFocusEvent(container);
        });

        // Question 3F
        container.queryById('item3F').on('change', function (radioGroup, newValue, oldValue) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            if (isEmptyOrFalse(newValue)) {
                return;
            }

            var parmsIn = {
                radioGroup: radioGroup,
                newValue: newValue,
                oldValue: oldValue
            },
            parms2 = getRadioGroupSelection(parmsIn),
            propertyName = 'IsFosterSafetyConcernNotAddressed';

            processQuestion3Change(parms2.control, propertyName);

            self.fireFocusEvent(container);
        });

        //***************************************************************************
        // Safety-related Incidents (Question 3D1)
        //***************************************************************************
        container.queryById('incident1').on('change', function (cmp, newValue, oldValue, eOpts) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            var parms = {
                control: cmp,
                newValue: newValue,
                oldValue: oldValue,
                itemCode: 4,
                storeId: 'CR_MultiAnswer_CollectionStore',
                runValidations: true,
                dataChanged: true,
                ratingItemId: 'safetyItem3Rating',
                itemName: 'Item3',
                methodName: 'ValidateItem3',
                fieldType: 'MultiAnswer',
                groupName: 'SafetyRelatedIncidents',
                questionId: 'incident1_change'
            };

            self.handleItem3Change(parms);

            self.fireFocusEvent(container);
        });

        container.queryById('incident2').on('change', function (cmp, newValue, oldValue, eOpts) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            var parms = {
                control: cmp,
                newValue: newValue,
                oldValue: oldValue,
                itemCode: 4,
                storeId: 'CR_MultiAnswer_CollectionStore',
                runValidations: true,
                dataChanged: true,
                ratingItemId: 'safetyItem3Rating',
                itemName: 'Item3',
                methodName: 'ValidateItem3',
                fieldType: 'MultiAnswer',
                groupName: 'SafetyRelatedIncidents',
                questionId: 'incident2_change'
            };

            self.handleItem3Change(parms);

            self.fireFocusEvent(container);
        });

        container.queryById('incident6').on('change', function (cmp, newValue, oldValue, eOpts) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            var parms = {
                control: cmp,
                newValue: newValue,
                oldValue: oldValue,
                itemCode: 4,
                storeId: 'CR_MultiAnswer_CollectionStore',
                runValidations: true,
                dataChanged: true,
                ratingItemId: 'safetyItem3Rating',
                itemName: 'Item3',
                methodName: 'ValidateItem3',
                fieldType: 'MultiAnswer',
                groupName: 'SafetyRelatedIncidents',
                questionId: 'incident6_change'
            };

            self.handleItem3Change(parms);

            self.fireFocusEvent(container);
        });

        //***************************************************************************
        // Safety concerns (Question 3E1)
        //***************************************************************************
        container.queryById('safetyConcern2').on('change', function (cmp, newValue, oldValue, eOpts) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            var parms = {
                control: cmp,
                newValue: newValue,
                oldValue: oldValue,
                itemCode: 4,
                storeId: 'CR_MultiAnswer_CollectionStore',
                runValidations: true,
                dataChanged: true,
                ratingItemId: 'safetyItem3Rating',
                itemName: 'Item3',
                methodName: 'ValidateItem3',
                fieldType: 'MultiAnswer',
                groupName: 'FosterSafety',
                questionId: 'safetyConcern2_change'
            };

            self.handleItem3Change(parms);

            self.fireFocusEvent(container);
        });

        container.queryById('safetyConcern6').on('change', function (cmp, newValue, oldValue, eOpts) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            var parms = {
                control: cmp,
                newValue: newValue,
                oldValue: oldValue,
                itemCode: 4,
                storeId: 'CR_MultiAnswer_CollectionStore',
                runValidations: true,
                dataChanged: true,
                ratingItemId: 'safetyItem3Rating',
                itemName: 'Item3',
                methodName: 'ValidateItem3',
                fieldType: 'MultiAnswer',
                groupName: 'FosterSafety',
                questionId: 'safetyConcern6_change'
            };

            self.handleItem3Change(parms);

            self.fireFocusEvent(container);
        });

        //***************************************************************************
        // Safety placement concerns (Question 3F1)
        //***************************************************************************
        container.queryById('placementConcern2').on('change', function (cmp, newValue, oldValue, eOpts) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            var parms = {
                control: cmp,
                newValue: newValue,
                oldValue: oldValue,
                itemCode: 4,
                storeId: 'CR_MultiAnswer_CollectionStore',
                runValidations: true,
                dataChanged: true,
                ratingItemId: 'safetyItem3Rating',
                itemName: 'Item3',
                methodName: 'ValidateItem3',
                fieldType: 'MultiAnswer',
                groupName: 'FosterPlacementConcern',
                questionId: 'placementConcern2_change'
            };

            self.handleItem3Change(parms);

            self.fireFocusEvent(container);
        });

        container.queryById('placementConcern7').on('change', function (cmp, newValue, oldValue, eOpts) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            var parms = {
                control: cmp,
                newValue: newValue,
                oldValue: oldValue,
                itemCode: 4,
                storeId: 'CR_MultiAnswer_CollectionStore',
                runValidations: true,
                dataChanged: true,
                ratingItemId: 'safetyItem3Rating',
                itemName: 'Item3',
                methodName: 'ValidateItem3',
                fieldType: 'MultiAnswer',
                groupName: 'FosterPlacementConcern',
                questionId: 'placementConcern7_change'
            };

            self.handleItem3Change(parms);

            self.fireFocusEvent(container);
        });

        //
        // Question 3D1
        //
        container.queryById('safetyRelatedIncidents').on('change', function (cmp, newValue, oldValue, eOpts) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            var parms = {
                control: cmp,
                itemCode: 4,
                runValidations: true,
                dataChanged: false,
                ratingItemId: 'safetyItem3Rating',
                itemName: 'Item3',
                methodName: 'ValidateItem3',
                groupName: 'SafetyRelatedIncidents',
                newValue: newValue
            };

            self.handleSafetyRelatedIncidentsChange(parms);

            self.fireFocusEvent(container);
        });

        //
        // Question 3E1
        //
        container.queryById('item3E1').on('change', function (cmp, newValue, oldValue, eOpts) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            var parms = {
                control: cmp,
                itemCode: 4,
                runValidations: true,
                dataChanged: false,
                ratingItemId: 'safetyItem3Rating',
                itemName: 'Item3',
                methodName: 'ValidateItem3',
                groupName: 'FosterSafety',
                newValue: newValue,
                oldValue: oldValue
            };

            self.handleItem3E1Change(parms);

            self.fireFocusEvent(container);
        });

        //
        // Question 3F1
        //
        container.queryById('item3F1').on('change', function (cmp, newValue, oldValue, eOpts) {

            if (appDataEvent.safety.initialLoad && isEmptyOrFalse(oldValue)) {
                return;
            }

            var parms = {
                control: cmp,
                itemCode: 4,
                runValidations: true,
                dataChanged: false,
                ratingItemId: 'safetyItem3Rating',
                itemName: 'Item3',
                questionId: 'item3F1',
                methodName: 'ValidateItem3',
                groupName: 'FosterPlacementConcern',
                newValue: newValue,
                oldValue: oldValue
            };

            self.handleItem3F1Change(parms);

            self.fireFocusEvent(container);
        });
    }
});