﻿Ext.define('App.CaseReview.controller.FacesheetControls',
{
    extend: 'Ext.Base',
    constructor: function (controller) {
        var self = controller;
        controller.control({

        //'#facesheetCenterPanel': {
        //    'afterrender': function () {

        //        var comp = this.getFacesheetCenterPanel();

        //        setDisableFieldValues(comp);

        //        var validationPluginResults = this.getChildDemographicGrid().plugins[2].getValidationResult();

        //        Ext.each(validationPluginResults, function (result) {

        //        });

        //        var participantGridPluginResults = this.getCaseParticipantGrid().plugins[2].getValidationResult();

        //        Ext.each(participantGridPluginResults, function (result) {

        //        });


        //    }
        //},
        //'#childDemographicGrid': {
        //    'afterrender': function () {

        //        //Ext.StoreManager.get("CR_ChildRace_CollectionStore")
        //        Ext.create('App.CaseReview.controller.common.ChildDemographicGrid', self);
        //    },
        //    'afterlayout': function () {

        //        runFacesheetRules(this);
        //    }
        //},
        //'#caseParticipantGrid': {
        //    'afterrender': function () {
        //        Ext.create('App.CaseReview.controller.common.CaseParticipantGrid', self);
        //    }
        //},
        //'#fosterEntryDate': {
        //    'beforerender': function () {

        //        var comp = this.getFosterEntryDate();
        //        var result = comp.plugins[0].getRulesEvalResult();

        //        if (result.validityResult == 'inHomeCase') {
        //            var checkBox = this.getIsFosterCareDateNA();
        //            checkBox = checkBox.setValue('1');

        //            // Disable datefield
        //            comp.setValue(null);
        //            comp.disable();
        //        }
        //    }
        //},
        //'#isFosterCareDateNA': {
        //    'change': function () {
        //        if (this.getIsFosterCareDateNA().checked == true) {
        //            this.getFosterEntryDate().setValue(null);
        //            this.getFosterEntryDate().disable();
        //        } else {
        //            this.getFosterEntryDate().enable();
        //        }
        //    }
        //},
        //'#dischargeNA': {
        //    'change': function () {
        //        if (this.getDischargeNA().checked == true) {
        //            this.getEpisodeDischargeDate().setValue(null);
        //            this.getEpisodeDischargeDate().disable();
        //            this.getNotYetDischarged().disable();
        //            if (this.getNotYetDischarged().getValue() == 1)
        //                this.getNotYetDischarged().setValue(0);
        //            else
        //                this.getNotYetDischarged().setValue(null);
        //        } else {
        //            this.getEpisodeDischargeDate().enable();
        //            this.getNotYetDischarged().enable();
        //        }
        //    }
        //},
        //'#notYetDischarged': {
        //    'change': function () {
        //        if (this.getNotYetDischarged().checked == true) {
        //            this.getEpisodeDischargeDate().setValue(null);
        //            this.getEpisodeDischargeDate().disable();
        //            this.getDischargeNA().disable();
        //            if (this.getDischargeNA().getValue() == 1)
        //                this.getDischargeNA().setValue(0);
        //            else
        //                this.getDischargeNA().setValue(null);
        //        } else {
        //            this.getEpisodeDischargeDate().enable();
        //            this.getDischargeNA().enable();
        //        }
        //    }
        //},
        //'#episodeDischargeDate': {
        //    'beforerender': function () {

        //        var comp = this.getEpisodeDischargeDate();
        //        var result = comp.plugins[0].getRulesEvalResult();

        //        if (result.validityResult == 'inHomeCase') {
        //            var checkBoxNA = this.getDischargeNA();
        //            checkBoxNA = checkBoxNA.setValue('1');

        //            var checkBoxNotDischarged = this.getNotYetDischarged();
        //            checkBoxNotDischarged = checkBoxNotDischarged.setValue(null);

        //            // Disable datefield
        //            comp.setValue(null);
        //            comp.disable();
        //        }
        //    }
        //},
        //'#caseClosureClosedInd': {
        //    'change': function () {

        //        if (this.getCaseClosureClosedInd().checked == true) {
        //            this.getCaseClosureDate().setValue(null);
        //            this.getCaseClosureDate().disable();
        //        } else {
        //            this.getCaseClosureDate().enable();
        //        }
        //        //caseClosureDate
        //    }
        //},
        //'#caseClosureDate': {
        //    'beforerender': function () {

        //        var caseClosureDate = this.getCaseClosureDate();
        //        var reviewEndDate;
        //        var store = Ext.data.StoreManager.lookup('CaseReviewStore');

        //        if (store.data.count() > 0) {

        //            reviewEndDate = store.getAt(0).data.ReviewCompleted;
        //        }

        //        if (caseClosureDate.value > reviewEndDate) {
        //            var closureInd = this.getCaseClosureClosedInd();

        //            closureInd.setValue('3');
        //            caseClosureDate.setValue('');
        //        }
        //    }
        //},
        //'#caseRsn14': {
        //     change: function () {
        //         if (this.getCaseRsn14().checked == true) {
        //             this.getQuestionMNarrative().enable();
        //            } else {
        //             this.getQuestionMNarrative().disable();
        //             this.getQuestionMNarrative().setValue(null);
        //         }
        //        }
        //    }
        });
    }
});