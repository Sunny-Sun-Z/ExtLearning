﻿Ext.define('App.CaseReview.controller.CaseReviewRoles',{
    extend: 'Ext.Base',
    singleton: true,
    alternateClassName: 'CaseReviewRoles',
    reviewRoles: {
        actions: {
            dataEntry: {
                name: 'dataEntry',
                startStatus: [
                    {
                        status: 'Not Started',
                        statusCode: sr.ItemStatus.NotStarted
                    },
                    {
                        status: 'In Progress',
                        statusCode: sr.ItemStatus.InProgress
                    },
                    {
                        status: 'Completed',
                        statusCode: sr.ItemStatus.Completed
                    },
                    {
                        status: 'Data Entry Complete',
                        statusCode: sr.CaseStatus.DataEntryComplete
                    }
                ],
                completedStatus: {
                    status: 'Data Entry Complete',
                    statusCode: sr.CaseStatus.DataEntryComplete
                }
            },
            eliminateCaseRequest: {
                name: 'eliminateCaseRequest',
                startStatus: [
                    {
                        status: 'Not Started',
                        statusCode: sr.ItemStatus.NotStarted
                    },
                    {
                        status: 'In Progress',
                        statusCode: sr.ItemStatus.InProgress
                    },
                    {
                        status: 'Completed',
                        statusCode: sr.ItemStatus.Completed
                    },
                    {
                        status: 'Data Entry Complete',
                        statusCode: sr.CaseStatus.DataEntryComplete
                    },
                    {
                        status: 'QA in Progress',
                        statusCode: sr.CaseStatus.QAinProgress
                    }
                ],
                completedStatus: {
                    status: 'Case Eliminated (Pending Approval)',
                    statusCode: sr.CaseStatus.CaseEliminatedPendingApproval
                }
            },
            eliminateCase: {
                name: 'eliminateCase',
                startStatus: [
                    {
                        status: 'Approved and Final',
                        statusCode: sr.CaseStatus.ApprovedandFinal
                    }
                ],
                completedStatus: {
                    status: 'Case Eliminated',
                    statusCode: sr.CaseStatus.CaseEliminated
                }
            },
            submitToQA: {
                name: 'submitToQA',
                startStatus: [
                    {
                        status: 'Data Entry Complete',
                        statusCode: sr.CaseStatus.DataEntryComplete
                    }
                ],
                completedStatus: {
                    status: 'QA in Progress',
                    statusCode: sr.CaseStatus.QAinProgress
                },
                completedStatusCode: sr.CaseStatus.QAinProgress
            },
            returnCaseToQA: {
                name: 'returnCaseToQA',
                startStatus: [
                    {
                        status: 'Finalized (Pending Approval)',
                        statusCode: sr.CaseStatus.FinalizedPendingApproval
                    }
                ],
                completedStatus: {
                    status: 'QA in Progress',
                    statusCode: sr.CaseStatus.QAinProgress
                }
            },
            returnCaseToReviewer: {
                name: 'returnCaseToReviewer',
                startStatus: [
                    {
                        status: 'QA in Progress',
                        statusCode: sr.CaseStatus.QAinProgress
                    }
                ],
                completedStatus: {
                    status: 'Data Entry Complete',
                    statusCode: sr.CaseStatus.DataEntryComplete
                }
            },
            finalizeCase: {
                name: 'finalizeCase',
                startStatus: [
                    {
                        status: 'QA in Progress',
                        statusCode: sr.CaseStatus.QAinProgress
                    }
                ],
                completedStatus: {
                    status: 'Finalized (Pending Approval)',
                    statusCode: sr.CaseStatus.FinalizedPendingApproval
                }
            },
            approveElimination: {
                name: 'approveElimination',
                startStatus: [
                    {
                        status: 'Case Eliminated (Pending Approval)',
                        statusCode: sr.CaseStatus.CaseEliminatedPendingApproval
                    }                    
                ],
                completedStatus: {
                    status: 'Case Eliminated',
                    statusCode: sr.CaseStatus.CaseEliminated
                }
            },
            signoffElimination: {
                name: 'signoffElimination',
                startStatus: [
                    {
                        status: 'Case Eliminated (Pending Approval)',
                        statusCode: sr.CaseStatus.CaseEliminatedPendingApproval
                    }
                ],
                completedStatus: {
                    status: 'Case Eliminated (Pending Approval)',
                    statusCode: sr.CaseStatus.CaseEliminatedPendingApproval
                }
            },
            approveFinalize: {
                name: 'approveFinalize',
                startStatus: [
                    {
                        status: 'Finalized (Pending Approval)',
                        statusCode: sr.CaseStatus.FinalizedPendingApproval
                    }
                ],
                completedStatus: {
                    status: 'Approved and Final',
                    statusCode: sr.CaseStatus.ApprovedandFinal
                }
            },
            overrideRating: {
                name: 'overrideRating',
                startStatus: [
                    {
                        status: 'QA in Progress',
                        statusCode: sr.CaseStatus.QAinProgress
                    }
                ],
                completedStatus: {
                    status: 'QA in Progress',
                    statusCode: sr.CaseStatus.QAinProgress
                }
            }
        },
        reviewer: {
            actionsAllowed: ['dataEntry', 'eliminateCaseRequest', 'submitToQA'],
            rank: 7
        },
        initialQA: {
            actionsAllowed: ['dataEntry', 'returnCaseToReviewer', 'finalizeCase', 'eliminateCaseRequest', 'signoffElimination'],
            rank: 6
        },
        secondLevelQA: {
            actionsAllowed: ['dataEntry', 'returnCaseToReviewer', 'finalizeCase', 'eliminateCaseRequest', 'signoffElimination'],
            rank: 5
        },
        secondaryOversight: {
            actionsAllowed: ['dataEntry', 'returnCaseToQA', 'approveFinalize', 'eliminateCaseRequest', 'eliminateCase', 'approveElimination'],
            rank: 4
        },
        ctSecondaryOversight: {
            actionsAllowed: ['dataEntry', 'returnCaseToQA', 'approveFinalize', 'eliminateCaseRequest', 'eliminateCase', 'approveElimination'],
            rank: 3
        },
        stateAdmin: {
            actionsAllowed: ['approveElimination', 'overrideRating'],
            rank: 2
        },
        fedTeamMember: {
            actionsAllowed: ['approveElimination', 'overrideRating'],
            rank: 1
        }
    },
    getAction: function(actionNames){

        var self = this;
        var actions = [];
        var action, result;
        var filteredStat;

        var user = GetLoggedInUser();
        var caseStatus = getSavedCaseStatus();

        var effRole = user.getEffectiveRole();
        var actionsAllowed = effRole.actionsAllowed;

        Ext.each(actionNames, function (actionName) {

            action = self.reviewRoles.actions[actionName];

            actions.push(action);
        });

        var filteredAction;

        Ext.each(actions, function (action) {

            filteredStat = action.startStatus.filter(function (stat) {

                return stat.status == caseStatus;
            });

            if (filteredStat.length > 0) {

                filteredAction = actionsAllowed.filter(function (actionId) {

                    return actionId == action.name;
                });

                if (filteredAction.length > 0) {
                    
                    result = action;

                    return false;
                }
            }
        });
        
        return result;
    },
    getActionList: function (actionName) {

        var result = [];

        Ext.each(this.getAction([actionName]).startStatus, function(action){

            result.push(action.status);
        });

        return result.toString();
    },
    getRole: function(roleName){

        return this.reviewRoles[roleName];
    },
    executeAction: function (action) {

        var result = {};

        if (Ext.isEmpty(action)) {
            
            result['ActionAllowed'] = false;
            result['MessageType'] = 'Access Denied';
            result['Message'] = 'You do not have the permissions needed to perform this action';

            return result;
        }

        var user = GetLoggedInUser();
        var caseStatus = getSavedCaseStatus();
        
        var filteredStat = action.startStatus.filter(function (stat) {

            return stat.status == caseStatus;
        });

        if (filteredStat.length == 0) {
            //
            // Invalid request
            //
            var statuslist = getActionList(action.name);

            result['ActionAllowed'] = false;
            result['MessageType'] = 'Error';
            result['Message'] = 'Case is not in the proper status to perform this action.' + ' Valid status(es) is/are ' + statusList;

            return result;
        }

        var effRole = user.getEffectiveRole();

        var actionsAllowed = effRole.actionsAllowed;

        var filteredAction = actionsAllowed.filter(function (actionId) {

            return actionId == action.name;
        });

        if (filteredAction.length == 0) {
            //
            // User does not have permission
            //

            result['ActionAllowed'] = false;
            result['MessageType'] = 'Access Denied';
            result['Message'] = 'You do not have the permissions needed to perform this action';

            return result;
        }

        //
        // Update case status
        //
        updateQAStatus(action.completedStatus.statusCode);

        result['ActionAllowed'] = true;
        result['Message'] = 'Success';
        result['CompletedStatus'] = action.completedStatus;

        return result;
    }
});