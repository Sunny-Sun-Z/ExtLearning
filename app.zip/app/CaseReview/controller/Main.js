﻿/* global framework */
var propertiesToUpdate = [
    'DataState', 'ItemID', 'NoteID', 'CaseReviewID', 'LastModifiedDate', 'ResponseID', 'OutcomeID', 'FaceSheetID',
    'PermanencyID', 'PlacementID', 'SafetyID', 'WellBeingID', 'CaseParticipantID', 'CasePreviousPreviousID', 'ChildDemographicID',
    'ChildDemographicPreviousID', 'ItemParticipantID', 'SafetyReportID', 'AllegationID', 'HeathID', 'GoalID', 'EducationID',
    'ChildRaceID', 'ParticipantID', 'AnswerID'
]
var revStartDate;
var revCompleteDate;
var participants;
var appController;
var lastSavedResult;
var saveRequestResults = [];
var qaNotesContainer;
var saveItemId;
var appErrors = [];
var saveCompleted = false;
var preAppMultiAnswerStore;
var silentSave = false;
var silentSaveTrigger = [];
var isReloadNeeded = function () {

    if (saveItemId === 'saveCaseButton' || saveItemId === 'saveCaseContinueButton') {

        if (!(window.currentTab == 'faceSheet' || activeTab == 'faceSheet')) {

            return false;
        }
    }
    
    if (saveItemId === 'submitToQA' ||
        saveItemId === 'returnToQA' ||
        saveItemId === 'returnToReviewer' ||
        saveItemId === 'submitToFinalize' ||
        saveItemId === 'finalizeAndApprove' ||
        saveItemId === 'approveNEliminateSave') {

        return true;
    }

    if (silentSave) {

        return false;
    }

    return true;
};
var isTabChange = false;
var appPages = {};
var appDataEvent = {
    facesheet: {
        initialLoad: true,
        dataChanged: false,
        changeByUserAction: false,
        questionMprevValue: undefined
    },
    safety: {
        initialLoad: true,
        dataChanged: false,
        changeByUserAction: false
    },
    permanency: {
        initialLoad: true,
        dataChanged: false,
        changeByUserAction: false
    },
    wellbeing: {
        initialLoad: true,
        dataChanged: false,
        changeByUserAction: false
    }
};
var appDataState = 'loading';
var itemStatuses = {
    facesheet: undefined,
    item1: undefined,
    item2: undefined,
    item3: undefined,
    item4: undefined,
    item5: undefined,
    item6: undefined,
    item7: undefined,
    item8: undefined,
    item9: undefined,
    item10: undefined,
    item11: undefined,
    item12: undefined,
    item12A: undefined,
    item12B: undefined,
    item12C: undefined,
    item13: undefined,
    item14: undefined,
    item15: undefined,
    item16: undefined,
    item17: undefined,
    item18: undefined,
    updateItem12Status: function () {

        var statusDesc;
        var itemName;

        for (var i = 14; i < 17; i++) {

            statusDesc = getItemStatus(i);
            itemName = getItemNameFromCode(i);

            itemStatuses[itemName] = statusDesc;
        }

        var item12Status = calculateItem12Status();

        var inputObj = { ItemCode: 13, OutcomeCode: 5, StatusDesc: item12Status };

        updateItemStatusCode(inputObj);
    }
};
var pageLoadStatus = {
    renderingComplete: function () {

        if (this.Facesheet == 'rendered' &&
           this.Safety == 'rendered' &&
           this.Permanency == 'rendered' &&
           this.Wellbeing == 'rendered') {

            return true;
        }

        return false;
    }
};
var layoutRuns = {};
var runDemographicGridLayoutEvent = true;
var runParticipantGridLayoutEvent = true;
var itemRatings = {
    Item1Rating: undefined,
    Item2Rating: undefined,
    Item3Rating: undefined,
    Item4Rating: undefined,
    Item5Rating: undefined,
    Item6Rating: undefined,
    Item7Rating: undefined,
    Item8Rating: undefined,
    Item9Rating: undefined,
    Item10Rating: undefined,
    Item11Rating: undefined,
    Item12Rating: undefined,
    Item12ARating: undefined,
    Item12BRating: undefined,
    Item12CRating: undefined,
    Item13Rating: undefined,
    Item14Rating: undefined,
    Item15Rating: undefined,
    Item16Rating: undefined,
    Item17Rating: undefined,
    Item18Rating: undefined,
    OverviewRatingItems: [
        { itemId: 'item1RatingDesc', ratingItemId: 'safetyItem1Rating', appPage: 'safety' },
        { itemId: 'item2RatingDesc', ratingItemId: 'safetyItem2Rating', appPage: 'safety' },
        { itemId: 'item3RatingDesc', ratingItemId: 'safetyItem3Rating', appPage: 'safety' },
        { itemId: 'item4RatingDesc', ratingItemId: 'permanencyItem4Rating', appPage: 'permanency' },
        { itemId: 'item5RatingDesc', ratingItemId: 'permanencyItem5Rating', appPage: 'permanency' },
        { itemId: 'item6RatingDesc', ratingItemId: 'permanencyItem6Rating', appPage: 'permanency' },
        { itemId: 'item7RatingDesc', ratingItemId: 'permanencyItem7Rating', appPage: 'permanency' },
        { itemId: 'item8RatingDesc', ratingItemId: 'permanencyItem8Rating', appPage: 'permanency' },
        { itemId: 'item9RatingDesc', ratingItemId: 'permanencyItem9Rating', appPage: 'permanency' },
        { itemId: 'item10RatingDesc', ratingItemId: 'permanencyItem10Rating', appPage: 'permanency' },
        { itemId: 'item11RatingDesc', ratingItemId: 'permanencyItem11Rating', appPage: 'permanency' },
        { itemId: 'item12RatingText' },
        { itemId: 'item12ARatingDesc', ratingItemId: 'wellbeingItem12ARating', appPage: 'wellbeing' },
        { itemId: 'item12BRatingDesc', ratingItemId: 'wellbeingItem12BRating', appPage: 'wellbeing' },
        { itemId: 'item12CRatingDesc', ratingItemId: 'wellbeingItem12CRating', appPage: 'wellbeing' },
        { itemId: 'item13RatingDesc', ratingItemId: 'wellbeingItem13Rating', appPage: 'wellbeing' },
        { itemId: 'item14RatingDesc', ratingItemId: 'wellbeingItem14Rating', appPage: 'wellbeing' },
        { itemId: 'item15RatingDesc', ratingItemId: 'wellbeingItem15Rating', appPage: 'wellbeing' },
        { itemId: 'item16RatingDesc', ratingItemId: 'wellbeingItem16Rating', appPage: 'wellbeing' },
        { itemId: 'item17RatingDesc', ratingItemId: 'wellbeingItem17Rating', appPage: 'wellbeing' },
        { itemId: 'item18RatingDesc', ratingItemId: 'wellbeingItem18Rating', appPage: 'wellbeing' }
    ],
    OverviewOutcomeItems: [
        { itemId: 'safetyOutcome1RatingDesc', ratingItemId: 'safetyItem1Rating', appPage: 'safety' },
        { itemId: 'safetyOutcome2RatingDesc', ratingItemId: 'safetyItem2Rating', appPage: 'safety' },
        { itemId: 'permanencyOutcome1RatingDesc', ratingItemId: 'permanencyItem4Rating', appPage: 'permanency' },
        { itemId: 'permanencyOutcome2RatingDesc', ratingItemId: 'permanencyItem7Rating', appPage: 'permanency' },
        { itemId: 'wellbeingOutcome1RatingDesc', ratingItemId: 'wellbeingItem12Rating', appPage: 'wellbeing' },
        { itemId: 'wellbeingOutcome2RatingDesc', ratingItemId: 'wellbeingItem16Rating', appPage: 'wellbeing' },
        { itemId: 'wellbeingOutcome3RatingDesc', ratingItemId: 'wellbeingItem17Rating', appPage: 'wellbeing' }
    ],
    getItem12Rating: function () {

        var ratingDesc;
        var ratingCode = null;
        var overrideRatingCode = null;
        var self = this;

        var getRating = function () {

            if ((self.Item12ARating == 'Strength' && self.Item12BRating == 'Strength' && self.Item12CRating == 'Strength') ||
               ((self.Item12ARating == 'Strength' || self.Item12BRating == 'Strength' || self.Item12CRating == 'Strength') &&
                (!(self.Item12ARating == 'Area Needing Improvement' || self.Item12BRating == 'Area Needing Improvement' ||
                 self.Item12CRating == 'Area Needing Improvement')))) {

                return 'Strength';
            }

            // Area Needing Improvement
            if (self.Item12ARating == 'Area Needing Improvement' || self.Item12BRating == 'Area Needing Improvement' ||
                 (self.Item12CRating == 'Area Needing Improvement' || self.Item12CRating == 'NA')) {

                return 'Area Needing Improvement';
            } else {

                return 'Not Yet Rated';
            }
        };

        var getRatingStore = function (rCode) {

            var itemRatingStore = Ext.data.ChainedStore.create({
                source: 'ItemRatingStore',
                filters: [
                    function (record) {
                        return record.data.GroupID == rCode;
                    }
                ]
            });

            return itemRatingStore;
        }

        var getSubItemRating = function (iCode, oCode) {

            var item = getItem(iCode, oCode);

            if (!Ext.isEmpty(item)) {

                ratingCode = item.ItemRatingCode;
                overrideRatingCode = item.OverriddenRatingCode;
            }

            ratingCode = ratingCode == undefined ? overrideRatingCode : ratingCode;

            var ratingStore = getRatingStore(ratingCode);

            var subItemRating = ratingStore.data.length == 0 ? 'Not Yet Rated' : ratingStore.getAt(0).data.DescriptionLarge;

            return subItemRating;
        };

        if (Ext.isEmpty(self.Item12ARating)) {

            self.Item12ARating = getSubItemRating(14, 5);
        }

        if (Ext.isEmpty(self.Item12BRating)) {

            self.Item12BRating = getSubItemRating(15, 5);
        }

        if (Ext.isEmpty(self.Item12CRating)) {

            self.Item12CRating = getSubItemRating(16, 5);
        }

        if (!Ext.isEmpty(self.Item12ARating) && !Ext.isEmpty(self.Item12BRating) && !Ext.isEmpty(self.Item12CRating)) {

            return getRating();
        }

        return '';
    },
    updateItem12Rating: function () {

        var self = this;
        var ratingCalculator = App.CaseReview.view.common.CRSRatingCalculator.create({});

        var rating = ratingCalculator.getRatingCode(self.getItem12Rating());

        var item = getItem(13, 5);

        if (!(item == undefined)) {

            item.ItemRatingCode = rating.RatingCode;

            updateItem(item);
            //
            // Update Outcome store
            //
            var ratingFunction = getAppController().getWellbeingItem12Rating;

            if (!Ext.isEmpty(ratingFunction)) {

                var ratingCmp = getAppController().getWellbeingItem12Rating();
                var ratingOverrideCmp = getAppController().getWellbeingItem12RatingOverride();

                ratingCmp.setRatingOverride(ratingOverrideCmp);

                var outcomeRatingInput = {};
                outcomeRatingInput['OutcomeCode'] = 5;
                outcomeRatingInput['Item12Rating'] = itemRatings.getItem12Rating();
                outcomeRatingInput['Item13Rating'] = itemRatings.Item13Rating;
                outcomeRatingInput['Item14Rating'] = itemRatings.Item14Rating;
                outcomeRatingInput['Item15Rating'] = itemRatings.Item15Rating;

                var outcomeRating = ratingCmp.calculateOutcomeRating(outcomeRatingInput);
                ratingCmp.updateOutcomeStore(outcomeRating);
            }
        }
    }
};
var outcomeRatings = {
    safety: {
        outcome1: { outcomeCode: 1, ratingCode: undefined, ratingDescription: undefined },
        outcome2: { outcomeCode: 2, ratingCode: undefined, ratingDescription: undefined }
    },
    permanency: {
        outcome1: { outcomeCode: 3, ratingCode: undefined, ratingDescription: undefined },
        outcome2: { outcomeCode: 4, ratingCode: undefined, ratingDescription: undefined }
    },
    wellbeing: {
        outcome1: { outcomeCode: 5, ratingCode: undefined, ratingDescription: undefined },
        outcome2: { outcomeCode: 6, ratingCode: undefined, ratingDescription: undefined },
        outcome3: { outcomeCode: 7, ratingCode: undefined, ratingDescription: undefined }
    }
};
var validationResults = {};
var deletedQANotes = [];
var facesheetQuestions = [
    {
        errorsExist: false,
        itemCode: 23,
        outcomeCode: 21,
        viewModel: 'facesheetViewModel',
        facesheet: [
            {
                QuestionG1: {
                    required: false,
                    answered: false,
                    modelProperty: [
                        { name: 'facesheetData', actionType: 'search', nodeToSelect: 'CR_ChildDemographic_Collection', validValues: 'gt0' }
                    ]
                }
            },
            {
                QuestionG2: {
                    required: false,
                    answered: false,
                    modelProperty: [
                        { name: 'facesheetData', actionType: 'search', nodeToSelect: 'CR_CaseParticipant_Collection', validValues: 'gt0' }
                    ]
                }
            },
            {
                QuestionH: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isCaseOpenReasonOtherAbuseNeglect', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                QuestionI: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'firstCaseOpeningDate', dataType: 'date' }
                    ]
                }
            },
            {
                QuestionJ: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'fosterEntryDate', dataType: 'date' },
                        { name: 'isFosterEntryDateNA', dataType: 'number', validValues: [1] }
                    ]
                }
            },
            {
                QuestionK: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'episodeDischargeDate', dataType: 'date' },
                        { name: 'isEpisodeDischargeDateNA', dataType: 'number', validValues: [1] },
                        { name: 'isEpisodeNotYetDischarged', dataType: 'number', validValues: [1] }
                    ]
                }
            },
            {
                QuestionL: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'caseClosureDate', dataType: 'date' },
                        { name: 'isCaseClosureNotClosed', dataType: 'number', validValues: [1] }
                    ]
                }
            },
            {
                QuestionM: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'questionM', storeId: 'CR_MultiAnswer_CollectionStore', groupName: 'CaseReason', actionType: 'lookup', validValues: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14] }
                    ]
                }
            }
        ]
    }
];
var safetyQuestions = [
    {
        errorsExist: false,
        itemCode: 2,
        outcomeCode: 1,
        ratingItemId: 'safetyItem1Rating',
        containerId: 'safetyPanel',
        viewModel: 'safetyViewModel',
        item1: [
            {
                Applicability: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'item1Applicable', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question1A: {
                    required: false,
                    answered: false,
                    modelProperty: [
                        { name: 'reportsNotInAccordance', dataType: 'number' }
                    ]
                }
            },
            {
                Question1A1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'safetyCollection', actionType: 'search', nodeToSelect: 'CR_SafetyReport_Collection', validValues: 'gt0' }
                    ]
                }
            },
            {
                Question1B: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'faceToFaceReportsNotInAccordance', dataType: 'number' }
                    ]
                }
            },
            {
                Question1C: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isDelayBeyondAgencyControl', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            }
        ]
    },
    {
        errorsExist: false,
        itemCode: 3,
        outcomeCode: 2,
        ratingItemId: 'safetyItem2Rating',
        containerId: 'safetyPanel',
        viewModel: 'safetyViewModel',
        item2: [
            {
                PreApplicability: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'answerCode51', validValues: [1, 2] },
                        { name: 'answerCode52', validValues: [1, 2] },
                        { name: 'answerCode53', validValues: [1, 2] },
                        { name: 'answerCode54', validValues: [1, 2] },
                        { name: 'answerCode55', validValues: [1, 2] },
                        { name: 'answerCode56', validValues: [1, 2] }
                    ]
                }
            },
            {
                Applicability: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'item2Applicable', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question2A: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isEffortToPreventReEntry', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question2B: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isChildRemovedToEnsureSafety', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            }
        ]
    },
    {
        errorsExist: false,
        itemCode: 4,
        outcomeCode: 2,
        ratingItemId: 'safetyItem3Rating',
        containerId: 'safetyPanel',
        viewModel: 'safetyViewModel',
        item3: [
            {
                Question3A: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isInitialAssesmentForAllChildrenInHome', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question3A1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isFamilyMaltreatmentAllegations', dataType: 'number', validValues: [1, 2] },
                        { name: 'isMaltreatmentNotSubstantiated', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question3B: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isOngoingAssesementForAllChildrenInHome', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question3C: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isSafetyPlanDevelopedAndMonitored', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question3D: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isSafetyConcernForOtherChildren', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question3D1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'question3D1', storeId: 'CR_MultiAnswer_CollectionStore', groupName: 'SafetyRelatedIncidents', actionType: 'lookup', validValues: [86, 87, 88, 89, 90, 91] }
                    ]
                }
            },
            {
                Question3E: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isFosterSafetyConcernDuringVisitation', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question3E1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'question3E1', storeId: 'CR_MultiAnswer_CollectionStore', groupName: 'FosterSafety', actionType: 'lookup', validValues: [92, 93, 94, 95, 96, 97] }
                    ]
                }
            },
            {
                Question3F: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isFosterSafetyConcernNotAddressed', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question3F1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'question3F1', storeId: 'CR_MultiAnswer_CollectionStore', groupName: 'FosterPlacementConcern', actionType: 'lookup', validValues: [98, 99, 100, 101, 102, 103, 104] }
                    ]
                }
            }
        ]
    }
];
var permanencyQuestions = [
    {
        errorsExist: false,
        itemCode: 5,
        outcomeCode: 3,
        ratingItemId: 'permanencyItem4Rating',
        containerId: 'permanencyPanel',
        viewModel: 'permanencyViewModel',
        item4: [
            {
                Question4A: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'numberOfPlacementSettings', dataType: 'number' }
                    ]
                }
            },
            {
                Question4A1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'permanencyCollection', actionType: 'search', nodeToSelect: 'CR_Placement_Collection', validValues: 'gt0' }
                    ]
                }
            },
            {
                Question4B: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'wereAllPlacementChangesPlanned', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question4C: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isCurrentPlacementSettingStable', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question4C1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'question4C1', storeId: 'CR_MultiAnswer_CollectionStore', groupName: 'PlacementApplicableCircumstances', actionType: 'lookup', validValues: [121, 122, 123, 124, 125, 126] }
                    ]
                }
            }
        ]
    },
    {
        errorsExist: false,
        itemCode: 6,
        outcomeCode: 3,
        ratingItemId: 'permanencyItem5Rating',
        containerId: 'permanencyPanel',
        viewModel: 'permanencyViewModel',
        item5: [
            {
                Applicability: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'item5Applicable', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question5A1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'permanencyCollection', actionType: 'search', nodeToSelect: 'CR_Goal_Collection', validValues: 'gt0' }
                    ]
                }
            },
            {
                Question5A2: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'goal1Code', dataType: 'number', validValues: [1, 2, 3, 4] },
                        { name: 'goal2Code', dataType: 'number', validValues: [1, 2, 3, 4, 5] }
                    ]
                }
            },
            {
                Question5A3: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isGoalSpecified', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question5B: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'wereAllGoalsInTimelyManner', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question5C: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'wereAllGoalsAppropriate', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question5D: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isInFoster15OutOf22', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question5E: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'meetsTerminationOfParentalRights', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question5F: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isAgencyJointTerminationOfParentalRights', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question5G: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isExceptionForTermination', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question5G1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'question5G1', storeId: 'CR_MultiAnswer_CollectionStore', groupName: 'TerminationExceptions', actionType: 'lookup', validValues: [138, 139, 140, 141, 142] }
                    ]
                }
            }
        ]
    },
    {
        errorsExist: false,
        itemCode: 7,
        outcomeCode: 3,
        ratingItemId: 'permanencyItem6Rating',
        containerId: 'permanencyPanel',
        viewModel: 'permanencyViewModel',
        item6: [
            {
                Question6A1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'childMostRecentFosterEntryDate', dataType: 'date' }
                    ]
                }
            },
            {
                Question6A2: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'timeInCare', dataType: 'number' }
                    ]
                }
            },
            {
                Question6A3: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'dischargeDate', dataType: 'date' },
                        { name: 'isDischargeDateNA', dataType: 'number', validValues: [1] }
                    ]
                }
            },
            {
                Question6A4: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'permGoal1', dataType: 'boolean', validValues: [true, false], selectedValue: true },
                        { name: 'permGoal2', dataType: 'boolean', validValues: [true, false], selectedValue: true },
                        { name: 'permGoal3', dataType: 'boolean', validValues: [true, false], selectedValue: true },
                        { name: 'permGoal4', dataType: 'boolean', validValues: [true, false], selectedValue: true }
                    ]
                }
            },
            {
                Question6B: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isAgencyConcertedEfforts', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question6C: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isOtherPlannedConcertedEffort', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question6C1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'livingArrangementCode', dataType: 'number', validValues: [1, 2, 3, 4, 5, 6] }
                    ]
                }
            },
            {
                Question6C2: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'otherPlannedArrangementDocumentationDate', dataType: 'date' },
                        { name: 'isOtherPlannedArrangementNA', dataType: 'number', validValues: [1] },
                        { name: 'isOtherPlannedArrangementNoDate', dataType: 'number', validValues: [1] }
                    ]
                }
            }
        ]
    },
    {
        errorsExist: false,
        itemCode: 8,
        outcomeCode: 4,
        ratingItemId: 'permanencyItem7Rating',
        containerId: 'permanencyPanel',
        viewModel: 'permanencyViewModel',
        item7: [
            {
                Applicability: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'item7Applicable', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question7A: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isPlacedWithAllSiblings', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question7B: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isValidReasonForSeparation', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            }
        ]
    },
    {
        errorsExist: false,
        itemCode: 9,
        outcomeCode: 4,
        ratingItemId: 'permanencyItem8Rating',
        containerId: 'permanencyPanel',
        viewModel: 'permanencyViewModel',
        item8: [
            {
                PreApplicability: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'answerCode57', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode58', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode59', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode60', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode61', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode62', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Applicability: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'item8Applicable', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                ApplicabilityMother: {
                    required: false,
                    answered: false,
                    groupId: 'item8ParticipantCheckboxGroupMother'
                }
            },
            {
                ApplicabilityFather: {
                    required: false,
                    answered: false,
                    groupId: 'item8ParticipantCheckboxGroupFather'
                }
            },
            {
                MotherOrFatherApplicable: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'motherOrFatherApplicable', actionType: 'calculation', input: ['item8ParticipantCheckboxGroupMother', 'item8ParticipantCheckboxGroupFather'] }
                    ]
                }
            },
            {
                Question8A: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isSufficientFrequencyForMotherVisitation', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question8A1: {
                    required: true,
                    answered: false,
                    modelProperty: undefined
                }
            },
            {
                Question8B: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isSufficientFrequencyForFatherVisitation', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question8B1: {
                    required: true,
                    answered: false,
                    modelProperty: undefined
                }
            },
            {
                Question8C: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isSufficientQualityForMotherVisitation', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question8D: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isSufficentQualityForFatherVisitation', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question8E: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isSufficientFrequencyForSiblingVisitation', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question8E1: {
                    required: true,
                    answered: false,
                    modelProperty: undefined
                }
            },
            {
                Question8F: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isSufficentQualityForSiblingVisitation', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            }
        ]
    },
    {
        errorsExist: false,
        itemCode: 10,
        outcomeCode: 4,
        ratingItemId: 'permanencyItem9Rating',
        containerId: 'permanencyPanel',
        viewModel: 'permanencyViewModel',
        item9: [
            {
                Applicability: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'item9Applicable', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question9A: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isConcertedEffortsForImportantConnections', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question9B: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isSufficientInquiryForIndianTribe', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question9C: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isTribeProvidedTimelyNotification', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question9D: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isAccordanceWithIndianChildWelfareAct', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            }
        ]
    },
    {
        errorsExist: false,
        itemCode: 11,
        outcomeCode: 4,
        ratingItemId: 'permanencyItem10Rating',
        containerId: 'permanencyPanel',
        viewModel: 'permanencyViewModel',
        item10: [
            {
                Applicability: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'item10Applicable', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question10A1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isRecentPlacementWithRelative', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question10A2: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isPlacementWithRelativeStable', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question10B: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isConcertedEffortToLocateMaternalRelatives', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question10C: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isConcertedEffortToLocatePaternalRelatives', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            }
        ]
    },
    {
        errorsExist: false,
        itemCode: 12,
        outcomeCode: 4,
        ratingItemId: 'permanencyItem11Rating',
        containerId: 'permanencyPanel',
        viewModel: 'permanencyViewModel',
        item11: [
            {
                PreApplicability: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'answerCode63', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode64', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode65', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode66', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode67', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode261', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Applicability: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'item11Applicable', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                ApplicabilityMother: {
                    required: false,
                    answered: false,
                    groupId: 'item11ParticipantCheckboxGroupMother'
                }
            },
            {
                ApplicabilityFather: {
                    required: false,
                    answered: false,
                    groupId: 'item11ParticipantCheckboxGroupFather'
                }
            },
            {
                MotherOrFatherApplicable: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'motherOrFatherApplicable', actionType: 'calculation', input: ['item11ParticipantCheckboxGroupMother', 'item11ParticipantCheckboxGroupFather'] }
                    ]
                }
            },
            {
                Question11A: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isConcertedEffortMotherFosterRelationship', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question11A1: {
                    required: true,
                    answered: false,
                    lookup: { storeId: 'CR_MultiAnswer_CollectionStore', validValues: [164, 165, 166, 167, 168, 169, 170] }
                }
            },
            {
                Question11B: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isConcertedEffortFatherFosterRelationship', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question11B1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'question11B1', storeId: 'CR_MultiAnswer_CollectionStore', groupName: 'EffortsToSupportFatherFosterRelationship', actionType: 'lookup', validValues: [171, 172, 173, 174, 175, 176, 177] }
                    ]
                }
            }
        ]
    }
];
var wellbeingQuestions = [
    {
        errorsExist: false,
        itemCode: 14,
        outcomeCode: 5,
        ratingItemId: 'wellbeingItem12ARating',
        containerId: 'wellbeingPanel',
        viewModel: 'wellbeingViewModel',
        item12A: [
            {
                Question12A1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isComprehensiveAssessementConducted', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question12A2: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isAppropriateServicesProvided', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            }
        ]
    },
    {
        errorsExist: false,
        itemCode: 15,
        outcomeCode: 5,
        ratingItemId: 'wellbeingItem12BRating',
        containerId: 'wellbeingPanel',
        viewModel: 'wellbeingViewModel',
        item12B: [
            {
                PreApplicability: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'answerCode68', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode69', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode70', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode71', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode72', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Applicability: {
                    required: false,
                    answered: false,
                    modelProperty: undefined
                }
            },
            {
                ApplicabilityMother: {
                    required: false,
                    answered: false,
                    modelProperty: [
                        { name: 'isNeedsServicesApplicableForMother', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                ApplicabilityFather: {
                    required: false,
                    answered: false,
                    modelProperty: [
                        { name: 'isNeedsServicesApplicableForFather', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                MotherSelected: {
                    required: false,
                    answered: false,
                    modelProperty: undefined
                }
            },
            {
                FatherSelected: {
                    required: false,
                    answered: false,
                    modelProperty: undefined
                }
            },
            {
                MotherOrFatherApplicable: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'motherOrFatherApplicable', actionType: 'calculation', input: ['item12BParticipantCheckboxGroupMother', 'item12BParticipantCheckboxGroupFather'] }
                    ]
                }
            },
            {
                Question12B1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isComprehensiveAssessementForMotherConducted', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question12B2: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isComprehensiveAssessementForFatherConducted', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question12B3: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isAppropriateServicesForMotherProvided', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question12B4: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isAppropriateServicesForFatherProvided', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            }
        ]
    },
    {
        errorsExist: false,
        itemCode: 16,
        outcomeCode: 5,
        ratingItemId: 'wellbeingItem12CRating',
        containerId: 'wellbeingPanel',
        viewModel: 'wellbeingViewModel',
        item12C: [
            {
                Applicability: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'item12CApplicable', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question12C1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isNeedsOfFosterParentsAdequatelyAssessed', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question12C2: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isFosterParentsProvidedAppropriateServices', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            }
        ]
    },
    {
        errorsExist: false,
        itemCode: 17,
        outcomeCode: 5,
        ratingItemId: 'wellbeingItem13Rating',
        containerId: 'wellbeingPanel',
        viewModel: 'wellbeingViewModel',
        item13: [
            {
                PreApplicability: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'answerCode73', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode74', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode75', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode292', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode76', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode77', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode78', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Applicability: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'item13Applicable', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Mother: {
                    required: false,
                    answered: false,
                    modelProperty: undefined
                }
            },
            {
                Father: {
                    required: false,
                    answered: false,
                    modelProperty: undefined
                }
            },
            {
                MotherOrFatherApplicable: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'motherOrFatherApplicable', actionType: 'calculation', input: ['item13ParticipantCheckboxGroupMother', 'item13ParticipantCheckboxGroupFather'] }
                    ]
                }
            },
            {
                Question13A: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isAgencyConcertedEffortsToInvolveTheChild', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question13B: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isAgencyConcertedEffortsToInvolveTheMother', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question13C: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isAgencyConcertedEffortsToInvolveTheFather', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            }
        ]
    },
    {
        errorsExist: false,
        itemCode: 18,
        outcomeCode: 5,
        ratingItemId: 'wellbeingItem14Rating',
        containerId: 'wellbeingPanel',
        viewModel: 'wellbeingViewModel',
        item14: [
            {
                Question14A: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isResponsiblePartyVisitationFrequencySufficient', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question14A1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'responsiblePartyVisitationFrequencyCode', dataType: 'number', validValues: [2, 3, 4, 5, 6, 7] }
                    ]
                }
            },
            {
                Question14B: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isResponsiblePartyVisitationQualitySufficient', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            }
        ]
    },
    {
        errorsExist: false,
        itemCode: 19,
        outcomeCode: 5,
        ratingItemId: 'wellbeingItem15Rating',
        containerId: 'wellbeingPanel',
        viewModel: 'wellbeingViewModel',
        item15: [
            {
                PreApplicability: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'answerCode79', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode80', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode293', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode81', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode82', dataType: 'number', validValues: [1, 2] },
                        { name: 'answerCode83', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Applicability: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'item15Applicable', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                MotherSelected: {
                    required: false,
                    answered: false,
                    modelProperty: undefined
                }
            },
            {
                FatherSelected: {
                    required: false,
                    answered: false,
                    modelProperty: undefined
                }
            },
            {
                MotherOrFatherApplicable: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'motherOrFatherApplicable', actionType: 'calculation', input: ['item15ParticipantCheckboxGroupMother', 'item15ParticipantCheckboxGroupFather'] }
                    ]
                }
            },
            {
                Question15A1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'responsiblePartyVisitationFrequencyWithMotherCode', dataType: 'number', validValues: [1, 2, 3, 4, 5, 6, 7] }
                    ]
                }
            },
            {
                Question15A2: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isResponsiblePartyVisitationFrequencyWithMotherSufficient', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question15B1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'responsiblePartyVisitationFrequencyWithFatherCode', dataType: 'number', validValues: [1, 2, 3, 4, 5, 6, 7] }
                    ]
                }
            },
            {
                Question15B2: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isResponsiblePartyVisitationFrequencyWithFatherSufficient', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question15C: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isResponsiblePartyVisitationQualityWithMotherSufficient', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question15D: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isResponsiblePartyVisitationQualityWithFatherSufficient', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            }
        ]
    },
    {
        errorsExist: false,
        itemCode: 20,
        outcomeCode: 6,
        ratingItemId: 'wellbeingItem16Rating',
        containerId: 'wellbeingPanel',
        viewModel: 'wellbeingViewModel',
        item16: [
            {
                Applicability: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'item16Applicable', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question16A: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isAgencyAssessEducationNeeds', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question16A1: {
                    required: false,
                    answered: false,
                    modelProperty: [
                        { name: 'wellbeingCollection', actionType: 'search', nodeToSelect: 'CR_Education_Collection', validValues: 'gt0' }
                    ]
                }
            },
            {
                Question16B: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isAgencyAddressEducationNeeds', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            }
        ]
    },
    {
        errorsExist: false,
        itemCode: 21,
        outcomeCode: 7,
        ratingItemId: 'wellbeingItem17Rating',
        containerId: 'wellbeingPanel',
        viewModel: 'wellbeingViewModel',
        item17: [
            {
                Applicability: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'item17Applicable', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question17A1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isAgencyAssessPhysicalHealthNeeds', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question17A2: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isAgencyAssessDentalHealthNeeds', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question17A3: {
                    required: false,
                    answered: false,
                    modelProperty: [
                        { name: 'wellbeingCollection', actionType: 'search', nodeToSelect: 'CR_Health_Collection', needCode: 1, validValues: 'gt0' }
                    ]
                }
            },
            {
                Question17A4: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'question17A4', storeId: 'CR_MultiAnswer_CollectionStore', groupName: 'FosterFederalCaseManagamentCriteria', actionType: 'lookup', validValues: [178, 179, 180, 181, 182] }
                    ]
                }
            },
            {
                Question17B1: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isFosterOversightMedicationForPhysicalHealtyAppropriate', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question17B2: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isAppropriateSerivcesForAllPhysicalHealthNeeds', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question17B3: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isAppropriateServicesForAllDentalNeeds', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            }
        ]
    },
    {
        errorsExist: false,
        itemCode: 22,
        outcomeCode: 7,
        ratingItemId: 'wellbeingItem18Rating',
        containerId: 'wellbeingPanel',
        viewModel: 'wellbeingViewModel',
        item18: [
            {
                Applicability: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'item18Applicable', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question18A: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isAgencyAssessMentalHealthNeeds', dataType: 'number', validValues: [1, 2] }
                    ]
                }
            },
            {
                Question18A1: {
                    required: false,
                    answered: false,
                    modelProperty: [
                        { name: 'wellbeingCollection', actionType: 'search', nodeToSelect: 'CR_Health_Collection', needCode: 2, validValues: 'gt0' }
                    ]
                }
            },
            {
                Question18B: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isFosterOversightMedicationForMentalHealtyAppropriate', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            },
            {
                Question18C: {
                    required: true,
                    answered: false,
                    modelProperty: [
                        { name: 'isAppropriateSerivcesForMentalHealthNeeds', dataType: 'number', validValues: [1, 2, 3] }
                    ]
                }
            }
        ]
    }
];
var getFacesheetQuestions = function () {

    return facesheetQuestions;
}
var getSafetyQuestions = function () {

    return safetyQuestions;
}
var getPermanencyQuestions = function () {

    return permanencyQuestions;
}
var getWellbeingQuestions = function () {

    return wellbeingQuestions;
}
var getItemQuestion = function (sourceName, itemName) {

    var itemQuestions;
    var source = [];

    switch (sourceName) {

        case 'facesheet':

            source = getFacesheetQuestions();
            break;

        case 'safety':

            source = getSafetyQuestions();
            break;

        case 'permanency':

            source = getPermanencyQuestions();
            break;

        case 'wellbeing':

            source = getWellbeingQuestions();
            break;

        default:

            break;
    }

    var filteredResult = source.filter(function (item) {

        return item.hasOwnProperty(itemName) && !Ext.isEmpty(item[itemName]);
    });

    if (filteredResult && filteredResult.length > 0) {

        itemQuestions = filteredResult[0];
    }

    return itemQuestions;
};
var getAppUsers = function () {

    var crsAppUsers;

    if (!Ext.isEmpty(qaNotesSummary)) {

        crsAppUsers = Ext.create('Ext.data.Store', {
            model: 'Reviewer',
            data: qaNotesSummary.getUsers()
        });
    }

    return crsAppUsers;
}
var getAppItems = function () {

    var crsAppItems;

    if (!Ext.isEmpty(qaNotesSummary)) {

        crsAppItems = Ext.create('Ext.data.Store', {
            model: 'itemModel',
            data: qaNotesSummary.getItems()
        });
    }

    return crsAppItems;
}
var getItemQuestions = function (itemName) {

    var result = [];
    var itemWithQuestions;

    switch (itemName) {

        case 'facesheet':

            itemWithQuestions = getItemQuestion('facesheet', itemName);

            break;

        case 'item1':
        case 'item2':
        case 'item3':

            itemWithQuestions = getItemQuestion('safety', itemName);

            break;

        case 'item4':
        case 'item5':
        case 'item6':
        case 'item7':
        case 'item8':
        case 'item9':
        case 'item10':
        case 'item11':

            itemWithQuestions = getItemQuestion('permanency', itemName);

            break;

        case 'item12A':
        case 'item12B':
        case 'item12C':
        case 'item13':
        case 'item14':
        case 'item15':
        case 'item16':
        case 'item17':
        case 'item18':

            itemWithQuestions = getItemQuestion('wellbeing', itemName);

            break;

        default:

            break;
    }

    if (!Ext.isEmpty(itemWithQuestions)) {

        result.push(itemWithQuestions);
    }

    return result;
}
var getAppController = function () {

    if (Ext.isEmpty(appController)) {

        appController = window.App.getApplication().controllers.items[0];
    }

    return appController;
}
var getItemStatuses = function () {

    return itemStatuses;
}
var getCRSComponent = function (itemId, container) {

    if (Ext.isEmpty(itemId)) {

        return undefined;
    }

    if (!appPages['DataReady']) {

        setAppPages();
    }

    var component;

    if (!Ext.isEmpty(getAppController())) {

        if (getAppController().references.indexOf(itemId.toLowerCase()) > -1) {

            var functionName = 'get' + itemId.charAt(0).toUpperCase() + itemId.slice(1);

            component = getAppController()[functionName]();

            return component;
        }
    }

    if (Ext.isEmpty(container)) {

        component = Ext.ComponentQuery.query('#' + itemId)[0];
    } else {

        component = container.queryById(itemId);
    }

    return component;
}
var getHashCode = function (text) {

    var hashCode = 0, i, chr, len;

    if (Ext.isEmpty(text)) {

        return hashCode;
    }

    if (text.length === 0) {

        return hashCode;
    }

    for (i = 0, len = text.length; i < len; i++) {

        chr = text.charCodeAt(i);

        hashCode = ((hashCode << 5) - hashCode) + chr;

        hashCode |= 0;
    }

    return hashCode;
}
var getMaxReportDate = function () {

    var maxDate = Ext.isEmpty(Ext.StoreManager.get('CaseReviewStore')) ? new Date() : Ext.StoreManager.get('CaseReviewStore').getAt(0).data.ReviewCompleted;

    return maxDate;
}
var removeDuplicatesFromJsonArray = function (arr, keyParms) {

    var objectStore = {},
        result = [],
        key,
        keyObj;

    var computeObjectKey = function (obj) {

        var objText = JSON.stringify(obj);

        var computedKey = getHashCode(objText);

        return computedKey;
    };

    Ext.each(arr, function (arrObj) {

        if (Ext.isEmpty(keyParms)) {

            key = computeObjectKey(arrObj);
        } else {

            keyObj = {};

            Ext.each(keyParms, function (keyParm) {

                keyObj[keyParm] = arrObj[keyParm];
            });

            key = computeObjectKey(keyObj);
        }

        var existingObj = objectStore[key];

        if (Ext.isEmpty(existingObj)) {

            objectStore[key] = arrObj;
            result.push(arrObj);
        }
    });

    return result;
}
var removeInvalidNotes = function (notes) {

    var result = [];

    Ext.each(notes, function (note) {

        if (!Ext.isEmpty(note.ItemID) &&
           !Ext.isEmpty(note.Description) &&
           !Ext.isEmpty(note.Subject)) {

            result.push(note);
        }
    });

    return result;
}
var getCaseClosureDate = function () {

    var facesheetStore = chainedStore('CR_FaceSheet_CollectionStore');
    var closureDate;

    if (Ext.isEmpty(facesheetStore)) {

        return closureDate;
    }

    if (Ext.isEmpty(facesheetStore.getAt(0).data)) {

        return closureDate;
    }

    closureDate = facesheetStore.getAt(0).data.CaseClosureDate;

    return closureDate;
}
var changeDataState = function (store, parent) {

    var dataState = {
        Added: 0,
        Deleted: 1,
        Detached: 2,
        Modified: 3,
        Unchanged: 4
    };

    var data = store.first();
    if (!data) {
        return;
    }

    // Get lowest level child that has been added or modified.
    var lowestLevelChild = GetLowestLevelChild(store, 'store', parent);

    // Update data state of parent if necessary
    if (!(lowestLevelChild.child == undefined)) {
        var parentStore = chainedStore(lowestLevelChild.parent.storeId);

        // This is strictly a fix, I dont like the solution but I cannot fix it any other way so that other things start working.
        // Whatever is the logic to mark everything which needs to be added needed to be revisited.
        if (!(lowestLevelChild.parent.storeId == "CR_Outcome_CollectionStore" && parentStore.getAt(0).data["OutcomeCode"] == 0)) {
            parentStore.getAt(0).data["DataState"] = dataState.Added;

            if (!(lowestLevelChild.grandParent == undefined)) {
                var grandParentStore = chainedStore(lowestLevelChild.grandParent.store.storeId);

                var gParent = Ext.isEmpty(grandParentStore) ? undefined : grandParentStore.getAt(0);

                if (!(Ext.isEmpty(gParent)) && !!gParent.data) {
                    grandParentStore.getAt(0).data["DataState"] = dataState.Added;
                }
            }
        }
    }

    for (var iRecord = 0; iRecord < store.count() ; iRecord++) {
        data = store.getAt(iRecord);
        for (var property in data.data) {
            if (data.data.hasOwnProperty(property) && property !== 'store') {
                var propertyValue = data.data[property];
                if (typeof propertyValue !== 'undefined' && !!data[property] && propertyValue !== null && propertyValue.constructor === Array) {
                    var childStore = Ext.StoreManager.get(property + 'Store');
                    if (Ext.isEmpty(childStore)) {
                        childStore = Ext.StoreManager.get(data.data["ExtId"]);
                    }

                    if (!Ext.isEmpty(childStore) && childStore.count() > 0) {

                        changeDataState(childStore, data);
                    }
                }
            }
        }
    }
};
var getMultiAnswerStore = function (groupName, groupMembers, itemName) {
    //
    // Update GroupName, if needed
    //
    var filteredStore;
    var multiAnswerStore;

    if (Ext.isEmpty(groupName)) {

        return multiAnswerStore;
    }

    var unFilteredStore = getFilteredMultiAnswerStore(groupName);

    if (!Ext.isEmpty(unFilteredStore)) {

        if (groupName == 'Applicability') {

            filteredStore = unFilteredStore.filter(function (record) {

                return record.DescriptionSmall == itemName;
            });

        } else {

            filteredStore = unFilteredStore;
        }

        var store = chainedStore('CR_MultiAnswer_CollectionStore'),
            storeItem;

        Ext.each(filteredStore, function (record) {

            storeItem = store.data.items.filter(function (item) {

                return item.data.CodeDescriptionID == record.CodeDescriptionID &&
                       !(item.data.GroupName == groupName);
            });
            
            if (storeItem && storeItem.length > 0) {

                storeItem[0].data.GroupName = groupName;
            }
        });

        multiAnswerStore = Ext.data.ChainedStore.create({
            source: store,
            filters: [
                function (record) {
                    return record.data.GroupName == groupName;
                }
            ]
        });
    }

    return multiAnswerStore;
}
var getDefaultItemValues = function (itemCode) {

    var result = {};
    var caseType = getCaseType();

    switch (itemCode) {

        case 4:

            result['IsApplicable'] = 1;

            break;

        case 5:

            if (caseType == 'Foster Case') {

                result['IsApplicable'] = 1;
                result['Goal2Code'] = 5;
            }

            break;

        case 7:
        case 13:
        case 14:
        case 18:

            if (caseType == 'Foster Case') {

                result['IsApplicable'] = 1;
            }

            break;

        default:

            break;
    }

    return result;
};
var updateDefaultValues = function (item) {

    if (Ext.isEmpty(item)) {

        return item;
    }

    var defaultValues = getDefaultItemValues(item.ItemCode);

    if (Ext.isEmpty(defaultValues.IsApplicable) && Ext.isEmpty(defaultValues.Goal2Code)) {

        return item;
    }

    var parms = {};

    if (!Ext.isEmpty(defaultValues.IsApplicable)) {

        item.IsApplicable = defaultValues.IsApplicable;
    }

    if (!Ext.isEmpty(defaultValues.Goal2Code)) {
        //
        // Update permanency store
        //
        var fields = [];
        var field = { 'Goal2Code': defaultValues.Goal2Code };

        fields.push(field);

        parms['storeId'] = 'CR_Permanency_CollectionStore';
        parms['fields'] = fields;

        updateStore(parms);
    }

    return item;
};
var setItemNotApplicableComplete = function (parms) {
    
    if (Ext.isEmpty(parms)) {

        return false;
    }

    if (Ext.isEmpty(parms.ItemCode)) {

        return false;
    }

    var item = getItem(parms.ItemCode, getOutcomeCode(parms.ItemCode));

    if (Ext.isEmpty(item)) {

        return false;
    }

    if (item.IsApplicable == 2) {
        //
        // Set all questions to answered
        //
        var question = getItemQuestions(parms.ItemName)[0];

        if (!Ext.isEmpty(question)) {

            var questions;
            errorsExist = question.errorsExist;

            if (question.hasOwnProperty(parms.ItemName) && question[parms.ItemName]) {

                questions = question[parms.ItemName];
            }

            var props = { QuestionsObj: question };

            Ext.each(questions, function (qItem) {

                for (key in qItem) {

                    props['ItemName'] = parms.ItemName;
                    props['Question'] = key;
                    props['Answered'] = true;

                    updateQuestionsAnswered(props);
                }
            });
        }

        return true;
    }

    return false;
};
var setAppPages = function () {

    appPages = {};
    appPages['DataReady'] = true;

    appPages['Facesheet'] = Ext.ComponentQuery.query('#facesheetCenterPanel')[0];
    appPages['Safety'] = Ext.ComponentQuery.query('#safetyPanel')[0];
    appPages['Permanency'] = Ext.ComponentQuery.query('#permanencyPanel')[0];
    appPages['Wellbeing'] = Ext.ComponentQuery.query('#wellbeingPanel')[0];

    if (Ext.isEmpty(appPages['Facesheet']) || Ext.isEmpty(appPages['Safety']) ||
       Ext.isEmpty(appPages['Permanency']) || Ext.isEmpty(appPages['Wellbeing'])) {

        appPages['DataReady'] = false;
    }
};
var updateLocationHref = function (tabId) {

    if (Ext.isEmpty(tabId)) {

        return;
    }

    var newUrl = window.baseUrl + "/CaseReview/Index/" + window.caseReviewRootId + "?activetab=" + tabId;

    history.replaceState({}, document.title, newUrl);
};
var updateOverviewPage = function () {

    var ratingComponent;
    var overviewPage = getAppController().getOverviewCenter();

    if (Ext.isEmpty(overviewPage)) {

        return;
    }

    //
    // Update all itemStatus components
    //
    var statusComponents = overviewPage.query('[xtype = itemStatus]');

    Ext.each(statusComponents, function (statCmp) {

        var status = statCmp.getItemStatus();

        statCmp.updateItemStatusDesc(status);

        statCmp.updateLayout();
    });

    //
    // Update all rating components
    //
    Ext.each(itemRatings.OverviewRatingItems, function (ratingItem) {

        ratingComponent = getCRSComponent(ratingItem.itemId, overviewPage);

        if (Ext.isEmpty(ratingItem.ratingItemId) && Ext.isEmpty(ratingItem.appPage)) {

            ratingComponent.setHtml(itemRatings.getItem12Rating());
        } else {

            var page = ratingItem.appPage == 'safety' ? appPages.Safety :
                       ratingItem.appPage == 'permanency' ? appPages.Permanency :
                       ratingItem.appPage == 'wellbeing' ? appPages.Wellbeing : undefined;

            ratingComponent.setHtml(getItemRatingDesc(ratingItem.ratingItemId, page));
        }

        ratingComponent.updateLayout();
    });

    //
    // Update all outcome ratings
    //
    var outcomeRating;
    var caseType = getCaseType();

    Ext.each(itemRatings.OverviewOutcomeItems, function (outcomeItem) {

        ratingComponent = getCRSComponent(outcomeItem.itemId, overviewPage);

        outcomeRating = 'Not Yet Determined';

        switch (outcomeItem.itemId) {

            case 'safetyOutcome1RatingDesc':

                outcomeRating = Ext.isEmpty(outcomeRatings.safety.outcome1.ratingDescription) ? outcomeRating :
                                outcomeRatings.safety.outcome1.ratingDescription;

                break;

            case 'safetyOutcome2RatingDesc':

                outcomeRating = Ext.isEmpty(outcomeRatings.safety.outcome2.ratingDescription) ? outcomeRating :
                                outcomeRatings.safety.outcome2.ratingDescription;

                break;

            case 'permanencyOutcome1RatingDesc':

                if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

                    outcomeRating = 'Not Applicable';
                } else {

                    outcomeRating = Ext.isEmpty(outcomeRatings.permanency.outcome1.ratingDescription) ? outcomeRating :
                                    outcomeRatings.permanency.outcome1.ratingDescription;
                }

                break;

            case 'permanencyOutcome2RatingDesc':

                if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

                    outcomeRating = 'Not Applicable';
                } else {

                    outcomeRating = Ext.isEmpty(outcomeRatings.permanency.outcome2.ratingDescription) ? outcomeRating :
                                    outcomeRatings.permanency.outcome2.ratingDescription;
                }

                break;

            case 'wellbeingOutcome1RatingDesc':

                outcomeRating = Ext.isEmpty(outcomeRatings.wellbeing.outcome1.ratingDescription) ? outcomeRating :
                                outcomeRatings.wellbeing.outcome1.ratingDescription;

                break;

            case 'wellbeingOutcome2RatingDesc':

                outcomeRating = Ext.isEmpty(outcomeRatings.wellbeing.outcome2.ratingDescription) ? outcomeRating :
                                outcomeRatings.wellbeing.outcome2.ratingDescription;

                break;

            case 'wellbeingOutcome3RatingDesc':

                outcomeRating = Ext.isEmpty(outcomeRatings.wellbeing.outcome3.ratingDescription) ? outcomeRating :
                                outcomeRatings.wellbeing.outcome3.ratingDescription;

                break;

            default:

                break;
        }
        //
        // Update outcome rating
        //
        ratingComponent.setHtml(outcomeRating);

        updateCaseStatus();

        ratingComponent.updateLayout();
    });

    overviewPage.updateLayout(true);
};
var updateGrids = function (tabName) {

    var refreshGrid = function (panel) {

        var grids = panel.query('[xtype=gridpanel]');

        Ext.each(grids, function (grid) {

            grid.getView().refresh();
        });
    };

    var panel = null;

    switch (tabName) {

        case 'faceSheet':

            panel = getAppController().getFacesheetCenterPanel();
            break;

        case 'safety':

            panel = getAppController().getSafetyPanel();
            break;

        case 'permanency':

            panel = getAppController().getPermanencyPanel();
            break;

        case 'wellBeing':

            panel = getAppController().getWellbeingPanel();
            break;
    }

    if (panel) {
        refreshGrid(panel);
    }
};
var getOutcomeRatingDesc = function (itemId, page) {

    if (Ext.isEmpty(itemId)) {

        return '';
    }

    var ratingComponent = getCRSComponent(itemId, page);

    var ratingDesc = ratingComponent.getOutcomeRatingText(ratingComponent.outcomeCode);

    return ratingDesc;
};
var getItemRatingDesc = function (itemId, page) {

    if (Ext.isEmpty(itemId)) {

        return '';
    }

    var ratingComponent = getCRSComponent(itemId, page);

    if (Ext.isEmpty(ratingComponent)) {

        return '';
    }

    var rating = ratingComponent.getRatingText();

    return rating.CodeDescription;
};
// 
// Determine if record is blank
var isRecordEmpty = function (record) {

}
// Get lowest level child that has been added or modified.
var GetLowestLevelChild = function (store, objectType, parent) {

    var lowestLevelChild = {};

    var childCollectionInStore = function () {

        var result = [];

        Ext.each(store.data.items, function (item) {

            for (key in item.data) {
                
                if (item.data.hasOwnProperty(key) && item.data[key]) {

                    var value = item.data[key];

                    if (value.constructor === Array) {

                        var objColl = {};

                        objColl[key] = value;
                        objColl['parent'] = parent;

                        result.push(objColl);
                    }

                    //if (typeof value !== 'undefined' && !!item[key] && value !== null && value.constructor === Array) {

                    //    var objColl = {};

                    //    objColl[key] = value;
                    //    objColl['parent'] = parent;

                    //    result.push(objColl);
                    //}
                }
            }
        });

        return result;

    };

    var childCollectionInObject = function (nonStoreObj, parent) {

        var result = [];

        for (key in nonStoreObj) {

            if (nonStoreObj.hasOwnProperty(key)) {

                var value = nonStoreObj[key];

                if (typeof value !== 'undefined' && !!nonStoreObj[key] && value !== null && value.constructor === Array) {

                    var objColl = {};

                    objColl[key] = value;
                    objColl['parent'] = parent;

                    result.push(objColl);
                }
            }
        }

        return result;

    };

    var coll = objectType == 'store' ? childCollectionInStore() : childCollectionInObject(store, parent);

    Ext.each(coll, function (childStore) {

        var key = getObjectKeys(childStore)[0];

        Ext.each(childStore[key], function (child) {

            if (child.DataState == 0 || child.DataState == 3) {
                lowestLevelChild['child'] = child;
                lowestLevelChild['parent'] = store;
                lowestLevelChild['grandParent'] = childStore.parent;
            }

            GetLowestLevelChild(child, 'object', store);
        });
    });

    return lowestLevelChild;
}
var getTimeInterval = function (milliSec, unit) {

    switch (unit) {

        case 'second':

            return  milliSec / 1000;
           
        case 'minute':

            return milliSec / (1000 * 60);                       

        case 'hour':

            return milliSec / (1000 * 60 * 60);

        case 'day':

            return milliSec / (1000 * 60 * 60 * 24);

        case 'year':

            return milliSec / (1000 * 60 * 60 * 24 * 365.25);

        default:

            return milliSec / (1000 * 60 * 60 * 24);
    }
}
var isValidDate = function (dateString) {

    var validDate = false;

    var date = Date.parse(dateString);

    if (!isNaN(date)) {

        validDate = true;
    }

    return validDate;
}
var getDateDiff = function (startDate, endDate, unit) {

    var date1, date2, dateDiff;

    if (Ext.isEmpty(startDate) || Ext.isEmpty(endDate)) {

        return 0;
    }

    if (isValidDate(startDate) && isValidDate(endDate)) {

        date1 = Date.parse(startDate);
        date2 = Date.parse(endDate);

        dateDiff = getTimeInterval(date2 - date1, unit);

        return Math.round(dateDiff);
    }

    return undefined;
}
var getTimeInFosterCare = function (period) {

    var fosterEntryDate;  // Facesheet question J
    var dischargeDate;    // Facesheet question K
    var notYetDischarged;
    var dischargeDateNA;
    var daysInFosterCare = 0;

    if (Ext.isEmpty(period)) {

        return undefined;
    }

    // Get facesheet data
    var facesheetStore = Ext.data.ChainedStore.create({
        source: 'CR_FaceSheet_CollectionStore'
    });

    fosterEntryDate = facesheetStore.getAt(0).data.FosterEntryDate;
    dischargeDate = facesheetStore.getAt(0).data.EpisodeDischargeDate;
    notYetDischarged = facesheetStore.getAt(0).data.IsEpisodeNotYetDischarged == 1 ? true : false;
    dischargeDateNA = facesheetStore.getAt(0).data.IsEpisodeDischargeDateNA;

    if (!Ext.isEmpty(fosterEntryDate)) {
        if (Ext.isEmpty(dischargeDate)) {
            if ((notYetDischarged) || dischargeDateNA == 1) {

                var caseReviewStore = Ext.data.ChainedStore.create({
                    source: 'CaseReviewStore'
                });

                dischargeDate = caseReviewStore.getAt(0).data.ReviewCompleted;
            }
        }

        daysInFosterCare = getDateDiff(fosterEntryDate, dischargeDate, period);

        return daysInFosterCare;
    }

    return undefined;
}
var getFosterEntryDate = function () {

    var fosterEntryDate;  // Facesheet question J

    // Get facesheet data
    var facesheetStore = Ext.data.ChainedStore.create({
        source: 'CR_FaceSheet_CollectionStore'
    });

    if (Ext.isEmpty(facesheetStore)) {

        return fosterEntryDate;
    }

    fosterEntryDate = facesheetStore.getAt(0).data.FosterEntryDate;

    return fosterEntryDate;
};
var getFosterDischargeDate = function () {

    var dischargeDate;    // Facesheet question K

    // Get facesheet data
    var facesheetStore = Ext.data.ChainedStore.create({
        source: 'CR_FaceSheet_CollectionStore'
    });

    if (Ext.isEmpty(facesheetStore)) {

        return dischargeDate;
    }

    dischargeDate = facesheetStore.getAt(0).data.EpisodeDischargeDate;

    return dischargeDate;
};
var getOutcomeCode = function (itemCode) {

    var outcomeCode;

    switch (itemCode) {

        case 2:

            return 1;

        case 3:
        case 4:

            return  2;

        case 5:
        case 6:
        case 7:

            return  3;

        case 8:
        case 9:
        case 10:
        case 11:
        case 12:

            return  4;

        case 13:
        case 14:
        case 15:
        case 16:
        case 17:
        case 18:
        case 19:

            return  5;

        case 20:

            return  6;

        case 21:
        case 22:

            return  7;

        case 23:

            return 21;
    }

    return outcomeCode;
};
var setDisableFieldValues = function (comp) {

    if (Ext.isEmpty(comp)) {

        return;
    }

    var disabledItems = comp.query("{isDisabled()}");

    if (Ext.isEmpty(disabledItems)) {

        return;
    }

    var removeHealthRecords = function (healthCode) {

        var storeId = comp.store.source.storeId,
            store = Ext.data.StoreManager.lookup(storeId),
            searchResult = store.data.items.filter(function (rec) {

                return rec.data.HealthNeedCode == healthCode;
            });

        store.remove(searchResult);

        comp.getView().refresh();
    };

    Ext.each(disabledItems, function (element) {

        if (!Ext.isEmpty(element)) {
            switch (element.xtype) {
                case 'radio':

                    element.setValue(false);
                    break;

                case 'textfield':
                case 'textarea':
                case 'textareafield':
                case 'numberfield':
                case 'datefield':
                case 'checkbox':
                case 'checkboxfield':
                case 'displayfield':

                    element.setValue(null);

                    break;

                case 'combobox':

                    var store = element.store;

                    break;

                default:

                    break;
            }
        }
    });

    if (disabledItems.length > 0) {

        if (comp.xtype == 'gridpanel') {

            var storeId = comp.store.storeId,
                store = null,
                updatedStore = null;

            if (comp.itemId == 'pdHealthGrid') {

                removeHealthRecords(1);

                return;
            }

            if (comp.itemId == 'mbHealthGrid') {

                removeHealthRecords(2);

                return;
            }

            store = Ext.data.StoreManager.lookup(storeId);

            updatedStore = store.removeAll(true);

            comp.getView().refresh();
        }

        if (comp.xtype == 'checkboxgroup' || comp.xtype == 'boundcheckboxgroup') {

            comp.suspendEvents();

            comp.reset();

            comp.resumeEvents();
        }

        if (comp.xtype == 'validationMessage') {

            comp.resetMessages();
        }
    }
};
var deleteFieldValues = function (elementIds) {

    if (Ext.isEmpty(elementIds)) {

        return;
    }

    Ext.each(elementIds, function (elementId) {

        var element = getCRSComponent(elementId);

        element.setValue(null);
    });
}
var setDisabledFieldValuesInContainer = function (containerIds) {

    if (Ext.isEmpty(containerIds)) {

        return;
    }

    var container;

    Ext.each(containerIds, function (containerId) {

        container = getCRSComponent(containerId);

        setDisableFieldValues(container);
    });
}
var disableContainerItems = function (containerIds, exceptions) {

    if (Ext.isEmpty(containerIds)) {

        return;
    }

    Ext.each(containerIds, function (containerId) {

        var container = getCRSComponent(containerId);

        if (!Ext.isEmpty(exceptions)) {

            var components = container.items;
            var includeItem = true;

            var itemsToDisable = components.items.filter(function (item) {

                includeItem = true;

                Ext.each(exceptions, function (exceptionItemId) {

                    if (item.itemId == exceptionItemId) {

                        includeItem = false;
                    }
                });

                if (includeItem) {

                    item.disable(true);

                    return item;
                }
            });
        } else {

            if (container.xtype == 'container' || container.xtype == 'panel') {

                container.cascade(function () { container.disable(true) });
            } else {

                container.disable(true);
            }
        }
    });
};
var enableContainerItems = function (containerIds) {

    if (Ext.isEmpty(containerIds)) {

        return;
    }

    Ext.each(containerIds, function (containerId) {

        var container = getCRSComponent(containerId);

        if (container.isDisabled()) {

            if (container.xtype == 'container' || container.xtype == 'panel') {

                container.cascade(function () { container.enable(true) });
            } else {

                container.enable(true);
            }
        } else {

            var components = container.items;

            Ext.each(components.items, function (item) {

                item.enable(true);
            });
        }
    });
};
var getNoOfSiblings = function () {

    var store = chainedStore('CR_CaseParticipant_CollectionStore');
    var noSiblings = 0;

    Ext.each(store.data.items, function (item) {

        if (item.data.RelationshipToChild == 'Brother' || item.data.RelationshipToChild == 'Sister') {
            noSiblings++;
        }
    });

    return noSiblings;
};
var getCaseType = function () {

    var store = chainedStore('CaseReviewStore');

    if (Ext.isEmpty(store)) {

        return result;
    }

    var reviewSubTypeId = store.getAt(0).data.ReviewSubTypeID;

    switch (reviewSubTypeId) {

        case 17:
        case 19:
        case 21:
        case 22:
        case 25:
        case 27:
            return 'In-Home Services';

        case 18:
        case 20:
        case 26:
            return 'Foster Case';

        case 23:
        case 28:
            return 'Juvenile Justice';

        case 24:
        case 29:
            return 'Behavioral Health';

        default:
            return null;
    }
};
var getNoOfChildren = function () {

    var store = chainedStore('CR_ChildDemographic_CollectionStore');

    if (Ext.isEmpty(store)) {

        return 0;
    }

    if (Ext.isEmpty(store.data)) {

        return 0;
    }

    return store.data.length;
};
var isRelationshipSpecified = function (relation) {

    if (Ext.isEmpty(relation)) {

        return false;
    }

    var store = chainedStore('CR_CaseParticipant_CollectionStore');
    var retval = false;

    if (Ext.isEmpty(store)) {

        return retval;
    }

    if (Ext.isEmpty(store.data)) {

        return retval;
    }

    Ext.each(store.data.items, function (item) {

        if (item.data.RelationshipToChild == relation) {

            retval = true;

            return false;
        }
    });

    return retval;
};
var isParentSelected = function (participantGroup) {

    var result = false;

    if (Ext.isEmpty(participantGroup)) {

        return result;
    }

    if (Ext.isEmpty(participantGroup.items)) {

        return result;
    }

    Ext.each(participantGroup.items.items, function (parent) {

        if (parent.checked) {

            result = true;

            return false;
        }
    });

    return result;
}
var isNonOPPLAGoalsSelected = function () {

    var store = Ext.data.StoreManager.lookup('CR_Permanency_CollectionStore');

    if (Ext.isEmpty(store)) {

        return false;
    }

    if (Ext.isEmpty(store.data)) {

        return false;
    }

    var goal1 = store.data.length == 0 ? '' : store.getAt(0).data.Goal1Code;
    var goal2 = store.data.length == 0 ? '' : store.getAt(0).data.Goal2Code;

    if (!(goal1 == 4) && !(goal2 == 4)) {

        return true;
    }

    return false;
};
var changeReviewId = function (store) {

    if (Ext.isEmpty(store)) {

        return;
    }

    for (var iCount = 0; iCount < store.count() ; iCount++) {

        var data = store.getAt(iCount);
        var lookupStore = Ext.StoreMgr.get('CrSecurityUserStore');
        var results = lookupStore.query('UserID', data.data['UserID'], false, false, true);

        if (results.length > 0) {

            data.data["FirstName"] = results.getAt(0).data.FirstName;
            data.data["LastName"] = results.getAt(0).data.LastName;
            data.data["FullName"] = results.getAt(0).data.FirstName + " " + results.getAt(0).data.LastName;
        }
    }
}
var getNumberOfResponses = function (answers) {

    var noResponses = 0;

    if (Ext.isEmpty(answers)) {

        return noResponses;
    }

    Ext.each(answers, function (answer) {

        if (!Ext.isEmpty(answer)) {

            noResponses++;
        }
    });

    return noResponses;
}
var getSavedStatusCode = function (itemCode) {

    var statusCode;

    if (Ext.isEmpty(itemCode)) {

        return statusCode;
    }

    var item = getItem(itemCode, getOutcomeCode(itemCode));

    var statusCode = Ext.isEmpty(item) ? 3 : Ext.isEmpty(item.StatusCode) ? 3 : item.StatusCode;

    return statusCode;
}
var getItemStatusCode = function (statusDesc) {

    switch (statusDesc) {

        case 'Completed':
            return 1;

        case 'In Progress':
            return 2;

        case 'Not Started':
            return 3;

        case 'Not Applicable':
            return 4;

        default:
            return null;
    }
}
var getItemStatus = function (itemCode) {

    var status = 'Not Started';

    var item = getItemFromGraph(itemCode, getOutcomeCode(itemCode));

    if (!Ext.isEmpty(item)) {

        status = item.StatusCode == 1 ? 'Completed' :
             item.StatusCode == 2 ? 'In Progress' :
             item.StatusCode == 3 ? 'Not Started' :
             item.StatusCode == 4 ? 'Not Applicable' : 'Invalid Status';
    }

    return status;
}
var updateItemNAStatus = function (itemObj) {

    if (Ext.isEmpty(itemObj)) {

        return;
    }

    var itemStatus = itemStatuses[itemObj.ItemName];

    var updateStatusCode = function (parms) {

        if (!Ext.isEmpty(itemStatus)) {

            var inputObj = { ItemCode: parms.ItemCode, OutcomeCode: parms.OutcomeCode, StatusDesc: itemStatus };

            updateItemStatusCode(inputObj);
        }
    };

    updateStatusCode(itemObj);

    if (itemObj.ItemName == 'item12A' || itemObj.ItemName == 'item12B' || itemObj.ItemName == 'item12C') {

        itemStatus = calculateItem12Status();

        var item12Parms = { ItemCode: 13, OutcomeCode: 5 };

        updateStatusCode(item12Parms);
    }
}
var updateItemStatusCode = function (obj) {

    if (Ext.isEmpty(obj)) {

        return;
    }

    var statusCode = getItemStatusCode(obj.StatusDesc);
    var item = getItemFromGraph(obj.ItemCode, obj.OutcomeCode);

    if (Ext.isEmpty(item)) {
        // Create item
        var inputObj = { objectType: 'item', outcomeCode: obj.OutcomeCode, DataState: 0, objValue: obj };
        addCRSObject(inputObj);

        item = getItemFromGraph(obj.ItemCode, obj.OutcomeCode);
    }

    if (!Ext.isEmpty(item)) {
        item.StatusCode = statusCode;
        item.DataState = 0;
        item['OutcomeCode'] = obj.OutcomeCode;

        updateItem(item);

        var itemName = getItemNameFromCode(obj.ItemCode);

        itemStatuses[itemName] = obj.StatusDesc;
    }
};
var updateQuestionsAnswered = function (parms) {

    if (Ext.isEmpty(parms)) {

        return;
    }

    var questionObj = Ext.isArray(parms.QuestionsObj) ? parms.QuestionsObj[0] : parms.QuestionsObj;

    if (!Ext.isEmpty(questionObj)) {

        if (questionObj.hasOwnProperty(parms.ItemName) && questionObj[parms.ItemName]) {

            var questions = questionObj[parms.ItemName],
                filteredQuestion = questions.filter(function (question) {

                    return question.hasOwnProperty(parms.Question) && question[parms.Question];
                });

            if (filteredQuestion && filteredQuestion.length > 0) {

                filteredQuestion[0][parms.Question].answered = parms.Answered;
            }
        }
    }
}
var verifyQuestionsAnswered = function (obj) {

    var itemQuestions;
    var itemName;
    var vModel;

    if (Ext.isEmpty(obj)) {

        return;
    }

    var getCollection = function (parms) {

        var result;
        var collection;

        switch (parms.questionObj.name) {

            case 'facesheetData':

                collection = window.facesheetViewModel.data.facesheetData.getAt(0).data;

                if (parms.questionObj.nodeToSelect == 'CR_ChildDemographic_Collection') {

                    result = collection.CR_ChildDemographic_Collection;

                    break;
                }

                if (parms.questionObj.nodeToSelect == 'CR_CaseParticipant_Collection') {

                    result = collection.CR_CaseParticipant_Collection;
                }

                break;

            case 'safetyCollection':

                collection = window.safetyViewModel.data.safetyCollection.getAt(0).data;

                if (parms.questionObj.nodeToSelect == 'CR_SafetyReport_Collection') {

                    result = collection.CR_SafetyReport_Collection;

                }

                break;

            case 'permanencyCollection':

                collection = window.permanencyViewModel.data.permanencyCollection.getAt(0).data;

                if (parms.questionObj.nodeToSelect == 'CR_Placement_Collection') {

                    result = collection.CR_Placement_Collection;

                    break;
                }

                if (parms.questionObj.nodeToSelect == 'CR_Goal_Collection') {

                    result = collection.CR_Goal_Collection;
                }

                break;

            case 'wellbeingCollection':

                collection = window.wellbeingViewModel.data.wellbeingCollection.getAt(0).data;

                if (parms.questionObj.nodeToSelect == 'CR_Education_Collection') {

                    result = collection.CR_Education_Collection;

                    break;
                }

                if (parms.questionObj.nodeToSelect == 'CR_Health_Collection') {

                    result = collection.CR_Health_Collection.filter(function (record) {

                        return record.HealthNeedCode == parms.questionObj.NeedCode;
                    });
                }

                break;

            default:

                break;
        }

        return result;
    }

    var getPropertyValue = function (props) {

        if (Ext.isEmpty(props)) {

            return;
        }

        var result = {};
        var store, filteredStore;

        Ext.each(props, function (property) {

            if (property.actionType == 'lookup') {

                store = Ext.data.StoreManager.lookup(property.storeId);

                filteredStore = store.data.items.filter(function (item) {

                    return item.data.GroupName == property.groupName;
                });

                result[property.name] = filteredStore;

            } else {

                if (property.actionType == 'calculation') {

                    var component, selections;

                    Ext.each(property.input, function (itemId) {

                        component = getCRSComponent(itemId);
                        selections = component.items.items.filter(function (item) {

                            return item.checked;
                        });

                        if (selections.length > 0) {

                            result[itemId] = selections;
                        }
                    });

                } else {

                    result[property.name] = vModel.data[property.name];
                }
            }
        });

        return result;
    };

    var isValueValid = function (parms) {

        var result = false;

        if (!Ext.isEmpty(parms.value)) {

            if (Ext.isArray(parms.questionObj.validValues)) {

                var filteredValues = parms.questionObj.validValues.filter(function (value) {

                    return value == parms.value;
                });

                if (filteredValues.length > 0) {

                    result = true;
                }

                return result;
            }

            if (!Ext.isEmpty(parms.questionObj.actionType)) {

                if (parms.questionObj.actionType == 'search') {

                    var collection = getCollection(parms);

                    if (parms.questionObj.validValues == 'gt0') {

                        return collection.length > 0;
                    }
                }

                if (parms.questionObj.actionType == 'lookup') {

                    if (!Ext.isEmpty(parms.value)) {

                        return parms.value.length > 0;
                    }

                    return false;
                }

                if (parms.questionObj.actionType == 'calculation') {

                    return Ext.isEmpty(parms.value) ? false : true;
                }
            }
        }

        if (parms.questionObj.dataType == 'date') {

            return Ext.isDate(parms.value);
        }

        if (parms.questionObj.dataType == 'number') {

            return Ext.isNumber(parms.value);
        }

        if (parms.questionObj.dataType == 'boolean') {

            return Ext.isBoolean(parms.value);
        }

        return result;
    };

    var isQuestionAnswered = function (questionObj, propValue) {

        var filteredValues;
        var result = {};
        var keys = Object.keys(propValue);

        result['answerTrue'] = Ext.isEmpty(questionObj.answerTrue) ? 'any' : questionObj.answerTrue;

        if (keys.length == 0) {

            result['questionAnswered'] = false;
            result[key] = { answer: undefined, isValid: false };

            return result;
        }

        for (key in propValue) {

            filteredQuestions = questionObj.modelProperty.filter(function (question) {

                if (question.actionType == 'calculation') {

                    if (propValue[key][0].checked) {

                        return question;
                    }
                } else {

                    return question.name == key;
                }

            });

            result['questionAnswered'] = false;

            if (filteredQuestions.length > 0) {

                if (!Ext.isEmpty(filteredQuestions[0].selectedValue)) {

                    if (!Ext.isEmpty(propValue[key])) {

                        if (propValue[key] == filteredQuestions[0].selectedValue) {

                            result[key] = { answer: propValue[key], isValid: true };

                        } else {

                            result[key] = { answer: propValue[key], isValid: false };
                        }
                    }
                }

                if (!Ext.isEmpty(propValue[key])) {

                    var parms = {};

                    parms['questionObj'] = filteredQuestions[0];
                    parms['value'] = propValue[key];

                    if (isValueValid(parms)) {

                        result[key] = { answer: propValue[key], isValid: true };

                    } else {

                        result[key] = { answer: propValue[key], isValid: false };
                    }
                } else {

                    result[key] = { answer: propValue[key], isValid: false };
                }
            }
        }

        var allAnswered = true;
        var atLeastOneAnswered = false;

        for (key in result) {

            if (!(key == 'answerTrue' || key == 'questionAnswered')) {

                if (!Ext.isEmpty(result[key].answer)) {

                    atLeastOneAnswered = true;
                } else {

                    allAnswered = false;
                }
            }
        }

        if (result.answerTrue == 'any') {

            if (atLeastOneAnswered) {

                result['questionAnswered'] = true;
            }
        }

        if (result.answerTrue == 'all') {

            if (allAnswered) {

                result['questionAnswered'] = true;
            }
        }

        return result;
    };

    Ext.each(obj, function (validationObj) {

        itemName = validationObj.ItemName;

        if (!Ext.isEmpty(itemName)) {

            itemQuestions = getItemQuestions(validationObj.ItemName);

            if (!Ext.isEmpty(itemQuestions)) {

                if (itemQuestions.length > 0) {

                    vModel = itemQuestions[0].viewModel == 'facesheetViewModel' ? window.facesheetViewModel :
                             itemQuestions[0].viewModel == 'safetyViewModel' ? window.safetyViewModel :
                             itemQuestions[0].viewModel == 'permanencyViewModel' ? window.permanencyViewModel :
                             itemQuestions[0].viewModel == 'wellbeingViewModel' ? window.wellbeingViewModel : undefined;

                    for (key in itemQuestions[0]) {

                        if (key == itemName) {

                            questions = itemQuestions[0][key];

                            Ext.each(questions, function (question) {

                                var result;
                                var valResult;
                                var questionAnswered = false;
                                var parms = {};
                                var questionName = Object.keys(question)[0];

                                for (key in question) {

                                    parms = {};
                                    var answerObj = question[key];

                                    if (!Ext.isEmpty(vModel)) {

                                        if (!Ext.isEmpty(answerObj.modelProperty)) {

                                            result = getPropertyValue(answerObj.modelProperty);

                                            if (questionName == 'PreApplicability') {

                                                answerObj['answerTrue'] = 'all';
                                            }

                                            valResult = isQuestionAnswered(answerObj, result);

                                            parms['ItemName'] = itemName;
                                            parms['Question'] = questionName;
                                            parms['Answered'] = valResult['questionAnswered'];
                                            parms['QuestionsObj'] = itemQuestions;

                                            updateQuestionsAnswered(parms);
                                        }
                                    }
                                }
                            });
                        }
                    }
                }
            }
        }
    });
}
var calculateItemStatus = function (obj) {

    var status;
    var itemName;

    if (Ext.isEmpty(obj)) {

        return '';
    }

    Ext.each(obj, function (validationObj) {

        validationObj['ItemName'] = obj.ItemName;

        verifyQuestionsAnswered(validationObj);

        if (!Ext.isEmpty(validationObj.ItemName)) {

            itemName = validationObj.ItemName;
        }
    });

    status = determineItemStatus(itemName);

    return status;
}
var determineItemStatus = function (itemName) {

    var status;
    var noResponses = 0;
    var errorCount = 0;
    var itemCode;
    var outcomeCode;
    var allQuestionsAnswered = true;
    var errorsExist = false;
    var oneOrMoreQuestionsAnswered = false;
    var noQuestionsAnswered = true;

    if (Ext.isEmpty(itemName)) {

        return status;
    }

    var itemQuestions = getItemQuestions(itemName);

    if (Ext.isEmpty(itemQuestions)) {

        return;
    }

    if (!Ext.isEmpty(itemQuestions)) {

        if (itemQuestions.length == 0) {

            return;
        }

        itemCode = itemQuestions[0].itemCode;
        outcomeCode = itemQuestions[0].outcomeCode;
    }

    if (!Ext.isEmpty(itemQuestions)) {

        if (itemQuestions.length > 0) {

            var questions;
            errorsExist = itemQuestions[0].errorsExist;

            for (key in itemQuestions[0]) {

                if (key == itemName) {

                    questions = itemQuestions[0][key];

                }
            }

            Ext.each(questions, function (question) {

                for (key in question) {

                    var answerObj = question[key];

                    if (answerObj.answered == false) {

                        if (answerObj.required) {

                            allQuestionsAnswered = false;
                        }
                    } else {

                        if (answerObj.required) {

                            oneOrMoreQuestionsAnswered = true;
                            noQuestionsAnswered = false;
                        }
                    }
                }
            });

            if (allQuestionsAnswered) {

                if (errorsExist) {

                    status = 'In Progress';
                } else {

                    status = 'Completed';
                }
            } else {

                if (oneOrMoreQuestionsAnswered) {

                    status = 'In Progress';
                } else {

                    status = 'Not Started';
                }
            }

            itemStatuses[itemName] = status;
        }
    }

    // Update Item Status
    if (!Ext.isEmpty(itemCode) && !Ext.isEmpty(outcomeCode) && !Ext.isEmpty(status)) {

        var statusObj = { ItemCode: itemCode, StatusDesc: status, OutcomeCode: outcomeCode };

        updateItemStatusCode(statusObj);
    }

    return status;
}
var initializeAnswers = function (itemName) {

    if (Ext.isEmpty(itemName)) {

        return;
    }

    var itemQuestions = getItemQuestions(itemName);

    var itemCode;
    var outcomeCode;

    if (Ext.isEmpty(itemQuestions)) {

        return;
    }

    if (!Ext.isEmpty(itemQuestions)) {

        if (itemQuestions.length == 0) {

            return;
        }

        itemCode = itemQuestions[0].itemCode;
        outcomeCode = itemQuestions[0].outcomeCode;
    }

    if (!Ext.isEmpty(itemQuestions)) {

        if (itemQuestions.length > 0) {

            var questions;

            for (key in itemQuestions[0]) {

                if (key == itemName) {

                    questions = itemQuestions[0][key];

                }
            }

            Ext.each(questions, function (question) {

                for (key in question) {

                    var answerObj = question[key];

                    answerObj.answered = false;
                }
            });
        }
    }
}
var calculateItemRating = function (parms) {

    if (Ext.isEmpty(parms)) {

        return;
    }

    if (Ext.isEmpty(parms.RatingItemId) || Ext.isEmpty(parms.RatingOverrideItemId)) {

        return;
    }

    var rating = updateItemRating(parms.RatingItemId, parms.RatingOverrideItemId);

    var ratingCmp = getCRSComponent(parms.RatingItemId);
    var ratingOverrideCmp = getCRSComponent(parms.RatingOverrideItemId);
    ratingCmp.setRatingOverride(ratingOverrideCmp);

    if (Ext.isEmpty(parms.RatingDefault)) {

        ratingCmp.setItemRating(rating.CodeDescription);

    } else {

        ratingCmp.setItemRating(parms.RatingDefault);
    }

    var ratingName = parms.RatingItemName.substr(0, 1).toUpperCase() + parms.RatingItemName.substr(1);

    itemRatings[ratingName + 'Rating'] = ratingCmp.getItemRating().CodeDescription;

    if (itemRatings[ratingName + 'Rating'] == 'NA') {

        var item = getItemFromGraph(ratingCmp.itemCode, ratingCmp.outcomeCode);

        if (item.IsApplicable == 2) {

            itemStatuses[parms.RatingItemName] = 'Completed';

            var itemObj = { ItemCode: ratingCmp.itemCode, OutcomeCode: ratingCmp.outcomeCode, ItemName: ratingCmp.itemName, StatusDesc: 'Completed' };

            updateItemNAStatus(itemObj);
        }
    }
}
var calculateItem12Status = function () {

    var item12AStatus = itemStatuses['item12A'];
    var item12BStatus = itemStatuses['item12B'];
    var item12CStatus = itemStatuses['item12C'];

    if (item12AStatus == 'Completed' && item12BStatus == 'Completed' && item12CStatus == 'Completed') {

        return 'Completed';
    }

    if (item12AStatus == 'Not Started' && item12BStatus == 'Not Started' && item12CStatus == 'Not Started') {

        return 'Not Started';
    }

    if (Ext.isEmpty(item12AStatus) && Ext.isEmpty(item12BStatus) && Ext.isEmpty(item12CStatus)) {

        return '';
    }

    return 'In Progress';
}
var calculateCaseStatus = function () {

    var result;
    var completeCnt = 0;
    var progressCnt = 0;
    var notStartedCnt = 0;
    var invalidStatusCnt = 0;
    var permanencyItems = ['item4', 'item5', 'item6', 'item7', 'item8', 'item9', 'item10', 'item11'];
    var caseType = getCaseType();
    var permanencyItem;

    for (prop in itemStatuses) {

        if (!Ext.isEmpty(prop)) {

            if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

                permanencyItem = permanencyItems.filter(function (itemName) {

                    return itemName == prop;
                });

                if (permanencyItem.length > 0) {

                    continue;
                }
            }

            if (itemStatuses[prop] == 'Completed') {
                completeCnt++;
            }

            if (itemStatuses[prop] == 'In Progress') {
                progressCnt++;
            }

            if (itemStatuses[prop] == 'Not Started') {
                notStartedCnt++;
            }

            if (itemStatuses[prop] == 'Invalid Status') {
                invalidStatusCnt++;
            }
        }
    }

    if (completeCnt >= 14 && (progressCnt == 0 && notStartedCnt == 0 && invalidStatusCnt == 0)) {

        updateCaseStatusCode(1);

        return 1;
    }

    if (isFacesheetComplete() && progressCnt >= 0) {

        updateCaseStatusCode(2);

        return 2;
    }

    if (completeCnt == 0 && progressCnt == 0 && notStartedCnt == 0 && invalidStatusCnt == 0) {

        updateCaseStatusCode(3);

        return 3;
    }

    updateCaseStatusCode(result);

    return result;
};
var updateQAStatus = function (statusCode) {

    if (Ext.isEmpty(statusCode)) {

        return;
    }

    updateCaseStatusCode(statusCode);

    saveCaseStatus();
}
var updateCaseStatus = function () {
    //
    // Update case status
    //
    var savedCaseStatus = getSavedCaseStatus();

    var store = Ext.StoreManager.get('CaseStatusStore');

    if (Ext.isEmpty(store)) {

        return;
    }

    var statusCode;

    var filteredStat = store.data.items.filter(function (stat) {

        return stat.data.DescriptionLarge.trim() == savedCaseStatus.trim();
    });

    statusCode = filteredStat[0].GroupID;

    if (!Ext.isEmpty(statusCode)) {

        if (statusCode > 0) {

            updateCaseStatusCode(statusCode);

            saveCaseStatus();
        }
    }
}
var updateCaseStatusCode = function (caseStatusCode) {

    var store = Ext.data.StoreManager.lookup('CaseReviewStore');

    if (Ext.isEmpty(store)) {

        return;
    }

    if (!Ext.isEmpty(caseStatusCode)) {

        if (!Ext.isEmpty(store.data)) {

            if (store.data.length > 0) {

                if (store.getAt(0).data.CaseStatusCode == 7) {

                    return;
                }

                if (!(store.getAt(0).data.CaseStatusCode == caseStatusCode)) {

                    store.getAt(0).data.CaseStatusCode = caseStatusCode;

                    var viewModel = getApplicationViewModel();

                    viewModel.set('caseStatusCode', caseStatusCode);
                }
            }
        }
    }
}
var saveCaseStatus = function () {

    silentSave = true;

    saveCompleted = false;

    initializeResultsContainer();

    getAppController().saveData();
}
var buildQANote = function (noteObj) {

    if (Ext.isEmpty(noteObj)) {

        return;
    }

    var newNote;
    var note = noteObj.NoteObj;
    var nItemId = noteObj.NoteItemId;
    var outcomeCode = noteObj.OutcomeCode;
    var noteType = noteObj.NoteType;

    var modifiedDate = isNaN(Date.parse(note.LastModifiedDate)) ? new Date(note.TS_UP) : new Date(note.LastModifiedDate);
    var formattedDate = Ext.Date.format(modifiedDate, 'm/d/Y');
    var subject = note.Subject.length == 0 ? titleArr[0] + ' ' + titleArr[1] + ' Note-' + cntr : note.Subject;
    var desc = note.Description;
    var isResolved = note.IsResolved == 1 ? true : false;
    var loggedInUser = GetLoggedInUser();

    var user = Ext.isEmpty(note.LastModifiedUserID) ? note.ID_UP : note.LastModifiedUserID;
    var noteUser = Ext.isEmpty(loggedInUser) ? loggedInUser : loggedInUser.getObjectCreator(user);
    var role = Ext.isEmpty(loggedInUser) ? loggedInUser : loggedInUser.getCaseRole(user);

    if (role.length > 0) {
        noteUser += ' (' + role + ')';
    }

    var noteId = note.NoteID;

    // Build note
    newNote = App.CaseReview.view.common.reviewNote.create({
        border: false,
        createDate: new Date(formattedDate),
        createBy: noteUser,
        subject: subject,
        text: desc,
        resolved: isResolved,
        noteId: noteId,
        noteItemId: nItemId,
        extNoteId: note.ExtId,
        status: 'stored',
        noteType: noteType,
        outcomeCode: outcomeCode,
        itemCode: noteObj.ItemCode
    });

    // Get all note responses
    var responses = noteType == 'case' ? note.CR_CaseNote_Response_Collection : note.CR_Response_Collection;

    if (!(Ext.isEmpty(responses))) {

        responses.sort(orderBy('TS_UP', 'desc'));

        var filteredResponses = responses.filter(function (responseObj) {
            return responseObj.NoteID == note.NoteID;
        });

        if (filteredResponses.length > 0) {

            // Build container for responses
            responseItems = framework.ListPanel.create({
                border: 'true',
                baseCls: 'x-panel panel-background-list-note',
                title: "<div class='html-content-header-margins'>Responses [HIDE]</div>",
                margin: '20 20 20 10',
                padding: '0 0 0 0',
                collapsed: false
            });

            Ext.each(responses, function (response) {

                if (response.ResponseID > 0 || (response.ResponseID == 0 && response.Description.trim().length > 0 && response.parentId == note.ExtId)) {

                    var respModifiedDate = isNaN(Date.parse(response.LastModifiedDate)) ? new Date(response.TS_UP) : new Date(response.LastModifiedDate);
                    //var respDate = new Date(response.TS_UP);
                    var dateUpdated = Ext.Date.format(respModifiedDate, 'm/d/Y');
                    var respDesc = response.Description;
                    var loggedInUser = GetLoggedInUser();

                    var user = Ext.isEmpty(response.LastModifiedUserID) ? response.ID_UP : response.LastModifiedUserID;

                    var responseUser = loggedInUser.getObjectCreator(user);
                    var role = loggedInUser.getCaseRole(user);

                    if (role.length > 0) {
                        responseUser += ' (' + role + ')';
                    }

                    var respId = response.ResponseID;

                    noteResp = App.CaseReview.view.common.noteResponse.create({
                        createDate: new Date(dateUpdated),
                        createBy: responseUser,
                        response: respDesc,
                        noteId: noteId,
                        responseId: respId,
                        extRespId: response.ExtId,
                        parentId: note.ExtId,
                        status: 'stored',
                        noteType: noteType
                    });

                    responseItems.add(noteResp);
                }
            });

            // Add responses to new note 
            if (responseItems.items.length > 0) {

                newNote.setResponseItems(responseItems);
            }
        }
    }

    // Add the Resolve/UnResolve button
    if (newNote.getResolved()) {
        newNote.queryById('resolvedBut').setStyle('display', 'none');
        newNote.queryById('unresolvedBut').setStyle('display', 'block');
    } else {
        newNote.queryById('unresolvedBut').setStyle('display', 'none');
        newNote.queryById('resolvedBut').setStyle('display', 'block');
    }

    return newNote;
}
var buildCaseNotesCollection = function () {

    // Get case notes
    var itemCode = 0;
    var noteType = 'case';
    var noteColl = getNoteCollection(itemCode, 'case');
    var outcomeCode,
        newNote;

    var item = getItem(itemCode, getOutcomeCode(itemCode));

    if (!Ext.isEmpty(noteColl)) {

        var notes = [];

        if (noteColl.length > 0) {

            var nItemId = itemCode == 0 ? undefined : Ext.isEmpty(item) ? undefined : item.ItemID;

            Ext.each(noteColl, function (note) {

                if (!(Ext.isEmpty(note.Subject)) && (!Ext.isEmpty(note.Description))) {
                    var noteSpecs = { NoteObj: note, ItemCode: itemCode, NoteItemId: nItemId, NoteType: noteType, OutcomeCode: outcomeCode };

                    newNote = buildQANote(noteSpecs);

                    // Add note to notes array
                    notes.push(newNote);
                }
            });

            var itemName = getItemNameFromCode(itemCode);
            var notesCollObj = { Name: itemName, objValue: notes };

            if (Ext.isEmpty(qaNotesSummary)) {

                qaNotesSummary = App.CaseReview.view.common.qaNotesCollection.create({});
            }

            if (notes.length > 0) {

                qaNotesSummary.addNote(notesCollObj);
            }
        }
    }

    // Get item notes
    for (var itemCode = 2; itemCode < 24; itemCode++) {

        var notes = [];

        noteType = 'item';

        // Get note collection for items
        var noteColl = getNoteCollection(itemCode, noteType);

        if (!Ext.isEmpty(noteColl)) {

            if (noteColl.length > 0) {

                var itemId = noteColl.length == 0 ? undefined : noteColl[0].ItemID;
                var outcomeCode = getOutcomeCode(itemCode);

                if (Ext.isEmpty(itemId)) {

                    itemId = getLatestItemId(itemCode, outcomeCode);
                }

                var iCode = itemId == undefined ? itemCode : itemId;

                var item = getItem(iCode, outcomeCode);

                if (iCode == itemId && Ext.isEmpty(item)) {

                    item = getItem(itemCode, outcomeCode);
                }

                var nItemId = itemCode == 0 ? undefined : item.ItemID;

                if (Ext.isEmpty(nItemId)) {

                    nItemId = itemId;
                }

                Ext.each(noteColl, function (note) {

                    if (!(Ext.isEmpty(note.Subject)) && (!Ext.isEmpty(note.Description))) {

                        var parms = {};

                        parms['itemCode'] = itemCode;
                        parms['outcomeCode'] = outcomeCode;
                        parms['itemId'] = itemId;
                        parms['description'] = note.Description;
                        parms['subject'] = note.Subject;

                        var updatedNoteId = getLatestNoteId(parms);

                        if (!(note.NoteID == updatedNoteId)) {

                            if (!Ext.isEmpty(updatedNoteId)) {

                                note.NoteID = updatedNoteId;
                            }
                        }

                        var noteSpecs = { NoteObj: note, ItemCode: itemCode, NoteItemId: nItemId, NoteType: noteType, OutcomeCode: outcomeCode };

                        newNote = buildQANote(noteSpecs);

                        // Add note to notes array
                        notes.push(newNote);
                    }
                });

                var itemName = getItemNameFromCode(itemCode);
                var notesCollObj = { Name: itemName, objValue: notes };

                if (Ext.isEmpty(qaNotesSummary)) {

                    qaNotesSummary = App.CaseReview.view.common.qaNotesCollection.create({});
                }

                if (notes.length > 0) {

                    qaNotesSummary.addNote(notesCollObj);
                }
            }
        }
    }
};
var updateAllRatings = function () {

    var itemName;
    var ratingCode;
    var itemCodeObj;
    var item, graphItem;

    for (key in itemRatings) {

        if (!Ext.isEmpty(key)) {

            itemName = key.replace('Rating', '').replace('I', 'i');

            if (itemName.substring(0, 4) == 'item') {

                itemCodeObj = getItemCodeFromName(itemName);

                ratingCode = getRatingCodeFromDesc(itemRatings[key]);

                item = getItem(itemCodeObj.ItemCode, itemCodeObj.OutcomeCode);

                if (!Ext.isEmpty(item)) {

                    item.ItemRatingCode = ratingCode;
                    //
                    // Update graph
                    //
                    graphItem = getItemFromGraph(itemCodeObj.ItemCode, itemCodeObj.OutcomeCode);

                    if (!Ext.isEmpty(graphItem)) {

                        graphItem.ItemRatingCode = ratingCode;
                    }
                }
            }
        }
    }
}
var updateAllStatuses = function () {

    for (key in itemStatuses) {

        var itemCodeObj = getItemCodeFromName(key);

        if (!(key == 'updateItem12Status')) {

            if (Ext.isEmpty(itemStatuses[key])) {

                itemStatuses[key] = getItemStatus(itemCodeObj.ItemCode);
            }

            if (!Ext.isEmpty(itemCodeObj.ItemCode) && !Ext.isEmpty(itemCodeObj.OutcomeCode) && !Ext.isEmpty(itemStatuses[key])) {

                var statusObj = { ItemCode: itemCodeObj.ItemCode, StatusDesc: itemStatuses[key], OutcomeCode: itemCodeObj.OutcomeCode };

                updateItemStatusCode(statusObj);
            }
        }
    }
}
var updateAllOutcomeRatings = function () {

    var outcomeCode;
    var ratingInput = {};
    var ratingCalculator = App.CaseReview.view.common.CRSRatingCalculator.create({});

    var getOutcomeRating = function (outcomeCode) {

        switch (outcomeCode) {

            case 1:

                ratingInput['Item1Rating'] = itemRatings['Item1Rating'];

                 return ratingCalculator.calculateSafetyOutcome1Rating(ratingInput);

            case 2:

                ratingInput['Item2Rating'] = itemRatings['Item2Rating'];
                ratingInput['Item3Rating'] = itemRatings['Item3Rating'];

                return ratingCalculator.calculateSafetyOutcome2Rating(ratingInput);

            case 3:

                ratingInput['Item4Rating'] = itemRatings['Item4Rating'];
                ratingInput['Item5Rating'] = itemRatings['Item5Rating'];
                ratingInput['Item6Rating'] = itemRatings['Item6Rating'];

                return ratingCalculator.calculatePermanencyOutcome1Rating(ratingInput);

            case 4:

                ratingInput['Item7Rating'] = itemRatings['Item7Rating'];
                ratingInput['Item8Rating'] = itemRatings['Item8Rating'];
                ratingInput['Item9Rating'] = itemRatings['Item9Rating'];
                ratingInput['Item10Rating'] = itemRatings['Item10Rating'];
                ratingInput['Item11Rating'] = itemRatings['Item11Rating'];

                return ratingCalculator.calculatePermanencyOutcome2Rating(ratingInput);

            case 5:

                ratingInput['Item12Rating'] = itemRatings['Item12Rating'];
                ratingInput['Item12ARating'] = itemRatings['Item12ARating'];
                ratingInput['Item12BRating'] = itemRatings['Item12BRating'];
                ratingInput['Item12CRating'] = itemRatings['Item12CRating'];
                ratingInput['Item13Rating'] = itemRatings['Item13Rating'];
                ratingInput['Item14Rating'] = itemRatings['Item14Rating'];
                ratingInput['Item15Rating'] = itemRatings['Item15Rating'];

                return ratingCalculator.calculateWellbeingOutcome1Rating(ratingInput);

            case 6:

                var controller = getAppController();

                ratingInput['Item16Rating'] = itemRatings['Item16Rating'];

                var item16AChecked = controller.getQuestion16AYes().checked ? 'Yes' :
                                     controller.getQuestion16ANo().checked ? 'No' : undefined;

                ratingInput['Item16A'] = item16AChecked;

                var item16BChecked = controller.getQuestion16BYes().checked ? 'Yes' :
                                     controller.getQuestion16BNo().checked ? 'No' :
                                     controller.getQuestion16BNA().checked ? 'NA' : undefined;

                ratingInput['Item16B'] = item16BChecked;

                return ratingCalculator.calculateWellbeingOutcome2Rating(ratingInput);

            case 7:

                ratingInput['Item17Rating'] = itemRatings['Item17Rating'];
                ratingInput['Item18Rating'] = itemRatings['Item18Rating'];

                return ratingCalculator.calculateWellbeingOutcome3Rating(ratingInput);

            default:

                return null;
        }
    };

    var statusCalculator = App.CaseReview.view.common.itemRating.create({});
    var outcome;

    for (var i = 1; i < 8; i++) {

        var statusResult = getOutcomeRating(i);
        outcome = null;

        //
        // Save outcome status
        //
        statusCalculator.setOutcomeCode(i);

        statusCalculator.updateOutcomeStore(statusResult);

        //
        // Update outcomeRatings
        //
        switch (i) {

            case 1:

                outcomeRatings.safety.outcome1.ratingCode = statusResult.RatingCode;
                outcomeRatings.safety.outcome1.ratingDescription = statusResult.RatingDescription;

                var oRating = { ratingCode: statusResult.RatingCode, ratingDescription: statusResult.RatingDescription, outcomeCode: outcomeRatings.safety.outcome1.outcomeCode };
                var viewModel = window.safetyViewModel;

                if (!Ext.isEmpty(viewModel)) {

                    viewModel.set('outcome1Rating', oRating);
                }

                break;

            case 2:

                outcomeRatings.safety.outcome2.ratingCode = statusResult.RatingCode;
                outcomeRatings.safety.outcome2.ratingDescription = statusResult.RatingDescription;

                var oRating = { ratingCode: statusResult.RatingCode, ratingDescription: statusResult.RatingDescription, outcomeCode: outcomeRatings.safety.outcome2.outcomeCode };
                var viewModel = window.safetyViewModel;

                if (!Ext.isEmpty(viewModel)) {

                    viewModel.set('outcome2Rating', oRating);
                }

                break;

            case 3:

                outcomeRatings.permanency.outcome1.ratingCode = statusResult.RatingCode;
                outcomeRatings.permanency.outcome1.ratingDescription = statusResult.RatingDescription;

                var oRating = { ratingCode: statusResult.RatingCode, ratingDescription: statusResult.RatingDescription, outcomeCode: outcomeRatings.permanency.outcome1.outcomeCode };
                var viewModel = window.permanencyViewModel;

                if (!Ext.isEmpty(viewModel)) {

                    viewModel.set('outcome1Rating', oRating);
                }

                break;

            case 4:

                outcomeRatings.permanency.outcome2.ratingCode = statusResult.RatingCode;
                outcomeRatings.permanency.outcome2.ratingDescription = statusResult.RatingDescription;

                var oRating = { ratingCode: statusResult.RatingCode, ratingDescription: statusResult.RatingDescription, outcomeCode: outcomeRatings.permanency.outcome2.outcomeCode };
                var viewModel = window.permanencyViewModel;

                if (!Ext.isEmpty(viewModel)) {

                    viewModel.set('outcome2Rating', oRating);
                }

                break;

            case 5:

                outcomeRatings.wellbeing.outcome1.ratingCode = statusResult.RatingCode;
                outcomeRatings.wellbeing.outcome1.ratingDescription = statusResult.RatingDescription;

                var oRating = { ratingCode: statusResult.RatingCode, ratingDescription: statusResult.RatingDescription, outcomeCode: outcomeRatings.wellbeing.outcome1.outcomeCode };
                var viewModel = window.wellbeingViewModel;

                if (!Ext.isEmpty(viewModel)) {

                    viewModel.set('outcome1Rating', oRating);
                }

                break;

            case 6:

                outcomeRatings.wellbeing.outcome2.ratingCode = statusResult.RatingCode;
                outcomeRatings.wellbeing.outcome2.ratingDescription = statusResult.RatingDescription;

                var oRating = { ratingCode: statusResult.RatingCode, ratingDescription: statusResult.RatingDescription, outcomeCode: outcomeRatings.wellbeing.outcome2.outcomeCode };
                var viewModel = window.wellbeingViewModel;

                if (!Ext.isEmpty(viewModel)) {

                    viewModel.set('outcome2Rating', oRating);
                }

                break;

            case 7:

                outcomeRatings.wellbeing.outcome3.ratingCode = statusResult.RatingCode;
                outcomeRatings.wellbeing.outcome3.ratingDescription = statusResult.RatingDescription;

                var oRating = { ratingCode: statusResult.RatingCode, ratingDescription: statusResult.RatingDescription, outcomeCode: outcomeRatings.wellbeing.outcome3.outcomeCode };
                var viewModel = window.wellbeingViewModel;

                if (!Ext.isEmpty(viewModel)) {

                    viewModel.set('outcome3Rating', oRating);
                }

                break;

            default:

                break;
        }

        outcome = getOutcome(i);

        if (!Ext.isEmpty(outcome)) {

            outcome.ExtOutcome.data.OutcomeRatingCode = statusResult.RatingCode;

            if (!Ext.isEmpty(outcome.GraphOutcome)) {

                outcome.GraphOutcome[0].OutcomeRatingCode = statusResult.RatingCode;
            }
        }
    }
}
var getCaseReviewId = function () {

    return chainedStore('CaseReviewStore').getAt(0).data.CaseReviewID;
}
// Generic sorting
var orderBy = function (property, direction) {

    switch (direction) {
        case 'asc':

            return function (obj1, obj2) {
                return ((obj1[property] === obj2[property]) ? 0 : ((obj1[property] > obj2[property]) ? 1 : -1));
            };

            break;

        case 'desc':

            return function (obj1, obj2) {
                return ((obj1[property] === obj2[property]) ? 0 : ((obj1[property] > obj2[property]) ? -1 : 1));
            };

            break;

        default:

            return function (obj1, obj2) {
                return ((obj1[property] === obj2[property]) ? 0 : ((obj1[property] > obj2[property]) ? 1 : -1));
            };

            break;
    }
    return function (obj1, obj2) {
        return ((obj1[property] === obj2[property]) ? 0 : ((obj1[property] > obj2[property]) ? 1 : -1));
    };
};
// Get Item from Outcome_CollectionStore
var getItemFromGraph = function (itemCode, outcomeCode) {

    var result;
    var searchResult = true;

    if (Ext.isEmpty(itemCode)) {

        return result;
    }

    if (Ext.isEmpty(outcomeCode)) {

        outcomeCode = getOutcomeCode(itemCode);
    }

    var getCurrentItem = function (itemObj) {

        var selectedItem;

        if (itemObj.ItemCode == itemCode || itemObj.ItemID == itemCode) {
            selectedItem = itemObj;
        }

        if (!(selectedItem == undefined)) {
            searchResult = false;
        }

        return selectedItem;
    }

    var getStoredItem = function () {

        var outcomeStore;
        var store = Ext.data.StoreManager.get('CaseReviewStore');

        if (!Ext.isEmpty(outcomeCode)) {

            outcomeStore = store.getAt(0).data.CR_Outcome_Collection.filter(function (outcome) {

                return outcome.OutcomeCode == outcomeCode;
            });
        }

        outcomeStore = outcomeStore == undefined ? (store.data.length == 0 ? [] : store.getAt(0).data.CR_Outcome_Collection) : outcomeStore;

        if (outcomeStore.length == 0) {

            return undefined;
        }

        Ext.each(outcomeStore, function (outcome) {
            Ext.each(outcome.CR_Item_Collection, function (item) {

                result = getCurrentItem(item);

                return searchResult;
            });

            return searchResult;
        });
    }

    getStoredItem();

    //
    // Create new Item if needed
    //
    if (Ext.isEmpty(result)) {

        result = getItem(itemCode, outcomeCode);

        if (Ext.isEmpty(result)) {

            var obj = { itemCode: itemCode, outcomeCode: outcomeCode };

            var inputObj = { objectType: 'item', containerType: 'graph', outcomeCode: outcomeCode, DataState: 0, objValue: obj };

            addCRSObject(inputObj);

            getStoredItem();

            return result;
        }
    }

    return result;
}
var getOutcomeFromGraph = function (outcomeCode) {

    var result;
    var searchResult = true;

    if (Ext.isEmpty(outcomeCode)) {

        return result;
    }

    var getStoredItem = function () {

        var outcomeStore;
        var store = Ext.data.StoreManager.get('CaseReviewStore');

        if (!(Ext.isEmpty(outcomeCode))) {

            outcomeStore = store.getAt(0).data.CR_Outcome_Collection.filter(function (outcome) {

                return outcome.OutcomeCode == outcomeCode;
            });
        }

        outcomeStore = outcomeStore == undefined ? (store.data.length == 0 ? [] : store.getAt(0).data.CR_Outcome_Collection) : outcomeStore;

        if (outcomeStore.length == 0) {

            return undefined;
        }

        return outcomeStore;
    }

    result = getStoredItem();

    return result;
}
var getItem = function (itemCode, outcomeCode) {

    var result;
    var searchResult = true;

    if (Ext.isEmpty(itemCode)) {

        return result;
    }

    if (Ext.isEmpty(outcomeCode)) {

        outcomeCode = getOutcomeCode(itemCode);
    }

    var getCurrentItem = function (itemObj) {

        var selectedItem;

        if (itemObj.ItemCode == itemCode || itemObj.ItemID == itemCode) {
            selectedItem = itemObj;
        }

        if (!(selectedItem == undefined)) {
            searchResult = false;
        }

        return selectedItem;
    }

    var getStoredItem = function () {

        var outcomeStore;
        var store = chainedStore('CR_Outcome_CollectionStore');

        if (!(Ext.isEmpty(outcomeCode))) {

            outcomeStore = store.data.items.filter(function (outcome) {
                return outcome.data.OutcomeCode == outcomeCode;
            });
        }

        outcomeStore = outcomeStore == undefined ? (store.length == 0 ? [] : store.data.items) : outcomeStore;

        if (outcomeStore.length == 0) {
            return undefined;
        }

        Ext.each(outcomeStore, function (outcome) {
            Ext.each(outcome.data.CR_Item_Collection, function (item) {

                result = getCurrentItem(item);

                return searchResult;
            });

            return searchResult;
        });
    }

    getStoredItem();

    //
    // Create new Item if needed
    //
    if (Ext.isEmpty(result)) {

        var obj = { itemCode: itemCode, outcomeCode: outcomeCode };

        var inputObj = { objectType: 'item', outcomeCode: outcomeCode, DataState: 0, objValue: obj };

        addCRSObject(inputObj);

        getStoredItem();

        return result;
    }

    return result;
}
var getOutcome = function (outcomeCode) {

    var outcomeStore;
    var result = {};

    var store = chainedStore('CR_Outcome_CollectionStore');

    if (Ext.isEmpty(outcomeCode)) {

        return result;
    }

    outcomeStore = store.data.items.filter(function (outcome) {
        return outcome.data.OutcomeCode == outcomeCode;
    });

    outcomeStore = Ext.isEmpty(outcomeStore) ? (store.length == 0 ? [] : store.data.items) : outcomeStore;

    if (outcomeStore.length == 0) {

        return undefined;
    }

    result['ExtOutcome'] = outcomeStore[0];
    result['GraphOutcome'] = getOutcomeFromGraph(outcomeCode);

    return result;
}
var getLatestItemId = function (itemCode, outcomeCode) {

    if (Ext.isEmpty(lastSavedResult)) {

        return undefined;
    }

    if (Ext.isEmpty(itemCode)) {

        return undefined;
    }

    if (Ext.isEmpty(outcomeCode)) {

        outcomeCode = getOutcomeCode(itemCode);
    }

    var itemIds = [];
    var outcomeColl = lastSavedResult.data.CaseReview[0].CR_Outcome_Collection;

    var selectedOutcomeColl = outcomeColl.filter(function (outcome) {

        return outcome.OutcomeCode == outcomeCode;
    });

    if (selectedOutcomeColl.length == 0) {

        return undefined;
    }

    Ext.each(selectedOutcomeColl[0].CR_Item_Collection, function (item) {

        if (item.ItemCode == itemCode) {

            itemIds.push(item.ItemID);
        }
    });

    itemIds.sort();

    return itemIds[itemIds.length - 1];
}
var getLatestNoteId = function (parms) {

    if (Ext.isEmpty(lastSavedResult)) {

        return undefined;
    }

    if (Ext.isEmpty(parms)) {

        return undefined;
    }

    var noteIds = [];
    var selectedItems = [];
    var outcomeColl = lastSavedResult.data.CaseReview[0].CR_Outcome_Collection;

    var selectedOutcomeColl = outcomeColl.filter(function (outcome) {

        return outcome.OutcomeCode == parms.outcomeCode;
    });

    if (selectedOutcomeColl.length == 0) {

        return undefined;
    }

    Ext.each(selectedOutcomeColl[0].CR_Item_Collection, function (item) {

        if (item.ItemCode == parms.itemCode) {

            selectedItems.push(item);
        }
    });

    Ext.each(selectedItems, function (selectedItem) {

        if (selectedItem.ItemID == parms.itemId) {

            Ext.each(selectedItem.CR_Note_Collection, function (note) {

                if (note.ItemID == parms.itemId &&
                    note.Description == parms.description &&
                    note.Subject == parms.subject) {

                    noteIds.push(note.NoteID);
                }
            });
        }
    });

    noteIds.sort();

    return noteIds[noteIds.length - 1];
}
var getNoteItemId = function (subject, comment) {

    var result;
    var searchItem = true;
    var searchNote = true;

    var store = chainedStore('CR_Outcome_CollectionStore');

    if (Ext.isEmpty(store)) {

        return result;
    }

    var getCurrentNote = function (itemObj) {

        var selectedNote;

        Ext.each(itemObj.CR_Note_Collection, function (note) {

            if (note.Subject == subject && note.Description == comment) {
                selectedNote = note;
            }

            if (!(selectedNote == undefined)) {
                searchNote = false;
                searchItem = false;
            }

            return searchNote;
        });

        return selectedNote;
    }

    Ext.each(store.data.items, function (outcome) {
        Ext.each(outcome.data.CR_Item_Collection, function (item) {

            result = getCurrentNote(item);

            return searchItem;
        });

        return searchItem;
    });

    return result;
}
var getItemNameFromCode = function (itemCode) {

    switch (itemCode) {

        case 0:
        case 1:
            return 'case';

        case 2:
            return 'item1';

        case 3:
            return 'item2';

        case 4:
            return 'item3';

        case 5:
            return 'item4';

        case 6:
            return 'item5';

        case 7:
            return 'item6';

        case 8:
            return 'item7';

        case 9:
            return 'item8';

        case 10:
            return 'item9';

        case 11:
            return 'item10';

        case 12:
            return 'item11';

        case 13:
            return 'item12';

        case 14:
            return 'item12A';

        case 15:
            return 'item12B';

        case 16:
            return 'item12C';

        case 17:
            return 'item13';

        case 18:
            return 'item14';

        case 19:
            return 'item15';

        case 20:
            return 'item16';

        case 21:
            return 'item17';

        case 22:
            return 'item18';

        case 23:
            return 'facesheet';

        default:
            return itemCode;
    }
}
var getSavedItemRatings = function () {

    var itemName;
    var result;
    var item;

    for (key in itemRatings) {

        if (Ext.isEmpty(itemRatings[key])) {

            itemName = key.replace('Rating', '').toLowerCase();
            result = getItemCodeFromName(itemName);

            item = getItem(result.ItemCode, result.OutcomeCode);

            itemRatings[key] = 'Not Yet Rated';

            if (!Ext.isEmpty(item)) {

                itemRatings[key] = item.ItemRatingCode == 1 ? 'Strength' :
                               item.ItemRatingCode == 2 ? 'Area Needing Improvement' :
                               item.ItemRatingCode == 3 ? 'NA' :
                               item.ItemRatingCode == 4 ? 'Unable to Rate' : 'Not Yet Rated';
            }
        }
    }
}
var getSavedOutcomeRatings = function () {

    var outcomes;
    var outcomeProps;
    var outcomeColl = chainedStore('CaseReviewStore').getAt(0).data.CR_Outcome_Collection;
    var savedOutcome;

    for (page in outcomeRatings) {

        outcomes = outcomeRatings[page];

        for (outcome in outcomes) {

            outcomeProps = outcomes[outcome];

            savedOutcome = outcomeColl.filter(function (outcomeObj) {

                return outcomeObj.OutcomeCode == outcomeProps.outcomeCode;
            });

            if (savedOutcome.length > 0) {

                outcomeProps.ratingCode = savedOutcome[0].OutcomeRatingCode;
                outcomeProps.ratingDescription = savedOutcome[0].OutcomeRatingCode == 1 ? 'Substantially Achieved' :
                                                 savedOutcome[0].OutcomeRatingCode == 2 ? 'Partially Achieved' :
                                                 savedOutcome[0].OutcomeRatingCode == 3 ? 'Not Achieved' :
                                                 savedOutcome[0].OutcomeRatingCode == 4 ? 'NA' : 'Not Yet Determined';

                if (page == 'permanency') {

                    var caseType = getCaseType();

                    if (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') {

                        outcomeProps.ratingDescription = 'Not Applicable';
                    }
                }
            }
        }
    }
}
var getSavedStatuses = function () {

    var itemName;
    var result;
    var item;

    for (key in itemStatuses) {

        result = getItemCodeFromName(key);

        item = getItemFromGraph(result.ItemCode, result.OutcomeCode);

        if (!(key == 'updateItem12Status')) {

            if (!Ext.isEmpty(item)) {

                itemStatuses[key] = item.StatusCode == 1 ? 'Completed' :
                            item.StatusCode == 2 ? 'In Progress' :
                            item.StatusCode == 3 ? 'Not Started' : 'Not Started';
            } else {

                itemStatuses[key] = 'Not Started';
            }
        }
    }
}
var getSavedCaseStatus = function () {

    var statusCode,
        caseStatusStore,
        store = Ext.data.StoreManager.lookup('CaseReviewStore');

    if (Ext.isEmpty(store)) {

        return itemStatuses.facesheet == 'Completed' ? 'In Progress' : 'Not Started';
    }

    if (Ext.isEmpty(store.data)) {

        return itemStatuses.facesheet == 'Completed' ? 'In Progress' : 'Not Started';
    }

    if (store.data.length > 0) {

        statusCode = store.data.items[0].data.CaseStatusCode;

        switch (statusCode) {

            case 1:
                return 'Data Entry Complete';

            case 2:
                return 'In Progress';

            case 3:
                return 'Not Started';

            case 4:
                return 'QA in Progress';

            case 5:
                return 'Finalized (Pending Approval)';

            case 6:
                return 'Case Eliminated';

            case 7:
                return 'Approved and Final';

            case 8:
                return 'Case Eliminated (Pending Approval)';

            default:
                return 'Not Started';
        }
    }
}
var getRatingCodeFromDesc = function (ratingDesc) {

    var result = 0;

    switch (ratingDesc) {

        case 'Strength':
            return 1;

        case 'Area Needing Improvement':
            return 2;

        case 'NA':
            return 3;

        case 'Unable to Rate':
            return 4;

        default:
            return 0;
    }

    return result;
}
var getItemCodeFromName = function (itemName) {

    var result = {};

    switch (itemName) {

        case 'case':

            result['ItemCode'] = 0;
            result['OutcomeCode'] = 0;

            break;

        case 'item1':

            result['ItemCode'] = 2;
            result['OutcomeCode'] = 1;

            break;

        case 'item2':

            result['ItemCode'] = 3;
            result['OutcomeCode'] = 2;

            break;

        case 'item3':

            result['ItemCode'] = 4;
            result['OutcomeCode'] = 2;

            break;

        case 'item4':

            result['ItemCode'] = 5;
            result['OutcomeCode'] = 3;

            break;

        case 'item5':

            result['ItemCode'] = 6;
            result['OutcomeCode'] = 3;

            break;

        case 'item6':

            result['ItemCode'] = 7;
            result['OutcomeCode'] = 3;

            break;

        case 'item7':

            result['ItemCode'] = 8;
            result['OutcomeCode'] = 4;

            break;

        case 'item8':

            result['ItemCode'] = 9;
            result['OutcomeCode'] = 4;

            break;

        case 'item9':

            result['ItemCode'] = 10;
            result['OutcomeCode'] = 4;

            break;

        case 'item10':

            result['ItemCode'] = 11;
            result['OutcomeCode'] = 4;

            break;

        case 'item11':

            result['ItemCode'] = 12;
            result['OutcomeCode'] = 4;

            break;

        case 'item12':

            result['ItemCode'] = 13;
            result['OutcomeCode'] = 5;

            break;

        case 'item12A':

            result['ItemCode'] = 14;
            result['OutcomeCode'] = 5;

            break;

        case 'item12B':

            result['ItemCode'] = 15;
            result['OutcomeCode'] = 5;

            break;

        case 'item12C':

            result['ItemCode'] = 16;
            result['OutcomeCode'] = 5;

            break;

        case 'item13':

            result['ItemCode'] = 17;
            result['OutcomeCode'] = 5;

            break;

        case 'item14':

            result['ItemCode'] = 18;
            result['OutcomeCode'] = 5;

            break;

        case 'item15':

            result['ItemCode'] = 19;
            result['OutcomeCode'] = 5;

            break;

        case 'item16':

            result['ItemCode'] = 20;
            result['OutcomeCode'] = 6;

            break;

        case 'item17':

            result['ItemCode'] = 21;
            result['OutcomeCode'] = 7;

            break;

        case 'item18':

            result['ItemCode'] = 22;
            result['OutcomeCode'] = 7;

            break;

        case 'facesheet':

            result['ItemCode'] = 23;
            result['OutcomeCode'] = 21;

            break;

        default:

            break;
    }

    return result;
}
var isCaseApplicable = function (itemCode, outcomeCode) {

    if (Ext.isEmpty(itemCode)) {

        return undefined;
    }

    var item = getItem(itemCode, outcomeCode);
    var caseApplicable;

    if (!(Ext.isEmpty(item))) {

        caseApplicable = item.IsApplicable;
    }

    return caseApplicable == 1 ? true : caseApplicable == 2 ? false : undefined;
}
var getFilteredMultiAnswerStore = function (groupName, groupMembers) {

    var filteredStore;

    if (Ext.isEmpty(groupName)) {

        return filteredStore;
    }

    var store = chainedStore('CaseReviewLookUpStore');

    var filteredStore = store.getAt(0).get(groupName);

    if (Ext.isEmpty(filteredStore)) {

        if (Ext.isEmpty(groupMembers)) {

            groupMembers = getCodeDescriptionGroup(groupName);
            var groupData;
            var model = {};

            model[groupName] = [];

            Ext.each(groupMembers, function (member) {

                groupData = {};

                for (key in member) {

                    groupData[key] = member[key];
                }

                model[groupName].push(groupData);
            });

            store.getAt(0).data[groupName] = model[groupName];
        }

        filteredStore = store.getAt(0).get(groupName);
    }

    return filteredStore;
};
// Update Item in Outcome_CollectionStore
var updateItem = function (updatedItem) {

    var result;

    if (Ext.isEmpty(updatedItem)) {

        return result;
    }

    updatedItem = updateDefaultValues(updatedItem);

    var outcomeStore = Ext.data.ChainedStore.create({
        source: 'CR_Outcome_CollectionStore',
        filters: [
            function (record) {
                return record.data.OutcomeID == updatedItem.OutcomeID &&
                       //record.data.OutcomeCode == updatedItem.OutcomeCode &&
                       record.data.OutcomeID >= 0;
            }
        ]
    });

    if (outcomeStore.data.length == 0) {
        return false;
    }

    if (outcomeStore.getAt(0).data == undefined || outcomeStore.getAt(0).data == null) {
        return false;
    }

    var itemColl = outcomeStore.getAt(0).data.CR_Item_Collection;

    Ext.each(itemColl, function (item) {
        if ((item.ItemCode == updatedItem.ItemCode &&
            (item.ItemID == updatedItem.ItemID || (Ext.isEmpty(item.ItemID) && updatedItem.ItemID == 0))) || item.ItemID == updatedItem.ItemCode) {

            for (var prop in updatedItem) {

                item[prop] = updatedItem[prop];

            }

            result = updatedItem;
        }

        if (!(result == undefined)) {
            return false;
        }
    });

    if (result == undefined) {
        outcomeStore.getAt(0).data.CR_Item_Collection.push(updatedItem);
    }

    //
    // Update Graph
    //
    var graphOutcomeStore = Ext.StoreMgr.get('CaseReviewStore').getAt(0).data.CR_Outcome_Collection.filter(function (outcome) {

        return outcome.OutcomeCode == updatedItem.OutcomeCode;
    })

    if (graphOutcomeStore.length > 0) {

        Ext.each(graphOutcomeStore[0].CR_Item_Collection, function (item) {

            if (item.ItemCode == updatedItem.ItemCode) {

                for (var prop in updatedItem) {

                    item[prop] = updatedItem[prop];

                }
            }
        });
    }

    return true;
}
// Get Note Collection from Outcome_CollectionStore
var getNoteCollection = function (itemCode, noteType) {

    var noteColl = [];
    var updatedColl = [];
    var keyParms = ['ItemID', 'Subject', 'Description'];

    if (Ext.isEmpty(itemCode)) {

        return noteColl;
    }

    if (noteType == 'item' || noteType == undefined) {
        var item = getItemFromGraph(itemCode, getOutcomeCode(itemCode));

        if (!Ext.isEmpty(item)) {
            var objColl = item.CR_Note_Collection;

            Ext.each(objColl, function (note) {

                if (!(Ext.isEmpty(note.Subject) && Ext.isEmpty(note.Description))) {

                    if (noteColl == undefined) {
                        noteColl = [];
                    }

                    noteColl.push(note);
                }
            });

            updatedColl = removeDuplicatesFromJsonArray(noteColl, keyParms);

            if (!Ext.isEmpty(updatedColl)) {

                updatedColl.sort(orderBy('LastModifiedDate', 'desc'));
            }

            item.CR_Note_Collection = updatedColl;
        }

        return updatedColl;
    }

    if (noteType == 'case') {

        var caseNoteStore = chainedStore('CR_CaseNote_CollectionStore');
        noteColl = [];
        var currentNotes = [];

        if (caseNoteStore.data.length > 0) {

            Ext.each(caseNoteStore.data.items, function (note) {

                currentNotes.push(note);
                noteColl.push(note.data);
            });
        }

        if (noteColl.length > 0) {

            noteColl.sort(orderBy('TS_UP', 'desc'));
        }

        updatedColl = removeDuplicatesFromJsonArray(noteColl, keyParms);

        if (currentNotes.length != updatedColl.length) {

            Ext.each(currentNotes, function (note) {

                caseNoteStore.remove(note);
            });

            Ext.each(updatedColl, function (note) {

                caseNoteStore.add(note);
            });
        }

        return updatedColl;
    }

    return noteColl;
}
// Update Note Collection
var updateNoteCollection = function (itemCode, note, noteType) {

    var noteColl;

    if (Ext.isEmpty(itemCode)) {

        return false;
    }

    // Process item notes
    if (noteType == 'item' || Ext.isEmpty(noteType)) {

        var item = getItemFromGraph(itemCode, getOutcomeCode(itemCode));

        // Process note if valid
        if (!Ext.isEmpty(note)) {

            if (!Ext.isEmpty(item)) {

                noteColl = item.CR_Note_Collection;
                var oldNote;

                if (!(Ext.isEmpty(noteColl))) {

                    oldNote = noteColl.filter(function (noteObj) {
                        return (noteObj.NoteID == note.NoteID && noteObj.NoteID > 0) ||
                               (noteObj.Subject == note.Subject && noteObj.Description == note.Description);
                    });
                }

                if (!Ext.isEmpty(oldNote)) {

                    if (oldNote.length > 0) {
                        // Update note
                        Ext.each(noteColl, function (noteToChange) {

                            if (noteToChange.NoteID == note.NoteID) {

                                noteToChange = note;

                                return false;
                            }
                        });
                    } else {
                        // Add note
                        if (Ext.isArray(note)) {

                            item.CR_Note_Collection = [];

                            Ext.each(note, function (noteItem) {

                                noteItem.DataState = 0;
                                item.CR_Note_Collection.push(noteItem);
                            })
                        } else {

                            var noteAlreadyInCollection = false;

                            Ext.each(item.CR_Note_Collection, function (noteItem) {

                                if ((noteItem.NodeID > 0 && noteItem.NodeID == note.NoteID) || noteItem.ExtId == note.ExtId) {

                                    noteItem = note;
                                    noteAlreadyInCollection = true;

                                    return false;
                                }
                            });

                            if (!(noteAlreadyInCollection)) {

                                item.CR_Note_Collection.push(note);
                            }
                        }
                    }
                }

                item.DataState = 0;

                updateItem(item);

                return true;
            }
        }

        // Process collection if valid
        if (!(Ext.isEmpty(noteColl))) {
            if (!(item == undefined)) {

                item.getAt(0).data.set("CR_Note_Collection", noteColl);

                updateItem(item);

                return true;
            }
        }
    }

    // Process case notes
    if (noteType == 'case') {

        var caseNoteStore = Ext.data.ChainedStore.create({
            source: 'CR_CaseNote_CollectionStore',
            filters: [
                function (record) {
                    return record.data.NoteID == note.NoteID &&
                           record.data.NoteID > 0;
                }
            ]
        });

        if (caseNoteStore.data.length > 0) {
            // Update note
            Ext.each(caseNoteStore.data.items, function (noteToChange) {
                if (noteToChange.NoteID == note.NoteID) {

                    noteToChange = note;

                    return false;
                }
            });
        } else {
            // Add note
            var model = caseNoteStore.add({});
            model[0].set("Subject", note.Subject);
            model[0].set("Description", note.Description);

            var cNoteStore = Ext.data.StoreManager.get('CaseReviewStore').getAt(0).data.CR_CaseNote_Collection;

            cNoteStore.push(model[0].data);
        }
    }

    return false;
}
// Get Response Collection from Outcome_CollectionStore
var getResponseCollection = function (itemCode, noteId, note) {

    var noteType = 'item';
    var responseColl = [];

    if (Ext.isEmpty(itemCode)) {

        return responseColl;
    }

    if (Ext.isEmpty(noteId)) {

        return responseColl;
    }

    if (Ext.isEmpty(note)) {

        return responseColl;
    }

    noteType = note.getNoteType();

    if (noteType == 'item') {

        var noteColl = getNoteCollection(itemCode);
        var note;

        if (!(Ext.isEmpty(noteColl))) {
            note = noteColl.filter(function (noteObj) {
                return noteObj.NoteID == noteId;
            });

            if (note.length > 0) {
                responseColl = note[0].CR_Response_Collection;
            }

            responseColl.sort(orderBy('TS_UP', 'desc'));

            return responseColl;
        }
    }

    if (noteType == 'case') {

        Ext.each(note.data.CR_CaseNote_Response_Collection, function (response) {
            responseColl.push(response);
        });

        responseColl.sort(orderBy('TS_UP', 'desc'));

        return responseColl;
    }

    return responseColl;
}
// Recalculate item rating
var updateItemRating = function (ratingComponentId, ratingOverrideComponentId) {

    if (Ext.isEmpty(ratingComponentId) || Ext.isEmpty(ratingOverrideComponentId)) {

        return;
    }

    var ratingCmp = getCRSComponent(ratingComponentId);
    var ratingOverrideCmp = getCRSComponent(ratingOverrideComponentId);

    ratingCmp.setChangesExist(true);
    ratingCmp.setRecalcNeeded(true);
    ratingCmp.setRatingOverride(ratingOverrideCmp);

    var rating = ratingCmp.calculateRating();

    return rating;
}
// Get item rating description
var getItemRatingDescription = function (ratingCode) {

    if (Ext.isEmpty(ratingCode)) {

        return undefined;
    }

    var itemRatingStore = Ext.data.ChainedStore.create({
        source: 'ItemRatingStore',
        filters: [
            function (record) {
                return record.data.GroupID == ratingCode;
            }
        ]
    });

    if (itemRatingStore.data.length > 0) {
        return itemRatingStore.getAt(0).data.DescriptionLarge;
    }

    return undefined;
}
// Recalculate outcome rating
var updateOutcomeRating = function (ratingComponentId, ratingOverrideComponentId, input) {

    var outcomeRatingInput = {};
    var outcomeRating;
    var isItem16 = false;
    var outcomeCode;

    if (Ext.isEmpty(ratingComponentId)) {

        return;
    }

    if (Ext.isEmpty(ratingOverrideComponentId)) {

        return;
    }

    var ratingCmp = getCRSComponent(ratingComponentId.replace('#', ''));
    var ratingOverrideCmp = getCRSComponent(ratingOverrideComponentId.replace('#', ''));
    var overriddenRating = getItemRatingDescription(ratingOverrideCmp.getOverrideRating());
    var currentRating = ratingCmp.getValue();

    if (!Ext.isEmpty(overriddenRating)) {

        ratingCmp.setValue(overriddenRating);
    }

    ratingCmp.setRatingOverride(ratingOverrideCmp);
    outcomeCode = ratingCmp.getOutcomeCode();
    outcomeRatingInput['OutcomeCode'] = outcomeCode;

    var ratedItems = ratingCmp.ownerCt.ownerCt.ownerCt.queryBy(function (obj) {
        return obj.xtype == "itemRating" && obj.outcomeCode == outcomeCode &&
               obj.itemType !== 'outcome'
    });

    Ext.each(ratedItems, function (ratedItem) {
        var itemNo = ratedItem.getItemName().replace('item', '');

        outcomeRatingInput['Item' + itemNo + 'Rating'] = ratedItem.value;

        if (itemNo == 16) {
            isItem16 = true;
        }
    });

    if (isItem16 && !Ext.isEmpty(input)) {

        outcomeRatingInput['Item16A'] = input.Answer16A;
        outcomeRatingInput['Item16B'] = input.Answer16B;
    } else {

        var controller = getAppController();
        var item16AChecked = controller.getQuestion16AYes().checked ? 'Yes' :
                             controller.getQuestion16ANo().checked ? 'No' : undefined;

        var item16BChecked = controller.getQuestion16BYes().checked ? 'Yes' :
                             controller.getQuestion16BNo().checked ? 'No' :
                             controller.getQuestion16BNA().checked ? 'NA' : undefined;

        outcomeRatingInput['Item16A'] = item16AChecked;
        outcomeRatingInput['Item16B'] = item16BChecked;
    }

    // Reset item rating
    ratingCmp.setValue(currentRating);

    outcomeRating = ratingCmp.calculateOutcomeRating(outcomeRatingInput);

    var outcomeComponentId = ratingOverrideCmp.getOutcomeRatingComponentId();
    var outcomeRatingCmp = getCRSComponent(outcomeComponentId);

    // Update outcome rating
    if (!(outcomeRatingCmp == undefined)) {

        outcomeRatingCmp.setValue(outcomeRating.RatingDescription);
    }

    return outcomeRating;
}
// Update Response Collection
var updateResponseCollection = function (parms) {

    if (Ext.isEmpty(parms)) {

        return true;
    }

    var note = parms.note;
    var response = parms.response;

    // Process item types
    if (parms.noteType == 'item' || Ext.isEmpty(parms.noteType)) {

        // Process response if valid        
        var responseColl;
        var oldResponse = [];

        responseColl = note.CR_Response_Collection.length > 0 ? note.CR_Response_Collection :
                       Ext.isEmpty(note.data.CR_Response_Collection) ? note.CR_Response_Collection :
                       note.data.CR_Response_Collection;

        if (!Ext.isEmpty(responseColl)) {

            oldResponse = responseColl.filter(function (respObj) {
                return respObj.ResponseID == response.ResponseID &&
                        (!(Ext.isEmpty(respObj.Description)));
            });
        }

        if (oldResponse.length > 0) {
            // Update response
            Ext.each(responseColl, function (respToChange) {
                if (respToChange.ResponseID == response.ResponseID) {
                    respToChange = response;

                    return false;
                }
            });
        } else {
            // Add response
            if (!Ext.isEmpty(note.CR_Response_Collection)) {

                note.CR_Response_Collection.push(response.data);
            }
        }

        //updateNoteCollection(parms.itemCode, note);

        return true;
    }

    // Process case types
    if (parms.noteType == 'case') {

        var caseResponseStore = Ext.data.ChainedStore.create({
            source: 'CR_CaseNote_Response_CollectionStore',
            filters: [
                function (record) {
                    return record.data.ResponseID == response.data.ResponseID &&
                           (!(Ext.isEmpty(record.data.Description)));
                }
            ]
        });

        if (caseResponseStore.data.length > 0) {
            // Update response
            Ext.each(caseResponseStore.data.items, function (responseToChange) {
                if (responseToChange.ResponseID == response.data.ResponseID) {
                    responseToChange = response;

                    return false;
                }
            });
        } else {
            // Add response
            var model = caseResponseStore.add({});
            model[0].set("Description", response.data.Description);
            model[0].set("NoteID", response.data.NoteID);
        }
    }

    return true;
}
//  There is an issue with executing the following statement:
//  Ext.StoreMgr.get('App.CaseReview.store.CaseReviewTop')
//  .getAt(0)
//  .getData(true)
//
//  The statement does not return all the data for QA Notes. The following is a
//  workaround until a better solution is found.
//        
// Get all the data that need to be persisted to the database
var getAllPersistentData = function () {

    var notesChanged = false;

    var associatedData = Ext.StoreMgr.get('App.CaseReview.store.CaseReviewTop')
                            .getAt(0)
                            .getData(true);

    var currentData = Ext.StoreMgr.get('App.CaseReview.store.CaseReviewTop')
                .getAt(0)
                .getData();

    var modifiedNotes = [];
    var notesToAdd = [];
    var notesUpdated = [];
    
    Ext.each(currentData.CaseReview[0].CR_Outcome_Collection, function (record) {

        Ext.each(record.CR_Item_Collection, function (item) {

            Ext.each(item.CR_Note_Collection, function (note) {

                if (note.DataState == 0) {

                    if (item.DataState != 0) {

                        item.DataState = 0;
                    }

                    modifiedNotes.push(note);
                }

                if (Ext.isEmpty(note.NoteID) || note.NoteID == 0) {

                    notesToAdd.push(note);
                }
            });
        });
    });
    //
    // Add modified notes
    //
    Ext.each(associatedData.CaseReview[0].CR_Outcome_Collection, function (record) {

        Ext.each(record.CR_Item_Collection, function (item) {

            Ext.each(item.CR_Note_Collection, function (note) {

                var modifiedNote = modifiedNotes.filter(function (changedNote) {
                    return (changedNote.ItemID == note.ItemID && note.ItemID > 0) ||
                           (changedNote.ExtId == note.ExtId && !Ext.isEmpty(note.ExtId));
                });

                if (modifiedNote.length > 0) {

                    if (modifiedNote[0].NoteID == note.NoteID && note.NoteID > 0) {

                        var noteUpd = notesUpdated.filter(function (updNote) {
                            return updNote.NoteID == note.NoteID;
                        });

                        if (noteUpd.length == 0) {

                            note.DataState = modifiedNote[0].DataState;
                            note.Subject = modifiedNote[0].Subject;
                            note.Description = modifiedNote[0].Description;
                            note.IsResolved = modifiedNote[0].IsResolved;
                            note.TS_CR = modifiedNote[0].TS_CR;
                            note.TS_UP = modifiedNote[0].TS_UP;
                            note.CR_Response_Collection = modifiedNote[0].CR_Response_Collection;
                        }

                        notesUpdated.push(note);

                    } else {

                        if (Ext.isEmpty(modifiedNote[0].NoteID) || modifiedNote[0].NoteID == 0) {

                            notesToAdd.push(modifiedNote[0]);
                        }
                    }
                }

                if (Ext.isEmpty(note.NoteID) || note.NoteID == 0) {

                    notesToAdd.push(note);
                }
            });

            var keyParms = ['ItemID', 'Subject', 'Description'];
            notesToAdd = removeDuplicatesFromJsonArray(notesToAdd, keyParms);
            notesToAdd = removeInvalidNotes(notesToAdd);

            if (notesToAdd.length > 0) {

                Ext.each(notesToAdd, function (noteToAdd) {

                    if (Ext.isEmpty(item.CR_Note_Collection)) {

                        item.CR_Note_Collection = [];
                    }

                    var noteAdded = item.CR_Note_Collection.filter(function (noteInList) {
                        return (noteInList.ItemID == noteToAdd.ItemID && noteInList.ExtId == noteToAdd.ExtId &&
                                noteInList.NoteID == noteToAdd.NoteID && noteInList.Subject == noteToAdd.Subject &&
                                noteInList.Description == noteToAdd.Description);
                    });

                    if (noteAdded.length == 0) {

                        if (item.ItemCode == noteToAdd.ItemCode) {

                            item.CR_Note_Collection.push(noteToAdd);
                        }
                    }
                });
            }
        });
    });
    //
    // Remove deleted notes
    //
    var notesToRemove = [];

    Ext.each(associatedData.CaseReview[0].CR_Outcome_Collection, function (record) {

        Ext.each(record.CR_Item_Collection, function (item) {

            Ext.each(item.CR_Note_Collection, function (note) {

                var deletedNote = deletedQANotes.filter(function (removedNote) {
                    return (removedNote[0].NoteID == note.NoteID && note.NoteID > 0) ||
                           (removedNote[0].ExtId == note.ExtId && !Ext.isEmpty(note.ExtId));
                });

                if (deletedNote.length > 0) {

                    notesToRemove.push(note);
                }
            });

            if (notesToRemove.length > 0) {

                Ext.each(notesToRemove, function (noteToRemove) {

                    var index = -1;

                    for (var i = 0; i < item.CR_Note_Collection.length; i++) {

                        if (item.CR_Note_Collection[i].NoteID == noteToRemove.NoteID) {

                            index = i;

                            i = item.CR_Note_Collection.length;
                        }
                    }

                    if (index > -1) {

                        var removedNote = item.CR_Note_Collection.splice(index, 1);
                    }
                });
            }
        });
    });

    var updatedData = removeEmptyItems(associatedData);

    var outcomeColl = Ext.StoreMgr.get('App.CaseReview.store.CaseReviewTop').getAt(0).data.CaseReview[0].CR_Outcome_Collection;

    var outcomeCollRevised = outcomeColl.length == 8 ? outcomeColl : reorganizeOutcomeCollection(outcomeColl);

    notesChanged = notesUpdated.length > 0 ? true :
                   notesToAdd.length > 0 ? true : false;

    if (isFacesheetComplete() || notesChanged) {

        updatedData.CaseReview[0].CR_Outcome_Collection = outcomeCollRevised;
    }
    //
    // Remove duplicate participants
    //
    updatedData = removeDuplicateParticipants(updatedData);

    //
    // Update Datastate property of top-level collections
    //
    updatedData.CaseReview[0].CR_FaceSheet_Collection[0].DataState = 0;
    updatedData.CaseReview[0].CR_Safety_Collection[0].DataState = 0;

    if (getCaseType() == 'Foster Case') {

        updatedData.CaseReview[0].CR_Permanency_Collection[0].DataState = 0;
    }

    updatedData.CaseReview[0].CR_WellBeing_Collection[0].DataState = 0;

    Ext.each(updatedData.CaseReview[0].CR_Outcome_Collection, function (outcome) {

        Ext.each(outcome.CR_Item_Collection, function (item) {

            Ext.each(item.CR_ItemParticipant_Collection, function (itemParticipant) {

                if (!Ext.isEmpty(itemParticipant.CodeDescriptionID)) {

                    itemParticipant.DataState = 0;
                }
            });
        });

    });

    updatedData.CaseReviewLookUp = null;

    return updatedData;
}
var reorganizeOutcomeCollection = function (outcomeColl) {

    var result = [];
    var outColl = [];
    var outcomeObj;
    var outcomeCodes = [21, 1, 2, 3, 4, 5, 6, 7];
    var itemGroup;

    Ext.each(outcomeColl, function (outcome) {

        Ext.each(outcome.CR_Item_Collection, function (item) {

            outcomeObj = createOutcome(item, outcome.CaseReviewID);
            outcomeObj[0].data.OutcomeRatingCode = outcome.OutcomeRatingCode;

            outColl.push(outcomeObj[0].data);
        });
    });

    //
    // Group items into appropriate outcome in collection
    //
    var filteredColl;

    Ext.each(outcomeCodes, function (outcomeCode) {

        itemGroup = null;

        if (!Ext.isEmpty(outColl)) {

            filteredColl = outColl.filter(function (outcome) {

                return outcome.OutcomeCode == outcomeCode;
            });

            if (!Ext.isEmpty(filteredColl)) {

                if (filteredColl.length > 0) {

                    itemGroup = filteredColl[0];
                }

                for (var i = 1; i < filteredColl.length; i++) {

                    itemGroup.CR_Item_Collection.push(filteredColl[i].CR_Item_Collection[0]);
                }

                if (!Ext.isEmpty(itemGroup)) {

                    result.push(itemGroup);
                }
            }
        }
    })

    return result;
}
var createOutcome = function (item, caseReviewId) {

    var outcomeColl = {};

    if (Ext.isEmpty(item)) {

        return outcomeColl
    }

    var outcomeCode = getOutcomeCode(item.ItemCode);

    outcomeColl = Ext.data.StoreManager.get('CR_Outcome_CollectionStore').add({});
    var index = outcomeColl.length - 1;

    outcomeColl[index].set("CaseReviewID", caseReviewId);
    outcomeColl[index].set("OutcomeCode", outcomeCode);
    outcomeColl[index].set("DataState", 0);
    outcomeColl[index].set("CR_Item_Collection", [item]);

    return outcomeColl;
}
var updateDatastate = function (data) {

    if (Ext.isEmpty(data)) {

        return data;
    }

    var objVal;
    var requiredFields;
    var objKeys = getObjectKeys(data);

    data.DataState = 0;

    Ext.each(objKeys, function (key) {

        objVal = data[key];

        if (Array.isArray(objVal)) {

            if (objVal.length > 0) {

                Ext.each(objVal, function (obj) {

                    requiredFields = getRequiredFields(key, obj);

                    if (!Ext.isEmpty(obj.DataState) && isObjectValid(requiredFields)) {

                        updateDatastate(obj);
                    }
                });
            }
        }
    });

    return data;
}
var isObjectValid = function (obj) {

    var retval = true;

    var keys = getObjectKeys(obj);

    Ext.each(keys, function (key) {

        if (Ext.isEmpty(obj[key])) {

            retval = false;

            return false;
        }
    });

    return retval;
}
var getRequiredFields = function (storeKey, valueObj) {

    var returnObj = {};

    if (Ext.isEmpty(valueObj)) {

        return returnObj;
    }

    switch (storeKey) {

        case 'CR_MultiAnswer_Collection':

            returnObj = { 'CodeDescriptionID': valueObj.CodeDescriptionID, 'AnswerCode': valueObj.AnswerCode };

            break;

        case 'CR_Outcome_Collection':

            returnObj = { 'OutcomeCode': valueObj.OutcomeCode };

            break;

        case 'CR_Permanency_Collection':

            returnObj = { 'CaseReviewID': valueObj.CaseReviewID };

            break;

        case 'CR_Safety_Collection':

            returnObj = { 'CaseReviewID': valueObj.CaseReviewID };

            break;

        case 'CR_WellBeing_Collection':

            returnObj = { 'CaseReviewID': valueObj.CaseReviewID };

            break;

        case 'CR_CaseNote_Collection':

            returnObj = { 'CaseReviewID': valueObj.CaseReviewID, 'Subject': valueObj.Subject, 'Description': valueObj.Description, 'IsResolved': valueObj.IsResolved };

            break;

        case 'CR_CaseNote_Response_Collection':

            returnObj = { 'NoteID': valueObj.NoteID, 'Description': valueObj.Description };

            break;

        case 'CR_Note_Collection':

            returnObj = { 'ItemID': valueObj.ItemID, 'Subject': valueObj.Subject, 'Description': valueObj.Description, 'IsResolved': valueObj.IsResolved };

            break;

        case 'CR_Response_Collection':

            returnObj = { 'NoteID': valueObj.NoteID, 'Description': valueObj.Description };

            break;

        case 'CR_ChildDemographic_Collection':

            returnObj = { 'Name': valueObj.Name, 'EthnicityCode': valueObj.EthnicityCode, 'DateOfBirth': valueObj.DateOfBirth, 'GenderCode': valueObj.GenderCode };

            break;

        case 'CR_CaseParticipant_Collection':

            returnObj = { 'Name': valueObj.Name, 'RoleCode': valueObj.RoleCode, 'RelationshipToChild': valueObj.RelationshipToChild };

            break;

        case 'CR_ItemParticipant_Collection':

            returnObj = { 'ItemID': valueObj.ItemID, 'CodeDescriptionID': valueObj.CodeDescriptionID };

            break;

        case 'CR_Education_Collection':

            returnObj = { 'WellBeingID': valueObj.WellBeingID, 'Needs': valueObj.Needs, 'ServicesProvided': valueObj.ServicesProvided };

            break;

        case 'CR_Goal_Collection':

            returnObj = {
                'PermanencyID': valueObj.PermanencyID, 'GoalCode': valueObj.Goal1Code,
                'DateEstablished': valueObj.DateEstablished, 'TimeInFosterCare': valueObj.TimeInFosterCare,
                'TimeUnitCode': valueObj.TimeUnitCode, 'IsCurrentGoal': valueObj.IsCurrentGoal
            };

            break;

        case 'CR_Health_Collection':

            returnObj = { 'WellBeingID': valueObj.WellBeingID, 'HealthNeeds': valueObj.HealthNeeds, 'ServicesProvided': valueObj.ServicesProvided, 'HealthNeedCode': valueObj.HealthNeedCode };

            break;

        case 'CR_Item_Collection':

            returnObj = { 'OutcomeID': valueObj.OutcomeID, 'ItemCode': valueObj.ItemCode };

            break;

        case 'CR_Placement_Collection':

            returnObj = { 'PermanencyID': valueObj.PermanencyID, 'TypeCode': valueObj.TypeCode, 'Date': valueObj.Date };

            break;

        case 'CR_SafetyReport_Collection':

            returnObj = { 'SafetyID': valueObj.SafetyID, 'ChildDemographicID': valueObj.ChildDemographicID, 'ReportDate': valueObj.ReportDate, 'PriorityLevel': valueObj.PriorityLevel, 'AssessmentCode': valueObj.AssessmentCode };

            break;

        case 'CR_SafetyReport_Allegation_Collection':

            returnObj = { 'SafetyReportID': valueObj.SafetyReportID, 'SafetyReportAllegationCode': valueObj.SafetyReportAllegationCode };

            break;

        default:

            break;
    }

    return returnObj;
}
var getItemRatingCode = function (ratingDesc) {

    var result = {};

    result['RatingDescription'] = ratingDesc;

    if (!Ext.isEmpty(ratingDesc)) {

        var itemRatingStore = Ext.data.ChainedStore.create({
            source: 'ItemRatingStore',
            filters: [
                function (record) {
                    return record.data.DescriptionLarge == ratingDesc;
                }
            ]
        });

        if (!(itemRatingStore.getAt(0) == null)) {

            result['RatingCode'] = itemRatingStore.getAt(0).data.GroupID;
        }

        return result;
    }

    return result;
}
var removeEmptyItems = function (collection) {

    var itemsToRemove = [];
    var outcomesToRemove = [];

    if (Ext.isEmpty(collection)) {

        return collection;
    }

    Ext.each(collection.CaseReview[0].CR_Outcome_Collection, function (record) {

        itemsToRemove = [];

        if (record.OutcomeCode == 0 || Ext.isEmpty(record.OutcomeCode)) {

            outcomesToRemove.push(record);
        } else {

            Ext.each(record.CR_Item_Collection, function (item) {

                if (item.ItemCode == 0 || Ext.isEmpty(item.ItemCode)) {

                    itemsToRemove.push(item);
                }
            });

            Ext.each(itemsToRemove, function (itemToRemove) {

                var index = -1;

                for (var i = 0; i < record.CR_Item_Collection.length; i++) {

                    if (record.CR_Item_Collection[i].ItemID == itemToRemove.ItemID) {

                        index = i;

                        i = record.CR_Item_Collection.length;
                    }
                }

                if (index > -1) {

                    var removedItem = record.CR_Item_Collection.splice(index, 1);
                }
            });
        }
    });

    //
    // Remove empty outcomes
    //
    var outcomes = collection.CaseReview[0].CR_Outcome_Collection;

    Ext.each(outcomesToRemove, function (outcomeToRemove) {

        var index = -1;

        for (var i = 0; i < outcomes.length; i++) {

            if (outcomes[i].OutcomeID == outcomeToRemove.OutcomeID) {

                index = i;

                i = outcomes.length;
            }
        }

        if (index > -1) {

            var removedOutcome = outcomes.splice(index, 1);
        }
    });

    return collection;
}
var removeDuplicateParticipants = function (data) {

    var result;
    var participants;
    var itemColl, participantColl, motherColl, fatherColl;
    var participantsToRemove = [];
    var motherToKeep, fatherToKeep;

    if (!Ext.isEmpty(data)) {

        var outcomeColl = data.CaseReview[0].CR_Outcome_Collection;

        Ext.each(outcomeColl, function (outcome) {

            itemColl = outcome.CR_Item_Collection;
            participantsToRemove = [];

            Ext.each(itemColl, function (item) {

                participantColl = item.CR_ItemParticipant_Collection;

                if (!Ext.isEmpty(participantColl)) {

                    if (participantColl.length > 1) {

                        motherColl = participantColl.filter(function (participant) {

                            return participant.CodeDescriptionID == 269;
                        });

                        if (motherColl.length > 1) {

                            Ext.each(motherColl, function (mother) {

                                if (Ext.isEmpty(motherToKeep)) {

                                    motherToKeep = mother;
                                }

                                if (mother.ItemParticipantID > motherToKeep.ItemParticipantID) {

                                    participantsToRemove.push(motherToKeep);

                                    motherToKeep = mother;
                                }

                                if (mother.ItemParticipantID < motherToKeep.ItemParticipantID) {

                                    participantsToRemove.push(mother);
                                }
                            });
                        }

                        fatherColl = participantColl.filter(function (participant) {

                            return participant.CodeDescriptionID == 270;
                        });

                        if (fatherColl.length > 1) {

                            Ext.each(fatherColl, function (father) {

                                if (Ext.isEmpty(fatherToKeep)) {

                                    fatherToKeep = father;
                                }

                                if (father.ItemParticipantID > fatherToKeep.ItemParticipantID) {

                                    participantsToRemove.push(fatherToKeep);

                                    fatherToKeep = father;
                                }

                                if (father.ItemParticipantID < fatherToKeep.ItemParticipantID) {

                                    participantsToRemove.push(father);
                                }
                            });
                        }
                        //
                        // Remove unneeded participants
                        //
                        var participantsToKeep = participantColl.filter(function (partToKeep) {

                            var filteredPart = participantsToRemove.filter(function (partToRemove) {

                                return partToKeep.ItemParticipantID == partToRemove.ItemParticipantID;
                            });

                            if (filteredPart.length == 0) {

                                return partToKeep;
                            }
                        });

                        item.CR_ItemParticipant_Collection = participantsToKeep;
                    }
                }
            });
        });
    }

    return data;
}
// Stores for Comboboxes used for QA notes filtering
var qaNotesSummary;
Ext.define('Reviewer', {
    extend: 'Ext.data.Model',
    fields: [
        { name: 'userName', type: 'string' },
        { name: 'fldValue', type: 'string' }
    ]
});
Ext.define('Options', {
    extend: 'Ext.data.Model',
    fields: [
        { name: 'displayText', type: 'string' },
        { name: 'fldValue', type: 'int' }
    ]
});
Ext.define('ItemModel', {
    extend: 'Ext.data.Model',
    fields: [
        { name: 'itemName', type: 'string' },
        { name: 'fldValue', type: 'string' }
    ]
});
var resolvedOptions = Ext.create('Ext.data.Store', {
    model: 'Options',
    data: [
        { "displayText": "Any", "fldValue": 0 },
        { "displayText": "Yes", "fldValue": 1 },
        { "displayText": "No", "fldValue": 2 }
    ]
});
var itemNameList = Ext.create('Ext.data.Store', {
    model: 'ItemModel',
    data: [
        { "itemName": "Any", "fldValue": "Any" },
        { "itemName": "case", "fldValue": "case" },
        { "itemName": "facesheet", "fldValue": "facesheet" },
        { "itemName": "item1", "fldValue": "item1" },
        { "itemName": "item2", "fldValue": "item2" },
        { "itemName": "item3", "fldValue": "item3" },
        { "itemName": "item4", "fldValue": "item4" },
        { "itemName": "item5", "fldValue": "item5" },
        { "itemName": "item6", "fldValue": "item6" },
        { "itemName": "item7", "fldValue": "item7" },
        { "itemName": "item8", "fldValue": "item8" },
        { "itemName": "item9", "fldValue": "item9" },
        { "itemName": "item10", "fldValue": "item10" },
        { "itemName": "item11", "fldValue": "item11" },
        { "itemName": "item12", "fldValue": "item12" },
        { "itemName": "item12A", "fldValue": "item12A" },
        { "itemName": "item12B", "fldValue": "item12B" },
        { "itemName": "item12C", "fldValue": "item12C" },
        { "itemName": "item13", "fldValue": "item13" },
        { "itemName": "item14", "fldValue": "item14" },
        { "itemName": "item15", "fldValue": "item15" },
        { "itemName": "item16", "fldValue": "item16" },
        { "itemName": "item17", "fldValue": "item17" },
        { "itemName": "item18", "fldValue": "item18" }
    ]
});
var userList = Ext.create('Ext.data.Store', {
    model: 'Reviewer',
    data: []
});
var userStore = function () {

    buildCaseNotesCollection();

    return getAppUsers();
};
var itemNameStore = function () {

    buildCaseNotesCollection();

    return getAppItems();
};
var isFacesheetComplete = function () {

    var result;
    var keys;
    var questionVal;
    var loopResult;

    if (!Ext.isEmpty(facesheetQuestions)) {

        Ext.each(facesheetQuestions[0].facesheet, function (question) {

            loopResult = true;

            keys = Object.keys(question);

            Ext.each(keys, function (key) {

                questionVal = question[key];

                if (questionVal.required) {

                    if (!questionVal.answered) {

                        result = false;
                        loopResult = false;

                        return false;
                    }
                }
            });

            return loopResult;
        });
    }

    if (Ext.isEmpty(result)) {

        result = true;

        itemStatuses['facesheet'] = 'Completed';
    }

    return result;
}
var areAllNotesResolved = function () {

    var result = true;

    if (!Ext.isEmpty(qaNotesSummary)) {

        var itemNotes = qaNotesSummary.notesCollection;

        Ext.each(itemNotes, function (note) {

            Ext.each(note.objValue, function (itemNote) {

                if (!itemNote.getResolved()) {

                    result = false;

                    return false;
                }
            });
        });
    }

    return result;
}
var findStore = function (storeId) {

    var result;
    var continueLookup = true;
    var store;

    if (Ext.isEmpty(storeId)) {

        return result;
    }

    store = Ext.data.StoreManager.lookup(storeId);
    var idPrefix = storeId.replace('_CollectionStore', '');

    if (!Ext.isEmpty(store)) {

        if (store.data.length > 0) {

            Ext.each(store.data.items, function (item) {

                if (item.store.storeId == storeId) {

                    result = item;

                    continueLookup = false;

                } else {

                    var idIndex = -1;

                    if (!Ext.isEmpty(idPrefix) && !Ext.isEmpty(item.id)) {

                        idIndex = item.id.indexOf(idPrefix);
                    }

                    if (idIndex > -1) {

                        result = item;

                        continueLookup = false;
                    } else {

                        if (!Ext.isEmpty(item['store'])) {

                            if (item['store'].storeId == storeId) {

                                result = item['store'];

                                continueLookup = false;

                                return false;
                            }
                        }
                    }
                }

                return continueLookup;
            });
        }
    }

    if (Ext.isEmpty(result)) {

        result = store;
    }

    return result;
}
var removeMultiAnswerGroup = function (coll, groupName) {

    if (Ext.isEmpty(coll)) {

        return coll;
    }
    //
    // Sort by group name
    //
    var sortedColl = Ext.isEmpty(coll.data) ? coll.sort(orderBy('GroupName', 'asc')) : coll.sort();

    if (Ext.isEmpty(groupName)) {

        return sortedColl;
    }

    var groupMembers = sortedColl.filter(function (member) {

        if (Ext.isEmpty(coll.data)) {

            return member.GroupName == groupName;
        } else {

            return member.data.GroupName == groupName;
        }
    });

    var index = -1;

    for (var i = 0; i < sortedColl.length; i++) {

        if (Ext.isEmpty(sortedColl[i].data)) {

            if (sortedColl[i].GroupName == groupName) {

                index = i;

                break;
            }
        } else {

            if (sortedColl[i].data.GroupName == groupName) {

                index = i;

                break;
            }
        }
    }

    if (index == -1) {

        return coll;
    }

    var result = sortedColl.splice(index, groupMembers.length);

    return sortedColl;
};
var updateMultiAnswerStore = function (parms) {

    var itemsToAdd = [];

    var extMultiAnswerStore = chainedStore('CR_MultiAnswer_CollectionStore').data;

    if (extMultiAnswerStore.items.length == 0) {

        return;
    }

    var caseReviewMultiAnswerStore = chainedStore('CaseReviewStore').getAt(0).data.CR_MultiAnswer_Collection;

    Ext.each(extMultiAnswerStore.items, function (extItem) {

        var caseReviewItem = caseReviewMultiAnswerStore.filter(function (item) {

            return item.CodeDescriptionID == extItem.data.CodeDescriptionID;
        });

        if (caseReviewItem.length > 0) {

            if (!(caseReviewItem[0].AnswerCode == extItem.data.AnswerCode)) {

                if (!Ext.isEmpty(extItem.data.AnswerCode)) {

                    caseReviewItem[0].AnswerCode = extItem.data.AnswerCode;
                }
            }
        } else {

            if (!Ext.isEmpty(extItem.data.AnswerCode)) {

                itemsToAdd.push(extItem.data);
            }
        }
    });

    if (itemsToAdd.length == 0) {

        caseReviewMultiAnswerStore = extMultiAnswerStore;

        return;
    }

    Ext.each(itemsToAdd, function (item) {

        caseReviewMultiAnswerStore.push(item);
    });
}
var updateItemParticipantStore = function (parms) {

    if (Ext.isEmpty(parms)) {

        return;
    }

    var store = parms.fieldType == 'MultiAnswer' ? getMultiAnswerStore(parms.groupName, parms.groupMembers, parms.groupItemName) : chainedStore(parms.storeId);
    var codeDescId;
    var itemParticipantId;
    var participant;
    var partId;

    if (parms.storeId == 'CR_ItemParticipant_CollectionStore') {
        //
        // Create participant item
        //
        partId = parms.fields.filter(function (field) {

            if (!Ext.isEmpty(field.ParticipantID)) {

                return field;
            }

        })[0].ParticipantID;

        codeDescId = parms.fields.filter(function (field) { return field.CodeDescriptionID; })[0].CodeDescriptionID;

        var itemParticipantIds = parms.fields.filter(function (field) {

            if (!Ext.isEmpty(field.ItemParticipantID)) {

                return field;
            }
        });

        if (itemParticipantIds.length > 0) {

            itemParticipantId = itemParticipantIds[0].ItemParticipantID;
        }

        participant = store.data.items.filter(function (item) {

            return item.data.CodeDescriptionID == codeDescId;
        });

        if (participant.length == 0) {

            if (!(partId == 0)) {

                var itemParticipant = {
                    CodeDescriptionID: codeDescId,
                    ParticipantID: partId,
                    DataState: 0
                };

                var inputObj = { objectType: 'itemParticipant', outcomeCode: getOutcomeCode(parms.itemCode), itemCode: parms.itemCode, DataState: 0, objValue: itemParticipant };
                addCRSObject(inputObj);

                store = chainedStore(parms.storeId);
            }

        } else {
            //
            // Delete de-selected participant
            //
            if (partId == 0) {

                //
                // Delete item from graph
                //
                var participants = chainedStore('CaseReviewStore').getAt(0).data.CR_Outcome_Collection.filter(function (outcome) {

                    return outcome.OutcomeCode == parms.outcomeCode;

                })[0]
                    .CR_Item_Collection.filter(function (item) {

                        return item.ItemCode == parms.itemCode;

                    })[0]
                        .CR_ItemParticipant_Collection.filter(function (part) {

                            return part.ItemParticipantID != itemParticipantId;
                        });

                var graphItems = chainedStore('CaseReviewStore').getAt(0).data.CR_Outcome_Collection.filter(function (outcome) {

                    return outcome.OutcomeCode == parms.outcomeCode;

                })[0]
                    .CR_Item_Collection.filter(function (item) {

                        return item.ItemCode == parms.itemCode;

                    })[0];

                graphItems.CR_ItemParticipant_Collection = participants;
                //
                // Delete item from store
                //
                var participantsInStore = chainedStore('CR_ItemParticipant_CollectionStore');

                var deletedPart = chainedStore('CR_ItemParticipant_CollectionStore').data.items.filter(function (extPart) {

                    return extPart.data.ItemParticipantID == itemParticipantId;

                });

                var remainingPart = chainedStore('CR_ItemParticipant_CollectionStore').data.items.filter(function (extPart) {

                    return extPart.data.ItemParticipantID != itemParticipantId;

                });

                participantsInStore.data.remove(deletedPart[0]);
            }
        }
    }
}
var updateStore = function (parms) {

    if (Ext.isEmpty(parms)) {

        return;
    }

    if (Ext.isEmpty(parms.storeId)) {

        return;
    }

    if (parms.recordType == 'Grid') {

        updateGridStore(parms);

        return;
    }

    if (parms.fields.length == 0) {

        return;
    }

    if (parms.storeId == 'CR_Item_CollectionStore') {

        var item = getItem(parms.itemCode, parms.outcomeCode);

        var keys;
        var result;

        Ext.each(parms.fields, function (field) {

            keys = getObjectKeys(field);

            for (key in item) {

                result = keys.filter(function (keyItem) {

                    return keyItem == key;
                });

                if (result.length > 0) {
                    //
                    // Update
                    //
                    item[key] = field[key];
                }
            }
        });

        return;
    }

    var store;

    if (parms.fieldType == 'MultiAnswer') {

        if (!Ext.isEmpty(parms.groupMembers)) {

            if (parms.groupName == 'Applicability') {

                if (!Ext.isEmpty(parms.groupMembers) && !Ext.isEmpty(parms.groupItemName)) {

                    store = getMultiAnswerStore(parms.groupName, parms.groupMembers, parms.groupItemName);
                }
            } else {

                store = getMultiAnswerStore(parms.groupName);
            }
        }
    } else {

        store = chainedStore(parms.storeId);
    }

    var codeDescId;
    var itemParticipantId;
    var participant;
    var partId;

    if (parms.storeId == 'CR_ItemParticipant_CollectionStore') {

        updateItemParticipantStore(parms);

        return;
    }

    var modifiedParms = parms;

    Ext.each(parms.fields, function (field) {

        if (!Ext.isEmpty(field.KeyField)) {
            //
            // Multi-answer store update
            //
            if (!Ext.isEmpty(store)) {

                var filteredRecord = store.data.items.filter(function (record) {
                    return record.data[field.KeyField] == field[field.KeyField];
                });

                if (filteredRecord.length > 0) {

                    if (!Ext.isEmpty(field['AnswerCode']) && !Ext.isEmpty(field['GroupName'])) {

                        if (field['AnswerCode'] == 0) {

                            store.data.remove(filteredRecord[0].data);
                        } else {

                            filteredRecord[0].set("AnswerCode", field['AnswerCode']);
                            filteredRecord[0].set("GroupName", field['GroupName']);
                            filteredRecord[0].set("CaseReviewID", getCaseReviewId());
                        }
                    }
                } else {
                    // Add new record
                    var loggedInUser = GetLoggedInUser();
                    var model = store.add({});
                    var parmObj = {};
                    var reviewId = getCaseReviewId();

                    if (field['AnswerCode'] == 0) {

                        var caseReviewMultiAnswerStore = chainedStore('CaseReviewStore').getAt(0).data.CR_MultiAnswer_Collection;

                        var caseReviewItem = caseReviewMultiAnswerStore.filter(function (item) {

                            return item.CodeDescriptionID == field[field.KeyField];
                        });

                        if (caseReviewItem.length > 0) {

                            var index;

                            Ext.each(caseReviewItem, function (reviewItem) {

                                index = caseReviewMultiAnswerStore.indexOf(reviewItem);

                                caseReviewMultiAnswerStore.splice(index, 1);
                            });
                        }
                    } else {

                        model[0].set(field.KeyField, field[field.KeyField]);
                        model[0].set("AnswerCode", field['AnswerCode']);
                        model[0].set("GroupName", field['GroupName']);
                        model[0].set("CaseReviewID", reviewId);
                    }
                }
            }

            updateMultiAnswerStore(parms);

        } else {

            var viewModel = getAppController().viewModel;

            for (key in field) {

                var result;

                if (key == 'Goal2Code') {

                    if (store.getAt(0).store.storeId == 'CR_Permanency_CollectionStore') {

                        if (store.getAt(0).data['Goal2Code'] == 0) {

                            result = store.getAt(0).data[key] = field[key];
                            //
                            // Force update of ViewModel
                            //
                            var itemId = 'CR_Permanency_Collection.' + key;

                            viewModel.setValue(itemId, result);
                        }
                    }
                } else {

                    if (store.data.length > 0) {

                        if (store.getAt(0).store.storeId == 'CR_ItemParticipant_CollectionStore') {

                            var graphParticipants = chainedStore('CaseReviewStore').getAt(0).data.CR_Outcome_Collection.filter(function (outcome) {

                                return outcome.OutcomeCode == parms.outcomeCode;

                            })[0]
                                .CR_Item_Collection.filter(function (item) {

                                    return item.ItemCode == parms.itemCode;

                                })[0]
                                    .CR_ItemParticipant_Collection;

                            var extParticipants = chainedStore('CR_ItemParticipant_CollectionStore');
                            var filteredPart;

                            Ext.each(graphParticipants, function (graphPart) {

                                filteredPart = extParticipants.data.items.filter(function (extPart) {

                                    return extPart.data.ItemParticipantID == graphPart.ItemParticipantID;
                                });

                                if (filteredPart.length == 0) {

                                    extParticipants.add(graphPart);
                                }
                            });
                        } else {

                            var collectionId = store.getAt(0).store.storeId.replace('Store', '');

                            var graphCollection = chainedStore('CaseReviewStore').getAt(0).data[collectionId];
                            //
                            // Update EXT Collection
                            //
                            store.getAt(0).data[key] = field[key];
                            graphCollection[0][key] = field[key];
                        }
                    }
                }
            }
        }
    });
};
var updateGridStore = function (parms) {

    if (Ext.isEmpty(parms)) {

        return;
    }

    if (!(parms.recordType == 'Grid')) {

        return;
    }

    var caseReviewStore = chainedStore('CaseReviewStore').getAt(0).data;
    var store = chainedStore(parms.storeId);
    var items = [];

    Ext.each(store.data.items, function (item) {

        items.push(item.data);
    });

    switch (parms.storeId) {

        case 'CR_Health_CollectionStore':

            caseReviewStore.CR_WellBeing_Collection[0].CR_Health_Collection = items;

            break;

        case 'CR_Education_CollectionStore':

            caseReviewStore.CR_WellBeing_Collection[0].CR_Education_Collection = items;

            break;

        case 'CR_ChildDemographic_CollectionStore':

            caseReviewStore.CR_FaceSheet_Collection[0].CR_ChildDemographic_Collection = items;

            break;

        case 'CR_CaseParticipant_CollectionStore':

            caseReviewStore.CR_FaceSheet_Collection[0].CR_CaseParticipant_Collection = items;

            break;

        case 'CR_SafetyReport_CollectionStore':

            caseReviewStore.CR_Safety_Collection[0].CR_SafetyReport_Collection = items;

            break;

        case 'CR_Placement_CollectionStore':

            caseReviewStore.CR_Permanency_Collection[0].CR_Placement_Collection = items;

            break;

        case 'CR_Goal_CollectionStore':

            caseReviewStore.CR_Permanency_Collection[0].CR_Goal_Collection = items;

            break;

        default:

            break;
    }
};
var cloneStoreData = function (source) {

    source = Ext.isString(source) ? Ext.data.StoreManager.lookup(source) : source;

    var target = [];

    if (!Ext.isEmpty(source)) {

        Ext.each(source.getRange(), function (record) {

            target.push(record);
        });
    }

    return target;
}
var getParticipantsSelected = function (parms) {

    var result = {};
    var mothers = [];
    var fathers = [];

    if (Ext.isEmpty(parms)) {

        return result;
    }

    var item = getItemFromGraph(parms.ItemCode, parms.OutcomeCode);

    if (!Ext.isEmpty(item)) {

        Ext.each(item.CR_ItemParticipant_Collection, function (itemParticipant) {

            if (itemParticipant.CodeDescriptionID == 269) {

                mothers.push(itemParticipant);
            }

            if (itemParticipant.CodeDescriptionID == 270) {

                fathers.push(itemParticipant);
            }
        });
    }

    result['MotherSelected'] = mothers.length > 0 ? true : false;
    result['FatherSelected'] = fathers.length > 0 ? true : false;
    result['Mothers'] = mothers;
    result['Fathers'] = fathers;

    return result;
}
//
// Use to get the last selected item in checkboxgroup
//
var getLastSelection = function (cmp, newSelection, oldSelection) {
    var selectedItem;
    var selectedItems = [];
    var oldSelections = [];
    var result = [];
    var item;
    var filteredItem;

    if (Ext.isEmpty(cmp)) {

        return result;
    }

    for (key in oldSelection) {

        item = {};
        item['idName'] = key;
        item['idValue'] = oldSelection[key];

        oldSelections.push(item);
    }

    for (key in newSelection) {

        selectedItem = oldSelections.filter(function (selection) {

            return selection && selection.idName == key;
        });

        if (selectedItem.length == 0) {

            item = {};
            item['idName'] = key;
            item['idValue'] = newSelection[key];

            selectedItems.push(item);
        }
    }

    Ext.each(selectedItems, function (selItem) {

        filteredItem = cmp.items.items.filter(function (item) {

            return selItem.idName == item.inputId;
        });

        if (filteredItem.length > 0) {

            Ext.each(filteredItem, function (fItem) {

                result.push(fItem);
            });
        }
    });

    return result;
}
//
// Use to update MultiAnswer store
//
var getRadioSelections = function (radio, newValue, groupName) {

    var parms = { currentVal: false };

    if (Ext.isEmpty(radio)) {

        return parms;
    }

    if (!Ext.isEmpty(newValue)) {

        var fields = [];

        for (key in newValue) {

            var field = { 'CodeDescriptionID': radio.codeDescValue, 'AnswerCode': newValue[key], 'KeyField': 'CodeDescriptionID', 'GroupName': groupName };
            fields.push(field);
        }

        parms = { currentVal: newValue };
        parms['storeId'] = 'CR_MultiAnswer_CollectionStore';
        parms['fieldType'] = 'MultiAnswer';
        parms['fields'] = fields;
        parms['groupName'] = groupName;
    }

    return parms;
};
//
// Another version to use to update MultiAnswer store
//
var getRadioSelections2 = function (radio, newValue, groupName) {

    var parms = { currentVal: false };

    if (Ext.isEmpty(radio)) {

        return parms;
    }

    var getElementInputValue = function () {

        var result;

        var radioItems = radio.el.component.items.items;

        Ext.each(radioItems, function (radioItem) {

            if (radioItem.checked) {

                result = radioItem.inputValue;

                return false;
            }
        });

        return result;
    }

    if (newValue) {

        var fields = [];
        var codeDescVal = radio.xtype == 'radiogroup' ? radio.codeDescValue : radio.ownerCt.codeDescValue;
        var answerCode = radio.xtype == 'radiogroup' ? getElementInputValue() : radio.inputValue;

        var field = { 'CodeDescriptionID': codeDescVal, 'AnswerCode': answerCode, 'KeyField': 'CodeDescriptionID', 'GroupName': groupName };

        fields.push(field);

        parms = { currentVal: newValue };
        parms['storeId'] = 'CR_MultiAnswer_CollectionStore';
        parms['fieldType'] = 'MultiAnswer';
        parms['fields'] = fields;
        parms['groupName'] = groupName;
    }

    return parms;
};
//
// Use to initialize Validation Messages
//
var resetValidationMessages = function (containerIds) {

    Ext.each(containerIds, function (containerId) {

        var container = getCRSComponent(containerId);

        if (!Ext.isEmpty(container)) {

            var msgList = container.query('validationMessage');

            if (msgList.length > 0) {

                Ext.each(msgList, function (vMsg) {

                    if (!Ext.isEmpty(vMsg)) {

                        vMsg.initMessages();

                        vMsg.value = '';
                    }
                });
            }
        }
    });
};
var getCheckboxSelections = function (newValue, groupName, fieldType) {

    var parms = { currentVal: newValue };

    if (Ext.isEmpty(groupName)) {

        groupName = "";
    }

    if (!Ext.isEmpty(newValue)) {

        var fields = [];

        for (key in newValue) {

            var field = { 'CodeDescriptionID': newValue[key], 'AnswerCode': 1, 'KeyField': 'CodeDescriptionID', 'GroupName': groupName };
            fields.push(field);
        }

        var parms2 = {
            storeId: 'CR_MultiAnswer_CollectionStore',
            fields: fields,
            fieldType: fieldType,
            groupName: groupName
        };

        //parms = concatJsonObjects(parms, [parms2]);
        parms = Ext.apply(parms, parms2);
    }

    return parms;
};
var getStatusParms = function (parms, ratingId) {

    if (Ext.isEmpty(parms)) {

        parms = {};
    }

    if (Ext.isEmpty(ratingId)) {

        return parms;
    }

    var ratingCmp = getCRSComponent(ratingId);

    if (!Ext.isEmpty(ratingCmp)) {

        var parms2 = {
            itemName: ratingCmp.itemName,
            itemCode: ratingCmp.itemCode,
            outcomeCode: ratingCmp.outcomeCode,
            ratingId: ratingId,
            ratingOverrideId: ratingId + 'Override'
        };

        //parms = concatJsonObjects(parms, [parms2]);
        parms = Ext.apply(parms, parms2);
    }

    return parms;
};
var updateTabAccessibility = function () {

    var appController = getAppController();

    var caseReviewStore = Ext.StoreManager.get('CaseReviewStore');

    if (!Ext.isEmpty(caseReviewStore) && caseReviewStore.count() > 0) {

        var caseType = getCaseType();

        if (!Ext.isEmpty(caseType)) {

            if (caseType == 'Foster Case') {

                appController.getItem12AChildParticipants().setHidden(true);
                appController.getItem13ChildParticipants().setHidden(true);
                appController.getItem16ChildParticipants().setHidden(true);
                appController.getItem17ChildParticipants().setHidden(true);
                appController.getItem18ChildParticipants().setHidden(true);

            } else {

                appController.getPermanency().setDisabled(true);
                appController.getPermanencySectionLeftNav().disable();
            }

            if (isFacesheetComplete()) {

                appController.getSafety().setDisabled(false);
                appController.getSafetySectionLeftNav().enable();

                if (caseType == 'Foster Case') {

                    appController.getPermanency().setDisabled(false);
                    appController.getPermanencySectionLeftNav().enable();
                }

                appController.getWellBeing().setDisabled(false);
                appController.getWellbeingSectionLeftNav().enable();
                //
                // Update case status
                //

                return;
            }

            appController.getSafety().setDisabled(true);
            appController.getSafetySectionLeftNav().disable();

            appController.getPermanency().setDisabled(true);
            appController.getPermanencySectionLeftNav().disable();

            appController.getWellBeing().setDisabled(true);
            appController.getWellbeingSectionLeftNav().disable();
        }
    }
}
var resetDatachangeIndicators = function () {

    appDataEvent.facesheet.dataChanged = false;
    appDataEvent.safety.dataChanged = false;
    appDataEvent.permanency.dataChanged = false;
    appDataEvent.wellbeing.dataChanged = false;

    appDataEvent.facesheet.changeByUserAction = false;
    appDataEvent.safety.changeByUserAction = false;
    appDataEvent.permanency.changeByUserAction = false;
    appDataEvent.wellbeing.changeByUserAction = false;
}
var unsavedChangesExist = function () {

    if (appDataEvent.facesheet.initialLoad &&
        appDataEvent.safety.initialLoad &&
        appDataEvent.permanency.initialLoad &&
        appDataEvent.wellbeing.initialLoad) {

        return false;
    }

    if ((appDataEvent.facesheet.dataChanged && appDataEvent.facesheet.changeByUserAction) ||
        (appDataEvent.safety.dataChanged && appDataEvent.safety.changeByUserAction) ||
        (appDataEvent.permanency.dataChanged && appDataEvent.permanency.changeByUserAction) ||
        (appDataEvent.wellbeing.dataChanged && appDataEvent.wellbeing.changeByUserAction)) {

        return true;
    }

    return false;
}
var updateDatabase = function (controller, userId) {

    try {

        //if (appErrors.length > 0) {

        //    return;
        //}

        changeDataState(Ext.StoreMgr.get('CaseReviewStore'));

        // Update item 12 rating
        itemRatings.updateItem12Rating();

        // Update ratings before saving
        updateAllRatings();

        // Update status before saving
        updateAllStatuses();

        // Update all outcome statuses before saving
        updateAllOutcomeRatings();

        // End of status update

        //CaseReviewStatusCalculation.analyseAndChangeCRStatus(Ext.StoreMgr.get('CaseReviewStore'));

        if (Ext.StoreMgr.get('CR_Reviewer_CollectionStore').count() > 0) {
            changeReviewId(Ext.StoreMgr.get('CR_Reviewer_CollectionStore'));
        }

        var persistentData = getAllPersistentData();

        window.Data.SaveData(
            {
                caseReviewTop: persistentData,
                userID: userId
            },
            controller.saveCallback
        );

    } catch (ex) {

        appErrors.push(ex);

        Rollbar.error("Application Error", ex);
    }
};
var updateCaseReviewModel = function (result) {

    //var viewModel = getAppController().viewModel;
    var caseReviewData = result.data.CaseReview[0];
    //var fieldName;
    var reviewStartDate = caseReviewData['ReviewStartDate'];
    var reviewEndDate = caseReviewData['ReviewCompleted'];

    //for (var caseProp in caseReviewData) {

    //    if (!Ext.isArray(caseReviewData[caseProp])) {

    //        fieldName = 'CaseReview' + '.' + caseProp;

    //        viewModel.setValue(fieldName, caseReviewData[caseProp]);
    //    }
    //}

    var viewModel = getApplicationViewModel();

    viewModel.set('reviewStartDate', reviewStartDate);
    viewModel.set('reviewCompletedDate', reviewEndDate);

    updateStores(result);
};
var updateStores = function (result) {

    if (Ext.isEmpty(result)) {

        return;
    }

    var resultOutcomeColl = result.data.CaseReview[0].CR_Outcome_Collection;

    var outcomeColl = Ext.data.StoreManager.get('CaseReviewStore').getAt(0).data.CR_Outcome_Collection;
    var caseReviewstore = chainedStore('CaseReviewStore');

    if (!Ext.isEmpty(resultOutcomeColl)) {

        caseReviewstore.getAt(0).data.CR_Outcome_Collection = resultOutcomeColl;
    }
};
var updateViewModel = function (result, controller) {

    if (Ext.isEmpty(result)) {

        return;
    }

    var storeId = 'App.CaseReview.store.CaseReviewTop';

    var oldStore = Ext.data.StoreManager.lookup(storeId);

    if (Ext.isEmpty(oldStore)) {

        return;
    }

    var store = new Ext.data.Store({
        model: oldStore.model,
        associations: oldStore.model.associations
    });

    store.loadRawData(result.data);

    if (store.data.length > 0) {

        framework.Store.updateStores(store, storeId);
        //
        // Update viewModel
        //
        controller.viewModel.bind(store, null);

        //
        // Update ids related to QA Notes and Responses
        //
        controller.updateNoteBindings();
    }
};
var getCodeDescriptionGroup = function (groupName) {

    var retval;

    switch (groupName) {

        case 'CaseReason':

            retval = [
                {
                    'CodeDescriptionID': 1,
                    'GroupName': 'CaseReason',
                    'GroupID': 1,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Physical abuse',
                    'DescriptionLarge': 'Physical abuse',
                    'FedID': 6
                },
                {
                    'CodeDescriptionID': 2,
                    'GroupName': 'CaseReason',
                    'GroupID': 2,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Sexual abuse',
                    'DescriptionLarge': 'Sexual abuse',
                    'FedID': 7
                },
                {
                    'CodeDescriptionID': 3,
                    'GroupName': 'CaseReason',
                    'GroupID': 3,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Emotional maltreatment',
                    'DescriptionLarge': 'Emotional maltreatment',
                    'FedID': 8
                },
                {
                    'CodeDescriptionID': 4,
                    'GroupName': 'CaseReason',
                    'GroupID': 4,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Neglect (not including medical neglect)',
                    'DescriptionLarge': 'Neglect (not including medical neglect)',
                    'FedID': 9
                },
                {
                    'CodeDescriptionID': 5,
                    'GroupName': 'CaseReason',
                    'GroupID': 5,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Medical neglect',
                    'DescriptionLarge': 'Medical neglect',
                    'FedID': 10
                },
                {
                    'CodeDescriptionID': 6,
                    'GroupName': 'CaseReason',
                    'GroupID': 6,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Abandonment',
                    'DescriptionLarge': 'Abandonment',
                    'FedID': 11
                },
                {
                    'CodeDescriptionID': 7,
                    'GroupName': 'CaseReason',
                    'GroupID': 7,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Mental/physical health of parent',
                    'DescriptionLarge': 'Mental/physical health of parent',
                    'FedID': 12
                },
                {
                    'CodeDescriptionID': 8,
                    'GroupName': 'CaseReason',
                    'GroupID': 8,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Mental/physical health of child',
                    'DescriptionLarge': 'Mental/physical health of child',
                    'FedID': 13
                },
                {
                    'CodeDescriptionID': 9,
                    'GroupName': 'CaseReason',
                    'GroupID': 9,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Substance abuse by parent(s)',
                    'DescriptionLarge': 'Substance abuse by parent(s)',
                    'FedID': 14
                },
                {
                    'CodeDescriptionID': 10,
                    'GroupName': 'CaseReason',
                    'GroupID': 10,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Child\'s behavior',
                    'DescriptionLarge': 'Child\'s behavior',
                    'FedID': 15
                },
                {
                    'CodeDescriptionID': 11,
                    'GroupName': 'CaseReason',
                    'GroupID': 11,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Substance abuse by child',
                    'DescriptionLarge': 'Substance abuse by child',
                    'FedID': 16
                },
                {
                    'CodeDescriptionID': 12,
                    'GroupName': 'CaseReason',
                    'GroupID': 12,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Domestic violence in child\'s home',
                    'DescriptionLarge': 'Domestic violence in child\'s home',
                    'FedID': 17
                },
                {
                    'CodeDescriptionID': 13,
                    'GroupName': 'CaseReason',
                    'GroupID': 13,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Child in juvenile justice system',
                    'DescriptionLarge': 'Child in juvenile justice system',
                    'FedID': 18
                },
                {
                    'CodeDescriptionID': 14,
                    'GroupName': 'CaseReason',
                    'GroupID': 14,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Other (specify)',
                    'DescriptionLarge': 'Other (specify)',
                    'FedID': 19
                }
            ];

            break;

        case 'SafetyRelatedIncidents':

            retval = [
                {
                    'CodeDescriptionID': 86,
                    'GroupName': 'SafetyRelatedIncidents',
                    'GroupID': 1,
                    'DescriptionSmall': 'D1-1',
                    'DescriptionMedium': 'isSafetyIncidentNa',
                    'DescriptionLarge': 'NA (no safety issues were present during the period under review).',
                    'FedID': 'D1-6'
                },
                {
                    'CodeDescriptionID': 87,
                    'GroupName': 'SafetyRelatedIncidents',
                    'GroupID': 2,
                    'DescriptionSmall': 'D1-2',
                    'DescriptionMedium': 'isNoSafetyIncident',
                    'DescriptionLarge': 'No safety-related incidents occurred that were not adequately addressed by the agency.',
                    'FedID': 'D1-5'
                },
                {
                    'CodeDescriptionID': 88,
                    'GroupName': 'SafetyRelatedIncidents',
                    'GroupID': 3,
                    'DescriptionSmall': 'D1-3',
                    'DescriptionMedium': 'isRecurringMaltreatmentSafety',
                    'DescriptionLarge': 'Recurring maltreatment: There was at least one substantiated or indicated maltreatment report on any child in the family during the period under review AND there was another substantiated report within a 6-month period before or after that report that involved the same or similar circumstances. In determining the similarity of the circumstances, consider the perpetrator of the maltreatment and other individuals involved in the incident.',
                    'FedID': 'D1-1'
                },
                {
                    'CodeDescriptionID': 89,
                    'GroupName': 'SafetyRelatedIncidents',
                    'GroupID': 4,
                    'DescriptionSmall': 'D1-4',
                    'DescriptionMedium': 'isRecuringSafetyConcern',
                    'DescriptionLarge': 'Recurring safety concerns: There was at least one maltreatment report involving any child in the family during the period under review that was handled by an alternative response and resulted in opening the case for services to address safety concerns (this decision may have been made by the agency or by a private provider under contract with the agency) AND there was at least one additional maltreatment report within a 6-month period before or after that report that was handled by an alternative response and resulted in a decision to open the case for services to address the same or similar safety concerns (the case may have been opened for services by the agency or by a private provider under contract with the agency). In determining the similarity of the concerns, consider the perpetrator of the maltreatment, other individuals involved in the incident, and the type of safety issues that existed.',
                    'FedID': 'D1-2'
                },
                {
                    'CodeDescriptionID': 90,
                    'GroupName': 'SafetyRelatedIncidents',
                    'GroupID': 5,
                    'DescriptionSmall': 'D1-5',
                    'DescriptionMedium': 'isCaseClosedWhileSafetyConcern',
                    'DescriptionLarge': 'The case was closed while significant safety concerns that were not adequately addressed still existed in the home.',
                    'FedID': 'D1-3'
                },
                {
                    'CodeDescriptionID': 91,
                    'GroupName': 'SafetyRelatedIncidents',
                    'GroupID': 6,
                    'DescriptionSmall': 'D1-6',
                    'DescriptionMedium': 'isOtherSafetyConcern',
                    'DescriptionLarge': 'Other (describe any other safety-related incidents that were not adequately addressed by the agency):',
                    'FedID': 'D1-4'
                }
            ];

            break;

        case 'FosterSafety':

            retval = [
                {
                    'CodeDescriptionID': 92,
                    'GroupName': 'FosterSafety',
                    'GroupID': 1,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'isFosterSafetyConcernNA',
                    'DescriptionLarge': 'NA (this is an in-home services case, or the target child did not have any visitation).',
                    'FedID': 'E1-1'
                },
                {
                    'CodeDescriptionID': 93,
                    'GroupName': 'FosterSafety',
                    'GroupID': 2,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'isFosterSafetyConcernNo',
                    'DescriptionLarge': 'No unmitigated safety concerns related to visitation were present.',
                    'FedID': 'E1-6'
                },
                {
                    'CodeDescriptionID': 94,
                    'GroupName': 'FosterSafety',
                    'GroupID': 3,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'isFosterSafetyConcernNotSufficient',
                    'DescriptionLarge': 'Sufficient monitoring of visitation by parents/caretakers or other family members was not ensured.',
                    'FedID': 'E1-2'
                },
                {
                    'CodeDescriptionID': 95,
                    'GroupName': 'FosterSafety',
                    'GroupID': 4,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'isFosterSafetyConcernUnsupervisedVisitation',
                    'DescriptionLarge': 'Unsupervised visitation was allowed when it was not appropriate.',
                    'FedID': 'E1-3'
                },
                {
                    'CodeDescriptionID': 96,
                    'GroupName': 'FosterSafety',
                    'GroupID': 5,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'isFosterVisitationCourtOrdered',
                    'DescriptionLarge': 'Visitation was court-ordered despite safety concerns that could not be controlled with supervision.',
                    'FedID': 'E1-4'
                },
                {
                    'CodeDescriptionID': 97,
                    'GroupName': 'FosterSafety',
                    'GroupID': 6,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'isFosterSafetyOther',
                    'DescriptionLarge': 'Other (describe the safety concerns that existed with visitation):',
                    'FedID': 'E1-5'
                }
            ];

            break;

        case 'FosterPlacementConcern':

            retval = [
                {
                    'CodeDescriptionID': 98,
                    'GroupName': 'FosterPlacementConcern',
                    'GroupID': 1,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'isFosterPlacementConcernNA',
                    'DescriptionLarge': 'NA (this is an in-home services case).',
                    'FedID': 'F1-1'
                },
                {
                    'CodeDescriptionID': 99,
                    'GroupName': 'FosterPlacementConcern',
                    'GroupID': 2,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'isFosterPlacementConcernNo',
                    'DescriptionLarge': 'No safety concerns existed for the target child while in foster care placement that were not adequately addressed.',
                    'FedID': 'F1-7'
                },
                {
                    'CodeDescriptionID': 100,
                    'GroupName': 'FosterPlacementConcern',
                    'GroupID': 3,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'isFosterPlacementConcernAllegation',
                    'DescriptionLarge': 'There was a substantiated allegation of maltreatment of the child by a foster parent (including a relative foster parent) or facility staff member that could have been prevented if the agency had taken appropriate actions.',
                    'FedID': 'F1-2'
                },
                {
                    'CodeDescriptionID': 101,
                    'GroupName': 'FosterPlacementConcern',
                    'GroupID': 4,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'isFosterPlacementConcernCriticalIncident',
                    'DescriptionLarge': 'There was a critical incident report or other major issue relevant to noncompliance by foster parents or facility staff that could potentially make the child unsafe, and the agency could have prevented it or did not provide an adequate response after it occurred.',
                    'FedID': 'F1-3'
                },
                {
                    'CodeDescriptionID': 102,
                    'GroupName': 'FosterPlacementConcern',
                    'GroupID': 5,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'isFosterPlacementConcernOtherPlacementRisk',
                    'DescriptionLarge': 'The child’s placement during the period under review presented other risks to the child that are not being addressed, even though no allegation was made and no critical incident reports were filed.',
                    'FedID': 'F1-4'
                },
                {
                    'CodeDescriptionID': 103,
                    'GroupName': 'FosterPlacementConcern',
                    'GroupID': 6,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'isFosterPlacementConcernInadequateMonitoring',
                    'DescriptionLarge': 'You discover that there are safety concerns related to the child in the foster home of which the agency is unaware because of inadequate monitoring.',
                    'FedID': 'F1-5'
                },
                {
                    'CodeDescriptionID': 104,
                    'GroupName': 'FosterPlacementConcern',
                    'GroupID': 7,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'isFosterPlacementConcernOther',
                    'DescriptionLarge': 'Other (describe any other safety concerns that existed with the child’s foster placement):',
                    'FedID': 'F1-6'
                }
            ];

            break;

        case 'TerminationExceptions':

            retval = [
                {
                    'CodeDescriptionID': 138,
                    'GroupName': 'TerminationExceptions',
                    'GroupID': 1,
                    'DescriptionSmall': 'NA',
                    'DescriptionMedium': 'NA',
                    'DescriptionLarge': 'NA',
                    'FedID': 'G1-1'
                },
                {
                    'CodeDescriptionID': 139,
                    'GroupName': 'TerminationExceptions',
                    'GroupID': 2,
                    'DescriptionSmall': 'No',
                    'DescriptionMedium': 'No Exceptions',
                    'DescriptionLarge': 'No exceptions apply.',
                    'FedID': 'G1-2'
                },
                {
                    'CodeDescriptionID': 140,
                    'GroupName': 'TerminationExceptions',
                    'GroupID': 3,
                    'DescriptionSmall': 'Relative',
                    'DescriptionMedium': 'Relative',
                    'DescriptionLarge': '(1) At the option of the state, the child is being cared for by a relative at the 15/22-month time frame.',
                    'FedID': 'G1-3'
                },
                {
                    'CodeDescriptionID': 141,
                    'GroupName': 'TerminationExceptions',
                    'GroupID': 4,
                    'DescriptionSmall': 'Agency',
                    'DescriptionMedium': 'Agency Termination not in best Interest',
                    'DescriptionLarge': '(2) The agency documented in the case plan a compelling reason for determining that termination of parental rights would not be in the best interests of the child.',
                    'FedID': 'G1-4'
                },
                {
                    'CodeDescriptionID': 142,
                    'GroupName': 'TerminationExceptions',
                    'GroupID': 5,
                    'DescriptionSmall': 'State',
                    'DescriptionMedium': 'State has Not proided services deemed necessary',
                    'DescriptionLarge': '(3) The state has not provided to the family the services that the state deemed necessary for the safe return of the child to the child’s home.',
                    'FedID': 'G1-5'
                }
            ];

            break;

        case 'PlacementApplicableCircumstances':

            retval = [
                {
                    'CodeDescriptionID': 121,
                    'GroupName': 'PlacementApplicableCircumstances',
                    'GroupID': 1,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'None apply, placement is stable.',
                    'DescriptionLarge': '',
                    'FedID': 'C1-6'
                },
                {
                    'CodeDescriptionID': 122,
                    'GroupName': 'PlacementApplicableCircumstances',
                    'GroupID': 2,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'The child’s current placement is in a temporary shelter or other temporary setting.',
                    'DescriptionLarge': '',
                    'FedID': 'C1-1'
                },
                {
                    'CodeDescriptionID': 123,
                    'GroupName': 'PlacementApplicableCircumstances',
                    'GroupID': 3,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'There is information indicating that the child’s current substitute care provider may not be able to continue to care for the child.',
                    'DescriptionLarge': '',
                    'FedID': 'C1-2'
                },
                {
                    'CodeDescriptionID': 124,
                    'GroupName': 'PlacementApplicableCircumstances',
                    'GroupID': 4,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'There are problems in the current placement threatening its stability that the agency is not addressing.',
                    'DescriptionLarge': '',
                    'FedID': 'C1-3'
                },
                {
                    'CodeDescriptionID': 125,
                    'GroupName': 'PlacementApplicableCircumstances',
                    'GroupID': 5,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'The child has run away from this placement more than once in the past, or is in runaway status at the time of the review.',
                    'DescriptionLarge': '',
                    'FedID': 'C1-4'
                },
                {
                    'CodeDescriptionID': 126,
                    'GroupName': 'PlacementApplicableCircumstances',
                    'GroupID': 6,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Other (describe reasons why the current placement is not stable):',
                    'DescriptionLarge': '',
                    'FedID': 'C1-5'
                }
            ];

            break;

        case 'PermanencyGoal1':

            retval = [
                {
                    'CodeDescriptionID': 127,
                    'GroupName': 'PermanencyGoal1',
                    'GroupID': 1,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Reunification',
                    'DescriptionLarge': 'Reunification',
                    'FedID': 42
                },
                {
                    'CodeDescriptionID': 128,
                    'GroupName': 'PermanencyGoal1',
                    'GroupID': 2,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Guardianship',
                    'DescriptionLarge': 'Guardianship',
                    'FedID': 43
                },
                {
                    'CodeDescriptionID': 129,
                    'GroupName': 'PermanencyGoal1',
                    'GroupID': 3,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Adoption',
                    'DescriptionLarge': 'Adoption',
                    'FedID': 44
                },
                {
                    'CodeDescriptionID': 130,
                    'GroupName': 'PermanencyGoal1',
                    'GroupID': 4,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Other Planned Permanent Living Arrangement',
                    'DescriptionLarge': 'Other Planned Permanent Living Arrangement',
                    'FedID': 45
                }
            ];

            break;

        case 'PermanencyGoal2':

            retval = [
                {
                    'CodeDescriptionID': 131,
                    'GroupName': 'PermanencyGoal2',
                    'GroupID': 1,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Reunification',
                    'DescriptionLarge': 'Reunification',
                    'FedID': 42
                },
                {
                    'CodeDescriptionID': 132,
                    'GroupName': 'PermanencyGoal2',
                    'GroupID': 2,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Guardianship',
                    'DescriptionLarge': 'Guardianship',
                    'FedID': 43
                },
                {
                    'CodeDescriptionID': 133,
                    'GroupName': 'PermanencyGoal2',
                    'GroupID': 3,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Adoption',
                    'DescriptionLarge': 'Adoption',
                    'FedID': 44
                },
                {
                    'CodeDescriptionID': 134,
                    'GroupName': 'PermanencyGoal2',
                    'GroupID': 4,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'Other Planned Permanent Living Arrangement',
                    'DescriptionLarge': 'Other Planned Permanent Living Arrangement',
                    'FedID': 45
                },
                {
                    'CodeDescriptionID': 135,
                    'GroupName': 'PermanencyGoal2',
                    'GroupID': 5,
                    'DescriptionSmall': '',
                    'DescriptionMedium': 'NA',
                    'DescriptionLarge': '',
                    'FedID': 2
                }
            ];

            break;

        case 'FosterFederalCaseManagamentCriteria':

            retval = [
                {
                    'CodeDescriptionID': 178,
                    'GroupName': 'FosterFederalCaseManagamentCriteria',
                    'GroupID': 1,
                    'DescriptionSmall': 'NA',
                    'DescriptionMedium': 'NA',
                    'DescriptionLarge': 'NA (this is an in-home services case).',
                    'FedID': 'A4-1'
                },
                {
                    'CodeDescriptionID': 179,
                    'GroupName': 'FosterFederalCaseManagamentCriteria',
                    'GroupID': 2,
                    'DescriptionSmall': 'NEF',
                    'DescriptionMedium': '',
                    'DescriptionLarge': 'No evidence found.',
                    'FedID': 'A4-2'
                },
                {
                    'CodeDescriptionID': 180,
                    'GroupName': 'FosterFederalCaseManagamentCriteria',
                    'GroupID': 3,
                    'DescriptionSmall': 'HUTD',
                    'DescriptionMedium': 'Health Records Up To Date',
                    'DescriptionLarge': 'To the extent available and accessible, the child’s health records are up to date and included in the case file [Social Security Act § 475(1)(C)].',
                    'FedID': 'A4-3'
                },
                {
                    'CodeDescriptionID': 181,
                    'GroupName': 'FosterFederalCaseManagamentCriteria',
                    'GroupID': 4,
                    'DescriptionSmall': 'CPAHD',
                    'DescriptionMedium': 'Health Plan addresses Health and Dental Needs',
                    'DescriptionLarge': 'The case plan addresses the issue of health and dental care needs [Social Security Act § 475(1)(C)].',
                    'FedID': 'A4-4'
                },
                {
                    'CodeDescriptionID': 182,
                    'GroupName': 'FosterFederalCaseManagamentCriteria',
                    'GroupID': 5,
                    'DescriptionSmall': 'FPPHR',
                    'DescriptionMedium': 'Foster Parents Provided Health Records',
                    'DescriptionLarge': 'To the extent available and accessible, foster parents or foster care providers are provided with the child’s health records [Social Security Act § 475(5)(D)].',
                    'FedID': 'A4-5'
                }
            ];

            break;

        case 'EffortsToSupportMotherFosterRelationship':

            retval = [
                {
                    'CodeDescriptionID': 164,
                    'GroupName': 'EffortsToSupportMotherFosterRelationship',
                    'GroupID': 1,
                    'DescriptionSmall': 'NA',
                    'DescriptionMedium': '',
                    'DescriptionLarge': 'NA',
                    'FedID': 'A1-1'
                },
                {
                    'CodeDescriptionID': 165,
                    'GroupName': 'EffortsToSupportMotherFosterRelationship',
                    'GroupID': 2,
                    'DescriptionSmall': '',
                    'DescriptionMedium': '',
                    'DescriptionLarge': 'Encouraged the mother’s participation in school activities and case conferences, attendance at doctors’ appointments with the child, or engagement in the child’s after-school or sports activities?',
                    'FedID': 'A1-2'
                },
                {
                    'CodeDescriptionID': 166,
                    'GroupName': 'EffortsToSupportMotherFosterRelationship',
                    'GroupID': 3,
                    'DescriptionSmall': '',
                    'DescriptionMedium': '',
                    'DescriptionLarge': 'Provided or arranged for transportation or provided funds for transportation so that the mother could attend the child’s special activities and doctors’ appointments?',
                    'FedID': 'A1-3'
                },
                {
                    'CodeDescriptionID': 167,
                    'GroupName': 'EffortsToSupportMotherFosterRelationship',
                    'GroupID': 4,
                    'DescriptionSmall': '',
                    'DescriptionMedium': '',
                    'DescriptionLarge': 'Provided opportunities for therapeutic situations to help the mother and child strengthen their relationship?',
                    'FedID': 'A1-4'
                },
                {
                    'CodeDescriptionID': 168,
                    'GroupName': 'EffortsToSupportMotherFosterRelationship',
                    'GroupID': 5,
                    'DescriptionSmall': '',
                    'DescriptionMedium': '',
                    'DescriptionLarge': 'Encouraged the foster parents to provide mentoring or serve as role models to the mother to assist her in appropriate parenting?',
                    'FedID': 'A1-5'
                },
                {
                    'CodeDescriptionID': 169,
                    'GroupName': 'EffortsToSupportMotherFosterRelationship',
                    'GroupID': 6,
                    'DescriptionSmall': '',
                    'DescriptionMedium': '',
                    'DescriptionLarge': 'Encouraged and facilitated contact with a mother not living in close proximity to the child?',
                    'FedID': 'A1-6'
                },
                {
                    'CodeDescriptionID': 170,
                    'GroupName': 'EffortsToSupportMotherFosterRelationship',
                    'GroupID': 7,
                    'DescriptionSmall': 'O',
                    'DescriptionMedium': 'Other',
                    'DescriptionLarge': 'Other (describe other concerted efforts made) ',
                    'FedID': 'A1-7'
                }
            ];

            break;

        case 'EffortsToSupportFatherFosterRelationship':

            retval = [
                {
                    'CodeDescriptionID': 171,
                    'GroupName': 'EffortsToSupportFatherFosterRelationship',
                    'GroupID': 1,
                    'DescriptionSmall': 'NA',
                    'DescriptionMedium': '',
                    'DescriptionLarge': 'NA',
                    'FedID': 'B1-1'
                },
                {
                    'CodeDescriptionID': 172,
                    'GroupName': 'EffortsToSupportFatherFosterRelationship',
                    'GroupID': 2,
                    'DescriptionSmall': '',
                    'DescriptionMedium': '',
                    'DescriptionLarge': 'Encouraged the father’s participation in school activities and case conferences, attendance at doctors’ appointments with the child, or engagement in the child’s after-school or sports activities?',
                    'FedID': 'B1-2'
                },
                {
                    'CodeDescriptionID': 173,
                    'GroupName': 'EffortsToSupportFatherFosterRelationship',
                    'GroupID': 3,
                    'DescriptionSmall': '',
                    'DescriptionMedium': '',
                    'DescriptionLarge': 'Provided or arranged for transportation or provided funds for transportation so that the mother could attend the child’s special activities and doctors’ appointments?',
                    'FedID': 'B1-3'
                },
                {
                    'CodeDescriptionID': 174,
                    'GroupName': 'EffortsToSupportFatherFosterRelationship',
                    'GroupID': 4,
                    'DescriptionSmall': '',
                    'DescriptionMedium': '',
                    'DescriptionLarge': 'Provided opportunities for therapeutic situations to help the father and child strengthen their relationship?',
                    'FedID': 'B1-4'
                },
                {
                    'CodeDescriptionID': 175,
                    'GroupName': 'EffortsToSupportFatherFosterRelationship',
                    'GroupID': 5,
                    'DescriptionSmall': '',
                    'DescriptionMedium': '',
                    'DescriptionLarge': 'Encouraged the foster parents to provide mentoring or serve as role models to the father to assist her in appropriate parenting?',
                    'FedID': 'B1-5'
                },
                {
                    'CodeDescriptionID': 176,
                    'GroupName': 'EffortsToSupportFatherFosterRelationship',
                    'GroupID': 6,
                    'DescriptionSmall': '',
                    'DescriptionMedium': '',
                    'DescriptionLarge': 'Encouraged and facilitated contact with a father not living in close proximity to the child?',
                    'FedID': 'B1-6'
                },
                {
                    'CodeDescriptionID': 177,
                    'GroupName': 'EffortsToSupportFatherFosterRelationship',
                    'GroupID': 7,
                    'DescriptionSmall': 'O',
                    'DescriptionMedium': 'Other',
                    'DescriptionLarge': 'Other (describe other concerted efforts made) ',
                    'FedID': 'B1-7'
                }
            ];

            break;

        default:

            break;
    }

    return retval;
}
var getFilteredVMMAStore = function (itemName) {

    var filteredStore;
    var maStore = Ext.data.StoreManager.get('CR_MultiAnswer_CollectionStore');

    if (Ext.isEmpty(maStore)) {

        return undefined;
    };

    switch (itemName) {

        case 'safety':

            filteredStore = Ext.data.ChainedStore.create({
                source: maStore,
                sorters: 'CodeDescriptionID',
                filters: [
                    function (item) {

                        return item.data.CodeDescriptionID > 50 & item.data.CodeDescriptionID < 57;
                    }
                ]
            })

            break;

        case 'permanency':

            filteredStore = Ext.data.ChainedStore.create({
                source: maStore,
                sorters: 'CodeDescriptionID',
                filters: [
                    function (item) {

                        return (item.data.CodeDescriptionID > 56 & item.data.CodeDescriptionID < 68) || item.data.CodeDescriptionID == 261;
                    }
                ]
            })

            break;

        case 'wellbeing':

            filteredStore = Ext.data.ChainedStore.create({
                source: maStore,
                sorters: 'CodeDescriptionID',
                filters: [
                    function (item) {

                        return (item.data.CodeDescriptionID > 67 & item.data.CodeDescriptionID < 84) ||
                               item.data.CodeDescriptionID == 292 || item.data.CodeDescriptionID == 293;
                    }
                ]
            })

            break;

        default:

            break;
    }

    return filteredStore;
}
var syncPermanencyFacesheetData = function () {

    var permanencyStore = Ext.data.StoreManager.get('CR_Permanency_CollectionStore');
    var facesheetStore = Ext.data.StoreManager.get('CR_FaceSheet_CollectionStore');

    var fosterEntryDate = facesheetStore.getAt(0).data.FosterEntryDate;

    if (Ext.isEmpty(permanencyStore.getAt(0).data.ChildMostRecentFosterEntryDate) ||
        Ext.isEmpty(permanencyStore.getAt(0).data.IsDischargeDateNA)) {

        permanencyStore.getAt(0).data.ChildMostRecentFosterEntryDate = fosterEntryDate;
        permanencyStore.getAt(0).data.DischargeDate = facesheetStore.getAt(0).data.EpisodeDischargeDate;
        permanencyStore.getAt(0).data.IsDischargeDateNA = facesheetStore.getAt(0).data.IsEpisodeNotYetDischarged;
    }
}
var createViewModel = function (pageName, containerName) {

    var result;
    var filteredStore;
    var store;
    var itemCollection = [];
    var parent;
    var container;

    var createCaseReviewViewModel = function () {

        result = getApplicationViewModel();

        filteredStore = Ext.data.StoreManager.get('CaseReviewStore');

        result.data.caseReviewStore = filteredStore;

        result = initViewModel(result, filteredStore);

        setApplicationViewModel(result);
    }

    var initViewModel = function (viewModel, store) {

        var modelData = {},
            modelProps = {},
            formulas = viewModel.getFormulas(),
            storeData = store.getAt(0).data,
            keyName, last2Chars,
            bindNames = Object.keys(formulas),
            propVal = null;

        if (containerName && containerName.length > 0) {

            modelData[containerName] = null;
        }

        Ext.each(bindNames, function (bindName) {

            if (!(bindName == '__proto__')) {

                keyName = bindName.charAt(0).toUpperCase() + bindName.slice(1);
                last2Chars = keyName.slice(-2);

                if (last2Chars == 'Id' || last2Chars == 'id') {

                    last2Chars = 'ID';
                }

                if (last2Chars == 'ID') {

                    keyName = keyName.substr(0, keyName.length - 2) + last2Chars;
                }

                if (pageName == 'caseReview') {

                    if (formulas.hasOwnProperty(bindName)) {

                        propVal = formulas[bindName].get();
                    } else {

                        propVal = storeData[keyName];
                    }
                } else {

                    propVal = storeData[keyName];
                }
                
                if (containerName && containerName.length > 0) {

                    modelProps[bindName] = propVal;
                } else {

                    modelData[bindName] = propVal;
                }
            }
        });

        if (containerName && containerName.length > 0) {

            modelData[containerName] = modelProps;
        }

        viewModel.setData(modelData);

        return viewModel;
    }

    switch (pageName) {

        case 'caseReview':
            
            createCaseReviewViewModel();

            break;

        case 'facesheet':

            container = getCRSComponent('facesheetCenterPanel');

            if (!Ext.isEmpty(container)) {

                result = container.getViewModel();

                filteredStore = Ext.data.StoreManager.get('CR_FaceSheet_CollectionStore');
                result.data.facesheetData = filteredStore;
                result.storeInfo.facesheetData = filteredStore;

                result = initViewModel(result, filteredStore);
            }

            break;

        case 'safety':

            container = getCRSComponent('safetyPanel');

            if (!Ext.isEmpty(container)) {

                result = container.getViewModel();

                //
                // Preapplicability
                //
                filteredStore = getFilteredVMMAStore(pageName);
                result.data.safetyPreAppAnswers = filteredStore;
                result.storeInfo.safetyPreAppAnswers = filteredStore;
                //
                // Get CR_Safety_Collection
                //
                store = Ext.data.StoreManager.get('CR_Safety_CollectionStore');
                result.data.safetyCollection = store;
                result.storeInfo.safetyCollection = store;

                result = initViewModel(result, store);
                //
                // Get Item Applicability
                //
                store = Ext.data.ChainedStore.create({
                    source: 'CR_Outcome_CollectionStore',
                    filters: [
                        function (outcome) {

                            return outcome.data.OutcomeCode == 1 || outcome.data.OutcomeCode == 2;
                        }
                    ]
                });

                result.data.itemApplicability = store;
                result.storeInfo.itemApplicability = store;
            }

            break;

        case 'permanency':

            container = getCRSComponent('permanencyPanel');

            if (!Ext.isEmpty(container)) {

                result = container.getViewModel();

                //
                // Preapplicability
                //
                filteredStore = getFilteredVMMAStore(pageName);
                result.data.permanencyPreAppAnswers = filteredStore;
                result.storeInfo.permanencyPreAppAnswers = filteredStore;
                //
                // Get CR_Permanency_Collection
                //
                syncPermanencyFacesheetData();

                store = Ext.data.StoreManager.get('CR_Permanency_CollectionStore');
                result.data.permanencyCollection = store;
                //result.data.goal1Store = chainedStore('PermanencyGoal1Store');
                //result.data.goal2Store = chainedStore('PermanencyGoal2Store');
                result.storeInfo.permanencyCollection = store;

                result = initViewModel(result, store);
                //
                // Get Item Applicability
                //
                store = Ext.data.ChainedStore.create({
                    source: 'CR_Outcome_CollectionStore',
                    filters: [
                        function (outcome) {

                            return outcome.data.OutcomeCode > 2 && outcome.data.OutcomeCode < 5;
                        }
                    ]
                });

                result.data.itemApplicability = store;
                result.storeInfo.itemApplicability = store;
            }

            break;

        case 'wellbeing':

            container = getCRSComponent('wellbeingPanel');

            if (!Ext.isEmpty(container)) {

                result = container.getViewModel();

                //
                // Preapplicability
                //
                filteredStore = getFilteredVMMAStore(pageName);
                result.data.wellbeingPreAppAnswers = filteredStore;
                result.storeInfo.wellbeingPreAppAnswers = filteredStore;
                //
                // Get CR_Wellbeing_Collection
                //
                store = Ext.data.StoreManager.get('CR_WellBeing_CollectionStore');
                result.data.wellbeingCollection = store;
                result.storeInfo.wellbeingCollection = store;

                result = initViewModel(result, store);
                //
                // Get Item Applicability
                //
                store = Ext.data.ChainedStore.create({
                    source: 'CR_Outcome_CollectionStore',
                    filters: [
                        function (outcome) {

                            return outcome.data.OutcomeCode > 4 && outcome.data.OutcomeCode < 8;
                        }
                    ]
                });

                result.data.itemApplicability = store;
                result.storeInfo.itemApplicability = store;
            }

            break;

        default:

            break;
    }

    return result;
}
var getLastRadioSelection = function (newValue, oldValue) {

    var result = {};

    if (Ext.isEmpty(newValue)) {

        return result;
    }

    if (Ext.isEmpty(oldValue)) {

        return result;
    }

    if (!Ext.isEmpty(newValue) && !Ext.isEmpty(oldValue)) {

        var oldKeys = getObjectKeys(oldValue);

        for (key in newValue) {

            var keyArr = oldKeys.filter(function (item) {

                return key == item;
            });

            if (keyArr.length == 0) {

                result[key] = newValue[key];
            }
        }
    }

    return result;
}
var getCheckedRadio = function (radioGroup) {

    var result;

    if (Ext.isEmpty(radioGroup)) {

        return result;
    }

    if (Ext.isEmpty(radioGroup.items)) {

        return result;
    }

    Ext.each(radioGroup.items.items, function (radio) {

        if (radio.checked) {

            if (Ext.isEmpty(result)) {

                result = {};
            }

            result[radio.inputId] = radio.inputValue;
        }
    });

    return result;
}
var processItem2PreApplicability = function (radio, newValue, oldValue) {

    if (Ext.isEmpty(radio)) {

        return;
    }

    if (Ext.isEmpty(newValue)) {

        return;
    }

    if (Ext.isEmpty(oldValue)) {

        return;
    }

    appDataEvent.safety.changeByUserAction = checkIfChangedByUser(oldValue);

    if (!appDataEvent.safety.changeByUserAction) {

        return;
    }

    if (pageLoadStatus['Safety'] == 'rendered') {

        var parms = {};
        parms['itemName'] = 'Item2';
        parms['pageName'] = 'Safety';
        parms['ratingId'] = 'safetyItem2Rating';
        parms['groupName'] = 'Applicability';
        parms['groupMembers'] = [51, 52, 53, 54, 55, 56];
        parms['dataChanged'] = true;
        parms['section'] = 'ValidateItem2';
        parms['validationMethod'] = 'ValidateItem2';
        parms['newValue'] = newValue;
        parms['oldValue'] = oldValue;
        parms['groupItemName'] = 'Item 2';

        processPreApplicabilityChange(radio, parms);
    }
}
var processPermanencyPreApplicability = function (radio, parms) {

    if (Ext.isEmpty(radio)) {

        return;
    }

    if (Ext.isEmpty(parms)) {

        return;
    }

    var oldKeys = getObjectKeys(parms.oldValue);

    if (oldKeys.length > 0) {

        appDataEvent.permanency.changeByUserAction = true;
    }

    if (pageLoadStatus['Permanency'] == 'rendered') {

        processPreApplicabilityChange(radio, parms);
    }
}
var processWellbeingPreApplicability = function (radio, parms) {

    if (Ext.isEmpty(radio)) {

        return;
    }

    if (Ext.isEmpty(parms)) {

        return;
    }

    var oldKeys = getObjectKeys(parms.oldValue);

    if (oldKeys.length > 0) {

        appDataEvent.wellbeing.changeByUserAction = true;
    }

    if (pageLoadStatus['Wellbeing'] == 'rendered') {

        processPreApplicabilityChange(radio, parms);
    }
}
var getItemParticipantCollection = function (parms) {

    var result;

    if (Ext.isEmpty(parms)) {

        return result;
    }

    var item = getItemFromGraph(parms.itemCode, parms.outcomeCode);

    if (Ext.isEmpty(item)) {

        return result;
    }

    var getItemPartCollection = function () {

        var retColl = [];
        var filteredPart = [];

        if (!Ext.isEmpty(item.CR_ItemParticipant_Collection)) {

            filteredPart = item.CR_ItemParticipant_Collection.filter(function (itemPart) {

                return itemPart.ParticipantID == parms.participantId &&
                       itemPart.CodeDescriptionID == parms.codeDescriptionId;
            });
        }

        if (filteredPart.length > 0) {

            retColl = filteredPart;
        }

        return retColl;
    };

    if (!Ext.isEmpty(item.CR_ItemParticipant_Collection)) {

        result = getItemPartCollection();

    } else {

        Ext.each(item.CR_ItemParticipant_Collection, function (itemPart) {

            if (itemPart.CodeDescriptionID == parms.codeDescriptionId) {

                itemPart.ParticipantID = parms.codeDescriptionId;
            }
        });

        result = getItemPartCollection();
    }

    return result;
}
var isParticipantSelected = function (participantId) {

    var result = false;

    if (Ext.isEmpty(participantId)) {

        return result;
    }

    var itemParticipantStore = chainedStore('CR_ItemParticipant_CollectionStore');
    var filteredStore = itemParticipantStore.data.items.filter(function (itemPart) {

        return itemPart.data.ParticipantID == participantId;
    });

    if (filteredStore.length > 0) {

        result = true;
    }

    return result;
}
var isItemParticipantSelected = function (parms) {

    var result = false;

    if (Ext.isEmpty(parms)) {

        return result;
    }

    var participantColl = getItemParticipantCollection(parms);
    
    if (!Ext.isEmpty(participantColl)) {

        if (participantColl.length > 0) {

            result = true;
        }
    }

    return result;
}
var getItemParticipantId = function (participantId) {

    var result = 0;

    if (Ext.isEmpty(participantId)) {

        return result;
    }

    var itemParticipantStore = chainedStore('CR_ItemParticipant_CollectionStore');

    var filteredStore = itemParticipantStore.data.items.filter(function (itemPart) {

        return itemPart.data.ParticipantID == participantId;
    });

    if (filteredStore.length > 0) {

        result = filteredStore[0].ItemParticipantID;
    }

    return result;
}
var updatePreApplicabilityAnswers = function (parms) {

    if (Ext.isEmpty(parms)) {

        return;
    }

    if (appDataEvent.safety.initialLoad && parms.pageName == 'safety') {

        return;
    }

    if (appDataEvent.permanency.initialLoad && parms.pageName == 'permanency') {

        return;
    }

    if (appDataEvent.wellbeing.initialLoad && parms.pageName == 'wellbeing') {

        return;
    }

    var multiAnswerStore = Ext.StoreManager.get('CR_MultiAnswer_CollectionStore');

    var items = multiAnswerStore.query('CodeDescriptionID', parms.codeDescriptionId);

    if (parms.value) {

        var oldValue = parms.oldValue;
        var newValue = parms.newValue;
        var selectedItem = getLastRadioSelection(newValue, oldValue);

        var newKeys = getObjectKeys(selectedItem);

        if (newKeys.length > 0) {

            if (items.length > 0) {

                items.items[0].data.AnswerCode = selectedItem[newKeys[0]];
                var viewModel;

                if (parms.pageName == 'safety') {

                    var filteredStore = getFilteredVMMAStore(parms.pageName);

                    viewModel = window.safetyViewModel;

                    viewModel.data.safetyPreAppAnswers = filteredStore;
                    viewModel.storeInfo.safetyPreAppAnswers = filteredStore;
                }

                if (parms.pageName == 'permanency') {

                    var filteredStore = getFilteredVMMAStore(parms.pageName);

                    viewModel = window.permanencyViewModel;

                    viewModel.data.permanencyPreAppAnswers = filteredStore;
                    viewModel.storeInfo.permanencyPreAppAnswers = filteredStore;
                }

                if (parms.pageName == 'wellbeing') {

                    var filteredStore = getFilteredVMMAStore(parms.pageName);

                    viewModel = window.wellbeingViewModel;

                    viewModel.data.wellbeingPreAppAnswers = filteredStore;
                    viewModel.storeInfo.wellbeingPreAppAnswers = filteredStore;
                }
            }
        }
    }
};
var deselectPrevChoices = function (component) {

    var radioList;

    if (Ext.isEmpty(component)) {

        return;
    }

    if ((component.isRadio) || (component.isCheckbox)) {

        radioList = component.ownerCt.query('radio, checkbox');
    }

    Ext.each(radioList, function (cmp) {

        if (cmp !== component) {

            cmp.setValue(false);
        }
    });
}
var getObjectKeys = function (obj) {

    var keys = [];

    if (Ext.isObject(obj)) {

        for (key in obj) {

            keys.push(key);
        }
    }

    return keys;
}
var initializeParticipantIds = function () {

    participants = {};

    //
    // Load Case Participants
    //
    var caseParticipants = chainedStore('CaseReviewStore').getAt(0).data.CR_FaceSheet_Collection[0].CR_CaseParticipant_Collection;
    var casePart;

    Ext.each(caseParticipants, function (participant) {

        casePart = {};

        casePart['Name'] = participant.Name;
        casePart['OldParticipantID'] = participant.CaseParticipantID;
        casePart['ParticipantID'] = participant.CaseParticipantID;

        participants[participant.Name] = casePart;
    });
    //
    // Load Children Participants
    //
    var childParticipants = chainedStore('CaseReviewStore').getAt(0).data.CR_FaceSheet_Collection[0].CR_ChildDemographic_Collection;

    Ext.each(childParticipants, function (participant) {

        casePart = {};

        casePart['Name'] = participant.Name;
        casePart['OldParticipantID'] = participant.ChildDemographicID;
        casePart['ParticipantID'] = participant.ChildDemographicID;

        participants[participant.Name] = casePart;
    });
}
var initializeItemParticipantIds = function () {


}
var updateParticipantIds = function (result) {

    if (Ext.isEmpty(result)) {

        return;
    }

    participants = {};

    var getNewCaseParticipantId = function (name) {

        var retval;
        var caseParts;

        var keys = Object.keys(result);
        var index = keys.indexOf('CR_FaceSheet_Collection');

        caseParts = index > -1 ? result.CR_FaceSheet_Collection[0].CR_CaseParticipant_Collection :
                    result.data.CaseReview[0].CR_FaceSheet_Collection[0].CR_CaseParticipant_Collection;

        Ext.each(caseParts, function (casePart) {

            if (casePart.Name == name) {

                retval = casePart.CaseParticipantID;

                return false;
            }
        });

        return retval;
    };

    var getNewChildParticipantId = function (name) {

        var retval;
        var childParts;

        var keys = Object.keys(result);
        var index = keys.indexOf('CR_FaceSheet_Collection');

        childParts = index > -1 ? result.CR_FaceSheet_Collection[0].CR_ChildDemographic_Collection :
                     result.data.CaseReview[0].CR_FaceSheet_Collection[0].CR_ChildDemographic_Collection;

        Ext.each(childParts, function (childPart) {

            if (childPart.Name == name) {

                retval = childPart.ChildDemographicID;

                return false;
            }
        });

        return retval;
    };
    //
    // Update Case Participants
    //
    var caseParticipants = chainedStore('CaseReviewStore').getAt(0).data.CR_FaceSheet_Collection[0].CR_CaseParticipant_Collection;
    var casePart;

    Ext.each(caseParticipants, function (participant) {

        casePart = {};

        casePart['Name'] = participant.Name;
        casePart['OldParticipantID'] = participant.CaseParticipantID;
        casePart['ParticipantID'] = getNewCaseParticipantId(participant.Name);

        participants[participant.Name] = casePart;
    });
    //
    // Update Children Participants
    //
    var childParticipants = chainedStore('CaseReviewStore').getAt(0).data.CR_FaceSheet_Collection[0].CR_ChildDemographic_Collection;

    Ext.each(childParticipants, function (participant) {

        casePart = {};

        casePart['Name'] = participant.Name;
        casePart['OldParticipantID'] = participant.ChildDemographicID;
        casePart['ParticipantID'] = getNewChildParticipantId(participant.Name);

        participants[participant.Name] = casePart;
    });
}
var updateModelProperties = function (result) {

    if (Ext.isEmpty(result)) {

        return;
    }

    var topStore = Ext.StoreManager.get('CaseReviewStore');
    var filteredProps;
    var filteredResult = result;
    var selectedKey;
    var outcomeCode;
    var itemCode;
    var childName;
    var childDateOfBirth;
    var partName;

    var caseReview = topStore.getAt(0).data;

    updateParticipantIds(result);

    var updateProperties = function (topLevelData) {

        filteredProps = getIDProperties(topLevelData);
        //
        // Update top-level properties
        //
        var parms = {
            'updatedData': result,
            'originalData': topLevelData,
            'outcomeCode': outcomeCode,
            'itemCode': itemCode,
            'selectedData': filteredResult,
            'selectedKey': Ext.isEmpty(selectedKey) ? 'CaseReview' : selectedKey,
            'childName': childName,
            'childDateOfBirth': childDateOfBirth,
            'participantName': partName
        };

        filteredResult = getUpdatedResultObject(parms);

        if (!Ext.isEmpty(filteredResult)) {

            Ext.each(filteredProps, function (prop) {

                topLevelData[prop] = filteredResult[prop];
            });
        }

        var keys = getArrayProperties(topLevelData);

        Ext.each(keys, function (key) {

            if (!(key == 'CR_Outcome_Collection')) {

                Ext.each(topLevelData[key], function (obj) {

                    selectedKey = key;

                    if (!(key == 'CR_ChildDemographic_Collection' || key == 'CR_ChildRace_Collection')) {

                        childName = undefined;
                        childDateOfBirth = undefined;
                    }

                    itemCode = Ext.isEmpty(obj.ItemCode) ? itemCode : obj.ItemCode;
                    outcomeCode = getOutcomeCode(itemCode);

                    if (key == 'CR_ChildDemographic_Collection') {

                        childName = obj.Name;
                        partName = obj.Name;

                        var dob = obj.DateOfBirth.valueOf();

                        childDateOfBirth = dob;
                    }

                    if (key == 'CR_CaseParticipant_Collection') {

                        partName = obj.Name;
                    }

                    updateProperties(obj);
                });
            }
        });
    };

    updateProperties(caseReview);

    initializeQuestionsAnswered();

    updateExtCollections();
}
var updateExtCollections = function () {

    var extCollections = ['CR_CaseNote_Collection',
                            'CR_CaseNote_Response_Collection',
                            'CR_MultiAnswer_Collection',
                            'CR_Outcome_Collection',
                            'CR_Item_Collection',
                            'CR_Note_Collection',
                            'CR_Response_Collection',
                            'CR_ItemParticipant_Collection',
                            'CR_Reviewer_Collection',
                            'CR_CaseParticipant_Collection',
                            'CR_ChildDemographic_Collection',
                            'CR_SafetyReport_Collection',
                            'CR_SafetyReport_Allegation_Collection',
                            'CR_Health_Collection',
                            'CR_Goal_Collection',
                            'CR_Education_Collection',
                            'CR_ChildRace_Collection',
                            'CR_Placement_Collection'];

    var extStoreColl, graphColl, filteredProps, parms, updatedObj;

    Ext.each(extCollections, function (storeName) {

        extStoreColl = Ext.data.StoreManager.get(storeName + 'Store');
        graphColl = getGraphCollection(storeName);

        if (!Ext.isEmpty(graphColl) && !Ext.isEmpty(extStoreColl)) {

            if (!Ext.isEmpty(extStoreColl.data)) {

                if (extStoreColl.data.length > 0) {

                    Ext.each(extStoreColl, function (extObj) {

                        filteredProps = getIDProperties(extObj.data);

                        parms = {};

                        parms['selectedKey'] = storeName;
                        parms['updatedData'] = graphColl;
                        parms['originalData'] = extObj.data;

                        Ext.each(filteredProps, function (prop) {

                            updatedObj = findUpdatedObject(parms);

                            extObj.data[prop] = updatedObj[prop];
                        });
                    });
                }
            }
        }
    });
}
var getMatchingProps = function (key) {

    if (Ext.isEmpty(key)) {

        return undefined;
    }

    var matchingProps = {
        'CR_CaseNote_Collection': ['Description', 'Subject'],
        'CR_CaseNote_Response_Collection': ['Description'],
        'CR_MultiAnswer_Collection': ['CodeDescriptionID'],
        'CR_Outcome_Collection': ['OutcomeCode'],
        'CR_Item_Collection': ['ItemCode'],
        'CR_Note_Collection': ['Description', 'Subject'],
        'CR_Response_Collection': ['Description'],
        'CR_ItemParticipant_Collection': ['CodeDescriptionID'],
        'CR_Reviewer_Collection': ['FullName'],
        'CR_CaseParticipant_Collection': ['Name', 'RoleCode'],
        'CR_ChildDemographic_Collection': ['Name', 'DateOfBirth'],
        'CR_SafetyReport_Collection': ['ReportDate', 'DispositionCode'],
        'CR_SafetyReport_Allegation_Collection': ['SafetyReportAllegationCode'],
        'CR_Health_Collection': ['HealthNeeds', 'HealthNeedCode'],
        'CR_Goal_Collection': ['GoalCode', 'DateEstablished'],
        'CR_Education_Collection': ['Needs', 'ServicesProvided'],
        'CR_ChildRace_Collection': ['RaceCode'],
        'CR_Placement_Collection': ['Date', 'TypeCode']
    };

    return matchingProps[key];
}
var findUpdatedObject = function (parms) {

    var matchCount = 0;
    var selectedData, matchFound;

    if (Ext.isEmpty(parms)) {

        return {};
    }

    var matchProps = getMatchingProps(parms.selectedKey);

    if (!Ext.isEmpty(matchProps)) {

        Ext.each(parms.updatedData, function (updatedObj) {

            matchCount = 0;

            Ext.each(matchProps, function (matchProp) {

                if (updatedObj[matchProp] == parms.originalData[matchProp]) {

                    matchCount++;
                }
            });

            if (matchCount == matchProps.length) {

                matchFound = true;

                selectedData = updatedObj;

                return false;
            }
        });

        if (matchFound) {

            return selectedData;
        }
    }

    return parms.updatedData[0];
}
var getGraphCollection = function (collectionName) {

    var reviewStore = Ext.data.StoreManager.get('CaseReviewStore');

    var getItemCollection = function () {

        var collection = reviewStore.getAt(0).data.CR_Outcome_Collection;
        var itemColl = [];

        Ext.each(collection, function (outcomeObj) {

            Ext.each(outcomeObj.CR_Item_Collection, function (itemObj) {

                itemColl.push(itemObj);
            });
        });

        return itemColl;
    }

    var getChildRaceCollection = function () {

        var collection = reviewStore.getAt(0).data.CR_FaceSheet_Collection[0].CR_ChildDemographic_Collection;
        var childRaceColl = [];

        Ext.each(collection, function (demographicObj) {

            Ext.each(demographicObj.CR_ChildRace_Collection, function (raceObj) {

                childRaceColl.push(raceObj);
            });
        });

        return childRaceColl;
    }

    var getItemParticipantCollection = function () {

        var collection = getItemCollection();
        var itemPartColl = [];

        Ext.each(collection, function (itemObj) {

            Ext.each(itemObj.CR_ItemParticipant_Collection, function (itemPartObj) {

                itemPartColl.push(itemPartObj);
            });
        });

        return itemPartColl;
    }

    var getItemNoteCollection = function () {

        var collection = getItemCollection();
        var itemNoteColl = [];

        Ext.each(collection, function (itemObj) {

            Ext.each(itemObj.CR_Note_Collection, function (itemNoteObj) {

                itemNoteColl.push(itemNoteObj);
            });
        });

        return itemNoteColl;
    }

    var getCaseNoteResponseCollection = function () {

        var collection = reviewStore.getAt(0).data['CR_CaseNote_Collection'];
        var caseNoteResponseColl = [];

        Ext.each(collection, function (noteObj) {

            Ext.each(noteObj.CR_CaseNote_Response_Collection, function (responseObj) {

                caseNoteResponseColl.push(responseObj);
            });
        });

        return caseNoteResponseColl;
    }

    var getItemNoteResponseCollection = function () {

        var collection = getItemNoteCollection();
        var itemNoteResponseColl = [];

        Ext.each(collection, function (noteObj) {

            Ext.each(noteObj.CR_Response_Collection, function (responseObj) {

                itemNoteResponseColl.push(responseObj);
            });
        });

        return itemNoteResponseColl;
    }

    var getSafetyReportAllegationCollection = function () {

        var collection = reviewStore.getAt(0).data.CR_Safety_Collection[0]['CR_SafetyReport_Collection'];
        var allegationColl = [];

        Ext.each(collection, function (reportObj) {

            Ext.each(reportObj.CR_SafetyReport_Allegation_Collection, function (allegationObj) {

                allegationColl.push(allegationObj);
            });
        });

        return allegationColl;
    }

    switch (collectionName) {

        case 'CR_CaseNote_Collection':
        case 'CR_FaceSheet_Collection':
        case 'CR_MultiAnswer_Collection':
        case 'CR_Outcome_Collection':
        case 'CR_Permanency_Collection':
        case 'CR_Reviewer_Collection':
        case 'CR_Safety_Collection':
        case 'CR_WellBeing_Collection':

            return reviewStore.getAt(0).data[collectionName];

        case 'CR_ChildRace_Collection':

            return getChildRaceCollection();

        case 'CR_Item_Collection':

            return getItemCollection();

        case 'CR_Note_Collection':

            return getItemNoteCollection();

        case 'CR_Response_Collection':

            return getItemNoteResponseCollection();

        case 'CR_CaseNote_Response_Collection':

            return getCaseNoteResponseCollection();

        case 'CR_ItemParticipant_Collection':

            return getItemParticipantCollection();

        case 'CR_CaseParticipant_Collection':
        case 'CR_ChildDemographic_Collection':

            return reviewStore.getAt(0).data.CR_FaceSheet_Collection[0][collectionName];

        case 'CR_Goal_Collection':
        case 'CR_Placement_Collection':

            return reviewStore.getAt(0).data.CR_Permanency_Collection[0][collectionName];

        case 'CR_SafetyReport_Collection':

            return reviewStore.getAt(0).data.CR_Safety_Collection[0][collectionName];

        case 'CR_SafetyReport_Allegation_Collection':

            return getSafetyReportAllegationCollection();

        case 'CR_Education_Collection':
        case 'CR_Health_Collection':

            return reviewStore.getAt(0).data.CR_WellBeing_Collection[0][collectionName];

        default:

            return undefined;
    }
};
var getCaseParticipant = function (parms) {

    if (Ext.isEmpty(parms)) {

        parms = { participantId: 0 };
    }

    var participants = chainedStore('CaseReviewStore').getAt(0).data.CR_FaceSheet_Collection[0].CR_CaseParticipant_Collection;

    var filteredPart = participants.filter(function (itemPart) {

        return itemPart.CaseParticipantID == parms.participantId;
    });

    return filteredPart.length == 0 ? filteredPart : filteredPart[0];
}
var updateModelIds = function () {
    //
    // Start with Outcome Collection and update all children
    //
    var outcomeColl = Ext.StoreManager.get('CaseReviewStore').getAt(0).data.CR_Outcome_Collection;

    //
    // Update Item IDs
    //
    var itemCode, outcomeCode, latestItemId;

    Ext.each(outcomeColl, function (outcome) {

        outcomeCode = outcome.OutcomeCode;

        Ext.each(outcome.CR_Item_Collection, function (item) {

            itemCode = item.ItemCode;

            latestItemId = getLatestItemId(itemCode, outcomeCode);

            if (!Ext.isEmpty(latestItemId)) {

                item.ItemID = latestItemId;
            }

            Ext.each(item.CR_Note_Collection, function (note) {

                note.ItemID = item.ItemID;

                var parms = {};

                parms['itemCode'] = itemCode;
                parms['outcomeCode'] = outcomeCode;
                parms['itemId'] = item.ItemID;
                parms['description'] = note.Description;
                parms['subject'] = note.Subject;

                var updatedNoteId = getLatestNoteId(parms);

                if (!(note.NoteID == updatedNoteId)) {

                    if (!Ext.isEmpty(updatedNoteId)) {

                        note.NoteID = updatedNoteId;
                    }
                }

                Ext.each(note.CR_Response_Collection, function (response) {

                    response.NoteID = note.NoteID;
                });
            });
        });
    });
}
var updateCurrentGoals = function () {

    var goalstore = Ext.data.StoreManager.lookup('CR_Goal_CollectionStore');
    var permanencyStore = Ext.data.StoreManager.lookup('CR_Permanency_CollectionStore');
    var currentGoals = [];

    if (Ext.isEmpty(goalstore)) {

        return;
    }

    if (Ext.isEmpty(permanencyStore)) {

        return;
    }

    if (goalstore.data.length > 0) {

        currentGoals = goalstore.data.items.filter(function (goal) {

            return goal.data.IsCurrentGoal == 1;
        });
    }
    //
    // This assumes sorting is not required.
    //
    if (currentGoals.length > 0) {

        permanencyStore.getAt(0).data.Goal1Code = currentGoals[0].data.GoalCode;
    }

    if (currentGoals.length > 1) {

        permanencyStore.getAt(0).data.Goal2Code = currentGoals[1].data.GoalCode;
    }
    // 
    // Update permanency viewModel
    //
    var vModel = createViewModel('permanency');

    window.permanencyViewModel = vModel;

    //updateQuestion6A4();
}
var updateQuestion6A4 = function () {

    var item6A4ComboBox = getAppController().getItem6A4CBGroup();
    var lookupStore = chainedStore('PermanencyGoal1Store');

    if (Ext.isEmpty(lookupStore)) {

        return;
    }

    var goals = Ext.data.StoreManager.lookup('CR_Goal_CollectionStore').data.items;
    var currentGoals = [];

    Ext.each(goals, function (goal) {

        if (goal.data.IsCurrentGoal == 1) {

            currentGoals.push(goal.data.GoalCode);
        }
    });

    var getResults = function (value) {

        return lookupStore.query('GroupID', value, false, false, true);
    };

    resetPermanencyGoals(currentGoals);

    Ext.each(currentGoals, function (goalCode) {

        var codeLookupResult = getResults(goalCode);

        Ext.each(item6A4ComboBox.items.items, function (item) {

            item.setValue(false);

            if (codeLookupResult.length > 0) {
                if (item.boxLabel == codeLookupResult.getAt(0).data.DescriptionLarge) {

                    item.setValue(true);
                }
            }
        });
    });
}
var resetPermanencyGoals = function (goals) {

    if (Ext.isEmpty(goals)) {

        return;
    }

    var multiAnswerCollection = Ext.StoreManager.get('CaseReviewStore').getAt(0).data.CR_MultiAnswer_Collection;
    var checkboxColl;
    var itemsToBeDeleted = [];

    var permanencyGoalCollection = multiAnswerCollection.filter(function (goalObj) {

        return goalObj.CodeDescriptionID == 127 ||
               goalObj.CodeDescriptionID == 128 ||
               goalObj.CodeDescriptionID == 129 ||
               goalObj.CodeDescriptionID == 130;
    });

    Ext.each(permanencyGoalCollection, function (permanencyGoal) {

        currentGoal = goals.filter(function (goal) {

            return (goal == 1 && permanencyGoal.CodeDescriptionID == 127) ||
                    (goal == 2 && permanencyGoal.CodeDescriptionID == 128) ||
                    (goal == 3 && permanencyGoal.CodeDescriptionID == 129) ||
                    (goal == 4 && permanencyGoal.CodeDescriptionID == 130);
        });

        if (currentGoal.length == 0) {

            itemsToBeDeleted.push(permanencyGoal);
        }
    });

    Ext.each(itemsToBeDeleted, function (itemToBeDeleted) {

        var index = multiAnswerCollection.indexOf(itemToBeDeleted);

        if (index > -1) {

            multiAnswerCollection.splice(index, 1);
        }
    });
}
var getIDProperties = function (obj) {

    var filteredProps = [];

    if (Ext.isEmpty(obj)) {

        return filteredProps;
    }

    var keys = Object.keys(obj);
    var last2;

    var filteredProps = keys.filter(function (key) {

        last2 = key.substring(key.length - 2);

        if (last2 == 'ID') {

            if (propertiesToUpdate.indexOf(key) > -1) {

                return key;
            }
        }
    });

    return filteredProps;
}
var getArrayProperties = function (obj) {

    var filteredProps = [];

    if (Ext.isEmpty(obj)) {

        return filteredProps;
    }

    var keys = Object.keys(obj);

    var filteredProps = keys.filter(function (key) {

        if (Ext.isArray(obj[key])) {

            return key;
        }
    });

    return filteredProps;
}
var findResultObject = function (parms) {

    if (Ext.isEmpty(parms)) {

        return parms;
    }

    var matchingProps = {
        'CR_CaseNote_Collection': ['Description', 'Subject'],
        'CR_CaseNote_Response_Collection': ['Description'],
        'CR_MultiAnswer_Collection': ['CodeDescriptionID'],
        'CR_Outcome_Collection': ['OutcomeCode'],
        'CR_Item_Collection': ['ItemCode'],
        'CR_Note_Collection': ['Description', 'Subject'],
        'CR_ItemParticipant_Collection': ['CodeDescriptionID'],
        'CR_Reviewer_Collection': ['FullName'],
        'CR_CaseParticipant_Collection': ['Name', 'RoleCode'],
        'CR_ChildDemographic_Collection': ['Name', 'DateOfBirth'],
        'CR_SafetyReport_Collection': ['ReportDate', 'DispositionCode'],
        'CR_SafetyReport_Allegation_Collection': ['SafetyReportAllegationCode'],
        'CR_Health_Collection': ['HealthNeeds', 'HealthNeedCode'],
        'CR_Goal_Collection': ['GoalCode', 'DateEstablished'],
        'CR_Education_Collection': ['Needs', 'ServicesProvided'],
        'CR_ChildRace_Collection': ['RaceCode'],
        'CR_Placement_Collection': ['Date', 'TypeCode']
    };

    var getItemNotesData = function () {

        var result;

        Ext.each(parms.updatedData.CR_Outcome_Collection, function (outcome) {

            if (outcome.OutcomeCode == parms.outcomeCode) {

                result = outcome.CR_Item_Collection;

                return false;
            }
        });

        return result;
    };

    var getCaseNotesData = function () {

        var result;

        result = parms.updatedData.CR_CaseNote_Collection;

        return result;
    };

    var findResultContainer = function () {

        var upperLevelContainer;

        switch (parms.selectedKey) {

            case 'CR_Note_Collection':

                Ext.each(getItemNotesData(), function (item) {

                    if (item.ItemCode == parms.itemCode) {

                        upperLevelContainer = item;

                        return false;
                    }
                });

                break;

            case 'CR_CaseNote_Collection':

                upperLevelContainer = getCaseNotesData();

                break;

            default:

                break;
        }

        return upperLevelContainer;
    };

    var result;
    var selectedData;
    var matchFound = false;
    var matchCount = 0;

    if (Ext.isEmpty(parms.selectedKey)) {

        return parms.updatedData;
    }

    if (parms.selectedKey == 'CR_Note_Collection') {

        var container = findResultContainer();

        if (Ext.isEmpty(container)) {

            return;
        }

        var matchProps = matchingProps[parms.selectedKey];

        if (!Ext.isEmpty(matchProps)) {

            Ext.each(container[parms.selectedKey], function (updatedObj) {

                matchCount = 0;

                Ext.each(matchProps, function (matchProp) {

                    if (updatedObj[matchProp] == parms.originalData[matchProp]) {

                        matchCount++;
                    }
                });

                if (matchCount == matchProps.length) {

                    matchFound = true;

                    selectedData = updatedObj;

                    return false;
                }
            });

            if (matchFound) {

                return selectedData;
            }
        }
    }

    if (parms.selectedKey == 'CR_CaseNote_Collection') {

        var container = findResultContainer();

        if (Ext.isEmpty(container)) {

            return;
        }

        var matchProps = matchingProps[parms.selectedKey];

        if (!Ext.isEmpty(matchProps)) {

            Ext.each(container, function (updatedObj) {

                matchCount = 0;

                Ext.each(matchProps, function (matchProp) {

                    if (updatedObj[matchProp] == parms.originalData[matchProp]) {

                        matchCount++;
                    }
                });

                if (matchCount == matchProps.length) {

                    matchFound = true;

                    selectedData = updatedObj;

                    return false;
                }
            });

            if (matchFound) {

                return selectedData;
            }
        }
    }

    if (!Ext.isEmpty(parms.updatedData[parms.selectedKey])) {

        if (parms.updatedData[parms.selectedKey].length == 1) {

            return parms.updatedData[parms.selectedKey][0];
        }

        var matchProps = matchingProps[parms.selectedKey];

        if (!Ext.isEmpty(matchProps)) {

            Ext.each(parms.updatedData[parms.selectedKey], function (updatedObj) {

                matchCount = 0;

                Ext.each(matchProps, function (matchProp) {

                    if (updatedObj[matchProp] == parms.originalData[matchProp]) {

                        matchCount++;
                    }
                });

                if (matchCount == matchProps.length) {

                    matchFound = true;

                    selectedData = updatedObj;

                    return false;
                }
            });

            if (matchFound) {

                return selectedData;
            }
        }
    }

    if (!Ext.isEmpty(parms.selectedData)) {

        if (!Ext.isEmpty(parms.selectedData[parms.selectedKey])) {

            if (parms.selectedData[parms.selectedKey].length == 1) {

                return parms.selectedData[parms.selectedKey][0];
            }

            var matchProps = matchingProps[parms.selectedKey];

            if (!Ext.isEmpty(matchProps)) {

                Ext.each(parms.selectedData[parms.selectedKey], function (updatedObj) {

                    matchCount = 0;

                    Ext.each(matchProps, function (matchProp) {

                        if (updatedObj[matchProp] == parms.originalData[matchProp]) {

                            matchCount++;
                        }
                    });

                    if (matchCount == matchProps.length) {

                        matchFound = true;

                        selectedData = updatedObj;

                        return false;
                    }
                });

                if (matchFound) {

                    return selectedData;
                }
            }
        }
    }

    return parms.originalData;
};
var getUpdatedResultObject = function (parms) {

    if (Ext.isEmpty(parms)) {

        return parms;
    }

    var collection, filteredColl;
    var result = parms.updatedData;

    var getUpdatedCaseReview = function () {

        if (Ext.isEmpty(result.data)) {

            return result;
        }

        var resultObj = result.data.CaseReview[0];

        return resultObj;
    }

    var getUpdatedFacesheet = function () {

        if (Ext.isEmpty(result.data)) {

            return result.CR_FaceSheet_Collection[0];
        }

        var resultObj = result.data.CaseReview[0].CR_FaceSheet_Collection[0];

        return resultObj;
    }

    var getUpdatedChildDemographicInfo = function () {

        var resultObj;

        if (Ext.isEmpty(result.data)) {

            collection = result.CR_FaceSheet_Collection[0].CR_ChildDemographic_Collection;
        } else {

            collection = result.data.CaseReview[0].CR_FaceSheet_Collection[0].CR_ChildDemographic_Collection;
        }

        if (!Ext.isEmpty(collection)) {

            filteredColl = collection.filter(function (obj) {

                var dob = new Date(obj.DateOfBirth.replace('T', ' '));

                return obj.Name == parms.childName &&
                       dob.getTime() == parms.childDateOfBirth;
            });

            if (filteredColl.length > 0) {

                resultObj = filteredColl[0];
            }
        }

        return resultObj;
    }

    var getUpdatedChildRaceInfo = function () {

        var resultObj;
        var demographicInfo = getUpdatedChildDemographicInfo();

        if (!Ext.isEmpty(demographicInfo)) {

            filteredColl = demographicInfo.CR_ChildRace_Collection.filter(function (obj) {

                return obj.RaceCode == parms.originalData.RaceCode;
            });

            if (filteredColl.length > 0) {

                resultObj = filteredColl[0];
            }
        }

        return resultObj;
    }

    var getUpdatedSafetyReport = function () {

        var resultObj;

        if (Ext.isEmpty(result.data)) {

            collection = result.CR_Safety_Collection[0].CR_SafetyReport_Collection;
        } else {

            collection = result.data.CaseReview[0].CR_Safety_Collection[0].CR_SafetyReport_Collection;
        }

        if (!Ext.isEmpty(collection)) {

            filteredColl = collection.filter(function (obj) {

                return obj.ReportDate == parms.originalData.ReportDate &&
                       obj.DispositionCode == parms.originalData.DispositionCode;
            });

            if (filteredColl.length > 0) {

                resultObj = filteredColl[0];
            }
        }

        return resultObj;
    }

    var getUpdatedSafetyReportAllegation = function () {

        var resultObj;
        collection = getUpdatedSafetyReport();

        if (!Ext.isEmpty(collection)) {

            filteredColl = collection.CR_SafetyReport_Allegation_Collection.filter(function (obj) {

                return obj.SafetyReportAllegationCode == parms.originalData.SafetyReportAllegationCode;
            });

            if (filteredColl.length > 0) {

                resultObj = filteredColl[0];
            }
        }

        return resultObj;
    }

    var getUpdatedOutcome = function () {

        var resultObj;

        if (Ext.isEmpty(result.data)) {

            collection = result.CR_Outcome_Collection;
        } else {

            collection = result.data.CaseReview[0].CR_Outcome_Collection;
        }

        if (!Ext.isEmpty(collection)) {

            filteredColl = collection.filter(function (obj) {

                return obj.OutcomeCode == parms.originalData.OutcomeCode ||
                       obj.OutcomeCode == parms.outcomeCode;
            });

            if (filteredColl.length > 0) {

                resultObj = filteredColl[0];
            }
        }

        return resultObj;
    }

    var getUpdatedItem = function () {

        var resultObj;

        var outcome = getUpdatedOutcome();

        if (!Ext.isEmpty(outcome)) {

            filteredColl = outcome.CR_Item_Collection.filter(function (item) {

                return item.ItemCode == parms.originalData.ItemCode ||
                       item.ItemCode == parms.itemCode;
            });

            if (filteredColl.length > 0) {

                resultObj = filteredColl[0];
            }
        }

        return resultObj;
    }

    var getUpdatedCaseNote = function () {

        var resultObj;

        if (Ext.isEmpty(result.data)) {

            collection = result.CR_CaseNote_Collection;
        } else {

            collection = result.data.CaseReview[0].CR_CaseNote_Collection;
        }

        if (!Ext.isEmpty(collection)) {

            filteredColl = collection.filter(function (obj) {

                return obj.Description == parms.originalData.Description &&
                       obj.Subject == parms.originalData.Subject;
            });

            if (filteredColl.length > 0) {

                resultObj = filteredColl[0];
            }
        }

        return resultObj;
    }

    var getUpdatedNote = function () {

        var resultObj;

        var updatedItem = getUpdatedItem();

        if (!Ext.isEmpty(updatedItem)) {

            filteredColl = updatedItem.CR_Note_Collection.filter(function (note) {

                return note.Description == parms.originalData.Description &&
                       note.Subject == parms.originalData.Subject;
            });

            if (filteredColl.length > 0) {

                resultObj = filteredColl[0];
            }
        }

        return resultObj;
    }

    var getUpdatedItemParticipant = function () {

        var resultObj;

        var updatedItem = getUpdatedItem();

        if (!Ext.isEmpty(updatedItem)) {

            var keys = Object.keys(participants);
            var participant;

            Ext.each(keys, function (key) {

                participant = participants[key];

                if (participant.OldParticipantID == parms.originalData.ParticipantID) {

                    resultObj = participant;

                    return false;
                }
            });
        }

        return resultObj;
    }

    var getUpdatedCaseParticipant = function () {

        var resultObj;

        if (Ext.isEmpty(result.data)) {

            collection = result.CR_FaceSheet_Collection[0];
        } else {

            collection = result.data.CaseReview[0].CR_FaceSheet_Collection[0];
        }

        if (!Ext.isEmpty(collection)) {

            filteredColl = collection.CR_CaseParticipant_Collection.filter(function (casePart) {

                return casePart.Name == parms.originalData.Name &&
                       casePart.RoleCode == parms.originalData.RoleCode;
            });

            if (filteredColl.length > 0) {

                resultObj = filteredColl[0];
            }
        }

        return resultObj;
    }

    var getUpdatedMultiAnswer = function () {

        var resultObj;

        if (Ext.isEmpty(result.data)) {

            collection = result.CR_MultiAnswer_Collection;
        } else {

            collection = result.data.CaseReview[0].CR_MultiAnswer_Collection;
        }

        if (!Ext.isEmpty(collection)) {

            filteredColl = collection.filter(function (answer) {

                return answer.CodeDescriptionID == parms.originalData.CodeDescriptionID;
            });

            if (filteredColl.length > 0) {

                resultObj = filteredColl[0];
            }
        }

        return resultObj;
    }

    var getUpdatedReviewer = function () {

        var resultObj;

        if (Ext.isEmpty(result.data)) {

            collection = result.CR_Reviewer_Collection;
        } else {

            collection = result.data.CaseReview[0].CR_Reviewer_Collection;
        }

        if (!Ext.isEmpty(collection)) {

            filteredColl = collection.filter(function (answer) {

                return answer.FullName == parms.originalData.FullName;
            });

            if (filteredColl.length > 0) {

                resultObj = filteredColl[0];
            }
        }

        return resultObj;
    }

    var getUpdatedHealthInfo = function () {

        var resultObj;

        if (Ext.isEmpty(result.data)) {

            collection = result.CR_WellBeing_Collection[0];
        } else {

            collection = result.data.CaseReview[0].CR_WellBeing_Collection[0];
        }

        if (!Ext.isEmpty(collection)) {

            filteredColl = collection.CR_Health_Collection.filter(function (healthNeed) {

                return healthNeed.HealthNeeds == parms.originalData.HealthNeeds &&
                       healthNeed.HealthNeedCode == parms.originalData.HealthNeedCode;
            });

            if (filteredColl.length > 0) {

                resultObj = filteredColl[0];
            }
        }

        return resultObj;
    }

    var getUpdatedEducationInfo = function () {

        var resultObj;

        if (Ext.isEmpty(result.data)) {

            collection = result.CR_WellBeing_Collection[0];
        } else {

            collection = result.data.CaseReview[0].CR_WellBeing_Collection[0];
        }

        if (!Ext.isEmpty(collection)) {

            filteredColl = collection.CR_Education_Collection.filter(function (educationNeed) {

                return educationNeed.Needs == parms.originalData.Needs &&
                       educationNeed.ServicesProvided == parms.originalData.ServicesProvided;
            });

            if (filteredColl.length > 0) {

                resultObj = filteredColl[0];
            }
        }

        return resultObj;
    }

    var getUpdatedGoalInfo = function () {

        var resultObj;

        if (Ext.isEmpty(result.data)) {

            collection = result.CR_Permanency_Collection[0];
        } else {

            collection = result.data.CaseReview[0].CR_Permanency_Collection[0];
        }

        if (!Ext.isEmpty(collection)) {

            filteredColl = collection.CR_Goal_Collection.filter(function (goal) {

                return goal.GoalCode == parms.originalData.GoalCode &&
                       goal.DateEstablished == parms.originalData.DateEstablished;
            });

            if (filteredColl.length > 0) {

                resultObj = filteredColl[0];
            }
        }

        return resultObj;
    }

    var getUpdatedPlacementInfo = function () {

        var resultObj;

        if (Ext.isEmpty(result.data)) {

            collection = result.CR_Permanency_Collection[0];
        } else {

            collection = result.data.CaseReview[0].CR_Permanency_Collection[0];
        }

        if (!Ext.isEmpty(collection)) {

            filteredColl = collection.CR_Placement_Collection.filter(function (goal) {

                return goal.Date == parms.originalData.Date &&
                       goal.TypeCode == parms.originalData.TypeCode;
            });

            if (filteredColl.length > 0) {

                resultObj = filteredColl[0];
            }
        }

        return resultObj;
    }

    var returnObj;

    switch (parms.selectedKey) {

        case 'CaseReview':
            return getUpdatedCaseReview();

        case 'CR_FaceSheet_Collection':
            return getUpdatedFacesheet();

        case 'CR_CaseNote_Collection':
            return getUpdatedCaseNote();

        case 'CR_CaseNote_Response_Collection':

            var caseNote = getUpdatedCaseNote();

            if (!Ext.isEmpty(caseNote)) {

                filteredColl = caseNote.CR_CaseNote_Response_Collection.filter(function (obj) {

                    return obj.Description == parms.originalData.Description;
                });

                if (filteredColl.length > 0) {

                    returnObj = filteredColl[0];
                }
            }

            return returnObj;

        case 'CR_Outcome_Collection':
            return getUpdatedOutcome();

        case 'CR_Item_Collection':
            return getUpdatedItem();

        case 'CR_Note_Collection':
            return getUpdatedNote();

        case 'CR_ItemParticipant_Collection':
            return getUpdatedItemParticipant();

        case 'CR_CaseParticipant_Collection':
            return getUpdatedCaseParticipant();

        case 'CR_Response_Collection':

            var itemNote = getUpdatedNote();

            if (!Ext.isEmpty(itemNote)) {

                filteredColl = itemNote.CR_Response_Collection.filter(function (obj) {

                    return obj.Description == parms.originalData.Description;
                });

                if (filteredColl.length > 0) {

                    returnObj = filteredColl[0];
                }
            }

            return returnObj;

        case 'CR_ChildDemographic_Collection':
            return getUpdatedChildDemographicInfo();

        case 'CR_ChildRace_Collection':
            return getUpdatedChildRaceInfo();

        case 'CR_SafetyReport_Collection':
            return getUpdatedSafetyReport();

        case 'CR_SafetyReport_Allegation_Collection':
            return getUpdatedSafetyReportAllegation();

        case 'CR_MultiAnswer_Collection':
            return getUpdatedMultiAnswer();

        case 'CR_Reviewer_Collection':
            return getUpdatedReviewer();

        case 'CR_Health_Collection':
            return getUpdatedHealthInfo();

        case 'CR_Education_Collection':
            return getUpdatedEducationInfo();

        case 'CR_Goal_Collection':
            return getUpdatedGoalInfo();

        case 'CR_Placement_Collection':
            return getUpdatedPlacementInfo();

        default:

            return returnObj;
    }
};
var verifyPreApplicabilityAnswers = function (itemName) {

    if (Ext.isEmpty(itemName)) {

        return;
    }

    var validIds = [];
    var filteredMAStore;
    var noAnswers = 0;
    var allQuestionsAnswered = false;
    var itemCode;
    var containerType;

    switch (itemName) {

        case 'item2':

            validIds = [51, 52, 53, 54, 55, 56];
            filteredMAStore = getFilteredVMMAStore('safety');
            itemCode = 3;
            containerType = 'safety';

            break;

        case 'item8':

            validIds = [57, 58, 59, 60, 61, 62];
            filteredMAStore = getFilteredVMMAStore('permanency');
            itemCode = 9;
            containerType = 'permanency';

            break;

        case 'item11':

            validIds = [63, 64, 65, 66, 67, 261];
            filteredMAStore = getFilteredVMMAStore('permanency');
            itemCode = 12;
            containerType = 'permanency';

            break;

        case 'item12B':

            validIds = [68, 69, 70, 71, 72];
            filteredMAStore = getFilteredVMMAStore('wellbeing');
            itemCode = 15;
            containerType = 'wellbeing';

            break;

        case 'item13':

            validIds = [73, 74, 75, 292, 76, 77, 78];
            filteredMAStore = getFilteredVMMAStore('wellbeing');
            itemCode = 17;
            containerType = 'wellbeing';

            break;

        case 'item15':

            validIds = [79, 80, 293, 81, 82, 83];
            filteredMAStore = getFilteredVMMAStore('wellbeing');
            itemCode = 19;
            containerType = 'wellbeing';

            break;

        default:

            break;
    }

    if (validIds.length > 0) {

        var answer;

        Ext.each(validIds, function (codeDescId) {

            answer = filteredMAStore.data.items.filter(function (item) {

                return item.data.CodeDescriptionID == codeDescId &&
                       (item.data.AnswerCode == 1 || item.data.AnswerCode == 2);
            });

            if (answer.length > 0) {

                noAnswers++;
            }
        });

        if (noAnswers == validIds.length) {

            allQuestionsAnswered = true;
        }
    }

    //
    // Update PreApplicability question
    //
    var questions = getItemQuestions(itemName);
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: getOutcomeCode(itemCode), ContainerType: containerType };

    parms['ItemName'] = itemName;
    parms['Question'] = 'PreApplicability';
    parms['Answered'] = allQuestionsAnswered;

    updateQuestionsAnswered(parms);
};
var getSelectedValue = function (newValue, oldValue) {

    var result;

    if (Ext.isEmpty(newValue)) {

        return result;
    }

    if (Ext.isEmpty(oldValue)) {

        return result;
    }

    var selectedItem = getLastRadioSelection(newValue, oldValue);

    var newKeys = getObjectKeys(selectedItem);

    return selectedItem[newKeys[0]];
}
var getSelectedGroupValue = function (newValue, oldValue) {

    var result = {};

    if (Ext.isEmpty(newValue)) {

        return result;
    }

    if (Ext.isEmpty(oldValue)) {

        return result;
    }

    var oldKeys = getObjectKeys(oldValue),
        filteredValues = [];

    for (key in newValue) {

        var keyArr = oldKeys.filter(function (item) {

            return key == item;
        });

        if (keyArr.length > 0) {

            filteredValues = newValue[key].filter(function (val) {

                return val != oldValue[keyArr[0]];
            });

            result[key] = filteredValues;
        }
    }

    var newKeys = getObjectKeys(result);

    if (newKeys.length == 0) {

        newKeys = getObjectKeys(newValue);
                
        return newKeys.length == 0 ? null : newValue[newKeys[0]];
    }

    return result[newKeys[0]][0];
}
var updateViewModels = function () {
    // 
    // Create Facesheet ViewModel
    //
    var vModel = createViewModel('facesheet');

    window.facesheetViewModel = vModel;
    // 
    // Create Safety ViewModel
    //
    vModel = createViewModel('safety');

    window.safetyViewModel = vModel;
    // 
    // Create Permanency ViewModel
    //
    vModel = createViewModel('permanency');

    window.permanencyViewModel = vModel;
    // 
    // Create viewModel
    //
    vModel = createViewModel('wellbeing');

    window.wellbeingViewModel = vModel;
};
var synchronizeSafetyAnswers = function () {


};
var synchronizePermanencyAnswers = function () {


};
var synchronizeWellbeingAnswers = function () {


};
var initializeQuestionsAnswered = function () {

    var reviewStore = chainedStore('CaseReviewStore');
    //
    // Facesheet Questions
    //
    var facesheetData = reviewStore.getAt(0).data.CR_FaceSheet_Collection[0];

    initializeFacesheetQuestions(facesheetData);
    //
    // Safety Questions
    //
    var safetyData = reviewStore.getAt(0).data.CR_Safety_Collection[0];

    initializeSafetyQuestions(safetyData);
    //
    // Permanency Questions
    //
    var permanencyData = reviewStore.getAt(0).data.CR_Permanency_Collection[0];

    initializePermanencyQuestions(permanencyData);
    //
    // Wellbeing Questions
    //
    var wellbeingData = reviewStore.getAt(0).data.CR_WellBeing_Collection[0];

    initializeWellbeingQuestions(wellbeingData);
};
var initializeFacesheetQuestions = function (data) {

    if (data.length == 0) {

        return;
    }

    var questions = getFacesheetQuestions();
    var itemCode = 23;
    var outcomeCode = 21;
    var facesheetItem;
    var participantGrid = data.CR_CaseParticipant_Collection;
    var childDemographicGrid = data.CR_ChildDemographic_Collection;
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'facesheet' };

    //
    // At least one participant must be entered into table G2. 
    //
    if (participantGrid.length > 0) {

        parms['ItemName'] = 'facesheet';
        parms['Question'] = 'QuestionG2';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    //
    // At least one child must be entered into table G1. 
    //
    if (childDemographicGrid.length > 0) {

        parms['ItemName'] = 'facesheet';
        parms['Question'] = 'QuestionG1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }
    //
    // Question H is a required field. 
    //
    var columnVal = data.IsCaseOpenReasonOtherAbuseNeglect;

    if (!(Ext.isEmpty(columnVal) || columnVal == 0)) {

        parms['ItemName'] = 'facesheet';
        parms['Question'] = 'QuestionH';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    // Question I
    var caseOpenDate = data.FirstCaseOpeningDate;

    if (!Ext.isEmpty(caseOpenDate)) {

        parms['ItemName'] = 'facesheet';
        parms['Question'] = 'QuestionI';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    // Question J
    var fosterEntryDate = data.FosterEntryDate;
    var isFosterEntryDateNA = data.IsFosterEntryDateNA == 1 ? true : false;

    if ((isFosterEntryDateNA) || !(Ext.isEmpty(fosterEntryDate))) {

        parms['ItemName'] = 'facesheet';
        parms['Question'] = 'QuestionJ';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    // Question K
    var dischargeDate = data.EpisodeDischargeDate;
    var dischargeDateNA = data.IsEpisodeDischargeDateNA;
    var notYetdischargeDate = data.IsEpisodeNotYetDischarged;

    var isDischargeDateNA = dischargeDateNA == 1 ? true : false;
    var isNotYetDischarged = notYetdischargeDate == 1 ? true : false;

    if ((isDischargeDateNA) || (isNotYetDischarged) || !Ext.isEmpty(dischargeDate)) {

        parms['ItemName'] = 'facesheet';
        parms['Question'] = 'QuestionK';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    // Question L
    var closureDate = data.CaseClosureDate;
    var caseNotClosed = data.IsCaseClosureNotClosed;

    var isCaseClosed = caseNotClosed == 1 ? true : false;

    if ((isCaseClosed) || !Ext.isEmpty(closureDate)) {

        parms['ItemName'] = 'facesheet';
        parms['Question'] = 'QuestionL';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    // Question M is a required field.

    var multiAnswers = getMultiAnswerStore('CaseReason');

    if (multiAnswers.data.length > 0) {

        parms['ItemName'] = 'facesheet';
        parms['Question'] = 'QuestionM';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }
}
var updateItem1Questions = function (data) {

    //--------------------------------------------------------------------------------
    // Item 1
    //--------------------------------------------------------------------------------
    var itemName = 'item1';
    var questions = getItemQuestions(itemName);
    var itemCode = 2;
    var outcomeCode = 1;
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'safety' };

    // 
    // Item 1 applicability is a required field.  
    //
    var item = getItemFromGraph(itemCode, outcomeCode);

    if (!Ext.isEmpty(item)) {

        if (!Ext.isEmpty(item.IsApplicable)) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Applicability';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }

        var safetyStore = data.CR_SafetyReport_Collection;

        if (safetyStore.length > 0 || item.ItemRatingCode == 3) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Question1A1';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }

        // Question 1A is a required field and must be numeric.

        var answer1A = data.ReportsNotInAccordance;

        if (!Ext.isEmpty(answer1A) || item.ItemRatingCode == 3) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Question1A';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }

        // Question 1B is a required field and must be numeric.                    

        var answer1B = data.FaceToFaceReportsNotInAccordance;

        if (!Ext.isEmpty(answer1B) || item.ItemRatingCode == 3) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Question1B';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }

        var answer1C = data.IsDelayBeyondAgencyControl;

        if (!Ext.isEmpty(answer1C) || item.ItemRatingCode == 3) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Question1C';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }
    }
}
var updateItem2Questions = function (data) {

    //--------------------------------------------------------------------------------
    // Item 2
    //--------------------------------------------------------------------------------
    var itemName = 'item2';
    var questions = getItemQuestions(itemName);
    var itemCode = 3;
    var outcomeCode = 2;
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'safety' };

    var item = getItemFromGraph(itemCode, outcomeCode);

    if (!Ext.isEmpty(item)) {
        // 
        // Item 2 preapplicability is a required field.  
        //
        var inHomeValues = [{ itemId: 'item2Question1', codeDescriptionId: 51 },
                                           { itemId: 'item2Question2', codeDescriptionId: 52 },
                                           { itemId: 'item2Question6', codeDescriptionId: 56 }
        ];

        var fosterCareValues = [{ itemId: 'item2Question3', codeDescriptionId: 53 },
                           { itemId: 'item2Question4', codeDescriptionId: 54 },
                           { itemId: 'item2Question5', codeDescriptionId: 55 },
                           { itemId: 'item2Question6', codeDescriptionId: 56 }
        ];

        var caseType = getCaseType();
        var validValues = (caseType == 'In-Home Services' || caseType == 'Juvenile Justice' || caseType == 'Behavioral Health') ? inHomeValues : fosterCareValues;
        
        var allQuestionsAnswered = self.validateItemPreApplicability(validValues);

        if (allQuestionsAnswered) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'PreApplicability';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }
        // 
        // Item 2 applicability is a required field.  
        //

        if (!Ext.isEmpty(item.IsApplicable)) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Applicability';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }

        var answer2A = data.IsEffortToPreventReEntry;

        if (!Ext.isEmpty(answer2A) || item.ItemRatingCode == 3) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Question2A';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }

        var answer2B = data.IsChildRemovedToEnsureSafety;

        if (!Ext.isEmpty(answer2B) || item.ItemRatingCode == 3) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Question2B';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }
    }
}
var updateItem3Questions = function (data) {

    //--------------------------------------------------------------------------------
    // Item 3
    //--------------------------------------------------------------------------------
    var itemName = 'item3';
    var questions = getItemQuestions(itemName);
    var itemCode = 4;
    var outcomeCode = 2;
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'safety' };

    var item = getItemFromGraph(itemCode, outcomeCode);

    if (!Ext.isEmpty(item)) {

        var questionD1CheckBoxGroup = getMultiAnswerStore('SafetyRelatedIncidents').data;
        var questionE1CheckBoxGroup = getMultiAnswerStore('FosterSafety').data;
        var questionF1CheckBoxGroup = getMultiAnswerStore('FosterPlacementConcern').data;

        if (questionD1CheckBoxGroup.length > 0 || item.ItemRatingCode == 3) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Question3D1';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }

        if (questionE1CheckBoxGroup.length > 0 || item.ItemRatingCode == 3) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Question3E1';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);

        }

        if (questionF1CheckBoxGroup.length > 0 || item.ItemRatingCode == 3) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Question3F1';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }

        var answer3A = data.IsInitialAssesmentForAllChildrenInHome;
        var answer3A1A = data.IsFamilyMaltreatmentAllegations;
        var answer3A1B = data.IsMaltreatmentNotSubstantiated;
        var answer3B = data.IsOngoingAssesementForAllChildrenInHome;
        var answer3C = data.IsSafetyPlanDevelopedAndMonitored;
        var answer3D = data.IsSafetyConcernForOtherChildren;
        var answer3E = data.IsFosterSafetyConcernDuringVisitation;
        var answer3F = data.IsFosterSafetyConcernNotAddressed;

        if ((!Ext.isEmpty(answer3A1A) && !Ext.isEmpty(answer3A1B)) || item.ItemRatingCode == 3) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Question3A1';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }

        if (!Ext.isEmpty(answer3A) || item.ItemRatingCode == 3) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Question3A';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }

        if (!Ext.isEmpty(answer3B) || item.ItemRatingCode == 3) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Question3B';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }

        if (!Ext.isEmpty(answer3C) || item.ItemRatingCode == 3) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Question3C';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }

        if (!Ext.isEmpty(answer3D) || item.ItemRatingCode == 3) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Question3D';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }

        if (!Ext.isEmpty(answer3E) || item.ItemRatingCode == 3) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Question3E';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }

        if (!Ext.isEmpty(answer3F) || item.ItemRatingCode == 3) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Question3F';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }
    }
}
var updateItem4Questions = function (data) {

    //--------------------------------------------------------------------------------
    // Item 4
    //--------------------------------------------------------------------------------
    var getCheckBoxGroup = function (storeId, groupName) {

        var store = Ext.data.ChainedStore.create({
            source: storeId,
            filters: [
                function (record) {
                    return record.data.GroupName == groupName;
                }
            ]
        });

        return store.data;
    };

    var itemName = 'item4';
    var questions = getItemQuestions(itemName);
    var itemCode = 5;
    var outcomeCode = 3;
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'permanency' };

    var placementTable = data.CR_Placement_Collection;

    if (placementTable.length > 0) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question4A1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer4A = data.NumberOfPlacementSettings;

    if (!Ext.isEmpty(answer4A)) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question4A';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer4B = data.wereAllPlacementChangesPlanned;

    if (!Ext.isEmpty(answer4B)) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question4B';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var question4C1CheckBoxGroup = getCheckBoxGroup('CR_MultiAnswer_CollectionStore', 'PlacementApplicableCircumstances');

    if (question4C1CheckBoxGroup.length > 0) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question4C1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer4C = data.IsCurrentPlacementSettingStable;

    if (!Ext.isEmpty(answer4C)) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question4C';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }
}
var updateItem5Questions = function (data) {

    //--------------------------------------------------------------------------------
    // Item 5
    //--------------------------------------------------------------------------------

    var itemName = 'item5';
    var questions = getItemQuestions(itemName);
    var itemCode = 6;
    var outcomeCode = 3;
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'permanency' };

    var item = getItemFromGraph(itemCode, outcomeCode);

    if (!Ext.isEmpty(item)) {

        if (!Ext.isEmpty(item.IsApplicable)) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Applicability';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }
    }

    var goalStore = data.CR_Goal_Collection;
    var ratingIsNA = Ext.isEmpty(item) ? false :
                     item.ItemRatingCode == 3 ? true : false;

    if (goalStore.length > 0 || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question5A1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var currentGoals = goalStore.filter(function (item) {
        return (item.IsCurrentGoal == 1);
    });

    if (currentGoals.length > 0 || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question5A2';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer5A3 = data.IsGoalSpecified;

    if (!Ext.isEmpty(answer5A3) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question5A3';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer5B = data.wereAllGoalsInTimelyManner;

    if (!Ext.isEmpty(answer5B) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question5B';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer5C = data.wereAllGoalsAppropriate;

    if (!Ext.isEmpty(answer5C) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question5C';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer5D = data.IsInFoster15OutOf22;

    if (!Ext.isEmpty(answer5D) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question5D';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer5E = data.meetsTerminationOfParentalRights;

    if (!Ext.isEmpty(answer5E) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question5E';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer5F = data.IsAgencyJointTerminationOfParentalRights;

    if (!Ext.isEmpty(answer5F) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question5F';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var question5G1CheckBoxGroup = getMultiAnswerStore('TerminationExceptions');

    if (question5G1CheckBoxGroup.data.length > 0 || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question5G1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer5G = data.IsExceptionForTermination;

    if (!Ext.isEmpty(answer5G) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question5G';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }
}
var updateItem6Questions = function (data) {

    //--------------------------------------------------------------------------------
    // Item 6
    //--------------------------------------------------------------------------------
    var getCheckBoxGroup = function (storeId, groupName) {

        var store = Ext.data.ChainedStore.create({
            source: storeId,
            filters: [
                function (record) {
                    return record.data.GroupName == groupName;
                }
            ]
        });

        return store.data;
    };

    var itemName = 'item6';
    var questions = getItemQuestions(itemName);
    var itemCode = 7;
    var outcomeCode = 3;
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'permanency' };

    var item = getItemFromGraph(itemCode, outcomeCode);
    var ratingIsNA = Ext.isEmpty(item) ? false :
                     item.ItemRatingCode == 3 ? true : false;

    var facesheetStore = Ext.data.ChainedStore.create({
        source: 'CR_FaceSheet_CollectionStore'
    });

    var answer6A1 = facesheetStore.getAt(0).data.FosterEntryDate;

    if (!Ext.isEmpty(answer6A1) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question6A1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer6A2 = data.TimeInCare;

    if (!Ext.isEmpty(answer6A2) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question6A2';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer6A3 = facesheetStore.getAt(0).data.EpisodeDischargeDate;
    var isDischargedDateNA = data.IsDischargeDateNA;

    answer6A3 = Ext.isEmpty(answer6A3) ? (isDischargedDateNA == 0 ? undefined : isDischargedDateNA) : answer6A3;

    if (!Ext.isEmpty(answer6A3) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question6A3';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer6B = data.IsAgencyConcertedEfforts;
    answer6B = Ext.isEmpty(answer6B) ? (answer6B == 0 ? undefined : answer6B) : answer6B;

    if (!Ext.isEmpty(answer6B) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question6B';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer6BNarrative = data.AgencyConcertedEffortsExplained;
    var question6A4CheckBoxGroup = getCheckBoxGroup('CR_MultiAnswer_CollectionStore', 'PermanencyGoal1');

    if (question6A4CheckBoxGroup.length > 0 || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question6A4';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer6C1 = data.LivingArrangementCode;
    var modifiedAnswer6C1 = answer6C1 == 0 ? undefined : answer6C1;

    if (!Ext.isEmpty(modifiedAnswer6C1) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question6C1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var noDate = data.IsOtherPlannedArrangementNoDate;
    var answer6C2DocumentDate = Date.parse(data.OtherPlannedArrangementDocumentationDate);
    noDate = noDate == 0 ? undefined : noDate;
    var answer6C2NA = data.IsOtherPlannedArrangementNA;
    answer6C2NA = answer6C2NA == 0 ? undefined : answer6C2NA;

    if (!Ext.isEmpty(noDate) || !(isNaN(answer6C2DocumentDate)) || !Ext.isEmpty(answer6C2NA) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question6C2';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer6C = data.IsOtherPlannedConcertedEffort;
    answer6C = answer6C == 0 ? undefined : answer6C;

    if (!Ext.isEmpty(answer6C) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question6C';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }
}
var updateItem7Questions = function (data) {

    //--------------------------------------------------------------------------------
    // Item 7
    //--------------------------------------------------------------------------------

    var itemName = 'item7';
    var questions = getItemQuestions(itemName);
    var itemCode = 8;
    var outcomeCode = 4;
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'permanency' };

    var item = getItemFromGraph(itemCode, outcomeCode);
    var ratingIsNA = Ext.isEmpty(item) ? false :
                     item.ItemRatingCode == 3 ? true : false;

    if (!Ext.isEmpty(item)) {

        if (!Ext.isEmpty(item.IsApplicable)) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Applicability';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }
    }

    var answer7A = data.IsPlacedWithAllSiblings;
    answer7A = answer7A == 0 ? undefined : answer7A;

    if (!Ext.isEmpty(answer7A) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question7A';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer7B = data.IsValidReasonForSeparation;
    answer7B = answer7B == 0 ? undefined : answer7B;

    if (!Ext.isEmpty(answer7B) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question7B';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }
}
var updateItem8Questions = function (data) {

    //--------------------------------------------------------------------------------
    // Item 8
    //--------------------------------------------------------------------------------
    var itemName = 'item8';
    var questions = getItemQuestions(itemName);
    var itemCode = 9;
    var outcomeCode = 4;
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'permanency' };

    var getApplicabilityAnswers = function () {

        var store = chainedStore('CaseReviewLookUpStore');

        var filteredStore = store.getAt(0).get('Applicability');
        var applicabilityStore;

        if (!Ext.isEmpty(filteredStore)) {

            applicabilityStore = filteredStore.filter(function (answer) {

                return answer.CodeDescriptionID > 56 && answer.CodeDescriptionID < 63;
            });
        }

        return applicabilityStore;
    };

    var isMotherSelected = function () {

        var motherStore = GetItemParticipant(1);
        var dataParms = { itemCode: itemCode, outcomeCode: outcomeCode };

        var result = false;

        Ext.each(motherStore, function (part) {

            dataParms['participantId'] = part.data.CaseParticipantID;;

            if (isItemParticipantSelected(dataParms)) {

                result = true;

                return false;
            }
        });

        return result;
    };

    var isFatherSelected = function () {

        var motherStore = GetItemParticipant(2);
        var dataParms = { itemCode: itemCode, outcomeCode: outcomeCode };

        var result = false;

        Ext.each(motherStore, function (part) {

            dataParms['participantId'] = part.data.CaseParticipantID;;

            if (isItemParticipantSelected(dataParms)) {

                result = true;

                return false;
            }
        });

        return result;
    };

    var item = getItemFromGraph(itemCode, outcomeCode);
    var ratingIsNA = Ext.isEmpty(item) ? false :
                     item.ItemRatingCode == 3 ? true : false;

    if (!Ext.isEmpty(item)) {

        if (!Ext.isEmpty(item.IsApplicable)) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Applicability';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }
    }

    if (getApplicabilityAnswers().length == 7) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'PreApplicability';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    if (isMotherSelected() || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'ApplicabilityMother';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    if (isFatherSelected() || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'ApplicabilityFather';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    if (isMotherSelected() || isFatherSelected() || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'MotherOrFatherApplicable';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer8A = data.IsSufficientFrequencyForMotherVisitation;
    answer8A = answer8A == 0 ? undefined : answer8A;

    if (!Ext.isEmpty(answer8A) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question8A';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer8A1 = data.MotherVisitationFrequencyCode;
    answer8A1 = answer8A1 == 0 ? undefined : answer8A1;

    if (!Ext.isEmpty(answer8A1) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question8A1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer8B = data.IsSufficientFrequencyForFatherVisitation;
    answer8B = answer8B == 0 ? undefined : answer8B;

    if (!Ext.isEmpty(answer8B) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question8B';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer8B1 = data.FatherVisitationFrequencyCode;
    answer8B1 = answer8B1 == 0 ? undefined : answer8B1;

    if (!Ext.isEmpty(answer8B1) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question8B1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer8C = data.IsSufficientQualityForMotherVisitation;
    answer8C = answer8C == 0 ? undefined : answer8C;

    if (!Ext.isEmpty(answer8C) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question8C';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer8D = data.IsSufficentQualityForFatherVisitation;
    answer8D = answer8D == 0 ? undefined : answer8D;

    if (!Ext.isEmpty(answer8D) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question8D';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer8E = data.IsSufficientFrequencyForSiblingVisitation;
    answer8E = answer8E == 0 ? undefined : answer8E;

    if (!Ext.isEmpty(answer8E) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question8E';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer8E1 = data.SiblingVisitationFrequencyCode;
    answer8E1 = answer8E1 == 0 ? undefined : answer8E1;

    if (!Ext.isEmpty(answer8E1) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question8E1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer8F = data.IsSufficentQualityForSiblingVisitation;
    answer8F = answer8F == 0 ? undefined : answer8F;

    if (!Ext.isEmpty(answer8F) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question8F';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }
}
var updateItem9Questions = function (data) {

    //--------------------------------------------------------------------------------
    // Item 9
    //--------------------------------------------------------------------------------

    var itemName = 'item9';
    var questions = getItemQuestions(itemName);
    var itemCode = 10;
    var outcomeCode = 4;
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'permanency' };

    var item = getItemFromGraph(itemCode, outcomeCode);
    var ratingIsNA = Ext.isEmpty(item) ? false :
                     item.ItemRatingCode == 3 ? true : false;

    if (!Ext.isEmpty(item)) {

        if (!Ext.isEmpty(item.IsApplicable)) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Applicability';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }
    }

    var answer9A = data.IsConcertedEffortsForImportantConnections;
    answer9A = answer9A == 0 ? undefined : answer9A;

    if (!Ext.isEmpty(answer9A) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question9A';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer9B = data.IsSufficientInquiryForIndianTribe;
    answer9B = answer9B == 0 ? undefined : answer9B;

    if (!Ext.isEmpty(answer9B) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question9B';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer9C = data.IsTribeProvidedTimelyNotification;
    answer9C = answer9C == 0 ? undefined : answer9C;

    if (!Ext.isEmpty(answer9C) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question9C';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer9D = data.IsAccordanceWithIndianChildWelfareAct;
    answer9D = answer9D == 0 ? undefined : answer9D;

    if (!Ext.isEmpty(answer9D) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question9D';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }
}
var updateItem10Questions = function (data) {

    //--------------------------------------------------------------------------------
    // Item 10
    //--------------------------------------------------------------------------------

    var itemName = 'item10';
    var questions = getItemQuestions(itemName);
    var itemCode = 11;
    var outcomeCode = 4;
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'permanency' };

    var item = getItemFromGraph(itemCode, outcomeCode);
    var ratingIsNA = Ext.isEmpty(item) ? false :
                     item.ItemRatingCode == 3 ? true : false;

    if (!Ext.isEmpty(item)) {

        if (!Ext.isEmpty(item.IsApplicable)) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Applicability';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }
    }

    var answer10A1 = data.IsRecentPlacementWithRelative;
    answer10A1 = answer10A1 == 0 ? undefined : answer10A1;

    if (!Ext.isEmpty(answer10A1) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question10A1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer10A2 = data.IsPlacementWithRelativeStable;
    answer10A2 = answer10A2 == 0 ? undefined : answer10A2;

    if (!Ext.isEmpty(answer10A2) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question10A2';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer10B = data.IsConcertedEffortToLocateMaternalRelatives;
    answer10B = answer10B == 0 ? undefined : answer10B;

    if (!Ext.isEmpty(answer10B) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question10B';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer10C = data.IsConcertedEffortToLocatePaternalRelatives;
    answer10C = answer10C == 0 ? undefined : answer10C;

    if (!Ext.isEmpty(answer10C) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question10C';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }
}
var updateItem11Questions = function (data) {

    //--------------------------------------------------------------------------------
    // Item 11
    //--------------------------------------------------------------------------------
    var itemName = 'item11';
    var questions = getItemQuestions(itemName);
    var itemCode = 12;
    var outcomeCode = 4;
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'permanency' };

    var getCheckBoxGroup = function (storeId, groupName) {

        var store = Ext.data.ChainedStore.create({
            source: storeId,
            filters: [
                function (record) {
                    return record.data.GroupName == groupName;
                }
            ]
        });

        return store.data;
    };

    var getApplicabilityAnswers = function () {

        var store = chainedStore('CaseReviewLookUpStore');

        var filteredStore = store.getAt(0).get('Applicability');
        var applicabilityStore;

        if (!Ext.isEmpty(filteredStore)) {

            applicabilityStore = filteredStore.filter(function (answer) {

                return (answer.CodeDescriptionID > 62 && answer.CodeDescriptionID < 68) || answer.CodeDescriptionID == 261;
            });
        }

        return applicabilityStore;
    };

    var isMotherSelected = function () {

        var motherStore = GetItemParticipant(1);
        var dataParms = { itemCode: itemCode, outcomeCode: outcomeCode };

        var result = false;

        Ext.each(motherStore, function (part) {

            dataParms['participantId'] = part.data.CaseParticipantID;;

            if (isItemParticipantSelected(dataParms)) {

                result = true;

                return false;
            }
        });

        return result;
    };

    var isFatherSelected = function () {

        var motherStore = GetItemParticipant(2);
        var dataParms = { itemCode: itemCode, outcomeCode: outcomeCode };

        var result = false;

        Ext.each(motherStore, function (part) {

            dataParms['participantId'] = part.data.CaseParticipantID;;

            if (isItemParticipantSelected(dataParms)) {

                result = true;

                return false;
            }
        });

        return result;
    };

    var item = getItemFromGraph(itemCode, outcomeCode);
    var ratingIsNA = Ext.isEmpty(item) ? false :
                     item.ItemRatingCode == 3 ? true : false;

    if (!Ext.isEmpty(item)) {

        if (!Ext.isEmpty(item.IsApplicable)) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Applicability';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }
    }

    if (getApplicabilityAnswers().length == 6) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'PreApplicability';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    //if (isMotherSelected()) {

    //    parms['ItemName'] = itemName;
    //    parms['Question'] = 'ApplicabilityMother';
    //    parms['Answered'] = true;

    //    updateQuestionsAnswered(parms);
    //}

    //if (isFatherSelected()) {

    //    parms['ItemName'] = itemName;
    //    parms['Question'] = 'ApplicabilityFather';
    //    parms['Answered'] = true;

    //    updateQuestionsAnswered(parms);
    //}

    //if (isMotherSelected() || isFatherSelected()) {

    //    parms['ItemName'] = itemName;
    //    parms['Question'] = 'MotherOrFatherApplicable';
    //    parms['Answered'] = true;

    //    updateQuestionsAnswered(parms);
    //}

    var answer11A = data.IsConcertedEffortMotherFosterRelationship;
    answer11A = answer11A == 0 ? undefined : answer11A;

    if (!Ext.isEmpty(answer11A) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question11A';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var question11A1CheckBoxGroup = getCheckBoxGroup('CR_MultiAnswer_CollectionStore', 'EffortsToSupportMotherFosterRelationship');

    if (question11A1CheckBoxGroup.length > 0 || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question11A1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer11B = data.IsConcertedEffortFatherFosterRelationship;
    answer11B = answer11B == 0 ? undefined : answer11B;

    if (!Ext.isEmpty(answer11A) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question11B';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var question11B1CheckBoxGroup = getCheckBoxGroup('CR_MultiAnswer_CollectionStore', 'EffortsToSupportFatherFosterRelationship');

    if (question11B1CheckBoxGroup.length > 0 || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question11B1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var parms1 = { ItemCode: itemCode, OutcomeCode: outcomeCode };

    var participants = getParticipantsSelected(parms1);

    var participantMotherStore = participants.Mothers;
    var participantFatherStore = participants.Fathers;

    if (participantMotherStore.length > 0 || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'ApplicabilityMother';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    if (participantFatherStore.length > 0 || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'ApplicabilityFather';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    if (participantMotherStore.length > 0 || participantFatherStore.length > 0 || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'MotherOrFatherApplicable';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }
}
var updateItem12AQuestions = function (data) {

    //--------------------------------------------------------------------------------
    // Item 12A
    //--------------------------------------------------------------------------------

    var itemName = 'item12A';
    var questions = getItemQuestions(itemName);
    var itemCode = 14;
    var outcomeCode = 5;
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'wellbeing' };

    var item = getItemFromGraph(itemCode, outcomeCode);
    var ratingIsNA = Ext.isEmpty(item) ? false :
                     item.ItemRatingCode == 3 ? true : false;

    var answer12A1 = data.IsComprehensiveAssessementConducted;
    answer12A1 = answer12A1 == 0 ? undefined : answer12A1;

    if (!Ext.isEmpty(answer12A1) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question12A1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer12A2 = data.IsAppropriateServicesProvided;
    answer12A2 = answer12A2 == 0 ? undefined : answer12A2;

    if (!Ext.isEmpty(answer12A2) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question12A2';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }
}
var updateItem12BQuestions = function (data) {

    //--------------------------------------------------------------------------------
    // Item 12B
    //--------------------------------------------------------------------------------

    var itemName = 'item12B';
    var questions = getItemQuestions(itemName);
    var itemCode = 15;
    var outcomeCode = 5;
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'wellbeing' };

    var getApplicabilityAnswers = function () {

        var store = chainedStore('CaseReviewLookUpStore');

        var filteredStore = store.getAt(0).get('Applicability');
        var applicabilityStore;

        if (!Ext.isEmpty(filteredStore)) {

            applicabilityStore = filteredStore.filter(function (answer) {

                return (answer.CodeDescriptionID > 67 && answer.CodeDescriptionID < 73);
            });
        }

        return applicabilityStore;
    };

    var isMotherSelected = function () {

        var motherStore = GetItemParticipant(1);
        var dataParms = { itemCode: itemCode, outcomeCode: outcomeCode };

        var result = false;

        Ext.each(motherStore, function (part) {

            dataParms['participantId'] = part.data.CaseParticipantID;;

            if (isItemParticipantSelected(dataParms)) {

                result = true;

                return false;
            }
        });

        return result;
    };

    var isFatherSelected = function () {

        var motherStore = GetItemParticipant(2);
        var dataParms = { itemCode: itemCode, outcomeCode: outcomeCode };

        var result = false;

        Ext.each(motherStore, function (part) {

            dataParms['participantId'] = part.data.CaseParticipantID;;

            if (isItemParticipantSelected(dataParms)) {

                result = true;

                return false;
            }
        });

        return result;
    };

    var item = getItemFromGraph(itemCode, outcomeCode);
    var ratingIsNA = Ext.isEmpty(item) ? false :
                     item.ItemRatingCode == 3 ? true : false;

    if (!Ext.isEmpty(item)) {

        if (!Ext.isEmpty(item.IsApplicable)) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Applicability';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }
    }

    if (getApplicabilityAnswers().length == 5) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'PreApplicability';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer12B1 = data.IsComprehensiveAssessementForMotherConducted;
    answer12B1 = answer12B1 == 0 ? undefined : answer12B1;

    if (!Ext.isEmpty(answer12B1) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question12B1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer12B3 = data.IsAppropriateServicesForMotherProvided;
    answer12B3 = answer12B3 == 0 ? undefined : answer12B3;

    if (!Ext.isEmpty(answer12B3) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question12B3';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer12B2 = data.IsComprehensiveAssessementForFatherConducted;
    answer12B2 = answer12B2 == 0 ? undefined : answer12B2;

    if (!Ext.isEmpty(answer12B2) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question12B2';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer12B4 = data.IsAppropriateServicesForFatherProvided;
    answer12B4 = answer12B4 == 0 ? undefined : answer12B4;

    if (!Ext.isEmpty(answer12B4) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question12B4';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    if (isMotherSelected() || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'MotherSelected';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    if (isFatherSelected() || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'FatherSelected';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }


    if (isMotherSelected() || isFatherSelected() || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'MotherOrFatherApplicable';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }
}
var updateItem12CQuestions = function (data) {

    //--------------------------------------------------------------------------------
    // Item 12C
    //--------------------------------------------------------------------------------

    var itemName = 'item12C';
    var questions = getItemQuestions(itemName);
    var itemCode = 16;
    var outcomeCode = 5;
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'wellbeing' };

    var item = getItemFromGraph(itemCode, outcomeCode);
    var ratingIsNA = Ext.isEmpty(item) ? false :
                     item.ItemRatingCode == 3 ? true : false;

    if (!Ext.isEmpty(item)) {

        if (!Ext.isEmpty(item.IsApplicable)) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Applicability';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }
    }

    var answer12C1 = data.IsNeedsOfFosterParentsAdequatelyAssessed;
    answer12C1 = answer12C1 == 0 ? undefined : answer12C1;

    var answer12C2 = data.IsFosterParentsProvidedAppropriateServices;
    answer12C2 = answer12C2 == 0 ? undefined : answer12C2;

    if (!Ext.isEmpty(answer12C1) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question12C1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    if (!Ext.isEmpty(answer12C2) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question12C2';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }
}
var updateItem13Questions = function (data) {

    //--------------------------------------------------------------------------------
    // Item 13
    //--------------------------------------------------------------------------------

    var itemName = 'item13';
    var questions = getItemQuestions(itemName);
    var itemCode = 17;
    var outcomeCode = 5;
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'wellbeing' };

    var getApplicabilityAnswers = function () {

        var store = chainedStore('CaseReviewLookUpStore');

        var filteredStore = store.getAt(0).get('Applicability');
        var applicabilityStore;

        if (!Ext.isEmpty(filteredStore)) {

            applicabilityStore = filteredStore.filter(function (answer) {

                return (answer.CodeDescriptionID > 72 && answer.CodeDescriptionID < 79) || answer.CodeDescriptionID == 292;
            });
        }

        return applicabilityStore;
    };

    var isMotherSelected = function () {

        var motherStore = GetItemParticipant(1);
        var dataParms = { itemCode: itemCode, outcomeCode: outcomeCode };

        var result = false;

        Ext.each(motherStore, function (part) {

            dataParms['participantId'] = part.data.CaseParticipantID;;

            if (isItemParticipantSelected(dataParms)) {

                result = true;

                return false;
            }
        });

        return result;
    };

    var isFatherSelected = function () {

        var motherStore = GetItemParticipant(2);
        var dataParms = { itemCode: itemCode, outcomeCode: outcomeCode };

        var result = false;

        Ext.each(motherStore, function (part) {

            dataParms['participantId'] = part.data.CaseParticipantID;;

            if (isItemParticipantSelected(dataParms)) {

                result = true;

                return false;
            }
        });

        return result;
    };

    var item = getItemFromGraph(itemCode, outcomeCode);
    var ratingIsNA = Ext.isEmpty(item) ? false :
                     item.ItemRatingCode == 3 ? true : false;

    if (!Ext.isEmpty(item)) {

        if (!Ext.isEmpty(item.IsApplicable)) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Applicability';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }
    }

    if (getApplicabilityAnswers().length == 7) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'PreApplicability';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer13A = data.IsAgencyConcertedEffortsToInvolveTheChild;
    answer13A = answer13A == 0 ? undefined : answer13A;

    if (!Ext.isEmpty(answer13A) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question13A';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer13B = data.IsAgencyConcertedEffortsToInvolveTheMother;
    answer13B = answer13B == 0 ? undefined : answer13B;

    if (!Ext.isEmpty(answer13B) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question13B';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer13C = data.IsAgencyConcertedEffortsToInvolveTheFather;
    answer13C = answer13C == 0 ? undefined : answer13C;

    if (!Ext.isEmpty(answer13C) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question13C';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    if (isMotherSelected() || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Mother';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    if (isFatherSelected() || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Father';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    if (isMotherSelected() || isFatherSelected() || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'MotherOrFatherApplicable';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }
}
var updateItem14Questions = function (data) {

    //--------------------------------------------------------------------------------
    // Item 14
    //--------------------------------------------------------------------------------

    var itemName = 'item14';
    var questions = getItemQuestions(itemName);
    var itemCode = 18;
    var outcomeCode = 5;
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'wellbeing' };

    var item = getItemFromGraph(itemCode, outcomeCode);
    var ratingIsNA = Ext.isEmpty(item) ? false :
                     item.ItemRatingCode == 3 ? true : false;

    var answer14A = data.IsResponsiblePartyVisitationFrequencySufficient;
    answer14A = answer14A == 0 ? undefined : answer14A;

    if (!Ext.isEmpty(answer14A) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question14A';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer14A1 = data.ResponsiblePartyVisitationFrequencyCode;
    answer14A1 = answer14A1 == 0 ? undefined : answer14A1;

    if (!Ext.isEmpty(answer14A1) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question14A1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer14B = data.IsResponsiblePartyVisitationQualitySufficient;
    answer14B = answer14B == 0 ? undefined : answer14B;

    if (!Ext.isEmpty(answer14B) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question14B';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }
}
var updateItem15Questions = function (data) {

    //--------------------------------------------------------------------------------
    // Item 15
    //--------------------------------------------------------------------------------

    var itemName = 'item15';
    var questions = getItemQuestions(itemName);
    var itemCode = 19;
    var outcomeCode = 5;
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'wellbeing' };

    var getApplicabilityAnswers = function () {

        var store = chainedStore('CaseReviewLookUpStore');

        var filteredStore = store.getAt(0).get('Applicability');
        var applicabilityStore;

        if (!Ext.isEmpty(filteredStore)) {

            applicabilityStore = filteredStore.filter(function (answer) {

                return (answer.CodeDescriptionID > 78 && answer.CodeDescriptionID < 84);
            });
        }

        return applicabilityStore;
    };

    var isMotherSelected = function () {

        var motherStore = GetItemParticipant(1);
        var dataParms = { itemCode: itemCode, outcomeCode: outcomeCode };

        var result = false;

        Ext.each(motherStore, function (part) {

            dataParms['participantId'] = part.data.CaseParticipantID;;

            if (isItemParticipantSelected(dataParms)) {

                result = true;

                return false;
            }
        });

        return result;
    };

    var isFatherSelected = function () {

        var motherStore = GetItemParticipant(2);
        var dataParms = { itemCode: itemCode, outcomeCode: outcomeCode };

        var result = false;

        Ext.each(motherStore, function (part) {

            dataParms['participantId'] = part.data.CaseParticipantID;;

            if (isItemParticipantSelected(dataParms)) {

                result = true;

                return false;
            }
        });

        return result;
    };

    var item = getItemFromGraph(itemCode, outcomeCode);
    var ratingIsNA = Ext.isEmpty(item) ? false :
                     item.ItemRatingCode == 3 ? true : false;

    if (!Ext.isEmpty(item)) {

        if (!Ext.isEmpty(item.IsApplicable)) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Applicability';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }
    }

    if (getApplicabilityAnswers().length == 5) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'PreApplicability';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer15A1 = data.ResponsiblePartyVisitationFrequencyWithMotherCode;
    answer15A1 = answer15A1 == 0 ? undefined : answer15A1;

    if (!Ext.isEmpty(answer15A1) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question15A1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer15A2 = data.IsResponsiblePartyVisitationFrequencyWithMotherSufficient;
    answer15A2 = answer15A2 == 0 ? undefined : answer15A2;

    if (!Ext.isEmpty(answer15A2) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question15A2';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer15B1 = data.ResponsiblePartyVisitationFrequencyWithFatherCode;
    answer15B1 = answer15B1 == 0 ? undefined : answer15B1;

    if (!Ext.isEmpty(answer15B1) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question15B1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer15B2 = data.IsResponsiblePartyVisitationFrequencyWithFatherSufficient;
    answer15B2 = answer15B2 == 0 ? undefined : answer15B2;

    if (!Ext.isEmpty(answer15B2) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question15B2';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer15C = data.IsResponsiblePartyVisitationQualityWithMotherSufficient;
    answer15C = answer15C == 0 ? undefined : answer15C;

    if (!Ext.isEmpty(answer15C) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question15C';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer15D = data.IsResponsiblePartyVisitationQualityWithFatherSufficient;
    answer15D = answer15D == 0 ? undefined : answer15D;

    if (!Ext.isEmpty(answer15D) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question15D';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    if (isMotherSelected() || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'MotherSelected';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    if (isFatherSelected() || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'FatherSelected';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    if (isMotherSelected() || isFatherSelected() || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'MotherOrFatherApplicable';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }
}
var updateItem16Questions = function (data) {

    //--------------------------------------------------------------------------------
    // Item 16
    //--------------------------------------------------------------------------------

    var itemName = 'item16',
        questions = getItemQuestions(itemName),
        itemCode = 20,
        outcomeCode = 6,
        parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'wellbeing' },
        item = getItemFromGraph(itemCode, outcomeCode),
        ratingIsNA = Ext.isEmpty(item) ? false :
                     item.ItemRatingCode == 3 ? true : false,
        educationTableRequired = false;

    if (!Ext.isEmpty(item)) {

        if (!Ext.isEmpty(item.IsApplicable)) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Applicability';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }
    }

    var answer16A = data.IsAgencyAssessEducationNeeds;
    answer16A = answer16A == 0 ? undefined : answer16A;

    if (!Ext.isEmpty(answer16A) || ratingIsNA) {

        if (item.IsApplicable == 1) {

            educationTableRequired = true;
        }

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question16A';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var educationStore = chainedStore('CR_Education_CollectionStore');

    if (educationStore.data.length > 0 || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question16A1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    if (educationTableRequired && educationStore.data.length == 0) {

        var parms = {
            questions: questions,
            itemName: itemName,
            msgComponent: getAppController().getMsgItem16A1(),
            message: 'The education table is required since you indicated that this item is applicable.'
        };

        recalculateItemStatus(parms);
    }

    var answer16B = data.IsAgencyAddressEducationNeeds;
    answer16B = answer16B == 0 ? undefined : answer16B;

    if (!Ext.isEmpty(answer16B) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question16B';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }
}
var updateItem17Questions = function (data) {

    //--------------------------------------------------------------------------------
    // Item 17
    //--------------------------------------------------------------------------------

    var itemName = 'item17';
    var questions = getItemQuestions(itemName);
    var itemCode = 21;
    var outcomeCode = 7;
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'wellbeing' };

    var item = getItemFromGraph(itemCode, outcomeCode);
    var ratingIsNA = Ext.isEmpty(item) ? false :
                     item.ItemRatingCode == 3 ? true : false;

    if (!Ext.isEmpty(item)) {

        if (!Ext.isEmpty(item.IsApplicable)) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Applicability';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }
    }

    var healthStore = Ext.data.ChainedStore.create({
        source: 'CR_Health_CollectionStore',
        filters: [
            function (record) {
                return record.get('HealthNeedCode') == 1;
            }
        ]
    });

    if (healthStore.data.length > 0 || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question17A3';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer17B1 = data.IsFosterOversightMedicationForPhysicalHealtyAppropriate;
    answer17B1 = answer17B1 == 0 ? undefined : answer17B1;

    if (!Ext.isEmpty(answer17B1) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question17B1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer17B2 = data.IsAppropriateSerivcesForAllPhysicalHealthNeeds;
    answer17B2 = answer17B2 == 0 ? undefined : answer17B2;

    if (!Ext.isEmpty(answer17B2) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question17B2';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer17B3 = data.IsAppropriateServicesForAllDentalNeeds;
    answer17B3 = answer17B3 == 0 ? undefined : answer17B3;

    if (!Ext.isEmpty(answer17B3) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question17B3';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer17A1 = data.IsAgencyAssessPhysicalHealthNeeds;
    answer17A1 = answer17A1 == 0 ? undefined : answer17A1;

    if (!Ext.isEmpty(answer17A1) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question17A1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer17A2 = data.IsAgencyAssessDentalHealthNeeds;
    answer17A2 = answer17A2 == 0 ? undefined : answer17A2;

    if (!Ext.isEmpty(answer17A2) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question17A2';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    if (!Ext.isEmpty(answer17A1) || !Ext.isEmpty(answer17A2)) {

        if (healthStore.data.length == 0) {

            var parms = {
                questions: questions,
                itemName: itemName,
                msgComponent: getAppController().getMsgItem17A3(),
                message: 'The physical and dental health table is required since you indicated that this item is applicable.'
            };

            recalculateItemStatus(parms);
        }
    }
}
var updateItem18Questions = function (data) {

    //--------------------------------------------------------------------------------
    // Item 18
    //--------------------------------------------------------------------------------

    var itemName = 'item18';
    var questions = getItemQuestions(itemName);
    var itemCode = 22;
    var outcomeCode = 7;
    var parms = { QuestionsObj: questions, ItemCode: itemCode, OutcomeCode: outcomeCode, ContainerType: 'wellbeing' };

    var item = getItemFromGraph(itemCode, outcomeCode);
    var ratingIsNA = Ext.isEmpty(item) ? false :
                     item.ItemRatingCode == 3 ? true : false;

    if (!Ext.isEmpty(item)) {

        if (!Ext.isEmpty(item.IsApplicable)) {

            parms['ItemName'] = itemName;
            parms['Question'] = 'Applicability';
            parms['Answered'] = true;

            updateQuestionsAnswered(parms);
        }
    }

    var healthStore = Ext.data.ChainedStore.create({
        source: 'CR_Health_CollectionStore',
        filters: [
            function (record) {
                return record.get('HealthNeedCode') == 2;
            }
        ]
    });

    if (healthStore.data.length > 0 || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question18A1';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer18A = data.IsAgencyAssessMentalHealthNeeds;
    answer18A = Ext.isEmpty(answer18A) ? undefined : answer18A;

    if (!Ext.isEmpty(answer18A) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question18A';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    if (!Ext.isEmpty(answer18A)) {

        if (healthStore.data.length == 0) {

            var parms = {
                questions: questions,
                itemName: itemName,
                msgComponent: getAppController().getMsgItem18A1(),
                message: 'The mental/behavioral health table is required since you indicated that this item is applicable.'
            };

            recalculateItemStatus(parms);
        }
    }

    var answer18B = data.IsFosterOversightMedicationForMentalHealtyAppropriate;
    answer18B = Ext.isEmpty(answer18B) ? undefined : answer18B;

    if (!Ext.isEmpty(answer18B) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question18B';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }

    var answer18C = data.IsAppropriateSerivcesForMentalHealthNeeds;
    answer18C = Ext.isEmpty(answer18C) ? undefined : answer18C;

    if (!Ext.isEmpty(answer18C) || ratingIsNA) {

        parms['ItemName'] = itemName;
        parms['Question'] = 'Question18C';
        parms['Answered'] = true;

        updateQuestionsAnswered(parms);
    }
}
var initializeSafetyQuestions = function (data) {

    if (data.length == 0) {

        return;
    }

    validateItemPreApplicability = function (validValues) {

        var allQuestionsAnswered = true;

        var multiAnswerStore = Ext.data.ChainedStore.create({
            source: 'CR_MultiAnswer_CollectionStore'
        });

        Ext.each(validValues, function (valueObj) {

            var answer = multiAnswerStore.data.items.filter(function (item) {
                return item.data.CodeDescriptionID == valueObj.codeDescriptionId;
            });

            var answerCode;
            var questionAns;

            if (answer.length > 0) {

                answerCode = answer[0].data.AnswerCode;
                questionAns = answerCode == 1 ? 'Yes' : answerCode == 2 ? 'No' : undefined;
            }

            if (Ext.isEmpty(answerCode)) {

                allQuestionsAnswered = false;

            }
        });

        return allQuestionsAnswered;
    };
    //--------------------------------------------------------------------------------
    // Item 1
    //--------------------------------------------------------------------------------
    updateItem1Questions(data);

    //--------------------------------------------------------------------------------
    // Item 2
    //--------------------------------------------------------------------------------
    updateItem2Questions(data);

    //--------------------------------------------------------------------------------
    // Item 3
    //--------------------------------------------------------------------------------
    updateItem3Questions(data);
}
var initializePermanencyQuestions = function (data) {

    if (data.length == 0) {

        return;
    }
    //--------------------------------------------------------------------------------
    // Item 4
    //--------------------------------------------------------------------------------
    updateItem4Questions(data);

    //--------------------------------------------------------------------------------
    // Item 5
    //--------------------------------------------------------------------------------
    updateItem5Questions(data);

    //--------------------------------------------------------------------------------
    // Item 6
    //--------------------------------------------------------------------------------
    updateItem6Questions(data);

    //--------------------------------------------------------------------------------
    // Item 7
    //--------------------------------------------------------------------------------
    updateItem7Questions(data);

    //--------------------------------------------------------------------------------
    // Item 8
    //--------------------------------------------------------------------------------
    updateItem8Questions(data);

    //--------------------------------------------------------------------------------
    // Item 9
    //--------------------------------------------------------------------------------
    updateItem9Questions(data);

    //--------------------------------------------------------------------------------
    // Item 10
    //--------------------------------------------------------------------------------
    updateItem10Questions(data);

    //--------------------------------------------------------------------------------
    // Item 11
    //--------------------------------------------------------------------------------
    updateItem11Questions(data);
}
var initializeWellbeingQuestions = function (data) {

    if (data.length == 0) {

        return;
    }
    //--------------------------------------------------------------------------------
    // Item 12A
    //--------------------------------------------------------------------------------
    updateItem12AQuestions(data);

    //--------------------------------------------------------------------------------
    // Item 12B
    //--------------------------------------------------------------------------------
    updateItem12BQuestions(data);

    //--------------------------------------------------------------------------------
    // Item 12C
    //--------------------------------------------------------------------------------
    updateItem12CQuestions(data);

    //--------------------------------------------------------------------------------
    // Item 13
    //--------------------------------------------------------------------------------
    updateItem13Questions(data);

    //--------------------------------------------------------------------------------
    // Item 14
    //--------------------------------------------------------------------------------
    updateItem14Questions(data);

    //--------------------------------------------------------------------------------
    // Item 15
    //--------------------------------------------------------------------------------
    updateItem15Questions(data);

    //--------------------------------------------------------------------------------
    // Item 16
    //--------------------------------------------------------------------------------
    updateItem16Questions(data);

    //--------------------------------------------------------------------------------
    // Item 17
    //--------------------------------------------------------------------------------
    updateItem17Questions(data);

    //--------------------------------------------------------------------------------
    // Item 18
    //--------------------------------------------------------------------------------
    updateItem18Questions(data);
}
var getCollectionObject = function (parms) {

    var caseReviewStore = chainedStore('CaseReviewStore').getAt(0).data;
    var result;

    if (Ext.isEmpty(parms)) {

        return result;
    }

    switch (parms.collectionName) {

        case 'facesheet':
            return caseReviewStore.CR_FaceSheet_Collection[0];

        case 'safety':
            return caseReviewStore.CR_Safety_Collection[0];

        case 'permanency':
            return caseReviewStore.CR_Permanency_Collection[0];

        case 'wellbeing':
            return caseReviewStore.CR_WellBeing_Collection[0];

        case 'caseNote':

            var filteredColl = caseReviewStore.CR_CaseNote_Collection.filter(function (note) {

                return note.Subject == parms.subject &&
                       note.Description == parms.description;
            });

            if (filteredColl.length > 0) {

                result = filteredColl[0];
            }

            break;

        case 'outcome':

            var filteredColl = caseReviewStore.CR_Outcome_Collection.filter(function (outcome) {

                return outcome.OutcomeCode == parms.outcomeCode;
            });

            if (filteredColl.length > 0) {

                result = filteredColl[0];
            }

            break;

        case 'item':
            return getItemFromGraph(parms.itemCode, getOutcomeCode(parms.itemCode));

        case 'itemNote':

            var item = getItemFromGraph(parms.itemCode, getOutcomeCode(parms.itemCode));

            var filteredColl = item.CR_Note_Collection.filter(function (note) {

                return note.Subject == parms.subject &&
                       note.Description == parms.description;
            });

            if (filteredColl.length > 0) {

                result = filteredColl[0];
            }

            break;

        case 'multianswer':

            result = caseReviewStore.CR_MultiAnswer_Collection.filter(function (answer) {

                return answer.CodeDescriptionID == parms.codeDescriptionId;
            });

            break;

        default:

            break;
    }

    return result;
}
var getSavedPropertyValue = function (parms) {

    var result;

    if (Ext.isEmpty(parms)) {

        return result;
    }

    var collectionObj = getCollectionObject(parms);

    result = collectionObj[parms.propertyName];

    return result;
}
var getSavedMultiAnswerResponse = function (parms) {

    var result;

    if (Ext.isEmpty(parms)) {

        return result;
    }

    var collectionObj = getCollectionObject(parms);

    if (collectionObj.length > 0) {

        result = collectionObj[0].AnswerCode;
    }

    return result;
}
var isDataChangedByUser = function (control, newValue, savedData) {

    var result = false;
    var bindValue;

    if (Ext.isEmpty(control)) {

        return result;
    }

    if (Ext.isEmpty(control.bind) && !Ext.isEmpty(newValue)) {

        return true;
    }

    if (!Ext.isEmpty(control.bind)) {

        if (!Ext.isEmpty(control.bind.value)) {

            if (Ext.isEmpty(control.bind.value.lastValue) && Ext.isEmpty(savedData) && !Ext.isEmpty(newValue)) {

                return true;
            }

            if (Ext.isEmpty(savedData) && Ext.isEmpty(control.bind.value.lastValue)) {

                return result;
            }

            bindValue = Ext.isEmpty(control.bind.value.lastValue) ? undefined : control.bind.value.lastValue.valueOf();
        }
    }

    var savedValue = Ext.isEmpty(savedData) ? undefined : savedData.valueOf();
    var updatedVal = Ext.isEmpty(newValue) ? undefined : newValue.valueOf();

    if (Ext.isEmpty(savedValue) && Ext.isEmpty(updatedVal)) {

        return false;
    }

    if (!(savedValue == updatedVal)) {

        result = true;
    }

    if (Ext.isEmpty(bindValue) && !Ext.isEmpty(updatedVal)) {

        return true;
    }

    if (!(bindValue == updatedVal)) {

        return true;
    }

    return result;
}
var isNumberChangedByUser = function (parms) {

    if (Ext.isEmpty(parms.newValue) || Ext.isEmpty(parms.savedValue) || Ext.isEmpty(parms.oldValue)) {

        return false;
    }

    if (parms.newValue == parms.oldValue) {

        return false;
    }

    return true;
}
var resetRadioButton = function (radio) {

    if (Ext.isEmpty(radio.ownerCt)) {

        return;
    }

    if (!radio.checked) {

        return;
    }

    Ext.each(radio.ownerCt.items.items, function (item) {

        if (item.xtype == 'radio') {

            if (!(item.itemId == radio.itemId)) {

                item.setValue(false);
            }
        }
    });
}
var isSelectionValid = function (parms) {

    var result = false;

    if (Ext.isEmpty(parms)) {

        return result;
    }

    if (Ext.isEmpty(parms.value)) {

        return result;
    }

    if (Ext.isArray(parms.validValues)) {

        var filteredValues = parms.validValues.filter(function (value) {

            return value == parms.value;
        });

        if (filteredValues.length > 0) {

            result = true;
        }

        return result;
    }

    if (parms.dataType == 'date') {

        return Ext.isDate(parms.value);
    }

    if (parms.dataType == 'number') {

        return Ext.isNumber(parms.value);
    }

    if (parms.dataType == 'boolean') {

        return Ext.isBoolean(parms.value);
    }

    return result;
}
var checkIfChangedByUser = function (value) {

    if (Ext.isEmpty(value)) {

        return false;
    }

    var oldKeys = getObjectKeys(value);

    if (oldKeys.length > 0) {

        return true;
    }

    return false;
}
var checkIfMultiAnswerChangedByUser = function (parms) {

    var result = {};

    if (Ext.isEmpty(parms)) {

        return result;
    }

    var selectedItem = getLastRadioSelection(parms.newValue, parms.oldValue);

    result['selectedItem'] = selectedItem;

    var selection = getRadioSelections2(parms.control, selectedItem, parms.groupName);
    var selectedValue = selection.fields[0].AnswerCode;
    var oldKeys = getObjectKeys(parms.oldValue);
    var oldValue = Ext.isEmpty(parms.oldValue) ? null : parms.oldValue[oldKeys[0]];

    var dataParms = {};

    dataParms['collectionName'] = 'multianswer';
    dataParms['codeDescriptionId'] = selection.fields[0].CodeDescriptionID;

    var savedValue = getSavedMultiAnswerResponse(dataParms);

    if (selectedValue == savedValue && oldKeys.length == 0) {

        result['isUserAction'] = false;

        return result;
    }

    if (selectedValue == savedValue && selectedValue == oldValue) {

        result['isUserAction'] = false;

        return result;
    }

    result['isUserAction'] = true;

    return result;
}
var isChangedByUser = function (parms) {

    var result = {};

    if (Ext.isEmpty(parms)) {

        return result;
    }

    var savedValue = getSavedPropertyValue(parms);
    var selection = (parms.newValue) ? parms.control.inputValue : 0;

    if (selection == savedValue && parms.oldValue == 0 && !parms.isPageRendered) {

        result['isUserAction'] = false;

        return result;
    }

    result['isUserAction'] = true;

    return result;
}
var resetItem5StoreValues = function () {

    // Reset store values
    var fields = [];
    var vmFields = [];
    var field;
    var vmField
    var parms = {};

    field = { 'wereAllGoalsInTimelyManner': null };
    fields.push(field);

    field = { 'wereAllGoalsAppropriate': null };
    fields.push(field);

    field = { 'IsInFoster15OutOf22': null };
    fields.push(field);

    field = { 'meetsTerminationOfParentalRights': null };
    fields.push(field);

    field = { 'IsAgencyJointTerminationOfParentalRights': null };
    fields.push(field);

    field = { 'IsExceptionForTermination': null };
    fields.push(field);

    parms['fields'] = fields;

    vmField = { 'wereAllGoalsInTimelyManner': null };
    vmField = { 'wereAllGoalsAppropriate': null };
    vmField = { 'isInFoster15OutOf22': null };
    vmField = { 'meetsTerminationOfParentalRights': null };
    vmField = { 'isAgencyJointTerminationOfParentalRights': null };
    vmField = { 'isExceptionForTermination': null };

    parms['vmFields'] = vmFields;

    parms['storeId'] = 'CR_Permanency_CollectionStore';

    saveChanges(parms);
}
var resetItem7StoreValues = function () {

    // Reset store values
    var fields = [];
    var vmFields = [];
    var field;
    var vmField
    var parms = {};

    field = { 'IsPlacedWithAllSiblings': null };
    fields.push(field);

    field = { 'IsValidReasonForSeparation': null };
    fields.push(field);

    parms['fields'] = fields;

    vmField = { 'isPlacedWithAllSiblings': null };
    vmField = { 'isValidReasonForSeparation': null };

    parms['vmFields'] = vmFields;

    parms['storeId'] = 'CR_Permanency_CollectionStore';

    saveChanges(parms);
}
var resetItem8StoreValues = function () {

    // Reset store values
    var fields = [];
    var vmFields = [];
    var field;
    var vmField
    var parms = {};

    field = { 'MotherVisitationFrequencyCode': null };
    fields.push(field);

    field = { 'IsSufficientFrequencyForMotherVisitation': null };
    fields.push(field);

    field = { 'IsSufficientQualityForMotherVisitation': null };
    fields.push(field);

    field = { 'FatherVisitationFrequencyCode': null };
    fields.push(field);

    field = { 'IsSufficientFrequencyForFatherVisitation': null };
    fields.push(field);

    field = { 'IsSufficentQualityForFatherVisitation': null };
    fields.push(field);

    field = { 'SiblingVisitationFrequencyCode': null };
    fields.push(field);

    field = { 'IsSufficientFrequencyForSiblingVisitation': null };
    fields.push(field);

    field = { 'IsSufficentQualityForSiblingVisitation': null };
    fields.push(field);

    parms['fields'] = fields;

    vmField = { 'isSufficientFrequencyForMotherVisitation': null };
    vmField = { 'isSufficientQualityForMotherVisitation': null };
    vmField = { 'fatherVisitationFrequencyCode': null };
    vmField = { 'motherVisitationFrequencyCode': null };
    vmField = { 'isSufficientFrequencyForFatherVisitation': null };
    vmField = { 'isSufficentQualityForFatherVisitation': null };
    vmField = { 'siblingVisitationFrequencyCode': null };
    vmField = { 'isSufficientFrequencyForSiblingVisitation': null };
    vmField = { 'isSufficentQualityForSiblingVisitation': null };

    parms['vmFields'] = vmFields;

    parms['storeId'] = 'CR_Permanency_CollectionStore';

    saveChanges(parms);
}
var resetItem9StoreValues = function () {

    // Reset store values
    var fields = [];
    var vmFields = [];
    var field;
    var vmField
    var parms = {};

    field = { 'IsConcertedEffortsForImportantConnections': null };
    fields.push(field);

    field = { 'IsSufficientInquiryForIndianTribe': null };
    fields.push(field);

    field = { 'IsTribeProvidedTimelyNotification': null };
    fields.push(field);

    field = { 'IsAccordanceWithIndianChildWelfareAct': null };
    fields.push(field);

    parms['fields'] = fields;

    vmField = { 'isConcertedEffortsForImportantConnections': null };
    vmField = { 'isSufficientInquiryForIndianTribe': null };
    vmField = { 'isTribeProvidedTimelyNotification': null };
    vmField = { 'isAccordanceWithIndianChildWelfareAct': null };

    parms['vmFields'] = vmFields;

    parms['storeId'] = 'CR_Permanency_CollectionStore';

    saveChanges(parms);
}
var resetItem10StoreValues = function () {

    // Reset store values
    var fields = [];
    var vmFields = [];
    var field;
    var vmField
    var parms = {};

    field = { 'IsRecentPlacementWithRelative': null };
    fields.push(field);

    field = { 'IsPlacementWithRelativeStable': null };
    fields.push(field);

    field = { 'IsConcertedEffortToLocateMaternalRelatives': null };
    fields.push(field);

    field = { 'IsConcertedEffortToLocatePaternalRelatives': null };
    fields.push(field);

    parms['fields'] = fields;

    vmField = { 'isRecentPlacementWithRelative': null };
    vmField = { 'isPlacementWithRelativeStable': null };
    vmField = { 'isConcertedEffortToLocateMaternalRelatives': null };
    vmField = { 'isConcertedEffortToLocatePaternalRelatives': null };

    parms['vmFields'] = vmFields;

    parms['storeId'] = 'CR_Permanency_CollectionStore';

    saveChanges(parms);
}
var resetItem11StoreValues = function () {

    // Reset store values
    var fields = [];
    var vmFields = [];
    var field;
    var vmField
    var parms = {};

    field = { 'IsConcertedEffortMotherFosterRelationship': null };
    fields.push(field);

    field = { 'IsConcertedEffortFatherFosterRelationship': null };
    fields.push(field);

    parms['fields'] = fields;

    vmField = { 'isConcertedEffortMotherFosterRelationship': null };
    vmField = { 'isConcertedEffortFatherFosterRelationship': null };

    parms['vmFields'] = vmFields;

    parms['storeId'] = 'CR_Permanency_CollectionStore';

    saveChanges(parms);
}
var resetItem12BStoreValues = function () {

    // Reset store values
    var fields = [];
    var vmFields = [];
    var field;
    var vmField
    var parms = {};

    field = { 'IsComprehensiveAssessementForMotherConducted': 0 };
    fields.push(field);

    field = { 'IsAppropriateServicesForMotherProvided': 0 };
    fields.push(field);

    field = { 'IsComprehensiveAssessementForFatherConducted': 0 };
    fields.push(field);

    field = { 'IsAppropriateServicesForFatherProvided': 0 };
    fields.push(field);

    parms['fields'] = fields;

    vmField = { 'isComprehensiveAssessementForMotherConducted': 0 };
    vmField = { 'isAppropriateServicesForMotherProvided': 0 };
    vmField = { 'isComprehensiveAssessementForFatherConducted': 0 };
    vmField = { 'isAppropriateServicesForFatherProvided': 0 };

    parms['vmFields'] = vmFields;

    parms['storeId'] = 'CR_WellBeing_CollectionStore';

    saveChanges(parms);
}
var initializeResultsContainer = function () {

    saveRequestResults = [];
}
var processItem2PreAppResponse = function (parms) {

    var selectedItem = getLastRadioSelection(parms.newValue, parms.oldValue);
    var newKeys = getObjectKeys(selectedItem);

    if (newKeys.length > 0) {

        deselectPrevChoices(parms.radio);

        processItem2PreApplicability(parms.radio, parms.newValue, parms.oldValue);
    }
}
var isRadioChangedByUser = function (parms) {

    var result = true;
    var checkResult = [];

    if (Ext.isEmpty(parms)) {

        return false;
    }

    Ext.each(parms.controls, function (control) {

        checkResult.push(control.checked);

        if (!control.checked) {

            result = false;
        }
    });

    return result;
}
var getStorePropertyValue = function (parms) {

    var result;
    var filteredStore = Ext.data.StoreManager.get(parms.storeId);

    if (filteredStore.data.length > 0) {

        result = filteredStore.getAt(0).data[parms.propertyName]
    }

    return result;
}
var setStorePropertyValue = function (parms) {

    var filteredStore = Ext.data.StoreManager.get(parms.storeId);

    if (filteredStore.data.length == 0) {

        return false;
    }

    filteredStore.getAt(0).data[parms.propertyName] = parms.propertyValue;

    return true;
}
var getApplicationViewModel = function () {

    var result = Ext.ComponentQuery.query('#reviewHeader')[0].getViewModel();

    return result;
}
var setApplicationViewModel = function (vModel) {

    var header = Ext.ComponentQuery.query('#reviewHeader')[0];

    header.setViewModel(vModel);
}
var initValidationMessages = function () {
    //
    // Reset all messages for items in the following statuses:
    // (1) Not Started
    // (2) Not Applicable or NA
    //
    var itemStatusColl = [];
    var keys = Object.keys(itemRatings);
    var itemProps, item, validationMessages, itemName;
    var filteredMessages = [];
    var msgCnt = 0;

    if (!(itemStatuses['facesheet'] == 'Completed')) {

        itemStatusColl.push('facesheet');
    }

    Ext.each(keys, function (key) {

        if (itemRatings[key] == 'Not Yet Rated' || itemRatings[key] == 'Not Applicable' || itemRatings[key] == 'NA') {

            itemName = 'item' + key.replace('Item', '').replace('Rating', '');

            itemStatusColl.push(itemName);
        }
    });

    if (itemStatusColl.length == 0) {

        return;
    }
    //
    // Get all validation messages for all items
    //
    validationMessages = Ext.ComponentQuery.query('validationMessage[hasMessages=true]');

    //
    // Filter validation messages
    //
    Ext.each(validationMessages, function (vMessage) {

        msgCnt = 0;

        Ext.each(itemStatusColl, function (itemName) {

            if (vMessage.itemName == itemName) {

                if (!(itemName == 'facesheet')) {

                    if (msgCnt == 0) {

                        filteredMessages.push(vMessage);
                    }

                    msgCnt++;
                }
            }
        });
    });

    Ext.each(filteredMessages, function (validationMsg) {

        validationMsg.initMessages();
    });
}
var disableTabs = function () {

    var tabIds = ['faceSheet', 'safety', 'permanency', 'wellBeing'];
    var tab;

    Ext.each(tabIds, function (tabId) {

        tab = getCRSComponent(tabId);

        if (!tab.disabled) {

            tab.setDisabled(true);
        }
    });
}
var executeQARequest = function (parms) {

    var action = CaseReviewRoles.getAction(parms);
    
    var result = CaseReviewRoles.executeAction(action);

    if (!(result.ActionAllowed && result.Message == 'Success')) {

        Ext.Msg.alert(result.MessageType, result.Message);
    }

    return result;
}
var dedupeStringArray = function (arr) {

    var result = [];
    var filteredResult;

    Ext.each(arr, function (str) {

        if (result.length == 0) {

            result.push(str);
        } else {

            filteredResult = result.filter(function (arrItem) {

                return arrItem == str;
            });

            if (filteredResult.length == 0) {

                result.push(str);
            }
        }
    });

    return result;
}
var getReviewPeriod = function () {

    var parms = {};

    parms['storeId'] = 'CaseReviewStore';
    parms['propertyName'] = 'ReviewStartDate';

    var revStartDate = new Date(getStorePropertyValue(parms));

    parms['storeId'] = 'CaseReviewStore';
    parms['propertyName'] = 'ReviewCompleted';

    var revEndDate = new Date(getStorePropertyValue(parms));

    return Ext.Date.format(revStartDate, 'm/d/Y') + ' - ' + Ext.Date.format(revEndDate, 'm/d/Y');
}
var getSiteName = function (siteCode) {

    var result;

    var store = Ext.StoreManager.get('SiteStore');

    var filteredItem = store.data.items.filter(function (item) {

        return item.data.GroupID == siteCode;
    });

    if (filteredItem.length > 0) {

        result = filteredItem[0].data.DescriptionLarge;
    }

    return result;
}
var getQAReviewerName = function (reviewerId) {

    var result;

    var store = Ext.StoreManager.get('CaseReviewQAStore');

    var filteredItem = store.data.items.filter(function (item) {

        return item.data.UserID == reviewerId;
    });

    if (filteredItem.length > 0) {

        result = filteredItem[0].data.FirstName + ' ' + filteredItem[0].data.LastName;
    }

    return result;
}
var getSecondaryOversightName = function (reviewerId) {

    var result;

    var store = Ext.StoreManager.get('CaseReviewSecondaryOversightStore');

    var filteredItem = store.data.items.filter(function (item) {

        return item.data.UserID == reviewerId;
    });

    if (filteredItem.length > 0) {

        result = filteredItem[0].data.FirstName + ' ' + filteredItem[0].data.LastName;
    }

    return result;
}
var setComponentValue = function (comp, value) {

    if (Ext.isEmpty(comp)) {

        return comp;
    }

    comp.suspendEvent();

    comp.setValue(value);

    comp.resumeEvents();

    return comp;
}
var getContainerPosition = function (parms) {

    if (Ext.isEmpty(parms.tabPanelId) && Ext.isEmpty(parms.itemId)) {

        return;
    }

    var parentPanel = getAppController().getOverviewTab().up('#' + parms.parentPanelId);

    var tabPanel = parentPanel.down('#' + parms.tabPanelId);
    var scrollAmt = tabPanel.down('#' + parms.itemId).getY() - offset;

    var scroller = tabPanel.getScrollable();
    scroller.scrollBy(0, scrollAmt, true);
}
var clearBrowserHistory = function () {

    var historyLen = history.length;

    if (historyLen > 0) {

        history.go(historyLen * -1);
    }
}
var isApplicableValue = function (value) {

    var valueType = typeof (value);

    if (valueType == 'boolean' || valueType == 'object') {

        return false;
    }

    if (value > 0 && value < 3) {

        return true;
    }

    return false;
}
var concatJsonObjects = function (startObj, objArray) {

    if (!Ext.isArray(objArray)) {

        return startObj;
    }

    var props;

    Ext.each(objArray, function (obj) {

        props = Object.keys(obj);

        Ext.each(props, function (prop) {

            startObj[prop] = obj[prop];
        });
    });

    return startObj;
}
var recalculateItemStatus = function (parms) {

    parms.questions[0].errorsExist = true;

    var itemStatus = determineItemStatus(parms.itemName);

    itemStatuses[parms.itemName] = itemStatus;
    //
    // Set error message
    //    
    if (!Ext.isEmpty(parms.msgComponent)) {

        var questionVal = {};
        questionVal[parms.itemName] = parms.message;

        parms.msgComponent.setValidationResult(questionVal);
        parms.msgComponent.setMsgType('Error');
        parms.msgComponent.updateMessages();
    }
}
var handleRadioGroupItemChange = function (parmsIn) {

    if (parmsIn.contol.checked) {

        parmsIn.componentToEnable.enable();
    }

    if (pageLoadStatus['Permanency'] == 'rendered') {

        var fields = [],
            field = {
                CodeDescriptionID: parmsIn.control.inputValue,
                AnswerCode: 1,
                KeyField: 'CodeDescriptionID',
                GroupName: parmsIn.groupName
            };

        if (parmsIn.newValue) {

            fields.push(field);

            var parms = {
                currentVal: newValue,
                storeId: parmsIn.storeId,
                fields: fields,
                fieldType: parmsIn.fieldType,
                control: parmsIn.control,
                runValidations: parmsIn.runValidations,
                dataChanged: parmsIn.dataChanged
            };

        } else {

            field.AnswerCode = 0;

            fields.push(field);

            var parms = {
                currentVal: newValue,
                storeId: parmsIn.storeId,
                fields: fields,
                fieldType: parmsIn.fieldType,
                control: parmsIn.control,
                runValidations: parmsIn.runValidations,
                dataChanged: parmsIn.dataChanged
            };
        }

        parms = getStatusParms(parms, parmsIn.ratingItemId);

        initValidations(parmsIn.itemName);

        runPermanencyRules(getAppController(), parmsIn.methodName, parms);
    }
}
var setModelData = function () {

    var store = Ext.StoreManager.get('CaseReviewStore').getAt(0).data,
        model = Ext.create('app.CaseReview.model.CaseReview'),
        props = Object.keys(model.data);

    Ext.each(props, function (prop) {

        model.set(prop, store[prop]);
    });

    getApplicationViewModel().set('modelData', model);
}
var setModelStore = function () {

    var store = Ext.StoreManager.get('CaseReviewStore');

}
var getActivePage = function () {

    var result;

    switch (window.currentTab) {

        case 'caseOverview':

            result = getAppController().getOverviewTab();

            break;

        case 'faceSheet':

            result = getAppController().getFacesheetTab();

            break;

        case 'safety':

            result = getAppController().getSafetyTab();

            break;

        case 'permanency':

            result = getAppController().getPermanencyTab();

            break;

        case 'wellBeing':

            result = getAppController().getWellbeingTab();

            break;

        default:
            break;

    }

    return result;
}
var isSafetyCompleted = function () {

    var itemNames = ['item1', 'item2', 'item3'],
        result = true;

    Ext.each(itemNames, function (itemName) {

        if (!(itemStatuses[itemName] == 'Completed')) {

            result = false;

            return false;
        }
    });

    return result;
}
var isPermanencyCompleted = function () {

    var itemNames = ['item4', 'item5', 'item6','item7','item8','item9','item10','item11'],
        result = true;

    Ext.each(itemNames, function (itemName) {

        if (!(itemStatuses[itemName] == 'Completed')) {

            result = false;

            return false;
        }
    });

    return result;
}
var isWellbeingCompleted = function () {

    var itemNames = ['item12', 'item12A', 'item12B', 'item12C', 'item13', 'item14', 'item15', 'item16','item17','item18'],
        result = true;

    Ext.each(itemNames, function (itemName) {

        if (!(itemStatuses[itemName] == 'Completed')) {

            result = false;

            return false;
        }
    });

    return result;
}
var isCurrentPageCompleted = function (step) {

    var result = false;

    switch (step.name) {

        case 'facesheet':

            result = isFacesheetComplete();
            break;

        case 'safety':

            result = isSafetyCompleted();
            break;

        case 'permanency':

            result = isPermanencyCompleted();
            break;

        case 'wellbeing':

            result = isWellbeingCompleted();
            break;

        default:

            break;
    }

    return result;
}
var getCaseStatus = function () {

    var store = Ext.StoreManager.get('CaseReviewStore'),
        statusCode = store.getAt(0).data.CaseStatusCode;

    var status = statusCode == 1 ? 'Completed' :
                 statusCode == 2 ? 'In Progress' :
                 statusCode == 3 ? 'Not Started' :
                 statusCode == 4 ? 'Not Applicable' : 'Invalid Status';
    
    return status;
}
var navigateToNextStep = function (action, stepName) {

    var currentTab = CaseReviewWorkFlow.tabPanel.getActiveTab(),
        currentStepName = Ext.isEmpty(stepName) ? currentTab.itemId.toLowerCase() : stepName,
        step = CaseReviewWorkFlow.getCurrentStep(currentStepName, action),
        caseStatus = getCaseStatus();
    
    CaseReviewWorkFlow.visitNextStep(step, caseStatus, action);
}
var isNewCase = function () {

    var caseStatus = getCaseStatus();

    if (caseStatus == 'Not Started') {
        return true;
    }

    return false;
}
var updateLocation = function (tabId) {

    var newUrl = window.location.origin + window.location.pathname + '?activetab=' + tabId;

    window.location.assign(newUrl);
}
var getReviewModelStore = function () {

    var modelFlds = Ext.create('app.CaseReview.model.CaseReview').fields,
        store = Ext.StoreManager.get('CaseReviewStore');
    //
    // Create chainedstore only with the fields present in modelFlds
    //
    if (Ext.isEmpty(store)) {

        return 'CaseReviewStore';
    }

    var chainedStore = new Ext.data.ChainedStore({
        source: store,
        filters: [
            function (item) {

                Ext.each(modelFlds, function (field) {
                    
                    if (item.data.hasOwnProperty(field.name)) {

                    }
                });
            }
        ]
    });
}
var getRadioGroupSelection = function (parmsIn) {

    var filteredRadio = parmsIn.radioGroup.items.items.filter(function (radio) {

            return radio.checked == true;
        }),
        oldKeys = Object.keys(parmsIn.oldValue),
        prevSelection = parmsIn.radioGroup.items.items.filter(function (radio) {

            return radio.inputValue == parmsIn.oldValue[oldKeys[0]];
        });

    if (filteredRadio.length == 0) {
        return;
    }

    var parms = {
        control: filteredRadio[0],
        newValue: filteredRadio[0].inputValue,
        oldValue: oldKeys.length == 0 ? null : parmsIn.oldValue[oldKeys[0]],
        oldSelection: prevSelection
    };

    return parms;
}
var isEmptyOrFalse = function (obj) {

    if (Ext.isEmpty(obj)) {
        return true;
    }

    if (Ext.isObject(obj)) {
        var keys = Object.keys(obj);

        if (keys.length == 0) {
            return true;
        }
    }

    if (Ext.isBoolean(obj)) {
        return (obj) ? false : true;
    }

    return false;
}
var enableButtons = function (buttons) {
    var result = false;

    Ext.each(buttons, function (btn) {

        if (btn.disabled) {
            btn.enable();
            result = true;
        }        
    });

    return result;
}
var disableButtons = function (buttons) {
    var result = true;

    Ext.each(buttons, function (btn) {

        if (!btn.disabled) {
            btn.disable();
            result = false;
        }        
    });

    return result;
}
var getSaveButtons = function () {

    var result = {};

    switch (window.currentTab) {

        case 'faceSheet':

            result['pageFunction'] = FacesheetFunctions;
            result['saveButtons'] = getCRSComponent('facesheetTab').query('savebuttons')[0].query('button');
            break;

        case 'safety':

            result['pageFunction'] = SafetyFunctions;
            result['saveButtons'] = getCRSComponent('safetyTab').query('savebuttons')[0].query('button');
            break;

        case 'permanency':

            result['pageFunction'] = PermanencyFunctions;
            result['saveButtons'] = getCRSComponent('permanencyTab').query('savebuttons')[0].query('button');
            break;

        case 'wellbeing':

            result['pageFunction'] = WellbeingFunctions;
            result['saveButtons'] = getCRSComponent('wellbeingTab').query('savebuttons')[0].query('button');
            break;

        default:
            break;
    }

    return result;
}
var hideRatingOverride = function (containerId) {

    var user = GetLoggedInUser();

    if (user.isFederalTeamMember() || user.isStateAdministrator()) {
        return;
    }

    var ovrComponents = getCRSComponent(containerId).query('ratingOverride');

    Ext.each(ovrComponents, function (ratingCmp) {
        ratingCmp.hide();
    });
}
var showRatingOverride = function (containerId) {

    var ovrComponents = getCRSComponent(containerId).query('ratingOverride');

    Ext.each(ovrComponents, function (ratingCmp) {
        ratingCmp.show();
    });
}

try {

    Ext.define('App.CaseReview.controller.Main', {
        extend: framework.controller.ViewModelController.$className,
        id: 'CaseReview',
        routes: {
            ':tab': 'onTabChange'
        },
        onTabChange: function (tab) {

            var newUrl;

            if (Ext.isEmpty(window.currentTab)) {

                newUrl = window.baseUrl + "/CaseReview/Index/" + window.caseReviewRootId;
            } else {

                newUrl = window.baseUrl + "/CaseReview/Index/" + window.caseReviewRootId + "?activetab=" + window.currentTab;
            }

            history.replaceState({}, document.title, newUrl);
        },
        init: function () {
            //"use strict";
            var self = this;
            var sr = App.Common.StringResources;
            var crc = App.CaseReview.Controller.CaseReviewCalculations;

            this.callParent([{
                // Class that represents the top level Model
                topStore: App.CaseReview.store.CaseReviewTop.$className,
                params: { caseReviewRootId: 0, caseReviewId: 0, userID: 0 },
                // function that handles passing the data to save back to the server

                saveFunction: function () {
                    // Data corresponds to DataController on the server.
                    // SaveData is the Action on the controller
                    // mainData is the name of the parameter on SaveData in the controller
                    // MAINDATAStore is our top level store that we are sending back
                    // getAt(0) retrieves what should be the only record in our top level store.
                    // getData(true) retrieves the JSON representation of the graph from MAINDATA on down.
                    // self.saveCallback is in the parent class and handles any errors 
                    // and reloads the data from the server once the save has completed

                    updateDatabase(self, userID);
                },
                // The view class this controller will create
                view: App.CaseReview.view.Main.$className,
            }]);

            var deleteData = function () {
                window.Data.DeleteData(
                   {
                       caseReviewRootID: caseReviewRootId
                   }, afterDeleteCallback);
            };

            var afterDeleteCallback = function () {

                alert("Case Review Deleted");
                Ext.dom.Element.get(window).clearListeners();
                window.location = window.baseUrl;
            };

            // The viewModel lives in parent class ViewModelController
            // between ViewModelControl and the viewModel object all changes
            // to the data in the view get reflected back into the viewModel
            // and any changes you need to make to the view should be made via
            // viewModel.  This enables the classes in the system to be
            // tested without needing a view in place.
            // You should put as little code as possible in the controller for
            // your app because the controller has a dependency on the view.
            // Instead you should create separate classes that have a dependancy
            // on the viewModel only and that dependancy should be passed in.
            // 
            // NONE OF _YOUR_ CODE SHOULD TALK TO THE VIEW DIRECTLY!
            //
            // To set a value/get a value
            //   self.viewModel.setValue('TableCollection.Field', 'NewValue');
            //     for example: 
            //         self.viewModel.setValue('MAINDATA.FIRSTNAME', 'Dave');
            //   self.viewModel.getValue('TableCollection.Field');
            //
            // To disable/enable an element
            //   self.viewModel.disable('itemIdGoesHere');
            //   self.viewModel.enable('itemIdGoesHere');
            //     If you enable an element, the children
            //     will automatically be enabled.
            //
            // To determine if an element is enabled/disabled
            //   self.viewModel.isEnabled('itemIdGoesHere');
            //   self.viewModel.isDisabled('itemIdGoesHere');
            //
            // To see if an element is valid
            //   self.viewModel.isValid('itemIdOfElementGoesHere');
            //
            // To find the errors registered by the view
            //   self.viewModel.getValidationErrors()
            //     returns an array of errors generated by the view.
            //
            // If you need to know if something has happened on the view,
            // it is probably reflected in the viewModel.  There are event
            // handlers that you can use to get notifications of changes
            // to the viewModel:
            //   To listen for changes to a value use
            //     viewModel.on('setValue', onSetValue);
            //       onSetValue is a function pointer that takes
            //         name: (MAINDATA.FIRSTNAME for example)
            //         value: the new value
            //   To listen changes when a store is cleared
            //     viewModel.on('clearStore', onClearStore);
            //       onClearStore(storeId)
            //         NOTE: it would probably be easier to
            //               add a listener to the store directly
            //               rather than use this listener
            //   To listen to changes when all of the elements
            //   on the screen are enabled
            //     viewModel.on('enableAll', onEnableAll);
            //       onEnableAll takes no parameters
            //   To listen for when an element is disabled
            //     viewModel.on('disabled', onDisabled);
            //       onDisabled(itemId)
            //   To listen for when an element is enabled
            //     viewModel.on('enabled', onEnabled);
            //       onEnabled(itemId);
            //   To listen for when an element is hidden
            //     viewModel.on('hide', onHide);
            //       onHide(itemId);
            //   To listen for when an element is made visible
            //     viewModel.on('show', onShow);
            //       onShow(itemId)

            self.viewModel.on('click', function (itemId) {
                
                if (itemId === "saveCaseButton") {

                    saveItemId = itemId;

                    silentSave = false;

                    initializeResultsContainer();

                    self.saveData();

                    var saveButs = getSaveButtons();
                    saveButs.pageFunction.saveEnabled = disableButtons(saveButs.saveButtons);
                    
                    return;
                }

                if (itemId === "saveCaseContinueButton") {

                    saveItemId = itemId;

                    silentSave = false;

                    initializeResultsContainer();

                    self.saveData();

                    var saveButs = getSaveButtons();
                    saveButs.pageFunction.saveEnabled = disableButtons(saveButs.saveButtons);

                    return;
                }

                if (itemId == "deleteCaseReview") {

                    deleteData();

                    return;
                }

                var parms, result;

                switch (itemId) {

                    case 'submitToQA':

                        saveItemId = itemId;

                        silentSave = false;

                        parms = ['submitToQA'];

                        result = executeQARequest(parms);

                        break;

                    case 'returnToQA':

                        saveItemId = itemId;

                        silentSave = false;

                        parms = ['returnCaseToQA'];

                        result = executeQARequest(parms);

                        reloadNeeded = true;

                        break;

                    case 'returnToReviewer':

                        saveItemId = itemId;

                        silentSave = false;

                        parms = ['returnCaseToReviewer'];

                        result = executeQARequest(parms);

                        break;

                    case 'submitToFinalize':

                        saveItemId = itemId;

                        silentSave = false;

                        parms = ['finalizeCase'];

                        result = executeQARequest(parms);

                        break;

                    case 'finalizeAndApprove':

                        saveItemId = itemId;

                        silentSave = false;

                        parms = ['approveFinalize'];

                        result = executeQARequest(parms);

                        break;

                    default:

                        break;
                }
            });

            self.control(
            {
                '#AppForm': {
                    'beforerender': function () {

                        Ext.suspendLayouts();
                        this.suspendEvents();

                        setAppPages();

                        initializeParticipantIds();

                        getSavedItemRatings();
                        getSavedStatuses();
                        getSavedOutcomeRatings();
                        //// 
                        //// Create common viewModel
                        ////
                        //createViewModel('caseReview');
                    },
                    'afterrender': function () {
                        var postRender = Ext.create('App.CaseReview.controller.PostRender', self);

                        //
                        // Takes too long -- 4.5 seconds. Need to refactor!!
                        //
                        if (!Ext.isEmpty(activeTab)) {

                            var currentTab = this.getCenterTabPanel().setActiveTab(activeTab);
                            window.currentTab = activeTab;
                        }

                        appDataState = 'rendered';

                        initializeQuestionsAnswered();

                        updateTabAccessibility();

                        Ext.resumeLayouts(true);
                        this.resumeEvents(true);

                        updateCaseStatus();

                        //
                        // Disable all tabs if case is eliminated
                        //

                        if (getSavedCaseStatus().indexOf('Case Eliminated') > -1) {

                            disableTabs();

                        } else {

                            var overrideValidationMsgs = overrideValidationMessages == 'true' ? true : false;

                            if (overrideValidationMsgs) {

                                initValidationMessages();
                            }
                        }
                    }
                },
                '#reviewBeginDate': {
                    'select': function (cmp, newValue, oldValue) {

                        revStartDate = undefined;

                        if (!isNaN(Date.parse(newValue))) {

                            revStartDate = newValue;

                            var dateDiffToday = (new Date()).valueOf() - revStartDate.valueOf();

                            if (dateDiffToday < 0) {

                                Ext.Msg.show({
                                    title: 'Invalid Review Start Date',
                                    msg: 'Review Start Date cannot be in the future!!',
                                    buttons: Ext.MessageBox.OK,
                                    icon: Ext.MessageBox.ERROR
                                });

                                cmp.setValue('');

                                return;
                            }

                            if (!Ext.isEmpty(revCompleteDate)) {

                                var dateDiff = revCompleteDate.valueOf() - revStartDate.valueOf();

                                if (dateDiff < 0) {

                                    Ext.Msg.show({
                                        title: 'Invalid Review Start Date',
                                        msg: 'Review Start Date cannot be after the Review Completed Date!!',
                                        buttons: Ext.MessageBox.OK,
                                        icon: Ext.MessageBox.ERROR
                                    });

                                    cmp.setValue('');
                                }
                            }
                        }
                    },
                    'blur': function (cmp, event, eOpts) {

                        revStartDate = undefined;
                        var newValue = cmp.getValue();

                        if (!isNaN(Date.parse(newValue))) {

                            revStartDate = newValue;

                            var dateDiffToday = (new Date()).valueOf() - revStartDate.valueOf();

                            if (dateDiffToday < 0) {

                                Ext.Msg.show({
                                    title: 'Invalid Review Start Date',
                                    msg: 'Review Start Date cannot be in the future!!',
                                    buttons: Ext.MessageBox.OK,
                                    icon: Ext.MessageBox.ERROR
                                });

                                cmp.setValue('');

                                return;
                            }

                            if (!Ext.isEmpty(revCompleteDate)) {

                                var dateDiff = revCompleteDate.valueOf() - revStartDate.valueOf();

                                if (dateDiff < 0) {

                                    Ext.Msg.show({
                                        title: 'Invalid Review Start Date',
                                        msg: 'Review Start Date cannot be after the Review Completed Date!!',
                                        buttons: Ext.MessageBox.OK,
                                        icon: Ext.MessageBox.ERROR
                                    });

                                    cmp.setValue('');
                                }
                            }
                        }
                    }
                },
                '#reviewCompleted': {
                    'select': function (cmp, newValue, eOpts) {

                        revCompleteDate = undefined;

                        if (!isNaN(Date.parse(newValue))) {

                            revCompleteDate = newValue;

                            var dateDiffToday = (new Date()).valueOf() - revCompleteDate.valueOf();

                            if (dateDiffToday < 0) {

                                Ext.Msg.show({
                                    title: 'Invalid Review Completed Date',
                                    msg: 'Review Completed Date cannot be in the future!!',
                                    buttons: Ext.MessageBox.OK,
                                    icon: Ext.MessageBox.ERROR
                                });

                                cmp.setValue('');

                                return;
                            }

                            if (!Ext.isEmpty(revStartDate)) {

                                var dateDiff = revCompleteDate.valueOf() - revStartDate.valueOf();

                                if (dateDiff <= 0) {

                                    Ext.Msg.show({
                                        title: 'Invalid Review Completed Date',
                                        msg: 'Review Completed Date cannot be before the Review Start Date!!',
                                        buttons: Ext.MessageBox.OK,
                                        icon: Ext.MessageBox.ERROR
                                    });

                                    cmp.setValue('');
                                }
                            }
                        }
                    },
                    'blur': function (cmp, event, eOpts) {

                        revCompleteDate = undefined;
                        var newValue = cmp.getValue();

                        if (!isNaN(Date.parse(newValue))) {

                            revCompleteDate = newValue;

                            var dateDiffToday = (new Date()).valueOf() - revCompleteDate.valueOf();

                            if (dateDiffToday < 0) {

                                Ext.Msg.show({
                                    title: 'Invalid Review Completed Date',
                                    msg: 'Review Completed Date cannot be in the future!!',
                                    buttons: Ext.MessageBox.OK,
                                    icon: Ext.MessageBox.ERROR
                                });

                                cmp.setValue('');

                                return;
                            }

                            if (!Ext.isEmpty(revStartDate)) {

                                var dateDiff = revCompleteDate.valueOf() - revStartDate.valueOf();

                                if (dateDiff <= 0) {

                                    Ext.Msg.show({
                                        title: 'Invalid Review Completed Date',
                                        msg: 'Review Completed Date cannot be before the Review Start Date!!',
                                        buttons: Ext.MessageBox.OK,
                                        icon: Ext.MessageBox.ERROR
                                    });

                                    cmp.setValue('');
                                }
                            }
                        }
                    }
                },
                '#pipMonitoredYes': {
                    'change': function (radio, newValue, oldValue) {

                        var store = Ext.StoreManager.get('CaseReviewStore');

                        var savedValue = store.getAt(0).data.IsPIPMonitored;
                        var selection = (newValue) ? radio.inputValue : 0;

                        var dataChangedByUser = isDataChangedByUser(radio, selection, savedValue);

                        if (!dataChangedByUser) {

                            return;
                        }

                        deselectPrevChoices(radio);

                        var parms = { currentVal: false };

                        if (newValue) {

                            store.getAt(0).data.IsPIPMonitored = selection;
                        }
                    }
                },
                '#pipMonitoredNo': {
                    'change': function (radio, newValue, oldValue) {

                        var store = Ext.StoreManager.get('CaseReviewStore');

                        var savedValue = store.getAt(0).data.IsPIPMonitored;
                        var selection = (newValue) ? radio.inputValue : 0;

                        var dataChangedByUser = isDataChangedByUser(radio, selection, savedValue);

                        if (!dataChangedByUser) {

                            return;
                        }

                        deselectPrevChoices(radio);

                        var parms = { currentVal: false };

                        if (newValue) {

                            store.getAt(0).data.IsPIPMonitored = selection;
                        }
                    }
                },
                '#centerTabPanel':
                {
                    'tabchange': function (tabPanel, newCard, oldCard, eOpts) {

                        window.currentTab = newCard.itemId;

                        if (newCard.itemId == "createCaseReview") {
                            window.location = window.baseUrl + "CreateCaseReview";
                        } else if (newCard.itemId == "dashboard") {
                            window.location = window.baseUrl;
                        } else {
                            CaseStatusNRoleSecurity.setUpSecurity(self);

                            if (newCard.itemId == "caseOverview") {

                                updateOverviewPage();
                            } else {
                                
                                isTabChange = true;

                                if (unsavedChangesExist()) {
                                    //
                                    // Save any unsaved changes
                                    //
                                    silentSave = true;

                                    initializeResultsContainer();

                                    getAppController().saveData();
                                }

                                updateGrids(newCard.itemId);

                                var overrideValidationMsgs = overrideValidationMessages == 'true' ? true : false;

                                if (overrideValidationMsgs) {

                                    initValidationMessages();
                                }
                            }
                            //
                            // This redirection is handled by the routes config definition of 'App.CaseReview.controller.Main'.
                            // tab is 'newCard.itemId' and is passed to the 'onTabChange' method. This is needed to dynamically update
                            // the page url on a tabchange event without reloading the page.
                            //

                            //
                            // Added to improve performance(Horace)
                            //
                            if (!(oldCard.itemId == 'caseOverview')) {

                                var oldPage = getCRSComponent(oldCard.itemId);

                                Ext.destroy(oldPage.items[0]);
                            }
                            //
                            // End of performance enhancement
                            //
                            this.redirectTo(newCard.itemId);
                        }

                        Ext.resumeLayouts(true);
                    },
                    'beforetabchange': function (tabPanel, newCard, oldCard, eOpts) {

                        Ext.suspendLayouts();

                        if (newCard.itemId == "createCaseReview" || newCard.itemId == "dashboard") {
                            var msg = "ALERT: Any unsaved work will be lost, press cancel if you need to save, otherwise press ok to proceed without saving?";
                            var response = confirm(msg);
                            if (response) {
                                Ext.dom.Element.get(window).clearListeners();
                            } else {
                                return false;
                            }
                        }
                    }
                },
                '#caseSetUpLink': {
                    'afterrender': function (cmp, eOpts) {
                        Ext.create('App.CaseReview.controller.common.CaseSetUpPopUp', self);

                        if (getSavedCaseStatus().indexOf('Case Eliminated') > -1) {

                            cmp.setDisabled(true);
                        }
                    }
                },
                '#eliminateCaseLink': {
                    'afterrender': function (cmp, eOpts) {
                        Ext.create('App.CaseReview.controller.common.EliminateCasePopUp', self);

                    }
                },
                '#pdHealthGrid': {
                    'afterrender': function () {

                        Ext.create('App.CaseReview.controller.common.PDHealthGrid', this);

                        var updatedGrid = this.getPdHealthGrid();
                        var healthStore = GetHealthStore(1);

                        updatedGrid.setStore(healthStore);
                    },
                    'edit': function (grid, record) {

                        var parms = {};

                        parms = getStatusParms(parms, 'wellbeingItem17Rating');
                        parms['runValidations'] = true;
                        parms['dataChanged'] = true;
                        parms['data'] = record;
                        parms['storeId'] = 'CR_Health_CollectionStore';
                        parms['recordType'] = 'Grid';

                        runWellbeingRules(this, 'pdHealthGrid', parms);
                    }
                },
                '#educationGrid': {
                    'afterrender': function () {

                        Ext.create('App.CaseReview.controller.common.EducationGrid', this);
                    },
                    'edit': function (grid, record) {

                        var parms = {};

                        parms = getStatusParms(parms, 'wellbeingItem16Rating');
                        parms['runValidations'] = true;
                        parms['dataChanged'] = true;
                        parms['data'] = record;
                        parms['storeId'] = 'CR_Education_CollectionStore';
                        parms['recordType'] = 'Grid';

                        runWellbeingRules(this, 'educationGrid', parms);
                    }
                },
                //***************************************************************************
                //***************************************************************************
                // Event handlers - Facesheet
                //***************************************************************************
                //***************************************************************************   
                '#isFosterCareDateNA': {
                    'afterrender': function (checkBox, eOpts) {

                        FacesheetFunctions.handleIsFosterCareDateNAAfterrender(checkBox);
                    }
                },
                '#dischargeNA': {
                    'afterrender': function (checkBox, eOpts) {

                        FacesheetFunctions.handleDischargeNAAfterrender(checkBox);
                    }
                },
                '#questionMNarrative': {
                    'blur': function (cmp, event, eOpts) {

                        FacesheetFunctions.handleQuestionMNarrativeBlur(cmp);
                    }
                },
                '#caseRsn14': {
                    'afterrender': function (cmp, eOpts) {

                        FacesheetFunctions.handleCaseRsn14Afterrender();
                    }
                },
                '#childRace1': {
                    'change': function (cmp, newValue, oldValue, eOpts) {

                        FacesheetFunctions.handleChildRaceChange(cmp);
                    }
                },
                '#childRace2': {
                    'change': function (cmp, newValue, oldValue, eOpts) {

                        FacesheetFunctions.handleChildRaceChange(cmp);
                    }
                },
                '#childRace3': {
                    'change': function (cmp, newValue, oldValue, eOpts) {

                        FacesheetFunctions.handleChildRaceChange(cmp);
                    }
                },
                '#childRace4': {
                    'change': function (cmp, newValue, oldValue, eOpts) {

                        FacesheetFunctions.handleChildRaceChange(cmp);
                    }
                },
                '#childRace5': {
                    'change': function (cmp, newValue, oldValue, eOpts) {

                        FacesheetFunctions.handleChildRaceChange(cmp);
                    }
                },
                '#childRace6': {
                    'change': function (cmp, newValue, oldValue, eOpts) {

                        FacesheetFunctions.handleChildRace6Change(cmp);
                    }
                },
                '#childDemographicGrid': {
                    'afterrender': function () {

                        Ext.create('App.CaseReview.controller.common.ChildDemographicGrid', self);
                    },
                    'edit': function (grid, record) {

                        FacesheetFunctions.handleGridEdit('childDemographicGrid', 'CR_ChildDemographic_CollectionStore', record);
                    }
                },
                '#caseParticipantGrid': {
                    'afterrender': function () {
                        Ext.create('App.CaseReview.controller.common.CaseParticipantGrid', self);
                    },
                    'edit': function (grid, record) {

                        FacesheetFunctions.handleGridEdit('caseParticipantGrid', 'CR_CaseParticipant_CollectionStore', record);
                    }
                },
                '#facesheetCenterPanel': {
                    'beforerender': function (cmp, eOpts) {
                        
                        FacesheetFunctions.handleFacesheetCenterPanelBeforerender();
                    },
                    'afterrender': function (cmp, eOpts) {
                        
                        FacesheetFunctions.handleFacesheetCenterPanelAfterrender();

                        FacesheetFunctions.addChangeEventListeners(cmp);
                    }
                },
                //***************************************************************************
                //***************************************************************************
                // Event Handlers - Safety
                //***************************************************************************
                //***************************************************************************
                '#safetyPanel': {
                    'beforerender': function (cmp,eOpts) {

                        SafetyFunctions.handleSafetyPanelBeforerender();
                    },
                    'afterrender': function (cmp, eOpts) {

                        hideRatingOverride('safetyPanel');

                        SafetyFunctions.handleSafetyPanelAfterrender();

                        SafetyFunctions.addChangeEventListeners(cmp);
                    }
                },
                // Outcome 1 Rating
                '#safetyOutcome1Rating': {
                    'afterrender': function () {

                        SafetyFunctions.handleSafetyOutcome1RatingAfterrender();
                    }
                },
                // Item 1 Rating
                '#safetyItem1Rating': {
                    'afterrender': function () {

                        SafetyFunctions.handleSafetyItem1RatingAfterrender();
                    }
                },
                '#item1No': {
                    'afterrender': function () {

                        SafetyFunctions.handleItem1NoAfterrender();
                    }
                },
                '#item1ApplicableComments': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'Comments',
                            itemCode: 2,
                            vmFieldName: 'comments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'safetyItem1Rating',
                            itemName: 'Item1',
                            methodName: 'ValidateItem1'
                        };

                        SafetyFunctions.handleSafetyBlur(parms);
                    }
                },
                '#item1RatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 2,
                            vmFieldName: 'item1RatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'safetyItem1Rating',
                            itemName: 'Item1',
                            methodName: 'ValidateItem1'
                        };

                        SafetyFunctions.handleSafetyBlur(parms);
                    }
                },
                '#item2RatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 3,
                            vmFieldName: 'item2RatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'safetyItem2Rating',
                            itemName: 'Item2',
                            methodName: 'ValidateItem2'
                        };

                        SafetyFunctions.handleSafetyBlur(parms);
                    }
                },
                '#item3RatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 4,
                            vmFieldName: 'item3RatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'safetyItem3Rating',
                            itemName: 'Item3',
                            methodName: 'ValidateItem3'
                        };

                        SafetyFunctions.handleSafetyBlur(parms);
                    }
                },
                // Question 1A
                '#question1A': {
                    'afterrender': function (cmp, eOpts) {

                        SafetyFunctions.handleQuestion1AAfterrender();
                    }
                },
                // Question 1B - Comments
                '#question1BDelayReason': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'safety',
                            propertyName: 'DelayReason',
                            itemCode: 2,
                            vmFieldName: 'delayReason',
                            storeId: 'CR_Safety_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'safetyItem1Rating',
                            itemName: 'Item1',
                            methodName: 'ValidateItem1'
                        };

                        SafetyFunctions.handleSafetyBlur(parms);
                    }
                },
                // Outcome 2 Rating
                '#safetyOutcome2Rating': {
                    'afterrender': function () {

                        SafetyFunctions.handleSafetyItem2RatingAfterrender();
                    }
                },
                '#item2Comments': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'Comments',
                            itemCode: 3,
                            vmFieldName: 'comments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'safetyItem2Rating',
                            itemName: 'Item2',
                            methodName: 'ValidateItem2'
                        };

                        SafetyFunctions.handleSafetyBlur(parms);
                    }
                },
                // Item 2 Rating
                '#safetyItem2Rating': {
                    'afterrender': function () {

                        SafetyFunctions.handleSafetyItem2RatingAfterrender();
                    }
                },
                //***************************************************************************            
                // Report Grid
                //***************************************************************************
                '#safetyReportGrid': {
                    'afterrender': function () {

                        var parms = {
                            control: this,
                            controlId: 'safetyReportGrid',
                            runValidations: true,
                            dataChanged: false,
                            ratingItemId: 'safetyItem1Rating'
                        };

                        SafetyFunctions.handleSafetyReportGridAfterrender(parms);
                    },
                    'edit': function (grid, record) {

                        var parms = {
                            controlId: 'safetyReportGrid',
                            runValidations: true,
                            dataChanged: false,
                            ratingItemId: 'safetyItem1Rating',
                            data: record,
                            recordType: 'Grid'
                        };

                        SafetyFunctions.handleSafetyReportGridEdit(parms);
                    }
                },
                //***************************************************************************
                // Question 2A - 2B
                //***************************************************************************
                // Question 2A - Yes
                '#Question2AYes': {
                    'afterrender': function (radio, eOpts) {

                        var parms = {
                            control: radio
                        };

                        SafetyFunctions.handleQuestion2Afterrender(parms);
                    }
                },
                // Question 2A - No
                '#Question2ANo': {
                    'afterrender': function (radio, eOpts) {

                        var parms = {
                            control: radio
                        };

                        SafetyFunctions.handleQuestion2Afterrender(parms);
                    }
                },
                // Question 2B - NA
                '#Question2BNA': {
                    'afterrender': function () {

                        SafetyFunctions.handleQuestion2BNAAfterrender();
                    }
                },
                // Question 2A - No comments
                '#agencyEffortConcerns': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'safety',
                            propertyName: 'EffortToPreventReEntryExplained',
                            itemCode: 3,
                            vmFieldName: 'effortToPreventReEntryExplained',
                            storeId: 'CR_Safety_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'safetyItem2Rating',
                            itemName: 'Item2',
                            methodName: 'ValidateItem2'
                        };

                        SafetyFunctions.handleSafetyBlur(parms);
                    }
                },
                // Question 2B - No comments
                '#childRemovalConcerns': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'safety',
                            propertyName: 'ChildRemovedToEnsureSafetyExplained',
                            itemCode: 3,
                            vmFieldName: 'childRemovedToEnsureSafetyExplained',
                            storeId: 'CR_Safety_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'safetyItem2Rating',
                            itemName: 'Item2',
                            methodName: 'ValidateItem2'
                        };

                        SafetyFunctions.handleSafetyBlur(parms);
                    }
                },
                //***************************************************************************
                // Question 3A - 3F
                //***************************************************************************
                // Question 3A - No comments
                '#initialAssessmentExplained': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'safety',
                            propertyName: 'InitialAssesmentForAllChildrenInHomeExplained',
                            itemCode: 4,
                            vmFieldName: 'initialAssesmentForAllChildrenInHomeExplained',
                            storeId: 'CR_Safety_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'safetyItem3Rating',
                            itemName: 'Item3',
                            methodName: 'ValidateItem3'
                        };

                        SafetyFunctions.handleSafetyBlur(parms);
                    }
                },
                // Question 3B - No comments
                '#ongoingAssessmentExplained': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'safety',
                            propertyName: 'OngoingAssessmentForAllChildrenInHomeExplained',
                            itemCode: 4,
                            vmFieldName: 'ongoingAssessmentForAllChildrenInHomeExplained',
                            storeId: 'CR_Safety_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'safetyItem3Rating',
                            itemName: 'Item3',
                            methodName: 'ValidateItem3'
                        };

                        SafetyFunctions.handleSafetyBlur(parms);
                    }
                },
                // Question 3C - No comments
                '#safetyPlanExplained': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'safety',
                            propertyName: 'SafetyPlanDevelopedAndMonitoredExplained',
                            itemCode: 4,
                            vmFieldName: 'safetyPlanDevelopedAndMonitoredExplained',
                            storeId: 'CR_Safety_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'safetyItem3Rating',
                            itemName: 'Item3',
                            methodName: 'ValidateItem3'
                        };

                        SafetyFunctions.handleSafetyBlur(parms);
                    }
                },
                // Question 3D1 - comments
                '#safetyRelatedIncidents': {
                    'afterrender': function (cmp, eOpts) {

                        SafetyFunctions.handleItem3D1Afterrender(cmp);
                    }
                },
                // Question 3E1
                '#item3E1': {
                    'afterrender': function (cmp, eOpts) {

                        SafetyFunctions.handleItem3E1Afterrender(cmp);
                    }
                },
                '#otherSafetyConcerns': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'safety',
                            propertyName: 'OtherSafetyConcernExplained',
                            itemCode: 4,
                            vmFieldName: 'otherSafetyConcernExplained',
                            storeId: 'CR_Safety_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'safetyItem3Rating',
                            itemName: 'Item3',
                            methodName: 'ValidateItem3'
                        };

                        SafetyFunctions.handleSafetyBlur(parms);
                    }
                },
                '#fosterSafetyConcerns': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'safety',
                            propertyName: 'FosterSafetyOtherExplained',
                            itemCode: 3,
                            vmFieldName: 'fosterSafetyOtherExplained',
                            storeId: 'CR_Safety_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'safetyItem3Rating',
                            itemName: 'Item3',
                            methodName: 'ValidateItem3'
                        };

                        SafetyFunctions.handleSafetyBlur(parms);
                    }
                },
                // Question 3F1 - comments
                '#otherPlacementConcerns': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'safety',
                            propertyName: 'FosterPlacementConcerOtherExplained',
                            itemCode: 3,
                            vmFieldName: 'fosterPlacementConcerOtherExplained',
                            storeId: 'CR_Safety_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'safetyItem3Rating',
                            itemName: 'Item3',
                            methodName: 'ValidateItem3'
                        };

                        SafetyFunctions.handleSafetyBlur(parms);
                    }
                },
                '#item3F1': {
                    'afterrender': function (cmp, eOpts) {

                        SafetyFunctions.handleItem3F1Afterrender(cmp);
                    }
                },
                // Item 3 Rating
                '#safetyItem3Rating': {
                    'afterrender': function () {

                        SafetyFunctions.handleSafetyItem3RatingAfterrender();
                    }
                },
                //***************************************************************************
                //***************************************************************************
                // Event Handlers - Permanency
                //***************************************************************************
                //***************************************************************************
                '#permanencyPanel': {
                    'beforerender': function (cmp,eOpts) {

                        PermanencyFunctions.handlePermanencyPanelBeforerender();
                    },
                    'afterrender': function (cmp, eOpts) {
                        
                        hideRatingOverride('permanencyPanel');

                        PermanencyFunctions.handlePermanencyPanelAfterrender();

                        PermanencyFunctions.addChangeEventListeners(cmp);
                    }
                },
                // Item 4 Rating
                '#permanencyItem4Rating': {
                    'afterrender': function () {

                        var parms = { ratingComponent: this.getPermanencyItem4Rating() };

                        PermanencyFunctions.handlePermanencyRatingAfterrender(parms);
                    }
                },
                '#item4RatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 5,
                            vmFieldName: 'item4RatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'permanencyItem4Rating',
                            itemName: 'Item4',
                            sectionName: 'item4RatingComment',
                            methodName: 'ValidateItem4'
                        };

                        PermanencyFunctions.handlePermanencyBlur(parms);
                    }
                },
                '#item5RatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 6,
                            vmFieldName: 'item5RatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'permanencyItem5Rating',
                            itemName: 'Item5',
                            sectionName: 'item5RatingComment',
                            methodName: 'ValidateItem5'
                        };

                        PermanencyFunctions.handlePermanencyBlur(parms);
                    }
                },
                '#item6RatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 7,
                            vmFieldName: 'item6RatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'permanencyItem6Rating',
                            itemName: 'Item6',
                            sectionName: 'item6RatingComment',
                            methodName: 'ValidateItem6'
                        };

                        PermanencyFunctions.handlePermanencyBlur(parms);
                    }
                },
                '#item7RatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 8,
                            vmFieldName: 'item7RatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'permanencyItem7Rating',
                            itemName: 'Item7',
                            sectionName: 'item7RatingComment',
                            methodName: 'ValidateItem7'
                        };

                        PermanencyFunctions.handlePermanencyBlur(parms);
                    }
                },
                '#item8RatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 9,
                            vmFieldName: 'item8RatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'permanencyItem8Rating',
                            itemName: 'Item8',
                            sectionName: 'item8RatingComment',
                            methodName: 'ValidateItem8'
                        };

                        PermanencyFunctions.handlePermanencyBlur(parms);
                    }
                },
                '#item9RatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 10,
                            vmFieldName: 'item9RatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'permanencyItem9Rating',
                            itemName: 'Item9',
                            sectionName: 'item9RatingComment',
                            methodName: 'ValidateItem9'
                        };

                        PermanencyFunctions.handlePermanencyBlur(parms);
                        var dataParms = {};

                        dataParms['collectionName'] = 'item';
                        dataParms['propertyName'] = 'RatingComments';
                        dataParms['itemCode'] = 10;

                        var savedValue = getSavedPropertyValue(dataParms);
                    }
                },
                '#item10RatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 11,
                            vmFieldName: 'item10RatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'permanencyItem10Rating',
                            itemName: 'Item10',
                            sectionName: 'item10RatingComment',
                            methodName: 'ValidateItem10'
                        };

                        PermanencyFunctions.handlePermanencyBlur(parms);
                    }
                },
                '#item11RatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 12,
                            vmFieldName: 'item11RatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'permanencyItem11Rating',
                            itemName: 'Item11',
                            sectionName: 'item11RatingComment',
                            methodName: 'ValidateItem11'
                        };

                        PermanencyFunctions.handlePermanencyBlur(parms);
                    }
                },
                '#permanencyOutcome1Rating': {
                    'afterrender': function () {

                        PermanencyFunctions.handlePermanencyOutcomeRatingAfterrender(3);
                    }
                },
                // Question 4C1 - Other comments
                '#item4C1placeApplicableCircumstancesOther': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'permanency',
                            propertyName: 'PlacementApplicableCircumstancesOther',
                            itemCode: 5,
                            vmFieldName: 'placementApplicableCircumstancesOther',
                            storeId: 'CR_Permanency_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'permanencyItem4Rating',
                            itemName: 'Item4',
                            sectionName: 'item4C1placeApplicableCircumstancesOther',
                            methodName: 'ValidateItem4'
                        };

                        PermanencyFunctions.handlePermanencyBlur(parms);
                    }
                },
                '#placementGrid': {
                    'afterrender': function () {

                        Ext.create('App.CaseReview.controller.common.PlacementGrid', this);

                        var parms = {
                            runValidations: true,
                            dataChanged: false,
                            ratingItemId: 'permanencyItem4Rating',
                            methodName: 'placementGrid'
                        };

                        PermanencyFunctions.handleGridAfterrender(parms);
                    },
                    'edit': function (grid, record) {

                        var parms = {
                            runValidations: true,
                            dataChanged: false,
                            ratingItemId: 'permanencyItem4Rating',
                            methodName: 'placementGrid',
                            data: record,
                            storeId: 'CR_Placement_CollectionStore',
                            recordType: 'Grid'
                        };

                        PermanencyFunctions.handleGridEdit(parms);
                    }
                },
                // Item 5 Rating
                '#permanencyItem5Rating': {
                    'afterrender': function () {

                        var parms = { ratingComponent: this.getPermanencyItem5Rating() };

                        PermanencyFunctions.handlePermanencyRatingAfterrender(parms);
                    }
                },
                '#goalGrid': {
                    'afterrender': function () {

                        Ext.create('App.CaseReview.controller.common.GoalGrid', this);
                    },
                    'edit': function (grid, record) {

                        var parms = {
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'permanencyItem4Rating',
                            methodName: 'goalGrid',
                            data: record,
                            storeId: 'CR_Goal_CollectionStore',
                            recordType: 'Grid'
                        };

                        PermanencyFunctions.handleGridEdit(parms);
                    }
                },
                '#permanencyGoal1Selection': {
                    'afterrender': function () {

                        var parms = {
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'permanencyItem5Rating',
                            methodName: 'permanencyGoal1Selection_beforerender'
                        };

                        PermanencyFunctions.handleGridAfterrender(parms);
                    }
                },
                // Question 5B - No comments
                '#allGoalsInTimelyMannerExplained': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'permanency',
                            propertyName: 'AllGoalsInTimelyMannerExplained',
                            itemCode: 6,
                            vmFieldName: 'allGoalsInTimelyMannerExplained',
                            storeId: 'CR_Permanency_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'permanencyItem5Rating',
                            itemName: 'Item5',
                            sectionName: 'allGoalsInTimelyMannerExplained',
                            methodName: 'ValidateItem5'
                        };

                        PermanencyFunctions.handlePermanencyBlur(parms);
                    }
                },
                // Question 5C - No comments
                '#allGoalsAppropriateExplained': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'permanency',
                            propertyName: 'AllGoalsAppropriateExplained',
                            itemCode: 6,
                            vmFieldName: 'allGoalsAppropriateExplained',
                            storeId: 'CR_Permanency_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'permanencyItem5Rating',
                            itemName: 'Item5',
                            sectionName: 'allGoalsAppropriateExplained',
                            methodName: 'ValidateItem5'
                        };

                        PermanencyFunctions.handlePermanencyBlur(parms);
                    }
                },
                '#recentFosterEntryDate': {
                    'afterrender': function () {

                        PermanencyFunctions.handlePermanencyRecentFosterEntryDateAfterrender();
                    }
                },
                '#permanencyDischargeDate': {
                    'afterrender': function () {

                        PermanencyFunctions.handlePermanencyDischargeDateAfterrender();
                    }
                },
                // Item 6 Rating
                '#permanencyItem6Rating': {
                    'afterrender': function () {

                        var parms = { ratingComponent: this.getPermanencyItem6Rating() };

                        PermanencyFunctions.handlePermanencyRatingAfterrender(parms);
                    }
                },
                // Question 6B - No comments
                '#agencyConcertedEffortsExplained': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'permanency',
                            propertyName: 'AgencyConcertedEffortsExplained',
                            itemCode: 7,
                            vmFieldName: 'agencyConcertedEffortsExplained',
                            storeId: 'CR_Permanency_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'permanencyItem6Rating',
                            itemName: 'Item6',
                            sectionName: 'agencyConcertedEffortsExplained',
                            methodName: 'ValidateItem6'
                        };

                        PermanencyFunctions.handlePermanencyBlur(parms);
                    }
                },
                // Question 6C1 - No comments
                '#livingArragmentExplained': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'permanency',
                            propertyName: 'LivingArrangementExplained',
                            itemCode: 7,
                            vmFieldName: 'livingArrangementExplained',
                            storeId: 'CR_Permanency_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'permanencyItem6Rating',
                            itemName: 'Item6',
                            sectionName: 'livingArragmentExplained',
                            methodName: 'ValidateItem6'
                        };

                        PermanencyFunctions.handlePermanencyBlur(parms);
                    }
                },
                '#question6C2DocumentationDate': {
                    'keyup': function (cmp, event, eOpts) {

                        appDataEvent.permanency.changeByUserAction = true;
                    },
                    'select': function (cmp, value, eOpts) {

                        appDataEvent.permanency.changeByUserAction = true;

                        var noDateComponent = getAppController().getQuestion6C2NoDate();
                        var naComponent = getAppController().getQuestion6C2NA();

                        var permanencyStore = Ext.data.ChainedStore.create({
                            source: 'CR_Permanency_CollectionStore'
                        });

                        if (!Ext.isEmpty(value)) {

                            naComponent.setValue(false);
                            noDateComponent.setValue(false);

                            permanencyStore.getAt(0).data.IsOtherPlannedArrangementNA = null;
                            permanencyStore.getAt(0).data.IsOtherPlannedArrangementNoDate = null;

                            var fields = [];
                            var vmFields = [];
                            var vmField = { 'otherPlannedArrangementDocumentationDate': value };
                            var field = { 'OtherPlannedArrangementDocumentationDate': value };

                            fields.push(field);

                            field = { 'DataState': 0 };
                            fields.push(field);

                            vmFields.push(vmField);

                            var parms = { currentVal: value };
                            parms['storeId'] = 'CR_Permanency_CollectionStore';
                            parms['fields'] = fields;
                            parms['vmFields'] = vmFields;
                            parms['control'] = cmp;
                            parms['runValidations'] = true;
                            parms['dataChanged'] = true;

                            parms = getStatusParms(parms, 'permanencyItem6Rating');

                            initValidations('Item6');

                            runPermanencyRules(this, 'question6C2DocumentationDate', parms);
                        }
                    },
                    'blur': function (cmp, event, eOpts) {

                        if (!appDataEvent.permanency.changeByUserAction) {

                            return;

                        }

                        if (pageLoadStatus['Permanency'] == 'rendered') {

                            var newValue = cmp.getValue(),
                                noDateComponent = getAppController().getQuestion6C2NoDate(),
                                naComponent = getAppController().getQuestion6C2NA(),
                                permanencyStore = Ext.data.ChainedStore.create({
                                    source: 'CR_Permanency_CollectionStore'
                                });

                            if (!Ext.isEmpty(newValue)) {

                                naComponent.setValue(false);
                                noDateComponent.setValue(false);

                                permanencyStore.getAt(0).data.IsOtherPlannedArrangementNA = null;
                                permanencyStore.getAt(0).data.IsOtherPlannedArrangementNoDate = null;

                                var fields = [];
                                var field = { 'OtherPlannedArrangementDocumentationDate': newValue };

                                fields.push(field);

                                field = { 'DataState': 0 };
                                fields.push(field);

                                var parms = { currentVal: newValue };
                                parms['storeId'] = 'CR_Permanency_CollectionStore';
                                parms['fields'] = fields;
                                parms['control'] = cmp;
                                parms['runValidations'] = true;
                                parms['dataChanged'] = true;

                                parms = getStatusParms(parms, 'permanencyItem6Rating');

                                initValidations('Item6');

                                runPermanencyRules(this, 'question6C2DocumentationDate', parms);
                            }
                        }
                    }
                },
                // Question 6C - No comments
                '#otherPlannedConcertedEffortExplained': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'permanency',
                            propertyName: 'OtherPlannedConcertedEffortExplained',
                            itemCode: 7,
                            vmFieldName: 'otherPlannedConcertedEffortExplained',
                            storeId: 'CR_Permanency_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'permanencyItem6Rating',
                            itemName: 'Item6',
                            sectionName: 'otherPlannedConcertedEffortExplained',
                            methodName: 'ValidateItem6'
                        };

                        PermanencyFunctions.handlePermanencyBlur(parms);
                    }
                },
                // Item 7 Rating
                '#permanencyItem7Rating': {
                    'afterrender': function () {

                        var parms = { ratingComponent: this.getPermanencyItem7Rating() };

                        PermanencyFunctions.handlePermanencyRatingAfterrender(parms);
                    }
                },
                '#question7AYes': {
                    'afterrender': function () {

                        PermanencyFunctions.handleQuestion7AYesAfterrender();
                    }
                },
                // Question 7B - No comments
                '#item7BConcerns': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'permanency',
                            propertyName: 'ValidReasonForSeparationExplained',
                            itemCode: 8,
                            vmFieldName: 'validReasonForSeparationExplained',
                            storeId: 'CR_Permanency_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'permanencyItem7Rating',
                            itemName: 'Item7',
                            sectionName: 'item7BConcerns',
                            methodName: 'ValidateItem7'
                        };

                        PermanencyFunctions.handlePermanencyBlur(parms);
                    }
                },
                '#permanencyOutcome2Rating': {
                    'afterrender': function () {

                        PermanencyFunctions.handlePermanencyOutcomeRatingAfterrender(4);
                    }
                },
                // Item 8 Rating
                '#permanencyItem8Rating': {
                    'afterrender': function () {

                        var parms = { ratingComponent: this.getPermanencyItem8Rating() };

                        PermanencyFunctions.handlePermanencyRatingAfterrender(parms);
                    }
                },
                // Item 9 Rating
                '#permanencyItem9Rating': {
                    'afterrender': function () {

                        var parms = { ratingComponent: this.getPermanencyItem9Rating() };

                        PermanencyFunctions.handlePermanencyRatingAfterrender(parms);
                    }
                },
                // Item 10 Rating
                '#permanencyItem10Rating': {
                    'afterrender': function () {

                        var parms = { ratingComponent: this.getPermanencyItem10Rating() };

                        PermanencyFunctions.handlePermanencyRatingAfterrender(parms);
                    }
                },
                '#placementEffortConcernsMother1': {
                    'afterrender': function (cmp, eOpts) {

                        var value = Ext.StoreManager.get('CaseReviewStore').getAt(0).data.CR_Permanency_Collection[0].IsConcertedEffortToLocateMaternalRelatives;
                        parms = {
                            control: cmp,
                            value: value
                        };

                        PermanencyFunctions.handleRelativeLocationAfterrender(parms);
                    }
                },
                '#placementEffortConcernsMother2': {
                    'afterrender': function (cmp, eOpts) {

                        var value = Ext.StoreManager.get('CaseReviewStore').getAt(0).data.CR_Permanency_Collection[0].IsConcertedEffortToLocateMaternalRelatives;
                        parms = {
                            control: cmp,
                            value: value
                        };

                        PermanencyFunctions.handleRelativeLocationAfterrender(parms);
                    }
                },
                '#placementEffortConcernsMother3': {
                    'afterrender': function (cmp, eOpts) {

                        var value = Ext.StoreManager.get('CaseReviewStore').getAt(0).data.CR_Permanency_Collection[0].IsConcertedEffortToLocateMaternalRelatives;
                        parms = {
                            control: cmp,
                            value: value
                        };

                        PermanencyFunctions.handleRelativeLocationAfterrender(parms);
                    }
                },
                '#placementEffortConcernsMother4': {
                    'afterrender': function (cmp, eOpts) {

                        var value = Ext.StoreManager.get('CaseReviewStore').getAt(0).data.CR_Permanency_Collection[0].IsConcertedEffortToLocateMaternalRelatives;
                        parms = {
                            control: cmp,
                            value: value
                        };

                        PermanencyFunctions.handleRelativeLocationAfterrender(parms);
                    }
                },
                // Item 11 Rating
                '#permanencyItem11Rating': {
                    'afterrender': function () {

                        var parms = { ratingComponent: this.getPermanencyItem11Rating() };

                        PermanencyFunctions.handlePermanencyRatingAfterrender(parms);
                    }
                },
                '#itemApplicable11No': {
                    'afterrender': function (radio, eOpts) {

                        var item = getItemFromGraph(12, 4);

                        if (!Ext.isEmpty(item)) {

                            if (item.IsApplicable == 2) {

                                // Disable section for Item 11
                                disableContainerItems(['item11APanel', 'item11A1Panel', 'item11BPanel', 'item11B1Panel']);
                                setDisabledFieldValuesInContainer(['item11APanel', 'item11A1Panel', 'item11BPanel', 'item11B1Panel']);
                            }
                        }
                    }
                },
                // Question 11A1 - Comments
                '#efforts11A1Comments': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'permanency',
                            propertyName: 'EffortsMotherFosterOther',
                            itemCode: 12,
                            vmFieldName: 'effortsMotherFosterOther',
                            storeId: 'CR_Permanency_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'permanencyItem11Rating',
                            itemName: 'Item11',
                            sectionName: 'efforts11A1Comments',
                            methodName: 'ValidateItem11'
                        };

                        PermanencyFunctions.handlePermanencyBlur(parms);
                    }
                },
                // Question 11A1 - Comments
                '#efforts11B1Comments': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'permanency',
                            propertyName: 'EffortFatherFosterRelationshipOther',
                            itemCode: 12,
                            vmFieldName: 'effortFatherFosterRelationshipOther',
                            storeId: 'CR_Permanency_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'permanencyItem11Rating',
                            itemName: 'Item11',
                            sectionName: 'efforts11A1Comments',
                            methodName: 'ValidateItem11'
                        };

                        PermanencyFunctions.handlePermanencyBlur(parms);
                    }
                },
                //***************************************************************************
                //***************************************************************************
                // Event Handlers - Wellbeing
                //***************************************************************************
                //***************************************************************************
                '#wellbeingPanel': {
                    beforerender: function (cmp, eOpts) {
                        
                        WellbeingFunctions.handleWellbeingPanelBeforerender();
                    },
                    afterrender: function (cmp, eOpts) {

                        hideRatingOverride('wellbeingPanel');

                        WellbeingFunctions.handleWellbeingPanelAfterrender();

                        WellbeingFunctions.addChangeEventListeners(cmp);
                    }
                },
                '#item12RatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 13,
                            vmFieldName: 'item12RatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem12Rating',
                            itemName: 'Item12',
                            sectionName: 'item12RatingComment',
                            methodName: 'ValidateItem12'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                '#item12ARatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 14,
                            vmFieldName: 'item12ARatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem12ARating',
                            itemName: 'Item12',
                            sectionName: 'item12ARatingComment',
                            methodName: 'ValidateItem12'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                '#item12BRatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 15,
                            vmFieldName: 'item12BRatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem12BRating',
                            itemName: 'Item12',
                            sectionName: 'item12BRatingComment',
                            methodName: 'ValidateItem12'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                '#item12CRatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 16,
                            vmFieldName: 'item12CRatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem12CRating',
                            itemName: 'Item12',
                            sectionName: 'item12CRatingComment',
                            methodName: 'ValidateItem12'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                '#item13RatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 17,
                            vmFieldName: 'item13RatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem13Rating',
                            itemName: 'Item13',
                            sectionName: 'item13RatingComment',
                            methodName: 'ValidateItem13'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                '#item14RatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 18,
                            vmFieldName: 'item14RatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem14Rating',
                            itemName: 'Item14',
                            sectionName: 'item14RatingComment',
                            methodName: 'ValidateItem14'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                '#item15RatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 19,
                            vmFieldName: 'item15RatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem15Rating',
                            itemName: 'Item15',
                            sectionName: 'item15RatingComment',
                            methodName: 'ValidateItem15'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                '#item16RatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 20,
                            vmFieldName: 'item16RatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem16Rating',
                            itemName: 'Item16',
                            sectionName: 'item16RatingComment',
                            methodName: 'ValidateItem16'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                '#item17RatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 21,
                            vmFieldName: 'item17RatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem17Rating',
                            itemName: 'Item17',
                            sectionName: 'item17RatingComment',
                            methodName: 'ValidateItem17'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                '#item18RatingComment': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'item',
                            propertyName: 'RatingComments',
                            itemCode: 22,
                            vmFieldName: 'item18RatingComments',
                            storeId: 'CR_Item_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem18Rating',
                            itemName: 'Item18',
                            sectionName: 'item18RatingComment',
                            methodName: 'ValidateItem18'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                // Item 12 Rating
                '#wellbeingItem12Rating': {
                    'afterrender': function () {

                        var parms = { ratingComponent: this.getWellbeingItem12Rating() };

                        WellbeingFunctions.handleWellbeingRatingAfterrender(parms);
                    }
                },
                '#wellbeingOutcome1Rating': {
                    'afterrender': function () {

                        WellbeingFunctions.handleWellbeingOutcomeRatingAfterrender(5);
                    }
                },
                // Item 12A Rating
                '#wellbeingItem12ARating': {
                    'afterrender': function () {

                        var parms = { ratingComponent: this.getWellbeingItem12ARating() };

                        WellbeingFunctions.handleWellbeingRatingAfterrender(parms);
                    }
                },
                // Question 12A1 - No comments
                '#needConcerns': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'wellbeing',
                            propertyName: 'ComprehensiveAssessmentExplained',
                            itemCode: 14,
                            vmFieldName: 'comprehensiveAssessmentExplained',
                            storeId: 'CR_WellBeing_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem12ARating',
                            itemName: 'Item12',
                            sectionName: 'ValidateItem12A',
                            methodName: 'ValidateItem12A'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                // Question 12A2 - No comments
                '#serviceConcerns': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'wellbeing',
                            propertyName: 'AppropriateServicesProvidedExplained',
                            itemCode: 14,
                            vmFieldName: 'appropriateServicesProvidedExplained',
                            storeId: 'CR_WellBeing_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem12ARating',
                            itemName: 'Item12',
                            sectionName: 'ValidateItem12A',
                            methodName: 'ValidateItem12A'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                '#item12B': {
                    'afterrender': function () {

                        var parms = {
                            runValidations: true,
                            dataChanged: false,
                            ratingItemId: 'wellbeingItem12BRating',
                            itemName: 'item12',
                            methodName: 'item12B'
                        };

                        WellbeingFunctions.handleWellbeingAfterrender(parms);
                    }
                },
                // Item 12B Rating
                '#wellbeingItem12BRating': {
                    'afterrender': function () {

                        var parms = { ratingComponent: this.getWellbeingItem12BRating() };

                        WellbeingFunctions.handleWellbeingRatingAfterrender(parms);
                    }
                },
                // Question 12B1 - No comments
                '#item12B1Concerns': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'wellbeing',
                            propertyName: 'ComprehensiveAssessementForMotherExplained',
                            itemCode: 15,
                            vmFieldName: 'comprehensiveAssessementForMotherExplained',
                            storeId: 'CR_WellBeing_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem12BRating',
                            itemName: 'Item12',
                            sectionName: 'ValidateItem12B',
                            methodName: 'ValidateItem12B'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                // Question 12B2 - No comments
                '#item12B2Concerns': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'wellbeing',
                            propertyName: 'ComprehensiveAssessementforFatherConductedExplained',
                            itemCode: 15,
                            vmFieldName: 'comprehensiveAssessementforFatherConductedExplained',
                            storeId: 'CR_WellBeing_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem12BRating',
                            itemName: 'Item12',
                            sectionName: 'ValidateItem12B',
                            methodName: 'ValidateItem12B'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                // Question 12B3 - No comments
                '#item12B3Concerns': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'wellbeing',
                            propertyName: 'AppropriateServicesForMotherExplained',
                            itemCode: 15,
                            vmFieldName: 'appropriateServicesForMotherExplained',
                            storeId: 'CR_WellBeing_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem12BRating',
                            itemName: 'Item12',
                            sectionName: 'ValidateItem12B',
                            methodName: 'ValidateItem12B'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                // Question 12B4 - No comments
                '#item12B4Concerns': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'wellbeing',
                            propertyName: 'AppropriateServicesForFatherExplained',
                            itemCode: 15,
                            vmFieldName: 'appropriateServicesForFatherExplained',
                            storeId: 'CR_WellBeing_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem12BRating',
                            itemName: 'Item12',
                            sectionName: 'ValidateItem12B',
                            methodName: 'ValidateItem12B'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                '#item12C': {
                    'afterrender': function () {

                        var parms = {
                            runValidations: true,
                            dataChanged: false,
                            ratingItemId: 'wellbeingItem12CRating',
                            itemName: 'item12',
                            methodName: 'item12C'
                        };

                        WellbeingFunctions.handleWellbeingAfterrender(parms);
                    }
                },
                // Item 12C Rating
                '#wellbeingItem12CRating': {
                    'afterrender': function () {

                        var parms = { ratingComponent: this.getWellbeingItem12CRating() };

                        WellbeingFunctions.handleWellbeingRatingAfterrender(parms);
                    }
                },
                // Question 12C1 - No comments
                '#item12C1Concerns': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'wellbeing',
                            propertyName: 'NeedsOfFosterParentsAdequatelyAssessedExplained',
                            itemCode: 16,
                            vmFieldName: 'needsOfFosterParentsAdequatelyAssessedExplained',
                            storeId: 'CR_WellBeing_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem12CRating',
                            itemName: 'Item12',
                            sectionName: 'ValidateItem12C',
                            methodName: 'ValidateItem12C'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                // Question 12C2 - No comments
                '#item12C2Concerns': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'wellbeing',
                            propertyName: 'FosterParentsProvidedAppropriateServicesExplained',
                            itemCode: 16,
                            vmFieldName: 'fosterParentsProvidedAppropriateServicesExplained',
                            storeId: 'CR_WellBeing_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem12CRating',
                            itemName: 'Item12',
                            sectionName: 'ValidateItem12C',
                            methodName: 'ValidateItem12C'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                // Item 13 Rating
                '#wellbeingItem13Rating': {
                    'afterrender': function () {

                        var parms = { ratingComponent: this.getWellbeingItem13Rating() };

                        WellbeingFunctions.handleWellbeingRatingAfterrender(parms);
                    }
                },
                // Question 13A - No comments
                '#item13AConcerns': {
                    'afterrender': function () {

                        var parms = getStatusParms(null, 'wellbeingItem13Rating');
                        parms['runValidations'] = true;
                        parms['dataChanged'] = false;

                        runWellbeingRules(this, 'item13AConcerns', parms);
                    },
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'wellbeing',
                            propertyName: 'AgencyConcertedEffortsToInvolveTheChildExplained',
                            itemCode: 17,
                            vmFieldName: 'agencyConcertedEffortsToInvolveTheChildExplained',
                            storeId: 'CR_WellBeing_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem13Rating',
                            itemName: 'Item13',
                            sectionName: 'ValidateItem13',
                            methodName: 'ValidateItem13'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                // Question 13B - No comments
                '#item13BConcerns': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'wellbeing',
                            propertyName: 'AgencyConcertedEffortsToInvolveTheMotherExplained',
                            itemCode: 17,
                            vmFieldName: 'agencyConcertedEffortsToInvolveTheMotherExplained',
                            storeId: 'CR_WellBeing_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem13Rating',
                            itemName: 'Item13',
                            sectionName: 'ValidateItem13',
                            methodName: 'ValidateItem13'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                // Question 13C - No comments
                '#item13CConcerns': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'wellbeing',
                            propertyName: 'AgencyConcertedEffortsToInvolveTheFatherExplained',
                            itemCode: 17,
                            vmFieldName: 'agencyConcertedEffortsToInvolveTheFatherExplained',
                            storeId: 'CR_WellBeing_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem13Rating',
                            itemName: 'Item13',
                            sectionName: 'ValidateItem13',
                            methodName: 'ValidateItem13'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                '#question13AAnswers': {
                    'afterrender': function () {

                        var parms = {
                            runValidations: true,
                            dataChanged: false,
                            ratingItemId: 'wellbeingItem13Rating',
                            itemName: 'item13',
                            methodName: 'question13AAnswers'
                        };

                        WellbeingFunctions.handleWellbeingAfterrender(parms);
                    }
                },
                '#item13ApplicableMotherYes': {
                    'afterrender': function () {

                        var parms = {
                            runValidations: true,
                            dataChanged: false,
                            ratingItemId: 'wellbeingItem13Rating',
                            itemName: 'item13',
                            methodName: 'item13ApplicableMotherYes'
                        };

                        WellbeingFunctions.handleWellbeingAfterrender(parms);
                    }
                },
                '#item13ApplicableFatherYes': {
                    'afterrender': function () {

                        var parms = {
                            runValidations: true,
                            dataChanged: false,
                            ratingItemId: 'wellbeingItem13Rating',
                            itemName: 'item13',
                            methodName: 'item13ApplicableFatherYes'
                        };

                        WellbeingFunctions.handleWellbeingAfterrender(parms);
                    }
                },
                '#item13ApplicableCases': {
                    'afterrender': function () {

                        var parms = {
                            runValidations: true,
                            dataChanged: false,
                            ratingItemId: 'wellbeingItem13Rating',
                            itemName: 'item13',
                            methodName: 'item13ApplicableCases'
                        };

                        WellbeingFunctions.handleWellbeingAfterrender(parms);
                    }
                },
                // Item 14 Rating
                '#wellbeingItem14Rating': {
                    'afterrender': function () {

                        var parms = { ratingComponent: this.getWellbeingItem14Rating() };

                        WellbeingFunctions.handleWellbeingRatingAfterrender(parms);
                    }
                },
                // Question 14B - No comments
                '#responsiblePartyVisitationQualityExplained': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'wellbeing',
                            propertyName: 'ResponsiblePartyVisitationQualityExplained',
                            itemCode: 18,
                            vmFieldName: 'responsiblePartyVisitationQualityExplained',
                            storeId: 'CR_WellBeing_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem14Rating',
                            itemName: 'Item14',
                            sectionName: 'ValidateItem14',
                            methodName: 'ValidateItem14'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                // Item 15 Rating
                '#wellbeingItem15Rating': {
                    'afterrender': function () {

                        var parms = { ratingComponent: this.getWellbeingItem15Rating() };

                        WellbeingFunctions.handleWellbeingRatingAfterrender(parms);
                    }
                },
                '#item15ApplicableCases': {
                    'afterrender': function () {

                        var parms = {
                            runValidations: true,
                            dataChanged: false,
                            ratingItemId: 'wellbeingItem15Rating',
                            itemName: 'item15',
                            methodName: 'item15ApplicableCases'
                        };

                        WellbeingFunctions.handleWellbeingAfterrender(parms);
                    }
                },
                '#item15ApplicableCaseYes': {
                    'afterrender': function () {

                        var parms = {
                            runValidations: true,
                            dataChanged: false,
                            ratingItemId: 'wellbeingItem15Rating',
                            itemName: 'item15',
                            methodName: 'item15ApplicableCaseYes'
                        };

                        WellbeingFunctions.handleWellbeingAfterrender(parms);
                    }
                },
                // Question 15C - No comments
                '#responsiblePartyVisitationQualityWithMotherExplained': {
                    'blur': function (cmp, event, eOpts) {

                        var parms = {
                            control: cmp,
                            collectionName: 'wellbeing',
                            propertyName: 'ResponsiblePartyVisitationQualityWithMotherExplained',
                            itemCode: 19,
                            vmFieldName: 'responsiblePartyVisitationQualityWithMotherExplained',
                            storeId: 'CR_WellBeing_CollectionStore',
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem15Rating',
                            itemName: 'Item15',
                            sectionName: 'ValidateItem15',
                            methodName: 'ValidateItem15'
                        };

                        WellbeingFunctions.handleWellbeingBlur(parms);
                    }
                },
                '#wellbeingOutcome2Rating': {
                    'afterrender': function () {

                        WellbeingFunctions.handleWellbeingOutcomeRatingAfterrender(6);
                    }
                },
                // Item 16 Rating
                '#wellbeingItem16Rating': {
                    'afterrender': function () {

                        var parms = { ratingComponent: this.getWellbeingItem16Rating() };

                        WellbeingFunctions.handleWellbeingRatingAfterrender(parms);
                    }
                },
                '#wellbeingOutcome3Rating': {
                    'afterrender': function () {

                        WellbeingFunctions.handleWellbeingOutcomeRatingAfterrender(7);
                    }
                },
                // Item 17 Rating
                '#wellbeingItem17Rating': {
                    'afterrender': function () {

                        var parms = { ratingComponent: this.getWellbeingItem17Rating() };

                        WellbeingFunctions.handleWellbeingRatingAfterrender(parms);
                    }
                },
                '#item17ApplicableCases': {
                    'afterrender': function () {

                        var parms = {
                            runValidations: true,
                            dataChanged: false,
                            ratingItemId: 'wellbeingItem17Rating',
                            itemName: 'item17',
                            methodName: 'item17ApplicableCases'
                        };

                        WellbeingFunctions.handleWellbeingAfterrender(parms);
                    }
                },
                // Item 18 Rating
                '#wellbeingItem18Rating': {
                    'afterrender': function () {

                        var parms = { ratingComponent: this.getWellbeingItem18Rating() };

                        WellbeingFunctions.handleWellbeingRatingAfterrender(parms);
                    }
                },
                '#item18B': {
                    'afterrender': function () {

                        var parms = {
                            runValidations: true,
                            dataChanged: false,
                            ratingItemId: 'wellbeingItem18Rating',
                            itemName: 'item18',
                            methodName: 'item18B'
                        };

                        WellbeingFunctions.handleWellbeingAfterrender(parms);
                    }
                },
                '#mbHealthGrid': {
                    'afterrender': function () {

                        Ext.create('App.CaseReview.controller.common.MBHealthGrid', this);

                        var updatedGrid = this.getMbHealthGrid(),
                            parms = {
                                healthGrid: updatedGrid,
                                healthCode: 2,
                                runValidations: true,
                                dataChanged: false,
                                ratingItemId: 'wellbeingItem18Rating',
                                methodName: 'mbHealthGrid_beforerender'
                            };

                        WellbeingFunctions.handleHealthGridAfterrender(parms);
                    },
                    'edit': function (grid, record) {

                        var parms = {
                            runValidations: true,
                            dataChanged: true,
                            ratingItemId: 'wellbeingItem18Rating',
                            methodName: 'mbHealthGrid',
                            data: record,
                            storeId: 'CR_Health_CollectionStore',
                            recordType: 'Grid'
                        };

                        WellbeingFunctions.handleHealthGridEdit(parms);
                    }
                }
            });

            // ReSharper disable WrongExpressionStatement
            // These are not needed anymore!! (Horace)
            /*new App.CaseReview.service.EnableDisable(self.viewModel);
            new App.CaseReview.service.HideShow(self.viewModel);
            new App.CaseReview.service.Validations(self.viewModel);*/
            // End (Horace)
            //new App.CaseReview.controller.FacesheetControls(self);
            // ReSharper restore WrongExpressionStatement
        }
    });
} catch (ex) {

    Rollbar.error("Application Error", ex);
}