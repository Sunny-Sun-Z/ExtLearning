﻿Ext.define('App.CaseReview.controller.CaseReviewStatusCalculation',
{
    extend: 'Ext.Base',
    singleton: true,
    alternateClassName: 'CaseReviewStatusCalculation',

    analyseAndChangeCRStatus : function(store)
    {
        var caseReviewStatus = store.getAt(0).data.CaseStatusCode;
        var caseReviewSubType = store.getAt(0).data.ReviewSubTypeID;

        switch (caseReviewStatus) {

            // Data Entry Complete
            case sr.CaseStatus.DataEntryComplete:

                if (submitToQA == true) {

                    store.getAt(0).data.CaseStatusCode = sr.CaseStatus.QAinProgress;

                    break;
                }
                else if (submitEliminateToApprove == true) {
                    store.getAt(0).data.CaseStatusCode = sr.CaseStatus.CaseEliminatedPendingApproval;
                    break;
                }
                else if (submitToEliminate == true) {
                    store.getAt(0).data.CaseStatusCode = sr.CaseStatus.CaseEliminated;
                    break;
                }
                break;

                // In progress
            case sr.CaseStatus.InProgress:
                // If all items are marked as complete then change data state to data entry Complete
                if (submitEliminateToApprove == true) {
                    store.getAt(0).data.CaseStatusCode = sr.CaseStatus.CaseEliminatedPendingApproval;
                    break;
                }
                else if (submitToEliminate == true) {
                    store.getAt(0).data.CaseStatusCode = sr.CaseStatus.CaseEliminated;
                    break;
                }
                // Put the code to check if a note is available with Descipriotn as not null.

                var outcomeStore = Ext.StoreManager.get('CR_Outcome_CollectionStore');

                // If case is foster type, then a complete case should have 6 Outcomes ( and 14 items in them including facesheet).
                // If case is not foster , then a complete case should have 8 Outcomes ( and 22 items in them including facesheet). 

                if (outcomeStore.count() == 0) 
                    break;

                var allItemsComplete = this.AllItemsComplete();

                if (allItemsComplete) {
                    store.getAt(0).data.CaseStatusCode = sr.CaseStatus.DataEntryComplete;
                }

                break;

                // Not started
            case sr.CaseStatus.NotStarted:
                // Check if facesheet is populated in

                //var faceSheet = Ext.StoreManager.get('CR_FaceSheet_CollectionStore').getAt(0).getData(true);
                //var childDemographicCollection = faceSheet.CR_ChildDemographic_Collection;
                //var participantCollection = faceSheet.CR_CaseParticipant_Collection;
                //if (childDemographicCollection.length > 0 && participantCollection.length > 0) {
                //    store.getAt(0).data.CaseStatusCode = sr.CaseStatus.InProgress;
                //    break;
                //}

                if (submitEliminateToApprove == true) {
                    store.getAt(0).data.CaseStatusCode = sr.CaseStatus.CaseEliminatedPendingApproval;
                }
                if (submitToEliminate == true) {
                    store.getAt(0).data.CaseStatusCode = sr.CaseStatus.CaseEliminated;
                }

                var outcomeStore = Ext.StoreManager.get('CR_Outcome_CollectionStore');
                var faceSheetOutcome = null;
                if (!Ext.isEmpty(outcomeStore) && outcomeStore.count() > 0) {
                    var tempOutcomeStore = Ext.data.ChainedStore.create({
                        source: 'CR_Outcome_CollectionStore',
                        filters: [
                            function (record) {
                                return record.get('OutcomeCode') == 21; // 21 is the outcome code for Facesheet
                            }
                        ]
                    });

                    if (tempOutcomeStore.count() != 0) {
                        faceSheetOutcome = tempOutcomeStore.getAt(0).data;

                        if (!Ext.isEmpty(faceSheetOutcome.CR_Item_Collection) && faceSheetOutcome.CR_Item_Collection.length > 0) {
                            var faceSheetItem = faceSheetOutcome.CR_Item_Collection[0];
                            if (faceSheetItem.StatusCode == sr.ItemStatus.Completed) {
                                store.getAt(0).data.CaseStatusCode = sr.CaseStatus.InProgress;
                            }
                        }
                    }
                }
                break;

                // QA in progress
            case sr.CaseStatus.QAinProgress:
                if (submitToReviewer == true) {
                    store.getAt(0).data.CaseStatusCode = sr.CaseStatus.InProgress;
                }
                if (submitToFinalize == true) {
                    store.getAt(0).data.CaseStatusCode = sr.CaseStatus.FinalizedPendingApproval;
                }

                if (submitToEliminate == true) {
                    store.getAt(0).data.CaseStatusCode = sr.CaseStatus.CaseEliminated;
                }

                if (submitEliminateToApprove == true) {
                    store.getAt(0).data.CaseStatusCode = sr.CaseStatus.CaseEliminatedPendingApproval;
                }

                break;
                // Finalized (Pending Approval)
            case sr.CaseStatus.FinalizedPendingApproval:
                if (returnToQA == true) {
                    store.getAt(0).data.CaseStatusCode = sr.CaseStatus.QAinProgress;
                }
                if (submitToApprove == true) {
                    store.getAt(0).data.CaseStatusCode = sr.CaseStatus.ApprovedandFinal;
                }
                if (submitEliminateToApprove == true) {
                    store.getAt(0).data.CaseStatusCode = sr.CaseStatus.CaseEliminatedPendingApproval;
                }

                if (submitToEliminate == true) {
                    store.getAt(0).data.CaseStatusCode = sr.CaseStatus.CaseEliminated;
                }

                break;
                // Case Eliminated
            case sr.CaseStatus.CaseEliminated:
                break;
                // Approved and Final
            case sr.CaseStatus.ApprovedandFinal:
                break;
                // Case Eliminated Pending Approval
            case sr.CaseStatus.CaseEliminatedPendingApproval:
                // If the case is marked as Eliminated by QA or is QA approved then change t
                if (submitToEliminate == true) {
                    store.getAt(0).data.CaseStatusCode = sr.CaseStatus.CaseEliminated;
                }
                // or if the user is a qa reviewer has marked the case for elimination change it to Eliminated
                break;
            default:
                break;

        }
        //return store;
    },

    AllItemsComplete: function(){

        var result = true;
        var caseType = getCaseType();

        for (key in itemStatuses) {

            var itemCodeObj = getItemCodeFromName(key);

            if (itemCodeObj.ItemCode > 0 && itemCodeObj.ItemCode < 24)
            {
                if (caseType == 'Foster Case') {

                    if (!(itemStatuses[key] == 'Completed')) {

                        result = false;

                        return false;
                    }
                } else {

                    if (itemCodeObj.ItemCode < 5 || itemCodeObj.ItemCode > 12) {

                        if (!(itemStatuses[key] == 'Completed')) {

                            result = false;

                            return false;
                        }
                    }
                }
            }
        }

        return result;
    },
    CheckForOutcomeAndItems: function (caseSubType, outcomeStore) {

        var allItemsCompleted = true;

        // Outcome 1 for Safety
        var tempOutcome1Store = Ext.data.ChainedStore.create({
            source: outcomeStore,
            filters: [
                function (record) {
                    return record.get('OutcomeCode') == 1;
                }
            ]
        }); 

        if (tempOutcome1Store.count() > 0) {

            var outCome1ItemCollection = tempOutcome1Store.getAt(0).data.CR_Item_Collection;
            if (outCome1ItemCollection.length < 1) {// Outcome 1 has 1 Item.
                allItemsCompleted = false;
                return allItemsCompleted;
            } else {

               Ext.Array.forEach(outCome1ItemCollection, function (record) {

                   if (!Ext.isEmpty(record.ItemCode)) {
                       if ((Ext.isEmpty(record.StatusCode)) || record.StatusCode != sr.ItemStatus.Completed) {
                           allItemsCompleted = false;
                           return false;
                       }
                   }

               });

               if (allItemsCompleted == false) {
                   return false;
               }
            }

        } else {
            return allItemsCompleted = false;
        }

        // Outcome 2 for Safety
        var tempOutcome2Store = Ext.data.ChainedStore.create({
            source: outcomeStore,
            filters: [
                function (record) {
                    return record.get('OutcomeCode') == 2;
                }
            ]
        });

        if (tempOutcome2Store.count() > 0) {

            var outCome2ItemCollection = tempOutcome2Store.getAt(0).data.CR_Item_Collection;
            if (outCome2ItemCollection.length < 2) {// Safety Outcome 2 has 2 Items.
                allItemsCompleted = false;
                return allItemsCompleted;
            } else {

                Ext.Array.forEach(outCome2ItemCollection, function (record) {

                    if (!Ext.isEmpty(record.ItemCode)) {
                        if ((Ext.isEmpty(record.StatusCode)) || record.StatusCode != sr.ItemStatus.Completed) {
                            allItemsCompleted = false;
                            return false;
                        }
                    }

                });

                if (allItemsCompleted == false) {
                    return false;
                }
            }

        } else {
            return allItemsCompleted = false;
        }

        // Permanency Outcome, to be checked only if Foster cases
        var caseType = getCaseType();

        if (caseType == 'Foster Case') {

            var tempOutcome3Store = Ext.data.ChainedStore.create({
                source: outcomeStore,
                filters: [
                    function (record) {
                        return record.get('OutcomeCode') == 3;
                    }
                ]
            });

            if (tempOutcome3Store.count() > 0) {

                var outCome3ItemCollection = tempOutcome3Store.getAt(0).data.CR_Item_Collection;
                if (outCome3ItemCollection.length < 3) {// Permanency Outcome 3 has 3 Items.
                    
                    allItemsCompleted = false;
                    return allItemsCompleted;
                } else {

                    Ext.Array.forEach(outCome3ItemCollection, function (record) {

                        if (!Ext.isEmpty(record.ItemCode)) {
                            if ((Ext.isEmpty(record.StatusCode)) || record.StatusCode != sr.ItemStatus.Completed) {
                                allItemsCompleted = false;
                                return false;
                            }
                        }

                    });

                    if (allItemsCompleted == false) {
                        return false;
                    }

                }

            } else {
                return allItemsCompleted = false;
            }

            var tempOutcome4Store = Ext.data.ChainedStore.create({
                source: outcomeStore,
                filters: [
                    function (record) {
                        return record.get('OutcomeCode') == 4;
                    }
                ]
            });

            if (tempOutcome4Store.count() > 0) {

                var outCome4ItemCollection = tempOutcome4Store.getAt(0).data.CR_Item_Collection;
                if (outCome4ItemCollection.length < 5) {// Permanency Outcome 3 has 3 Items.

                    allItemsCompleted = false;
                    return allItemsCompleted;
                } else {

                    Ext.Array.forEach(outCome4ItemCollection, function (record) {

                        if (!Ext.isEmpty(record.ItemCode)) {
                            if ((Ext.isEmpty(record.StatusCode)) || record.StatusCode != sr.ItemStatus.Completed) {
                                allItemsCompleted = false;
                                return false;
                            }
                        }

                    });

                    if (allItemsCompleted == false) {
                        return false;
                    }

                }

            } else {
                return allItemsCompleted = false;
            }
        }


        // Well being Outcome 1
        var tempOutcome5Store = Ext.data.ChainedStore.create({
            source: outcomeStore,
            filters: [
                function (record) {
                    return record.get('OutcomeCode') == 5;
                }
            ]
        });

        if (tempOutcome5Store.count() > 0) {

            var outCome5ItemCollection = tempOutcome5Store.getAt(0).data.CR_Item_Collection;
            if (outCome5ItemCollection.length < 7) {// Well Being Outcome 1 has 7 Items.

                allItemsCompleted = false;
                return allItemsCompleted;
            } else {

                Ext.Array.forEach(outCome5ItemCollection, function (record) {

                    if (!Ext.isEmpty(record.ItemCode)) {
                        if ((Ext.isEmpty(record.StatusCode)) || record.StatusCode != sr.ItemStatus.Completed) {
                            allItemsCompleted = false;
                            return false;
                        }
                    }

                });

                if (allItemsCompleted == false) {
                    return false;
                }

            }

        } else {
            return allItemsCompleted = false;
        }


        // Well Being Outcome 2
        var tempOutcome6Store = Ext.data.ChainedStore.create({
            source: outcomeStore,
            filters: [
                function (record) {
                    return record.get('OutcomeCode') == 6;
                }
            ]
        });

        if (tempOutcome6Store.count() > 0) {

            var outCome6ItemCollection = tempOutcome6Store.getAt(0).data.CR_Item_Collection;
            if (outCome6ItemCollection.length < 1) {
                // Outcome 1 has 1 Item.
                allItemsCompleted = false;
                return allItemsCompleted;
            } else {

                //var item1 = outCome4ItemCollection[0];
                //if (item1.StatusCode == sr.ItemStatus.Completed) {
                //    allItemsCompleted = true;
                //}
                Ext.Array.forEach(outCome6ItemCollection, function (record) {

                    if (!Ext.isEmpty(record.ItemCode)) {
                        if ((Ext.isEmpty(record.StatusCode)) || record.StatusCode != sr.ItemStatus.Completed) {
                            allItemsCompleted = false;
                            return false;
                        }
                    }

                });

                if (allItemsCompleted == false) {
                    return false;
                }

            }

        } else {
            return allItemsCompleted = false;
        }


        // WellBeing Outcome 3
        var tempOutcome7Store = Ext.data.ChainedStore.create({
            source: outcomeStore,
            filters: [
                function (record) {
                    return record.get('OutcomeCode') == 7;
                }
            ]
        });

        if (tempOutcome7Store.count() > 0) {

            var outCome7ItemCollection = tempOutcome7Store.getAt(0).data.CR_Item_Collection;
            if (outCome7ItemCollection.length < 2) {// Wellbeing Outcome 3 has 2 Items.

                allItemsCompleted = false;
                return allItemsCompleted;
            } else {

                Ext.Array.forEach(outCome7ItemCollection, function (record) {

                    if (!Ext.isEmpty(record.ItemCode)) {
                        if ((Ext.isEmpty(record.StatusCode)) || record.StatusCode != sr.ItemStatus.Completed) {
                            allItemsCompleted = false;
                            return false;
                        }
                    }

                });

                if (allItemsCompleted == false) {
                    return false;
                }

            }

        } else {
            return allItemsCompleted = false;
        }

        return allItemsCompleted;
    }
});