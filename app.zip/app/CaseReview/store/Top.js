﻿/* globals App*/
Ext.define('App.CaseReview.store.CaseReviewTop', {
    extend: Ext.data.Store.$className,
    //Fully Qualified Model required
    model: App.model.CaseReviewTop.$className,
    autoLoad: false,
    proxy: {
        type: 'direct',
        api: {
            read: window.Data.GetData
        },
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    }
});