﻿/* globals App*/
//Ext.define('App.CaseReview.store.LookUp', {
//    extend: Ext.data.Store.$className,
//    //Fully Qualified Model required
//    model: App.model.LookUp.$className,
//    autoLoad: false,
//    proxy: {
//        type: 'direct',
//        api: {
//            read: window.Data.GetDataLookUp
//        },
//        reader: {
//            type: 'json',
//            rootProperty: 'data'
//        }
//    }
//});