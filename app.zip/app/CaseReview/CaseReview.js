﻿Ext.require('Ext.direct.Manager');
Ext.app.REMOTING_API.timeout = 300000;
Ext.app.REMOTING_API.maxRetries = 0;

Ext.direct.Manager.addProvider(Ext.app.REMOTING_API);

Ext.Date.useStrict = true;

var arrowRefresh = window.baseUrl + '/content/icons/arrow_refresh.png';
var addButtonImage = window.baseUrl + '/content/icons/plus-circle-frame.png';
var editButtonImage = window.baseUrl + '/content/icons/pencil.png';
var deleteButtonImage = window.baseUrl + '/content/icons/cross-circle-frame.png';
var saveButtonImage = window.baseUrl + '/content/icons/database_add.png';
var deleteButtonImage = window.baseUrl + '/content/icons/cross-circle-frame.png';
var sr = App.Common.StringResources;
var caseReviewSpacing = 900;
var submitToQA = false;
var returnToQA = false;
var submitToReviewer = false;
var submitToFinalize = false;
var submitToEliminate = false;
var submitToApprove = false;
var submitEliminateToApprove = false;
var currentTab = "";
var viewportWidth;
var viewportHeight;
var msgStartX;
var appMessage;
var msgDisplayObj;

Ext.Loader.setConfig({
    enabled: true,
    disableCaching: false,
    paths: {
        framework: window.cdnUrl + '/cdn/js/framework/' + window.extVersion + '/framework',
        Sacwis: window.cdnUrl + '/cdn/js/Sacwis',
        App: '/App'
    }
});


Ext.onReady(function () {
    //"use strict";

    //Ext.Ajax.on('requestexception', function (conn, response, options, eOpts) {
    //    var error = response.status + ' - ' + response.statusText;
    //    Ext.Msg.alert('Danger!', error);
    //});
        
    try {
        Ext.tip.QuickTipManager.init();

        Ext.getBody().mask('<b>Loading</br> Please wait </b>');
        // make sure the DirectAPI got loaded (currently a problem in FireFox during Selenium Test
       
        var saveButton;
        
        var startup = function () {

            ////
            //// Create a floating save button within a panel
            ////
            //saveButton = Ext.create('Ext.form.Panel', {
            //    renderTo: Ext.getBody(),
            //    floating: true,
            //    layout: 'hbox',
            //    items: [
            //        {
            //            xtype: 'button',
            //            text: 'Save Case',
            //            itemId: 'saveCaseButton',
            //            height: 30,
            //            width: 100
            //        },
            //        {
            //            xtype: 'component',
            //            border: false,
            //            bodyCls: 'panel-background-color',
            //            margin: '0 0 0 10'
            //        },
            //        {
            //            xtype: 'button',
            //            text: 'Save Case and Continue',
            //            itemId: 'saveCaseContinueButton',
            //            height: 30,
            //            width: 180
            //        }
            //    ]
            //});

            //Ext.WindowManager.bringToFront(saveButton);
            //
            // Create a floating display for messages
            //
            appMessage = Ext.create('Ext.form.Panel', {
                renderTo: Ext.getBody(),
                floating: true,
                layout: 'fit',
                hidden: true,
                items: [
                    {
                        xtype: 'displayfield',
                        itemId: 'appMessage',
                        height: 30,
                        width: 220,
                        padding: 0,
                        value: 'Changes were saved successfully!!',
                        margin: '0 10 0 10'
                    }
                ]
            });

            Ext.WindowManager.bringToFront(appMessage);
            
            Ext.application({
                autoCreateViewport: false,
                appFolder: window.appDir + "/App",
                controllers: ['App.CaseReview.controller.Main'],
                name: 'App'
            });
        };
        
        startup();

        viewportWidth = Ext.getBody().getViewSize().width;
        viewportHeight = Ext.getBody().getViewSize().height;

        //saveButton.setPagePosition(viewportWidth * 0.82, viewportHeight * 0.85);
        msgStartX = viewportWidth * 0.85;

        appMessage.setPagePosition(msgStartX, 0);

        caseReviewSpacing = Ext.getBody().getViewSize().width - 300;
    }
    catch (exception) {
        alert(exception);
    }
});