﻿/* globals App */
Ext.define('App.CaseReview.service.EnableDisable',
{
    extend: Ext.Base.$className,
    constructor: function (viewModel) {
        //"use strict";
        var sr = App.Common.StringResources;
        var enableDisableTimeoutId = 0;

        var enableDisable = function () {
            //enableDisableTimeoutId = 0;
            Ext.suspendLayouts();
            viewModel.enableAll();
            if (viewModel.getValue(sr.MAINDATA.CHILDREN_EXIST) !== 'Y')
            {
                viewModel.disable(sr.ItemIds.gridChildren); // the itemId we want to disable
            }
            Ext.resumeLayouts();
        };
        //var enableDisableTimeoutId = 0;
        viewModel.on('setValue', function (name /*, value */)
        {
            // you probably want to filter by names that will have impact
            if (name !== sr.MAINDATA.CHILDREN_EXIST)
            {
                return;
            }

            if (enableDisableTimeoutId !== 0) {
                return;
            }
            enableDisableTimeoutId = setTimeout(enableDisable, 0);
        });
    }
});