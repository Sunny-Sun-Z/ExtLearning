﻿Ext.define('app.CaseReview.model.CaseReview', {
    extend: 'Ext.data.Model',
    fields: [
        { name: 'CaseID', type: 'int' },
        { name: 'CaseName', type: 'string'},
        { name: 'CaseReviewID', type: 'int' },
        { name: 'CaseReviewRootID', type: 'int'},
        { name: 'CaseStatusCode', type: 'int' },
        { name: 'ReviewTypeID', type: 'int'},
        { name: 'ReviewSubTypeID', type: 'int' },
        { name: 'SiteCode', type: 'int'},
        { name: 'IsPIPMonitored', type: 'int'},
        { name: 'InitialQAUserID', type: 'int' },
        { name: 'SecondQAUserID', type: 'int' },
        { name: 'SecondaryOversightUserID', type: 'int' },
        { name: 'CtSecondaryOversightUserID', type: 'int' },
        { name: 'ReviewStartDate', type: 'date', defaultValue: null },
        { name: 'ReviewCompleted', type: 'date', defaultValue: null },
        { name: 'CR_Reviewer_Collection', type: 'auto', defaultValue: [] }
    ]
});