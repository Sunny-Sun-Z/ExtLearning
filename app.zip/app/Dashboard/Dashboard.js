﻿Ext.require('Ext.direct.Manager');
Ext.app.REMOTING_API.timeout = 300000;
Ext.app.REMOTING_API.maxRetries = 0;

Ext.direct.Manager.addProvider(Ext.app.REMOTING_API);

Ext.Date.useStrict = true;

Ext.Loader.setConfig({
    enabled: true,
    disableCaching: false,
    paths: {
        framework: window.cdnUrl + '/cdn/js/framework/' + window.extVersion + '/framework',
        Sacwis: window.cdnUrl + '/cdn/js/Sacwis',
        App: '/App'
    }
});

Ext.onReady(function ()
{
    //"use strict";
    try
    {
        Ext.tip.QuickTipManager.init();

        Ext.getBody().mask('<b>Loading</br> Please wait </b>');
        // make sure the DirectAPI got loaded (currently a problem in FireFox during Selenium Test
        var startup = function ()
        {
            Ext.application({
                autoCreateViewport: false,
                appFolder: window.appDir + "/App",
                controllers: ['App.Dashboard.controller.Main'],
                name: 'App'
            });
        };
        startup();
    }
    catch (exception)
    {
        alert(exception);
    }
});