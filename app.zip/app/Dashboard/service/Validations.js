﻿Ext.define('App.service.Validations',
{
    extend: Ext.Base.$className,
    constructor: function (viewModel)
    {
        //"use strict";
        var validateTimeoutId = 0;

        var validate = function ()
        {
            //validateTimeoutId = 0;
            Ext.suspendLayouts();
            var valid = viewModel.getValue('MAINDATA.LASTNAMENOTVALID');
            if (valid === 'Y') {
                viewModel.setValidationError('MAINDATA_LASTNAME', ['Last Name is Not Valid Now!']);

            } else {
                viewModel.setValidationError('MAINDATA_LASTNAME', []);
            }
            Ext.resumeLayouts();
        };
        //var validateTimeoutId = 0;
        viewModel.on('setValue', function (name /*, value*/)
        {
            // you probably want to filter by names that will have impact
            if (name !== 'MAINDATA.LASTNAMENOTVALID')
            {
                return;
            }

            if (validateTimeoutId !== 0)
            {
                return;
            }
            validateTimeoutId = setTimeout(validate, 0);
        });
    }
});