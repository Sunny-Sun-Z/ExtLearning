﻿Ext.isHandlingError = false;
Ext.lastError = null;
Ext.Error.handle = function (error)
{
    //"use strict";
    if (Ext.isHandlingError)
    {
        return;
    }
    Ext.isHandlingError = true;
    if (error.msg)
    {
        error.description = error.msg;
        error.stack = error.sourceClass + ":" + error.sourceMethod;
    }
    if (!error.description)
    {
        error = { description: error, stack: '' };
    }
    if (!error.stack)
    {
        error.stack = "no stack available";
    }
    error = { errorDescription: error.description, stack: error.stack };
    if (!Ext.lastError || error.errorDescription !== Ext.lastError.errorDescription || error.stack !== Ext.lastError.stack)
    {
        window.JavaScriptException.Log(error);
        Ext.lastError = { errorDescription: error.description, stack: error.stack };
    }
    Ext.isHandlingError = false;
};
window.onerror = function (m, u, l, c, error)
{
    //"use strict";
    if (!error)
    {
        return;
    }
        
    Ext.Error.handle(error);
};