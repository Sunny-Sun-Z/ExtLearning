﻿/* globals App*/
Ext.define('App.Dashboard.store.CaseReviewDashboardTop', {
    extend: Ext.data.Store.$className,
    //Fully Qualified Model required
    model: App.model.CaseReviewDashboardTop.$className,
    autoLoad: false,
    proxy: {
        type: 'direct',
        api: {
            read: window.Data.GetDashboardLookup
        },
        reader: {
            type: 'json',
            rootProperty: 'data'
        }
    }
});