﻿/* globals App*/
Ext.define('App.Dashboard.view.Main',
{
    // Forms have to be children of tabs so our top level
    // control is derived from a Panel.
    //
    // This view is launched by the controller.
    extend: Ext.panel.Panel.$className,
    renderTo: 'ext',
    border: false,
    initComponent: function () {
        

 //if you don't have any stores yet, use this instead
        
        var chainedStore = function (parentStore) {

            if (Ext.data.StoreManager.get(parentStore) == null) {
                return [];
            }
            return new Ext.data.ChainedStore({ source: parentStore });

        };

        var me = this;
        
        // these values keep us from having to type everything out
        // every time we want to put icons on the screen and makes it
        // easy to change their values in one place
        /* Commented the definitions below because they are not being used*/
        var windowBaseUrl = window.baseUrl;
        var sr = App.Common.StringResources;
        //var arrowRefresh = windowBaseUrl + '/content/icons/arrow_refresh.png';
        var addButtonImage = windowBaseUrl + '/content/icons/plus-circle-frame.png';
        var editButtonImage = windowBaseUrl + '/content/icons/pencil.png';
        var deleteButtonImage = windowBaseUrl + '/content/icons/cross-circle-frame.png';
        var saveButtonImage = window.baseUrl + '/content/icons/database_add.png';

        var reviewerStore = chainedStore('CrSecurityUserStore');

        reviewerStore.sort([
            {
                property: 'LastName',
                direction: 'ASC'
            },
            {
                property: 'FirstName',
                direction: 'ASC'
            }
        ])

        Ext.applyIf(me, {
            xtype: 'container',
            plugins: 'viewport',
            layout: 'fit',
            items: [
            {
                xtype: 'viewport',
                title: 'Border Layout',
                layout: 'border',
                bodyBorder: false,
                items: [
                {
                    region: 'south',
                    width: 100,
                    xtype: 'panel',
                    split: true,
                    layout: 'fit',
                    contentEl: 'divfootertext',
                    collapsible: true,
                    collapsed: true
                },
                {
                    region: 'center',
                    xtype: 'container',
                    layout: 'fit',
                    items: [
                    {
                        xtype: 'tabpanel',
                        layout: 'fit',
                        itemId: 'centerTabPanel',
                        activeTab: 1,
                        items: [
                        {
                            title: 'CRS',
                            iconCls: 'brand',
                            disabled: true

                        }, {
                            title: 'Dashboard',
                            xtype: 'form',
                            itemId: 'dashboard',
                            layout: 'border',
                            defaults: {
                                collapsible: true,
                                split: true,
                                bodyStyle: 'padding:15px'
                            },

                            items: [
                            {
                                region: 'west',
                                xtype: 'panel',
                                collapsible: true,
                                header: false,
                                width: 300,
                                border: false,
                                bodyStyle: { "background-color": "#EEEEEE" },
                                layout: 'vbox',
                                items: [
                                    {
                                        //
                                        xtype: 'panel',
                                        html: '<h2>Search Criteria</h2>',
                                        bodyStyle: { "background-color": "#EEEEEE" },
                                        margin: '1 0 0 10'

                                    }, {
                                        //TYPE
                                        xtype: 'combobox',
                                        itemId: 'typeID',
                                        fieldLabel: 'Type',
                                        margin: '1 0 0 10',
                                        labelWidth: 100,
                                        editable: false,
                                        store: 'CrReviewTypeStore',
                                        displayField: 'Description',
                                        valueField: 'ReviewTypeID',
                                        listeners: {
                                            select: function(combo, record, index) {
                                                
                                                var selVal = combo.getValue();

                                                var subTypeStore = Ext.data.ChainedStore.create({
                                                    source: 'CrReviewSubTypeStore',
                                                    filters: [
                                                        function (record) {
                                                            return record.get('ReviewTypeID') == selVal;
                                                        }
                                                    ]
                                                });

                                                var subTypeCombo = Ext.ComponentQuery.query('#subTypeID')[0];

                                                subTypeCombo.setStore(subTypeStore);
                                            }
                                        }
                                    },
                                    {
                                        //TYPE
                                        xtype: 'combobox',
                                        itemId: 'subTypeID',
                                        fieldLabel: 'Sub Type',
                                        margin: '1 0 0 10',
                                        labelWidth: 100,
                                        //store: 'CrReviewSubTypeStore',
                                        displayField: 'Description',
                                        valueField: 'ReviewSubTypeID'

                                    }, {
                                        //MEETING ID
                                        xtype: 'textfield',
                                        itemId: 'meetingID',
                                        fieldLabel: 'Meeting ID',
                                        margin: '1 0 0 10',
                                        labelWidth: 100

                                    }, {
                                        //CASE ID
                                        xtype: 'textfield',
                                        name: 'caseID',
                                        itemId: 'caseID',
                                        fieldLabel: 'Case ID',
                                        margin: '1 0 0 10',
                                        labelWidth: 100,

                                    }, {
                                        //CASE ID
                                        xtype: 'textfield',
                                        name: 'name',
                                        itemId: 'name',
                                        fieldLabel: 'Case Name',
                                        margin: '1 0 0 10',
                                        labelWidth: 100,

                                    },
                                    {
                                        //CASE ID
                                        xtype: 'combo',
                                        name: 'status',
                                        itemId: 'status',
                                        fieldLabel: 'Status',
                                        margin: '1 0 0 10',
                                        labelWidth: 100,
                                        editable: false,
                                        store: 'CaseStatusStore',
                                        displayField: 'DescriptionLarge',
                                        valueField: 'GroupID'

                                    }, {
                                        //CASE ID
                                        xtype: 'datefield',
                                        name: 'rstart',
                                        itemId: 'rstart',
                                        fieldLabel: 'Review Start',
                                        margin: '1 0 0 10',
                                        labelWidth: 100,
                                        maxValue: new Date(),
                                        minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30)

                                    }, {
                                        //CASE ID
                                        xtype: 'datefield',
                                        name: 'rend',
                                        itemId: 'rend',
                                        fieldLabel: 'Review End',
                                        margin: '1 0 0 10',
                                        labelWidth: 100,
                                        maxValue: new Date(),
                                        minValue: Ext.Date.subtract(new Date(), Ext.Date.YEAR, 30)

                                    },
                                    {
                                        //CASE ID
                                        xtype: 'combobox',
                                        name: 'site',
                                        itemId: 'site',
                                        fieldLabel: 'Site',
                                        margin: '1 0 0 10',
                                        labelWidth: 100,
                                        store: 'SiteStore',
                                        editable: false,
                                        displayField: 'DescriptionLarge',
                                        valueField: 'GroupID'

                                    }, {
                                        ////CASE ID
                                        //xtype: 'combobox',
                                        //name: 'reviewers',
                                        //itemId: 'reviewers',
                                        //fieldLabel: 'Reviewers',
                                        //editable: false,
                                        //margin: '1 0 0 10',
                                        //labelWidth: 100,
                                        //store: 'CrSecurityUserStore',
                                        //tpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '<div class="x-boundlist-item">{FirstName} {LastName}</div>', '</tpl>'),
                                        //displayTpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '{FirstName} {LastName}', '</tpl>'),
                                        //valueField: 'UserID'
                                        xtype: 'combobox',
                                        name: 'reviewers',
                                        itemId: 'reviewers',
                                        fieldLabel: 'Reviewers',
                                        editable: false,
                                        margin: '1 0 0 10',
                                        labelWidth: 100,
                                        //store: 'CrSecurityUserStore',
                                        store: reviewerStore,
                                        tpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '<div class="x-boundlist-item">{LastName}, {FirstName}</div>', '</tpl>'),
                                        displayTpl: Ext.create('Ext.XTemplate', '<tpl for=".">', '{LastName}, {FirstName}', '</tpl>'),
                                        valueField: 'UserID'

                                    },
                                    {
                                        xtype: 'panel',
                                        itemId: 'buttonsPanel',
                                        border: false,
                                        bodyStyle: { "background-color": "#EEEEEE" },
                                        items: [
                                            {
                                                //RESET BUTTON
                                                xtype: 'button',
                                                itemId: 'btnSearchReset',
                                                margin: '10 10 0 38',
                                                text: '<font size=2><b>Reset all</b></font>',
                                                scale: 'medium',
                                                width: 90
                                            }, {
                                                //SEARCH BUTTON
                                                xtype: 'button',
                                                id: 'btnSearch',
                                                itemId: 'btnSearch',
                                                margin: '10 0 0 15',
                                                text: '<font size=3><b>Search</b></font>',
                                                scale: 'medium',
                                                width: 90
                                            }
                                        ]
                                    },
                                    //Tips Panel
                                    {
                                        xtype: 'panel',
                                        itemId: 'notesPanel',
                                        border: true,
                                        width: '95%',
                                        margin: '10 0 0 10',
                                        html: "<div style='background-color:#FFFF99;height:135px;border-style:solid;border-width:1px;border-color:FFCC66;margin: 0px 0px 0px 0px;padding: 10px 10px 10px 10px;'>" +
                                                  "<div style='float: left;font-size:1em; font-weight: bold'>Search Tips:</div><br/>" +
                                                  "<div><font size='2em'>Wildcards</font><font size='5em'>(*)</font><font size='2em'>&nbsp;can be used like this:</font></div>" +
                                                  "<div style='float: left;font-size:1em;padding: 5px 0px 0px 10px;'>Starts with:&nbsp; 123<FONT size='5em'>*</FONT>&nbsp;&nbsp;or&nbsp;&nbsp;Rod<FONT size='5em'>*</FONT></div>" +
                                                  "<div style='float: left;font-size:1em;padding: 5px 0px 0px 10px;'>Ends with:&nbsp; <FONT size='5em'>*</FONT>234&nbsp;&nbsp;or&nbsp;&nbsp;<FONT size='5em'>*</FONT>guez</div>" +
                                                  "<div style='float: left;font-size:1em;padding: 5px 0px 0px 10px;'>Contains:&nbsp; <FONT size='5em'>*</FONT>23<FONT size='5em'>*</FONT>&nbsp;&nbsp;or&nbsp;&nbsp;<FONT size='5em'>*</FONT>gue<FONT size='5em'>*</FONT></div>" +
                                              "</div>"

                                    }
                                ]

                            },
                            {
                                region: 'center',
                                xtype: 'panel',
                                header: false,
                                //scrollable: 'auto',
                                layout: 'vbox',
                                items: [
                                {
                                    //
                                    xtype: 'panel',
                                    html: '<h1>Dashboard</h1>',
                                    height:40

                                },
                                {
                                    //RESULTS GRID
                                    xtype: 'gridpanel',
                                    flex: 1,
                                    border: true,
                                    loadMask: true,
                                    //scrollable: 'auto',
                                    scrollable: true,
                                    // layout : 'fit',
                                    title: '<font size="4">Available Cases</font>',
                                    store: 'CaseReviewDashboardSearchStore',
                                    itemId: 'caseReviewDashboardSearch',
                                    // height: 500,
                                    width: '100%',
                                    magrin: '20 20 100 20',
                                    autoHeight: true,
                                    columns: [
                                    {
                                        text: 'View',
                                        //width: 30,
                                        renderer: function(val, meta, record) {
                                            return '<a href="/CaseReview/Index/' + record.data.CaseReviewRootID + '/">View</a>';
                                        }
                                    },
                                    {
                                        text: 'Case ID',
                                        dataIndex: 'CaseID'
                                    },
                                    {
                                        text: 'Meeting ID',
                                        //width: '5%',
                                        dataIndex: 'MeetingID'
                                        //,renderer: function (val, meta, record) {
                                        //    return '<a href="/CaseReview/Index/' + record.data.CaseReviewRootID + '/">' + val + '</a>';
                                        //}
                                    },
                                    {
                                        text: 'Type',
                                        //width: '5%',
                                        dataIndex: 'ReviewTypeID',
                                        renderer: function(value) {
                                            var lookupStore = chainedStore('CrReviewTypeStore');
                                            var results = lookupStore.query('ReviewTypeID', value, false, false, true);
                                            if (results.length > 0) {
                                                return results.getAt(0).data.Description;
                                            }

                                            return '';
                                        }
                                    },
                                    {
                                        text: 'Sub Type',
                                        //width: '7%',
                                        dataIndex: 'ReviewSubTypeID',
                                        renderer: function(value) {
                                            var lookupStore = chainedStore('CrReviewSubTypeStore');
                                            var results = lookupStore.query('ReviewSubTypeID', value, false, false, true);
                                            if (results.length > 0) {
                                                return results.getAt(0).data.Description;
                                            }

                                            return '';
                                        }
                                    },
                                    {
                                        text: 'Case Name',
                                        //width: '15%',
                                        dataIndex: 'CaseName'

                                    },
                                    {
                                        text: 'Status',
                                        //width: '10%',
                                        dataIndex: 'CaseStatusCode',
                                        renderer: function(value) {
                                            var lookupStore = chainedStore('CaseStatusStore');
                                            var results = lookupStore.query('GroupID', value, false, false, true);
                                            if (results.length > 0) {
                                                return results.getAt(0).data.DescriptionLarge;
                                            }

                                            return '';
                                        }
                                    },
                                    {
                                        text: 'Review Start',
                                        //width: '7%',
                                        dataIndex: 'ReviewStartDate',
                                        renderer: Ext.util.Format.dateRenderer('m/d/Y')
                                    },
                                    {
                                        text: 'Review End',
                                        //width: '7%',
                                        dataIndex: 'ReviewCompleted',
                                        renderer: Ext.util.Format.dateRenderer('m/d/Y')
                                    },
                                    {
                                        text: 'Site Name',
                                        //width: '10%',
                                        dataIndex: 'SiteCode',
                                        renderer: function(value) {
                                            var lookupStore = chainedStore('SiteStore');
                                            var results = lookupStore.query('GroupID', value, false, false, true);
                                            if (results.length > 0) {
                                                return results.getAt(0).data.DescriptionLarge;
                                            }

                                            return '';
                                        }
                                    },
                                    {
                                        text: 'Reviewer(s)',
                                        dataIndex: 'Reviewers'

                                        //dataIndex: 'UserID',
                                        //renderer: function (val, meta, record) {
                                        //        if (!Ext.isEmpty(record.data.CR_Reviewer_Collection)) {
                                        //            var reviewers = "";
                                        //            for (var iCount = 0; iCount < record.data.CR_Reviewer_Collection.length; iCount++) {
                                        //                reviewers = reviewers + record.data.CR_Reviewer_Collection[iCount].FullName + ", ";
                                        //            }
                                        //            reviewers = reviewers.substring(0, reviewers.lastIndexOf(','));
                                        //            return reviewers;
                                        //        }
                                    }                                    
                                    ],
                                    viewConfig: {
                                        listeners: {
                                            refresh: function (dataview) {
                                                Ext.each(dataview.panel.columns, function(column) {
                                                    column.autoSize();
                                                });
                                            }
                                        }
                                    }

                                    }
                                    ]
                                    }]
                            },
                            {
                                title: 'Create New Case',
                                itemId: 'createCaseReview',
                                layout: 'fit'
                            },
                            {
                                title: 'Security Management',
                                itemId: 'securityManagement',
                                layout : 'fit'
                            }
                        ]
                    }]
                }
                ]
            }

            ]
        }
        );
        me.callParent(arguments);
    }
});